# CLAUDE.md

This file provides guidance to Claude Code when working with this repository.

## Commands

```bash
pnpm dev         # Start development server (http://localhost:3030)
pnpm build       # Production build
pnpm lint        # Run ESLint
```

## Architecture

Next.js 16 site for Odyssey Alive, an AI automation consulting business.

### Route Groups

- `(marketing)` -- Clean layout for `/services`, `/projects`, `/contact`, `/presentations`
- `(editorial)` -- Watercolor-themed layout for `/about`, `/focus`
- `/slides/[slug]` -- Standalone (root layout only, no header/footer) for reveal.js presentations

### Header Transparency

```tsx
<HeroHeader transparent darkHero />
```

- `transparent` — Translucent header that becomes solid on scroll
- `darkHero` — Dark translucent background with light text

If menu text is hard to read on a light hero, remove `darkHero` for light background with dark text.

### Content System

Focus posts managed with Velite (MDX):
- Source: `content/focus/*.mdx`
- Generated: `.velite/` (gitignored)
- Import via `#site/content` path alias

Required frontmatter: `title`, `slug`, `description`, `date`, `category`
Categories: `ai-transformation`, `pattern-recognition`, `case-studies`, `field-notes`
Optional: `sideQuest: true` for non-tech passion projects

Presentations managed with Velite (MDX):
- Source: `content/presentations/*.mdx`
- Slides separated by `---` (horizontal rule) in MDX body
- Viewer at `/slides/[slug]` (full-screen reveal.js, no site chrome)
- Directory at `/presentations` (marketing layout, not linked from navigation)
- Required frontmatter: `title`, `slug`, `description`, `date`
- Optional: `event`, `image`
- Speaker notes: `<aside class="notes">` blocks (press S in presentation)

### Asset Pipeline

Source assets live in `assets/` (committed to git). During build:
- **Velite** processes content images → `public/static/` (with hashes)
- **copy-assets.js** copies non-Velite assets → `public/images/`, `public/svg/`

| Asset Type | Source Location | Build Output |
|------------|-----------------|--------------|
| Focus hero images | `assets/images/focus/hero/` | `public/static/` |
| Focus inline images | `assets/images/focus/inline/[slug]/` | `public/static/` |
| Project hero images | `assets/images/projects/hero/` | `public/static/` |
| Presentation hero images | `assets/images/presentations/hero/` | `public/static/` |
| Presentation slide images | `assets/images/presentations/inline/[slug]/` | `public/static/` |
| Page images | `assets/images/pages/` | `public/images/` |
| SVGs | `assets/svg/` | `public/svg/` |

The `public/static/`, `public/images/`, and `public/svg/` directories are gitignored and regenerated on each build.

### Styling

- Tailwind CSS 4 with brand colors in `src/app/globals.css`
- Palette: `brand-black`, `brand-cream`, `brand-coral`, `brand-accent`, `brand-bg`
- Fonts: Inter (sans) and Playfair Display (serif) via `next/font`
- No dark mode — warm, light-only brand
- Use `cn()` from `@/lib/utils` for conditional class merging

### Path Aliases

- `@/*` → `./src/*`
- `#site/content` → `./.velite`

## Project Structure

```
odyssey-alive/
├── assets/                  # Source assets (committed)
│   ├── images/
│   │   ├── focus/hero/      # Focus article hero images
│   │   ├── focus/inline/    # Focus article inline images by slug
│   │   ├── projects/hero/   # Project hero images
│   │   └── pages/           # Page images (about, services, etc.)
│   └── svg/                 # SVG icons and graphics
├── content/
│   ├── focus/               # MDX focus posts
│   ├── presentations/       # MDX presentation slides
│   └── projects/            # MDX project posts
├── public/                  # Build output (mostly gitignored)
│   ├── static/              # Velite-processed images (gitignored)
│   ├── images/              # Copied page images (gitignored)
│   └── svg/                 # Copied SVGs (gitignored)
├── scripts/
│   └── copy-assets.js       # Asset copy script for build
├── src/
│   ├── app/
│   │   ├── (marketing)/     # services, projects, contact
│   │   ├── (editorial)/     # about, focus
│   │   ├── globals.css      # Global styles + Tailwind
│   │   └── layout.tsx       # Root layout
│   ├── components/          # focus/, editorial/, forms/, layout/, marketing/, ui/
│   ├── lib/actions/         # Server actions
│   └── types/               # TypeScript definitions
└── .velite/                 # Generated content (gitignored)
```

## Tech Stack

- **Framework:** Next.js 16.1.0 (App Router), React 19.2.3
- **Styling:** Tailwind CSS 4, Framer Motion
- **Content:** Velite (MDX processing)
- **Email:** Nodemailer with Apple SMTP
- **Validation:** Zod

## Skills

On-demand skills in `.claude/skills/`. Invoke with `/skillname`. Run `/skill-builder skills` for the full list.

Key skills: `/focus` (articles), `/edit` (content revision gateway), `/present` (conference slides), `/voice` + `/writing` (content foundation), `/image` (watercolor generation), `/promote` (social media), `/ynab` `/zoho` `/timesheet` (business ops), `/skill-builder` (skill management), `/awareness-ledger` (institutional memory).

**Awareness Ledger:** Consult `.claude/skills/awareness-ledger/ledger/index.md` before planning work that touches areas with prior incidents or decisions.

---

## Important Rules

- **Use respectful language for client work** — Use "established," "mature," "production" instead of "legacy," "old," "outdated"
- **Add ShareButton to shareable content pages** — Place after hero AND at end of content
- **Use `frontend-design` skill for UI work**
- **Maintain warm, light-only brand aesthetic** — no dark mode
- **Keep components organized by concern** in appropriate subdirectories
- **Temporal references are literal.** "This week," "today," "this month" always mean the current calendar date, never a date in the content being discussed or edited.
- **Use Playwright, not the Chrome browser plugin, for visual debugging.** Use Playwright instead of the Chrome browser plugin to visually view and debug sites, every time. At the end of every debug session, no temporary files, images, etc. should be left over after the debugging has been completed. *(Added 2026-04-11.)*
- **Plan or execute, not both.** When the user provides or approves a plan, proceed to implementation. Don't continue brainstorming or elaborating. If clarification is truly needed, ask one focused question.
- **Only do what was asked.** Don't add bonus deliverables, extra options, or unrequested scope. Ask before expanding.
- **Log failures.** When you encounter bugs, add to the **Discovered Issues Log** in the relevant skill file. Build/dev issues go in this file.
- **Route all content edits through `/edit`.** When modifying body text in any content file or drafted text (focus articles, social posts, newsletters, presentations), invoke `/edit` to load the writing kernel first. This applies whether the change comes from a skill pipeline or a standalone user request. The only exception is mechanical changes (fixing a typo, updating a date, correcting a URL) that don't touch prose.
