---
name: quo
description: "Look up Quo (OpenPhone) calls, transcripts, and SMS for a contact, or review all recent texts across inboxes. Modes: lookup, review, messages, calls, send. Usage: /quo [mode] [contact]"
allowed-tools: Read, Grep, Bash, Task, mcp__claude_ai_Quo__list-contacts, mcp__claude_ai_Quo__get-contact, mcp__claude_ai_Quo__fetch-call-transcripts, mcp__claude_ai_Quo__fetch-messages, mcp__claude_ai_Quo__fetch-missed-calls, mcp__claude_ai_Quo__send-message
minimum-effort-level: high
strictness: standard
---

# Quo

Contact-first lookup over Quo (formerly OpenPhone): resolve a person by name, pull their recent calls, transcripts, and SMS, and surface the concrete action items discussed (e.g. "which event/site am I supposed to debug to fix the Gravity Forms situation"). The calls/SMS analogue of `/email`.

## Modes

| Mode | Command | Description |
|------|---------|-------------|
| `lookup` | `/quo` or `/quo lookup <name>` | Resolve a contact name → phone number(s), then show a combined recent calls + SMS digest with extracted action items (default) |
| `review` | `/quo review` | Read-only sweep of ALL recent SMS across every inbox, ranked by what needs a reply (not contact-scoped) |
| `messages` | `/quo messages <name\|number>` | Recent SMS thread with one contact |
| `calls` | `/quo calls <name\|number>` | Recent calls with a contact; per-call summary, escalating to full transcript only when the summary is thin; includes missed calls |
| `send` | `/quo send <name\|number>` | Compose and send an SMS — confirmation-gated, prose routed through `/voice` + `/writing` |

Default mode is `lookup` if not specified.

---

<!-- origin: user | added: 2026-06-02 | immutable: true -->
## Directives

> **Never auto-send.** Every outbound SMS must be shown to the user in full and explicitly confirmed before `send-message` is called. Unlike an email draft, a sent text is transmitted immediately and cannot be recalled.

> **Maintain SBDC / Odyssey Alive separation.** Outbound messages must never reference an SBDC role or AI-consulting engagement when speaking for Odyssey Alive. AI consulting is SBDC-only; Odyssey Alive positions on web development and automation.

> **Route outbound prose through `/voice` and `/writing`.** Any SMS body drafted in `send` mode is content — load the voice and writing protocol before composing, the same as any other correspondence.

*— Added 2026-06-02, source: user instruction (skill creation via /route → /skill-builder new) + standing content/business-separation preferences*
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Never auto-send. Every outbound SMS must be shown to the user in full and explicitly confirmed before send-message is called." -->
CHECKPOINT — Outbound SMS Confirmation Gate (fires in `send` mode only):
1. After drafting the SMS body and resolving the recipient number, render to the user: recipient name + number, the sending inbox, and the full message text verbatim.
2. STOP and wait for explicit confirmation ("send", "yes", "go"). A request to revise is NOT confirmation — revise and re-render, then STOP again.
3. IF the user has not explicitly confirmed → do NOT call `mcp__claude_ai_Quo__send-message`. Do not infer consent from earlier turns.
4. IF confirmed → send exactly the rendered text. Do not alter wording between confirmation and send.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Route outbound prose through /voice and /writing. Any SMS body drafted in send mode is content — load the voice and writing protocol before composing, the same as any other correspondence." -->
CHECKPOINT — Outbound Prose Protocol Gate (fires in `send` mode only):
1. Before drafting any SMS body, verify both `/voice` and `/writing` have been loaded via the Skill tool IN THIS conversation. Recall of their content from a previous session does not count as loaded.
2. IF either is not loaded → STOP. Invoke `Skill(voice)` then `Skill(writing)` before composing a single word of the body.
3. Only after both are loaded → draft the SMS body.
4. IF a draft was produced before the protocols loaded → discard it and redraft from scratch; do not patch the pre-protocol draft.
<!-- END ENFORCEMENT ANNOTATION -->

---

<!-- origin: skill-builder | version: 1.0 | modifiable: true -->
## Integration model

`quo` is a **hybrid**: the Quo MCP server resolves contacts (the one thing the REST script cannot do), and the existing `quo-fetch.sh` REST integration does the bulk message/call/transcript retrieval.

- **Contact resolution (name → number):** Quo MCP only. `quo-fetch.sh` keys on inbox-ID + time window and has no contact-name search, so a name lookup MUST go through `mcp__claude_ai_Quo__list-contacts` / `get-contact`. Every mode that begins with "Resolve `<name>` → number" delegates this step to the **contact-resolver** agent ([agents/contact-resolver/AGENT.md](agents/contact-resolver/AGENT.md)) — one deterministic resolver that disambiguates namesakes, never guesses, and returns UNAVAILABLE (ask the user for the number) when the MCP server is absent. Skip it when a raw number was passed directly.
- **Bulk retrieval (messages, calls, transcripts, summaries):** prefer the shared `quo-fetch.sh` REST integration so there is one paginated/auth'd Quo retrieval path to maintain and the skill degrades gracefully when the interactively-authenticated MCP server is absent (headless/cron). The MCP `fetch-messages` / `fetch-call-transcripts` / `fetch-missed-calls` tools are the fallback when the script path is unavailable.
- **Shared script — do not move or copy.** The REST integration lives at `../agenda/scripts/quo-fetch.sh` (canonical: `.claude/skills/agenda/scripts/quo-fetch.sh`). `/agenda triage` already calls it by relative path and it self-locates `.env.local` from the repo root. `quo` references this single shared instance. See [reference.md](reference.md) § "Shared REST integration".

## Workflow: Lookup (default)

1. **Resolve contact** — Call `mcp__claude_ai_Quo__list-contacts` (and `get-contact` as needed) to turn `<name>` into one or more phone numbers. If MCP is unavailable, ask the user for the number directly rather than failing.
   - If multiple contacts match the name, list them and ask which one.
2. **Pull recent activity** — For each resolved number, fetch the recent window (default 90 days — see reference.md § "Default window"):
   - Calls: `quo-fetch.sh calls --since <ISO8601>`, then `quo-fetch.sh summary <call-id>` per call. Filter client-side to the resolved number(s).
   - Messages: `quo-fetch.sh messages --since <ISO8601>`, filtered to the resolved number(s).
3. **Extract action items** — Read summaries first; pull a full transcript (`quo-fetch.sh transcript <call-id>`) ONLY when a summary is too thin to answer the user's question. Surface concrete asks, commitments, dates, and named entities (sites, events, forms).
4. **Present** — Lead with the answer to the user's actual question, then a short combined timeline (calls + texts, newest first) with action items called out.

## Workflow: Review (all-inbox text review)

Read-only sweep of recent SMS across **every** inbox — the contact-agnostic counterpart to `lookup`. The SMS analogue of `/email triage`. It never writes anything.

1. **Sweep** — `bash ../agenda/scripts/quo-fetch.sh messages --since <ISO8601>` over all inboxes (sentinel `0`). Default window: **72 hours** (see reference.md § "Default window"). No contact resolution needed.
2. **Group** — Group messages by sender phone number into threads.
3. **Rank** — Highest priority first:
   1. **Awaiting reply** — an inbound message with no subsequent outbound reply in the thread.
   2. **Explicit ask** — contains a question mark or ask language ("can you", "let me know", "when").
   3. **Known contact** — digit-matches an entry in `../agenda/references/account-index.org` (ranks above unknown numbers).
   4. **Recency** — tiebreaker.
4. **Tag** each thread: `NEEDS REPLY` (inbound, unanswered), `ACTION` (contains an ask/commitment), or `FYI` (informational/automated).
5. **Present** — A 2-3 sentence lead calling out the top awaiting-reply items by name, then a compact ranked table: `Contact` (name from the index or raw number), `Last msg` (relative time), `Tag`, `Snippet` (~80 chars of the latest inbound).

This mode does NOT classify texts into org tasks or write anything. If a surfaced text should become a tracked task, that is `/agenda triage`'s job (see § Relationship to /agenda triage).

## Workflow: Messages

1. Resolve `<name>` → number via MCP (skip if a number was passed directly).
2. `quo-fetch.sh messages --since <ISO8601>`, filter to that number, present the thread newest-first.

## Workflow: Calls

1. Resolve `<name>` → number via MCP (skip if a number was passed directly).
2. `quo-fetch.sh calls --since <ISO8601>`, filter to that number. Include missed calls (MCP `fetch-missed-calls` if the script omits them).
3. Show each call's summary; expand to transcript on request or when the summary can't answer the question.

## Workflow: Send

1. Resolve `<name>` → number via MCP.
2. Load `/voice` + `/writing`, then draft the SMS body.
3. Apply the **Outbound SMS Confirmation Gate** above — render, STOP, wait for explicit confirmation.
4. On confirmation, send via `mcp__claude_ai_Quo__send-message`.

## Relationship to /agenda triage

`/agenda triage` already consumes Quo signals — but in the opposite direction: it batches **all inboxes** over a `--since` window through its classifier and write-guard, resolving numbers → project slugs via `account-index.org`. `quo` resolves the other direction (name → number) for a **single contact on demand**.

They are tied together by **sharing the one `quo-fetch.sh` REST integration**, not by duplicating signal logic:
- Triage keeps calling `quo-fetch.sh` directly. Do NOT route triage through `/quo` (that would force the interactive MCP path onto the cron path).
- `/route` sends contact-specific call/SMS lookups to `/quo`; batch/triage stays with `/agenda triage`.

**`quo review` vs `agenda triage` — read vs write.** Both sweep the same `quo-fetch.sh messages --since` SMS data, so the boundary must stay explicit: `/agenda triage` is the only **writer** — it resolves numbers → project slugs via `account-index.org`, classifies signals, and proposes/applies DEADLINEs, TODOs, and body-notes through the write-guard hook. `/quo review` is strictly **read-only human-facing surfacing** — it ranks recent texts for the user to eyeball and never touches org files, the routing index, or any hook. If a surfaced text should become a tracked task, that is triage's job, not review's.
<!-- /origin -->

---

<!-- origin: skill-builder | version: 1.0 | modifiable: true -->
## Grounding

Before pulling any Quo data, read [reference.md](reference.md) for the shared script path, subcommands, default time window, and contact-resolution rules. State: "I will resolve [CONTACT] via [MCP/given number] and fetch [calls/messages] over [window]."

See [reference.md](reference.md) for IDs, subcommands, and the shared REST integration contract.
<!-- /origin -->
