# Quo Skill Reference
<!-- Enforcement: LOW — shared-script contract and resolution rules; no hook attached -->

## Shared REST integration

The Quo REST integration is **owned by `/agenda`** and shared, not copied:

- Canonical path: `.claude/skills/agenda/scripts/quo-fetch.sh`
- From this skill: `../agenda/scripts/quo-fetch.sh`
- It reads `QUO_API_KEY` (and optional `QUO_INBOX_IDS`) from `.env.local` at the repo root. No MCP dependency. It self-locates `.env.local` (CWD → repo root → `~/lab/odyssey-alive`).
- Base API: `https://api.openphone.com/v1`
- Do **not** move or copy this file — `/agenda triage` invokes it by relative path. One shared instance, two consumers.

### Subcommands

| Command | Returns |
|---------|---------|
| `quo-fetch.sh inboxes` | Your own Quo phone numbers / inboxes (NOT external contacts) |
| `quo-fetch.sh messages --since <ISO8601> [--inbox <id>]` | SMS to/from configured inboxes in the window |
| `quo-fetch.sh calls --since <ISO8601> [--inbox <id>]` | Calls in the window |
| `quo-fetch.sh transcript <call-id>` | Full transcript for one call |
| `quo-fetch.sh summary <call-id>` | Auto-summary for one call |
| `quo-fetch.sh check` | Probe auth mode and cache the result |

Output is one JSON document per call (paginated results merged into a single array).

## Contact resolution (name → number)

`quo-fetch.sh` has **no contact-name search** — it keys only on inbox-ID + `--since`. To turn a name into a number, use the Quo MCP server:

- `mcp__claude_ai_Quo__list-contacts` — list/search contacts
- `mcp__claude_ai_Quo__get-contact` — fetch one contact's detail
- `mcp__claude_ai_Quo__fetch-missed-calls` — missed calls (no script analogue)
- `mcp__claude_ai_Quo__fetch-messages` / `fetch-call-transcripts` — MCP fallback when the script path is unavailable
- `mcp__claude_ai_Quo__send-message` — send SMS (confirmation-gated; see SKILL.md Directives)

**MCP availability:** the Quo MCP server is interactively authenticated and may be absent in headless/cron runs. When resolution is needed but MCP is unavailable, ask the user for the number directly — never hard-fail, and never make a cron-reachable path depend on MCP.

## Default window

- **Contact lookup (`lookup` / `messages` / `calls`): 90 days.** Because the script filters by time window (not by participant), pulling "recent activity for one contact" means fetching the window and filtering client-side by the resolved phone digits. Widen on request for an older call; narrow for speed.
- **All-inbox sweep (`review`): 72 hours.** A sweep wants a tight recency window so the awaiting-reply set stays actionable. Widen on request.

### `review` ranking (all-inbox)

Rank threads highest→lowest: (1) inbound with no later outbound reply (awaiting-reply); (2) explicit ask (`?`, "can you", "let me know", "when"); (3) known contact (digit-match in `account-index.org`) over unknown; (4) recency as tiebreaker. Tag each: `NEEDS REPLY`, `ACTION`, or `FYI`. Read-only — never writes to org (that is `/agenda triage`).

## Routing / triage relationship

- Account-routing index (number → project slug) lives at `.claude/skills/agenda/references/account-index.org` — used by triage, not required for contact lookups.
- Batch signal triage across all inboxes: `/agenda triage`.
- Single-contact, on-demand call/SMS lookup: this skill (`/quo`).
