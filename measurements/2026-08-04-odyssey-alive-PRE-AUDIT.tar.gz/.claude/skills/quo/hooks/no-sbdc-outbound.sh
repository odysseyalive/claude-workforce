#!/bin/bash
# Hook: Block any outbound Quo SMS that names the SBDC (literal token only)
# Skill: /quo
# Scope: PreToolUse on mcp__claude_ai_Quo__send-message ONLY (the matcher IS the
#   outbound scope — this never touches lookups, reviews, or internal discussion).
# Rationale: sacred directive — "Maintain SBDC / Odyssey Alive separation. Outbound
#   messages must never reference an SBDC role ... when speaking for Odyssey Alive."
#   The literal proper noun "SBDC" / "Small Business Development Center" has no
#   legitimate place in an OA-voiced text, so it is a hard block (exit 2). The broader
#   "AI-consulting framing" half is a semantic positioning call that collides with
#   on-brand "AI automation" copy — it stays at the SKILL.md model CHECKPOINT, NOT here
#   (2-agent enforcement-boundary panel, conservative split).
# Rule reference: shell-safety R3, R5, R7, R10
CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null; exit 0' ERR

INPUT=$(cat 2>/dev/null) || exit 0

# Pull every string value out of tool_input and join them, so the check is robust to
# the send-message body field name (text / body / content / message). Recipient is a
# phone number (no letters), so this only meaningfully inspects the message body.
BODY=$(INPUT="$INPUT" python3 - <<'PY' 2>/dev/null
import os, json, sys
def strings(v):
    if isinstance(v, str):
        yield v
    elif isinstance(v, dict):
        for x in v.values():
            yield from strings(x)
    elif isinstance(v, list):
        for x in v:
            yield from strings(x)
try:
    d = json.loads(os.environ.get("INPUT", "{}"))
except Exception:
    sys.exit(0)
ti = d.get("tool_input", d)
print(" ".join(strings(ti)))
PY
)

# Hard block on the literal SBDC proper noun (case-insensitive, word-boundary).
if echo "$BODY" | grep -qiE '\bSBDC\b|Small Business Development Center' 2>/dev/null; then
  echo "BLOCKED: outbound Quo SMS references 'SBDC' — Odyssey Alive outbound must not name an SBDC role (per /quo SBDC/OA separation directive). Remove the reference and resend." >&2
  exit 2
fi

exit 0
