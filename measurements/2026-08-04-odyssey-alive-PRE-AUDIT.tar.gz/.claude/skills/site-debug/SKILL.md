---
name: site-debug
description: Visual debugging of the Odyssey Alive site via the playwright-mcp browser tools. Captures screenshots, accessibility snapshots, console errors, and network failures from the dev server (or any localhost/production URL).
allowed-tools: Read, Glob, Grep, Bash, Task, mcp__playwright-mcp__browser_navigate, mcp__playwright-mcp__browser_snapshot, mcp__playwright-mcp__browser_take_screenshot, mcp__playwright-mcp__browser_console_messages, mcp__playwright-mcp__browser_network_requests, mcp__playwright-mcp__browser_resize, mcp__playwright-mcp__browser_wait_for, mcp__playwright-mcp__browser_evaluate, mcp__playwright-mcp__browser_close
minimum-effort-level: medium
strictness: standard
---

# Site Debug

Diagnose visual, console, and network problems on the site by driving a real headless browser. Used whenever a styling change, layout regression, hydration error, or asset 404 needs to be confirmed against the running app rather than guessed at from source.

**Trigger phrases:** "debug the site visually", "screenshot the site", "what does this page look like", "check for console errors on", "visual regression on", "is the site rendering"

---

<!-- origin: user | added: 2026-04-11 | immutable: true -->
## Directives

> **"Use Playwright, not the Chrome browser plugin, for visual debugging. Use Playwright instead of the Chrome browser plugin to visually view and debug sites, every time. At the end of every debug session, no temporary files, images, etc. should be left over after the debugging has been completed."**

*— Added 2026-04-11, source: project CLAUDE.md*
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Use Playwright, not the Chrome browser plugin, for visual debugging. Use Playwright instead of the Chrome browser plugin to visually view and debug sites, every time. At the end of every debug session, no temporary files, images, etc. should be left over after the debugging has been completed." -->
CHECKPOINT — Visual Debug Tooling Gate:
1. Before opening any browser-style tool to inspect a URL, list the candidate tools (Playwright via the `mcp__playwright-mcp__browser_*` tools, Chrome plugin via `mcp__claude-in-chrome__*`, manual `curl` HTML fetch).
2. IF the goal is purely textual (read HTML, check headers, fetch JSON) → `curl` or `mcp__playwright-mcp__web_fetch` is acceptable; CONTINUE.
3. IF the goal involves rendered output (screenshot, accessibility snapshot, layout, computed styles, hydration, runtime console/network capture) → the `mcp__playwright-mcp__browser_*` tools are the ONLY allowed path. STOP if you reach for `mcp__claude-in-chrome__*` OR for raw `node -e`/`npx playwright` shelled through Bash; drive the playwright-mcp tools directly per `references/playwright-snippets.md`. ("Playwright, not the Chrome browser plugin" per the directive — the playwright-mcp server IS Playwright.)
4. The playwright-mcp server owns the browser session, so there is no `/tmp` script churn. Track only files the session deliberately saves: screenshots written via `mcp__playwright-mcp__browser_take_screenshot` (default save location or a path you pass) and any export you write by hand. Console and network captures are returned as tool output — they create no files.
5. At session end, delete every saved screenshot/export with `rm` and confirm the path no longer exists. Report cleanup explicitly: "Cleanup: removed N saved artifacts." IF the run saved no files → state "Cleanup: no artifacts written." IF any tracked file remains → STOP and remove it before claiming the session is complete.
<!-- END ENFORCEMENT ANNOTATION -->

---

## Workflow

1. **Identify the URL.** Default to `http://localhost:3030` (the project's `pnpm dev` port per CLAUDE.md). For production checks, use `https://www.odysseyalive.com`. For specific routes, append the path.

2. **Confirm the dev server is up** if hitting localhost: `curl -sI http://localhost:3030 | head -1`. If it returns nothing, prompt the user to start `pnpm dev` (do not start it autonomously — it's a long-lived background process).

3. **Navigate, then capture with the playwright-mcp tools.** Open the URL with `mcp__playwright-mcp__browser_navigate`, then pick the capture(s) the symptom calls for. See [references/playwright-snippets.md](references/playwright-snippets.md) for the tool-call recipe behind each one:
   - **Accessibility snapshot first** — `mcp__playwright-mcp__browser_snapshot` (the structured a11y tree; preferred over a screenshot for "what's on the page / why is an element missing").
   - **Screenshot** — `mcp__playwright-mcp__browser_take_screenshot` (full page or viewport).
   - **Console + page errors** — `mcp__playwright-mcp__browser_console_messages` (use its `pattern` to filter, e.g. hydration warnings).
   - **Network failures / asset 404s** — `mcp__playwright-mcp__browser_network_requests`, filtered to `status >= 400`.
   - **Responsive sweep** — loop `mcp__playwright-mcp__browser_resize` + `browser_take_screenshot` across mobile/tablet/desktop.

4. **No Bash browser scripts.** Drive the playwright-mcp tools directly — never shell out to `node -e`/`npx playwright`. The server holds one browser session across the calls above; close it with `mcp__playwright-mcp__browser_close` when done.

5. **Spawn the site-investigator agent** for triage when the run produces non-trivial output (multiple errors, ambiguous screenshots, regression suspected). See [agents/site-investigator/AGENT.md](agents/site-investigator/AGENT.md). Pass: the URL, the console/network captures as text (paste the relevant tool output), the path(s) to any saved screenshot, and the user's symptom description.

6. **Cleanup (mandatory).** Console/network captures are tool output and leave nothing behind. Delete any screenshot the session saved:
   ```bash
   rm -f <saved-screenshot-path>
   ```
   Confirm the path no longer exists. Report the cleanup explicitly — or state that no files were written — in your response.

---

## What this skill is NOT for

- Reading static HTML or sitemaps — use `curl` or `mcp__playwright-mcp__web_fetch`.
- Long-running browser sessions — the playwright-mcp session is scoped to one debug invocation; close it with `browser_close` when done.
- Replacing `/deploy verify` — that skill checks deployment health, not visual rendering.
- Browser automation against authenticated third-party sites — see the paywall reader at `scripts/read-paywalled.js` instead.

---

## Related

- `/browser` — troubleshoots the Chrome extension if its tools were ever needed (this skill exists precisely so that path is rarely taken).
- `/deploy verify` — post-deploy health check (status codes, key routes).

---

<!-- ROUTE-EMBED START — auto-generated by /skill-builder route embed; safe to replace -->
<!-- origin: skill-builder | modifiable: true -->
## Route Consultation

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: /skill-builder route embed. Closes the dispatch-bypass gap: a /route announcement is not a substitute for a Skill tool call, and consulting /route does not license the caller to execute the target skill's procedure manually. -->
CHECKPOINT — Skill Routing Gate:
1. During this skill's workflow, IF a step requires research, web search, lookup, analysis, or any follow-up NOT already covered by an explicit tool or skill name → STOP before improvising.
2. Already-named exception. IF the current workflow step EXPLICITLY names tools or skills (e.g., "use Read", "spawn the X agent", "invoke /[skill]") → execute as written. Do NOT consult `/route` for steps already determined. Skip to your skill's next step.
3. Otherwise → invoke `/route <task description>` via the Skill tool. `/route` reads its index and either returns a target skill or reports "no match."
4. Dispatch Required. IF `/route` returns a target → the IMMEDIATE next tool call MUST be `Skill(skill=<target>, args=<derived>)`. Do NOT execute the target skill's procedure steps yourself with raw Edit / Write / Bash / Task / Agent / Read calls. The target skill's gates (asset backups, agent panels, exit tests, cascade steps, frontend-design reviews, immutable-directive checks) ONLY fire when its SKILL.md is loaded via Skill — running steps manually silently skips every gate.
5. Bypass detection. IF a Skill dispatch was just announced (yours or `/route`'s) and the next tool call is non-Skill work germane to the routed task → STOP. Print verbatim: "Route dispatch announced but Skill call skipped. Invoking Skill tool now." then issue the Skill call.
6. No-match path. IF `/route` returns "no match" → proceed with the most direct, manual approach. Document the gap; the user may want to register a skill.
7. Follow-ups loop back. After the dispatched skill returns, IF further follow-up is needed → consult `/route` again via Skill. Do not freelance the next step.
8. Auto-mode override clause. Auto-mode ("execute immediately", "prefer action over planning") does NOT override clauses 4–5. Auto-mode chooses WHAT to do; once a routing decision is on the table, the only valid next action is Skill invocation.
<!-- END ENFORCEMENT ANNOTATION -->
<!-- /origin -->
<!-- ROUTE-EMBED END -->
