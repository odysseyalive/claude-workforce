# Playwright-MCP Recipes

Ready-to-run capture recipes for common site-debug tasks, expressed as **playwright-mcp tool calls** (`mcp__playwright-mcp__browser_*`). The server holds one browser session across calls, so navigate once and run as many captures as the symptom needs, then close.

**Pattern:** `browser_navigate` → one or more captures → `browser_close`. Console and network captures return as tool output (no files). Screenshots are the only thing that lands on disk — clean them up at session end.

---

## 0. Open the page

```
mcp__playwright-mcp__browser_navigate { "url": "<URL>" }
```

Use the project default `http://localhost:3030`, or a route like `http://localhost:3030/focus/<slug>`, or `https://www.odysseyalive.com` for production. Optionally follow with `browser_wait_for` (e.g. wait for text or a timeout) when the page hydrates slowly.

---

## 1. Accessibility snapshot (preferred first look)

```
mcp__playwright-mcp__browser_snapshot {}
```

Returns the structured accessibility tree — the best first look for "what's actually on the page," missing elements, or wrong roles/labels. Prefer this over a screenshot when the question is structural rather than visual.

---

## 2. Screenshot a single page

```
mcp__playwright-mcp__browser_take_screenshot { "fullPage": true }
```

Full scrolling page. Omit `fullPage` (or set it false) for the initial viewport only. Pass a `filename`/path argument if you want a specific save location; otherwise note where the tool reports it saved the image so you can clean it up.

---

## 3. Capture console + page errors

```
mcp__playwright-mcp__browser_console_messages {}
```

Returns all console messages and page errors as text. To narrow to a category, pass a regex `pattern` (the tool filters server-side), e.g. `"error|warn"`.

---

## 4. Network failures / asset 404 audit

```
mcp__playwright-mcp__browser_network_requests {}
```

Returns every request/response. Scan the output for `status >= 400` (broken assets, failed API calls) and for the resource types that matter for rendering — `image`, `stylesheet`, `script`, `font`. This replaces the old "asset 404 audit" node script: the full inventory is in the tool output, no JSON file to write.

---

## 5. Multi-viewport sweep (responsive check)

Loop resize + screenshot across the three breakpoints the site targets:

```
mcp__playwright-mcp__browser_resize { "width": 390,  "height": 844 }   # mobile
mcp__playwright-mcp__browser_take_screenshot { "fullPage": true }

mcp__playwright-mcp__browser_resize { "width": 768,  "height": 1024 }  # tablet
mcp__playwright-mcp__browser_take_screenshot { "fullPage": true }

mcp__playwright-mcp__browser_resize { "width": 1440, "height": 900 }   # desktop
mcp__playwright-mcp__browser_take_screenshot { "fullPage": true }
```

Re-navigate or `browser_wait_for` between resizes if the layout depends on load-time viewport. Track each saved screenshot path for cleanup.

---

## 6. Hydration mismatch detection

Capture console filtered to hydration-relevant entries:

```
mcp__playwright-mcp__browser_console_messages { "pattern": "hydrat|did not match|server.*client" }
```

If the page needs a beat to surface the warning, `browser_wait_for` (a short timeout or expected text) before the capture. For a deeper check, `browser_evaluate` can read computed DOM state to compare against the server HTML.

---

## Cleanup (mandatory at session end)

```bash
rm -f <each-saved-screenshot-path>
```

Then `browser_close` to end the session:

```
mcp__playwright-mcp__browser_close {}
```

Console/network captures wrote no files. If the run saved no screenshots, state "Cleanup: no artifacts written." If cleanup of a saved file fails, the directive requires resolving it before claiming the session is complete.
