---
name: pdf
description: "Convert markdown files to PDF via chromium headless rendering. Usage: /pdf <file.md> [--output path] [--layout single|two-column]"
allowed-tools: [Read, Bash, Write, Glob]
---

# PDF

Convert markdown files to professional PDF documents using chromium headless rendering of hand-crafted HTML. Accepts any `.md` file and produces a clean, print-ready PDF.

## Usage

```
/pdf <file.md> [--output path] [--layout single|two-column]
```

- `<file.md>` — path to the markdown file to convert
- `--output` — optional output path (default: same directory, same name with `.pdf` extension)
- `--layout single` — single-column layout (default, best for documents, estimates, quotes)
- `--layout two-column` — two-column flexbox layout (best for dense reference material)

---

## Directives

*(none yet)*

---

<!-- origin: skill-builder | version: 1.0 | modifiable: true -->
## Workflow

1. **Resolve inputs.** Accept the markdown file path. Verify the file exists. Determine the output path: use `--output` if given, otherwise replace the `.md` extension with `.pdf` in the same directory. Determine layout: `--layout` flag or default to `single`.
2. **Check chromium.** Run `which chromium`. If not found, report: "PDF generation skipped — chromium not found. Install chromium to use this skill." and STOP.
3. **Read the markdown file.** Parse the full content. Extract the title from the first `# ` heading (or the filename if no heading). Identify sections by `## ` headings.
4. **Build HTML.** Using the template from [reference.md](reference.md), construct an HTML document:
   - Map `## Heading` sections to `<div class="section"><h2>...</h2>...</div>` blocks
   - Convert markdown tables to `<table>` with `<th>` headers and `<td>` cells
   - Convert bullet lists to `<ul><li>` elements
   - Convert bold text to `<b>` tags
   - Convert inline code to `<code>` tags
   - For `single` layout: place all sections in a single column
   - For `two-column` layout: distribute sections roughly evenly between left and right columns; place the largest tables in the left column
5. **Write temp HTML.** Write the HTML to a temporary file alongside the output path (e.g., `/tmp/pdf-[timestamp].html`).
6. **Render to PDF.** Run:
   ```bash
   chromium --headless --disable-gpu --no-sandbox \
     --print-to-pdf="[output].pdf" \
     --print-to-pdf-no-header \
     "file://[absolute-path-to-html]"
   ```
7. **Verify and clean up.** Run `pdfinfo [output].pdf | grep Pages` to confirm generation. Delete the temp HTML file. Report the output path and page count to the user.
8. **Overflow handling.** If page count exceeds expectations, suggest reducing content density or switching to `two-column` layout. Do not automatically reformat without user input.
<!-- /origin -->

---

<!-- origin: skill-builder | version: 1.0 | modifiable: true -->
## Grounding

Before generating HTML:
1. Read [reference.md](reference.md) for the HTML template and sizing guidelines
2. State: "I will convert [FILE] to PDF using the [single/two-column] layout"

See [reference.md](reference.md) for the HTML template, markdown-to-HTML mapping rules, and font sizing guidelines.
<!-- /origin -->
