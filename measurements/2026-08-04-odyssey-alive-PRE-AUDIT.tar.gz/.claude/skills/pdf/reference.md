# PDF Reference

## HTML Template — Single Column

```html
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>[TITLE]</title>
<style>
@page { size: letter; margin: 0.6in 0.75in; }
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
  font-family: "DejaVu Sans", "Liberation Sans", Arial, sans-serif;
  font-size: 10pt;
  line-height: 1.4;
  color: #1a1a1a;
}
h1 {
  font-size: 16pt;
  font-weight: 700;
  margin: 0 0 6pt 0;
  padding-bottom: 4pt;
  border-bottom: 2pt solid #333;
}
h2 {
  font-size: 12pt;
  font-weight: 700;
  margin: 14pt 0 4pt 0;
  padding-bottom: 2pt;
  border-bottom: 0.75pt solid #999;
}
h3 {
  font-size: 10.5pt;
  font-weight: 700;
  margin: 10pt 0 3pt 0;
}
p { margin: 4pt 0; }
b { font-weight: 700; }
code {
  font-family: "DejaVu Sans Mono", "Liberation Mono", monospace;
  font-size: 9pt;
  background: #f0f0f0;
  padding: 1pt 3pt;
  border-radius: 2pt;
}
ul, ol { padding-left: 16pt; margin: 4pt 0; }
li { margin: 2pt 0; }
table {
  width: 100%;
  border-collapse: collapse;
  font-size: 9pt;
  margin: 6pt 0;
}
th {
  background: #e0e0e0;
  font-weight: 700;
  text-align: left;
  padding: 4pt 6pt;
  border: 0.75pt solid #999;
}
td {
  padding: 3pt 6pt;
  border: 0.75pt solid #bbb;
  vertical-align: top;
}
tr:nth-child(even) { background: #f7f7f7; }
.section { margin-bottom: 4pt; }
.page-break { page-break-before: always; }
.meta {
  font-size: 9pt;
  color: #666;
  margin-bottom: 10pt;
}
hr {
  border: none;
  border-top: 0.5pt solid #ccc;
  margin: 10pt 0;
}
</style>
</head>
<body>

<h1>[TITLE]</h1>
<div class="meta">[DATE or other metadata]</div>

<!-- Sections inserted here -->

</body>
</html>
```

## HTML Template — Two Column

```html
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>[TITLE]</title>
<style>
@page { size: letter; margin: 0.35in; }
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
  font-family: "DejaVu Sans", "Liberation Sans", Arial, sans-serif;
  font-size: 7pt;
  line-height: 1.2;
  color: #1a1a1a;
}
.page {
  width: 100%;
  page-break-after: always;
}
.page:last-child { page-break-after: avoid; }
.page-title {
  font-size: 9pt;
  font-weight: 700;
  text-align: center;
  border-bottom: 1.5pt solid #000;
  padding-bottom: 2pt;
  margin-bottom: 4pt;
}
.cols { display: flex; gap: 10pt; }
.col { flex: 1; min-width: 0; }
.section { margin-bottom: 4pt; }
.section h2 {
  font-size: 7.5pt;
  font-weight: 700;
  margin: 0 0 1.5pt 0;
  border-bottom: 0.5pt solid #888;
  padding-bottom: 1pt;
}
h3 { font-size: 7pt; margin: 3pt 0 1pt 0; }
p { margin: 1pt 0; }
b { font-weight: 700; }
code {
  font-family: "DejaVu Sans Mono", "Liberation Mono", monospace;
  font-size: 6pt;
  background: #f0f0f0;
  padding: 0.5pt 2pt;
}
ul, ol { padding-left: 10pt; margin: 1pt 0; }
li { margin: 0.5pt 0; }
table {
  width: 100%;
  border-collapse: collapse;
  font-size: 6pt;
  margin: 2pt 0;
}
th {
  background: #d8d8d8;
  font-weight: 700;
  text-align: left;
  padding: 1.5pt 3pt;
  border: 0.5pt solid #999;
  white-space: nowrap;
}
td {
  padding: 1.5pt 3pt;
  border: 0.5pt solid #bbb;
  vertical-align: top;
}
tr:nth-child(even) { background: #f2f2f2; }
</style>
</head>
<body>

<div class="page">
  <div class="page-title">[TITLE]</div>
  <div class="cols">
    <div class="col">
      <!-- Left column sections -->
    </div>
    <div class="col">
      <!-- Right column sections -->
    </div>
  </div>
</div>

</body>
</html>
```

## Markdown-to-HTML Mapping

| Markdown element | HTML output |
|-----------------|-------------|
| `# Title` | `<h1>Title</h1>` |
| `## Section` | `<div class="section"><h2>Section</h2>...</div>` |
| `### Subsection` | `<h3>Subsection</h3>` |
| `**bold**` | `<b>bold</b>` |
| `` `code` `` | `<code>code</code>` |
| `- item` | `<ul><li>item</li></ul>` |
| `1. item` | `<ol><li>item</li></ol>` |
| `---` | `<hr>` |
| Table rows | `<table>` with `<th>` / `<td>` |
| `→` | `&rarr;` |
| `≠` | `&ne;` |

## Sizing Guidelines

### Single Column (default)

| Content volume | Body font | Table font | Expected pages |
|---------------|-----------|------------|----------------|
| Short doc (1-3 sections) | 10pt | 9pt | 1 page |
| Medium doc (4-8 sections) | 10pt | 9pt | 2-4 pages |
| Long doc (8+ sections) | 10pt | 9pt | 4+ pages |

### Two Column

| Content volume | Body font | Table font | Expected pages |
|---------------|-----------|------------|----------------|
| Light (3-5 sections) | 7pt | 6pt | 1 page |
| Medium (6-10 sections) | 7pt | 6pt | 1-2 pages |
| Dense (10+ sections) | 6.5pt | 5.5pt | 2-3 pages |

### Overflow Adjustments

If content exceeds target page count:
1. First: abbreviate table cells (short phrases, not sentences)
2. Second: reduce body font by 1pt, table font by 0.5pt
3. Third: reduce margins (single: to 0.5in; two-column: to 0.25in)
4. Never go below 8pt body / 7pt tables (single) or 5.5pt body / 5pt tables (two-column)

## Chromium Command

```bash
chromium --headless --disable-gpu --no-sandbox \
  --print-to-pdf="[output].pdf" \
  --print-to-pdf-no-header \
  "file://[absolute-path-to-html]"
```

## Verify Command

```bash
pdfinfo [output].pdf | grep Pages
```
