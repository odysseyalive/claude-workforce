---
name: writing
description: Load content and communication protocol. Use for emails, messages, correspondence, drafting copy, any written content.
allowed-tools: Read, Glob, Grep
minimum-effort-level: xhigh
strictness: standard
---

# Content & Communication Protocol

**Write with intention, wit, and humanity.** Text is interface. Every word shapes experience.

<!-- origin: user | added: 2026-01-29 | immutable: true -->
## Directives

> **Let new ideas land before moving on.**
> When a new concept or frame enters the piece, let the reader sit inside it for a beat before pivoting to analysis, callback, or the next idea. The tendency is to introduce a concept and immediately connect it to something else. That rewards the fast reader but loses the one who's still arriving. One more sentence inside the experience — what it feels like, what it looks like in practice, why it's strange — makes the difference between an idea the reader follows and one they inhabit. Accessibility isn't about simpler words. It's about pacing that lets the reader keep up without rushing.

*— 2026-01-29, source: podcast vs. article pacing comparison*

> **Give the reader something portable.**
> Every piece should leave the reader with one idea they could repeat to someone else without referencing the article. Not a slogan. A practical point that holds up in conversation. If the writing covers a lot of ground, make sure one thread stands above the rest as the thing worth remembering. Beautiful wordplay that doesn't leave the reader with something useful is craft for its own sake. The test is simple: if someone read this and a colleague asked what it was about, could they answer in one sentence?

*— 2026-01-29, source: practicality vs. craft reflection*

> **Never compact voice to fit length.**
> When text exceeds a word limit, never shorten sentences, remove texture, or tighten phrasing to fit. Voice has rhythm and breathing room that must be preserved. Instead, identify the least consequential conceptual section and remove it entirely. Update transitions so the reader never senses something was removed. If two passages make the same point, cut the second one. Reduce scope, not voice.

*— Added pre-2026-01-29, source: user instruction*

> **Never cite what you can't read.**
> If a reference has a URL, that URL must be accessible and the full article text must be read before it can be cited. Search result summaries, snippets from Jina or other search tools, and metadata descriptions are not substitutes for reading the source. If the URL returns a 404, a paywall blocks most of the text, or the content is otherwise inaccessible, stop immediately. Ask the user if they can supply the full text from the proposed URL. If the user cannot provide it, the source must not be cited, referenced, paraphrased, or used in any way. No guessing what an article says based on a search summary. No inferring arguments from titles or abstracts. Either you've read the full text or the source doesn't exist.

*— 2026-01-29, source: user directive on reference integrity*

> **Never fabricate Francis's actions or experiences.**
> If Francis hasn't given an indication that he did something, said something, or had a specific interaction, don't put words in his mouth. Instead, propose the angle and ask for approval: "It would be great if we hit this article from this angle. Would it be appropriate to ask your clients this question so that we can print it? Or should I approach this from another angle?" This doesn't curb creativity. The ideas, angles, and framings are welcome. But when a draft needs a personal anecdote or claimed experience, ask before writing it in.

*— 2026-02-13, source: "The SaaSpocalypse" fabricated a client interaction that didn't happen*

> **When referring to math, use accepted statistical notation.**
> Percentages and mathematical values use their standard form (20%, not "20 percent") when presenting data as math. Spelled-out "percent" is only for conversational prose where the number is rhetorical, not statistical. If a sentence presents a survey result, research finding, or data point, use the symbol.

*— Added 2026-03-23, source: user directive on statistical notation*

Additional directives enforced via hooks and text-eval agents: [references/directives.md](references/directives.md)
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Let new ideas land before moving on. When a new concept or frame enters the piece, let the reader sit inside it for a beat before pivoting to analysis, callback, or the next idea. The tendency is to introduce a concept and immediately connect it to something else. That rewards the fast reader but loses the one who's still arriving. One more sentence inside the experience — what it feels like, what it looks like in practice, why it's strange — makes the difference between an idea the reader follows and one they inhabit." -->
CHECKPOINT — Idea-Landing Gate:
1. After a draft is complete, identify every sentence that introduces a new concept, frame, metaphor, or shift in subject (call each one a "pivot point").
2. For EACH pivot point, examine the sentence(s) immediately following it (within the same paragraph).
3. IF the very next sentence after a pivot performs analysis, callback, generalization, or transition to another idea (e.g., "This means…", "Which is why…", "And that connects to…") → STOP. Insert at least one grounding sentence between the pivot and the analysis. The grounding sentence must do one of: name a concrete example, describe what the concept looks like in practice, name what the experience feels like, or name why it is strange.
4. IF the pivot is followed by only abstract elaboration (restating the concept in different words) rather than a landing sentence → STOP. Replace with a concrete landing.
5. Apply the inhabitability test: after reading the pivot + the following sentence, could the reader describe the concept using a specific image, feeling, or example? IF NO → STOP and revise.
6. IF every pivot point is followed by at least one grounded landing sentence before any analysis → CONTINUE to the next directive gate.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Give the reader something portable. Every piece should leave the reader with one idea they could repeat to someone else without referencing the article. Not a slogan. A practical point that holds up in conversation. If the writing covers a lot of ground, make sure one thread stands above the rest as the thing worth remembering. Beautiful wordplay that doesn't leave the reader with something useful is craft for its own sake. The test is simple: if someone read this and a colleague asked what it was about, could they answer in one sentence?" -->
CHECKPOINT — Portable Idea Gate:
1. After a draft is complete, write the "portable answer" — one sentence that a reader could repeat to a colleague, in plain conversational language (no jargon, no metaphor-dependent phrasing), without citing the article.
2. Scan the draft. IF the portable answer does NOT appear explicitly somewhere in the body (not just the title, not only implied) → STOP. Revise the draft to state the portable idea plainly in at least one sentence.
3. IF the portable answer is a slogan or a rephrased title rather than a practical point → STOP. Rewrite to a conversational, practical statement.
4. IF the draft has multiple equally weighted threads with no single portable takeaway that stands above the rest → STOP. Reorganize so one thread dominates; demote or cut the others.
5. Read the draft as if a colleague asked "what's this about?" IF no single-sentence answer emerges from the body → STOP and revise.
6. IF the draft passes the portable answer scan, has one dominant thread, and produces a clean single-sentence answer → CONTINUE.
<!-- END ENFORCEMENT ANNOTATION -->

---


<!-- MODEL-LANE-GATE START — auto-generated by /skill-builder route embed; safe to replace -->
<!-- origin: skill-builder | modifiable: true -->
## Model-Lane Preflight

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: /skill-builder route embed (model-lane gate, slim form per the 2026-06-06 2-Brain Harness directive: gates are slimmed, never stripped — this block is the lane checkpoint that travels with the skill through EVERY entry path, including hand-run invocations, which are always permitted. It goes silent when /route already covered the endeavor. Advisory-only per the 2026-06-06 No-Switch-Prompt directive: the gate CANNOT switch the model and NEVER asks the user to — its entire output is one advisory line, which names the exact remedy informationally per the 2026-06-11 named-command advisory directive. -->
CHECKPOINT — Model-Lane Preflight Gate (slim, advisory-only; fires at the TOP of this skill's workflow, before any generative step):
1. SKIP silently IF ANY of: `/route` dispatched this invocation after running its own lane preflight (a lane advisory OR ask already printed, route otherwise ASSESSED the lane this turn, or it was deliberately suppressed — route's coverage extends to the whole endeavor whether route asked, matched, or the user declined, including skills this one chains); this skill's frontmatter sets `model-lane-gate: off`; the session is headless / non-interactive; this gate is executing inside a subagent (a subagent is already model-pinned via its own frontmatter); OR an advisory for this LANE already printed this endeavor AND the active model is unchanged (advise at most once per (lane, active-model) pair per endeavor).
2. Resolve this skill's lane (own `lane:` frontmatter → the Skill→Lane table in `.claude/skills/skill-builder/references/model-lanes.md` → NO LANE) and the lane's Preferred Model. IF no lane resolves OR the preferred-model cell is empty → silent no-op (correctly absent, not a gap). IF this skill declares per-function lanes AND the invocation's resolved mode has its own row → that function's lane governs; otherwise the skill-level lane covers all modes.
3. Read ACTIVE_MODEL from the session system-context line "The exact model ID is …" (strip `[1m]`/`[200k]`, lowercase — model-lanes.md § Active-Model Detection; never an env var or Bash probe). IF the Preferred Model is malformed or names a clearly superseded family → emit the one-line stale-mapping advisory and proceed; never advise from a stale mapping, never validate against a hardcoded list.
4. Compare. Match → silent no-op. Mismatch → print ONE advisory line and PROCEED: "Lane advisory: this skill declares the `<lane>` lane (preferred `<preferred>`); the active model is `<active>` — to align, run `/model <preferred>` and re-invoke; proceeding as-is." Naming the command is INFORMATIONAL (named-command advisory directive, 2026-06-11): NEVER an AskUserQuestion, never a blocking wait (No-Switch-Prompt directive, 2026-06-06). A skill can NEVER switch the session model and never asks the user to.
5. Primary-lane scope. This gate fires ONCE per invocation, for the resolved PRIMARY lane. Cross-lane mid-workflow steps never re-advise — they delegate via this skill's LANE-AGENT-EMBED Delegation Map when present (see .claude/skills/skill-builder/references/lane-delegation.md). Delegation is never a substitute for THIS gate: analytical primary work runs on the analytical main model — never a creative main session orchestrating analytical-pinned agents to dodge the lane.
<!-- END ENFORCEMENT ANNOTATION -->
<!-- /origin -->
<!-- MODEL-LANE-GATE END -->


## Grounding

**Before writing any content, read [reference.md](reference.md)** for voice guidelines (9 sections) and client language rules.

## Validation (Enforced via Agents)

After generating any draft content, spawn the voice-validator agent (`agents/voice-validator/AGENT.md`). If violations found, fix before presenting to user.

For protocol-level evaluation (engagement, metaphor, rhythm, client language), spawn the writing-evaluator agent (`agents/writing-evaluator/AGENT.md`). Use when content needs deeper quality assessment beyond voice alignment.

---

## Project Memory

Writing decisions are recorded in the awareness ledger. Before modifying writing rules, check `.claude/skills/awareness-ledger/ledger/index.md` for relevant records (especially DEC-edit-skill-creation, DEC-voice-protection-gate, FLW-content-pipeline-evolution). Changes flow to downstream skills.

