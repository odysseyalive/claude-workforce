#!/bin/bash
# Hook: Block em-dashes and en-dashes per /writing and /promote directives
# Scope: Project content files only (skips .claude/ infrastructure)
CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR

INPUT=$(cat 2>/dev/null) || exit 0

# Scope check: skip .claude/ infrastructure files
FILE_PATH=$(echo "$INPUT" | grep -oP '"file_path"\s*:\s*"[^"]*"' 2>/dev/null | head -1 | sed 's/.*"file_path"\s*:\s*"//;s/"$//')
if echo "$FILE_PATH" | grep -q '\.claude/' 2>/dev/null; then
  exit 0
fi

# Only check content files (mdx, md, txt, html)
if ! echo "$FILE_PATH" | grep -qE '\.(mdx?|txt|html)$' 2>/dev/null; then
  exit 0
fi

# Check for em-dash (—) or en-dash (–) in new content
CONTENT=$(echo "$INPUT" | grep -oP '"(?:new_string|content)"\s*:\s*"[^"]*"' 2>/dev/null | head -1)
if echo "$CONTENT" | grep -qP '[—–]' 2>/dev/null; then
  echo "BLOCKED: Em-dashes (—) and en-dashes (–) are forbidden per /writing directive. Use periods or commas instead." >&2
  exit 2
fi
exit 0
