#!/bin/bash
# Hook: Flag rhetorical colons per /writing directive
# Scope: Project content files only (skips .claude/ infrastructure)
# Note: Cannot distinguish all rhetorical vs mechanical colons mechanically.
#       Flags lines with colons that aren't clearly mechanical (URLs, timestamps,
#       list intros, frontmatter). False positives possible — warns, doesn't block.
CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR

INPUT=$(cat 2>/dev/null) || exit 0

# Scope check: skip .claude/ infrastructure files
FILE_PATH=$(echo "$INPUT" | grep -oP '"file_path"\s*:\s*"[^"]*"' 2>/dev/null | head -1 | sed 's/.*"file_path"\s*:\s*"//;s/"$//')
if echo "$FILE_PATH" | grep -q '\.claude/' 2>/dev/null; then
  exit 0
fi

# Only check content files (mdx, md, txt, html)
if ! echo "$FILE_PATH" | grep -qE '\.(mdx?|txt|html)$' 2>/dev/null; then
  exit 0
fi

# Extract new content
CONTENT=$(echo "$INPUT" | grep -oP '"(?:new_string|content)"\s*:\s*"[^"]*"' 2>/dev/null | head -1 | sed 's/^"[^"]*"\s*:\s*"//;s/"$//')

# Skip if no content or no colons
if [ -z "$CONTENT" ] || ! echo "$CONTENT" | grep -q ':' 2>/dev/null; then
  exit 0
fi

# Skip frontmatter-only content (starts with ---)
if echo "$CONTENT" | grep -qP '^---' 2>/dev/null; then
  exit 0
fi

# Remove clearly mechanical colons before checking:
# - URLs (http:// https://)
# - Timestamps (HH:MM)
# - Frontmatter keys (key: value at line start)
# - Image/link syntax (](http)
# - Code blocks
CLEANED=$(echo "$CONTENT" | \
  sed 's|https\?://[^ ]*||g' | \
  sed 's|[0-9]\{1,2\}:[0-9]\{2\}||g' | \
  sed 's|^[a-zA-Z_-]*:.*||g' | \
  sed 's|```[^`]*```||g')

# Check if remaining text has colons that look rhetorical
# Pattern: word(s) then colon then word(s) — not at start of line (which would be a key: value)
if echo "$CLEANED" | grep -qP '(?<!^)\w\s*:\s+[A-Za-z]' 2>/dev/null; then
  echo "WARNING: Possible rhetorical colon(s) detected. Per /writing directive, colons for emphasis are an AI tell. Use periods, question marks, or restructure instead. Mechanical colons (lists, URLs, timestamps) are fine." >&2
  # Exit 0 — warn only, don't block. Colon distinction requires judgment.
  exit 0
fi
exit 0
