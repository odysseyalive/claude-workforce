#!/bin/bash
# Hook: Flag known AI vocabulary, filler phrases, structural narration, and ghost citations
# Scope: Project content files only (skips .claude/ infrastructure)
# Advisory — warns but does not block (exit 0). Individual hits are tells only in clusters,
# and some words have legitimate uses. The text-eval agents handle severity.
CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR

INPUT=$(cat 2>/dev/null) || exit 0

FILE_PATH=$(echo "$INPUT" | grep -oP '"file_path"\s*:\s*"[^"]*"' 2>/dev/null | head -1 | sed 's/.*"file_path"\s*:\s*"//;s/"$//')
if echo "$FILE_PATH" | grep -q '\.claude/' 2>/dev/null; then
  exit 0
fi
if ! echo "$FILE_PATH" | grep -qE '\.(mdx?|txt|html)$' 2>/dev/null; then
  exit 0
fi

CONTENT=$(echo "$INPUT" | grep -oP '"(?:new_string|content)"\s*:\s*"[^"]*"' 2>/dev/null | head -1 | sed 's/^"[^"]*"\s*:\s*"//;s/"$//')
if [ -z "$CONTENT" ]; then
  exit 0
fi

# Skip frontmatter-only content
if echo "$CONTENT" | grep -qP '^---' 2>/dev/null && ! echo "$CONTENT" | grep -cP '^---' 2>/dev/null | grep -q '[2-9]'; then
  exit 0
fi

HITS=""

# --- AI vocabulary (case-insensitive word boundaries) ---
AI_WORDS="delve|showcase|tapestry|beacon|multifaceted|pivotal|realm|meticulous|intricate|commendable|paramount|commence|noteworthy|underscores|utilize|facilitate|leverage|harness|spearhead|foster|landscape|ecosystem|robust|seamless|cutting-edge|game-changing|groundbreaking"
VOCAB_HITS=$(echo "$CONTENT" | grep -oiP "\b($AI_WORDS)\b" 2>/dev/null | sort -uf)
if [ -n "$VOCAB_HITS" ]; then
  HITS="${HITS}  AI vocabulary: $(echo "$VOCAB_HITS" | tr '\n' ', ' | sed 's/, $//')\n"
fi

# --- Filler phrases (case-insensitive) ---
FILLER_HITS=$(echo "$CONTENT" | grep -oiP "(it'?s worth noting that|it should be mentioned|one might argue|in today'?s digital age|in today'?s world|at the end of the day|it goes without saying)" 2>/dev/null | sort -uf)
if [ -n "$FILLER_HITS" ]; then
  HITS="${HITS}  Filler phrases: $(echo "$FILLER_HITS" | tr '\n' ', ' | sed 's/, $//')\n"
fi

# --- Structural narration ---
STRUCT_HITS=$(echo "$CONTENT" | grep -oiP "(in this article|as we'?ve seen|in conclusion|let'?s dive into|let'?s explore|we will explore|we'?ll explore|without further ado)" 2>/dev/null | sort -uf)
if [ -n "$STRUCT_HITS" ]; then
  HITS="${HITS}  Structural narration: $(echo "$STRUCT_HITS" | tr '\n' ', ' | sed 's/, $//')\n"
fi

# --- Ghost citations ---
GHOST_HITS=$(echo "$CONTENT" | grep -oiP "(studies show|experts agree|research suggests|data proves|research shows|studies suggest|experts say|data suggests)" 2>/dev/null | sort -uf)
if [ -n "$GHOST_HITS" ]; then
  HITS="${HITS}  Ghost citations: $(echo "$GHOST_HITS" | tr '\n' ', ' | sed 's/, $//')\n"
fi

if [ -n "$HITS" ]; then
  echo -e "WARNING: AI tells detected in content:\n$HITS  Individual hits are advisory. Clusters of 3+ in the same passage are text-eval MUST FIX." >&2
fi
exit 0
