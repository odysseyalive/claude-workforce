# Image Reference

## Supported Aspect Ratios

| Ratio | Orientation | Resolution | Use Case |
|-------|-------------|------------|----------|
| 1:1 | Square | 1024x1024 | Profile images, thumbnails |
| 2:3 | Portrait | 832x1248 | Portraits |
| 3:2 | Landscape | 1248x832 | Photos |
| 3:4 | Portrait | 896x1152 | Mobile screens |
| 4:3 | Landscape | 1152x896 | Article headers, cards |
| 4:5 | Portrait | 928x1152 | Instagram portrait |
| 5:4 | Landscape | 1152x928 | Print |
| 9:16 | Vertical | 768x1344 | TikTok, Reels, Stories |
| 16:9 | Widescreen | 1344x768 | Hero images |
| 21:9 | Cinematic | 1536x640 | Full-width hero banners |

**Common Use Cases:**
- **Full-width hero banners:** 21:9
- **Standard hero images:** 16:9
- **Article headers / cards:** 4:3
- **Portraits:** 3:4 or 4:5
- **Square thumbnails:** 1:1
