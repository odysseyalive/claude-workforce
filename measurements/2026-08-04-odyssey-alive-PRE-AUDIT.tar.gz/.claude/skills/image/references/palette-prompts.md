# Watercolor Palette Variants

Full palette prompt text for each variant.

---

## Warm Earth (Default)

For cozy, reflective, human-centered scenes.

```
Warm sienna, ochre, and burnt orange with cool blue-grey tones in shadows. Dreamy, luminous, gentle atmosphere.
```

**Use for:** Coffee shops, homes, conversations, personal moments

---

## Cool Industrial

For technology, machinery, corporate settings.

```
Steel blues, slate greys, and cool teals - rich and vibrant, not pale or faded. Warm amber accents from overhead lights. Atmospheric.
```

**Use for:** Factories, offices, tech environments, machinery

---

## Verdant

For nature, growth, organic subjects.

```
Soft sage greens, moss, and olive tones - rich and vibrant, not pale or faded. Touches of warm gold where light falls. Fresh, alive, grounded.
```

**Use for:** Outdoors, gardens, organic themes, growth metaphors

---

## Saturated Pop

For energy, contrast, key moments. Use sparingly.

```
Rich, confident colors with full saturation in focal areas fading to softer washes at edges. Bold but still painterly.
```

**Use for:** Hero images needing punch, key visual moments, high-energy scenes

---

## Night/Moody

For evening scenes, contemplative moments.

```
Deep indigo and midnight blue - rich color, not pale or faded. Warm orange-amber glow from screens or lamps. Intimate, atmospheric.
```

**Use for:** Evening, rain, contemplative moods, screen glow scenes

---

## Example Prompts

### Warm Earth (coffee shop)
```
A watercolor painting of a cozy coffee shop interior. Warm amber lamplight glowing, wooden tables with coffee cups and scattered papers, rain visible through large windows. Wet-on-wet technique with diffused edges and seamless color blending. Transparent layered washes. Medium-rough cold-press paper texture. Painting fades softly into white paper at the edges, unfinished border with visible raw paper showing through. Warm sienna, ochre, and burnt orange with cool blue-grey tones in shadows. Dreamy, luminous, gentle atmosphere. Aspect ratio 16:9.
```

### Cool Industrial (factory floor)
```
A soft watercolor painting of an automotive factory floor with robotic arms and CNC machines, an intricate lattice-like metal part on a workbench in foreground. Wet-on-wet technique with diffused edges and seamless color blending. Transparent layered washes. Medium-rough cold-press paper texture. Painting fades softly into white paper at the edges, unfinished border. Steel blues, slate greys, and cool teals - rich and vibrant, not pale or faded. Warm amber accents from overhead lights. Atmospheric. Aspect ratio 16:9.
```

### Night/Moody (empty conference room)
```
A soft watercolor painting of an empty corporate conference room at dusk. Wet-on-wet technique with diffused edges and seamless color blending. Transparent layered washes. Medium-rough cold-press paper texture. Painting fades softly into white paper at the edges, unfinished border. Deep indigo and midnight blue walls - rich color, not pale or faded. A presentation screen glows warm orange-amber. Chairs pushed back from table, coffee cups left behind. Intimate, atmospheric. Aspect ratio 4:3.
```

---

## Key Style Characteristics

Always include these in prompts:

- **Technique:** Wet-on-wet, diffused edges, seamless color blending
- **Washes:** Transparent layered washes
- **Texture:** Medium-rough cold-press paper visible throughout
- **Border:** Soft fade to white paper at edges, unfinished look
- **Palette:** Varies by scene (use appropriate variant)

**Note:** This style works best for scenes and environments. Specific objects may retain more definition.
