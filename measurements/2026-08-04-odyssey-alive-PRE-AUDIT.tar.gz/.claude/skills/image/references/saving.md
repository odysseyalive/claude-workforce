## Saving Images

Save images to the correct source location in `assets/`:

1. Find the most recent image: `find /home/francis/Downloads -maxdepth 1 -type f \( -name "*.jpg" -o -name "*.png" -o -name "*.webp" \) -printf '%T@ %p\n' | sort -rn | head -1`
2. Copy to correct location:
   - **Hero images:** `assets/images/focus/hero/[article-slug]-hero.jpg`
   - **Inline images:** `assets/images/focus/inline/[article-slug]/[image-name].jpg`
   - **Project hero images:** `assets/images/projects/hero/[project-slug]-hero.jpg`
3. Update the MDX frontmatter or inline markdown reference with relative path
4. Run `pnpm dev` or `pnpm build` to process through Velite

**Example paths in MDX:**
```yaml
# Frontmatter hero
image: ../../assets/images/focus/hero/article-slug-hero.jpg
```
```markdown
# Inline image
![Alt text](../../assets/images/focus/inline/article-slug/image-name.jpg)
```
