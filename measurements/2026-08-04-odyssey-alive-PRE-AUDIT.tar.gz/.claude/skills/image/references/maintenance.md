## Image Maintenance

### Converting PNG to JPG

When Nano Banana generates PNG files that need to be JPG, use ImageMagick's `magick` command. Always flatten with the site's background color (`#FDF8F0`) to avoid black borders from transparency:

```bash
magick input.png -background '#FDF8F0' -flatten output.jpg
```

To convert and remove the original PNG in one step:
```bash
magick input.png -background '#FDF8F0' -flatten output.jpg && rm input.png
```

### Removing AI Signatures

Generated images sometimes include unwanted signatures or watermarks in corners. The base style template includes anti-signature language, but generators occasionally add them anyway.

#### Preferred: Regenerate

Regenerate the image using the same prompt. The base style template already includes "No text, no signature, no watermark, no letters anywhere in the image," which prevents signatures on most generations. This produces a clean image with no artifacts.

Paint-over (ImageMagick rectangles) and edit-tool removal both leave visible artifacts on watercolor textures. Flat solid shapes on organic washes look like redaction bars regardless of color matching.

#### Fallback: Edit Tool

If the composition is irreplaceable and regeneration keeps producing inferior results, use the edit tool as a last resort:

```
mcp__nanobanana-mcp__gemini_edit_image
- image_path: [path to image with signature]
- edit_prompt: "Remove the signature in the bottom right corner. Keep everything else exactly the same. The area should blend naturally with the surrounding watercolor paper texture and painting."
- aspect_ratio: [same as original, e.g., "4:3"]
- output_path: [path for edited version]
```

Verify the edit blends naturally before accepting. If it doesn't, regenerate.
