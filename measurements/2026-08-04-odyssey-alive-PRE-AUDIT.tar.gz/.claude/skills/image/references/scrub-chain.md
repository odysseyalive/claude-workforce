# Image Scrub Loop — Bounded Regeneration with Best-So-Far Keeper

<!-- origin: skill-builder | added: 2026-06-11 by /skill-builder audit (Step 4c-bis) | modifiable: true -->
<!-- Standard: .claude/skills/skill-builder/references/creative-integrity.md § Canonical Scrub-Loop Spec (image) -->

**Terminology:** this loop scrubs *AI tells via bounded regeneration*. It is not, and does not
replace, `/steganographer scrub`, which strips metadata and remains mandatory before any asset
placement — including every output of this loop (SKILL.md § Scrubbing AI Provenance).

## Deference Map (existing instructions govern — cited, never restated)

This skill already carries most loop legs. Where a leg exists elsewhere, that text governs and
this file only points to it:

| Loop leg | Governing text |
|----------|----------------|
| Evaluation of every generated image | Immutable directive "After generating any image, automatically invoke /image-eval…" (SKILL.md § Directives) + `hooks/chain-image-eval.sh`. This loop never adds its own eval mechanism; every regeneration re-enters that directive. |
| Loop entry (human gate) | `/image-eval`'s "One pass, then stop. Human decides whether to regenerate" (image-eval/SKILL.md). Regeneration cycles run only on that decision. |
| Fixability of provenance flags (NON-FIXABLE class) | image-eval/agents/image-validator/AGENT.md recommendation logic: clean → no action; generator-attributed metadata → `/steganographer scrub`; provenance-sensitive downstream use → regenerate end-to-end per SKILL.md's binding SynthID caveat. Provenance flags are surfaced to the human, never looped on — cycle-capped Nano Banana regeneration never clears SynthID. |
| Feedback folding into the next prompt | image-eval's "Preserve what works — note strengths so regeneration prompts retain successful elements" plus each flag's "Suggestion:" line. Fold the stated strengths verbatim and address flags with short, specific re-descriptions of the flawed element — never broad negative lists. |
| Palette handling | `references/workflow.md` Step 5 governs palette-monotony flags (the palette MUST change there, per the immutable palette-variant directive); the set-level palette plan (workflow.md Steps 1–2) pins sibling images' palette assignments. Nothing in this loop overrides Step 5. |

## Best-So-Far Keeper (the leg this file adds — ◆ non-negotiable)

The asset paths in `references/saving.md` are fixed, so naive regeneration overwrites its
predecessor: last-output-wins. Image quality oscillates between cycles, so last is often not best.
When the human approves regeneration:

1. ◆ **Snapshot before regenerating.** Never overwrite the prior candidate at its asset path.
   Keep candidates side by side in the staging directory (e.g. `<name>-r1.png`, `<name>-r2.png` in
   `~/Documents/nanobanana_generated/`) — never in `assets/`.
2. ◆ **Score every candidate** on: blocking-flag count from `/image-eval`, Visual Clarity Gate
   result (PASS/STOP), and palette-plan conformance.
3. ◆ **Cycle cap: 2** regeneration cycles per image within one approved scrub. Each regeneration
   is a real API spend.
4. ◆ **Present the BEST candidate across cycles, never the last.** On cap-out the keeper exhausts
   the *loop*, not the gates: if no candidate passes the Visual Clarity Gate, report to the user
   with the cycle history — never present an image past a STOP.
5. ◆ **Never optimize toward an AI-detector score.** The target is the watercolor craft rubric
   (base style, clarity, palette plan) — detector-guided revision measurably degrades quality.
6. Only the presented winner proceeds to `/steganographer scrub` and asset placement; discard the
   other candidates from staging.
<!-- /origin -->
