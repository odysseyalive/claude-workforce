# LinkedIn Posting Plan

The plan covers the operational steps after the post is written: when to post, what to do in the first 60 minutes, how to handle the comment thread. The post itself is written per `/promote/references/post-templates.md` § "LinkedIn Personal Profile" — this file does NOT redefine post structure.

## Timing

LinkedIn personal-post reach is timing-sensitive. The audience (engineering leaders) is most active during work hours, and the algorithm weighs first-hour engagement heavily, so posting time matters more than on most platforms.

### Best windows (US-centric, since the audience target is US-heavy)

- **Tuesday, Wednesday, Thursday — 7:00-9:00am ET.** This is the prime window. Engineering leaders check LinkedIn before standup. Posts dropped at 7:30am ET have a 2-hour engagement runway before West Coast wakes up, then a second wave when WC opens.
- **Tuesday, Wednesday, Thursday — 12:00-1:30pm ET.** Lunch window. Lower volume than morning but cleaner — fewer competing posts.

### Windows to avoid

- **Monday before noon.** Inbox-clearing mode; engagement rates drop ~20%.
- **Friday after 1pm.** Audience checks out for the weekend.
- **Saturday and Sunday.** This audience does not work on LinkedIn on weekends. Engagement collapses.
- **After 5pm ET any day.** Algorithm pushes posts during work hours; evening posts get throttled.

### Concrete recommendation per session

Pick one of these three slots, in order of preference:
1. Tomorrow (or next Tue/Wed/Thu) at 7:30am ET
2. Tomorrow (or next Tue/Wed/Thu) at 12:30pm ET
3. Today, IF it's currently between 7-9am or 12-1:30pm ET on a Tue/Wed/Thu

If the user has reasons to post outside these windows, do not argue. Surface the timing recommendation, then accept the user's call.

## Hashtags

LinkedIn's hashtag value has eroded since 2023; over-hashtagging now hurts reach. Three rules:

1. **3-5 hashtags maximum.** Past 5, reach drops measurably.
2. **Niche over broad.** `#PlatformEngineering` outperforms `#AI`. `#LLMOps` outperforms `#Innovation`. Specific tags reach the right audience; broad tags get drowned in noise.
3. **No invented hashtags.** Only use tags that already have an active follower base (check before recommending). Vanity tags signal vendor-pitch.

### Hashtag pool for this audience

Use any 3-5 from the pool that match the article topic:

- `#PlatformEngineering`
- `#LLMOps`
- `#MLOps`
- `#AIEngineering`
- `#EngineeringLeadership`
- `#SoftwareArchitecture`
- `#DevEx` (developer experience)
- `#Observability`
- `#TechnicalLeadership`
- `#StaffEng`
- `#EngineeringManagement`
- `#AISafety` (only when the article actually addresses safety)
- `#Reliability` / `#SRE`

Avoid: `#AI`, `#ArtificialIntelligence`, `#Innovation`, `#FutureOfWork`, `#DigitalTransformation`, `#TechTrends`, anything starting with "Future of."

Place hashtags at the end of the post body, NOT inline in the prose. Inline hashtags break reading flow and signal vendor-pitch register.

## First Comment

The first comment is for the article link. This is non-negotiable per `/promote`'s "never tell the audience where the link is" directive — the post sells the idea; the link is discoverable, not announced.

### What goes in the first comment

Just the URL. Nothing else. Examples:

- ✅ `https://www.odysseyalive.com/focus/the-fortress`
- ❌ `Read the full piece here: https://...`
- ❌ `For the full argument, see: https://...`
- ❌ `https://... — full article on the blog`

The post does the selling. The link sits there as a quiet next step.

### Why first-comment placement

LinkedIn deprioritizes posts with outbound links in the body — measured 30-50% reach reduction. A link in the first comment, dropped by the post author within the first minute, gets the URL into the conversation without triggering the link-penalty.

### Drop the comment within 60 seconds of posting

If the user delays past 60 seconds, the algorithm has already classified the post; adding the link later has weaker effect. Surface this as part of the plan: "Post → drop the link comment within 60 seconds → THEN start engaging."

## First 60 Minutes (the engagement window)

LinkedIn's algorithm decides the post's distribution ceiling within roughly the first hour. The author's own engagement during that window is the largest single signal.

### Steps within the first 60 minutes after posting

1. **0-1 minute:** Drop the article link in the first comment.
2. **1-15 minutes:** Reply to any early comments. Substantive replies (2-3 sentences, advancing the conversation), not "thanks for reading." Each reply triggers a notification to the commenter and pushes the post back into circulation.
3. **15-60 minutes:** Visit 5-10 posts in your feed from the audience archetypes. Leave thoughtful comments on theirs. Reciprocity is real — the people you engage with are more likely to engage back when notified of your post.
4. **Throughout the window:** Do not delete and repost if engagement is slow. Algorithmic penalty for delete-and-repost is severe.

### What "substantive reply" means

- Names something specific in the comment that prompted the reply.
- Adds new information or a new angle, not just affirmation.
- Asks a follow-up question if the comment opens one — but only when there's a real question, not a rhetorical "great point!"
- 2-3 sentences. One-line replies signal low-effort and are weighted lower.

## Comment-Thread Strategy (after the first hour)

The post will likely accumulate comments over 24-72 hours. The author's job during this window:

### Reply to every substantive comment within 4 hours

Substantive = the commenter wrote more than "Great post!" or a single emoji. The 4-hour window keeps the post in the algorithm's "active" state and signals that the author is present.

### When a commenter pushes back, engage the disagreement

The audience reads disagreement-handling carefully. A defensive reply tanks credibility; a curious reply ("you might be right — what specifically broke for you?") builds it. The forward-test colleague is watching how the author handles pushback before deciding whether to share.

### When a commenter shares something useful, surface it

A reply like "@FirstName makes the sharper point here — [paraphrase their addition]" pulls them deeper into the thread, signals to the algorithm that the post is a discussion, and builds reciprocity.

### Do not @-tag aggressively in the post or replies

@-tagging more than one or two people in the body of a post is widely read as a reach hack. Use sparingly and only when the tagged person is genuinely central to the argument.

## @-Mentions in the Post

The post can @-mention up to 1-2 people if the article quotes them, names them, or builds on their public work. The criteria:

1. **They are named in the article**, not just topically related.
2. **They are recognizable to the audience**, not just to Francis personally. Per the user's `feedback_promote-name-drops-hooks` memory: "Name drops must be household-recognizable; hooks 1-2 sentences max."
3. **The mention is natural in the post's flow**, not bolted on.

If those criteria are not met, no @-mention. An ungrounded @ reads as fishing for amplification.

## Output Format for the Plan

When the skill presents the plan to the user, format it like this:

```
POSTING PLAN — [article slug]

Post when:
  → [Day], [Time] ET (primary)
  → [Day], [Time] ET (alternate)

First comment (drop within 60 seconds of posting):
  → [exact URL]

Hashtags (place at end of post body):
  → #Tag1 #Tag2 #Tag3

@-mentions in body:
  → [name(s) if any, with reason — or "none, no household-recognizable names available"]

First 60 minutes after posting:
  1. Drop link in first comment (0-1 min)
  2. Reply to early commenters with substantive 2-3 sentence replies (1-15 min)
  3. Visit 5-10 audience-archetype feeds, comment substantively on theirs (15-60 min)

Comment-thread strategy:
  → Reply to every substantive comment within 4 hours
  → Engage disagreements with curiosity, not defense
  → Surface and amplify commenter additions

Do not:
  → Announce the link in the post body
  → @-tag for reach
  → Delete and repost if engagement is slow
```

This format makes the plan operational. Francis should be able to act on it without needing to re-read this reference file.
