# Audience: VP of Engineering, 100-1000 Employee Companies, Considering AI Transformation

## Forward-Recipient Archetypes

When the Shareability Gate asks "who would forward this to a colleague?", the answer comes from this list. Pick the most specific match for the article. Do not generalize to "engineering leaders" — that fails the gate.

### A. The Mandate-Pressed Director
A director of engineering whose CEO came back from a board meeting saying "we need an AI strategy in 90 days." They know the deadline is performative. They also know "no, we don't" is not on the table. They're looking for cover that lets them slow down without looking like they're dragging.

**Forward trigger:** Anything that names the gap between the executive's narrative and the actual implementation cost. Anything that gives them language to push back without sounding obstructionist.

### B. The Eval-Drowning Platform VP
Runs a platform team that adopted LLM features last year. The eval harness is held together with goodwill and three cron jobs. Half the team thinks they're doing great because the demo works; the other half is up at 2am triaging hallucinations in prod. They are tired of "we just need better prompts."

**Forward trigger:** Specifics about evals, observability, prod incidents in AI features, the cost of "it works on my machine" with non-determinism. Anything that validates their tired-ness without being cynical.

### C. The Reluctant Buyer
A VP who has been pitched 11 AI vendors this quarter. They've signed two pilots that went nowhere. They know the next pilot has to actually work or their CFO will stop signing the POs. They are not interested in another "transformation" pitch.

**Forward trigger:** Honest accounting of failure modes. Anti-pattern catalogs. Anything that names what won't work and why, especially when the article's author has skin in the same problem.

### D. The On-Call Engineer Promoted Up
Recently moved from senior IC to first-line manager. Still wears the pager. Still gets called when AI features break in prod. Hasn't yet learned the executive-translation skill — they communicate the way engineers communicate, which is to say, accurately. Their boss has started using phrases like "you need to be more strategic."

**Forward trigger:** Stories where someone gets the "be more strategic" feedback and finds a way to push back without burning the relationship. Pieces that respect the truth-telling instinct of someone who still does the work.

### E. The Skeptical Architect
Principal-level. Has seen three hype cycles. Will probably see three more. Quietly believes most of the AI work is wrong but doesn't want to be the obstructionist. Reads to know which battles to pick.

**Forward trigger:** Pattern recognition. Anything that names what THIS hype cycle has in common with last cycle's mistakes, without being smug. Bonus if it gives them ammunition for the architecture review.

---

## Working Vocabulary

### Use these (the audience's own words)

- **Eval harness, eval suite, evals** (not "quality assurance," not "testing framework")
- **On-call, the pager, the rotation, the runbook**
- **Prod, prod incident, the postmortem, the blameless review**
- **Platform debt, integration debt, eval debt** (technical debt has subtypes here)
- **Hallucination** in the technical sense (not generic "AI mistake")
- **Latency budget, token budget, context window**
- **The 99th percentile, p99, the long tail**
- **Pilot, pilot graveyard, POC, POC purgatory**
- **Backpressure, retry storms, thundering herd**
- **The on-call rotation, the escalation path**
- **Vendor lock-in, the SLA, the credit window**

### Avoid these (vendor-pitch register)

- **Transformation, transformation journey, digital transformation**
- **Synergy, synergize, alignment, alignment-driven**
- **Leverage** (as a verb)
- **Stakeholders** (use specific roles instead — "the VP of Eng," "the on-call team," "the CFO")
- **Best-in-class, world-class, industry-leading**
- **Unlock value, drive value, value creation**
- **At scale** (often empty; if you mean "in production with real traffic," say that)
- **Robust, scalable, future-proof** (compression vocabulary; the audience hears it as "no concrete claim")
- **Empower, enable** (empty intransitive verbs in this register)
- **Mission-critical** (degraded by overuse; either it's down or it's not)

### Borderline — use only with concrete anchor

- **Production-ready** — fine if you say what "ready" means (load tested at X RPS, on-call rotation covers it, etc.)
- **Adopt, adoption** — fine if you describe what adoption looked like (who used it, how often, what broke)
- **AI-native** — only if the article actually distinguishes from "AI-bolted-on"

---

## Stakes Framing

The audience is making decisions where they can be fired for getting it wrong, and where they can be sidelined for getting it right too slowly. Stakes language must reflect THEIR stakes, not abstract organizational stakes.

### The stakes that move this audience

- **Career risk of a bad bet.** "If this pilot fails, my CFO will stop signing POs and I won't get another shot." Concrete, time-boxed, personal.
- **Credibility decay.** "If I keep saying 'we're working on it' for another quarter, I lose the room." Status-of-voice over time.
- **Team morale debt.** "My senior engineers will leave if we keep shipping AI features that page them at 2am." Retention as a real cost, not an HR slogan.
- **Audit/compliance trap.** "When the auditor asks how this model makes decisions, I need an answer that isn't 'vibes.'" The downstream regulator they haven't met yet.
- **Personal runway.** "I'm 90 days into a 180-day mandate and I have nothing real to show." Calendar pressure, not vague urgency.

### Stakes language to AVOID

- **"In an era of"** — abstract, no-one's-stakes-in-particular
- **"Companies that don't X will Y"** — generic threat, not the reader's threat
- **"The future of work / leadership / engineering"** — none of this is what the reader is being measured on next quarter
- **"Disruption" / "be left behind"** — vendor-pitch threat register; the audience has heard it for a decade and learned to discount it

---

## Forward-Test Phrasing

When applying `/promote`'s Shareability Gate to a draft, use this test phrasing specifically for this audience:

> "Would [archetype name] forward this to [specific colleague archetype], with a comment that's either 'this is exactly the conversation we had last week' or 'this is what I've been trying to explain in the architecture review'?"

If you can't write that sentence with specifics filled in, the post hasn't earned the audience yet.
