# Practitioner-Vulnerability as Primary Register

## What it is

The author writes from inside the problem, not from above it. They've carried it, failed at it, sat with it, paid for it. The post draws its authority from skin in the game, not from analysis.

The `awareness-ledger` PAT-2026-04-01 documents this register's measured effect: 3-5x dwell time on articles in this register vs. observational pieces. The Dose, The Fortress, The Dress Rehearsal, Faster Than Thought, No Brakes, The Compliance Funnel — all in this register. The Quick Last Prompt, The Island — observational, bounce in 6 seconds.

## What it sounds like

### In the article (where you'll find the anchor)

> "I sat with this for three weeks before I wrote about it. I didn't have a clean answer. I'm not sure I have one now."

> "We shipped it. It broke. The postmortem named me. That's where this started."

> "I keep getting this question and I keep giving the wrong answer. Here's what I should have said."

### In the LinkedIn post (where you'll anchor it)

The hook should land in the practitioner's voice, not the analyst's voice. Compare:

**Observational hook (avoid as primary):**
> "Companies are struggling to operationalize AI evals. Most pilots fail in production."

**Practitioner-vulnerability hook (use as primary when available):**
> "We had three pilots running. Two are quietly dead and the third is held together by a person, not a process. I keep telling myself we'll fix that next quarter."

Same topic. Different stance. The first is correct and forgettable. The second is the post that gets forwarded with "this is exactly us."

## How to find the anchor

When reading the article, look for moments where the author:

1. **Names a personal cost.** Time spent, sleep lost, a meeting where they were wrong, a pager event, a relationship strained. The cost is concrete, not metaphorical.
2. **Admits an unresolved tension.** Not "here's the answer" but "here's the thing I keep not solving."
3. **Quotes themselves being wrong, or being asked something they didn't know how to answer.** Mid-conversation discovery, not retroactive synthesis.
4. **Describes work they actually did.** Hands on a keyboard, not a position taken.

If you find more than one, pick the one with the highest specificity. Specificity is the active ingredient — generic vulnerability ("it's hard") fails the same way generic optimism does.

## How to anchor the post in it

The hook should reference the practitioner moment without explaining it. Examples:

- Drop a verbatim line from the article into the hook (LinkedIn likes single-quote rhythm).
- Open with the cost ("I lost a sprint to this") and let the reader lean in.
- Open with the unresolved tension ("Three months in, I still don't have a clean answer for this question").

Then the body unfolds the article's argument — but the body is *earned* because the hook proved the author isn't pitching.

## Disqualification cases

There are 3 cases where practitioner-vulnerability is NOT the right primary register, and the skill should fall back to `/promote`'s standard wit-first approach. Surface this in the output:

### Case 1: The article is purely observational

The author is reporting on a phenomenon they didn't experience. Pattern recognition piece, industry analysis, news commentary. There's no first-person stakes to anchor in.

**Signal:** No first-person sentences in the article body, or first-person sentences are limited to "I noticed" / "I've been watching" — observation, not participation.

**Fallback:** `/promote`'s wit-first hook. The hook leads with the observation's punch, not with manufactured vulnerability.

### Case 2: The vulnerability would be inauthentic

The article touches a topic where Francis has an opinion but not skin in the game (e.g., commentary on a sector he doesn't work in, a piece that's primarily a quote from someone else). Pretending to carry a problem he didn't carry produces the worst of both worlds: a vulnerability claim that reads as performance.

**Signal:** The article's first-person sentences are stylistic but not stakes-based ("I read this and thought..." rather than "I lived this and learned...").

**Fallback:** `/promote`'s wit-first hook. Better to be sharp and observational than to manufacture skin.

### Case 3: The article's wit IS the value

Some articles are primarily satirical (compare The SaaSpocalypse, The Trojan Combine when it leans satirical). The wit IS the practitioner stance — there's no separate vulnerability to reach for; the joke is the way the author processed the experience.

**Signal:** The article's strongest moments are wit/observation, and the wit itself feels lived-in (not detached). Practitioner-vulnerability would dilute it.

**Fallback:** `/promote`'s wit-first hook with full emphasis. Lean into the article's own punch.

## Output annotation

When the skill produces a post, include a one-line annotation in the presentation:

```
Register: practitioner-vulnerability — anchored on "[article quote]"
```

OR

```
Register: wit-first (article register is observational; practitioner-vulnerability fallback per disqualification case [1|2|3])
```

This makes the choice visible to the user and surfaces it for revision if they disagree with the read.
