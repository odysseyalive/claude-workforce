---
name: linkedin-promote
description: "LinkedIn-only promotion of a focus article — VP-of-Engineering audience lock, practitioner-vulnerability register, organic posting plan. Usage: /linkedin-promote [slug]"
allowed-tools: Read, Glob, Grep, Write, Bash, Skill, Task
minimum-effort-level: high
strictness: standard
---

# LinkedIn Promote

LinkedIn-only organic promotion of a focus article, tuned to a specific decision-maker audience and posted with a deliberate engagement plan. Inherits `/promote`'s directive enforcement (wit-first, shareability, name-drop, message-lands) — does not re-state it.

## Usage

```
/linkedin-promote [slug]
```

Single-purpose. `slug` matches a file in `content/focus/*.mdx`.

When invoked from `/promote --linkedin-only [slug]`, this skill produces the same output and skips cross-platform adaptation.

---

<!-- origin: user | added: 2026-04-25 | immutable: true -->
## Directives

> **Audience: VPs of Engineering at companies with 100-1000 employees considering AI transformation.** Every post is written to this reader, not to a generic LinkedIn feed. Concrete archetype and vocabulary in `references/audience-vp-eng.md`.

*— Added 2026-04-25, source: user, conversation 2026-04-25 (analytics review)*

> **Practitioner-vulnerability is the primary register, not one option.** First-person stakes inside a technical problem, not analysis from above it. The Dose, The Fortress, The Dress Rehearsal showed 3-5x dwell time on this register vs. observational pieces (PAT-2026-04-01-the-dose-deep-engagement). Default here unless the article has no first-person stakes available.

*— Added 2026-04-25, source: derived from PAT-2026-04-01 + user audience-targeting decision*

> **Organic only. No paid mechanics.** Paid LinkedIn boosting is closed for this account (Boost button not in rollout; Company Page opted out). Do not generate ad copy, targeting parameters, or budget recommendations. The skill produces a post and a posting plan — that is the entire scope.

*— Added 2026-04-25, source: user constraint, conversation 2026-04-25*
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Audience: VPs of Engineering at companies with 100-1000 employees considering AI transformation." -->
CHECKPOINT — Audience Lock Gate:
1. Before drafting, read `references/audience-vp-eng.md` and extract the forward-recipient archetypes, vocabulary list, and stakes framing into working context.
2. After drafting the post, name in one sentence which specific archetype the post is written TO (e.g., "the eng director who just got an AI mandate from the CEO and has 90 days to show results", "the platform VP whose team is drowning in eval debt").
3. IF the named archetype is generic ("anyone in tech", "engineering leaders", "decision-makers") → STOP. The audience lock failed. Rewrite around a concrete archetype from the reference file.
4. Scan the draft for forbidden vocabulary: "transformation journey", "synergy", "leverage", "stakeholders", "best-in-class", any phrase the audience would scroll past in a vendor pitch. IF present → STOP and replace with the audience's actual working vocabulary (eval harnesses, on-call, platform debt, prod incidents, the on-call rotation, etc.).
5. IF the post is written TO a concrete archetype AND uses the audience's working vocabulary → CONTINUE to the register gate.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Practitioner-vulnerability is the primary register, not one option." -->
CHECKPOINT — Register Gate:
1. Read `references/register.md` for the practitioner-vulnerability framing and the 3 disqualification cases.
2. Scan the source article for first-person practitioner stakes: did the author actually carry the problem, fail at it, or sit with it? Quote the strongest practitioner moment from the article verbatim into working context.
3. IF the article contains a clear practitioner-vulnerability moment → the post MUST anchor in that moment, not in observation about the moment. The post says "I did this and it cost me," not "Here's what people are doing wrong."
4. IF the article is purely observational (no first-person stakes available) → fall back to `/promote`'s standard wit-first hook approach. Note in the output: "Article register is observational; primary register N/A here."
5. IF the post is written from observational distance when a practitioner moment was available → STOP. The register gate failed. Rewrite anchored in the practitioner moment.
6. IF the register matches the article's available stance → CONTINUE to /promote's directive gates (wit-first, shareability, name-drop, message-lands) which run at validation time.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Organic only. No paid mechanics." -->
CHECKPOINT — Organic-Only Gate:
1. Before producing any output, scan the planned deliverables for paid-mechanics elements: ad copy variants, targeting filters (job title, company size, industry pickers), budget recommendations, campaign duration, bid strategy, "boost recipe" tables.
2. IF any paid-mechanics element is present in the planned output → STOP. Remove. The deliverables are: (a) one LinkedIn personal post, (b) a posting plan covering timing/hashtags/first-comment/engagement strategy. Nothing else.
3. The posting plan is OPERATIONAL (when to post, what to do in the first 60 minutes, how to handle the comment thread). It is NOT promotional infrastructure.
4. IF a user request during the session asks for paid mechanics → respond with: "Paid LinkedIn promotion is out of scope for this skill per your constraint. To revisit, you'd need either Boost button rollout access or a minimal Company Page to host an ad account."
5. IF deliverables match the organic-only set → CONTINUE.
<!-- END ENFORCEMENT ANNOTATION -->

---

## Skill Chaining

This skill does not duplicate `/promote`'s directive infrastructure. It loads it.

**Before drafting:**
1. Invoke `/voice` — Load Francis's authentic voice
2. Read `.claude/skills/promote/references/social-writing.md` — five writing directives for short-form social
3. Read `.claude/skills/promote/references/social-coherence.md` — seven structural rules
4. Read `.claude/skills/voice/references/satirical-wit.md` — for hook punch calibration
5. Read `.claude/skills/promote/references/post-templates.md` § "LinkedIn Personal Profile" — structural template
6. Read `references/audience-vp-eng.md` — audience lock
7. Read `references/register.md` — practitioner-vulnerability primary register
8. Read `references/posting-plan.md` — operational plan after the post is written

**Hook Workshop is mandatory before drafting.** Use `/promote`'s hook workshop verbatim — `.claude/skills/promote/references/hook-workshop.md`. Do not reinvent.

---

## Workflow

1. **Read the article.** Find `content/focus/[slug].mdx` and read in full. Extract: practitioner moment (verbatim quote), strongest stat or name drop, the one viral point.
2. **Run Audience Lock Gate** (see CHECKPOINT above) — name the archetype before drafting.
3. **Run Register Gate** (see CHECKPOINT above) — anchor in the practitioner moment if available.
4. **Run /promote's Hook Workshop** — generate 3-5 candidate hooks; present to user; user picks.
5. **Draft the LinkedIn personal post** using `/promote/references/post-templates.md` § "LinkedIn Personal Profile" structure (~140 char hook, 5-8 sentences, 500-900 chars total).
6. **Run validation** — Stage 1 social-validator (`/promote`'s agent), then Stage 2 finishing chain (`/text-eval`).
7. **Generate the posting plan** — read `references/posting-plan.md`; produce a concrete plan: best posting time (Tue-Thu morning ET window), first-comment link content, 60-minute post-publish engagement steps, comment-thread reply strategy, hashtag set (3-5 niche), suggested @-mentions if any are warranted by the article.
8. **Present** — post + posting plan in a single output. Offer revision via `/edit` (chained mode, content type `social-post`).

---

## Validation

Inherit `/promote`'s two-stage validation. Do not create a separate validator.

**Stage 1: Social Validator** — `.claude/skills/promote/agents/social-validator/AGENT.md` (LinkedIn Personal Profile platform).

**Stage 2: Content Finishing Chain** — per `.claude/skills/text-eval/references/finishing-chain.md`. Content type: **social post**.

---

## Revision Phase

When the user requests changes after presentation:
1. Invoke `/edit` in chained mode with content type `social-post`.
2. `/edit` applies the change with social writing context loaded.
3. Re-present the modified post.

---

## Post-Action Capture

After producing a post + plan, if engagement results emerge later (saved comments, inbound DM, sustained dwell on the article from LinkedIn referral in GA4), suggest recording in the awareness ledger as a PAT update — extending PAT-2026-04-01 if the practitioner-vulnerability pattern continues to hold under LinkedIn-driven traffic. Never auto-record — ask the user first.

---

## Grounding

Before writing, state which audience archetype and which article practitioner moment will anchor the post.

**References:**
- [references/audience-vp-eng.md](references/audience-vp-eng.md) — Audience archetypes, vocabulary, stakes framing
- [references/register.md](references/register.md) — Practitioner-vulnerability primary register, disqualification cases
- [references/posting-plan.md](references/posting-plan.md) — Timing, hashtags, first-comment, engagement plan

**Inherited from `/promote`:**
- `.claude/skills/promote/references/post-templates.md` — structural template (LinkedIn Personal section)
- `.claude/skills/promote/references/social-writing.md` — writing directives
- `.claude/skills/promote/references/social-coherence.md` — coherence rules
- `.claude/skills/promote/references/hook-workshop.md` — hook workshop procedure
- `.claude/skills/promote/references/engagement.md` — engagement steps (referenced by posting-plan.md)

---

## Discovered Issues Log

### 2026-07-06 — check-temporal-refs.sh blocked org-file edits *(RESOLVED 2026-07-06)*

**Symptom:** During `/agenda today`, a confirmed triage body-note append to `~/org/dynamicmotorsports.org` was blocked by this skill's `check-temporal-refs.sh` — the pure-append `new_string` re-includes the anchor line, which contained the word "today".

**Cause:** The hook's scope check skipped only `.claude/` and `agenda/` paths, so it fired on any Edit anywhere else, including org-mode files that are internal dated records, never LinkedIn content.

**Fix:** Added `\.org(_archive)?$` to the scope exclusion in all three copies of the hook (linkedin-promote, newsletter, promote). Verified with `bash -n` and by re-applying the blocked write.
