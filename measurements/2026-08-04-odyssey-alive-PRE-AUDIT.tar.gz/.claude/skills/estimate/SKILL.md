---
name: estimate
description: "Cross-reference logged org CLOCK time against an estimate document to produce calibrated hour estimates per line item. Modes: estimate, calibrate. Usage: /estimate [mode] [args]"
allowed-tools: [Read, Edit, Bash, Glob, Grep]
---

# Estimate

Produce calibrated hour estimates for quoted work items by cross-referencing logged CLOCK time in org files. Finds the closest logged analogue for each line item, favors recent timestamps (streamlined workflows), and outputs a per-item range with point estimates and a roll-up total.

## Usage

```
/estimate [mode] [args]
```

### Modes

| Mode | Command | Description |
|------|---------|-------------|
| `estimate` | `/estimate <estimate-doc> <org-file>` | Produce hour estimates per line item (default) |
| `calibrate` | `/estimate calibrate <org-file>` | Show logged CLOCK entries grouped by task type as reference rates |

Default mode is `estimate` if not specified.

---

## Directives

*(none yet)*

---

<!-- origin: skill-builder | version: 1.0 | modifiable: true -->
## Workflow: Estimate

1. **Resolve inputs.** Accept two paths: the estimate document (`.md` or `.pdf`) and the org file with CLOCK entries. If only one path is given, infer the other from context (e.g., the project's known org file). If neither is given, ask.
2. **Parse the estimate document.** Read the file and extract each numbered line item: item number, description, scope/effort notes, and any existing sizing (T-shirt or hours). For PDFs, read the relevant pages containing the estimate table.
3. **Extract CLOCK entries.** Read the org file and extract all `:LOGBOOK:` / `CLOCK:` blocks with their parent TODO headlines. Compute elapsed hours per entry. Group by TODO headline.
4. **Build the reference rate table.** Group CLOCK entries by task type (option patch, pricing fix, stain/swatch work, render build, collection work, import, theme change, etc.) using headline keywords. Prefer recent entries (last 90 days) over older ones. Present the calibration anchors: each task type with its logged hours and the specific TODO headline.
5. **Match each line item to analogues.** For each estimate line item, find the closest logged analogue(s) by task type. Consider:
   - Nature of the work (option build, pricing resolver, data fix, frontend render, config change)
   - Scope (single builder vs multi-builder, number of files touched)
   - Complexity indicators from the estimate doc (effort sizing, risk notes, gotcha flags)
6. **Produce the estimate.** For each line item, output:
   - Item number and description
   - Closest logged analogue(s) with their actual hours
   - Estimated range (low-high)
   - Point estimate (user preference: low, mid, or max of range)
   - Scaling rationale (why this item is similar/different from the analogue)
7. **Roll-up.** Sum the point estimates. Note any bundling efficiencies (shared regression sweeps, overlapping files). Present the total with caveats (labor hours only, excludes client-blocked wait time).
8. **Output format.** Present as a markdown table matching the estimate document's structure, followed by a calibration block showing the reference rates used.

## Workflow: Calibrate

1. **Read org file.** Parse all CLOCK entries with parent headlines.
2. **Group by task type.** Classify each entry by work type using headline keywords.
3. **Present reference rates.** Show a table of task types with: example headline, logged hours, date, and whether it's a greenfield build or a streamlined patch. Flag the most recent entry per type as the preferred anchor.

## Point Estimate Preference

The user may specify which part of the range to use as the point estimate:

- `--low` — use the low end of each range
- `--mid` — use the midpoint (default)
- `--max` — use the high end of each range

When unspecified, default to `--mid`. The user can override per session.
<!-- /origin -->

---

<!-- origin: skill-builder | version: 1.0 | modifiable: true -->
## Grounding

Before producing estimates:
1. Read [reference.md](reference.md) for the task-type classification heuristics and calibration methodology
2. State: "I will scan [ORG_FILE] for CLOCK entries and match against [ESTIMATE_DOC] line items"

See [reference.md](reference.md) for task-type keywords, analogue-matching rules, and scaling factors.
<!-- /origin -->
