# Estimate Reference

## Task-Type Classification

Map org TODO headlines to task types using keyword matching. A headline may match multiple types; use the primary match.

| Task type | Headline keywords | Typical scope |
|-----------|------------------|---------------|
| Option patch | `option`, `options`, `patch`, `add option` | Single builder, 1-2 files |
| Pricing fix | `pricing`, `price`, `stain pricing`, `resolver` | Per-builder pricing logic, resolver in frontend.php |
| Stain/swatch data | `stain`, `swatch`, `color`, `fabric`, `missing stain` | Data class + media assets |
| Render/frontend build | `render`, `frontend`, `linking`, `collection`, `display` | Shared frontend.php, CSS |
| Import/importer | `import`, `importer`, `builder`, `new builder` | Per-builder importer class |
| Theme/config | `theme`, `related`, `category`, `filter`, `elementor` | Theme functions.php, WC config |
| Full builder (greenfield) | `woodworking`, `new builder`, full builder name | All files, end-to-end |

## Calibration Methodology

1. **Prefer recent entries.** CLOCK entries from the last 90 days reflect current tooling and workflow maturity. Older entries (especially greenfield builds) overestimate because early work includes learning curves and one-time setup.
2. **Greenfield vs patch.** A full builder build (e.g., "J&R Woodworking" at 11.33h) is NOT a valid anchor for incremental work. Use focused patches (2-4h range) as anchors for change-order items.
3. **Scaling factors.** When an estimate item spans more builders or files than the analogue:
   - Per-builder multiplier: if the analogue covers 1 builder and the item covers N, scale by ~N*0.7 (not N*1.0 — subsequent builders reuse the pattern).
   - Shared-file risk: items touching `class-frontend.php` or other shared files add ~1h for regression testing.
   - Bundling discount: items sharing the same shared file in one pass reduce the per-item regression cost.
4. **Range construction.** Low = analogue hours (assumes identical scope). High = analogue hours * scaling factor + risk buffer. Point = user-selected position in range (low/mid/max).

## Analogue Matching Rules

For each estimate line item:

1. Read the item's description, scope notes, and effort sizing from the estimate doc.
2. Classify the primary work type using the Task-Type table above.
3. Search the org CLOCK entries for the closest match by type AND recency.
4. If multiple analogues exist, prefer: (a) most recent, (b) closest scope match, (c) same project/builder.
5. If no close analogue exists, use the task-type average and flag as "low confidence."

## Output Table Format

```markdown
| # | Item (recommended scope) | Closest logged analogue(s) | Est. range | Point |
|---|--------------------------|----------------------------|-----------|-------|
| 1 | [description] | [analogue] [hours]h | [low]-[high]h | ~[point]h |
```

Followed by:
- Roll-up total (range and point)
- In-scope vs out-of-scope split (if applicable)
- Caveats (labor hours only, client-blocked inputs, bundling notes)
