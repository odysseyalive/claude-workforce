## Structure Template

```
[Subject Line] — Hook based on lead article, creates curiosity

[Best Image] — Most compelling image from lead article (hero or inline)

[Lead Article]
- 2-3 sentence teaser that creates an open loop
- "Read more →" link

[Second Article]
- 1-2 sentence teaser
- "Read more →" link

[Third Article]
- 1-2 sentence teaser
- "Read more →" link

[Closing] — Optional single line. "Thanks for reading" or similar.
```

### Lead Article Selection

The lead article should be:
- The best social performer (if user indicated one)
- OR the most broadly appealing topic
- OR the most recent if all else is equal

Give the lead article more space (2-3 sentences). The other two get briefer treatment (1-2 sentences each).

### Lead Article Image

Pick the **best image** from the lead article for the newsletter. This could be:
- The hero image (most common)
- An inline image if it's more visually compelling or better represents the article

Check the article's images at:
- Hero: `assets/images/focus/hero/[slug]-hero.jpg`
- Inline: `assets/images/focus/inline/[slug]/`

Choose the image that will grab attention in an inbox.
