## Selection Workflow Details

### Step 1: Get the Date

Ask: "What is today's date?"

### Step 2: List Recent Articles

Look back **one month** from the provided date. Run this command to find articles:

```bash
for f in content/focus/*.mdx; do
  date=$(grep "^date:" "$f" | head -1 | sed 's/date: //' | cut -d'T' -f1)
  title=$(grep "^title:" "$f" | head -1 | sed 's/title: "//' | sed 's/"$//')
  slug=$(grep "^slug:" "$f" | head -1 | sed 's/slug: "//' | sed 's/"$//')
  echo "$date | $title | https://odysseyalive.com/focus/$slug"
done | sort -r | head -20
```

Filter to articles within the one-month window and present as a table:

```
| Date | Title | URL |
|------|-------|-----|
| 2026-01-22 | AI Needs Two Context Windows | https://odysseyalive.com/focus/ai-needs-two-context-windows |
| ... | ... | ... |
```

### Step 3: Ask About Social Performance

Ask: "Which of these articles performed best on social media?"

Wait for user response. This helps prioritize content that resonated.

### Step 4: Select Three Articles

From the available articles, select **exactly 3** for the newsletter based on:

1. **Social performance** — Prioritize articles the user identified as performing well
2. **Subject diversity** — Don't pick three AI articles; mix categories (ai-transformation, pattern-recognition, case-studies, field-notes)
3. **Recency balance** — Mix of newer and slightly older (but still within the month)

Present the selection for approval:

```
Recommended newsletter articles:
1. [Title] — [Category] — [Why selected]
2. [Title] — [Category] — [Why selected]
3. [Title] — [Category] — [Why selected]
```

Ask: "Does this selection work, or would you like to swap any articles?"

### Step 5: Create Newsletter Content

Once articles are approved, create the newsletter with all three articles featured.
