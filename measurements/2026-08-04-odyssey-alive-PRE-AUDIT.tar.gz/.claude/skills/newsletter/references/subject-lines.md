## Subject Lines

**Good examples:**
- "The librarian who never sleeps" (intriguing, from article metaphor)
- "What I learned at 2 AM in a browser tab rabbit hole" (personal, specific)
- "The one skill that changes everything with AI" (benefit-focused hook)

**Bad example:**
- "Your New Research Partner: How AI Can Help With Research" (too explanatory)

**Rules:**
- Create curiosity, don't summarize
- Pull from article metaphors or specific details
- First-person hooks work well
