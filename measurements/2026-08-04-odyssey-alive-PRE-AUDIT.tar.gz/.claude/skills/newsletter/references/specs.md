# Newsletter Reference

## Specs

| Element | Guideline |
|---------|-----------|
| **Articles** | Exactly 3 articles per newsletter |
| **Total word count** | 300-400 words (entire newsletter) |
| **Images** | Best image from lead article only (hero or inline) |
| **Reading time** | ~1 minute to scan |
