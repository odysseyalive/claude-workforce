## Output Templates

### Single Image Evaluation

```
## Image Evaluation

### Required Checks
Signature check: [found/none]
Symmetry check: [symmetric/asymmetric] — [brief note]

### Summary
[One sentence: overall assessment and confidence level]

### Flags
[List specific concerns with descriptions]

1. **[Pattern name]** — [location in image]
   - Why flagged: [brief explanation]
   - Suggestion: [concrete alternative or regeneration approach]

### Strengths
[2-3 things that work well and should be preserved in regeneration]

### Recommendation
[Keep as-is / Regenerate with adjustments / Significant revision needed]
```

### Article Image Set Evaluation

```
## Article Image Set Evaluation

### Required Checks
Signature check:
- Hero: [found/none]
- Inline 1: [found/none]
- Inline 2: [found/none]

Symmetry check:
- Hero: [symmetric/asymmetric]
- Inline 1: [symmetric/asymmetric]
- Inline 2: [symmetric/asymmetric]

Palette identification:
- Hero: [palette or dominant colors]
- Inline 1: [palette or dominant colors]
- Inline 2: [palette or dominant colors]
- Variation verdict: [sufficient/insufficient]

### Palette Variation Assessment
[Does the set have sufficient color variation? Describe the palette distribution across images]

### Individual Image Notes
[Brief assessment of each image's strengths and concerns]

### Set Cohesion
[Do the images feel like they belong to the same article while remaining visually distinct?]

### Recommendation
[Which images, if any, should be regenerated to improve variation or cohesion]
```
