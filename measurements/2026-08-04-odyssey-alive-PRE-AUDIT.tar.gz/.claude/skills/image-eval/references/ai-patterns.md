## Common AI Image Patterns

| Pattern | Example | Why It's a Tell |
|---------|---------|-----------------|
| **Symbolic abstraction** | Light beams representing ideas | Stock illustration aesthetic |
| **Split-screen contrast** | Old vs. new side by side | Requires interpretation, not immediate |
| **Metaphor stacking** | Gears + rivers + light bulbs | Conceptual overload |
| **Generic corporate** | Handshakes, puzzle pieces, targets | Clip-art energy |
| **Uncanny faces** | Distorted features, wrong finger count | Technical generation artifacts |
| **Over-rendered detail** | Every surface equally sharp | Lacks selective focus of real photography |
| **Floating elements** | Objects suspended without context | Breaks physical grounding |
| **Impossible lighting** | Light sources that contradict each other; screens emitting focused beams instead of diffused glow; lamps casting light inconsistent with their type | AI treats "glowing" as a visual effect rather than simulating how light physically propagates — screens diffuse, candles flicker, overhead lights cast downward. A laptop projecting a laser-like beam is not how screens work. |
| **Plastic skin texture** | Overly smooth, waxy human skin | Common in AI portraits |
| **Text artifacts** | Garbled letters, nonsense signage | AI struggles with legible text |
| **Symmetry obsession** | Unnaturally perfect bilateral symmetry | Real scenes have asymmetry |
| **Background blur uniformity** | Entire background at same blur level | Real depth of field varies |
| **Spatial depth violations** | Objects spanning surfaces on different planes as if flat | Posters stuck across both a wall and a recessed window, items draped over a depth change without bending — objects ignore architectural geometry they should respect |
