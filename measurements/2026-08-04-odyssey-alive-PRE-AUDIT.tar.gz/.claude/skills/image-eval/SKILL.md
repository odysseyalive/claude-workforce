---
name: image-eval
description: Evaluate images for AI generation tells and watercolor authenticity. Run as Task agent for unbiased assessment.
allowed-tools: Read, Glob, Grep, Task
minimum-effort-level: high
strictness: standard
---

# Image Evaluation Protocol

**IMPORTANT:** Run this evaluation as a **Task agent** to ensure context isolation. The agent evaluates without being influenced by the conversation that created the content.

---

## How to Invoke

Launch the image-validator agent via Task tool with `context: none`. See [references/invocation.md](references/invocation.md) for single-image and article-set templates, and [agents/image-validator/AGENT.md](agents/image-validator/AGENT.md) for evaluation criteria.

---

## When to Run

Execute this evaluation after:
- Generating images via Nano Banana
- Creating hero images for articles
- Producing inline images for content
- Any visual content creation

---

## Required Verification Steps

**Before subjective evaluation, perform these checks.** Do not skip. Do not assume images are clean. See [references/invocation.md](references/invocation.md) for signature/watermark, symmetry, and palette checks.

**Metadata provenance check (additional, mandatory for any image being considered for publish):** the image-validator agent must inspect embedded metadata via `exiftool -a -G1 -s <path>` and surface any of:

- C2PA / JUMBF manifests (`[JUMBF]` or `[CBOR]` group tags)
- Generator-name strings (`Google C2PA Core Generator Library`, `OpenAI`, `Midjourney`, `Adobe Firefly`, `Stable Diffusion`, `Flux`)
- IPTC `DigitalSourceType: trainedAlgorithmicMedia` tag
- Per-image `InstanceID` UUIDs that identify a specific generation session
- XMP `xmpMM:History` arrays that record edit chains

If any of these are present, recommend `/steganographer scrub <path>` (which shells out to `exiftool -all=`) for a clean strip. **Caveat to surface in the evaluation report:** pixel-layer invisible watermarks (Google SynthID, Adobe pixel watermark, Stable Signature) survive metadata strip — for those, only end-to-end regeneration through a non-watermarked pipeline removes the trace. Cite this honestly when the image's downstream use is provenance-sensitive.

---

## Evaluation Criteria

See references for detailed criteria:
- **[Visual Clarity](references/visual-clarity.md)** — Immediate comprehension, concrete subjects, grounded imagery
- **[Common AI Image Patterns](references/ai-patterns.md)** — Symbolic abstraction, impossible lighting, uncanny artifacts
- **[Watercolor Technique Authenticity](references/watercolor.md)** — Physical constraints, edge quality, bloom patterns
- **[Style Consistency](references/invocation.md#style-consistency)** — Watercolor aesthetic checklist
- **[Output Templates](references/templates.md)** — Single image and article set evaluation formats

Cross-reference `/image` skill for full visual clarity guidelines.

---

## Important Notes

- **Required checks come first.** Always perform signature, symmetry, and palette checks before subjective evaluation. Report findings explicitly. Do not assume or skip.
- **Advisory, not prescriptive.** Flags prompt human judgment, not automatic regeneration.
- **View in context.** An image that looks off in isolation might work perfectly with the article.
- **Specificity matters.** "Looks AI-generated" is useless. "The lighting on the left contradicts the window placement on the right" is actionable.
- **Preserve what works.** Note strengths so regeneration prompts retain successful elements.
- **One pass, then stop.** Present evaluation once. Human decides whether to regenerate.
- **Be selective.** 3-5 substantive flags maximum. Don't nitpick every detail.

---

