## Expense Categories

| Category | ID |
|----------|-----|
| Advertising And Marketing | 1117916000000000403 |
| Automobile Expense | 1117916000000000424 |
| Bank Fees and Charges | 1117916000000000409 |
| Consultant Expense | 1117916000000000454 |
| Credit Card Charges | 1117916000000000412 |
| Depreciation Expense | 1117916000000000451 |
| Gifts | 1117916000000798041 |
| Insurance | 1117916000000061100 |
| IT and Internet Expenses | 1117916000000000427 |
| Janitorial Expense | 1117916000000000433 |
| Lodging | 1117916000000032023 |
| Meals and Entertainment | 1117916000000000448 |
| Medical Expense | 1117916000001167937 |
| Nonprofit Contributions | 1117916000000082091 |
| Office Supplies | 1117916000000400 |
| ~~Other Expenses~~ | 1117916000000000460 | **NEVER USE** |
| Payroll | 1117916000001172093 |
| Postage | 1117916000000436 |
| Printing and Stationery | 1117916000000442 |
| Professional Expenses | 1117916000000061084 |
| Rent Expense | 1117916000000430 |
| Rental Equipment | 1117916000000061104 |
| Repairs and Maintenance | 1117916000000457 |
| Research and Development | 1117916000000061096 |
| Salaries and Employee Wages | 1117916000000445 |
| Software | 1117916000000061602 |
| Square Fees | 1117916000000061690 |
| Subscriptions | 1117916000000061088 |
| Telephone Expense | 1117916000000421 |
| Travel Expense | 1117916000000418 |
| ~~Uncategorized~~ | 1117916000000035005 | **NEVER USE** |
| Uniforms | 1117916000000794581 |
| Utilities | 1117916000000061092 |
