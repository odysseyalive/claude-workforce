## API Reference

All calls require `organization_id=660295414` and `Authorization: Zoho-oauthtoken $TOKEN` header.

```bash
TOKEN=$(./scripts/zoho-token.sh) && \
curl -s -H "Authorization: Zoho-oauthtoken $TOKEN" "https://www.zohoapis.com/books/v3/ENDPOINT?organization_id=660295414" | jq .
```

### Common Endpoints

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/bankaccounts` | GET | List all bank accounts |
| `/bankaccounts/{id}/transactions` | GET | Get bank transactions |
| `/banktransactions/uncategorized` | GET | List uncategorized transactions |
| `/banktransactions/{id}` | POST | Categorize a bank transaction |
| `/expenses` | GET, POST | List/create expenses |
| `/invoices` | GET | List invoices |
| `/reports/profitandloss` | GET | P&L report |
| `/reports/balancesheet` | GET | Balance sheet |

### Creating Expenses

```bash
TOKEN=$(./scripts/zoho-token.sh) && \
curl -X POST \
  -H "Authorization: Zoho-oauthtoken $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "account_id": "1117916000000061602",
    "date": "2026-01-29",
    "amount": 29.99,
    "description": "ChatGPT Plus subscription",
    "vendor_name": "OpenAI",
    "is_billable": false
  }' \
  "https://www.zohoapis.com/books/v3/expenses?organization_id=660295414"
```

### Reports

```bash
# Profit & Loss
TOKEN=$(./scripts/zoho-token.sh) && \
curl -s -H "Authorization: Zoho-oauthtoken $TOKEN" \
  "https://www.zohoapis.com/books/v3/reports/profitandloss?organization_id=660295414&from_date=2026-01-01&to_date=2026-01-31" | jq .

# Balance Sheet
TOKEN=$(./scripts/zoho-token.sh) && \
curl -s -H "Authorization: Zoho-oauthtoken $TOKEN" \
  "https://www.zohoapis.com/books/v3/reports/balancesheet?organization_id=660295414&date=2026-01-31" | jq .
```
