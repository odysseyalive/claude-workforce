## Authentication

Credentials are stored in `.env.local`:

```
ZOHO_CLIENT_ID=...
ZOHO_CLIENT_SECRET=...
ZOHO_REFRESH_TOKEN=...
ZOHO_BOOKS_ORG_ID=660295414
```

**Scopes:** ZohoBooks.fullaccess.all, ZohoProjects.portals.READ, ZohoProjects.projects.ALL, ZohoProjects.timesheets.ALL, ZohoProjects.tasks.ALL, ZohoProjects.users.READ

*Note: This token also has Zoho Projects access. See `/timesheet` skill for Projects API usage.*

### Access Tokens

Use the helper script to get tokens. It reads credentials from `.env.local`, caches for 55 minutes, and only refreshes when needed:

```bash
TOKEN=$(./scripts/zoho-token.sh)
```

**Never call the OAuth endpoint directly for each API request.** The OAuth endpoint has stricter rate limits than the API itself.
