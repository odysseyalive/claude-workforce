# Zoho Books Transaction Categorization

**Trigger phrases:** "Categorize transactions", "Categorize uncategorized", "Bank reconciliation", "Match transactions"

Rules for categorizing uncategorized bank transactions in Zoho Books.

**Pre-approved operations:** All categorization API calls are pre-approved. Do not ask for permission.

**Date confirmation required:** If the user doesn't supply the current date when working with transactions, ask for it. This helps identify sync gaps between bank feeds and API data.

---

## Core Principles

1. **Never use Uncategorized or Other Expenses** — Every expense gets a specific category
2. **Deposits stay uncategorized** — Import deposits as uncategorized; Francis categorizes income manually
3. **Always import expenses as categorized** — Never import expense transactions without a category. If unknown, ask first.
4. **Ask about unclear transactions** — When uncertain, present a list and ask before importing
5. **Checks require review** — Most are personal draw (rent, etc.), but ask about unknowns

---

## Double-Entry Bookkeeping Fundamentals

Understanding debit/credit in Zoho Books requires knowing the account type context.

### The Golden Rule

Every transaction affects **two accounts** with equal and opposite entries. When money moves, one account increases and another decreases.

### Account Types and Debit/Credit Behavior

| Account Type | Debit Effect | Credit Effect | Examples |
|-------------|--------------|---------------|----------|
| **Asset** | Increase (+) | Decrease (-) | Bank accounts, Accounts Receivable |
| **Liability** | Decrease (-) | Increase (+) | Loans, Credit Cards payable |
| **Equity** | Decrease (-) | Increase (+) | Owner's Capital, Drawings |
| **Revenue** | Decrease (-) | Increase (+) | Sales, Service Income |
| **Expense** | Increase (+) | Decrease (-) | Utilities, Subscriptions |

### Bank Account Perspective (Asset Account)

The bank account (Umpqua Business Checking) is an **asset account**. In Zoho Books:

| `debit_or_credit` value | Meaning | Money Direction | Examples |
|------------------------|---------|-----------------|----------|
| `"debit"` | Increase to bank | Money IN | Square deposits, client payments |
| `"credit"` | Decrease to bank | Money OUT | Expenses, owner draws |

### Transaction Types in Zoho Books

| Type | Direction | Use Case | How It Works |
|------|-----------|----------|--------------|
| `uncategorized` | Either | Imported, awaiting categorization | Raw bank feed data |
| `expense` | Credit (OUT) | Business expenses | Bank → Expense Account |
| `owner_drawings` | Credit (OUT) | Personal expenses | Bank → Drawings (Equity) |
| `transfer_fund` | Either | Account transfers | Bank ↔ Clearing Account |
| `sales_without_invoices` | Debit (IN) | Direct income | Revenue → Bank |

### Why Deposits Are "Debit"

This confuses many people. Here's the logic:

1. The bank account is an **asset** (something we own)
2. When money comes IN, our asset **increases**
3. Debits **increase** asset accounts
4. Therefore: Deposit = Debit to bank account

The offsetting credit goes to a revenue or clearing account (like Square Clearing).

### Existing Transaction Patterns (February 2025)

From actual Zoho data:

**Categorized Deposit (transfer from Square Clearing):**
```json
{
  "transaction_type": "transfer_fund",
  "debit_or_credit": "debit",
  "offset_account_name": "Square Clearing"
}
```

**Categorized Expense:**
```json
{
  "transaction_type": "expense",
  "debit_or_credit": "credit",
  "account_name": "Utilities"
}
```

**Categorized Owner Drawing:**
```json
{
  "transaction_type": "owner_drawings",
  "debit_or_credit": "credit",
  "to_account_name": "Drawings"
}
```

### Year-End Closing: Why It Reveals Everything

The year-end closing process is the key to understanding why debits and credits work the way they do. It shows how temporary accounts flow into permanent accounts.

#### Temporary vs. Permanent Accounts

| Type | Accounts | What Happens at Year-End |
|------|----------|--------------------------|
| **Permanent** | Assets, Liabilities, Equity (Capital) | Balances carry forward to next year |
| **Temporary** | Revenue, Expenses, Drawings | Reset to zero; balances transfer to Equity |

#### The T-Account Structure

Every account is visualized as a "T" with two sides:

```
        Account Name
    ─────────┬─────────
    DEBIT    │  CREDIT
    (Left)   │  (Right)
```

**Normal balances by account type:**
- **Left side (Debit):** Assets, Expenses, Drawings
- **Right side (Credit):** Liabilities, Equity, Revenue

An account **increases** on its normal balance side and **decreases** on the opposite side.

#### The Four Closing Entries

At year-end, temporary accounts are "closed" (zeroed out) by doing the **opposite** of their normal balance:

**1. Close Revenue → Income Summary**
```
Revenue (normally Credit)     Income Summary
─────────┬─────────          ─────────┬─────────
  DEBIT  │ balance    →              │ CREDIT
 (close) │  $XXX               $XXX  │ (receives)
```

**2. Close Expenses → Income Summary**
```
Expenses (normally Debit)     Income Summary
─────────┬─────────          ─────────┬─────────
 balance │  CREDIT     →      DEBIT  │
  $XXX   │  (close)          (receives)│
```

**3. Close Income Summary → Retained Earnings/Capital**
```
Income Summary now shows Net Income (Revenue - Expenses)
If credit balance → profit → Credit to Capital (increases equity)
If debit balance → loss → Debit to Capital (decreases equity)
```

**4. Close Drawings → Capital**
```
Drawings (normally Debit)     Owner's Capital
─────────┬─────────          ─────────┬─────────
 balance │  CREDIT     →      DEBIT  │
  $XXX   │  (close)          (reduces)│
```

#### Why This Matters for Zoho Books

Understanding the year-end process reveals why:

1. **Expenses have debit balances** — They're "left side" accounts that reduce equity when closed
2. **Revenue has credit balances** — It's a "right side" account that increases equity when closed
3. **Drawings has a debit balance** — It's a contra-equity account that reduces the owner's capital when closed

**The bank account perspective:**
- When we pay an expense: Bank (asset) is **credited** (decreases), Expense is **debited** (increases)
- When we receive income: Bank (asset) is **debited** (increases), Revenue is **credited** (increases)
- When owner takes a draw: Bank (asset) is **credited** (decreases), Drawings is **debited** (increases)

At year-end, all those expenses and drawings flow through to reduce Capital, while revenue increases it. The Drawings account in Zoho (1117916000000012001) accumulates all personal expenses throughout the year, then closes to reduce owner's equity.

#### The Accounting Equation Connection

```
Assets = Liabilities + Equity

Where Equity = Capital + Revenue - Expenses - Drawings
```

This is why:
- Revenue (credit) and Capital (credit) are on the same side — revenue increases equity
- Expenses (debit) and Drawings (debit) are on the same side — they decrease equity
- At year-end, everything collapses into the permanent Capital account

---

## Account IDs Quick Reference

### Expense Accounts
| Category | Account ID | Use For |
|----------|------------|---------|
| Advertising & Marketing | 1117916000000000403 | Facebook Ads, Darryl Davis |
| Automobile Expense | 1117916000000000424 | **NOT USED** — all auto → Personal Draw |
| Bank Fees & Charges | 1117916000000000409 | Overdraft, maintenance, intl fees |
| Gifts | 1117916000000798041 | Gift purchases |
| Insurance | 1117916000000061100 | Artisan & Truck, State Farm |
| IT and Internet Expenses | 1117916000000000427 | Internet service, web hosting, domains |
| Meals & Entertainment | 1117916000000000448 | Restaurants, bars, breweries |
| Nonprofit Contributions | 1117916000000082091 | Charitable donations (jw.org) |
| Office Supplies | 1117916000000000400 | General shopping (Amazon, eBay, Ross, Bambulab) |
| Postage | 1117916000000000436 | USPS, shipping costs |
| Professional Expenses | 1117916000000061084 | State registration, licenses |
| Research & Development | 1117916000000061096 | Education, GOG games, Ticket Tomato |
| Software | 1117916000000061602 | Claude/Anthropic, Hetzner, dev tools |
| Square Fees | 1117916000000061690 | Square processing fees |
| Subscriptions | 1117916000000061088 | SaaS, streaming, memberships |
| Utilities | 1117916000000061092 | Spectrum, Tillamook PUD, City of Rockaway |

### Equity Account (Owner's Draw)
| Category | Account ID | Use For |
|----------|------------|---------|
| Drawings | 1117916000000012001 | Personal expenses incl. groceries, gas (see below) |

### Bank Account
| Account | Account ID | Use For |
|---------|------------|---------|
| Umpqua Business Checking | 1117916000002695020 | Primary business bank account |

### CRITICAL: Transaction Type Selection

**Personal items (groceries, gas, pets, etc.) must use `owner_drawings` transaction type, NOT `expense`.**

| Item Type | Transaction Type | Endpoint | Account IDs |
|-----------|-----------------|----------|-------------|
| Personal Draw | `owner_drawings` | POST `/banktransactions` | from: 1117916000002695020, to: 1117916000000012001 |
| Business Expense | `expense` | POST `/expenses` | account_id: (expense account), paid_through: 1117916000002695020 |

**Never create personal items as expenses** — they will end up in Uncategorized or wrong accounts.

---

## Personal Draw (Drawings Account)

The following categories go to **Drawings** (1117916000000012001):

### Groceries
Fred Meyer, Center Market, Tillamook Grocery Outlet, Safeway, Dollar General, Tillamook Meat, Natural Grocers, Garibaldi Deli Mart, South Prairie Market, Trader Joe's, Tillamook Co-op

### Pets & Vet
Chewy, Four Paws, Nehalem Animal Healing

### Auto Loan Payments
Columbia Credit Union (ACI*COLUMBIA CREDIT UN)

### Gas & Auto (all vehicle expenses)
Chevron, Shell, Carson Oil, any gas station, Garibaldi Car Wash, car washes, Carr Subaru Service, auto repairs, auto service, parking

### Personal Shopping
Goorin Bros, Goodwill, clothing stores, personal items

### Hobbies (except GOG)
Tillamook Sporting Goods, RockinRonsMusic, record stores (Rough Trade, Lonely Crab), antique stores, Rosenberg Builders

### PayPal (most cases)
PayPal transactions are usually personal unless clearly business-related

### Checks
Most checks are personal draw (e.g., $2,300 = rent). For unknown check amounts, ask Francis.

---

## Business Expense Mappings

### Subscriptions (1117916000000061088)
Apple.com/Bill, Patreon, YouTube, YouTube Premium, Amazon Prime, Rocket Money, Zoom, GitHub, SkySlope, Cloudflare, HP Instant Ink, McEvoy Atelier, DigiSigner, BoardGameGeek, LinkedIn, Mailchimp, Google One, Google Workspace, Squarespace, NATE AI News, Pipecottage, OpenAI/ChatGPT, Internet Archive, X Corp/Twitter, Codeium

### Software (1117916000000061602)
Claude/Anthropic, Hetzner Online, FMG*ADDINS, Zoho

### Advertising & Marketing (1117916000000000403)
Facebook/Meta Ads, Darryl Davis Seminars

### Insurance (1117916000000061100)
Artisan & Truck Ins, State Farm

### Utilities (1117916000000061092)
Spectrum (all), Tillamook PUD, City of Rockaway Beach (water/sewer)

### Automobile Expense (1117916000000000424)
**NOT USED** — All vehicle expenses (gas, service, parking) go to Personal Draw

### Meals & Entertainment (1117916000000000448)
Pelican Brewing, Fish Peddler, Urban German, McMenamins, Matt's BBQ, Five Rivers Coffee, Offshore Grill, Bahama Mama's, Tie Breaker, Prost, Corral Grill, Sarasota's, Wild Manzanita, OR Liquor Store, Bay City Kitchen, Tillamook County Cream, Fort George Brewer, Lindsey's Lattes, Taqueria Mendez, Columbia River Maritime

### Equipment Rental (1117916000000061104)
Bay Ocean Boys, Starlink Internet

### Nonprofit Contributions (1117916000000082091)
Donate.jw.org, any charitable donation

### Bank Fees & Charges (1117916000000000409)
Overdraft Fee, Maintenance Fee, SVC CHG INTRNTL TRAN, EFT Service Charge

### Research & Development (1117916000000061096)
Lane Enrollment (kids education), GOG games (game research)

### Office Supplies (1117916000000000400)
Amazon (non-Prime general purchases), eBay, Ross Stores, Bandcamp, Kofi, Tillamook Electronics

### Gifts (1117916000000798041)
Lilyroot Clover, gift shops when purchasing gifts

### Professional Expenses (1117916000000061084)
OR SEC STATE (state registration/licensing), Jenny Bocko Photography

---

## Deposit Handling

**All deposits remain uncategorized.** Francis categorizes income manually because:
- Income requires matching to invoices or projects
- Square/Stripe deposits need reconciliation with clearing accounts
- Some deposits are refunds, not income

### Deposit Sources (all uncategorized)
- **Square Inc** — Client payments via Square
- **Stripe Transfer** — Online payments
- **Universal Credit Square** — Square Capital advances
- **ACH Credits** — Direct deposits, refunds

### How Deposits Appear in Zoho

Uncategorized deposits from bank feed:
```json
{
  "transaction_type": "uncategorized",
  "status": "uncategorized",
  "debit_or_credit": "debit",
  "description": "PREAUTHORIZED ACH CREDIT Square Inc..."
}
```

After Francis categorizes (typically as transfer from clearing):
```json
{
  "transaction_type": "transfer_fund",
  "debit_or_credit": "debit",
  "offset_account_name": "Square Clearing"
}
```

### Importing Deposits from Bank Statements

When importing from PDF bank statements, deposits should be imported as uncategorized bank transactions. The bank feed import handles this automatically, but for manual statement imports:

1. **Do not create expenses or categorized transactions for deposits**
2. **Do not use `sales_without_invoices`** — that auto-categorizes as income
3. **Leave deposits for Francis** — note them in the import summary but don't process them

---

## Categorization Workflow

**CRITICAL: Test First Strategy**
Before running bulk operations on Zoho or YNAB:
1. **Test ONE transaction first** — verify the API call works
2. **Fix any errors** — debug until it succeeds
3. **Only then proceed with batches** — to avoid burning rate limits on errors

### Steps

1. **Query uncategorized transactions** from the target bank account
2. **Separate deposits from expenses** — deposits (debit) stay uncategorized, expenses (credit) get categorized
3. **Group expenses by payee/merchant** to batch similar transactions
4. **Test one categorization** — verify API format works
5. **Match against mappings above** — categorize known merchants
6. **Flag unknowns for review** — present a list of unclear transactions
7. **Present check list** — for CHECK PAID entries, ask about unknown amounts
8. **Summarize deposits** — list deposits for Francis to categorize manually

### API: Categorize as Expense

For expense accounts (Utilities, Subscriptions, Software, etc.):

```bash
TOKEN=$(./scripts/zoho-token.sh)
curl -s -X POST \
  "https://www.zohoapis.com/books/v3/banktransactions/uncategorized/$TXN_ID/categorize/expenses?organization_id=660295414" \
  -H "Authorization: Zoho-oauthtoken $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "account_id": "EXPENSE_ACCOUNT_ID",
    "amount": 100.00,
    "date": "2026-01-16",
    "paid_through_account_id": "1117916000002695020"
  }'
```

**Required fields:**
- `account_id` — The expense account ID
- `amount` — Transaction amount
- `date` — Transaction date (YYYY-MM-DD)
- `paid_through_account_id` — The bank account ID (Umpqua: 1117916000002695020)

### API: Categorize as Owner Drawings

For personal/owner draw transactions (groceries, pets, auto loan, etc.):

```bash
TOKEN=$(./scripts/zoho-token.sh)
curl -s -X POST \
  "https://www.zohoapis.com/books/v3/banktransactions/uncategorized/$TXN_ID/categorize?organization_id=660295414" \
  -H "Authorization: Zoho-oauthtoken $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "transaction_type": "owner_drawings",
    "from_account_id": "1117916000002695020",
    "to_account_id": "1117916000000012001",
    "amount": 100.00,
    "date": "2026-01-16"
  }'
```

**Required fields:**
- `transaction_type` — Must be "owner_drawings"
- `from_account_id` — The bank account (Umpqua: 1117916000002695020)
- `to_account_id` — The Drawings equity account (1117916000000012001)
- `amount` — Transaction amount
- `date` — Transaction date (YYYY-MM-DD)

### API: Match to Existing Expense

If matching to an existing expense record:
```bash
curl -s -X POST "https://www.zohoapis.com/books/v3/banktransactions/uncategorized/match?organization_id=660295414" \
  -H "Authorization: Zoho-oauthtoken $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"transaction_id":"BANK_TXN_ID","transactions":[{"transaction_id":"EXPENSE_ID","transaction_type":"expense"}]}'
```

---

## Bank Statement Import Workflow

When importing transactions from PDF bank statements (not from bank feed):

### Pre-Import Checks

1. **Check for existing transactions** — Query Zoho for the date range to avoid duplicates
2. **Parse the PDF** — Extract date, amount, and description for each transaction
3. **Identify deposits vs expenses** — Deposits show as credits on statement (money IN), expenses as debits (money OUT)

### Import Strategy

**For Expenses (withdrawals):**
- Create directly as categorized expenses or owner drawings
- Use POST `/expenses` for business expenses
- Use POST `/banktransactions` with `transaction_type: "owner_drawings"` for personal draws

**For Deposits:**
- **Do not import deposits via API** — The bank feed handles these automatically
- If bank feed is not connected, note the deposits for Francis to enter manually
- Deposits require matching to invoices/clearing accounts which is done by hand

### API: Create Expense (from statement import)

```bash
TOKEN=$(./scripts/zoho-token.sh)
curl -s -X POST "https://www.zohoapis.com/books/v3/expenses?organization_id=660295414" \
  -H "Authorization: Zoho-oauthtoken $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "account_id": "EXPENSE_ACCOUNT_ID",
    "date": "2025-03-03",
    "amount": 5.50,
    "paid_through_account_id": "1117916000002695020",
    "description": "Patreon Membership"
  }'
```

### API: Create Owner Drawing (from statement import)

```bash
TOKEN=$(./scripts/zoho-token.sh)
curl -s -X POST "https://www.zohoapis.com/books/v3/banktransactions?organization_id=660295414" \
  -H "Authorization: Zoho-oauthtoken $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "transaction_type": "owner_drawings",
    "from_account_id": "1117916000002695020",
    "to_account_id": "1117916000000012001",
    "amount": 12.09,
    "date": "2025-03-03",
    "description": "Fred Meyer"
  }'
```

### Import Summary Template

After importing, provide a summary:

```
## Import Summary: [Month Year]

### Expenses Imported
| Date | Payee | Amount | Category |
|------|-------|--------|----------|
| ... | ... | ... | ... |

### Owner Draws Imported
| Date | Payee | Amount |
|------|-------|--------|
| ... | ... | ... |

### Deposits (for manual entry)
| Date | Description | Amount |
|------|-------------|--------|
| ... | ... | ... |

### Skipped (already in Zoho)
| Date | Description | Amount |
|------|-------------|--------|
| ... | ... | ... |
```

---

## When to Ask

Always ask Francis about:
- Checks with unknown purposes (provide amount and date)
- PayPal transactions that might be business-related
- New merchants not in the mappings
- Any transaction over $500 that doesn't clearly fit a category
- Deposits (skip or ask, never auto-categorize)

---

## Notes

- **Drawings is an equity account**, not expense — it reduces owner's equity
- **Ticket Tomato transactions** are usually internal business operations — ask if unclear
- **Apple Cash Sent** is personal draw
- **LILYROOT CLOVER** is a gift shop — goes to Gifts
