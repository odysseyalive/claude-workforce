## Agent Invocation Patterns

### ID Lookup Agent

**Purpose:** Look up account IDs from reference files, enforce FORBIDDEN categories.

**Invocation:**
```
Task tool with:
  subagent_type: "general-purpose"
  prompt: "Read .claude/skills/zoho/agents/id-lookup/AGENT.md for instructions,
          then look up [description] in the references/ files under .claude/skills/zoho/references/.
          Return only the ID and its context. If not found, say NOT FOUND."
```

**Example:**
```
prompt: "Read .claude/skills/zoho/agents/id-lookup/AGENT.md for instructions,
        then look up 'Software expense category' in .claude/skills/zoho/references/expense-categories.md.
        Return only the ID and its context. If not found, say NOT FOUND."
```

**Response format:**
```
FOUND: Software (1117916000000061602)
Category: Expense Categories
```

**For FORBIDDEN categories:**
```
FORBIDDEN: Uncategorized (1117916000000035005) is a prohibited category.
You must ask the user for a specific category instead.
```

**Why use the agent?** The agent has `context: none` and cannot use memory. It also enforces the FORBIDDEN categories rule, providing an additional safety layer beyond the hook.

See [agents/id-lookup/AGENT.md](../agents/id-lookup/AGENT.md) for full agent details.

### Payee Matcher Agent

**Purpose:** Match payees to categories using mappings from categorization.md, flag Personal Draw transactions for user confirmation.

**Invocation:**
```
Task tool with:
  subagent_type: "general-purpose"
  prompt: "Read .claude/skills/zoho/agents/payee-matcher/AGENT.md for instructions,
          then match these payees: [list of payees with amounts and descriptions]
          Return category matches with confidence levels."
```

**Example:**
```
prompt: "Read .claude/skills/zoho/agents/payee-matcher/AGENT.md for instructions,
        then match these payees:
        - AWS ($127.43, 'Amazon Web Services')
        - Starbucks ($8.50, 'Coffee')
        - Francis Bresnahan ($500.00, 'Personal transfer')
        Return category matches with confidence levels."
```

**Response format:**
```
MATCHES:
1. AWS ($127.43) → IT and Internet Expenses (1117916000000000427) [HIGH confidence]
2. Starbucks ($8.50) → Meals and Entertainment (1117916000000000448) [MEDIUM confidence]

DRAWINGS REQUIRING CONFIRMATION:
3. Francis Bresnahan ($500.00) → Drawings (1117916000000012001) [HIGH confidence]
   ⚠️ Personal Draw - requires user confirmation per directive
```

The agent will:
- Match payees to categories using mappings in categorization.md
- Flag Personal Draw matches for user confirmation (per directive)
- Return confidence levels (HIGH, MEDIUM, LOW)
- Handle uncertain matches

See [agents/payee-matcher/AGENT.md](../agents/payee-matcher/AGENT.md) for full agent details.
