## Bank Reconciliation Workflow

1. **Get uncategorized transactions:**
   ```bash
   TOKEN=$(./scripts/zoho-token.sh) && \
   curl -s -H "Authorization: Zoho-oauthtoken $TOKEN" \
     "https://www.zohoapis.com/books/v3/banktransactions/uncategorized?organization_id=660295414" | jq .
   ```

2. **Use Payee Matcher agent** to categorize transactions (see [Payee Matcher Agent](agents.md#payee-matcher-agent) above)

3. **Present Drawings transactions to user for confirmation** (per directive)

4. **Categorize each transaction:**
   ```bash
   TOKEN=$(./scripts/zoho-token.sh) && \
   curl -X POST \
     -H "Authorization: Zoho-oauthtoken $TOKEN" \
     -H "Content-Type: application/json" \
     -d '{
       "transaction_type": "expense",
       "account_id": "1117916000000061602",
       "description": "ChatGPT Plus"
     }' \
     "https://www.zohoapis.com/books/v3/banktransactions/{transaction_id}?organization_id=660295414"
   ```

5. **For Personal Draws** (after user confirmation):
   ```bash
   curl -X POST \
     -H "Authorization: Zoho-oauthtoken $TOKEN" \
     -H "Content-Type: application/json" \
     -d '{
       "transaction_type": "transfer_fund",
       "to_account_id": "1117916000000012001"
     }' \
     "https://www.zohoapis.com/books/v3/banktransactions/{transaction_id}?organization_id=660295414"
   ```

See [categorization.md](../categorization.md) for:
- Complete payee-to-category mappings (100+ merchants)
- Double-entry bookkeeping reference
- Bank statement import examples

---

## Notes

- All monetary amounts are in USD
- Dates use ISO format: `YYYY-MM-DD`
- The refresh token is long-lived but should be stored securely
- Access tokens expire after 3600 seconds (1 hour)
- Always include `organization_id=660295414` in query parameters
