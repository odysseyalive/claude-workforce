## Bank Accounts

| Account | ID | Type |
|---------|-----|------|
| Umpqua Business Checking | 1117916000002695020 | bank |
| BridgeSense Checking | 1117916000000957018 | bank |
| Business Credit Card - 6184 | 1117916000000957027 | credit_card |
| Business Credit Card - 7537 | 1117916000000177590 | credit_card |
| Square Clearing | 1117916000000061702 | payment_clearing |
| Stripe Clearing | 1117916000002695007 | payment_clearing |
| SBA Disaster Relief Loan | 1117916000001619245 | credit_card |
| Petty Cash | 1117916000000000361 | cash |

---

## Equity Accounts

| Account | ID | Notes |
|---------|-----|-------|
| Drawings | 1117916000000012001 | Owner's draws - use `transfer_fund` transaction type |
| Owner's Contributions | 1117916000000065382 | Capital contributions |
| Owner's Equity | 1117916000000000382 | Main equity account |
| Retained Earnings | 1117916000000000379 | Accumulated profits |
