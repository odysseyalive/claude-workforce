## Rate Limits

### Per-Minute Limit
- **100 requests per minute** per organization (all plans)
- Error code **44** when exceeded

### Daily Limits by Plan
| Plan | Daily Limit |
|------|-------------|
| Free | 1,000 |
| Standard | 2,000 |
| Professional | 5,000 |
| Premium/Elite/Ultimate | 10,000 |

- Error code **45** when exceeded
- Resets at midnight in the organization's timezone

### Concurrent Limits
- **5 concurrent calls** (Free plan)
- **10 concurrent calls** (Paid plans, soft limit)
- Error code **1070** when exceeded

**For bulk operations:** Add 1 second delay between calls to stay under the per-minute limit. Never fire hundreds of requests without pacing.

**Reference:** [Zoho Books API Introduction](https://www.zoho.com/books/api/v3/introduction/)
