#!/bin/bash
# Hook: Validate date parameters in Zoho API curl commands
# Catches: start > end, dates far in future, invalid formats
CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR

INPUT=$(cat 2>/dev/null) || exit 0

COMMAND=$(echo "$INPUT" | grep -oP '"command"\s*:\s*"[^"]*"' | head -1 | sed 's/.*"command"\s*:\s*"//;s/"$//')

# Only check curl commands targeting Zoho API
if ! echo "$COMMAND" | grep -q 'api.zoho.com\|zoho.*books'; then
  exit 0
fi

# Extract date parameters (YYYY-MM-DD format)
DATES=$(echo "$COMMAND" | grep -oP '\d{4}-\d{2}-\d{2}' | sort -u)

if [ -z "$DATES" ]; then
  exit 0
fi

# Validate each date
TODAY=$(date +%Y-%m-%d)
TODAY_EPOCH=$(date -d "$TODAY" +%s 2>/dev/null)

while IFS= read -r d; do
  # Check valid date format
  if ! date -d "$d" +%s >/dev/null 2>&1; then
    echo "BLOCKED: Invalid date format in Zoho API call: $d" >&2
    exit 2
  fi

  D_EPOCH=$(date -d "$d" +%s 2>/dev/null)

  # Warn if date is more than 1 year in the future
  FUTURE_LIMIT=$(date -d "+365 days" +%s 2>/dev/null)
  if [ "$D_EPOCH" -gt "$FUTURE_LIMIT" ] 2>/dev/null; then
    echo "BLOCKED: Zoho API date $d is more than 1 year in the future. Verify this is intentional." >&2
    exit 2
  fi
done <<< "$DATES"

# If there are exactly 2 dates, check start < end
DATE_COUNT=$(echo "$DATES" | wc -l)
if [ "$DATE_COUNT" -eq 2 ]; then
  START=$(echo "$DATES" | head -1)
  END=$(echo "$DATES" | tail -1)
  START_EPOCH=$(date -d "$START" +%s 2>/dev/null)
  END_EPOCH=$(date -d "$END" +%s 2>/dev/null)
  if [ "$START_EPOCH" -gt "$END_EPOCH" ] 2>/dev/null; then
    echo "BLOCKED: Zoho API date range is inverted: start=$START > end=$END" >&2
    exit 2
  fi
fi

exit 0
