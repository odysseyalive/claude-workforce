#!/bin/bash
# Hook: Block account creation in Chart of Accounts per /zoho directive
# NEVER create new accounts via API
CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR

INPUT=$(cat 2>/dev/null) || exit 0

if echo "$INPUT" | grep -q 'chartofaccounts' 2>/dev/null && echo "$INPUT" | grep -qiE '(POST|"method"\s*:\s*"post")' 2>/dev/null; then
  echo "BLOCKED: Creating accounts in Chart of Accounts is forbidden per /zoho directive. Use existing accounts only." >&2
  exit 2
fi
exit 0
