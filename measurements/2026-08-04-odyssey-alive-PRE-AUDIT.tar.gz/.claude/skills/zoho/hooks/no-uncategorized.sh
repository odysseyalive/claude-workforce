#!/bin/bash
# Hook: Block Uncategorized/Other Expenses, Warn about Drawings
# Purpose: Enforce Zoho directives:
#   - BLOCK: "NEVER assign to Uncategorized or Other Expenses"
#   - WARN: "Confirm Personal Draw transactions before applying"
#
# Exit codes:
#   0 = Allow (possibly with warning)
#   2 = Block (forbidden ID detected)

CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR

# Forbidden account IDs (BLOCK)
UNCATEGORIZED="1117916000000035005"
OTHER_EXPENSES="1117916000000000460"

# Requires confirmation (WARN)
DRAWINGS="1117916000000012001"

# Read the tool input from stdin
INPUT=$(cat 2>/dev/null) || exit 0

# Check for forbidden IDs - BLOCK
if echo "$INPUT" | grep -qE "$UNCATEGORIZED|$OTHER_EXPENSES" 2>/dev/null; then
  echo "BLOCKED: Uncategorized ($UNCATEGORIZED) and Other Expenses ($OTHER_EXPENSES) accounts are forbidden." >&2
  echo "Per user directive: Every transaction must go to a specific, meaningful expense category." >&2
  echo "If the transaction doesn't match a known category, stop and ask the user which category to use." >&2
  exit 2
fi

# Check for Drawings - WARN (don't block, but remind)
if echo "$INPUT" | grep -q "$DRAWINGS" 2>/dev/null; then
  echo "⚠️  REMINDER: Drawings account detected." >&2
  echo "Per user directive: Confirm Personal Draw transactions with user before applying." >&2
  echo "Ensure user has reviewed and approved this Drawings transfer." >&2
  # Exit 0 to allow, but warning is logged
fi

exit 0
