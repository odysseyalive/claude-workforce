# Zoho Books Cleanup Plan

Created: 2026-01-22

## Problem Summary

168 transactions from June-August 2025 were incorrectly created as "expenses" with "Uncategorized" account instead of as "owner_drawings" (Personal Draw) transactions.

| Month | Uncategorized Expenses |
|-------|----------------------|
| June 2025 | 47 |
| July 2025 | 59 |
| August 2025 | 62 |
| **Total** | **168** |

Additionally, September 2025 import is incomplete (Personal Draw transactions done, business expenses not yet imported).

## Root Cause

The skill file `categorization.md` had incorrect account IDs that didn't match actual Zoho accounts.

## Correct Account IDs (from Zoho)

```
1117916000000000403 | Advertising And Marketing
1117916000000000409 | Bank Fees and Charges
1117916000000061100 | Insurance
1117916000000000427 | IT and Internet Expenses
1117916000000000448 | Meals and Entertainment
1117916000000000400 | Office Supplies
1117916000000000436 | Postage
1117916000000061088 | Subscriptions
1117916000000061092 | Utilities
1117916000000061690 | Square Fees
```

## Cleanup Steps

### Day 1: June 2025 Cleanup

1. **Export uncategorized expenses** (for reference)
   ```bash
   TOKEN=$(./scripts/zoho-token.sh)
   curl -s "https://www.zohoapis.com/books/v3/expenses?organization_id=660295414&date_start=2025-06-01&date_end=2025-06-30&per_page=100" \
     -H "Authorization: Zoho-oauthtoken $TOKEN" | jq '.expenses[] | select(.account_name == "Uncategorized")' > /tmp/june-uncategorized.json
   ```

2. **Delete 47 uncategorized expenses**
   - Extract expense IDs and delete each one
   - ~47 DELETE calls

3. **Recreate as owner_drawings transactions**
   - All these are Personal Draw (groceries, gas, pet supplies, games)
   - ~47 POST calls to banktransactions endpoint
   - Use transaction_type: "owner_drawings"

4. **Verify June totals match statement**

### Day 2: July 2025 Cleanup

Same process for 59 items.

### Day 3: August 2025 Cleanup

Same process for 62 items.

### Day 4: September 2025 Completion

1. Import remaining business expenses with CORRECT account IDs:
   - IT and Internet: 1117916000000000427
   - Advertising: 1117916000000000403
   - Utilities: 1117916000000061092
   - Insurance: 1117916000000061100
   - Meals & Entertainment: 1117916000000000448
   - Subscriptions: 1117916000000061088
   - Office Supplies: 1117916000000000400
   - Postage: 1117916000000000436
   - Bank Fees: 1117916000000000409

2. Verify September totals match statement ($6,247.86 deposits, $6,438.47 withdrawals)

### Day 5: October 2025 Import

Import October statement if exists.

## Skill File Update Required

Update `.claude/skills/zoho/categorization.md` with correct account IDs before proceeding.

## API Call Estimates

- June: ~94 calls (47 delete + 47 create)
- July: ~118 calls (59 delete + 59 create)
- August: ~124 calls (62 delete + 62 create)
- September business expenses: ~30 calls
- October import: ~100+ calls

Total: ~466 calls spread across multiple days to stay under 1000/day limit.

## Verification

After each month's cleanup, verify:
1. No uncategorized expenses remain for that month
2. Bank transaction totals match statement totals
3. All Personal Draw items show in Drawings account

## Status

- [x] Update skill file with correct account IDs (2026-01-22)
- [ ] June 2025 cleanup (47 items)
- [ ] July 2025 cleanup (59 items)
- [ ] August 2025 cleanup (62 items)
- [ ] September 2025 completion
- [ ] October 2025 import (if statement exists)
