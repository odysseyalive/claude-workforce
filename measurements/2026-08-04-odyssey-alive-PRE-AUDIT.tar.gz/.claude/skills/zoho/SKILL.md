---
name: zoho
description: Zoho Books API integration for bookkeeping, bank reconciliation, expenses, and reporting.
allowed-tools: Read, Glob, Grep, Bash, Task
minimum-effort-level: high
strictness: standard
---

# Zoho Books Integration

**Trigger phrases:** "Zoho Books", "Bookkeeping", "Reconcile bank", "Log expense", "Financial report", "Invoice status", "Zoho"

Rules for connecting to Odyssey Alive's Zoho Books account via the API.

---

<!-- origin: user | added: 2026-01-15 | immutable: true -->
## Directives

> **Date confirmation required:** If the user doesn't supply the current date when querying transactions, ask for it. This helps identify potential sync gaps between bank feeds and API data.

*— Added 2026-01-15, source: user instruction*

### ⚠️ CRITICAL: Never Use Generic or Uncategorized Accounts

> **NEVER assign a transaction or expense to:**
> - Uncategorized (1117916000000035005)
> - Other Expenses (1117916000000000460)
> - Any catch-all or generic account
>
> **Every transaction must go to a specific, meaningful expense category.**
>
> If a transaction doesn't clearly match a known category:
> 1. **Stop immediately**
> 2. Present the transaction details (date, amount, description, payee)
> 3. **Ask the user** which specific account to use
> 4. Wait for explicit confirmation before proceeding
> 5. Never guess or use a fallback account
>
> This applies to:
> - Creating expenses via POST `/expenses`
> - Categorizing bank transactions
> - Any bulk import operations
> - Any automated or batch processing
>
> When in doubt, ask. A transaction sitting uncategorized in your queue is better than a transaction mis-categorized in the books.

*— Added 2026-01-15, source: user instruction. Enforced via hook.*

### ⚠️ CRITICAL: Never Create Accounts in Zoho

> **NEVER create new accounts in Zoho's Chart of Accounts via the API.**
>
> - Only use accounts that already exist in Zoho
> - If a transaction doesn't fit an existing account, **ask the user** which account to use
> - You MAY update the references/ files to document existing Zoho accounts
> - You may NOT use the API to create, modify, or delete accounts in Zoho
>
> If you're unsure which account applies, present the transaction and ask.

*— Added 2026-01-15, source: user instruction*

### ⚠️ Confirm Personal Draws Before Applying

> **When categorizing uncategorized transactions, always confirm Personal Draw (Drawings) transactions with the user before applying them.**
>
> Before processing any transaction as a Drawings transfer:
> 1. Present the list of proposed Drawings transactions (date, amount, vendor)
> 2. Wait for explicit user confirmation
> 3. Only then proceed with creating the transfers
>
> This prevents personal expenses from being mis-categorized without user review.

*— Added 2026-01-23, source: user instruction*
<!-- /origin -->

---

## Workflows

All workflows require:
1. **ID lookup** via agent (see [references/agents.md](references/agents.md))
2. **Token retrieval** via `./scripts/zoho-token.sh` (see [references/authentication.md](references/authentication.md))
3. **API calls** with proper headers (see [references/api.md](references/api.md))

| Task | Endpoints | Details |
|------|-----------|---------|
| Bank reconciliation | GET `/bankaccounts/{id}/transactions`, GET `/banktransactions/uncategorized`, POST `/banktransactions/{id}` | [references/reconciliation.md](references/reconciliation.md) |
| Log expense | POST `/expenses` | [references/api.md § Creating Expenses](references/api.md#creating-expenses) |
| Financial reports | GET `/reports/profitandloss`, GET `/reports/balancesheet` | [references/api.md § Reports](references/api.md#reports) |
| List invoices | GET `/invoices` | [references/api.md](references/api.md) |

**Payee matching:** Use Payee Matcher agent (see [references/agents.md § Payee Matcher Agent](references/agents.md#payee-matcher-agent)) with mappings from [references/categorization.md](references/categorization.md).

---

## Grounding (Enforced via Agent)

Before using any account or category ID, spawn the ID Lookup agent (see [agents/id-lookup/AGENT.md](agents/id-lookup/AGENT.md)) with the account/category description. Only proceed if it returns FOUND with a valid ID. The agent returns FORBIDDEN for Uncategorized or Other Expenses.

**References:** [accounts.md](references/accounts.md) · [expense-categories.md](references/expense-categories.md) · [authentication.md](references/authentication.md) · [api.md](references/api.md) · [rate-limits.md](references/rate-limits.md) · [reconciliation.md](references/reconciliation.md) · [categorization.md](references/categorization.md) · [agents.md](references/agents.md)

---

**Organization ID:** `660295414` (required on all API calls)

---

## Post-Action Capture

After resolving categorization decisions, reconciliation choices, or account mapping questions, suggest recording the decision in the awareness ledger (DEC record) so it persists across sessions. Never auto-record — ask the user first.

