#!/bin/bash
# Validate Zoho API calls use correct organization_id
#
# This hook blocks Bash commands that call Zoho APIs with the wrong org ID.
# The only valid organization_id is 660295414.

CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR

INPUT=$(cat 2>/dev/null) || exit 0

# Extract the command from the JSON input
COMMAND=$(echo "$INPUT" | jq -r '.tool_input.command // empty')

# Check if this is a Zoho API call
if echo "$COMMAND" | grep -q "zohoapis.com"; then
  # Check for correct org ID
  if ! echo "$COMMAND" | grep -q "organization_id=660295414"; then
    echo "BLOCKED: Zoho API call must use organization_id=660295414" >&2
    echo "Found command: $COMMAND" >&2
    exit 2
  fi
fi

exit 0
