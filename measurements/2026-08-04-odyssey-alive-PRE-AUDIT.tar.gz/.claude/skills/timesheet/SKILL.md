---
name: timesheet
description: "Bidirectional sync of tasks and time between org-mode and Zoho Books. Modes: push, pull, sync, status, log. Usage: /timesheet [mode] [args]"
allowed-tools: Read, Glob, Grep, Edit, Bash, Task
minimum-effort-level: high
strictness: standard
---

# Timesheet Sync: Org-mode ⇄ Zoho Books

**Trigger phrases:** "Transfer timesheet", "Log time to Zoho", "Submit hours", "Time entry for", "Timesheet for", "Sync timesheet", "Pull from Zoho", "Sync time", "Sync tasks", "Log time to", "Add time to", "Log <duration> to <task>", "I just spent <duration> on"

Two-way sync of project **tasks** and **tracked time** between nvim-orgmode files and Zoho Books. The org→Zoho direction (push) is the original, unchanged transfer; pull and sync add the reverse and the reconcile.

## Modes

| Mode | Command | Description |
|------|---------|-------------|
| `push` | `/timesheet push [window]` (default; also "Transfer timesheet for [date]") | Org → Zoho, **status-agnostic** (TODO **and** DONE): CLOCK time → Zoho time entries; any windowed headline missing in Zoho → Zoho task (a TODO with no clock yet syncs as a **name-only** task). One leg of the windowed reconcile. |
| `pull` | `/timesheet pull [window]` | Zoho → org, **scoped to tasks with activity in the window**: such tasks with no org counterpart become `** TODO` headlines (always TODO) and their time becomes closed CLOCK lines, **within existing org files only**. |
| `sync` | `/timesheet sync [window]` | Full **windowed reconcile** both directions over the [Activity Window](#activity-window-the-2-week-reconcile-scope) (default **14 days**) per [references/sync-model.md](references/sync-model.md). |
| `status` | `/timesheet status [window]` | Read-only **preview of exactly what `sync` would do** over the window — Zoho↔org time drift, name-only TODOs not yet in Zoho, link health — then offers to continue into `sync`. Writes nothing. |
| `log` | `/timesheet log <task> <duration> [--project <name>]` | Quick-log a just-finished block: discover/confirm the matching task (or create it), build a CLOCK ending **now** and starting `now − duration`, and write it to **both** the org file and Zoho in one shot. |

A bare "Transfer timesheet for [DATE]" stays the `push` mode for backward compatibility.

---

<!-- origin: user | added: 2026-02-03 | immutable: true -->
## Directives

> **Pre-approved operations:** All Zoho Books API calls (time entries, tasks, projects) and org file scanning are pre-approved. Do not ask for permission to run these queries.

> **Organization ID:** All Zoho API calls MUST use `organization_id=660295414`. This is the ONLY valid organization ID. Never use any other value.
> *(Enforced by hook: `hooks/validate-org-id.sh` — blocks Bash commands with wrong org ID)*

> **Include micro time, skip true zeroes:** Skip entries showing exactly 0:00, but always include micro time entries like 0:02 or 0:05. Never ask whether to skip short entries — if it's greater than zero, it gets transferred.

*— Added 2026-02-03, source: user instruction*
<!-- /origin -->

<!-- origin: user | added: 2026-06-26 | immutable: true -->

> **Check `AGENDA_SOURCE` before accessing org files.** Before touching any org file, read `AGENDA_SOURCE` from `.env.local` and resolve the org directory from it: `local` (or unset) → the local org directory; `server` → the synced server org directory (`ORG_DIR`, kept in sync with Google Drive). Any other value → stop.

*— Added 2026-06-26, source: user instruction (via /route → /skill-builder inline; local/server source switch). Reworded 2026-06-26 to wire the `server` source — deliberate checksum override, user-approved.*
<!-- /origin -->

<!-- origin: user | added: 2026-06-24 | immutable: true -->
### Bidirectional Sync Directives

> **Sync project tasks and time back-and-forth between Zoho and Org — make it run both ways.** This is the same sync we already have one way; pull and sync are the reverse and the reconcile.

> **Only work within the confines of existing org files.** Pull and sync never create new org *files*. A Zoho project with no org file is out of scope. Tasks and time land only inside org files that already exist.

> **Only time and tasks are synced both ways.** Nothing else (no deadlines, no prose, no body notes) crosses between Zoho and Org through this skill.

> **The project index updates as new projects and clients sync.** When sync sees a Zoho project that maps to an existing org file but is missing from `references/project-mapping.md`, it adds the row so the index stays current.

> **Store the Zoho IDs in the org files.** Each synced task headline carries its Zoho IDs in a `:PROPERTIES:` drawer so matching is deterministic and the sync is self-recoverable if the local state cache is lost. Storing IDs is additive metadata — it never touches, edits, or reduces any `CLOCK:` line (the time-data preservation directive and the `triage-write-guard.sh` rails still hold).

> **Run automatically.** Sync does not stop to confirm each additive write. Correctness comes from stable IDs, reconcile-before-post, and real Zoho timestamps — not from per-item prompts. The MANDATORY task-matching checkpoint still governs task *creation* (never silently create a duplicate task), and the org-ID and micro-time directives above are unchanged.

*— Added 2026-06-24, source: user instruction (via /route → /skill-builder; bidirectional-sync build session). Org-provenance and full-auto posture ratified via AskUserQuestion the same day.*
<!-- /origin -->

<!-- origin: user | added: 2026-06-24 | immutable: true -->
### Windowed Reconcile Directives

> **Sync the last two weeks of activity, in one windowed reconcile — both directions, status-agnostic.** Focusing on a 14-day activity window is deliberately less work and less prone to accidents than syncing full task and time history. The window default is **14 days** (`today − 14d … today`); a `[window]` argument may widen or narrow it.

> **DONE counts, not just TODO.** The scan is status-agnostic: a headline marked DONE (manually or otherwise) is synced exactly like a TODO. Completion is NOT propagated as a status — org DONE never closes a Zoho task; pulled Zoho tasks always land as `TODO`. Only **task existence and time** cross, per the bidirectional directive above.

> **Name-only sync for clock-less TODOs.** A TODO with no clock data yet still syncs to Zoho as a new **task name** (no time entry). Org → Zoho: any windowed headline (TODO or DONE) missing in Zoho gets created.

> **Zoho → org is activity-scoped.** Only Zoho tasks with **time entries in the window** that have no org counterpart are pulled in (as `** TODO <name>`, formatted like existing headlines with a `:PROPERTIES:` drawer). No full-history backfill.

> **Confirm the project boundary, not each write.** Additive time/clock dedup runs automatically (per the full-auto directive above). Stop to confirm ONLY a new or ambiguous **project** mapping, and a **NO MATCH** before creating a brand-new task (the MANDATORY task-matching checkpoint). Everything else proceeds without per-item prompts.

> **`status` is the dry run of this same window.** `status` previews exactly what `sync` would do over the window — including the name-only TODOs it would create in Zoho and the TODO/DONE time it would move — writes nothing, and offers to continue into `sync`.

*— Added 2026-06-24, source: user instruction (build-it ratification; windowing steer "just focus on the last two weeks of activity"; Q&A answers: clock-less TODOs sync by name, org DONE leaves the Zoho task open, Zoho→org activity-scoped, pulled tasks always TODO).*
<!-- /origin -->

<!-- origin: user | added: 2026-07-20 | immutable: true -->
### Concurrent-Work Directive

> **I often run more than one job at a time. Please don't be concerned about overlap anymore. Adjust the timesheet entry to ignore this.**

*— Added 2026-07-20, source: user instruction (inline). Overlapping `CLOCK:` ranges are LEGITIMATE — Francis routinely runs concurrent jobs, so two blocks covering the same wall-clock minutes are expected data, not an error. Never surface a time-range intersection as a warning, a drift signal, a dedup candidate, or something to reconcile or confirm; never ask about it, and never mention it in a report. Overlap is NEVER a reason to alter, merge, trim, split, or re-time a CLOCK line — this composes with the "Org-mode time data is sacrosanct" rail rather than competing with it: both forbid touching logged time. Dedup stays keyed on `task_id` + `log_date` + `duration` per [sync-model.md](references/sync-model.md) § Idempotency; time-range intersection is not and never becomes a dedup key. Applies to every mode (`push`, `pull`, `sync`, `status`, `log`) and to totals that legitimately exceed elapsed wall-clock time.*
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "I often run more than one job at a time. Please don't be concerned about overlap anymore. Adjust the timesheet entry to ignore this." -->
CHECKPOINT — Concurrent-Work Gate (fires in EVERY mode — `push`, `pull`, `sync`, `status`, `log` — at any point a CLOCK line is built, compared, reported, or written):
1. State, in one sentence, the principle this checkpoint enforces: "Overlapping clock times are legitimate concurrent work, not an anomaly — noticing an overlap is a reflex, not a finding, and it obligates no action and no mention." Then proceed.
2. Identify any comparison you are about to make between two CLOCK time RANGES (start/end intersection, "this block starts before that one ends", adjacency, gap analysis, wall-clock-total plausibility). Time-range intersection is NOT a defined operation in this skill.
3. IF such a comparison produced (or would produce) an overlap observation → STOP. Discard it. Do NOT warn, flag, footnote, caveat, ask, or "just note" it; do NOT offer to adjust, merge, trim, split, re-time, or reconcile any CLOCK line; do NOT treat it as drift, as a dedup signal, or as a reason to withhold a write. Continue the mode exactly as if the ranges did not intersect.
4. Dedup and idempotency identity remains EXACTLY `task_id` + `log_date` + `duration` (sync-model.md § Idempotency). IF you are tempted to add a time-range test to a dedup, reconcile-before-post, or drift check → STOP. That is the same reflex wearing a different hat; the identity keys are closed.
5. A day's summed CLOCK time MAY exceed elapsed wall-clock time. IF a total looks "impossible" → CONTINUE without comment; concurrency is the expected explanation and requires no verification.
6. Before emitting any report, confirm it contains no overlap observation. IF one is present → remove it and re-read this checkpoint's step 1. IF none is present → CONTINUE to the report.
<!-- END ENFORCEMENT ANNOTATION -->

---

## Activity Window (the 2-week reconcile scope)

Every reconcile mode (`push`, `pull`, `sync`, `status`) operates over a single **activity window**: `today − 14 days … today` by default. Compute it once from the real date (`date '+%Y-%m-%d'`), never guess. A `[window]` argument overrides the span (e.g. `7d`, `30d`, or an explicit `YYYY-MM-DD..YYYY-MM-DD`).

The window scopes BOTH sides identically:

| Side | In scope when… |
|------|----------------|
| **Org → Zoho** | a headline (TODO **or** DONE) has a `CLOCK:` whose **start date** is in the window, **or** a clock-less headline carries a `<YYYY-MM-DD>` tag in the window (name-only sync). |
| **Zoho → org** | a Zoho **time entry**'s `log_date` is in the window (the task it belongs to is the unit pulled in). |

Zoho is read with the fast path from [pull-api.md](references/pull-api.md) (`sort_column=log_date&sort_order=D`, stop paging once `log_date` drops below the window) — the date params Books ignores are never relied on.

## Grounding (Enforced via Agent)

Before using any project ID, spawn the ID Lookup agent (see [agents/id-lookup/AGENT.md](agents/id-lookup/AGENT.md)) with the org filename or project name. Only proceed if it returns FOUND with a valid ID. The agent has `context: none` — IDs come from file, not memory. For manual fallback, read [references/project-mapping.md](references/project-mapping.md) and state the ID you found.

**Batch rule:** When a transfer involves multiple projects, spawn ONE ID Lookup agent with the full list of project names and have it return all IDs in a single FOUND/NOT_FOUND report — never one agent per project.

**References:** [workflow.md](references/workflow.md) · [clock-format.md](references/clock-format.md) · [project-mapping.md](references/project-mapping.md) · [task-cache.md](references/task-cache.md) · [entry-patterns.md](references/entry-patterns.md) · [api.md](references/api.md) · [pull-api.md](references/pull-api.md) · [sync-model.md](references/sync-model.md) · [log-workflow.md](references/log-workflow.md) · [agents/task-matcher/AGENT.md](agents/task-matcher/AGENT.md)

---

## Org Files Location

Before touching any org file, **resolve the source** — read `AGENDA_SOURCE` + `ORG_DIR` from `.env.local`:

- **`local`/unset** → an external syncer keeps `ORG_DIR` fresh; use it directly (default path below).
- **`server`** → this host owns the sync. **If `/timesheet` is the entry skill** (invoked directly), run the full bracket (same as agenda's [Server sync bracket](../agenda/references/org-format.md)): `bash scripts/org-sync.sh pull` before the first read → `bash scripts/org-sync.sh deletions` and **ask** before any `delete-local` (incoming deletions) → work → `bash scripts/org-sync.sh push` **once** at the end **only if** an org write happened → `deletions` again and **ask** before any `delete-remote` (outgoing). Deletions are **always user-confirmed**, never silent; a failed pull → **STOP**. **If `/timesheet` was chained from `/agenda`**, the bracket already ran there — do **not** pull, push, or delete again (one sync per run, owned by the entry skill).
- **anything else** → **STOP**; report `AGENDA_SOURCE` is unrecognized.

**Zoho-only operations** (API calls that touch no org file) are unaffected by the source check. `org-sync.sh` lives at the project root beside `zoho-token.sh`; it is never-delete and stateless.

```
ORG_DIR default: /home/francis/Insync/fmeetze@gmail.com/Google Drive/gdrive/org/
```

Each `.org` file corresponds to a project/client. The filename (minus extension) is the project identifier.

---

## Time Calculation Rules

1. **Aggregate by headline per day** — Sum all clock entries under a single headline for a given date. The headline is the unit of work.
2. **Use start date** — If a clock spans midnight, attribute to the date when work STARTED
3. **Round to nearest 15 minutes** for Zoho entry (optional, confirm with Francis)
4. **Headline = Task description** — Use the headline text (after TODO/DONE keyword) as the time entry description.

See [references/clock-format.md](references/clock-format.md) for format details and examples.

---

## Workflow: Push (Org → Zoho)

The org → Zoho leg, scoped to the [Activity Window](#activity-window-the-2-week-reconcile-scope) and **status-agnostic** (TODO **and** DONE). Before submitting, follow the **idempotency preflight** in [sync-model.md](references/sync-model.md) § Push: link each headline to its `:ZOHO_TASK_ID:` (or first-link via the matcher), skip any org CLOCK already recorded as synced or already present in Zoho (reconcile-before-post), and never re-post a CLOCK that originated from a pull. Then run the steps below.

| Step | Action | Details |
|------|--------|---------|
| 1 | **Request** | `/timesheet push [window]` (default 14 days; a bare "Transfer timesheet for [DATE]" pins the window to that single date) |
| 2 | **Parse** | Scan all mapped org files for in-window headlines — **TODO and DONE alike**: their CLOCK lines, plus clock-less headlines whose `<date>` tag is in the window |
| 3 | **Aggregate** | Sum time per headline per day. A clock-less windowed headline carries **no time** — it is a name-only candidate |
| 4 | **Display** | Show mockup for review (time entries + name-only tasks to be created) |
| 5 | **Confirm** | Confirm only a new/ambiguous **project** mapping and any **NO MATCH** task creation; additive dedup is automatic |
| 6 | **Match Tasks** | Deterministic precheck first, then spawn task-matcher for each UNRESOLVED headline |
| 7 | **Submit** | Create tasks (if needed — including **name-only** tasks for clock-less TODOs) and post in-window time entries |

See [references/workflow.md](references/workflow.md) for detailed step-by-step execution.

---

### Task-Matching Precheck (deterministic, runs before any agent spawn)

**Cache fast-path first (exact-name only).** Consult the per-project task-name cache ([references/task-cache.md](references/task-cache.md), `task-cache.json`) before any Zoho fetch. Order per headline: property-hit (`:ZOHO_TASK_ID:` on the headline) → **cache exact case-insensitive name hit** (→ use that `task_id` directly, AUTO tier, no fetch, no agent) → otherwise it is a **cache miss** and MUST fall through to the authoritative fetch below. A cache miss is NEVER a NO MATCH — the cache may only ever *skip* work, never license a task creation (task-cache.md § invariant; the 2026-06-08 duplicate-task incident is exactly this failure).

**Authoritative fetch (unchanged) for any headline the cache did not resolve.** Fetch the project's **complete** Zoho task list ONCE (per [references/api.md](references/api.md), response uses `.task[]`). The endpoint returns max 200 tasks per page — you MUST page through `&page=N&per_page=200` until `page_context.has_more_page` is false, or recent tasks on later pages will be missed and you will create duplicates (large projects like tickettomato.com have 1,000+ tasks). For each such headline check for an exact case-insensitive title match against the full list. Exact match → use that task ID directly (AUTO tier) — no agent spawn for that headline. Spawn the task-matcher agent ONLY for headlines still without an exact match — and **pass it the already-fetched task list** (see [agents/task-matcher/AGENT.md](agents/task-matcher/AGENT.md) § Step 1) so it does NOT re-paginate; without this each unresolved headline re-fetches the whole list (the old 1+n cost). Matching itself is never skipped — the mandatory checkpoint below applies to every headline either way; only the *fetch and* agent spawn are skipped when the cache/precheck already produced an exact match.

**Persist opportunistically (no extra API calls).** After the authoritative fetch runs, persist that complete list into `task-cache.json` (write-through refresh) and stamp `last_full_refresh`. On every task this skill CREATES, write `{normalized_name: task_id}` into the cache immediately after the POST. A missing/corrupt cache is safe — it degrades to the full-pagination behavior above with no correctness loss (task-cache.md § Hard constraints).

### CHECKPOINT: Task Matching (MANDATORY)

**Grounding:** Read [references/checkpoint.md](references/checkpoint.md) — this is a blocking gate. Do not skip.

---

## Authentication

The OAuth helper and credentials live at the **project root** (`/home/francis/lab/odyssey-alive/`), **not** inside this skill — there is no `scripts/` dir under `.claude/skills/timesheet/`. The token helper is `scripts/zoho-token.sh` and it reads creds from `.env.local`, caching for 55 min.

Run Zoho API calls from the project root (the default working directory) so the relative path resolves — **do not `cd` into the skill directory first**:

```bash
# from /home/francis/lab/odyssey-alive (default cwd)
TOKEN=$(./scripts/zoho-token.sh)
```

If the working directory has moved, call it by absolute path instead:

```bash
TOKEN=$(/home/francis/lab/odyssey-alive/scripts/zoho-token.sh)
```

**Never call the OAuth endpoint directly for each API request.**

---

## Workflow: Pull (Zoho → Org)

Bring Zoho Books tasks and time entries **into existing org files only**, scoped to the [Activity Window](#activity-window-the-2-week-reconcile-scope). Additive: pull never edits or removes a CLOCK line, and never creates an org file.

**Grounding:** Read [references/sync-model.md](references/sync-model.md) (identity, idempotency, conflict rules) and [references/pull-api.md](references/pull-api.md) (the list endpoints and the time-entry → CLOCK construction) before writing anything.

1. **Scope to mapped files + window.** For each project in [references/project-mapping.md](references/project-mapping.md) whose org file exists, resolve `project_id` via the ID Lookup agent. Projects with no org file are skipped (out of scope per the directive).
2. **Index refresh.** List Zoho projects (`pull-api.md` § List Projects). For any Zoho project whose name matches an existing org file but is missing from `project-mapping.md`, add the row (org file ↔ project name ↔ project ID). Never invent a mapping for a project with no org file. If a project name is ambiguous → confirm before proceeding (per the windowed directive).
3. **Find active tasks in the window.** List the project's **time entries** over the window (fast path: `sort_column=log_date&sort_order=D`, stop once `log_date` < window-start). The set of `task_id`s on those entries is the **activity-scoped** task set — the only Zoho tasks eligible to be pulled. (No full task-list backfill.)
4. **Pull tasks → headlines.** For each active `task_id`: if an org headline already carries its `:ZOHO_TASK_ID:`, it is linked; else first-link by exact-name match (then the task-matcher for fuzzy), and **insert the `:PROPERTIES:` drawer** with `:ZOHO_TASK_ID:`/`:ZOHO_PROJECT_ID:` onto the matched headline. A task with no org counterpart is appended as a new `** TODO <name> <YYYY-MM-DD Day>` headline — **always TODO regardless of Zoho status** — with its `:PROPERTIES:` drawer, formatted like existing headlines; the `<date>` tag is the latest in-window time-entry date for that task.
5. **Pull time → CLOCK lines.** For each in-window entry NOT already represented in org (per `sync-model.md` § Time identity — dedup by stored entry id and by content reconciliation), construct a closed CLOCK line from `begin_time`/`end_time` (or synthesize per the fidelity rule) and **insert it into the task's `:LOGBOOK:`** (creating the drawer if absent). Record the entry id in the state cache with `origin: pull`.
6. **Report.** Summarize tasks linked/created and CLOCK lines added per project.

All writes in steps 4–5 are the insert-only shapes permitted by `agenda/hooks/triage-write-guard.sh` Pattern 8.

## Workflow: Sync (windowed reconcile, both directions)

One pass over the [Activity Window](#activity-window-the-2-week-reconcile-scope), status-agnostic, per [references/sync-model.md](references/sync-model.md) § Windowed Reconcile.

1. **Pull** (above) so org reflects the latest in-window Zoho activity (activity-scoped; pulled tasks land as TODO).
2. **Resolve conflicts** per [references/sync-model.md](references/sync-model.md) § Conflict Rules: time = additive union, never overwrite; **task status is NOT synced** (existence + time only — org DONE never closes Zoho; pulled tasks stay TODO); task rename or new-on-both = report, don't guess.
3. **Push** (org → Zoho), status-agnostic and including **name-only** clock-less TODOs: for every windowed headline (TODO **or** DONE) not yet in Zoho, ensure the task exists; post any missing in-window time (honoring reconcile-before-post). A clock-less windowed TODO becomes a name-only Zoho task (no time entry).
4. **Report** what moved each way. Confirm only the project-boundary / NO-MATCH cases (per the windowed directive); all dedup is automatic.

## Workflow: Status (read-only dry run → continue into sync)

Writes nothing. `status` is the **preview of exactly what `sync` would do** over the [Activity Window](#activity-window-the-2-week-reconcile-scope). Per [references/sync-model.md](references/sync-model.md) § Status:

1. **Read the window both ways.** List in-window Zoho time entries + their tasks per mapped project (fast path); scan mapped org files for in-window headlines (TODO **and** DONE) — their CLOCK lines AND clock-less headlines whose `<date>` tag is in the window.
2. **Diff** — exactly the `sync` actions, as a preview:
   - **Zoho → org:** in-window time entries / active tasks not yet in org (would become TODO headlines + CLOCK lines).
   - **org → Zoho time:** org CLOCK in the window not yet in Zoho (would post time entries).
   - **org → Zoho name-only:** windowed TODO/DONE headlines with no Zoho task yet, including **clock-less TODOs** (would create name-only tasks).
   - **Link health:** headlines linked (`:ZOHO_TASK_ID:`) vs unlinked; any cached `time_entry_id` no longer in Zoho (drift alarm, CRITICAL).
3. **Present** the per-project preview table, then **offer to continue into `sync`** (the only decision handoff status makes). Choosing to continue runs the windowed `sync` above; declining leaves everything untouched.

## Workflow: Log (quick-log a just-finished block)

Log a duration you just finished against a task, ending now, written to org AND Zoho together. This is the fast counterpart to `push` for a single block you didn't clock live.

**Grounding:** Read [references/log-workflow.md](references/log-workflow.md) for the full procedure (input parsing, `now` capture, task discovery/confirm, dual-write). Identity, idempotency, and CLOCK construction follow [references/sync-model.md](references/sync-model.md).

1. **Parse** `<task>` + `<duration>` (`45m`, `1h30m`, `1:30`, or bare minutes) and optional `--project <name>`.
2. **Now** — capture the real current timestamp with `date '+%Y-%m-%d %a %H:%M'` (never guess the time). `end = now`, `start = now − duration`.
3. **Resolve project** — `--project` → ID Lookup agent; else search the task name across mapped org files + Zoho task lists and pick the project.
4. **Discover + confirm task** — match via the `task-matcher` (exact-name AUTO, else fuzzy). **Present the matched task and the proposed CLOCK to the user for one confirmation** (the user asked for this); on NO MATCH, confirm creating a new task (MANDATORY task-matching checkpoint applies).
5. **Dual-write** — insert `CLOCK: [start]--[now] => H:MM` into the task's org `:LOGBOOK:` (hook Pattern 8) AND `POST` the time entry to Zoho Books **duration-only** (`log_date`, `log_time`, `is_billable` — do NOT send `begin_time`/`end_time`; Zoho rejects them, see Discovered Issues Log), honoring reconcile-before-post. The real start/end live only in the org CLOCK line for local fidelity. Record it in the state cache with `origin: log`.
6. **Report** the task, project, start–end, duration, and that both destinations were written.

---

## Notes

- Clock entries spanning midnight are attributed to the START date
- Task hierarchy (parent headings) can provide additional context if needed
- The `=> H:MM` duration is pre-calculated by org-mode, so we use it directly rather than recalculating from timestamps

---

## Discovered Issues Log

- **Zoho API returns `.task` not `.tasks`** — All task list responses use singular `.task[]` in jq. Fixed in task-matcher agent and reference.md. (2026-01-26)
- **Organization ID confusion** — Used wrong org ID (765429142 instead of 660295414). Added explicit directive at top of skill. Now enforced by hook `hooks/validate-org-id.sh`. (2026-01-26)
- **Task matcher agent not invoked** — Workflow step 6 was skipped, resulting in duplicate task creation. Added MANDATORY CHECKPOINT between steps 6 and 7. (2026-01-26)
- **Task list pagination missed** — Zoho's tasks endpoint returns max 200 tasks per page and paginates (`page_context.has_more_page`). The precheck and the task-matcher agent fetched only page 1, so for large projects (e.g. tickettomato.com with ~1,392 tasks across 7 pages) recent tasks on later pages were invisible — the matcher reported NO MATCH and would have created a duplicate. A nearly-created "Avelera Tax Integration" duplicate was caught only by a manual full-page scan. Fixed: precheck and task-matcher agent now page through `&page=N&per_page=200` until `has_more_page` is false. (2026-06-08)
- **Time-entries `from_date`/`to_date` filter is silently ignored** — The Books v3 time-entries list endpoints (both per-project `/projects/{id}/timeentries` and global `/projects/timeentries`) return the full history regardless of `from_date`/`to_date`; entries from 2018 came back on a `from_date=2026-06-01&to_date=2026-06-24` query. `pull-api.md` (List Time Entries) presents date scoping as if it works — it does not. **Workaround (verified on org 660295414):** add `sort_column=log_date&sort_order=D` and read page 1, filtering `log_date` client-side — most-recent entries surface first, so a single 200-row page covers the current month. pull/sync/status must date-filter client-side, never trust the query params. (2026-06-24, found during `status`)
- **`begin_time`/`end_time` POST is rejected — post duration-only** — `POST /projects/timeentries` returns `code 2: Invalid value passed for begin_time` when `begin_time`/`end_time` are supplied, in BOTH `"2026-06-24 14:01"` (24h) and `"02:01 PM"` (12h) formats. Francis's existing entries don't populate begin/end anyway — they're all duration-only. **Fix:** post with `log_time` (the `HH:MM` duration) only; keep the real start/end in the org `:LOGBOOK:` CLOCK line for local fidelity. The `log` workflow and `entry-patterns.md` are duration-only by design. (2026-06-24, found during `log`)
- **Token helper is at the project root, not the skill** — `scripts/zoho-token.sh` and `.env.local` live at `/home/francis/lab/odyssey-alive/`, not under `.claude/skills/timesheet/`. Running `cd` into the skill dir first makes `./scripts/zoho-token.sh` fail with "no such file or directory." **Fix:** run Zoho calls from the project root (the default cwd), or use the absolute path. See § Authentication. (2026-06-24, found during `log`)
- **Reconcile-before-post double-posted because an unreliable LIST query overrode the state cache** — A `/timesheet log` of a 0:51 block to "image upload issue" (task `1117916000006815153`, 2026-06-29 12:33–13:24) was posted to Zoho **twice**. The block was already in the state cache (key `…6825002`, `origin: log`) from a prior run, which by `sync-model.md` § Idempotency rule (b) ("not in the state cache") should have stopped the POST. But reconcile-before-post queried the per-task list endpoint `/projects/{PID}/tasks/{TID}/timeentries?sort_column=log_date&sort_order=D` — a variant **not documented in pull-api.md** and subject to the same unreliability as the rest of the Books v3 time-entry list family (date filters ignored; freshness for a just-created entry unestablished). It returned EMPTY; the orchestrator trusted that, POSTed a new entry (`…6827002`), then reclassified the cached `…6825002` as a "phantom" and re-keyed the cache to the new id — silently auto-healing exactly the drift that `sync-model.md` § Status forbids healing, leaving the first entry orphaned in Zoho. **Fix:** made the state cache authoritative for the POST gate — a cache hit on `(task_id, log_date, duration)` with `origin log|push` is a hard stop (link, never POST); the live LIST query may only *add* dedup matches, never subtract; a cache entry is **never** deleted/re-keyed on an empty list result (phantom status requires a positive single-entry 404, not absence from a list); any cache-vs-live disagreement resolves toward NOT posting plus a surfaced drift warning. Guard placed in the shared `sync-model.md` § Idempotency (covers push/sync/log), with an ordering note in `log-workflow.md` Step 5. (2026-06-30, found during `log`)
- **Full task-list pagination was the `log` bottleneck → added a positive-only task-name cache** — Confirming an exact-name task match required paginating the whole project task list (tickettomato ≈ 1,392 tasks / 7 pages), which timed out repeatedly during `/timesheet log`. Added a per-project `task_name → task_id` cache (`task-cache.json`, spec in [references/task-cache.md](references/task-cache.md)) that serves **exact-name hits only** and skips the fetch on a hit. Hard rule (design panel, 2026-07-14): a cache **miss never licenses a create** — it falls through to the authoritative fully-paginated fetch + MANDATORY checkpoint, unchanged; a stale cache missing a just-created Zoho task is structurally identical to the truncated fetch that caused the 2026-06-08 duplicate. Refresh is free (write-through on create + opportunistic persist of the fetch each mode already runs; no incremental "since"-fetch, since the tasks endpoint has no sort/date param). Same session also fixed the `push`/`sync` **1+n re-pagination**: the single precheck fetch is now passed into `task-matcher` spawns instead of each agent re-fetching. Loss/corruption of the cache degrades to slow-but-correct. (2026-07-14, design session via route → skill-builder)
- **Edit tool strips trailing whitespace → write-guard Pattern 8 blocks the append** — When the new headline/CLOCK subtree is appended immediately after an existing org line that ends in trailing whitespace (e.g. a dated note line ending in two spaces), the `Edit` tool silently trims that whitespace, which `agenda/hooks/triage-write-guard.sh` sees as a line *replace* — disqualifying the otherwise-valid Pattern 8 insert-only append (the guard rejects any delete/replace). Symptom: repeated "does not match an allowed agenda write pattern" even though the new block is well-formed. **Fixed (2026-06-30):** Pattern 8 now `rstrip()`s lines before its difflib compare (`agenda/hooks/triage-write-guard.sh`), so a trailing-whitespace-only diff on the anchor line registers as "equal" and the `Edit` tool append succeeds directly — a genuine content/CLOCK change still shows as a replace and stays blocked (verified both ways). The earlier `Bash` `printf >>` EOF append (guard matches only `Edit`/`Write`, not `Bash`) remains a valid fallback; either way keep the write strictly additive and verify no existing line changed (line-count delta == lines added). Do NOT "fix" an anchor line's whitespace as a separate edit — that is a replace. (2026-06-30, found during `log`)

---

