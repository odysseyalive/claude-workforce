# Sync Model — Identity, Idempotency, Conflicts
<!-- Enforcement: HIGH — these rules prevent duplicate tasks and double-billed time -->

The two-way sync is **poll + diff** (Zoho Books has no webhooks). Correctness comes from durable identity, content reconciliation against live Zoho, and additive-only org writes — not from per-item confirmation. This file is the contract every mode honors.

---

## Windowed Reconcile

All reconcile modes (`push`, `pull`, `sync`, `status`) operate over a single **activity window**: `today − 14 days … today` by default (a `[window]` argument overrides the span). Compute the window once from the real date — never guess. The window is the safety boundary the user ratified ("just focus on the last two weeks of activity" — less work, less prone to accidents): it bounds both the read and every write.

**Status-agnostic scan.** A headline's TODO/HOLD/DONE keyword does NOT gate eligibility. A DONE headline is reconciled exactly like a TODO. The matching ladder already strips the keyword before comparing names (§ Identity), so widening to DONE changes only *which headlines are scanned*, never how they match or dedup.

**What's in scope, per side (identical window):**

| Side | Eligible when… | Result |
|------|----------------|--------|
| **org → Zoho (time)** | a headline (TODO/DONE) has a `CLOCK:` whose start date ∈ window | ensure the task exists, post missing in-window time (reconcile-before-post) |
| **org → Zoho (name-only)** | a clock-less headline (TODO/DONE) carries a `<YYYY-MM-DD>` tag ∈ window | create the task by name in Zoho — **no time entry** |
| **Zoho → org** | a Zoho **time entry**'s `log_date` ∈ window | its task (if absent in org) becomes a `** TODO <name>` headline; its time becomes a CLOCK line |

**Status is existence + time only — never propagated.** Org DONE does NOT close the Zoho task; a closed/open Zoho task always lands in org as `TODO`. (Per the bidirectional directive "only time and tasks are synced" — completion state is neither.)

**Confirmation boundary.** Additive time/clock dedup is automatic. The reconcile STOPS to confirm only: (a) a new or ambiguous **project** mapping, and (b) a **NO MATCH** before creating a brand-new task (the MANDATORY checkpoint). No per-item write prompts.

---

## Identity

### Task identity — deterministic after first link

Each synced org headline carries its Zoho IDs in a `:PROPERTIES:` drawer directly under the headline:

```org
** TODO CVE Review
   :PROPERTIES:
   :ZOHO_TASK_ID: 1117916000004523001
   :ZOHO_PROJECT_ID: 1117916000000067095
   :END:
   :LOGBOOK:
   CLOCK: [2026-06-24 Wed 09:00]--[2026-06-24 Wed 10:30] => 1:30
   :END:
```

Matching ladder (stop at the first hit):

1. **Property hit** — headline has `:ZOHO_TASK_ID:` → that is the match. No scoring, ever.
2. **First-link** — no ID property → match by **exact case-insensitive task name** (org headline minus the TODO/HOLD/DONE keyword == Zoho `task_name`). Exact match → AUTO; write the `:PROPERTIES:` drawer so it never re-scores.
3. **Fuzzy first-link** — no exact match → spawn the `task-matcher` agent (AUTO ≥85% / REVIEW 60–84% / NO MATCH). On AUTO, write the property. REVIEW/NO MATCH obey the MANDATORY checkpoint (see below).

`:PROPERTIES:` drawers are written once via an **insert** (hook Pattern 8). They are never edited in place — the hook is insert-only, and an ID never changes once linked.

### Time identity — dedup without mutable org edits

A time block's identity is its Zoho **`time_entry_id`**. Because the write-guard hook is insert-only, we do **not** mutate org to tag each CLOCK with its id. Instead, dedup is two-layered:

- **State cache (`time-sync-state.json`)** — the detailed ledger, keyed `time_entry_id → { task_id, log_date, begin, end, duration, origin: pull|push }`. Location: repo-local under the skill dir, gitignored, single-writer. This is a **cache**, not the source of truth.
- **Content reconciliation (the safety net)** — every push/pull lists live Zoho entries for the task+date and matches them to existing org CLOCK lines by `(task_id, log_date, begin/end or duration)`. This means a **lost or stale cache degrades to "slow but correct," never to double-billing**: a CLOCK already present in Zoho is recognized by content and skipped.

A CLOCK recorded with `origin: pull` (it came from Zoho) is **never pushed back**. A CLOCK authored in org (no matching live Zoho entry) is pushed exactly once, then recorded `origin: push`.

---

## Task-name cache (positive-only)

A per-project `task_name → task_id` cache (`task-cache.json`, full spec in [task-cache.md](task-cache.md)) accelerates the **exact-name** match tier so task discovery can skip the full paginated Zoho fetch when the name is already known. It is a derived cache, never a system of record, and it obeys the same asymmetry as the time-entry state cache above:

> **A cache HIT may be trusted to skip work; a cache MISS must NEVER be trusted to permit task creation.** A cache that hasn't seen a just-created Zoho task is structurally identical to a truncated fetch — which § Idempotency forbids treating as NO MATCH.

- **Consult order:** property-hit (Identity Rule 1) → cache **exact-name** hit (→ AUTO, use the `task_id`, skip pagination) → **miss falls through** to the fully-paginated live fetch + `task-matcher`, unchanged. Fuzzy/REVIEW scoring never runs against the cache (a fuzzy hit on a stale cache could mis-link) — it stays on the live full-candidate path.
- **Refresh is free:** write-through on every task this skill creates, plus opportunistic whole-list persist whenever a mode runs the paginated fetch it already runs. No incremental "since" fetch exists (the tasks endpoint has no sort/date param; Zoho date filters are documented-unreliable).
- **Loss = slow, never wrong:** a missing/corrupt cache degrades to today's full-pagination behavior with no correctness loss. Index-vs-live disagreement resolves toward **not creating** and is surfaced, never silently healed. An entry is never pruned on absence from a list result — only rebuilt by the next full persist.

---

## Idempotency

The original one-way push had no dedup — the Discovered Issues Log records two real duplicate-creation incidents. These rules close that:

**Tasks — never double-created.** Creation requires BOTH (a) no `:ZOHO_TASK_ID:` on the headline AND (b) NO MATCH from the matcher against the **fully paginated** task list. A truncated/errored task fetch is NOT a NO MATCH — it HALTS (never falls through to create). This is the MANDATORY checkpoint, and it applies in `push` and `sync` alike.

**Time — never double-posted (push).** Before any `POST /projects/timeentries`, run **reconcile-before-post** in this order: **(1) state-cache check FIRST** — look for any cache entry with the same `task_id` AND `log_date` AND `duration` whose `origin` is `log` or `push`; a hit means the block is **already posted** → keep/record its `time_entry_id`, treat the write as a link, and **do NOT POST**. **(2) live check second** — only if the cache has no hit, list the task's recent Zoho entries and match by `(log_date, duration)` (and `begin/end` when present); a live hit also links instead of posting. Only post a CLOCK that is (a) not `origin: pull`, (b) not in the state cache, AND (c) not found live. After a successful POST, write the returned id to the cache **before** moving to the next entry, so an interrupted run resumes via reconciliation rather than re-posting.

> **The state cache is authoritative for the POST gate; the live LIST query may only ADD dedup matches, never subtract them.** The Books v3 time-entry list endpoints — per-project, **per-task** (`/projects/{PID}/tasks/{TID}/timeentries`), and global — are documented-unreliable (`from_date`/`to_date` ignored; freshness/completeness for a just-created entry unestablished — see SKILL.md § Discovered Issues Log + [pull-api.md](pull-api.md)). An **empty live result is never evidence of absence**: dedup signals are a monotonic union (cache-hit OR live-hit ⇒ already posted), so a missing live entry can never license a POST the cache already covers.

> **Never delete, re-key, or down-rank a state-cache entry on the strength of a LIST result.** A cached `time_entry_id` that does not appear in a live list is a **drift alarm to SURFACE, not to auto-heal** — the same policy as § Status's CRITICAL drift alarm ("never auto-heal billing silently"). "Phantom" status may be assigned ONLY by a direct, positive single-entry probe — `GET /projects/{PID}/timeentries/{time_entry_id}` returning 404/not-found — never by absence from a list page. When the cache says "posted" but a live list says "absent," **prefer NOT posting**: keep the cached id, write the org side as a link, and surface the cache/Zoho disagreement to the user rather than posting a second entry.

**Time — never double-imported (pull).** Insert a CLOCK for a Zoho entry only if its id is absent from the cache AND no existing org CLOCK under that task matches it by content. Re-running pull is a no-op for already-landed entries.

---

## Timestamp fidelity (org CLOCK construction)

Org CLOCK needs real start AND end: `CLOCK: [YYYY-MM-DD Day HH:MM]--[YYYY-MM-DD Day HH:MM] => H:MM`.

- **Zoho entry has `begin_time` + `end_time`** (timer-driven, or manually clocked) → build the CLOCK from them directly. Faithful.
- **Zoho entry has only `log_date` + `log_time`** (duration only — e.g. an entry the push created) → these are normally already represented in org (that's where they came from) and are skipped by dedup. If a duration-only entry must still be imported, **choose an end-time anchor and work BACKWARDS**: anchor `end` to the workday end (default **17:00**) on `log_date`, then `start = end − duration`, giving `[log_date end−duration]--[log_date end]`. Tag it `synthetic_times: true` in the cache, and **never treat a synthetic block as a billing source** — billing originates only from real Zoho `begin/end`.
- **Midnight-spanning** — if `log_hour` exceeds the start→end clock delta, the block crossed midnight; attribute to the START date (consistent with the existing Notes) and flag rather than guess the end date.

---

## Conflict Rules

A conflict is an object changed on BOTH sides since the last sync. Defaults:

| Object | Resolution | Halt? |
|--------|-----------|-------|
| **Time / CLOCK** | **Additive union, never overwrite.** Both sides' blocks are kept; dedup by id/content. A destructive time conflict is impossible by construction (insert-only + the hook's CLOCK-count rail). | No |
| **Task status** (TODO/HOLD/DONE ↔ open/closed) | **NOT synced** — status never crosses. Org DONE never closes a Zoho task; pulled Zoho tasks always land as `TODO`. Only task existence + time reconcile (§ Windowed Reconcile). | No |
| **Task rename** | **Report, don't guess** — the name drives identity and the billing description. Keep both readings in the report; let the user reconcile. | Yes |
| **New-on-both** (same task created independently both sides) | **Report** the candidate pair (with the matcher score); could be a true duplicate or two real tasks. | Yes |

Rule of thumb: additive or clear state-progression auto-resolves; anything that would overwrite human-authored text or risk a duplicate is reported, not acted on.

---

## Index auto-update

`project-mapping.md` (org file ↔ Zoho project name ↔ project ID) is the routing table. During pull/sync:

- List Zoho projects. For a Zoho project whose **name matches an existing org file** but whose row is **absent** from the mapping → append the row (idempotent; never duplicate an existing row).
- Never add a row for a Zoho project with **no** org file (out of scope — "only existing org files").
- The mapping file is editable by the skill (it is not under the org dir, so the write-guard hook does not gate it).

---

## Status mode

Read-only **dry run of the windowed `sync`** — it computes the exact actions `sync` would take over the activity window, presents them, writes nothing, and then offers to continue into `sync`. For each mapped project, read the window both ways (in-window Zoho time entries + their tasks; in-window org headlines TODO **and** DONE — their CLOCK lines and clock-less `<date>`-tagged headlines) and present:

- **Zoho → org:** in-window time entries / active tasks not yet in org → would become `TODO` headlines + CLOCK lines.
- **org → Zoho (time):** org CLOCK in the window not yet in Zoho → would post time entries.
- **org → Zoho (name-only):** windowed TODO/DONE headlines with no Zoho task — **including clock-less TODOs** → would create name-only tasks.
- **Link health:** linked vs unlinked headlines (missing `:ZOHO_TASK_ID:`).
- **Cache drift alarm:** any `time_entry_id` in the cache that no longer exists in Zoho (deleted/edited upstream) — flag as CRITICAL, never auto-heal billing silently.

After the preview table, offer to continue into `sync` (the only decision handoff status makes). Status itself never writes.

---

*Created by skill-builder during the 2026-06-24 bidirectional-sync build. Enforcement boundary: agent (task-matcher) + hook (triage-write-guard Pattern 8).*
