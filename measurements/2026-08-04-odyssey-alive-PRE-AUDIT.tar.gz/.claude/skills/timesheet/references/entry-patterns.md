## Francis's Zoho Entry Patterns

Observed from existing time entries in Zoho Books:

| Field | Pattern |
|-------|---------|
| **notes** | Empty — task name serves as description |
| **is_billable** | true (default) |
| **log_time format** | "HH:MM" (e.g., "03:52") |
| **log_date format** | "YYYY-MM-DD" (e.g., "2026-01-13") |
| **billed_status** | "unbilled" (auto-set, changes when invoiced) |

**Key insight:** The Zoho task name IS the description. When creating time entries, the `notes` field can be left empty since the task name (e.g., "CVE Review", "Server Decommission Review") already describes the work.

This maps to org-mode headlines:
- Org headline: `** TODO CVE Review` -> Zoho task name: "CVE Review"
- Time logged against that task needs no additional notes
