## Org-mode Clock Format

nvim-orgmode uses standard org-mode CLOCK entries in a `:LOGBOOK:` drawer:

```org
** TODO Task description <2026-01-04 Sun>
   :LOGBOOK:
   CLOCK: [2026-01-13 Tue 14:16]--[2026-01-13 Tue 17:08] => 2:52
   CLOCK: [2026-01-06 Tue 14:25]--[2026-01-06 Tue 14:30] => 0:05
   :END:
```

**Format:** `CLOCK: [START_DATE DAY START_TIME]--[END_DATE DAY END_TIME] => H:MM`

### Hierarchy

```
* Project Section (H1)
** Task Headline (H2) <- This is the billable unit
   :LOGBOOK:
   CLOCK: [2026-01-13 Tue 14:16]--[2026-01-13 Tue 17:08] => 2:52
   CLOCK: [2026-01-13 Tue 23:37]--[2026-01-14 Wed 00:37] => 1:00
   :END:
```

Both clock entries above -> **one line item**: "Task Headline" = 3:52 for 2026-01-13
