# Log Workflow — Quick-log a just-finished block
<!-- Enforcement: MEDIUM — task-matching checkpoint + reconcile-before-post apply -->

`/timesheet log <task> <duration> [--project <name>]` logs a duration you just finished against a task: end = the current time, start = end − duration, written to the org file AND Zoho Books in one action. It is the single-block, end-now counterpart to `push`.

Examples:
- `/timesheet log "CVE Review" 45m`
- `/timesheet log "Server decommission" 1h30m --project tickettomato`
- `I just spent 25 minutes on the Avelera tax integration`

---

## Step 1: Parse input

- **task** — free text; the headline/task name to match (quoted or trailing phrase).
- **duration** — accept `45m`, `1h`, `1h30m`, `1:30` (H:MM), or a bare integer (minutes). Normalize to total minutes, then to `H:MM` for the CLOCK suffix and to Zoho `log_time` (`HH:MM`).
- **--project `<name>`** — optional project/org-file hint (fuzzy, like `review` mode: `tt` → tickettomato).

If duration is missing or unparseable → ask for it in prose (it is the one value that can't be inferred). Do not guess a duration.

## Step 2: Capture "now" (never guess the time)

The session does not know the wall-clock time — read it from the system:

```bash
date '+%Y-%m-%d %a %H:%M'   # e.g. 2026-06-24 Wed 14:52
```

- `end = now`
- `start = now − duration` (compute with `date -d "now - <N> minutes" '+%Y-%m-%d %a %H:%M'`)
- If `start` lands on the previous calendar day (duration crosses midnight) the CLOCK spans two dates honestly; attribute the entry to the START date for Zoho `log_date` (consistent with the existing midnight rule in SKILL.md § Notes).

## Step 3: Resolve the project

- `--project` given → resolve its Zoho project ID via the **ID Lookup agent** (SKILL.md § Grounding) and its org file from [project-mapping.md](project-mapping.md).
- No project given → search the **task name** first across existing org headlines in the mapped files (fast, local `grep`), then against Zoho task lists for the candidate projects. If exactly one project plausibly owns the task → use it. If several → present the candidates and let the user pick (this is part of the Step 4 confirmation, one interaction).

## Step 4: Discover + confirm the task (the user-requested confirmation)

0. **Cache fast-path (exact-name only).** Consult the per-project task-name cache ([task-cache.md](task-cache.md), `task-cache.json`) FIRST, after checking existing org headlines for a `:ZOHO_TASK_ID:` link. An **exact case-insensitive** name hit → use that `task_id` as the AUTO match and SKIP the paginated fetch entirely (this is the common case a `log` targets and the whole point of the cache). Any **miss** falls through to step 1 — a miss is NEVER a NO MATCH (task-cache.md § invariant).
1. On a cache miss, run the **task-matcher** ([agents/task-matcher/AGENT.md](../agents/task-matcher/AGENT.md)) for the task text against the resolved project (paginated; exact-name → AUTO, else fuzzy REVIEW/NO MATCH). Also check existing org headlines carrying a `:ZOHO_TASK_ID:` for a deterministic link. Fuzzy scoring runs only here against the live full list — never against the cache.
2. **Present one confirmation** showing: the matched task name (or "create new task '<task>'"), the project, and the proposed `CLOCK: [start]--[now] => H:MM`. The user confirms, picks a different candidate, or approves creating a new task.
3. **NO MATCH → create:** the MANDATORY task-matching checkpoint ([checkpoint.md](checkpoint.md)) applies — never silently create a duplicate; a truncated/errored task fetch HALTS rather than falling through to create. On confirmed create, POST the task and capture its `task_id`, then **write-through** `{normalized_name: task_id}` into `task-cache.json` under the project. If a full task list was fetched on the miss path, also persist it into the cache and stamp `last_full_refresh` (opportunistic, no extra API call).

## Step 5: Dual-write (org + Zoho, idempotent)

Both writes represent the SAME block; record it once in the state cache so a re-run never double-logs (sync-model.md § Idempotency).

1. **Org** — insert `CLOCK: [start]--[end] => H:MM` into the task headline's `:LOGBOOK:` (create the drawer if absent); ensure the headline carries its `:ZOHO_TASK_ID:`/`:ZOHO_PROJECT_ID:` `:PROPERTIES:` (insert if first-link). All inserts are hook Pattern 8 shapes (insert-only, closed CLOCK, drawer-balanced).
2. **Zoho** — `POST /projects/timeentries` **duration-only**: `project_id`, `task_id`, `log_date`, `log_time` (the `HH:MM` duration), `is_billable:true` (entry-patterns.md). **Do NOT send `begin_time`/`end_time`** — Zoho rejects them with `code 2: Invalid value passed for begin_time` (in both 24h and 12h formats), and Francis's entries are duration-only anyway; the real start/end stay in the org `:LOGBOOK:` CLOCK line for local fidelity (SKILL.md § Discovered Issues Log). Run the POST from the **project root** so `./scripts/zoho-token.sh` resolves (or use its absolute path — SKILL.md § Authentication). Run **reconcile-before-post** first (sync-model.md § Idempotency), **in order: (1) state-cache check, then (2) live check**. A state-cache entry for the same `task_id`+`log_date`+`duration` (origin `log`/`push`) is a **hard stop** — link it, never POST. Only if the cache has no hit does the live query run, to catch out-of-band entries. **Never** delete or re-key a cache entry because a live LIST came back empty (the list endpoints are documented-unreliable); if the cache says posted but the live query says absent, prefer NOT posting and surface the disagreement to the user.
3. Record `{ task_id, log_date, begin, end, duration, origin: "log", books_time_entry_id }` in `time-sync-state.json`.

## Step 6: Report

State concisely: task, project, `start–end (duration)`, and that both the org file (`<file>.org`) and Zoho Books were written. If reconcile-before-post found an existing Zoho entry, say it linked rather than re-posted.

---

*Created by skill-builder 2026-06-24. Reuses the bidirectional-sync machinery (task-matcher, sync-model, Pattern 8, Books push).*
