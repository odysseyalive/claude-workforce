# Task Matching Checkpoint (MANDATORY)

**STOP. Before creating ANY tasks or time entries, you MUST complete this checklist:**

- [ ] For EACH headline, did you spawn a task-matcher agent?
- [ ] Did you wait for ALL agent responses before proceeding?
- [ ] AUTO (85%+) results: proceed without asking
- [ ] REVIEW (60-84%) results: show match to user for confirmation
- [ ] NO MATCH results: confirm with user before creating new task
- [ ] MULTIPLE MATCHES results: user selects the correct task

**Display a summary table before proceeding:**

```
| Headline | Matched Task | Score | Action |
|----------|-------------|-------|--------|
| CVE Review | CVE Review | 100% | auto |
| Server Review | Server Decommission Review | 72% | needs review |
| New Feature | (none) | - | create new |
```

**Only proceed to Step 7 when all non-AUTO items are resolved.**

If you skipped task matching, STOP NOW and go back to Step 6.
