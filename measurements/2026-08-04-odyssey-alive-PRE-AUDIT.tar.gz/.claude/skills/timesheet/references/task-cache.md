# Task-Name Cache — positive-only exact-match fast path
<!-- Enforcement: HIGH — a misuse of this cache reintroduces the 2026-06-08 duplicate-task incident -->

A per-project local cache of `task_name → task_id` that lets task-matching skip the full paginated Zoho task fetch **when the exact task name is already known**. It is the task-level analogue of [project-mapping.md](project-mapping.md), but with one non-negotiable difference: **it is a derived cache, never a system of record, and it may only ever produce a *skip*, never a *create*.**

Motivation: large projects carry 1,000+ tasks (tickettomato ≈ 1,392 across 7 pages). Paginating the entire list just to confirm an exact-name match cost 2+ minutes and timed out repeatedly during `/timesheet log`. Most logs target a task that already exists — so a local exact-name lookup removes that cost for the common case.

---

## The invariant (read this first)

> **A cache HIT may be trusted to skip work. A cache MISS must NEVER be trusted to permit task creation.**

A local cache that has not yet seen a just-created Zoho task is *structurally identical to a truncated fetch* — the exact condition the MANDATORY checkpoint ([checkpoint.md](checkpoint.md), [sync-model.md](sync-model.md) § Idempotency) forbids treating as NO MATCH. Zoho Books has no webhooks, so staleness between runs is unbounded: a task typed into the Zoho UI seconds before a run is invisible here. Therefore a miss is never evidence of absence — it only means "not accelerated; do the authoritative thing."

This mirrors the time-entry state cache's own asymmetry (sync-model.md § Idempotency, 2026-06-30 lesson): the cache is authoritative to make the system **stand down** (skip), never authoritative to **license** a write.

---

## Scope: exact-name hits only

The cache serves **exact case-insensitive name matches only** — the same determination SKILL.md's deterministic precheck and sync-model.md Identity Rule 2 already make, just without the fetch.

- **Exact-name hit** in the cache → treat as the AUTO-tier match; use the `task_id`, skip the paginated fetch.
- **Any miss** (name not present) → fall through to the authoritative fully-paginated live fetch + the `task-matcher` agent, exactly as today. Fuzzy/REVIEW scoring is **never** run against the cache: fuzzy needs the complete live candidate set to score correctly, and a fuzzy hit against a stale cache could mis-link to the wrong task. Fuzzy stays on the live path.

Consult order (stop at the first hit):

1. **Property hit** — the org headline already carries `:ZOHO_TASK_ID:` → that is the match (sync-model.md Identity Rule 1). The cache is not consulted.
2. **Cache exact-name hit** → AUTO match; use the cached `task_id`, skip pagination.
3. **Miss** → full paginated fetch + `task-matcher` (unchanged). On this path, opportunistically refresh the cache from the list you just fetched (see Refresh).

---

## File format

Location: `.claude/skills/timesheet/task-cache.json` (repo-local, **gitignored**, single-writer — same posture as `time-sync-state.json`).

```json
{
  "schema": "timesheet-task-cache/1",
  "projects": {
    "1117916000000067095": {
      "project_name": "tickettomato.com",
      "last_full_refresh": "2026-07-14",
      "task_count": 1393,
      "tasks": {
        "questionnaire orphan issue": "1117916000006976004",
        "tax refund calculation hardening": "1117916000006922004"
      }
    }
  }
}
```

- Keyed by `project_id` (stable), then by **normalized task name** → `task_id`. Normalization = `lower().strip()` (the same normalization the matcher applies before comparison).
- `last_full_refresh` records the date of the most recent whole-list persist for that project; it is advisory (it bounds when the cache was last synced, NOT whether an out-of-band task appeared since) and may inform *when to opportunistically refresh*, never *whether a miss is safe*.
- Name collisions (two Zoho tasks sharing a normalized name) → do **not** cache that name (ambiguous); let it fall through to the live matcher, which reports MULTIPLE MATCHES. A normalized name maps to at most one `task_id` in the cache.

---

## Refresh mechanics (no extra API calls)

The cache is populated as a **free by-product** of work the skill already does — never by a dedicated fetch:

- **Write-through on create.** Every task this skill creates (`push`, `sync`, `log`) is known locally at creation time → insert `{normalized_name: task_id}` into the project's `tasks` map immediately after the POST returns.
- **Opportunistic full persist.** Whenever a mode runs the full paginated task fetch it already runs (the precheck in `push`/`sync`, or a `log` miss that triggers the authoritative fetch), persist that complete list into the cache and stamp `last_full_refresh`. Zero extra calls.
- **No incremental "since" refresh.** The Zoho tasks endpoint exposes no `sort`/`created_time`/`modified_time`/date param (only `page`/`per_page`), and Zoho's date filters are twice-proven unreliable ([pull-api.md](pull-api.md); SKILL.md § Discovered Issues Log). There is no trustworthy "modified-since" fetch, so the only refresh is write-through + opportunistic full persist.

---

## Hard constraints (must-haves)

These are the panel-ratified invariants (design review 2026-07-14). Any change to this feature must keep every one intact:

1. **A miss never licenses a create.** A cache miss falls through to the full paginated live fetch before any creation decision — it is never itself a NO MATCH.
2. **The MANDATORY checkpoint runs unmodified on the miss path:** full paginated fetch, matcher scoring, HALT on truncation/error (never fall through to create on an incomplete fetch).
3. **Freshness informs *when to refresh*, never *whether a miss is trustworthy*.** `last_full_refresh` is advisory only.
4. **No reliance on Zoho list/date "since" semantics** for refresh — the track record is two confirmed failures.
5. **Disagreement resolves toward not-creating, and is surfaced** — never silently reconciled in either direction (same rule as the § Status CRITICAL drift alarm).
6. **Never delete/downgrade a cache entry on absence from a list/page result.** Only a positive single-item probe (`GET …/timeentries/{id}` 404 analogue — here a task GET-by-id 404) may retire an entry. (In practice the cache is simply rebuilt by the next opportunistic full persist; do not prune on negative signals.)
7. **Loss/corruption degrades to slow-but-correct.** If `task-cache.json` is missing, unreadable, or fails to parse, the skill falls back to the current fully-paginated behavior with no correctness loss — only speed. The cache is derived; it is safe to delete at any time.
8. **Property-hit stays logically prior.** The `:ZOHO_TASK_ID:` headline check (Identity Rule 1) always precedes any cache consultation. The cache sits *below* the property, never replaces it, and only ever serves the exact-name tier.

---

## Where each mode uses it

| Mode | Consult (skip on exact hit) | Write-through on create | Opportunistic full persist |
|------|------------------------------|--------------------------|-----------------------------|
| `log` | Step 4 task discovery (after property, before matcher) | Step 5 on create | on a miss that triggers the authoritative fetch |
| `push` | Task-Matching Precheck (exact tier) | on any task created | after the precheck's full fetch |
| `sync` | via push leg | on any task created | after the full fetch |
| `pull` / `status` | n/a (read Zoho→org) | n/a | persist the full task list it already reads |

---

*Created by the 2026-07-14 task-index design session (route → skill-builder; 3-agent design panel: throughput cartographer / cache-coherence auditor / Zoho ledger archivist). The positive-only-exact envelope is the panel's ratified safe form; the create-gate stays exactly as hardened on 2026-06-08.*
