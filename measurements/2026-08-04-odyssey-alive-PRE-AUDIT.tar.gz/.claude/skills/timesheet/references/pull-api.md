# Pull API — Zoho Books → Org
<!-- Enforcement: LOW — API reference for the pull/sync/status read path -->

The reverse of [api.md](api.md) (which covers create task / create time entry / list tasks). This file covers the **read** endpoints pull/sync/status use, and how a Zoho time entry becomes an org CLOCK line.

Base URL: `https://www.zohoapis.com/books/v3` · every call needs `organization_id=660295414` (enforced by `hooks/validate-org-id.sh`). Auth header: `Authorization: Zoho-oauthtoken $TOKEN` (token via `./scripts/zoho-token.sh`). Rate limit: 100 req/min per org — throttle and prefer date-scoped queries over re-paging everything.

---

## List Projects (index refresh)

```bash
TOKEN=$(./scripts/zoho-token.sh)
curl -s -H "Authorization: Zoho-oauthtoken $TOKEN" \
  "https://www.zohoapis.com/books/v3/projects?organization_id=660295414&per_page=200" \
  | jq -r '.projects[] | "\(.project_id)\t\(.project_name)\t\(.status)"'
```

Use this for the index auto-update (`sync-model.md` § Index auto-update): a project whose `project_name` matches an existing org file but is missing from `project-mapping.md` gets a row added. Paginate via `page_context.has_more_page`.

## List Time Entries (the pull source)

> **⚠️ `from_date`/`to_date` are SILENTLY IGNORED by Books v3.** Both the per-project and the global time-entry endpoints return the FULL history regardless of any date params — a June-2026 query comes back with entries from 2018. Do NOT scope by date params (verified on org 660295414, 2026-06-24; see SKILL.md Discovered Issues Log). **Scope by sorting newest-first and filtering client-side:** add `sort_column=log_date&sort_order=D` so the most-recent entries land on page 1, then keep only `log_date >= <window-start>`. A single 200-row page covers the current month; stop paging once `log_date` drops below the window.

Per project, newest-first, filtered client-side to the date window:

```bash
TOKEN=$(./scripts/zoho-token.sh)
PID={PROJECT_ID}
FROM=2026-06-01
curl -s -H "Authorization: Zoho-oauthtoken $TOKEN" \
  "https://www.zohoapis.com/books/v3/projects/$PID/timeentries?organization_id=660295414&sort_column=log_date&sort_order=D&per_page=200" \
  | jq --arg from "$FROM" '.time_entries[]? | select(.log_date >= $from)
      | {time_entry_id, task_id, log_date, begin_time, end_time, log_time, is_billable, billed_status, notes}'
```

The same `sort_column=log_date&sort_order=D` + `select(.log_date >= $from)` shape works against the global `/projects/timeentries` endpoint (no `project_id`) when a whole-org sweep is wanted — that is how `status` reads every project's current month in one call.

**Key fields (verified):**

| Field | Use |
|-------|-----|
| `time_entry_id` | The durable identity key for time dedup (`sync-model.md` § Time identity). |
| `task_id` | Links the entry to its task → to the org headline carrying that `:ZOHO_TASK_ID:`. |
| `log_date` | `YYYY-MM-DD`. The CLOCK date. |
| `begin_time` / `end_time` | Real clock start/end when present (timer-driven or manually clocked) → faithful CLOCK. |
| `log_time` | `HH:MM` duration — the `=> H:MM` suffix; also the fallback when begin/end are absent. |
| `is_billable`, `billed_status` | Carried for the status drift report; do not alter on pull. |

Paginate via `page_context.has_more_page`. (A bare `/projects/timeentries` without a `project_id` returns differently across plans — always query per-project with the path above.)

## List Tasks

Use the paginated task list exactly as the `task-matcher` agent does (see [api.md](api.md) § List Tasks for a Project — singular `.task[]`, page through `has_more_page`). Pull links each task to an org headline by `:ZOHO_TASK_ID:` then exact name, and appends a `** TODO <task_name>` headline (inside the existing file) for any task with no org counterpart.

---

## Time entry → org CLOCK construction

Target line: `   CLOCK: [YYYY-MM-DD Day HH:MM]--[YYYY-MM-DD Day HH:MM] => H:MM`

1. `Day` is the 3-letter weekday for `log_date` (e.g. `2026-06-24` → `Wed`).
2. **Real times present** (`begin_time` + `end_time`) → `[log_date Day begin]--[log_date Day end] => log_time`. Normalize times to 24-hour `HH:MM` (Books may return `03:38 PM`).
3. **Duration only** (`log_time`, no begin/end) → normally already in org (skip via dedup). If it must import, **choose an end-time anchor and work BACKWARDS**: `end` = the workday end (default **17:00**) on `log_date`, then `start = end − duration`, giving `[log_date Day (end−duration)]--[log_date Day end]`. Tag `synthetic_times: true` and never treat it as a billing source (`sync-model.md` § Timestamp fidelity).
4. **Midnight span** (`log_time` > clock delta) → attribute to the START date, flag, don't guess the end date.
5. Insert the line into the task's `:LOGBOOK:` (create the drawer if absent). This is hook Pattern 8 (insert-only, closed CLOCK, drawer-balanced). Then record `time_entry_id` in the state cache with `origin: pull`.

---

## Incremental / change detection

Books exposes no millisecond modified-since filter on time entries and no webhooks, and (as above) its `from_date`/`to_date` params are ignored — sort `log_date` descending, take entries from page 1 until `log_date` drops below the window, and dedup by `time_entry_id` + content. For tasks, page the full list (the matcher already does) and rely on `:ZOHO_TASK_ID:` for linkage. `status` mode additionally verifies each cached `time_entry_id` still exists upstream (drift alarm).

---

*Created by skill-builder during the 2026-06-24 bidirectional-sync build. Field names verified against the live Books v3 API (org 660295414) and the official Time Entries v3 reference.*
