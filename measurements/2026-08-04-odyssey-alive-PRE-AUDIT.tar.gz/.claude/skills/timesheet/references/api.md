## API Endpoints

Base URL: `https://www.zohoapis.com/books/v3`
All requests require `organization_id=660295414` parameter.

### Create Task

Tasks must exist before logging time against them:

```bash
TOKEN=$(./scripts/zoho-token.sh)
curl -s -X POST "https://www.zohoapis.com/books/v3/projects/{PROJECT_ID}/tasks?organization_id=660295414" \
  -H "Authorization: Zoho-oauthtoken $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"task_name":"Task headline from org file","is_billable":true}'
```

### Create Time Entry

```bash
TOKEN=$(./scripts/zoho-token.sh)
curl -s -X POST "https://www.zohoapis.com/books/v3/projects/timeentries?organization_id=660295414" \
  -H "Authorization: Zoho-oauthtoken $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"project_id":"PROJECT_ID","task_id":"TASK_ID","log_date":"2026-01-13","log_time":"03:52","is_billable":true}'
```

**Parameters:**
- `project_id` — Zoho Books project ID
- `task_id` — Zoho Books task ID (create task first if needed)
- `log_date` — YYYY-MM-DD format
- `log_time` — HH:MM format (e.g., "03:52")
- `is_billable` — true or false
- `notes` — Optional description (task name usually sufficient)

### List Time Entries

**⚠️ `from_date`/`to_date` are silently ignored** — these endpoints return the full history regardless of date params. To scope to a window, sort newest-first (`sort_column=log_date&sort_order=D`) and filter `log_date` client-side; recent entries surface on page 1. See [pull-api.md](pull-api.md) § List Time Entries.

```bash
TOKEN=$(./scripts/zoho-token.sh)
curl -s -H "Authorization: Zoho-oauthtoken $TOKEN" \
  "https://www.zohoapis.com/books/v3/projects/{PROJECT_ID}/timeentries?organization_id=660295414&sort_column=log_date&sort_order=D&per_page=200"
```

### List Tasks for a Project

**IMPORTANT — paginate.** This endpoint returns at most 200 tasks per page and signals more via `page_context.has_more_page`. A single un-paged request only sees the first 200 tasks; large projects (e.g. tickettomato.com ~1,392 tasks) keep recent tasks on later pages. Always loop until `has_more_page` is false:

```bash
TOKEN=$(./scripts/zoho-token.sh)
PID={PROJECT_ID}
page=1
while :; do
  resp=$(curl -s -H "Authorization: Zoho-oauthtoken $TOKEN" \
    "https://www.zohoapis.com/books/v3/projects/$PID/tasks?organization_id=660295414&page=$page&per_page=200")
  echo "$resp" | jq -r '.task[]? | "\(.task_id)\t\(.task_name)"'
  [ "$(echo "$resp" | jq -r '.page_context.has_more_page')" != "true" ] && break
  page=$((page+1))
done
```

**IMPORTANT:** Response uses `.task[]` (singular), not `.tasks[]`:
```bash
# Correct jq path
jq '.task[] | {task_id, task_name}'
```

### List All Projects

```bash
TOKEN=$(./scripts/zoho-token.sh)
curl -s -H "Authorization: Zoho-oauthtoken $TOKEN" \
  "https://www.zohoapis.com/books/v3/projects?organization_id=660295414" | jq '.projects[] | {project_name, project_id, status}'
```
