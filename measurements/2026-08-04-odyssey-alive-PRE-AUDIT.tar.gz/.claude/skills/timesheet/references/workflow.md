## Workflow Procedures

Detailed step-by-step execution for the workflow dispatch table in SKILL.md.

### Step 1: Request

`/timesheet push [window]` — default window is the last **14 days** (`today − 14d … today`; compute from the real `date '+%Y-%m-%d'`, never guess). A bare "Transfer timesheet for [DATE]" pins the window to that single date for backward compatibility — parse it to YYYY-MM-DD (e.g., "January 13, 2026" -> "2026-01-13").

### Step 2: Parse (status-agnostic + name-only)

Scan all mapped org files for in-window headlines — **TODO and DONE alike** (the keyword never gates eligibility). Two kinds of in-window candidate:

1. **Timed** — a headline with a `CLOCK:` whose start date is in the window → push its time.
2. **Name-only** — a clock-less headline whose `<YYYY-MM-DD>` tag is in the window → create the task by name (no time entry).

```bash
# Build the window once, then match any CLOCK date or headline <date> tag within it.
ORG="/home/francis/Insync/fmeetze@gmail.com/Google Drive/gdrive/org"
FROM=$(date -d '14 days ago' '+%Y-%m-%d'); TO=$(date '+%Y-%m-%d')
for f in "$ORG/"*.org; do
  # in-window CLOCK lines (timed candidates), keyword-agnostic — the headline above each is the unit
  awk -v from="$FROM" -v to="$TO" '
    /^\*+ (TODO|DONE|HOLD|NEXT)?/ { headline=$0 }
    /CLOCK: \[/ {
      if (match($0, /\[([0-9]{4}-[0-9]{2}-[0-9]{2})/, m) && m[1] >= from && m[1] <= to)
        print FILENAME": "headline" || "$0
    }' "$f"
done
```

This surfaces, per file:
- Project name (from filename)
- Task headlines (TODO **or** DONE), with their in-window clock entries
- (Separately) clock-less headlines whose `<date>` tag falls in the window → name-only candidates

### Step 3: Aggregate

For each headline found, sum all clock entries for the requested date.

**Time Parsing Logic:**

Extract hours and minutes from the `=> H:MM` suffix:

```bash
# Extract time from a clock line
echo "CLOCK: [2026-01-13 Tue 14:16]--[2026-01-13 Tue 17:08] => 2:52" | \
  grep -oP '=> \K\d+:\d+' | \
  awk -F: '{print $1 * 60 + $2 " minutes"}'
```

To sum multiple entries for a task:
```bash
# Sum all times for a task (in minutes), then convert back
total_minutes=0
while read -r line; do
  time=$(echo "$line" | grep -oP '=> \K\d+:\d+')
  hours=$(echo "$time" | cut -d: -f1)
  mins=$(echo "$time" | cut -d: -f2)
  total_minutes=$((total_minutes + hours * 60 + mins))
done <<< "$clock_entries"
echo "$((total_minutes / 60)):$(printf '%02d' $((total_minutes % 60)))"
```

### Step 4: Display

Generate a timesheet summary mockup:

```
## Timesheet for [DATE]

### [Project Name] (from filename.org)

| Headline | Total |
|----------|-------|
| Task headline text (from ** line) | H:MM |
| Another headline | H:MM |
| **Project Total** | **H:MM** |

### [Another Project]
...

---
**Day Total: H:MM**
```

**Key:** Each row = one headline. Multiple clock entries under the same headline are summed into a single total for that day.

### Step 5: Confirm

Present mockup to user for approval or adjustment.

### Step 6: Match Tasks

For each headline, spawn the task matcher agent:

```
Task tool with subagent_type: "general-purpose"
prompt: "Read .claude/skills/timesheet/agents/task-matcher/AGENT.md for instructions,
        then match headline '[headline]' in project [project_id].
        Query Zoho for existing tasks and return MATCH, NO MATCH, or MULTIPLE MATCHES."
```

Wait for ALL agent responses before proceeding.

Handle agent responses by confidence tier:
- **AUTO (85%+):** Use the returned `task_id` without asking
- **REVIEW (60-84%):** Show the uncertain match to user for confirmation
- **NO MATCH (<60%):** Confirm with user before creating new task
- **MULTIPLE MATCHES:** User selects the correct task

### Step 7: Submit

For each headline. **Name-only candidates (clock-less, in-window TODO/DONE):** do step 1 only — create the task — and SKIP step 2 (no time entry). **Timed candidates:** do both.

1. **Create task if needed** (NO MATCH case):
   ```bash
   TOKEN=$(./scripts/zoho-token.sh)
   curl -s -X POST "https://www.zohoapis.com/books/v3/projects/{PROJECT_ID}/tasks?organization_id=660295414" \
     -H "Authorization: Zoho-oauthtoken $TOKEN" \
     -H "Content-Type: application/json" \
     -d '{"task_name":"Task headline from org file","is_billable":true}'
   ```

2. **Create time entry:**
   ```bash
   TOKEN=$(./scripts/zoho-token.sh)
   curl -s -X POST "https://www.zohoapis.com/books/v3/projects/timeentries?organization_id=660295414" \
     -H "Authorization: Zoho-oauthtoken $TOKEN" \
     -H "Content-Type: application/json" \
     -d '{"project_id":"PROJECT_ID","task_id":"TASK_ID","log_date":"2026-01-13","log_time":"03:52","is_billable":true}'
   ```
