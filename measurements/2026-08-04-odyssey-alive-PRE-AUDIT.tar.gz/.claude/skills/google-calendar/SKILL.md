---
name: google-calendar
description: "Query, add, update, and delete events on Google Calendar 'Francis Meetze' (default calendar) on fmeetze@gmail.com. Modes: agenda, event, update, delete, check. Usage: /google-calendar [mode] [args]"
allowed-tools: Read, Glob, Grep, Bash
minimum-effort-level: high
---

# Google Calendar

Read and write Francis's Google Calendar via a skill-local REST integration
(no MCP dependency). Scoped to one calendar — 'Francis Meetze', the account's
default/primary calendar on `fmeetze@gmail.com`. (To-dos are handled by `/agenda`,
not here.)

## Usage

```
/google-calendar [mode] [args]
```

### Modes

| Mode | Command | Description |
|------|---------|-------------|
| `agenda` | `/google-calendar agenda [--days N] [--max N] [--q "text"]` | Query upcoming events (default: next 14 days; `--q` text-searches) |
| `event` | `/google-calendar event …` | Add a new event |
| `update` | `/google-calendar update --id <eventId> …` | Update fields on an existing event |
| `delete` | `/google-calendar delete --id <eventId>` | Delete an event |
| `check` | `/google-calendar check` | Probe auth and resolve the calendar ID |

Default mode is `agenda` if not specified. `update`/`delete` need an event id — get it from `agenda`.

---

<!-- origin: user | added: 2026-06-26 | immutable: true -->
## Directives

> **"Query and post to my Google Calendar 'Francis Meetze' (my default calendar) on the fmeetze@gmail.com account — query, add, update, and delete events. To-dos are handled by /agenda, not here."**

*— Added 2026-06-26, source: user (skill creation request, refined 2026-06-26)*
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Query and post to my Google Calendar 'Francis Meetze' (my default calendar) on the fmeetze@gmail.com account — query, add, update, and delete events. To-dos are handled by /agenda, not here." -->
CHECKPOINT — Target & Write-Confirmation Gate:
1. This skill operates ONLY on the calendar named 'Francis Meetze' (the account's default/primary calendar). Never target a different calendar. The name resolves to an ID via `scripts/gcal.sh check` (it falls back to the primary calendar if the name was changed).
2. This skill does NOT manage to-dos / tasks. If the user asks to capture a task or to-do, route them to `/agenda` (org-mode) — do not create a Google Tasks entry here.
3. READ mode (`agenda`, `check`) runs directly — non-destructive.
4. WRITE modes (`event`, `update`, `delete`) are outward-facing and change a real calendar. Before invoking them, echo the exact event fields (or, for delete, the event title/time you resolved from its id) back to the user and get explicit confirmation. IF the user has not confirmed THIS specific write → STOP. Do not call the API.
5. Never invent times, dates, titles, or attendees. If a required field (event `--start`/`--end`/`--summary`, or an `--id` for update/delete) is missing or ambiguous → ask the user, do not guess. For `update`/`delete`, resolve the target via `agenda` first and confirm it is the right event before writing.
<!-- END ENFORCEMENT ANNOTATION -->

---

<!-- origin: skill-builder | version: 1.0 | modifiable: true -->
## Workflow

All operations run through `scripts/gcal.sh`, which delegates auth to
`scripts/gcal-token.sh` (OAuth2 refresh-token flow, cached 55 minutes). Credentials
and the optional calendar-name override live in `.env.local` — see
[reference.md](reference.md) § Setup.

### Preflight (first run / auth doubt)

Run `bash scripts/gcal.sh check`. It verifies the token refreshes and that the
'Francis Meetze' calendar resolves to an ID (cached afterward). If it errors with a
missing-credential message, route the user to reference.md § Setup.

### agenda — query events

```bash
bash scripts/gcal.sh agenda --days 14 --max 25
bash scripts/gcal.sh agenda --q "Acme"        # text search to find an event to update/delete
```

Returns the Calendar `events.list` JSON (single events, ordered by start time).
Summarize for the user: date/time, title, location — and keep each event's `id`
handy for `update`/`delete`. Do not write anything.

### event — add an event

1. Collect: summary, start (ISO8601), end (ISO8601); optional description, location, reminders.
2. Per the Write-Confirmation Gate, echo the fields and get explicit confirmation.
3. On confirmation:

```bash
bash scripts/gcal.sh event --summary "Discovery call — Acme" \
  --start "2026-06-30T14:00:00-07:00" --end "2026-06-30T14:30:00-07:00" \
  --desc "Intro to AI automation" --location "Zoom" \
  --remind 1h --remind email:1d
```

Report the created event's `htmlLink` from the response.

**Reminders (`--remind`, repeatable).** Each `--remind` adds a notification override in the
form `[method:]duration` — `method` is `popup` (default) or `email`; `duration` is plain
minutes or `<n>m`/`<n>h`/`<n>d` (e.g. `--remind 5h`, `--remind 300m`, `--remind email:1d`).
Passing any `--remind` sets `reminders.useDefault=false` with the explicit overrides; omitting
it leaves the calendar's default reminders untouched.

### update — change an existing event

1. Find the event with `agenda` (use `--q` to search) and confirm its `id`.
2. Collect only the fields to change (partial patch): any of summary, start, end, desc, location, reminders.
3. Per the Write-Confirmation Gate, echo old → new and get explicit confirmation.
4. On confirmation:

```bash
bash scripts/gcal.sh update --id "abc123eventid" \
  --start "2026-06-30T15:00:00-07:00" --end "2026-06-30T15:30:00-07:00"

# reminders only (notify 5 hours before, replacing calendar defaults):
bash scripts/gcal.sh update --id "abc123eventid" --remind 5h
```

Only the supplied fields are modified. `--remind` (repeatable, same `[method:]duration` form as
`event`) replaces the event's reminder set with the given overrides — a `--remind`-only update is
valid. Report the updated event's `htmlLink`.

### delete — remove an event

1. Find the event with `agenda` and confirm its `id` and that it is the right one.
2. Per the Write-Confirmation Gate, echo the event title/time and get explicit confirmation.
3. On confirmation:

```bash
bash scripts/gcal.sh delete --id "abc123eventid"
```

Returns `{deleted:true, eventId:…}` on success (HTTP 204).

### Error handling

- `.env.local not found` / missing `GOOGLE_*` → reference.md § Setup (OAuth client + refresh token).
- `authentication failed` → token refresh problem; re-check the `GOOGLE_*` values and scope.
- Any non-2xx Google response is passed through as JSON — read `.error.message` and report it.
<!-- /origin -->

---

<!-- origin: skill-builder | version: 1.0 | modifiable: true -->
## Grounding

Before running any operation, read [reference.md](reference.md) for the env keys,
OAuth scope, calendar-name override, and API endpoint shapes.

See [reference.md](reference.md) for setup and the REST integration contract.
<!-- /origin -->
