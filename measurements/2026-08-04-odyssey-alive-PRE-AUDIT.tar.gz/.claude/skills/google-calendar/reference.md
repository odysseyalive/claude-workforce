# Google Calendar Skill Reference
<!-- Enforcement: LOW — REST integration contract and setup; no hook attached -->

## REST integration

Skill-local, no MCP dependency. Two scripts:

- `scripts/gcal-token.sh` — OAuth2 refresh-token → access-token, cached 55 min in
  `.gcal-token-cache`. Mirrors the `zoho-token.sh` pattern.
- `scripts/gcal.sh` — the operations (`check`, `agenda`, `event`, `update`, `delete`).
  Resolves the 'Francis Meetze' calendar to its ID once and caches it in `.gcal-id-cache`.

Both self-locate `.env.local` (CWD → repo root → `~/lab/odyssey-alive`).

| Command | Returns / does |
|---------|----------------|
| `gcal.sh check` | `{auth, calendar:{name,id}}` — verifies auth + name resolution |
| `gcal.sh agenda [--days N] [--max N] [--q "text"]` | Calendar `events.list` JSON (single events, ordered by start) |
| `gcal.sh event --summary --start --end [--desc] [--location] [--remind …]` | Creates an event; returns the event resource (`htmlLink`) |
| `gcal.sh update --id [--summary] [--start] [--end] [--desc] [--location] [--remind …]` | Partial-updates an event (PATCH); returns the event resource |
| `gcal.sh delete --id` | Deletes an event; returns `{deleted:true, eventId}` |

Output is one JSON document per call (Google API responses passed through; `delete`
prints a small status object).

### Reminders (`--remind`)

`event` and `update` accept a repeatable `--remind <spec>` flag. Each spec is
`[method:]duration`:

- **method** — `popup` (default) or `email`.
- **duration** — plain minutes, or `<n>m` / `<n>h` / `<n>d`. Examples: `5h`, `300m`, `1d`, `30`.

Examples: `--remind 5h`, `--remind 300m`, `--remind email:1d`, `--remind popup:2h --remind email:1d`.

Passing one or more `--remind` sets `reminders.useDefault=false` with the explicit
`overrides` array (so the calendar's default reminders are replaced for that event). Omitting
`--remind` leaves the event's reminders untouched — `update` then sends a true partial patch,
and `event` inherits the calendar defaults. A `--remind`-only `update` is valid (changes just
the reminders). Google caps an override at 40320 minutes (4 weeks) and rejects out-of-range or
malformed values — those surface as the passed-through API error.

## Account & target

- **Account:** `fmeetze@gmail.com`
- **Calendar:** `Francis Meetze` — the account's **default/primary** calendar (override: `GCAL_CALENDAR_NAME`)

The calendar name is resolved to an ID at runtime, so it survives a Google-side ID
change. If the name doesn't match, the resolver falls back to the **primary**
calendar (which is the default). To-dos/tasks are out of scope — use `/agenda`.

## Setup (one-time)

The skill needs a Google OAuth client with the **Calendar** scope and a refresh
token. No existing credential in `.env.local` covers this (the rclone GDrive token
is Drive-scoped; `GMAIL_APP_PASSWORD` is IMAP-only).

1. **Google Cloud Console** → create/choose a project → enable the **Google Calendar API**.
2. **Credentials** → create an **OAuth client ID** of type *Desktop app*. Note the
   client ID and client secret.
3. Authorize once (e.g. via the OAuth Playground or a local consent flow) with scope
   `https://www.googleapis.com/auth/calendar`, and exchange the resulting
   authorization code for a **refresh token**.
4. Add to `.env.local` at the repo root:

```
GOOGLE_CLIENT_ID=...
GOOGLE_CLIENT_SECRET=...
GOOGLE_REFRESH_TOKEN=...
# optional override:
# GCAL_CALENDAR_NAME=Francis Meetze
```

5. Verify: `bash scripts/gcal.sh check` should print the resolved calendar ID.

> **7-day-expiry gotcha:** while the OAuth consent screen is in **Testing**, refresh tokens
> expire after 7 days — and the expiry is fixed at issuance, so publishing to Production
> *afterward* does NOT save a token minted during Testing. **Publish the app to Production
> first, then mint the refresh token.** For own-account use the "unverified app" warning at
> consent is fine (Advanced → continue). A token minted while Testing must be re-minted after
> publishing.

> Setup help is available on request — ask to walk through generating the refresh token.

## API endpoints used

- Token: `POST https://oauth2.googleapis.com/token` (grant_type=refresh_token)
- Calendar v3: `https://www.googleapis.com/calendar/v3`
  - `GET /users/me/calendarList` — name → calendarId
  - `GET /calendars/{calendarId}/events` — query (timeMin/timeMax/singleEvents/orderBy/q)
  - `POST /calendars/{calendarId}/events` — add
  - `PATCH /calendars/{calendarId}/events/{eventId}` — partial update
  - `DELETE /calendars/{calendarId}/events/{eventId}` — delete

## Local state (gitignored, never committed)

- `.gcal-token-cache` — cached access token (chmod 600)
- `.gcal-id-cache` — resolved calendarId

Delete `.gcal-id-cache` to force re-resolution after renaming the calendar.
