#!/usr/bin/env bash
# Google Calendar REST integration for the /google-calendar skill.
# Operates ONLY on the 'Francis Meetze' calendar — the account's default/primary
# calendar (name overridable via GCAL_CALENDAR_NAME in .env.local).
#
# Usage:
#   gcal.sh check
#   gcal.sh agenda [--days N] [--max N] [--q "text"]
#   gcal.sh event  --summary "Title" --start <ISO8601> --end <ISO8601> [--desc "..."] [--location "..."] [--remind <spec>]...
#   gcal.sh update --id <eventId> [--summary "..."] [--start <ISO8601>] [--end <ISO8601>] [--desc "..."] [--location "..."] [--remind <spec>]...
#   gcal.sh delete --id <eventId>
#
#   --remind <spec>: a notification override, repeatable. Form "[method:]duration":
#     method   = popup | email (default popup); duration = plain minutes, or <n>m/<n>h/<n>d.
#     Examples: --remind 5h   --remind 300m   --remind email:1d   --remind 30 --remind popup:2h
#     Passing one or more --remind sets reminders.useDefault=false with explicit overrides.
#
# Auth: delegates to gcal-token.sh (OAuth2 refresh-token flow, cached 55m).
# Output: one JSON document per call (Google API responses passed through; delete prints a status line).

set -euo pipefail

CAL_BASE="https://www.googleapis.com/calendar/v3"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_DIR="$(dirname "$SCRIPT_DIR")"
ID_CACHE="$SKILL_DIR/.gcal-id-cache"

die() { echo "ERROR: $*" >&2; exit 1; }

# Target calendar name (overridable via .env.local).
load_names() {
  for candidate in \
    "$PWD/.env.local" \
    "$(git -C "$PWD" rev-parse --show-toplevel 2>/dev/null)/.env.local" \
    "$HOME/lab/odyssey-alive/.env.local"
  do
    if [[ -n "$candidate" && -f "$candidate" ]]; then
      # shellcheck disable=SC1090
      set -a; source "$candidate"; set +a
      break
    fi
  done
  CALENDAR_NAME="${GCAL_CALENDAR_NAME:-Francis Meetze}"
}

# Access token resolved ONCE in the main flow (never inside a command substitution,
# so a die() here exits the whole script with a single clean message — not just a subshell).
ACCESS_TOKEN=""
ensure_token() {
  [[ -n "$ACCESS_TOKEN" ]] && return 0
  ACCESS_TOKEN="$("$SCRIPT_DIR/gcal-token.sh")" || die "authentication failed — see reference.md § Setup"
  [[ -n "$ACCESS_TOKEN" ]] || die "authentication returned an empty token — see reference.md § Setup"
}

api() {  # api <METHOD> <url> [json-body]  — assumes ensure_token already ran in the main flow
  local method="$1" url="$2" body="${3:-}"
  if [[ -n "$body" ]]; then
    curl -sS -X "$method" -H "Authorization: Bearer $ACCESS_TOKEN" \
      -H "Content-Type: application/json" --data "$body" "$url"
  else
    curl -sS -X "$method" -H "Authorization: Bearer $ACCESS_TOKEN" "$url"
  fi
}

urlenc() { jq -rn --arg s "$1" '$s|@uri'; }

# ------- calendar-ID resolution (cached) -----------------------------------
resolve_cal() {
  ensure_token   # main-flow auth (always); dies cleanly before any nested API substitution
  if [[ -f "$ID_CACHE" ]]; then
    CAL_ID="$(sed -n '1p' "$ID_CACHE")"
    [[ -n "$CAL_ID" ]] && return 0
  fi
  local cal_resp
  cal_resp="$(api GET "$CAL_BASE/users/me/calendarList?maxResults=250")"
  # Prefer an exact name match; fall back to the primary (default) calendar.
  CAL_ID="$(printf '%s' "$cal_resp" | jq -r --arg n "$CALENDAR_NAME" '.items[]? | select(.summary==$n) | .id' | head -n1)"
  [[ -n "$CAL_ID" ]] || CAL_ID="$(printf '%s' "$cal_resp" | jq -r '.items[]? | select(.primary==true) | .id' | head -n1)"
  [[ -n "$CAL_ID" ]] || die "calendar '$CALENDAR_NAME' not found and no primary calendar. Available: $(printf '%s' "$cal_resp" | jq -r '[.items[]?.summary] | join(", ")')"
  printf '%s\n' "$CAL_ID" > "$ID_CACHE"
}

# ------- commands -----------------------------------------------------------
cmd_check() {
  resolve_cal
  jq -n --arg cal "$CALENDAR_NAME" --arg calid "$CAL_ID" \
        '{auth:"ok", calendar:{name:$cal, id:$calid}}'
}

cmd_agenda() {
  local days=14 max=25 q=""
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --days) days="$2"; shift 2 ;;
      --max)  max="$2";  shift 2 ;;
      --q)    q="$2";    shift 2 ;;
      *) die "unknown agenda flag: $1" ;;
    esac
  done
  resolve_cal
  local now end url
  now="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  end="$(date -u -d "+${days} days" +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || date -u -v+"${days}"d +%Y-%m-%dT%H:%M:%SZ)"
  url="$CAL_BASE/calendars/$(urlenc "$CAL_ID")/events?timeMin=${now}&timeMax=${end}&singleEvents=true&orderBy=startTime&maxResults=${max}"
  [[ -n "$q" ]] && url="${url}&q=$(urlenc "$q")"
  api GET "$url"
}

# Build an event JSON body from flags (used by create + update).
# Only non-empty fields are included, so update sends a true partial patch.
build_event_body() {
  local summary="$1" start="$2" end="$3" desc="$4" location="$5"
  jq -n --arg s "$summary" --arg st "$start" --arg en "$end" --arg d "$desc" --arg l "$location" \
    '{}
     + (if $s  != "" then {summary:$s} else {} end)
     + (if $st != "" then {start:{dateTime:$st}} else {} end)
     + (if $en != "" then {end:{dateTime:$en}} else {} end)
     + (if $d  != "" then {description:$d} else {} end)
     + (if $l  != "" then {location:$l} else {} end)'
}

# Parse one --remind spec "[method:]duration" → "method<TAB>minutes" on stdout.
# method: popup|email (default popup). duration: plain minutes, or <n>m/<n>h/<n>d.
parse_reminder() {
  local spec="$1" method="popup" dur num unit mins
  if [[ "$spec" == *:* ]]; then method="${spec%%:*}"; dur="${spec#*:}"; else dur="$spec"; fi
  case "$method" in
    popup|email) ;;
    *) die "invalid --remind method '$method' (use popup or email)" ;;
  esac
  [[ "$dur" =~ ^[0-9]+[dhm]?$ ]] || die "invalid --remind duration '$dur' (use minutes, or <n>m/<n>h/<n>d)"
  num="${dur//[dhm]/}"; unit="${dur//[0-9]/}"
  case "$unit" in
    ""|m) mins="$num" ;;
    h)    mins=$(( num * 60 )) ;;
    d)    mins=$(( num * 1440 )) ;;
  esac
  printf '%s\t%s\n' "$method" "$mins"
}

# Build a reminders-override object {reminders:{useDefault:false, overrides:[...]}}
# from one or more --remind specs. Prints the JSON object; no args → prints nothing.
reminders_override() {
  [[ $# -gt 0 ]] || return 0
  local spec
  for spec in "$@"; do parse_reminder "$spec"; done \
    | jq -R 'split("\t") | {method:.[0], minutes:(.[1]|tonumber)}' \
    | jq -s '{reminders:{useDefault:false, overrides:.}}'
}

# Deep-merge a reminders override (if any) into an event body. Echoes the merged body.
merge_reminders() {
  local body="$1"; shift
  [[ $# -gt 0 ]] || { printf '%s' "$body"; return 0; }
  local rem; rem="$(reminders_override "$@")"
  jq -n --argjson a "$body" --argjson b "$rem" '$a * $b'
}

cmd_event() {
  local summary="" start="" end="" desc="" location=""
  local -a reminders=()
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --summary)  summary="$2";  shift 2 ;;
      --start)    start="$2";    shift 2 ;;
      --end)      end="$2";      shift 2 ;;
      --desc)     desc="$2";     shift 2 ;;
      --location) location="$2"; shift 2 ;;
      --remind)   reminders+=("$2"); shift 2 ;;
      *) die "unknown event flag: $1" ;;
    esac
  done
  [[ -n "$summary" ]] || die "event requires --summary"
  [[ -n "$start"   ]] || die "event requires --start (ISO8601)"
  [[ -n "$end"     ]] || die "event requires --end (ISO8601)"
  resolve_cal
  local body; body="$(build_event_body "$summary" "$start" "$end" "$desc" "$location")"
  body="$(merge_reminders "$body" "${reminders[@]}")"
  api POST "$CAL_BASE/calendars/$(urlenc "$CAL_ID")/events" "$body"
}

cmd_update() {
  local id="" summary="" start="" end="" desc="" location=""
  local -a reminders=()
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --id)       id="$2";       shift 2 ;;
      --summary)  summary="$2";  shift 2 ;;
      --start)    start="$2";    shift 2 ;;
      --end)      end="$2";      shift 2 ;;
      --desc)     desc="$2";     shift 2 ;;
      --location) location="$2"; shift 2 ;;
      --remind)   reminders+=("$2"); shift 2 ;;
      *) die "unknown update flag: $1" ;;
    esac
  done
  [[ -n "$id" ]] || die "update requires --id (event id; get it from 'agenda')"
  local body; body="$(build_event_body "$summary" "$start" "$end" "$desc" "$location")"
  body="$(merge_reminders "$body" "${reminders[@]}")"
  [[ "$body" != "{}" ]] || die "update requires at least one field to change (or a --remind override)"
  resolve_cal
  # PATCH = partial update; only the supplied fields are modified.
  api PATCH "$CAL_BASE/calendars/$(urlenc "$CAL_ID")/events/$(urlenc "$id")" "$body"
}

cmd_delete() {
  local id=""
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --id) id="$2"; shift 2 ;;
      *) die "unknown delete flag: $1" ;;
    esac
  done
  [[ -n "$id" ]] || die "delete requires --id (event id; get it from 'agenda')"
  resolve_cal
  local http
  # DELETE returns 204 No Content on success; surface the HTTP status explicitly.
  http="$(curl -sS -o /dev/null -w '%{http_code}' -X DELETE \
    -H "Authorization: Bearer $ACCESS_TOKEN" \
    "$CAL_BASE/calendars/$(urlenc "$CAL_ID")/events/$(urlenc "$id")")"
  if [[ "$http" == "204" || "$http" == "200" ]]; then
    jq -n --arg id "$id" '{deleted:true, eventId:$id}'
  else
    die "delete failed (HTTP $http) for event $id"
  fi
}

main() {
  command -v jq >/dev/null 2>&1   || die "jq is required"
  command -v curl >/dev/null 2>&1 || die "curl is required"
  load_names
  local cmd="${1:-}"; shift || true
  case "$cmd" in
    check)  cmd_check  "$@" ;;
    agenda) cmd_agenda "$@" ;;
    event)  cmd_event  "$@" ;;
    update) cmd_update "$@" ;;
    delete) cmd_delete "$@" ;;
    ""|-h|--help)
      sed -n '2,19p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//' ;;
    *) die "unknown command: $cmd (try: check, agenda, event, update, delete)" ;;
  esac
}

main "$@"
