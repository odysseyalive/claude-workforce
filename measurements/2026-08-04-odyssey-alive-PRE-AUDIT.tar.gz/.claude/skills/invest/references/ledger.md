# Invest — Ledger Schemas & Math
<!-- Enforcement: HIGH — status/ledger/watch/spend read and write these schemas -->

Two-tier ledger, skill-local JSON under `data/`. All money in USD.

## data/holdings.json — open positions

```json
{
  "lots": [
    { "stock_id": "AAPL", "date": "2026-07-13", "fill_price": 289.24,
      "shares": 0.1729, "notional": 50.00 }
  ],
  "score_history": {
    "AAPL": [ { "date": "2026-07-13", "score": 0.71 } ]
  },
  "week_marker": "2026-W28"
}
```

- One `lots` entry per purchase (multiple over time per `stock_id` = multiple lots).
- `score_history[stock_id]` is the composite-score time-series (Directive 7): append
  on every buy and on every `watch` run.
- `week_marker` (ISO week) enforces one buy per week (No-Auto-Buy Gate clause 4).

## data/realized.json — closed positions

```json
{
  "closed": [
    { "stock_id": "XYZ", "opened": "2026-03-02", "closed": "2026-09-15",
      "total_invested": 150.00, "proceeds": 171.30, "realized_pl": 21.30,
      "lots_closed": 3, "method": "full-exit", "reason": "thesis break: <detail>" }
  ]
}
```

## Number 1 — full-holding P/L (status display, red/green)

For a `stock_id`, aggregate across all its lots:
- `shares_total = Σ lot.shares`
- `invested_total = Σ lot.notional`
- `market_value = shares_total × current_price` (current price via alpaca)
- **P/L $ = market_value − invested_total** ; green if ≥ 0, red if < 0.
- `scripts/ledger.py pl <ticker>` computes this.

## Number 2 — distance from the 200-day MA (status display, green/red)

- `dist = current_price − MA200` (and as %). Green if current price is ABOVE the
  200-day MA (uptrend intact), red if below.
- `scripts/ma.py <ticker>` computes MA200, MA20, last close, and this distance.

## Selling (Directive 8 — rare, fundamental-warning only)

- **Full exit (default):** on a serious fundamental red flag, sell the entire
  position. Move ALL lots for the `stock_id` out of `holdings.json` into
  `realized.json` as one closed record. On a full exit, lot-selection method is
  moot (every share sold), so `realized_pl = proceeds − Σ lot.notional`.
- **Partial trim (rare):** if ever trimming rather than exiting, use **HIFO** —
  sell the highest-`fill_price` lots first (most tax-efficient: smallest gain /
  largest loss). Caveat: Alpaca tax-reports FIFO by default, so a real HIFO trim
  needs explicit lot specification at sale. `scripts/ledger.py close <ticker>
  [--partial <amount>]` implements full-exit and HIFO-partial.
- The realized ledger doubles as the tax record (every sale + realized P/L).

## Never
- Never reduce or rewrite historical lots or score_history entries (append-only;
  a sale MOVES lots to realized, it does not delete history).
- Never let `watch` or any non-`spend` mode write a buy.
