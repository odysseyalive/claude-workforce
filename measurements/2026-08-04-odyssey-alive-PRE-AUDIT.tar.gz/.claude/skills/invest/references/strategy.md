# Invest — Strategy & Architecture
<!-- Enforcement: MEDIUM — the scout/watch workflows ground on this file -->

Condensed from the ratified design workshop (2026-07-06→07) and two adversarially
verified deep-research reports. Full spec + reports:
`~/.claude/plans/let-s-add-directions-for-enchanted-church.md`,
`~/.claude/plans/fundamental-research-report-2026-07-06.json`,
`~/.claude/plans/technical-research-report-2026-07-06.json`.

## The core principle

The **fundamental/sentiment layer holds the edge**; the technical layer does not.
Rigorous evidence (Sullivan/Timmermann/White 1999; Bajgrowicz/Scaillet 2012;
Park/Irwin 2007, all verified) shows classic technical indicators give no reliable,
cost-survivable entry-timing edge on mature large-cap equities. So the technical
layer is **execution framing only** — a moving-average read and an optional RSI dip
check that inform, but never gate, a fundamentally-chosen buy.

## Three layers (mechanical-first, AI-vetted)

### Layer 1 — Mechanical gather (no AI)
- **SEC filings** via the `edgartools` MCP (`edgar_company`, `edgar_filing`,
  `edgar_read`, `edgar_ownership`) or `scripts/edgar_pull.py`. Pull 10-K/10-Q/8-K,
  XBRL financials, Risk Factors + MD&A.
- **Filing-change signal (Lazy Prices, J. Finance 2020, verified):** year-over-year
  textual similarity of successive filings, computed mechanically. Non-changers
  drift up ~18 months with no announcement-day spike. Big filing changes = red flag.
- **News** via WebSearch → verified with web_fetch. Only professionally edited
  firm-level news enters the scored path.
- **Prices / MA** via the `alpaca` MCP or `scripts/ma.py`. Free IEX feed is fine for
  daily-bar MAs; full SIP history >15 min old is available on the free tier.

### Layer 2 — AI vet (subordinate, live-data only)
An agent scores what Layer 1 collected: news relevance/sentiment per ticker,
characterization of WHAT changed in a filing, macro/political + catastrophe impact.
It never invents data points and never sees future-dated information (LLM
look-ahead bias is real — backtests use mechanical signals only). The AI is a
vetter, not an oracle.

### Bias hygiene (the single most consequential finding — verified 3-0)
- **Point-in-time everything:** timestamp by filing/publication datetime, never
  fiscal period (non-PIT inflated a factor's predictive power ~60% in the canonical
  study).
- Lag vendor fundamentals ~3 months unless truly point-in-time.
- Never rank/backtest on today's index membership (survivorship bias can invert a
  signal's sign).

## The technical layer (minor, confirming)
- **200-day & 20-day simple moving averages** — MA timing has a verified parameter
  PLATEAU (Han/Yang/Zhou 2013): significant from ~20 to ~200-day lookbacks, no
  fragile peak. Use long lookbacks; choose by robustness, not tuning.
- **No repainting:** closed bars only; anchors fixed at signal time.
- **Optional RSI** as a within-uptrend dip helper only — oscillators misfire in
  trends unless a regime already fixes direction; here the fundamental score IS the
  regime filter.
- Display "number 2" = distance of current price from the **200-day** MA
  (green above / red below). See [ledger.md](ledger.md).

## Red-flag channel (out-of-band)
Fringe/social/conspiracy chatter NEVER enters the score (academically endorsed:
manipulation, noise, sample bias). It may feed a separate early-warning queue that
surfaces items for human review — never an automated trade.

## Position monitoring ("snoop", Directive 7)
The `watch` mode re-runs the same fundamental+news scoring over HELD names, appends
each new score to the stock's time-series, and alerts when the score falls below the
floor or a hard red flag fires. Surveillance of holdings; alerts only, never sells.

## What NOT to build (verified anti-patterns)
- No indicator zoo, no parameter optimization (genetic-optimized MACD triples were
  shown to be overfit outliers the author said not to trade live).
- No LLM feature-extraction pipeline claiming big prediction gains (refuted 0-3).
- No volume-based signals on the free IEX feed (IEX volume is ~2% of real volume).

## Open calibration items (settle in paper trading)
Scan cadence (proposed weekly; watchdog daily), position sizing, autonomy level,
the alert-floor value, the news vendor, and whether entry engineering (limit +
countdown) beats a plain market buy once fundamentals pick the name — test as a
paper-trading control.
