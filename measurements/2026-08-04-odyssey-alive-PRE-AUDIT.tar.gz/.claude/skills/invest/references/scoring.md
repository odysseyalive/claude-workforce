# Invest — Composite Score Methodology
<!-- Enforcement: HIGH — scout/watch score every candidate against this file -->

The composite score is the system's one governing number: it selects buys and, for
held stocks, it drives the watchdog flag. Grounded in the verified fundamental
research report.

**Implementation:** this spec is executed mechanically by `scripts/score.py` (SEC XBRL
fundamentals → sector-relative composite, dividend-first, reproducible). The Layer-2
agent supplies ONLY the leaf sub-scores; `score.py` owns the composite math. Scores are
never LLM-assigned. *(Moved to the mechanical scorer 2026-07-07 — prior LLM-assigned
scores were cleared from the ledgers so the weekly trend never mixes methodologies.)*

## Design principle: hierarchical, decay-ordered — NOT a flat average

Flat linear averaging of heterogeneous signals is verified bad practice. Weight
inputs by their information-decay horizon (valuation decays over years, sentiment
over months). Order, slowest→fastest:

| Tier | Input | Decay horizon | Role |
|------|-------|---------------|------|
| Root | Valuation / fundamentals (from XBRL financials) | years | highest structural weight |
| Mid | Filing-change signal (Lazy-Prices YoY similarity) | 12–18 mo | quality/continuity |
| Leaf | News sentiment (firm-level, edited) | 1–3 mo | size-conditioned: more weight for smaller names, less for mega-caps |

Sentiment enters **contrarian-and-conditional**, not additively: the best verified
long entry is sound/cheap fundamentals + washed-out (not euphoric) sentiment.

## Sector-relative normalization

Rank candidates cross-sectionally WITHIN each universe separately (technology; and
food/agriculture/consumer-staples). A stock competes against its own sector, not the
whole market.

## Dual threshold (Directive 6 — dividend-first)

- Determine dividend status mechanically (from fundamentals/EDGAR — no AI needed).
- **Dividend payer** → must clear the normal "substantial" score bar.
- **Non-dividend (growth)** → must clear a distinctly HIGHER bar.
- Threshold values live in `data/config.json` (`score.buy_threshold_dividend`,
  `score.buy_threshold_growth`), initially `null` = **calibrate in paper trading**.

## Catastrophe inputs (Directive 8)

War theaters and natural disasters LOCAL TO A COMPANY'S ASSETS (factories, HQ,
supply nodes, growing regions) feed the score as a downward news/event input. This
requires knowing each company's asset geography (derive from filings/news). A plant
in a war zone or a flooded farm belt → score drops → if a held name falls below the
alert floor, the watchdog fires.

## Alert floor (Directive 7)

The watchdog flag is a score-threshold test, NOT a fuzzy judgment. Set
`score.alert_floor` somewhat BELOW the buy threshold, with hysteresis (a holding
must stay down, not just touch), so a one-point dip doesn't cry wolf. `null` until
calibrated in paper trading.

## Reading discipline (the professional lens — applies to every news vet)

Modeled on how professional fundamental commentary actually reads markets
(adopted 2026-07-13 from a worked FT example). Four rules:

1. **Score the reaction, not the headline.** A blowout result met with a shrug
   means expectations were already priced in — bearish, not bullish. The
   *divergence* between news polarity and the market's received reaction is
   the signal. This is measured MECHANICALLY by `scripts/reaction.py` (never
   by the agent) and enters the composite as the `expectation_reaction` leaf.
2. **Know the cycle.** Semiconductors, agriculture, and commodity food are
   cyclical: peak earnings can be a top, not a buy. The agent supplies a
   `cycle_read` leaf (early/mid/crested) for cyclical subsectors ONLY, from
   news + filing language — never from price.
3. **Rotation is context, not score.** Cross-sector flow stories (money
   leaving chips for something else) explain moves and belong in the news
   narrative and divergence explanations; they are too noisy to quantify.
4. **Structure is data.** ADR ratios, dual listings, circuit-breaker regimes:
   record them as facts that bear on risk, don't score them.

**Divergence must be explained.** When root fundamentals are strong
(root >= 0.60) but the market disagrees — price below the 200-day MA, or an
`expectation_reaction` in the crowded family — the scout MUST source a
one-line "why" from the gathered news (rotation, cycle fears, litigation,
etc.) and carry it with the suggestion. If no reason can be sourced, write
"unexplained — caution": an unexplained divergence is itself information.

## Expectation-reaction leaf (mechanical — scripts/reaction.py)

For each candidate's most material dated news item, `reaction.py <ticker>
<news_date> --polarity <agent polarity>` measures the ~5-trading-day price
reaction from closed bars (Directive 4) and classifies it, conditioned on the
200/20-day MA state at news time (Directive 5: the MA CONDITIONS the size of a
news-driven adjustment; it never creates or vetoes a pick).

**The confirm threshold is volatility-scaled per stock** — a 2% move is an
event for a mega-cap staple and noise for a mid-cap semi, so the "market
agrees/shrugs" bar is `0.75 × σ_daily × sqrt(window_days)`, where σ is the
stock's own trailing 120-closed-day return volatility anchored at the baseline
bar (point-in-time, no lookahead), clamped to [1%, 10%]. Sub-1% moves never
count as a verdict; hyper-volatile names still get judged.

| classification | meaning | composite |
|---|---|---|
| confirming | market agrees with the news | +2 |
| confirming_reversal | good news confirmed while price breaks a downtrend (close above a rising 20MA under a falling/undercut 200MA) | +4 |
| crowded | good news, shrug/sell-off | -4 |
| crowded_extended | …while price > +20% above the 200MA | -7 |
| crowded_reversion | …while the 20MA sits >= +12% above the 200MA (equalization pull is DOWN) | -8 |
| washed_out | bad news absorbed flat/up | +3 |
| washed_out_depressed | …while price < -15% below the 200MA | +5 |
| washed_out_reversion | …while the 20MA sits <= -12% below the 200MA (equalization pull is UP) | +6 |

**Root gate:** every bonus above plain `confirming` requires root >= 0.55 —
no contrarian or reversion credit for weak fundamentals (that's how falling
knives get bought). Crowd penalties always apply. Thresholds INITIAL —
calibrate in paper trading.

**Double-count guard (score.py):** sentiment and expectation_reaction usually
derive from the SAME news event (bad news scores negative sentiment AND
generates a reaction read). When their final adjustments agree in sign, the
weaker of the two is halved before summing — one story is never charged (or
credited) twice at full weight.

## Cycle-read leaf (agent judgment, cyclical subsectors only)

`cycle_read`: none 0 / early +1 / mid 0 / crested -4. Supplied by the scoring
agent ONLY for cyclical names (semis, ag, commodity food), judged from news +
filing language — NEVER from price data, which the agent does not see.
Non-cyclicals (mega-cap software, branded staples) are always `none`.

**Corroboration requirement — MECHANICALLY ENFORCED by `score.py`
(`validate_cycle`)** — this is the most narrative-prone leaf in the system
("the cycle has crested" is a story financial media tells at every stage of
every cycle), so a non-`none`/`mid` value must arrive as a structured claim:

```json
"cycle_read": { "read": "crested", "evidence": [
  {"source": "10-Q", "date": "2026-07-01", "type": "quantitative", "note": "inventory days +22% q/q"},
  {"source": "FT",   "date": "2026-07-08", "type": "commentary",   "note": "orders met with a shrug"} ] }
```

- `crested`/`early` counts ONLY with ≥2 dated evidence items from DISTINCT
  sources, at least one `type: "quantitative"` (inventory build, ASP/pricing
  rollover, capacity glut, order-book contraction — or their recovery-side
  mirrors) — never commentary tone alone.
- Anything less — a bare string, one source, no quantitative marker, missing
  dates — is downgraded to `mid` (0) with `cycle_downgraded: true` in the
  score output, so uncorroborated attempts are visible in the audit trail.
- **Flip-flop freeze (mechanical, history-backed):** ≥2 changes across the
  last 4 recorded weekly reads in `score_history.json` plus the incoming one
  → frozen to `mid` with `cycle_frozen: true`. Calibration-review material.

## Calibration loop (/invest review — the process's own track record)

Every recorded weekly score carries its full `adjustments` breakdown and
validated `cycle_read` in `score_history.json`, which makes the system
self-evaluating: `scripts/review.py` mechanically measures the composite's
rank correlation with realized forward returns (4/8/12-week horizons) and
each signal's bucket performance, from stored point-in-time data only — a
retrospective on our own dated decisions, never a backtest search.

Cadence: the measurement AUTO-RUNS inside `scout` per `config.review`
(`cadence_weeks` since the last review, once `min_history_weeks` of history
exist) — it is read-only and its digest lands in the scout report, so the
system always measures itself on schedule. The judgment half stays explicit:
in `/invest review`, the AI interprets the report and PROPOSES at most one or
two parameter changes with evidence; **nothing is ever applied without
explicit approval**, and approved changes are logged to `data/calibration_log.json`
(`{date, parameter, old, new, evidence, review_file}`). Directive 4 governs:
stable plateaus over sharp peaks, INSUFFICIENT verdicts mean keep collecting,
and `scripts/selftest.py` must pass before and after every applied change.

## No verified decay constants

Every specific sentiment-decay constant in the literature was refuted (0-3). Decay
weighting must be estimated in-house from our own feed during paper trading — do not
hardcode a half-life.

## Scoring Agent (Layer 2)

Spawn via Task (general-purpose) with a bespoke persona used nowhere else. Contract:
- **Input:** ONLY mechanically gathered, point-in-time data (filing text/diffs,
  dated news snippets, asset-geography facts). Never fetches its own data.
- **Output (structured):** `news_sentiment` (−1..+1 + rationale), `filing_change`
  (none/minor/material + what changed), `catastrophe_proximity` (none/indirect/
  direct + which asset), `cycle_read` (cyclical subsectors only, from
  news/filing language — a non-none/mid read MUST be the structured
  `{read, evidence[]}` claim from § Cycle-read leaf; bare strings are
  mechanically downgraded to mid), and per material news item a
  `polarity` (positive/negative) + date that feeds `scripts/reaction.py`. Each
  with a one-line justification.
- **Forbidden:** future-dated information, price/technical opinions, buy/sell calls.
  The agent scores fundamentals; the composite math and thresholds live here, not in
  the agent. The `expectation_reaction` leaf is NEVER the agent's to assign —
  it is computed mechanically by `reaction.py` from the agent's polarity + the
  price record.

The main skill combines the agent's sub-scores with the mechanical tiers into the
final composite. Agent judgment feeds the score; it never IS the score.
