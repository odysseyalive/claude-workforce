---
name: invest
description: "Long-only buy-and-hold equity investing on Alpaca (paper) + SEC EDGAR. Modes: scout, screen, status, spend, budget, ledger, watch, review. Usage: /invest [mode] [args]"
allowed-tools: Read, Write, Edit, Bash, Task, WebSearch, mcp__alpaca__*, mcp__edgartools__*, mcp__playwright-mcp__web_fetch, mcp__playwright-mcp__session_login, mcp__playwright-mcp__session_status
minimum-effort-level: high
hooks:
  PreToolUse:
    - matcher: "Edit|Write"
      hooks:
        - type: prompt
          prompt: "Check if this edit alters any text between <!-- origin: user | immutable: true --> and <!-- /origin --> markers: $ARGUMENTS. If directive content was changed, DENY. Otherwise APPROVE."
          if: "Edit(**/SKILL.md)|Write(**/SKILL.md)"
          statusMessage: "Checking directive integrity..."
  PostCompact:
    - hooks:
        - type: command
          command: "echo '{\"additionalContext\": \"REMINDER: /invest never auto-buys. The buy path requires explicit human invocation of `spend`. Directives are sacred — never reword text between <!-- origin: user | immutable: true --> markers.\"}'"
          statusMessage: "Re-injecting invest directive awareness..."
---

# Invest

A long-only, buy-and-hold equity investing assistant. The **fundamental/sentiment
layer decides what and whether**; the technical layer only informs entry. Claude
**never buys automatically** — a purchase happens only when Francis explicitly runs
`spend`. Runs on Alpaca **paper trading** until a deliberate go-live.

## Usage

```
/invest [mode] [args]
```

### Modes

| Mode | Command | Description |
|------|---------|-------------|
| `scout` | `/invest scout` | Run the fundamental+sentiment scoring scan over the screened universe → produce this week's ranked suggestions (the stable weekly pick). Discovery only; never buys. |
| `screen` | `/invest screen [--force]` | Rebuild the candidate universe mechanically: `scripts/screen.py` sweeps ALL SEC filers in the tech + food/staples SIC codes (~1,000 listed companies), bulk pre-scores them from XBRL frames, and writes the top-N-per-sector shortlist to `data/universe.json`. Auto-refreshed by `scout` when stale. |
| `status` | `/invest status` | Show current holdings (with P/L + MA read) and this week's suggestions. Default mode. |
| `spend` | `/invest spend [amount] <stock_id>` | **Human-approved weekly buy.** Places ONE notional order (default = configured weekly budget) for the named stock. Requires explicit invocation + confirmation. |
| `budget` | `/invest budget <amount>` | Persist a new weekly spend amount (until changed again). |
| `ledger` | `/invest ledger` | View the two-tier ledger: open holdings (per-lot + score history) and realized/closed positions. |
| `watch` | `/invest watch` | Holdings watchdog: recompute each held stock's score, alert on score-floor breach or a red flag. Never sells — only warns. |
| `review` | `/invest review` | **Calibration retrospective.** The mechanical measurement (`scripts/review.py`: recorded signals vs realized forward returns) auto-runs inside `scout` on cadence (every ~4 weeks once ≥8 weeks of history exist) and its digest lands in the scout report. This mode is the judgment half: the AI interprets the latest report and PROPOSES threshold/weight adjustments with evidence. Never applies changes — Francis approves; approved changes are logged to `data/calibration_log.json`, one parameter at a time (Directive 4). |
| `pin` | `/invest pin <stock_id> [weeks]` · `/invest unpin <stock_id>` · `/invest pins` | Temporarily pin a ticker into this week's suggestions as a **comparison candidate** (default 3 weeks) so it rides alongside the scored picks. Discovery/compare only — a pin is never a recommendation and shows no Buy affordance. |

Default mode is `status`.

---

<!-- origin: user | added: 2026-07-07 | immutable: true -->
## Directives

> **1. Fundamentals first.** Fundamental news and public sympathy trump analytics. News, macro events, and sentiment (including the political dimension) set trade direction. Technical indicators are subordinate timing confirmation only — never an override.

> **2. Long-only, tech + food, ride long-term bull runs.** Long positions only — no shorting, no hedging, no derivatives. When the outlook is down, the position is cash. Universe is technology and food/agriculture/consumer-staples equities and ETFs. Target sustained multi-month/multi-year uptrends, not swing trades.

> **3. Human-in-the-loop, budgeted, one stock per week.** Claude never buys automatically. A weekly budget (default $50) buys exactly ONE stock, only on explicit `spend` invocation. Entries may use a limit price with a countdown that cancels the order if unfilled; for small notional buys a market order is acceptable.

> **4. Distortion-resistant technicals.** Signals compute on closed bars only; anchors (swing points, retracement levels) are fixed at signal time and never redefined retroactively. Lookbacks match the multi-month horizon. Parameters are chosen from stable plateaus, never sharp peaks. Temporal stability outranks backtest magnitude.

> **5. Simplicity, buy-and-hold, monitor holdings.** A moving average plus a buy signal is enough. No stop-loss. No short-term selling. The 200/20 MA and RSI are minor confirming indicators, secondary to the fundamental score. Continuously watch held companies for red flags (e.g. core technology being deprecated) and warn Francis — never auto-sell.

> **6. Dividend-first universe.** Build primarily from dividend-paying stocks. A non-dividend (growth) stock is chosen only on a distinctly higher fundamental score than a dividend payer must clear.

> **7. The composite score is stored and it governs both buying and flagging.** Store each held stock's composite score over time. The watchdog's flag is a score-threshold test: if a holding's score falls below a floor (set below the buy bar, with hysteresis), alert. Catastrophe inputs — war theaters and natural disasters local to a company's assets — feed the score.

> **8. Sell only on a serious fundamental warning, exit whole.** The only sell trigger is a fundamental red flag, never a technical indicator. A sale exits the entire position (all lots → realized ledger). HIFO applies only to a rare partial trim.

*— Added 2026-07-07, source: the /invest design workshop (2026-07-06→07). Full ratified spec: `~/.claude/plans/let-s-add-directions-for-enchanted-church.md` and the two deep-research reports beside it.*
<!-- /origin -->

<!-- origin: user | added: 2026-07-07 | immutable: true -->

> **9. News is a daily, permanent part of the picture — never empty.** News must be there every day and refreshed every day, gathered in BOTH the weekly `scout` (the start-of-week pick refresh) AND the daily `watch` (the holdings watchdog) — and it refreshes daily even when there are no holdings. The news isn't always about the stocks themselves: it must include **world events and company-related events that affect the business's rating** — the catastrophe / macro / sentiment inputs that feed the composite score per Directives 1 and 7 (war theaters, natural disasters local to a company's assets, regulatory/sector shifts, macro shocks), alongside firm-specific developments. Every item carries a real **source + date** (+ url when available); never fabricate — gather it live (WebSearch → web_fetch), the same mechanical-first discipline as the rest of the scout. The result is persisted to `data/news.json` and flows into the agenda's Investment feed (`investment.news[]`) so the "Latest fundamental news" block is populated on **every** run. Francis's framing: **the agenda is a daily newspaper about his company, work, and investment opportunities** — a newspaper always carries news.

*— Added 2026-07-07, source: user instruction (inline). Verbatim intent: "news should always be there every day, and refreshed every day … both the starting week process and the watch process … the news isn't always about the stocks themselves, it should be world events and company related events that affect the business's rating … think of my agenda as sort of a newspaper about my company, work and investment opportunities."*
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Claude never buys automatically. A weekly budget (default $50) buys exactly ONE stock, only on explicit `spend` invocation." -->
CHECKPOINT — No-Auto-Buy Gate (fires before ANY order-placement action):
1. An order may be placed ONLY inside the `spend` workflow, and ONLY when the current turn's user input explicitly invoked `/invest spend`.
2. IF an order placement is contemplated from any other mode (`scout`, `status`, `watch`, `ledger`, `budget`) → STOP. Never place it. Report: "Buying requires explicit `/invest spend <stock_id>`."
3. Within `spend`: confirm the resolved amount and stock with the user before sending. IF unconfirmed → STOP.
4. Never place more than ONE buy per calendar week (check `data/suggestions.json` week marker + `data/holdings.json`). IF a buy already exists this week → STOP and report.
5. The order runs against the PAPER endpoint (`ALPACA_PAPER_TRADE=True`). Never place a live order without an explicit, separate go-live decision recorded in config.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Technical indicators are subordinate timing confirmation only — never an override." + "The 200/20 MA and RSI are minor confirming indicators, secondary to the fundamental score." -->
CHECKPOINT — Fundamentals-First Gate (fires whenever a stock is selected or ranked):
1. A stock qualifies as a suggestion ONLY by clearing its fundamental-score threshold (Directive 6 dual bar: dividend payers at the normal bar, non-payers at the higher bar).
2. The 200/20 MA and RSI may only ADJUST an already-qualified pick's entry framing or display — they may NEVER promote an unqualified stock or veto a qualified one.
3. IF a ranking or suggestion is driven by a technical indicator rather than the fundamental score → STOP. Re-rank by score.
<!-- END ENFORCEMENT ANNOTATION -->

---

<!-- origin: skill-builder | version: 1.0 | modifiable: true -->
## Architecture (read [references/strategy.md](references/strategy.md) first)

Three layers, mechanical-first, AI-vetted:
1. **Mechanical gather** — SEC filings via the `edgartools` MCP (or `scripts/edgar_pull.py`), news via WebSearch + web_fetch, prices/MA via the `alpaca` MCP (or `scripts/ma.py`). No AI invents data.
2. **AI vet** — an agent scores news relevance/sentiment, characterizes filing changes, and judges catastrophe proximity. Subordinate to layer 1; live data only (never on backtests — LLM look-ahead bias).
3. **Composite score** — hierarchical, decay-ordered, sector-relative, dual-threshold. See [references/scoring.md](references/scoring.md).

Point-in-time discipline is mandatory: timestamp every input by its publication/filing datetime, never fiscal period.

## Workflow: screen  (mechanical universe builder — no AI in the data path)

Run `python3 scripts/screen.py` (add `--force` to ignore the freshness window).
The script is fully deterministic: it enumerates every SEC filer in the configured
tech + food/staples SIC codes (browse-edgar listings, cached 30 days), maps CIK→ticker,
pulls bulk fundamentals for ALL of them via the XBRL frames API (~25 requests cover
~5,000 filers — revenue growth, operating/net/FCF margins, dividend-payer flag),
computes a coarse sector-relative pre-score, drops non-tradable/non-fractionable
symbols (Alpaca assets API), and writes the top-N-per-sector shortlist to
`data/universe.json`. **No agent reads the bulk data and nothing is truncated by
judgment — the cut is a mechanical rank.** The pre-score is a coarse filter only;
the composite from `score.py` still governs suggestions (Directive 7).

## Workflow: scout

1. Read `data/config.json` (universe, thresholds, budget) and `references/scoring.md`.
1.5. **Screen (mechanical):** run `python3 scripts/screen.py` — it no-ops if `data/universe.json` is younger than `universe.screen.refresh_days`, else rebuilds the sector-wide shortlist (see § Workflow: screen). The candidate list for the steps below = the `shortlist` in `data/universe.json` (`score.py --universe` reads it automatically).
2. **Gather (mechanical):** for each universe candidate — pull latest 10-K/10-Q via `edgartools` MCP (`edgar_company`, `edgar_filing`); compute the Lazy-Prices year-over-year filing-change measure (`scripts/edgar_pull.py` returns risk-factors text + hash); pull recent firm news via WebSearch → verify with web_fetch. Timestamp everything point-in-time.
3. **Vet (AI — leaf sub-scores ONLY):** spawn a scoring agent (see § Scoring Agent) to return, per candidate, just the leaf inputs — `news_sentiment` (−1..+1), `filing_change` (none/minor/material), `catastrophe_proximity` (none/indirect/direct), `cycle_read` (none/early/mid/crested — cyclical subsectors only), plus per material news item a `polarity` + date. The agent never assigns the composite and never sees prices (per `references/scoring.md` § Reading discipline).
3.5. **Reaction (mechanical):** for each candidate with a material dated news item, run `python3 scripts/reaction.py <ticker> <news_date> --polarity <positive|negative>` (most recent material item wins). It measures the ~5-day closed-bar reaction, conditions it on the 200/20-day MA regime, trend-break state, and 20-vs-200 reversion gap, and returns the `expectation_reaction` classification — pass it into the candidate's `leaf` for Step 4. "Score the reaction, not the headline."
4. **Score (mechanical — `scripts/score.py`):** run `python3 scripts/score.py '<json array of {ticker, sector, leaf?}>'`. It computes the **hierarchical, sector-relative composite** from live SEC XBRL fundamentals (revenue growth, gross/operating/FCF margins, debt/equity, ROE) plus **dividend quality** (yield-based payer flag at ≥1%, yield + growth-streak rewarded), normalized WITHIN tech and within food/staples, then folds in the Step-3 leaf sub-scores as bounded adjustments and applies the dual-threshold dividend-first penalty (Directive 6). Mechanical and reproducible — same inputs → same score. `score.py` owns the composite; the agent only feeds it.
5. **Rank + stable pick:** produce ranked suggestions. Carry forward last week's top pick unless something material broke (Directive: stable weekly pick). **Divergence check (scoring.md § Reading discipline):** for any suggestion with `root >= 0.60` whose price sits below its 200-day MA (`scripts/ma.py` trend red) or whose `expectation_reaction` is in the crowded family, source a one-line "why" from the gathered news (rotation, cycle fears, litigation…) and carry it as `divergence` on the pick; if nothing explains it, write "unexplained — caution". Write `data/suggestions.json` (week marker, picks, top).
5b. **Persist the weekly score + panel data (Directive 7).** For each pick, **append this week's full score record to `data/score_history.json`** — `{ "<TICKER>": [ {week, score, adjustments, cycle_read} ] }` where `adjustments` is `score.py`'s per-leaf breakdown and `cycle_read` its validated cycle value (both straight from the score output — they feed the flip-flop freeze and the `/invest review` calibration; a composite alone can't be calibrated). Exactly one point per ISO week, **never backfilled** (the composite is point-in-time). For the agenda dropdown panel, each suggestion carried into the feed also gets: `score` (current composite), `scoreHistory` (that ticker's array from `score_history.json` — drives the trend sparkline + week-over-week delta), and `series` (the ~6-month weekly `close`/`ma20`/`ma200` line from `scripts/ma.py <ticker>` for the price chart).
5c. **Fold in user pins (comparison candidates).** Read `data/pins.json`; **drop expired pins** (`expires_week` < current ISO week) and rewrite the file. Score each still-active pinned ticker through the SAME gather→vet→score path as a pick (so the comparison is apples-to-apples), append its weekly score to `score_history.json`, and add it to the feed's `suggestions` — ranked by score alongside the picks — with `pinned: true` and `pinnedUntil: "<expires_week>"`. A pin is **never** the stable `top` pick and never carries a Buy affordance; it is comparison-only.
6. **News (Directive 9 — mandatory, never empty):** run the daily **News Gather** (see § News Gather) and write `data/news.json`. Scope is NOT just the picks' tickers — include world/macro/geopolitical events and company-specific events that move a rating (war theaters, disasters local to a company's assets, regulatory/sector shifts, macro shocks), each with a real source + date (+ url). This is the same news that fed the score in steps 2–4, surfaced for the reader.
7. **Auto-measurement (calibration):** if `data/score_history.json` spans ≥ `config.review.min_history_weeks` of ISO weeks AND the newest `data/review-*.json` (or `calibration_log.json` entry) is older than `config.review.cadence_weeks` → **run `python3 scripts/review.py` now** (mechanical, read-only — it only measures and writes `data/review-<date>.json`, never changes a parameter). Add a one-line digest to the scout report and the agenda feed note: composite IC per horizon + any non-INSUFFICIENT signal verdicts, e.g. "📐 calibration measured: IC +0.31 @8w; `crowded` CONTRADICTED @4w — run `/invest review` for proposals". The judgment half (interpretation, proposals, approval) still ONLY happens in an explicit `/invest review`.
8. Report the shortlist with the one-line fundamental reason each, plus the news headlines. **Never buys.**

## Workflow: status (default)

1. Read `data/holdings.json`, `data/realized.json`, `data/suggestions.json`, `data/config.json`.
2. For each holding: run `scripts/ma.py <ticker>` for the 200-day distance ("number 2", green/red) and `scripts/ledger.py pl <ticker>` for the full-holding P/L ("number 1").
3. Print two sections: **Owned** (holdings + P/L + MA read) and **Suggestions** (this week's picks; whether a buy has been made this week).

## Workflow: spend  (HUMAN-APPROVED BUY — see No-Auto-Buy Gate above)

1. Require explicit `/invest spend [amount] <stock_id>`. Resolve amount = arg or `config.weekly_budget_usd` (default $50).
2. Confirm no buy has been made this calendar week (Gate clause 4).
3. Run `scripts/ma.py <stock_id>` and show the fundamental score + MA read so the human sees what they're buying.
4. **Confirm with the user** the exact amount + stock. Only on explicit confirmation, place ONE notional order via the `alpaca` MCP (paper). Order placement lives in `scripts/place_order.py`, which is dry-run by default and requires `--execute` — NEVER run during scouting or scaffolding.
5. On fill: append a lot to `data/holdings.json` (`stock_id, date, fill_price, shares, notional`), snapshot the current score into `score_history[stock_id]`, and mark the week's buy done.

## Workflow: budget

1. `/invest budget <amount>` → validate positive number → write `config.weekly_budget_usd` → confirm the new persisted weekly amount.

## Workflow: ledger

1. Read and pretty-print `data/holdings.json` (per-lot + score history) and `data/realized.json` (closed positions with realized P/L). Read-only.

## Workflow: watch  (holdings watchdog — Directive 7)

1. For each held stock: re-run the scout gather+vet+score path (live data) and append the new score to `score_history[stock_id]`.
2. Compare to `config.score.alert_floor`. IF a holding's score has fallen below the floor (with hysteresis), OR a hard red flag fired (catastrophe local to assets, filing-change red flag, structural sentiment break) → **ALERT Francis** with the reason and the score trajectory.
3. **Daily News refresh (Directive 9 — mandatory, runs every day even with zero holdings):** run the § News Gather over the held stocks (if any) AND this week's suggestions/universe, plus the world/macro layer, and **overwrite `data/news.json`** with the day's fresh items (world/company events affecting ratings; each with source + date + url). This is what keeps the agenda's newspaper current between weekly scouts — the section is never empty.
4. Never sells. A sell is Francis's decision (Directive 8); if he decides to exit, `scripts/ledger.py close <ticker>` moves all lots to the realized ledger (HIFO only for a partial trim).

## Workflow: pin  (temporary comparison candidates)

Pin a ticker into this week's suggestions so it rides alongside the scored picks —
purely to compare (its score trend + price chart) against what the tool chose. A pin
is **never a recommendation**: it is not the stable `top`, and it shows no Buy affordance.

- **`/invest pin <stock_id> [weeks]`** — validate the ticker (`scripts/ma.py <stock_id>`
  must resolve), then add/update it in `data/pins.json` with `pinned_week` = current ISO
  week and `expires_week` = the LAST week it stays shown (inclusive) = current week +
  (`weeks` − 1), default `weeks` = **3** → visible for exactly 3 weeks (handle ISO-week
  year rollover). Score it now through the scout gather→vet→score path so it appears
  immediately, and append its score to `data/score_history.json`.
- **`/invest unpin <stock_id>`** — remove it from `data/pins.json`.
- **`/invest pins`** — list active pins with their `expires_week`.

Pins are re-scored every `scout` run and auto-expire (Step 5c) once `expires_week` passes.
`data/pins.json` shape: `{ "pins": [ { "ticker", "pinned_week", "expires_week" } ] }`.

## Workflow: review  (calibration retrospective — the system evaluates itself)

The track-record loop: once enough history exists, the system's recorded signals
are measured against what the market actually did, and the process gets adjusted
on evidence — never on narrative. See `references/scoring.md` § Calibration loop.

1. **Preconditions:** `data/score_history.json` spans ≥ `config.review.min_history_weeks`
   ISO weeks. If not, report "insufficient history (N of M weeks) — keep collecting"
   and STOP; never tune on thin data.
2. **Measure (mechanical):** reuse the newest `data/review-*.json` if it is
   from within the past 7 days (the scout's auto-measurement usually just ran
   it — Step 7 of the scout workflow); otherwise run `python3 scripts/review.py`
   now. The report computes, from stored point-in-time records only: the
   composite's Spearman IC vs forward returns per horizon (4/8/12 weeks),
   per-signal bucket returns (positive / negative / zero adjustment) with
   counts, and naive SUPPORTED / CONTRADICTED / MIXED / INSUFFICIENT verdicts
   (n < 5 on a side ⇒ INSUFFICIENT).
3. **Interpret (AI):** read the report and draft findings — which signals earned
   their weight, which contradicted, what stayed unmeasurable. Verdicts are flags,
   not conclusions: check confounds (one bad week, sector-wide moves, tiny n)
   before believing a CONTRADICTED.
4. **Propose (AI) — never apply:** for at most ONE or TWO parameters, propose a
   specific change (`old → new`) with the evidence lines from the report.
   Directive 4 discipline: prefer stable plateaus (a value that works across
   horizons), never chase the sharpest number, INSUFFICIENT means keep collecting.
5. **Approve (Francis) + log:** only on explicit approval, apply the change and
   append to `data/calibration_log.json`:
   `{ "date", "parameter", "old", "new", "evidence", "review_file" }`.
   Run `python3 scripts/selftest.py` BEFORE and AFTER any applied change; a
   failure reverts the change immediately.
6. The next review measures the change's effect — the calibration log is the
   process's own score history.

---

## Scoring Agent

When `scout`/`watch` needs judgment on gathered material, spawn a scoring agent
(Task, general-purpose) with a bespoke persona. It receives ONLY mechanically
gathered, point-in-time data and returns structured sub-scores (news sentiment,
filing-change characterization, catastrophe proximity, cycle read for cyclical
subsectors, and per-item news polarity+date for the mechanical reaction pass).
It never fetches its own data, never sees future-dated information, and never
sees prices — the `expectation_reaction` leaf is computed by `scripts/reaction.py`,
not the agent. The agent applies the reading discipline in
[references/scoring.md](references/scoring.md) § Reading discipline (reaction
over headline, cycle awareness, rotation as context, structure as data).

---

## News Gather (Directive 9 — shared by scout + watch)

The daily news pass. Mechanical-first, never fabricated, and **never empty** — a
newspaper always carries news. Both `scout` (weekly) and `watch` (daily) call this
and write `data/news.json`. Every item carries a `group` so the agenda can file it
under a subheading: `subscription` (paid publications), `world` (other world/macro),
or `company` (ticker-specific).

1. **Premium Source Pulse (subscriptions — do this FIRST).** Discover + read from the
   subscribed publications — **Financial Times** (markets / companies / global-economy)
   and **New York Times** (business / DealBook / economy). Both scripts live at the
   **repo root** (`/home/francis/lab/odyssey-alive/scripts/`), NOT the skill's `scripts/`:
   - **Step 0 — SESSION CHECK COMES FIRST (before any news work, hard gate):** check BOTH
     sessions with the `session_status` MCP tool (`mcp__playwright-mcp__session_status`,
     `name: "ft"` probeUrl `https://www.ft.com/myft`; `name: "nyt"` probeUrl
     `https://www.nytimes.com/account`). The probe doubles as a **keepalive** — a fresh
     verdict writes the site's refreshed cookies back to the storageState artifact
     (rolling expiry), so checking daily is what KEEPS the sessions alive for weeks.
     - `fresh` → proceed.
     - `missing`/`stale` → **re-authenticate NOW, before proceeding**: run the
       `session_login` MCP tool (`mcp__playwright-mcp__session_login`, `headed: true`,
       `name: "ft"`/`"nyt"`, the site's `loginUrl` + a post-login `successSignal`) and
       WAIT for Francis to complete the FT university SSO+MFA or NYT login/bot challenge
       (the display is reachable during a run; session_login shares the stealth disguise,
       so PerimeterX-guarded login pages don't flag). **An expired session is never a
       reason to skip the source** — skipping is permitted ONLY when the run is headless
       /non-interactive (no display, no human), and then it must be reported LOUDLY: a
       "⚠ FT/NYT session expired — headed re-login required" line at the TOP of the run
       report AND in the agenda feed note, never a silent omission.
     - `unreachable` → the probe failed (network/site down), the session itself may be
       fine: retry once, then proceed with RSS-only for that source and note the outage.
     Sessions persist as mode-600 `storageState` artifacts; no password is stored in a
     reader. Every authed `web_fetch(session:…)` read ALSO writes back refreshed cookies,
     so normal daily reading extends session life indefinitely (bounded only by the
     publisher's absolute session cap / forced MFA re-challenge).
   - **Discover:** `node scripts/premium-news-feeds.js [--limit N]` prints recent FT + NYT
     articles as JSON (`source, title, url, date`) from the **public** RSS feeds (no auth).
     Scan those headlines for items bearing on the investing environment (macro/policy,
     rates, sector moves, company events, energy/minerals supply chains, geopolitics) —
     the NYT feeds carry some non-market items, so filter for rating relevance.
   - **Read full text — via playwright-mcp:** for each flagged item, call the `web_fetch`
     MCP tool (`mcp__playwright-mcp__web_fetch`) with `session: "ft"` for `ft.com` URLs and
     `session: "nyt"` for `nytimes.com` URLs. It renders the article in an **isolated,
     stealthed, session-seeded** context (authed cookies never touch the shared scraping
     profile) and returns readable text + a CSL-JSON citation. Anonymous `web_fetch` (no
     `session`) is unchanged for free sources.
   Tag these items `group: "subscription"`. IF a `web_fetch(session:…)` read comes back
   as a login/paywall wall (empty or `fetchStatus` blocked) despite a fresh Step-0 check
   → treat it as a stale session: go back to Step 0's re-authentication path (headed
   `session_login`, wait, then retry the read). Never skip silently and never fabricate
   a subscription item; a headless run that cannot re-login reports the expiry loudly
   per Step 0.
   - **EverydaySpy Daily Intelligence Brief (email, not RSS).** Pull the latest issue
     from Francis's iCloud inbox: `python3 scripts/newsletter-latest.py --from
     everydayspydib@mail.beehiiv.com --account icloud --since <~5 days ago, DD-Mon-YYYY>`
     (prints `{subject, date, body}`). The DIB is a **single-topic essay** that often
     ends in an EverydaySpy product pitch — it is NOT a sourced headline list. So apply
     a **strict market-relevance guard**: include something ONLY if the issue's theme
     genuinely bears on the investing environment (geopolitics/war, China/supply chains,
     energy/minerals, defense, macro/policy). When it does, do NOT link the newsletter's
     promo URLs — instead **find and verify a corroborating third-party article** (WebSearch
     → web_fetch) for the claim and cite THAT as the item's `source`/`url`, with a short
     note that the EverydaySpy DIB flagged it; tag it `group: "world"`. IF the latest DIB
     is off-topic (self-promo, lifestyle, tradecraft) → contribute nothing that day (this
     is the common case; never force an item).
2. **Open-web scope — three layers** (each item tagged with the matching `group`):
   - **World / macro (`world`):** geopolitical + macro events beyond the tickers — war
     theaters, natural disasters, rate/inflation/policy shifts, sector-wide regulation
     (Directives 1 + 7 catastrophe/macro inputs).
   - **Company-specific (`company`):** developments for held stocks + this week's
     suggestions that affect their rating (earnings, guidance, filings, product/tech
     deprecation, disasters local to assets); set `stockId`.
   - **Universe/sector (`world`):** tech and food/staples sector news relevant to the
     buy-and-hold thesis.
   Discover via WebSearch, then verify with `web_fetch`.
3. **Verify + timestamp:** confirm each candidate item; keep the real **source +
   publication date** (+ url). Point-in-time only — no future-dated items.
4. **Select:** keep the most rating-relevant items (aim ~6–10 across all groups),
   newest first, de-duplicated. Set `group` on every item and `stockId` on firm-specific ones.
5. **Write `data/news.json`:** `{ "date": "<YYYY-MM-DD>", "items": [ { "headline", "source", "date", "url?", "stockId?", "group" } ] }`. `scout` and `watch` both **overwrite** it with the current day's set (daily freshness). If a gather genuinely returns nothing, keep the prior file and note staleness — never write an empty `items` array silently.
6. The agenda `today` run reads this file into `investment.news[]` (see agenda html-render), so the browser view's "Latest Fundamental News" rail reflects it every day, grouped under its subheadings (subscriptions → world → companies).

---

<!-- origin: skill-builder | version: 1.0 | modifiable: true -->
## Grounding

Before using any threshold, weight, or schema:
1. Read the relevant file from `references/`.
2. State: "I will use [VALUE] for [PURPOSE], found in references/[file] under [SECTION]".

Reference files:
- [references/strategy.md](references/strategy.md) — the full fundamentals-first architecture, layers, and pipeline
- [references/scoring.md](references/scoring.md) — composite-score methodology, dual threshold, catastrophe inputs, scoring agent
- [references/ledger.md](references/ledger.md) — ledger schemas, P/L math, MA display numbers, HIFO, full-exit close

Config + data (skill-local):
- `data/config.json` — weekly budget, score thresholds/floor, universe + screen params (`universe.screen`: top-N, revenue floor, refresh window), paper flag
- `data/universe.json` — the mechanically screened candidate shortlist (top N per sector with pre-scores + coverage stats); rebuilt by `scripts/screen.py`, read by `score.py --universe`
- `data/holdings.json` — open holdings (per-lot) + per-stock score time-series
- `data/realized.json` — closed positions with realized P/L
- `data/suggestions.json` — current week's ranked suggestions + stable top pick
- `data/news.json` — the day's news (world/macro + company events affecting ratings), refreshed daily by `watch` and weekly by `scout` (Directive 9); read into the agenda's `investment.news[]`
- `data/score_history.json` — weekly score history per ticker (Directive 7): `{week, score, adjustments, cycle_read}`, one point per ISO week (never backfilled); appended by `scout` (picks) and `watch` (holdings), drives the panel's score trend, the cycle flip-flop freeze, and the `review` calibration
- `data/review-<date>.json` — mechanical calibration reports from `scripts/review.py` (signal-vs-forward-return retrospective)
- `data/calibration_log.json` — append-only record of APPROVED parameter changes (`{date, parameter, old, new, evidence, review_file}`); the process's own track record
- `data/pins.json` — user comparison pins (`{ pins: [{ ticker, pinned_week, expires_week }] }`); folded into the suggestions by `scout` Step 5c, auto-expiring

Scripts (deterministic; PROVEN read paths):
- `scripts/screen.py [--force|--dry-run]` — the **mechanical universe screener**: SIC-code sector sweep (browse-edgar) → bulk XBRL-frames pre-score of every filer → tradability filter → `data/universe.json` shortlist. Zero AI in the data path; auto-no-ops while the file is fresh
- `scripts/reaction.py <ticker> <news_date> --polarity positive|negative` — the **mechanical expectation-reaction classifier**: ~5-day closed-bar price reaction to a material news item, conditioned on the 200/20 MA regime, trend-break state, and 20-vs-200 reversion gap → `expectation_reaction` leaf for `score.py` ("score the reaction, not the headline"; see scoring.md § Reading discipline)
- `scripts/ma.py <ticker>` — 200/20-day MA + distance-from-200-day (the display "number 2"), plus a `series` of ~26 weekly `{date, close, ma20, ma200}` points for the panel line chart
- `scripts/edgar_pull.py <ticker>` — latest 10-K, financials availability, risk-factors text + hash (Lazy-Prices YoY input)
- `scripts/score.py '<[{ticker,sector,leaf?}]>'` — the **mechanical composite scorer**: sector-relative fundamentals from SEC XBRL + dividend quality (yield/streak), folds in the agent's leaf sub-scores, applies the dividend-first penalty. Reproducible; owns the composite (scoring.md is its spec)
- `scripts/ledger.py <cmd>` — P/L, HIFO selection, full-exit close, ledger read/write
- `scripts/place_order.py` — notional buy; **dry-run default, `--execute` required, never auto-run**
- `scripts/review.py [--horizons 4,8,12] [--min-n 5] [--dry-run]` — the **mechanical calibration retrospective**: stored point-in-time scores vs realized forward returns (composite IC + per-signal buckets + naive verdicts) → `data/review-<date>.json`. Measures only; proposals and approvals live in the `review` workflow
- `scripts/selftest.py` — no-network regression tests for the pure scoring logic (classification matrix, vol thresholds, corroboration gate, double-count guard, root gate). Run before AND after every calibration change

Credentials come from the repo `.env.local` (`ALPACA_API_KEY`, `ALPACA_SECRET_KEY`, `ALPACA_PAPER_TRADE=True`, `ALPACA_PAPER_BASE_URL`, `EDGAR_IDENTITY`). Never commit them. The News Gather's premium reads run **through the `playwright-mcp` server** (`session_login` / `session_status` / `web_fetch`), not the standalone reader: discovery pulls the **public** FT + NYT RSS feeds (`scripts/premium-news-feeds.js`), then full-text reads call `web_fetch` with `session: "ft"` / `session: "nyt"` against a session captured once via headed `session_login`. **Financial Times** is a university-SSO capture (no stored password); **New York Times** is captured headed (its PerimeterX bot-check blocks headless form login). session artifacts are mode-600 `storageState` files under the playwright-mcp sessions dir; the shared stealth disguise (`src/stealth.ts`) lets the login and the authed read pass bot detection. **Rolling keepalive (added 2026-07-13):** both `session_status` (on a fresh verdict) and `web_fetch(session:…)` (on a non-login-wall read) write the site's refreshed cookies back to the storageState file, so the daily watch's Step-0 probe + reads extend session life indefinitely — sessions expire only if unused past the publisher's rolling window or on a forced MFA re-challenge. See § News Gather.
<!-- /origin -->
