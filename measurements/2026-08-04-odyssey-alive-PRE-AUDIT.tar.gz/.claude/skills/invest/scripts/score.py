#!/usr/bin/env python3
"""score.py — mechanical, reproducible, sector-relative fundamentals scorer.

Long-only, dividend-first. Implements the HIERARCHICAL composite described in
`.claude/skills/invest/references/scoring.md`:

    Root  = fundamentals from XBRL financials  (highest structural weight)
    Mid   = filing-change signal               (Lazy-Prices YoY)   [leaf input]
    Leaf  = news sentiment / catastrophe        (soft, from Layer-2 agent)

The LLM/agent NEVER supplies the composite. It may only pass optional soft leaf
sub-scores (filing_change, sentiment, catastrophe). Everything structural — the
fundamentals, the sector-relative normalization, the dividend flag, and all of
the composite math — is computed here, mechanically, from the SEC XBRL API.

Data source (no LLM, fully reproducible):
  * Ticker->CIK   : https://www.sec.gov/files/company_tickers.json  (cached /tmp)
  * Company facts : https://data.sec.gov/api/xbrl/companyfacts/CIK##########.json
  * A self-identifying User-Agent (EDGAR_IDENTITY from .env.local) is required;
    SEC blocks requests without it. Calls are rate-limited to ~150ms apart.

--------------------------------------------------------------------------------
WEIGHTS & BANDS BELOW ARE INITIAL — CALIBRATE IN PAPER TRADING.
--------------------------------------------------------------------------------

Per-metric absolute-quality bands (linear, clamped 0..1):
    gross_margin      0.00 -> 0 ,  0.60 -> 1
    operating_margin  0.00 -> 0 ,  0.35 -> 1
    fcf_margin        0.00 -> 0 ,  0.30 -> 1
    revenue_growth   -0.05 -> 0 ,  0.25 -> 1
    debt_to_equity    2.00 -> 0 ,  0.00 -> 1   (inverted: less debt is better)
    roe               0.00 -> 0 ,  0.40 -> 1
    dividend_quality  identity (already 0..1; see below)

Dividend-first is "Balanced — reward yield": yield is BOTH a gate and a positive
root metric.
  * PAYER FLAG is yield-based (not mere presence): dividend = (yield >= INCOME_GRADE_YIELD_MIN, 0.5%), where
    yield = trailing-annual dividend-per-share / current price. This fixes the
    token-dividend bug — NVDA (~0.02% yield) is classed non-payer and takes the
    -8 growth penalty, even though it declares a nominal dividend.
  * dividend_quality (0..1) = 0.6*yield_band + 0.4*streak_band, and 0 for non-payers.
      yield_band : 0%->0, 2.5%->0.8, 4%->1.0, plateau to 5%, then TAPER down (a
                   >6% yield usually signals distress, so it is not over-rewarded).
      streak_band: consecutive years of rising annual DPS; 0yr->0, 25yr->1 (King).

Sector-relative blend (robust for small n):
    per_metric = 0.6 * absolute_quality + 0.4 * sector_percentile_rank

Root fundamentals (0..1), weighted sum of the blended per-metric scores. The six
fundamental weights below sum to 1.00; dividend_quality is folded in at .18 and the
other six are scaled by 0.82 so the total stays 1.00:
    revenue_growth .20   gross_margin .12   operating_margin .20
    fcf_margin     .20   debt_to_equity .10 roe              .18
    dividend_quality .18 (others *0.82)   -> effective total 1.00

Composite base = Root * 100.

Leaf adjustments (optional per-ticker; default neutral):
    filing_change : none 0 / minor -2 / material -6
    sentiment     : (-1..+1) magnitude 6, applied CONTRARIAN-conditional on Root
    catastrophe   : none 0 / indirect -5 / direct -12
    expectation_reaction (MECHANICAL, from scripts/reaction.py — never the agent):
                    none 0 / confirming +2 / confirming_reversal +4 /
                    crowded -4 / crowded_extended -7 / crowded_reversion -8 /
                    washed_out +3 / washed_out_depressed +5 / washed_out_reversion +6
                    Bonuses beyond plain `confirming` require root >= 0.55
                    (no contrarian credit for weak fundamentals); penalties
                    always apply.
    cycle_read    : (agent, cyclical subsectors only — semis/ag/commodity food;
                    requires corroboration per scoring.md)
                    none 0 / early +1 / mid 0 / crested -4
    dividend-first penalty : non-dividend payers (yield<1%) -8  ("higher bar")

    Double-count guard: when sentiment and expectation_reaction adjustments
    agree in sign (usually the same news event scored twice), the weaker of
    the two is halved before summing.

    composite = clamp(base + filing + sentiment + catastrophe + reaction
                      + cycle - div_penalty, 0, 100)
"""

import json
import os
import sys
import time
import urllib.request

ENV_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))), ".env.local")
TICKERS_CACHE = "/tmp/sec_company_tickers.json"
FACTS_CACHE_DIR = "/tmp/sec_companyfacts"
REQUEST_GAP_S = 0.15

# ---------------------------------------------------------------------------
# Root fundamentals weights — INITIAL, calibrate in paper trading.
# The six fundamental weights sum to 1.00; dividend_quality is folded in at .18
# and the six are scaled by (1-.18)=0.82 so the effective total stays 1.00.
# ---------------------------------------------------------------------------
DIVIDEND_QUALITY_WEIGHT = 0.18
# Income-grade yield gate — a real dividend name vs a token/growth one. Below this,
# the −8 dividend-first penalty applies and dividend_quality is 0. 0.5% keeps genuine
# low-yield growers (e.g. MSFT ~0.85%) as payers while still catching token yields
# (NVDA ~0.02%). INITIAL — calibrate in paper trading.
INCOME_GRADE_YIELD_MIN = 0.005
_FUNDAMENTAL_WEIGHTS = {
    "revenue_growth": 0.20,
    "gross_margin": 0.12,
    "operating_margin": 0.20,
    "fcf_margin": 0.20,
    "debt_to_equity": 0.10,
    "roe": 0.18,
}
ROOT_WEIGHTS = {k: v * (1 - DIVIDEND_QUALITY_WEIGHT)
                for k, v in _FUNDAMENTAL_WEIGHTS.items()}
ROOT_WEIGHTS["dividend_quality"] = DIVIDEND_QUALITY_WEIGHT
# DPS concept fallbacks (merged): filers switch between these over time.
DPS_NAMES = ["CommonStockDividendsPerShareDeclared",
             "CommonStockDividendsPerShareCashPaid"]

# Last-resort seed list — used by --universe ONLY when data/universe.json
# (the mechanical screen output from scripts/screen.py) is missing.
DEFAULT_UNIVERSE = [
    {"ticker": "MSFT", "sector": "tech"},
    {"ticker": "TXN", "sector": "tech"},
    {"ticker": "CSCO", "sector": "tech"},
    {"ticker": "IBM", "sector": "tech"},
    {"ticker": "QCOM", "sector": "tech"},
    {"ticker": "NVDA", "sector": "tech"},
    {"ticker": "KO", "sector": "food_staples"},
    {"ticker": "PG", "sector": "food_staples"},
    {"ticker": "PEP", "sector": "food_staples"},
]
UNIVERSE_PATH = os.path.join(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__))), "data", "universe.json")
SCORE_HISTORY_PATH = os.path.join(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__))), "data", "score_history.json")


def load_universe():
    """Screened shortlist from scripts/screen.py, else the legacy seed list."""
    if os.path.exists(UNIVERSE_PATH):
        with open(UNIVERSE_PATH) as fh:
            shortlist = json.load(fh).get("shortlist", [])
        if shortlist:
            return [{"ticker": r["ticker"], "sector": r["sector"]}
                    for r in shortlist]
    print("universe.json missing/empty — falling back to legacy seed list; "
          "run scripts/screen.py", file=sys.stderr)
    return DEFAULT_UNIVERSE

# us-gaap concept fallbacks. "duration" = flow (income/cashflow over a period);
# "instant" = balance-sheet point-in-time value.
CONCEPTS = {
    "revenue": (["RevenueFromContractWithCustomerExcludingAssessedTax",
                 "Revenues", "SalesRevenueNet",
                 "RevenueFromContractWithCustomerIncludingAssessedTax"], "duration"),
    "gross_profit": (["GrossProfit"], "duration"),
    "cost_of_revenue": (["CostOfRevenue", "CostOfGoodsAndServicesSold",
                         "CostOfGoodsSold"], "duration"),
    # OperatingIncomeLoss is preferred; some filers (e.g. IBM) never tag it, so
    # fall back to pre-tax continuing-ops income as an operating proxy.
    "operating_income": (["OperatingIncomeLoss",
                          "IncomeLossFromContinuingOperationsBeforeIncomeTaxesExtraordinaryItemsNoncontrollingInterest",
                          "IncomeLossFromContinuingOperationsBeforeIncomeTaxesMinorityInterestAndIncomeLossFromEquityMethodInvestments"],
                         "duration"),
    "net_income": (["NetIncomeLoss", "ProfitLoss"], "duration"),
    "equity": (["StockholdersEquity",
                "StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest"],
               "instant"),
    "lt_debt_noncurrent": (["LongTermDebtNoncurrent",
                            "LongTermDebtAndCapitalLeaseObligationsNoncurrent"], "instant"),
    "lt_debt_current": (["LongTermDebtCurrent",
                         "LongTermDebtAndCapitalLeaseObligationsCurrent"], "instant"),
    "long_term_debt": (["LongTermDebt", "LongTermDebtAndCapitalLeaseObligations",
                        "DebtLongtermAndShorttermCombinedAmount"], "instant"),
    "liabilities": (["Liabilities"], "instant"),
    "operating_cash_flow": (["NetCashProvidedByUsedInOperatingActivities",
                             "NetCashProvidedByUsedInOperatingActivitiesContinuingOperations"],
                            "duration"),
    "capex": (["PaymentsToAcquirePropertyPlantAndEquipment",
               "PaymentsToAcquireProductiveAssets"], "duration"),
}


# ---------------------------------------------------------------------------
# SEC data access
# ---------------------------------------------------------------------------
def load_identity():
    ua = os.environ.get("EDGAR_IDENTITY")
    if ua:
        return ua.strip().strip('"').strip("'")
    try:
        with open(ENV_PATH) as fh:
            for line in fh:
                line = line.strip()
                if line.startswith("#") or "EDGAR_IDENTITY" not in line:
                    continue
                _, _, val = line.partition("=")
                return val.strip().strip('"').strip("'")
    except OSError:
        pass
    raise SystemExit("EDGAR_IDENTITY not found (env or .env.local); SEC requires it.")


IDENTITY = load_identity()


def _get(url):
    req = urllib.request.Request(url, headers={
        "User-Agent": IDENTITY,
        "Accept-Encoding": "gzip, deflate",
        "Host": urllib.request.urlparse(url).netloc if hasattr(urllib.request, "urlparse") else None,
    })
    # urllib has no urlparse attr; build headers cleanly:
    req = urllib.request.Request(url, headers={"User-Agent": IDENTITY})
    with urllib.request.urlopen(req, timeout=60) as resp:
        raw = resp.read()
    return raw


def load_ticker_map():
    if not os.path.exists(TICKERS_CACHE):
        raw = _get("https://www.sec.gov/files/company_tickers.json")
        with open(TICKERS_CACHE, "wb") as fh:
            fh.write(raw)
        time.sleep(REQUEST_GAP_S)
    with open(TICKERS_CACHE) as fh:
        data = json.load(fh)
    out = {}
    for row in data.values():
        out[row["ticker"].upper()] = int(row["cik_str"])
    return out


def load_company_facts(cik):
    os.makedirs(FACTS_CACHE_DIR, exist_ok=True)
    padded = f"CIK{cik:010d}"
    cache = os.path.join(FACTS_CACHE_DIR, f"{padded}.json")
    if not os.path.exists(cache):
        url = f"https://data.sec.gov/api/xbrl/companyfacts/{padded}.json"
        raw = _get(url)
        with open(cache, "wb") as fh:
            fh.write(raw)
        time.sleep(REQUEST_GAP_S)
    with open(cache) as fh:
        return json.load(fh)


# ---------------------------------------------------------------------------
# XBRL extraction
# ---------------------------------------------------------------------------
def _days(start, end):
    from datetime import date
    y1, m1, d1 = (int(x) for x in start.split("-"))
    y2, m2, d2 = (int(x) for x in end.split("-"))
    return (date(y2, m2, d2) - date(y1, m1, d1)).days


def concept_fy_values(facts, names, kind):
    """Return {data_year: value} for an annual (10-K, fp=FY) concept.

    IMPORTANT XBRL gotcha: the `fy`/`fp` fields describe the *filing context*,
    not the data period. A 10-K filed for FY2025 also restates FY2024 and FY2023
    as comparatives, and ALL three carry fy=2025/fp=FY — distinguished only by
    their period `end` date. So we key each fact by the calendar year of its
    period END (the real data year), not by the `fy` tag.

    For 'duration' (flow) concepts only full-year periods (~365 days) are kept,
    so a Q4-only stub inside a 10-K can't masquerade as the annual figure.

    Fallback concepts are MERGED (not first-wins): a single filer can switch tags
    over time (e.g. NVDA reports recent revenue under `Revenues` but older years
    under `RevenueFromContractWithCustomerExcludingAssessedTax`), so we take the
    union across all fallback names. For a given data year the most-recently-filed
    value wins; ties break toward the earlier-listed (preferred) concept.
    """
    gaap = facts.get("facts", {}).get("us-gaap", {})
    best = {}  # data_year -> (filed, priority, val)
    for prio, name in enumerate(names):
        node = gaap.get(name)
        if not node:
            continue
        for entries in node.get("units", {}).values():
            for e in entries:
                if e.get("fp") != "FY":
                    continue
                if not e.get("form", "").startswith("10-K"):
                    continue
                end, val = e.get("end"), e.get("val")
                if end is None or val is None:
                    continue
                if kind == "duration":
                    start = e.get("start")
                    if not start or not (330 <= _days(start, end) <= 400):
                        continue
                year = int(end[:4])
                filed = e.get("filed", "")
                cur = best.get(year)
                if cur is None or filed > cur[0] or (filed == cur[0] and prio < cur[1]):
                    best[year] = (filed, prio, val)
    return {y: v[2] for y, v in best.items()}


def pick_two_years(fy_map):
    years = sorted(fy_map.keys(), reverse=True)
    return years[:2]


def extract_metrics(facts):
    vals = {k: concept_fy_values(facts, names, kind)
            for k, (names, kind) in CONCEPTS.items()}

    rev_map = vals["revenue"]
    if not rev_map:
        return None, {"error": "no revenue concept found"}
    years = pick_two_years(rev_map)
    if not years:
        return None, {"error": "no fiscal years found"}
    cur = years[0]
    prev = years[1] if len(years) > 1 else None

    def at(metric, fy):
        return vals[metric].get(fy)

    revenue = at("revenue", cur)
    rev_prev = at("revenue", prev) if prev is not None else None

    # Gross profit: direct, else revenue - cost of revenue.
    gross = at("gross_profit", cur)
    if gross is None and revenue is not None:
        cor = at("cost_of_revenue", cur)
        if cor is not None:
            gross = revenue - cor

    op_inc = at("operating_income", cur)
    net_inc = at("net_income", cur)
    equity = at("equity", cur)
    opcash = at("operating_cash_flow", cur)
    capex = at("capex", cur)

    # Debt: LT noncurrent (+ LT current) -> LongTermDebt -> Liabilities.
    ltn = at("lt_debt_noncurrent", cur)
    ltc = at("lt_debt_current", cur)
    debt = None
    debt_basis = None
    if ltn is not None:
        debt = ltn + (ltc or 0)
        debt_basis = "LongTermDebtNoncurrent(+Current)"
    elif at("long_term_debt", cur) is not None:
        debt = at("long_term_debt", cur)
        debt_basis = "LongTermDebt"
    elif at("liabilities", cur) is not None:
        debt = at("liabilities", cur)
        debt_basis = "Liabilities(fallback)"

    def ratio(num, den):
        if num is None or den in (None, 0):
            return None
        return num / den

    revenue_growth = None
    if revenue is not None and rev_prev not in (None, 0):
        revenue_growth = (revenue - rev_prev) / rev_prev

    fcf = None
    if opcash is not None and capex is not None:
        fcf = opcash - capex

    metrics = {
        "fiscal_year": cur,
        "prior_fiscal_year": prev,
        "revenue": revenue,
        "revenue_growth": revenue_growth,
        "gross_margin": ratio(gross, revenue),
        "operating_margin": ratio(op_inc, revenue),
        "net_margin": ratio(net_inc, revenue),
        "fcf_margin": ratio(fcf, revenue),
        "debt_to_equity": ratio(debt, equity),
        "roe": ratio(net_inc, equity),
        "debt_basis": debt_basis,
    }
    # Dividend classification (yield-based) is handled separately by
    # analyze_dividend(), which needs the current price.
    return metrics, {}


# ---------------------------------------------------------------------------
# Dividend analysis (yield-based flag + dividend_quality)
# ---------------------------------------------------------------------------
MA_SCRIPT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ma.py")


def get_price(ticker):
    """Current price = last_close from ma.py (reads Alpaca keys from .env.local)."""
    import subprocess
    try:
        out = subprocess.run(
            [sys.executable, MA_SCRIPT, ticker],
            capture_output=True, text=True, timeout=60,
            cwd=os.path.dirname(MA_SCRIPT))
        data = json.loads(out.stdout or "{}")
        return data.get("last_close")
    except Exception:  # noqa: BLE001
        return None


def annual_dps_series(facts):
    """{data_year: annual DPS}. Prefers the annual-tagged (fp=FY, ~365d) value;
    for filers that only tag DPS quarterly (e.g. KO), sums the four quarters that
    fall in each calendar year (dedup by period-end, most-recently-filed wins)."""
    annual = concept_fy_values(facts, DPS_NAMES, "duration")
    # quarterly fallback for years annual tagging doesn't cover
    gaap = facts.get("facts", {}).get("us-gaap", {})
    q = {}  # end_date -> (filed, val)
    for name in DPS_NAMES:
        node = gaap.get(name)
        if not node:
            continue
        for entries in node.get("units", {}).values():
            for e in entries:
                start, end, val = e.get("start"), e.get("end"), e.get("val")
                if not start or not end or val is None:
                    continue
                if not (75 <= _days(start, end) <= 100):  # a quarter
                    continue
                filed = e.get("filed", "")
                if end not in q or filed > q[end][0]:
                    q[end] = (filed, val)
    q_by_year = {}
    for end, (_, val) in q.items():
        q_by_year.setdefault(int(end[:4]), []).append(val)
    q_annual = {y: round(sum(v), 4) for y, v in q_by_year.items() if len(v) >= 4}
    series = dict(q_annual)
    series.update(annual)  # annual-tagged wins where present
    return series


def dividend_growth_streak(series):
    """Consecutive years of rising annual DPS, counting back from the latest year.
    Bounded by EDGAR XBRL history depth (~2009+), so long-tenured Dividend Kings
    will UNDERCOUNT — the streak reflects the tagged record, not the true history."""
    years = sorted(series.keys())
    if len(years) < 2:
        return 0
    streak = 0
    for i in range(len(years) - 1, 0, -1):
        y, py = years[i], years[i - 1]
        if py != y - 1:            # gap in the record breaks the chain
            break
        if series[y] > series[py]:
            streak += 1
        else:
            break
    return streak


def trailing_annual_dps(facts, series, current_fy):
    """Trailing-annual DPS for the yield calc: the annual-tagged value when it
    covers the current FY, else the sum of the four most-recent quarterly
    declarations (true TTM), else the latest annual value on record."""
    if series and max(series) >= current_fy:
        return series[max(series)]
    # four most-recent quarterly declarations
    gaap = facts.get("facts", {}).get("us-gaap", {})
    q = {}
    for name in DPS_NAMES:
        node = gaap.get(name)
        if not node:
            continue
        for entries in node.get("units", {}).values():
            for e in entries:
                start, end, val = e.get("start"), e.get("end"), e.get("val")
                if not start or not end or val is None:
                    continue
                if not (75 <= _days(start, end) <= 100):
                    continue
                filed = e.get("filed", "")
                if end not in q or filed > q[end][0]:
                    q[end] = (filed, val)
    if len(q) >= 4:
        recent = sorted(q.items())[-4:]
        return round(sum(v for _, (_, v) in recent), 4)
    return series[max(series)] if series else 0.0


def yield_band(y):
    """0%->0, 2.5%->0.8, 4%->1.0, plateau to 5%, then taper (>5% ~ distress)."""
    if y is None or y <= 0:
        return 0.0
    if y < 0.025:
        return (y / 0.025) * 0.8
    if y < 0.04:
        return 0.8 + (y - 0.025) / 0.015 * 0.2
    if y <= 0.05:
        return 1.0
    return max(0.6, 1.0 - (y - 0.05) / 0.03 * 0.4)   # taper to a 0.6 floor


def streak_band(years):
    return clamp01(years / 25.0)   # 25+ consecutive raises = Dividend King -> 1


def analyze_dividend(facts, current_fy, ticker):
    series = annual_dps_series(facts)
    price = get_price(ticker)
    dps = trailing_annual_dps(facts, series, current_fy) if series else 0.0
    dyield = (dps / price) if (price and dps) else (0.0 if price else None)
    streak = dividend_growth_streak(series)
    is_payer = (dyield is not None and dyield >= INCOME_GRADE_YIELD_MIN)
    if is_payer:
        dq = 0.6 * yield_band(dyield) + 0.4 * streak_band(streak)
    else:
        dq = 0.0
    return {
        # income_payer: yield-gated (>=1%) — drives the dividend-first SCORE penalty.
        "dividend": is_payer,
        # pays_dividend: factual — does it pay ANY dividend at all? Drives the display
        # chip ("Dividend" vs "Growth"), independent of yield. NVDA (token) => True.
        "pays_dividend": bool(dps and dps > 0),
        "yield": None if dyield is None else round(dyield, 4),
        "annual_dps": round(dps, 4) if dps else 0.0,
        "price": price,
        "streak": streak,
        "dividend_quality": round(clamp01(dq), 4),
    }


# ---------------------------------------------------------------------------
# Scoring
# ---------------------------------------------------------------------------
def clamp01(x):
    return max(0.0, min(1.0, x))


def band(value, lo, hi):
    if value is None:
        return None
    return clamp01((value - lo) / (hi - lo))


def absolute_quality(metric, value):
    if value is None:
        return None
    if metric == "gross_margin":
        return band(value, 0.0, 0.60)
    if metric == "operating_margin":
        return band(value, 0.0, 0.35)
    if metric == "fcf_margin":
        return band(value, 0.0, 0.30)
    if metric == "revenue_growth":
        return band(value, -0.05, 0.25)
    if metric == "debt_to_equity":
        # inverted: 0 debt -> 1, 2.0x -> 0
        return clamp01(1.0 - (value - 0.0) / (2.0 - 0.0))
    if metric == "roe":
        return band(value, 0.0, 0.40)
    if metric == "dividend_quality":
        return clamp01(value)   # already a 0..1 composite; identity
    return None


def oriented(metric, value):
    """Orient a raw metric so that higher == better (for percentile ranking)."""
    if value is None:
        return None
    return -value if metric == "debt_to_equity" else value


def percentile_rank(value, peers):
    """Fraction-of-peers rank in 0..1 (mid-rank for ties). Single-name -> 0.5."""
    vals = [p for p in peers if p is not None]
    if not vals or value is None:
        return 0.5
    below = sum(1 for p in vals if p < value)
    equal = sum(1 for p in vals if p == value)
    return (below + 0.5 * equal) / len(vals)


def score_universe(entries):
    # 1) fetch + extract every ticker
    tmap = load_ticker_map()
    rows = []
    for ent in entries:
        ticker = ent["ticker"].upper()
        sector = ent.get("sector", "unknown")
        leaf = ent.get("leaf", {}) or {}
        cik = tmap.get(ticker)
        if cik is None:
            rows.append({"ticker": ticker, "sector": sector,
                         "error": "ticker not in SEC map"})
            continue
        try:
            facts = load_company_facts(cik)
            metrics, meta = extract_metrics(facts)
        except Exception as e:  # noqa: BLE001
            rows.append({"ticker": ticker, "sector": sector,
                         "error": f"{type(e).__name__}: {e}"})
            continue
        if metrics is None:
            rows.append({"ticker": ticker, "sector": sector, "error": meta.get("error")})
            continue
        div = analyze_dividend(facts, metrics["fiscal_year"], ticker)
        metrics["dividend_quality"] = div["dividend_quality"]
        rows.append({"ticker": ticker, "sector": sector, "leaf": leaf,
                     "metrics": metrics, "div": div})

    good = [r for r in rows if "metrics" in r]

    # 2) sector-relative percentile inputs (oriented raw values per sector)
    sectors = {}
    for r in good:
        sectors.setdefault(r["sector"], []).append(r)
    peer_values = {}  # (sector, metric) -> list of oriented raw values
    for sector, members in sectors.items():
        for metric in ROOT_WEIGHTS:
            peer_values[(sector, metric)] = [
                oriented(metric, m["metrics"].get(metric)) for m in members]

    # 3) score each good row
    results = []
    for r in good:
        m = r["metrics"]
        sector = r["sector"]
        per_metric = {}
        for metric in ROOT_WEIGHTS:
            raw = m.get(metric)
            absq = absolute_quality(metric, raw)
            pct = percentile_rank(oriented(metric, raw), peer_values[(sector, metric)])
            if absq is None:
                blended = pct  # metric missing -> lean on sector rank only
            else:
                blended = 0.6 * absq + 0.4 * pct
            per_metric[metric] = {
                "value": raw,
                "absolute": None if absq is None else round(absq, 4),
                "sector_pct": round(pct, 4),
                "blended": round(blended, 4),
            }

        root = sum(ROOT_WEIGHTS[k] * per_metric[k]["blended"] for k in ROOT_WEIGHTS)
        base = root * 100.0

        # ---- leaf adjustments (pure math: see leaf_adjustments) ----------
        adj = leaf_adjustments(root, r["leaf"],
                               prior_cycle_reads(r["ticker"]))
        filing, sentiment = adj["filing_change"], adj["sentiment"]
        catastrophe, reaction = adj["catastrophe"], adj["expectation_reaction"]
        cycle = adj["cycle_read"]

        div = r["div"]
        div_penalty = 0 if div["dividend"] else 8   # dividend-first higher bar

        composite = (base + filing + sentiment + catastrophe + reaction
                     + cycle - div_penalty)
        composite = int(round(max(0.0, min(100.0, composite))))

        results.append({
            "ticker": r["ticker"],
            "sector": sector,
            "dividend": div["dividend"],
            "pays_dividend": div["pays_dividend"],
            "yield": div["yield"],
            "annual_dps": div["annual_dps"],
            "price": div["price"],
            "streak": div["streak"],
            "dividend_quality": div["dividend_quality"],
            "metrics": {
                "fiscal_year": m["fiscal_year"],
                "prior_fiscal_year": m["prior_fiscal_year"],
                "revenue": m["revenue"],
                "revenue_growth": _r4(m["revenue_growth"]),
                "gross_margin": _r4(m["gross_margin"]),
                "operating_margin": _r4(m["operating_margin"]),
                "net_margin": _r4(m["net_margin"]),
                "fcf_margin": _r4(m["fcf_margin"]),
                "debt_to_equity": _r4(m["debt_to_equity"]),
                "roe": _r4(m["roe"]),
                "dividend_quality": m["dividend_quality"],
                "debt_basis": m["debt_basis"],
                "per_metric": per_metric,
            },
            "root": round(root, 4),
            "adjustments": {
                "filing_change": filing,
                "sentiment": sentiment,
                "catastrophe": catastrophe,
                "expectation_reaction": reaction,
                "cycle_read": cycle,
                "dividend_penalty": -div_penalty,
            },
            # validated cycle value + audit flags — the scout persists
            # cycle_read into score_history.json for the flip-flop freeze
            # and the /invest review calibration retrospective
            "cycle_read": adj["cycle_read_value"],
            "cycle_downgraded": adj["cycle_downgraded"],
            "cycle_frozen": adj["cycle_frozen"],
            "expectation_reaction_value": str(
                (r["leaf"] or {}).get("expectation_reaction", "none")).lower(),
            "composite": composite,
        })

    # errored rows surfaced at the end
    for r in rows:
        if "error" in r:
            results.append({"ticker": r["ticker"], "sector": r["sector"],
                            "error": r["error"]})

    results.sort(key=lambda x: x.get("composite", -1), reverse=True)
    return results


def _r4(x):
    return None if x is None else round(x, 4)


# ---------------------------------------------------------------------------
# leaf adjustments — pure math, no I/O (regression-tested by selftest.py)
# ---------------------------------------------------------------------------
def validate_cycle(raw, prior_reads):
    """Mechanical corroboration gate (scoring.md § Cycle-read leaf).

    A non-none/mid cycle read counts ONLY as a structured claim:
        {"read": "crested", "evidence": [{source, date, type, note}, ...]}
    with >=2 dated items from DISTINCT sources, >=1 of type "quantitative".
    A bare-string "crested"/"early" is an uncorroborated narrative -> mid.
    Flip-flop freeze: >=2 changes across the last 4 recorded weekly reads
    plus this one -> frozen to mid (calibration review material).

    Returns (value, downgraded, frozen)."""
    if isinstance(raw, str) or raw is None:
        val = str(raw or "none").lower()
        if val in ("none", "mid"):
            return val, False, False
        return "mid", True, False          # uncorroborated bare claim
    if not isinstance(raw, dict):
        return "none", False, False
    read = str(raw.get("read", "none")).lower()
    if read in ("none", "mid"):
        return read, False, False
    ev = [e for e in (raw.get("evidence") or []) if isinstance(e, dict)]
    sources = {str(e.get("source", "")).strip().lower()
               for e in ev if e.get("source")}
    quant = any(str(e.get("type", "")).lower() == "quantitative" for e in ev)
    dated = bool(ev) and all(e.get("date") for e in ev)
    if len(ev) < 2 or len(sources) < 2 or not quant or not dated:
        return "mid", True, False
    seq = [x for x in (prior_reads or [])[-4:] if x] + [read]
    changes = sum(1 for a, b in zip(seq, seq[1:]) if a != b)
    if changes >= 2:
        return "mid", False, True          # flip-flop freeze
    return read, False, False


def prior_cycle_reads(ticker):
    """Recorded weekly cycle reads for the flip-flop freeze (oldest→newest)."""
    try:
        with open(SCORE_HISTORY_PATH) as fh:
            hist = json.load(fh)
        return [e.get("cycle_read") for e in hist.get(ticker, [])
                if isinstance(e, dict)]
    except Exception:
        return []


def leaf_adjustments(root, leaf, prior_reads=None):
    """Final leaf adjustment values from raw leaf inputs. Pure — no I/O."""
    leaf = leaf or {}
    filing = {"none": 0, "minor": -2, "material": -6}.get(
        str(leaf.get("filing_change", "none")).lower(), 0)

    s = float(leaf.get("sentiment", 0) or 0)
    s = max(-1.0, min(1.0, s))
    # Contrarian-conditional (sentiment enters as an opportunity signal, not
    # additively). Sound fundamentals (root>=0.55): washed-out sentiment is a
    # contrarian BONUS; euphoria is discounted. Weak fundamentals: additive.
    if root >= 0.55:
        if s < 0:
            sentiment = (-s) * 6 * 0.5      # up to +3 contrarian credit
        else:
            sentiment = -s * 6 * 0.25       # up to -1.5 euphoria discount
    else:
        sentiment = s * 6                    # additive when fundamentals weak
    sentiment = round(sentiment, 2)

    catastrophe = {"none": 0, "indirect": -5, "direct": -12}.get(
        str(leaf.get("catastrophe", "none")).lower(), 0)

    # Expectation-reaction (MECHANICAL — from scripts/reaction.py, never the
    # agent): how the market received material news, conditioned on the MA
    # regime, trend-break state, and the 20-vs-200 reversion gap.
    reaction_kind = str(leaf.get("expectation_reaction", "none")).lower()
    reaction = {"none": 0, "confirming": 2, "confirming_reversal": 4,
                "crowded": -4, "crowded_extended": -7,
                "crowded_reversion": -8,
                "washed_out": 3, "washed_out_depressed": 5,
                "washed_out_reversion": 6}.get(reaction_kind, 0)
    # Contrarian/reversal BONUSES require sound fundamentals (same gate as
    # the contrarian sentiment credit) — no knife-catching credit for weak
    # roots. Crowd PENALTIES always apply.
    if reaction > 0 and reaction_kind != "confirming" and root < 0.55:
        reaction = 0

    # Double-count guard: sentiment and expectation_reaction usually derive
    # from the SAME news event. When their final adjustments agree in sign,
    # halve the weaker so one story can't be charged (or credited) twice.
    if sentiment * reaction > 0:
        if abs(sentiment) <= abs(reaction):
            sentiment = round(sentiment * 0.5, 2)
        else:
            reaction = round(reaction * 0.5, 2)

    # Cycle read (agent judgment, cyclical subsectors only — semis, ag,
    # commodity food). Deliberately light AND mechanically corroborated:
    # the most narrative-prone leaf in the system (scoring.md).
    cycle_val, cycle_downgraded, cycle_frozen = validate_cycle(
        leaf.get("cycle_read"), prior_reads)
    cycle = {"none": 0, "early": 1, "mid": 0, "crested": -4}.get(cycle_val, 0)

    return {
        "filing_change": filing,
        "sentiment": sentiment,
        "catastrophe": catastrophe,
        "expectation_reaction": reaction,
        "cycle_read": cycle,
        "cycle_read_value": cycle_val,
        "cycle_downgraded": cycle_downgraded,
        "cycle_frozen": cycle_frozen,
    }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main(argv):
    if "--universe" in argv:
        entries = load_universe()
    else:
        payload = next((a for a in argv[1:] if not a.startswith("--")), None)
        if not payload:
            print("usage: score.py '<json-array>' | score.py --universe",
                  file=sys.stderr)
            return 2
        entries = json.loads(payload)
        if isinstance(entries, dict):
            entries = [entries]
    results = score_universe(entries)
    print(json.dumps(results, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
