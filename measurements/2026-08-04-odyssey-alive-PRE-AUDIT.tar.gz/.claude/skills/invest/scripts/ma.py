#!/usr/bin/env python3
"""ma.py <TICKER> — 200/20-day simple moving averages + distance from the 200-day.

Reads Alpaca keys from the repo .env.local (ALPACA_API_KEY/ALPACA_SECRET_KEY).
Uses the free IEX daily-bar feed (SIP history >15min old is available free).
Directive 4: closed daily bars only, long-horizon lookbacks, no repainting.

Output (JSON): last_close, ma200, ma20, dist_200 ($ and %), trend (green/red).
Distance from the 200-day MA is the status display's "number 2".
"""
import json
import os
import re
import sys
import urllib.request
from datetime import date, timedelta

ENV = "/home/francis/lab/odyssey-alive/.env.local"
DATA_HOST = "https://data.alpaca.markets/v2"


def load_keys(env_path=ENV):
    txt = open(env_path).read()
    key = re.search(r"^ALPACA_API_KEY=(.+)$", txt, re.M).group(1).strip()
    sec = re.search(r"^ALPACA_SECRET_KEY=(.+)$", txt, re.M).group(1).strip()
    return key, sec


def get_daily_bars(ticker, key, sec, days=400):
    start = (date.today() - timedelta(days=int(days * 1.6) + 40)).isoformat()
    url = (f"{DATA_HOST}/stocks/{ticker}/bars"
           f"?timeframe=1Day&start={start}&limit=10000&feed=iex&adjustment=split")
    req = urllib.request.Request(url, headers={
        "APCA-API-KEY-ID": key, "APCA-API-SECRET-KEY": sec})
    with urllib.request.urlopen(req, timeout=30) as r:
        data = json.load(r)
    bars = data.get("bars", [])
    dates = [b["t"][:10] for b in bars]
    closes = [b["c"] for b in bars]
    return dates, closes


def build_series(dates, closes, weeks=26, step=5):
    """Weekly-sampled points (oldest→newest) for the panel line chart: each carries
    the close plus the 20- and 200-day SMA computed at that point (Directive 4:
    closed bars, no repainting). Only points with a full 200-day window are emitted."""
    n = len(closes)
    idxs = []
    i = n - 1
    while len(idxs) < weeks and i >= 199:
        idxs.append(i)
        i -= step
    idxs.reverse()
    series = []
    for i in idxs:
        series.append({
            "date": dates[i],
            "close": round(closes[i], 2),
            "ma20": round(sum(closes[i - 19:i + 1]) / 20, 2),
            "ma200": round(sum(closes[i - 199:i + 1]) / 200, 2),
        })
    return series


def main():
    if len(sys.argv) < 2:
        print("usage: ma.py <TICKER>", file=sys.stderr)
        sys.exit(2)
    ticker = sys.argv[1].upper()
    key, sec = load_keys()
    dates, closes = get_daily_bars(ticker, key, sec)
    if len(closes) < 200:
        print(json.dumps({"ticker": ticker, "error": f"only {len(closes)} daily "
              "bars available; need 200 for the 200-day MA"}))
        sys.exit(1)
    last = closes[-1]
    ma200 = sum(closes[-200:]) / 200
    ma20 = sum(closes[-20:]) / 20
    dist = last - ma200
    out = {
        "ticker": ticker,
        "last_close": round(last, 2),
        "ma200": round(ma200, 2),
        "ma20": round(ma20, 2),
        "dist_200_usd": round(dist, 2),
        "dist_200_pct": round(100 * dist / ma200, 2),
        "trend": "green" if dist >= 0 else "red",
        "bars_used": len(closes),
        "series": build_series(dates, closes),
    }
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
