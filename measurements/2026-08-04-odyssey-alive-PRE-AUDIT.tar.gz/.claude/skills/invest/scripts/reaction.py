#!/usr/bin/env python3
"""reaction.py <TICKER> <NEWS_DATE> --polarity positive|negative [--window 5]

Mechanical expectation-reaction classifier — "score the reaction, not the
headline." Given a material news item's date and its polarity (the ONLY
judgment input, supplied by the Layer-2 agent), this script measures how the
market actually received the news and classifies the divergence:

    good news + price rises        -> confirming      (market agrees)
    good news + shrug/sell-off     -> crowded         (expectations already in;
                                       cycle may have crested)
    bad news  + price falls        -> confirming      (market agrees it's bad)
    bad news  + absorbed flat/up   -> washed_out      (already priced; the
                                       contrarian setup scoring.md prizes)

The 200/20-day MA supplies REGIME CONTEXT that conditions the read (Directive
5: a minor confirming input, never an override — it can strengthen a
classification, never create or veto a pick):

    extended  (close > +20% above the 200-day MA at news time)
        -> a muted/negative reaction to good news reads MORE crowded
    depressed (close < -15% below the 200-day MA at news time)
        -> absorbed bad news reads MORE washed-out (deeper contrarian value)

TREND-BREAK detection (long-term data establishing a possible reversal): when
the long trend is down (close below the 200-day MA, or the 200-day MA itself
falling over the past ~month) BUT price action is breaking it (close back
above a RISING 20-day MA), a market-confirmed piece of good news classifies as
`confirming_reversal` — the strongest long entry context per Directive 2
(catch the start of a multi-month run), worth slightly more than a plain
confirmation. The news is still the driver; the trend state only sizes it.

REVERSION GAP (20-vs-200 equalization, both directions): the 20-day MA tends
to equalize toward the 200-day.
    20MA deep BELOW the 200MA (gap <= -12%) + absorbed bad news
        -> washed_out_reversion  (upward pull; score.py credits it ONLY when
           root fundamentals are sound — no falling-knife credit)
    20MA deep ABOVE the 200MA (gap >= +12%) + good news met with a shrug
        -> crowded_reversion     (downward pull; the harshest crowd penalty,
           applied unconditionally)

Everything here is computed from closed daily bars (Directive 4) fetched from
Alpaca, same feed as ma.py. The agent never sees or opines on prices; it hands
this script a polarity, and score.py folds the resulting classification in as
a bounded leaf adjustment.

Output (JSON): baseline/reaction closes + dates, reaction_pct, MA regime,
trend state, and 20-vs-200 gap at news time, and `classification` for
score.py's `expectation_reaction` leaf: one of confirming /
confirming_reversal / crowded / crowded_extended / crowded_reversion /
washed_out / washed_out_depressed / washed_out_reversion / none.

Thresholds are INITIAL — calibrate in paper trading.
"""
import json
import re
import sys
import urllib.request
from datetime import date, timedelta

ENV = "/home/francis/lab/odyssey-alive/.env.local"
DATA_HOST = "https://data.alpaca.markets/v2"

WINDOW_DEFAULT = 5          # trading days after the news date
# Confirm threshold is VOLATILITY-SCALED per stock (a 2% move is an event for
# KO and noise for a mid-cap semi): threshold_pct = CONFIRM_Z * sigma_daily *
# sqrt(days_observed), clamped to [CONFIRM_FLOOR_PCT, CONFIRM_CAP_PCT].
# sigma_daily = stdev of daily returns over VOL_LOOKBACK_D closed days ending
# at the baseline bar (point-in-time — Directive 4, no lookahead).
CONFIRM_Z = 0.75
VOL_LOOKBACK_D = 120
CONFIRM_FLOOR_PCT = 1.0     # sub-1% moves never count as a verdict
CONFIRM_CAP_PCT = 10.0      # hyper-volatile names still get judged
EXTENDED_PCT = 20.0         # close vs 200MA above this = euphoric regime
DEPRESSED_PCT = -15.0       # close vs 200MA below this = washed-out regime
REVERSION_GAP_PCT = -12.0   # 20MA this far below 200MA = deep reversion gap:
                            # absorbed bad news upgrades to washed_out_reversion
                            # (equalization pull toward the 200-day; score.py
                            # only credits it when root fundamentals are sound)


def load_keys(env_path=ENV):
    txt = open(env_path).read()
    key = re.search(r"^ALPACA_API_KEY=(.+)$", txt, re.M).group(1).strip()
    sec = re.search(r"^ALPACA_SECRET_KEY=(.+)$", txt, re.M).group(1).strip()
    return key, sec


def get_daily_bars(ticker, key, sec, since):
    url = (f"{DATA_HOST}/stocks/{ticker}/bars"
           f"?timeframe=1Day&start={since}&limit=10000&feed=iex&adjustment=split")
    req = urllib.request.Request(url, headers={
        "APCA-API-KEY-ID": key, "APCA-API-SECRET-KEY": sec})
    with urllib.request.urlopen(req, timeout=30) as r:
        data = json.load(r)
    bars = data.get("bars", [])
    return [b["t"][:10] for b in bars], [b["c"] for b in bars]


def confirm_threshold(closes, base_i, days_observed):
    """Volatility-scaled confirm threshold (pct), point-in-time at baseline."""
    lo = max(1, base_i - VOL_LOOKBACK_D)
    rets = [closes[i] / closes[i - 1] - 1 for i in range(lo, base_i + 1)]
    if len(rets) < 20:
        return 2.0   # not enough history: legacy fixed threshold
    mean = sum(rets) / len(rets)
    sigma = (sum((r - mean) ** 2 for r in rets) / (len(rets) - 1)) ** 0.5
    thr = CONFIRM_Z * sigma * (days_observed ** 0.5) * 100
    return max(CONFIRM_FLOOR_PCT, min(CONFIRM_CAP_PCT, thr))


def classify(polarity, reaction_pct, regime, trend_break=False, gap_pct=0.0,
             confirm_pct=2.0):
    stretched = gap_pct >= -REVERSION_GAP_PCT     # 20MA deep ABOVE the 200MA
    deep_gap = gap_pct <= REVERSION_GAP_PCT       # 20MA deep BELOW the 200MA
    if polarity == "positive":
        if reaction_pct >= confirm_pct:
            return "confirming_reversal" if trend_break else "confirming"
        if reaction_pct <= 0:
            if stretched:
                return "crowded_reversion"        # equalization pull is DOWN
            return "crowded_extended" if regime == "extended" else "crowded"
        # muted (0..confirm_pct): a shrug only counts against euphoric pricing
        return "crowded" if (regime == "extended" or stretched) else "none"
    else:  # negative
        if reaction_pct <= -confirm_pct:
            return "confirming"
        if reaction_pct >= 0:
            if deep_gap:
                return "washed_out_reversion"     # equalization pull is UP
            return "washed_out_depressed" if regime == "depressed" else "washed_out"
        # muted decline: only a depressed regime / deep gap upgrades it
        return "washed_out" if (regime == "depressed" or deep_gap) else "none"


def main(argv):
    args = [a for a in argv[1:] if not a.startswith("--")]
    if len(args) < 2:
        print("usage: reaction.py <TICKER> <NEWS_DATE YYYY-MM-DD> "
              "--polarity positive|negative [--window N]", file=sys.stderr)
        return 2
    ticker, news_date = args[0].upper(), args[1]
    polarity = None
    window = WINDOW_DEFAULT
    for i, a in enumerate(argv):
        if a == "--polarity" and i + 1 < len(argv):
            polarity = argv[i + 1].lower()
        if a == "--window" and i + 1 < len(argv):
            window = int(argv[i + 1])
    if polarity not in ("positive", "negative"):
        print("--polarity positive|negative is required", file=sys.stderr)
        return 2

    key, sec = load_keys()
    # enough history for a 200-day MA at the news date
    since = (date.fromisoformat(news_date) - timedelta(days=420)).isoformat()
    dates, closes = get_daily_bars(ticker, key, sec, since)
    # Directive 4: closed bars only — today's bar may still be forming
    while dates and dates[-1] >= date.today().isoformat():
        dates.pop(), closes.pop()

    # baseline = last closed bar strictly BEFORE the news date (Directive 4)
    base_i = None
    for i, d in enumerate(dates):
        if d < news_date:
            base_i = i
    if base_i is None:
        print(json.dumps({"ticker": ticker, "error":
                          f"no bars before {news_date}"}))
        return 1
    if base_i < 199:
        print(json.dumps({"ticker": ticker, "error":
                          f"only {base_i + 1} bars before {news_date}; "
                          "need 200 for the MA regime"}))
        return 1

    react_i = min(base_i + window, len(dates) - 1)
    days_observed = react_i - base_i
    if days_observed < 1:
        print(json.dumps({"ticker": ticker, "error":
                          f"no closed bars after {news_date} yet"}))
        return 1

    baseline, reaction = closes[base_i], closes[react_i]
    reaction_pct = 100 * (reaction / baseline - 1)
    confirm_pct = confirm_threshold(closes, base_i, days_observed)

    ma200 = sum(closes[base_i - 199:base_i + 1]) / 200
    ma20 = sum(closes[base_i - 19:base_i + 1]) / 20
    dist_200_pct = 100 * (baseline - ma200) / ma200
    gap_20v200_pct = 100 * (ma20 - ma200) / ma200
    regime = ("extended" if dist_200_pct >= EXTENDED_PCT
              else "depressed" if dist_200_pct <= DEPRESSED_PCT
              else "normal")

    # Trend state from long-term data (closed bars only): the 200-day MA's
    # slope over the past ~month, and whether price action is breaking a
    # downtrend via a reclaimed, rising 20-day MA.
    ma200_slope_pct = None
    trend, trend_break = "unknown", False
    if base_i >= 219:
        ma200_prev = sum(closes[base_i - 219:base_i - 19]) / 200
        ma20_prev = sum(closes[base_i - 24:base_i - 4]) / 20
        ma200_slope_pct = 100 * (ma200 - ma200_prev) / ma200_prev
        long_down = baseline < ma200 or ma200_slope_pct < 0
        trend = ("up" if baseline >= ma200 and ma200_slope_pct >= 0
                 else "down" if long_down else "flat")
        trend_break = long_down and baseline > ma20 and ma20 > ma20_prev

    out = {
        "ticker": ticker,
        "news_date": news_date,
        "polarity": polarity,
        "baseline_date": dates[base_i],
        "baseline_close": round(baseline, 2),
        "reaction_date": dates[react_i],
        "reaction_close": round(reaction, 2),
        "reaction_pct": round(reaction_pct, 2),
        "confirm_threshold_pct": round(confirm_pct, 2),
        "window_days_observed": days_observed,
        "window_partial": days_observed < window,
        "ma200_at_news": round(ma200, 2),
        "ma20_at_news": round(ma20, 2),
        "dist_200_pct_at_news": round(dist_200_pct, 2),
        "gap_20v200_pct": round(gap_20v200_pct, 2),
        "regime": regime,
        "ma200_slope_pct": (round(ma200_slope_pct, 2)
                            if ma200_slope_pct is not None else None),
        "trend": trend,
        "trend_break": trend_break,
        "classification": classify(polarity, reaction_pct, regime, trend_break,
                                   gap_20v200_pct, confirm_pct),
    }
    print(json.dumps(out, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
