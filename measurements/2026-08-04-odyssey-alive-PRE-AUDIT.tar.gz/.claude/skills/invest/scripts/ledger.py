#!/usr/bin/env python3
"""ledger.py <cmd> — the two-tier ledger: holdings + realized.

Commands:
  pl <TICKER>              full-holding P/L (number 1): market value vs invested
  show                     pretty summary of holdings + realized
  add <TICKER> <price> <shares> <notional>   append a lot (used by spend on fill)
  score <TICKER> <score>   append a composite score to the stock's time-series
  close <TICKER> <proceeds> [--partial <amount>] "<reason>"
                           full exit (default) → realized; --partial uses HIFO

Schemas: see references/ledger.md. Money in USD. Append-only history.
Current price for `pl` comes from ma.py's last_close (Alpaca), passed via --price.
"""
import json
import os
import sys
from datetime import date, datetime

SKILL = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HOLD = os.path.join(SKILL, "data", "holdings.json")
REAL = os.path.join(SKILL, "data", "realized.json")


def load(p):
    with open(p) as f:
        return json.load(f)


def save(p, obj):
    with open(p, "w") as f:
        json.dump(obj, f, indent=2)
        f.write("\n")


def iso_week(d=None):
    d = d or date.today()
    y, w, _ = d.isocalendar()
    return f"{y}-W{w:02d}"


def cmd_add(args):
    ticker, price, shares, notional = args[0].upper(), float(args[1]), float(args[2]), float(args[3])
    h = load(HOLD)
    h["lots"].append({"stock_id": ticker, "date": date.today().isoformat(),
                      "fill_price": price, "shares": shares, "notional": notional})
    h["week_marker"] = iso_week()
    save(HOLD, h)
    print(json.dumps({"added": ticker, "week_marker": h["week_marker"]}, indent=2))


def cmd_score(args):
    ticker, score = args[0].upper(), float(args[1])
    h = load(HOLD)
    h.setdefault("score_history", {}).setdefault(ticker, []).append(
        {"date": date.today().isoformat(), "score": score})
    save(HOLD, h)
    print(json.dumps({"scored": ticker, "score": score}, indent=2))


def cmd_pl(args):
    ticker = args[0].upper()
    price = None
    if "--price" in args:
        price = float(args[args.index("--price") + 1])
    h = load(HOLD)
    lots = [l for l in h["lots"] if l["stock_id"] == ticker]
    if not lots:
        print(json.dumps({"ticker": ticker, "error": "no lots held"}))
        return
    shares = sum(l["shares"] for l in lots)
    invested = sum(l["notional"] for l in lots)
    out = {"ticker": ticker, "lots": len(lots), "shares_total": round(shares, 4),
           "invested_total": round(invested, 2)}
    if price is not None:
        mv = shares * price
        out.update({"current_price": price, "market_value": round(mv, 2),
                    "pl_usd": round(mv - invested, 2),
                    "trend": "green" if mv >= invested else "red"})
    else:
        out["note"] = "pass --price <last_close> (from ma.py) for market value / P&L"
    print(json.dumps(out, indent=2))


def cmd_close(args):
    ticker = args[0].upper()
    proceeds = float(args[1])
    partial = None
    reason = ""
    rest = args[2:]
    if "--partial" in rest:
        i = rest.index("--partial")
        partial = float(rest[i + 1])
        rest = rest[:i] + rest[i + 2:]
    reason = " ".join(rest).strip('"')
    h = load(HOLD)
    r = load(REAL)
    lots = [l for l in h["lots"] if l["stock_id"] == ticker]
    if not lots:
        print(json.dumps({"ticker": ticker, "error": "no lots held"}))
        return
    if partial is None:
        # FULL EXIT (default) — method-agnostic; move all lots to realized
        invested = sum(l["notional"] for l in lots)
        r["closed"].append({
            "stock_id": ticker,
            "opened": min(l["date"] for l in lots),
            "closed": date.today().isoformat(),
            "total_invested": round(invested, 2),
            "proceeds": round(proceeds, 2),
            "realized_pl": round(proceeds - invested, 2),
            "lots_closed": len(lots),
            "method": "full-exit",
            "reason": reason or "fundamental thesis break",
        })
        h["lots"] = [l for l in h["lots"] if l["stock_id"] != ticker]
        h.get("score_history", {}).pop(ticker, None)
        save(HOLD, h); save(REAL, r)
        print(json.dumps({"closed": ticker, "method": "full-exit",
                          "realized_pl": round(proceeds - invested, 2)}, indent=2))
    else:
        # PARTIAL TRIM — HIFO: sell highest fill_price lots first
        print(json.dumps({"error": "partial HIFO trim is intentionally manual-review "
              "only in the scaffold — Alpaca reports FIFO by default, so a real HIFO "
              "trim needs explicit lot specification at sale. Implement when first "
              "needed (Directive 8: full exits are the default)."}, indent=2))


def cmd_show(_):
    h = load(HOLD); r = load(REAL)
    print(json.dumps({"holdings": h, "realized": r}, indent=2))


CMDS = {"pl": cmd_pl, "add": cmd_add, "score": cmd_score, "close": cmd_close, "show": cmd_show}


def main():
    if len(sys.argv) < 2 or sys.argv[1] not in CMDS:
        print("usage: ledger.py {pl|add|score|close|show} [...]", file=sys.stderr)
        sys.exit(2)
    CMDS[sys.argv[1]](sys.argv[2:])


if __name__ == "__main__":
    main()
