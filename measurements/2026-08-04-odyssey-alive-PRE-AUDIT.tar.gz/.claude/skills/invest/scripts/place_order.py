#!/usr/bin/env python3
"""place_order.py — notional BUY on Alpaca. SAFETY-GATED.

  DRY-RUN BY DEFAULT. Places a real (paper) order ONLY with --execute.
  Never invoked by scout/status/watch/scaffolding. Only the `spend` workflow,
  after explicit human confirmation, may call this with --execute.

Usage:
  place_order.py <TICKER> <NOTIONAL_USD>              # dry-run (prints intent)
  place_order.py <TICKER> <NOTIONAL_USD> --execute    # places the PAPER order

Guards:
  - Refuses unless ALPACA_PAPER_TRADE=True in .env.local (no live orders here).
  - --execute is required; without it, prints the order it WOULD place and exits 0.
"""
import json
import re
import sys
import urllib.request

ENV = "/home/francis/lab/odyssey-alive/.env.local"


def cfg():
    txt = open(ENV).read()
    def g(k):
        m = re.search(rf"^{k}=(.+)$", txt, re.M)
        return m.group(1).strip() if m else None
    return {
        "key": g("ALPACA_API_KEY"),
        "sec": g("ALPACA_SECRET_KEY"),
        "paper": (g("ALPACA_PAPER_TRADE") or "").lower() == "true",
        "base": (g("ALPACA_PAPER_BASE_URL") or "https://paper-api.alpaca.markets/v2").rstrip("/"),
    }


def main():
    args = sys.argv[1:]
    execute = "--execute" in args
    args = [a for a in args if a != "--execute"]
    if len(args) < 2:
        print("usage: place_order.py <TICKER> <NOTIONAL_USD> [--execute]", file=sys.stderr)
        sys.exit(2)
    ticker, notional = args[0].upper(), float(args[1])
    c = cfg()

    if not c["paper"]:
        print(json.dumps({"refused": "ALPACA_PAPER_TRADE is not True — this script "
              "places PAPER orders only. Live trading requires a separate, deliberate "
              "go-live change."}))
        sys.exit(1)

    order = {"symbol": ticker, "notional": round(notional, 2), "side": "buy",
             "type": "market", "time_in_force": "day"}

    if not execute:
        print(json.dumps({"dry_run": True, "would_place": order,
              "note": "Re-run with --execute to place this PAPER order. Requires "
                      "explicit human approval per the No-Auto-Buy Gate."}, indent=2))
        return

    base = c["base"] if c["base"].endswith("/v2") else c["base"] + "/v2"
    req = urllib.request.Request(
        f"{base}/orders", method="POST",
        data=json.dumps(order).encode(),
        headers={"APCA-API-KEY-ID": c["key"], "APCA-API-SECRET-KEY": c["sec"],
                 "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=30) as r:
        resp = json.load(r)
    print(json.dumps({"placed": True, "order_id": resp.get("id"),
          "symbol": resp.get("symbol"), "notional": resp.get("notional"),
          "status": resp.get("status")}, indent=2))


if __name__ == "__main__":
    main()
