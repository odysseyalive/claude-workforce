#!/usr/bin/env python3
"""review.py — mechanical calibration retrospective for /invest review.

Measures whether the system's own recorded signals actually predicted forward
returns, from stored point-in-time data only. No LLM in the math (the AI's
role in `review` is to INTERPRET this report and PROPOSE adjustments, which
Francis approves — approved changes are logged to data/calibration_log.json).

Inputs:
  * data/score_history.json — weekly {week, score, adjustments?, cycle_read?}
    per ticker (point-in-time, never backfilled)
  * Alpaca daily bars (closed) for forward returns

For each recorded week old enough to have a forward window:
  fwd_return(N) = close(first bar >= Monday of week+N) / close(first bar >=
                  Monday of week) - 1

Report (data/review-<date>.json + stdout):
  * composite information coefficient: Spearman rank correlation between the
    stored composite and pooled forward returns, per horizon
  * per-signal buckets: for each leaf adjustment (expectation_reaction,
    cycle_read, sentiment, filing_change, catastrophe), mean forward return of
    weeks where the adjustment was positive / negative / zero, with counts
  * naive verdict per signal: SUPPORTED / CONTRADICTED / INSUFFICIENT
    (n < MIN_N on either side -> INSUFFICIENT; a verdict is a flag for the
    interpreting reviewer, not a conclusion)

Directive-4 discipline: this is a retrospective on OUR OWN stored, dated
decisions — not a backtest search. One parameter change at a time; prefer
stable plateaus; INSUFFICIENT means keep collecting, not tune harder.

Usage:
    python3 review.py [--horizons 4,8,12] [--min-n 5] [--dry-run]
"""
import json
import os
import re
import sys
import urllib.request
from datetime import date, timedelta

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HISTORY_PATH = os.path.join(SKILL_DIR, "data", "score_history.json")
ENV = "/home/francis/lab/odyssey-alive/.env.local"
DATA_HOST = "https://data.alpaca.markets/v2"
MIN_N = 5
SIGNALS = ["expectation_reaction", "cycle_read", "sentiment",
           "filing_change", "catastrophe"]


def load_keys(env_path=ENV):
    txt = open(env_path).read()
    key = re.search(r"^ALPACA_API_KEY=(.+)$", txt, re.M).group(1).strip()
    sec = re.search(r"^ALPACA_SECRET_KEY=(.+)$", txt, re.M).group(1).strip()
    return key, sec


def get_daily_closes(ticker, key, sec, since):
    url = (f"{DATA_HOST}/stocks/{ticker}/bars"
           f"?timeframe=1Day&start={since}&limit=10000&feed=iex&adjustment=split")
    req = urllib.request.Request(url, headers={
        "APCA-API-KEY-ID": key, "APCA-API-SECRET-KEY": sec})
    with urllib.request.urlopen(req, timeout=30) as r:
        data = json.load(r)
    bars = data.get("bars", [])
    out = []
    today = date.today().isoformat()
    for b in bars:
        d = b["t"][:10]
        if d < today:                      # closed bars only (Directive 4)
            out.append((d, b["c"]))
    return out


def week_monday(iso_week):
    y, w = iso_week.split("-W")
    return date.fromisocalendar(int(y), int(w), 1)


def price_at_or_after(closes, target):
    t = target.isoformat()
    for d, c in closes:
        if d >= t:
            return c
    return None


def spearman(xs, ys):
    """Spearman rank correlation, no scipy. Average ranks for ties."""
    def ranks(vals):
        order = sorted(range(len(vals)), key=lambda i: vals[i])
        rk = [0.0] * len(vals)
        i = 0
        while i < len(order):
            j = i
            while j + 1 < len(order) and vals[order[j + 1]] == vals[order[i]]:
                j += 1
            avg = (i + j) / 2 + 1
            for k in range(i, j + 1):
                rk[order[k]] = avg
            i = j + 1
        return rk
    if len(xs) < 3:
        return None
    rx, ry = ranks(xs), ranks(ys)
    mx, my = sum(rx) / len(rx), sum(ry) / len(ry)
    num = sum((a - mx) * (b - my) for a, b in zip(rx, ry))
    dx = sum((a - mx) ** 2 for a in rx) ** 0.5
    dy = sum((b - my) ** 2 for b in ry) ** 0.5
    return round(num / (dx * dy), 3) if dx and dy else None


def signal_sign(entry, signal):
    adj = entry.get("adjustments") or {}
    v = adj.get(signal, 0) or 0
    return "positive" if v > 0 else "negative" if v < 0 else "zero"


def verdict(pos, neg, zero):
    """Naive mechanical flag: did signed adjustments point the right way?"""
    checks = []
    if pos["n"] >= MIN_N and zero["n"] >= MIN_N:
        checks.append(pos["mean"] > zero["mean"])
    if neg["n"] >= MIN_N and zero["n"] >= MIN_N:
        checks.append(neg["mean"] < zero["mean"])
    if not checks:
        return "INSUFFICIENT"
    return "SUPPORTED" if all(checks) else (
        "CONTRADICTED" if not any(checks) else "MIXED")


def main(argv):
    horizons = [4, 8, 12]
    for i, a in enumerate(argv):
        if a == "--horizons" and i + 1 < len(argv):
            horizons = [int(x) for x in argv[i + 1].split(",")]
        if a == "--min-n" and i + 1 < len(argv):
            global MIN_N
            MIN_N = int(argv[i + 1])
    dry = "--dry-run" in argv

    with open(HISTORY_PATH) as fh:
        history = json.load(fh)
    tickers = [t for t in history if not t.startswith("_")]
    key, sec = load_keys()

    # collect (ticker, week, score, entry, {horizon: fwd_return})
    rows = []
    for ticker in tickers:
        entries = [e for e in history[ticker] if isinstance(e, dict)
                   and e.get("week") and e.get("score") is not None]
        if not entries:
            continue
        earliest = week_monday(min(e["week"] for e in entries))
        closes = get_daily_closes(ticker, key, sec,
                                  (earliest - timedelta(days=7)).isoformat())
        for e in entries:
            monday = week_monday(e["week"])
            base = price_at_or_after(closes, monday)
            if base is None:
                continue
            fwd = {}
            for h in horizons:
                p = price_at_or_after(closes, monday + timedelta(weeks=h))
                if p is not None:
                    fwd[h] = round(p / base - 1, 4)
            if fwd:
                rows.append({"ticker": ticker, "week": e["week"],
                             "score": e["score"], "entry": e, "fwd": fwd})

    report = {"generated": date.today().isoformat(),
              "history_weeks": len({r["week"] for r in rows}),
              "evaluable_points": len(rows),
              "min_n": MIN_N, "horizons": {}}

    for h in horizons:
        pts = [r for r in rows if h in r["fwd"]]
        hrep = {"n": len(pts)}
        if len(pts) >= 3:
            hrep["composite_ic_spearman"] = spearman(
                [r["score"] for r in pts], [r["fwd"][h] for r in pts])
        hrep["signals"] = {}
        for sig in SIGNALS:
            buckets = {}
            for lab in ("positive", "negative", "zero"):
                vals = [r["fwd"][h] for r in pts
                        if signal_sign(r["entry"], sig) == lab]
                buckets[lab] = {"n": len(vals),
                                "mean": (round(sum(vals) / len(vals), 4)
                                         if vals else None)}
            hrep["signals"][sig] = {
                **buckets,
                "verdict": verdict(buckets["positive"], buckets["negative"],
                                   buckets["zero"]),
            }
        report["horizons"][str(h)] = hrep

    # cycle-read audit: downgrades/freezes recorded this period
    cyc = [ (r["ticker"], r["week"], r["entry"].get("cycle_read"))
            for r in rows if r["entry"].get("cycle_read") not in (None, "none")]
    report["cycle_reads_recorded"] = len(cyc)

    out_path = os.path.join(SKILL_DIR, "data",
                            f"review-{date.today().isoformat()}.json")
    if not dry:
        with open(out_path, "w") as fh:
            json.dump(report, fh, indent=2)
    print(json.dumps(report, indent=2))
    if not dry:
        print(f"\nwrote {out_path}", file=sys.stderr)
    print("\nREMINDER: verdicts are mechanical flags, not conclusions. "
          "Proposals require explicit human approval; log approved changes to "
          "data/calibration_log.json (one parameter at a time — Directive 4).",
          file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
