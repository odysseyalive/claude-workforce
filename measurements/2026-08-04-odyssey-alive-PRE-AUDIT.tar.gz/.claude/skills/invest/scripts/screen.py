#!/usr/bin/env python3
"""screen.py — mechanical universe screener. Zero AI in the data path.

Builds the candidate universe for /invest scout by screening the ENTIRE
technology and food/agriculture/consumer-staples sectors mechanically, so the
scoring pipeline (and the Layer-2 agent) only ever sees a small ranked
shortlist — no LLM reads bulk data, no LLM decides what to truncate.

Pipeline (all deterministic, stdlib-only, same conventions as score.py):

  1. SECTOR MEMBERSHIP — enumerate every SEC filer in the configured SIC codes
     via the browse-edgar company listing (paginated atom, cached 30 days).
  2. TICKER MAP — company_tickers.json maps CIK -> primary ticker; filers
     without a listed ticker drop out.
  3. BULK FUNDAMENTALS — the XBRL "frames" API returns one concept for ALL
     filers per request. ~25 requests cover revenue (two years -> growth),
     operating income, net income, operating cash flow, capex, and
     dividends-per-share for every US filer. Concept fallbacks are merged
     (filers switch tags over time), and two target years are merged so
     offset fiscal years (MSFT Jun, AAPL Sep, NVDA Jan) stay covered.
  4. PRE-SCORE — coarse 0..100: revenue growth, operating margin, FCF margin,
     net margin, dividend-payer bonus (Directive 6). Blend of absolute-quality
     bands and sector percentile rank, mirroring score.py's philosophy.
  5. TRADABILITY — top candidates are checked against the Alpaca assets API
     (active + tradable + fractionable — $50 notional buys need fractions).
  6. OUTPUT — data/universe.json: top N per sector with pre-scores and the
     screen's coverage stats. score.py --universe reads this shortlist; the
     full (expensive, per-ticker) composite scoring runs only on it.

The pre-score is a COARSE FILTER, not the composite (references/scoring.md);
it exists only to cut ~5,000 filers down to a shortlist mechanically. The
composite from score.py still governs suggestions (Directive 7).

Usage:
    python3 screen.py                 # refresh if universe.json stale/missing
    python3 screen.py --force         # ignore caches + refresh now
    python3 screen.py --dry-run       # print shortlist, don't write universe.json
"""

import json
import os
import re
import sys
import time
import urllib.error
import urllib.request

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ENV_PATH = os.path.join(os.path.dirname(os.path.dirname(
    os.path.dirname(SKILL_DIR))), ".env.local")
CONFIG_PATH = os.path.join(SKILL_DIR, "data", "config.json")
UNIVERSE_PATH = os.path.join(SKILL_DIR, "data", "universe.json")
TICKERS_CACHE = "/tmp/sec_company_tickers.json"
SIC_CACHE = "/tmp/sec_sic_members.json"
SIC_CACHE_DAYS = 30
REQUEST_GAP_S = 0.15

# ---------------------------------------------------------------------------
# Universe SIC codes — INITIAL, overridable via config.json universe.screen.sic
# ---------------------------------------------------------------------------
DEFAULT_SIC = {
    "tech": [
        3570, 3571, 3572, 3575, 3576, 3577, 3578, 3579,   # computers/office
        3661, 3663, 3669,                                  # comm equipment
        3670, 3672, 3674, 3677, 3678, 3679,                # electronics/semis
        7370, 7371, 7372, 7373, 7374, 7375, 7377, 7378, 7379,  # software/IT svcs
    ],
    "food_staples": [
        100, 200,                                          # ag: crops, livestock
        2000, 2011, 2013, 2015, 2020, 2024, 2030, 2033,    # food & kindred
        2040, 2050, 2052, 2060, 2070, 2080, 2082, 2084,
        2085, 2086, 2090, 2092,
        # tobacco (2100, 2111) deliberately excluded — user decision 2026-07-13
        2840, 2842, 2844,                                  # household/personal care
        5140, 5411,                                        # grocery wholesale/retail
    ],
}

DEFAULT_SCREEN = {
    "top_n_per_sector": 20,
    "min_revenue_usd": 500_000_000,
    "refresh_days": 30,
    "sic": DEFAULT_SIC,
}

# Frame concept fallbacks (merged in order; first hit per CIK wins).
REVENUE_CONCEPTS = ["RevenueFromContractWithCustomerExcludingAssessedTax",
                    "Revenues"]
FLOW_CONCEPTS = {
    "operating_income": ["OperatingIncomeLoss"],
    "net_income": ["NetIncomeLoss"],
    "cfo": ["NetCashProvidedByUsedInOperatingActivities"],
    "capex": ["PaymentsToAcquirePropertyPlantAndEquipment"],
}
DPS_CONCEPTS = ["CommonStockDividendsPerShareDeclared",
                "CommonStockDividendsPerShareCashPaid"]

# Pre-score bands (linear, clamped 0..1) — coarse versions of score.py's bands.
BANDS = {
    "revenue_growth": (-0.05, 0.25),
    "operating_margin": (0.00, 0.35),
    "fcf_margin": (0.00, 0.30),
    "net_margin": (0.00, 0.25),
}
PRESCORE_WEIGHTS = {
    "revenue_growth": 0.30,
    "operating_margin": 0.25,
    "fcf_margin": 0.25,
    "net_margin": 0.20,
}
DIVIDEND_PAYER_BONUS = 8   # Directive 6: dividend-first, coarse flavor
ABS_BLEND = 0.6            # per-metric = 0.6*absolute + 0.4*sector percentile


# ---------------------------------------------------------------------------
# plumbing
# ---------------------------------------------------------------------------
def load_env():
    env = {}
    if os.path.exists(ENV_PATH):
        with open(ENV_PATH) as fh:
            for line in fh:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    env[k.strip()] = v.strip().strip('"').strip("'")
    return env


_ENV = load_env()
_LAST_REQ = [0.0]


def _get(url, headers=None, ok404=False):
    wait = REQUEST_GAP_S - (time.time() - _LAST_REQ[0])
    if wait > 0:
        time.sleep(wait)
    hdrs = {"User-Agent": _ENV.get("EDGAR_IDENTITY", "invest-skill screen.py")}
    if headers:
        hdrs.update(headers)
    req = urllib.request.Request(url, headers=hdrs)
    _LAST_REQ[0] = time.time()
    try:
        return urllib.request.urlopen(req, timeout=60).read()
    except urllib.error.HTTPError as e:
        if e.code == 404 and ok404:
            return None
        raise


def _get_json(url, **kw):
    raw = _get(url, **kw)
    return None if raw is None else json.loads(raw)


def load_config():
    with open(CONFIG_PATH) as fh:
        cfg = json.load(fh)
    screen = dict(DEFAULT_SCREEN)
    screen.update(cfg.get("universe", {}).get("screen", {}) or {})
    if not screen.get("sic"):
        screen["sic"] = DEFAULT_SIC
    return cfg, screen


# ---------------------------------------------------------------------------
# stage 1 — sector membership by SIC (browse-edgar, cached)
# ---------------------------------------------------------------------------
def fetch_sic_members(sic, force=False):
    cache = {}
    if os.path.exists(SIC_CACHE):
        with open(SIC_CACHE) as fh:
            cache = json.load(fh)
    fresh_after = time.time() - SIC_CACHE_DAYS * 86400
    key_meta = cache.get("_fetched", {})
    members = {}
    dirty = False
    for sector, codes in sic.items():
        for code in codes:
            k = str(code)
            if not force and k in cache and key_meta.get(k, 0) > fresh_after:
                ciks = cache[k]
            else:
                ciks = []
                start = 0
                while True:
                    url = ("https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany"
                           f"&SIC={code:04d}&type=10-K&count=100&start={start}&output=atom")
                    raw = _get(url).decode("utf-8", "replace")
                    page = re.findall(r"<cik>0*(\d+)</cik>", raw)
                    ciks.extend(int(c) for c in page)
                    if len(page) < 100:
                        break
                    start += 100
                cache[k] = ciks
                key_meta[k] = time.time()
                dirty = True
                print(f"  SIC {code:04d}: {len(ciks)} filers", file=sys.stderr)
            for c in ciks:
                members.setdefault(c, sector)   # first sector wins on overlap
    if dirty:
        cache["_fetched"] = key_meta
        with open(SIC_CACHE, "w") as fh:
            json.dump(cache, fh)
    return members


def load_ticker_map():
    if not os.path.exists(TICKERS_CACHE):
        raw = _get("https://www.sec.gov/files/company_tickers.json")
        with open(TICKERS_CACHE, "wb") as fh:
            fh.write(raw)
    with open(TICKERS_CACHE) as fh:
        rows = json.load(fh)
    out = {}   # cik -> shortest (primary-class) ticker
    for row in rows.values():
        cik, tik = int(row["cik_str"]), row["ticker"].upper()
        if cik not in out or len(tik) < len(out[cik]):
            out[cik] = tik
    return out


# ---------------------------------------------------------------------------
# stage 2 — bulk fundamentals via XBRL frames
# ---------------------------------------------------------------------------
def latest_target_years():
    """Frames lag filings; the newest broadly-populated annual frame is
    usually last calendar year. Return (current, prior, fallback)."""
    y = time.gmtime().tm_year - 1
    return y, y - 1, y - 2


def fetch_frame(concept, period, unit="USD"):
    url = (f"https://data.sec.gov/api/xbrl/frames/us-gaap/{concept}/"
           f"{unit}/{period}.json")
    d = _get_json(url, ok404=True)
    return {} if d is None else {row["cik"]: row["val"] for row in d["data"]}


def merged_frame(concepts, years, unit="USD"):
    """{cik: (year, val)} — newest year wins, concept order breaks ties."""
    out = {}
    for year in years:                      # newest first
        for concept in concepts:
            frame = fetch_frame(concept, f"CY{year}", unit)
            for cik, val in frame.items():
                if cik not in out:
                    out[cik] = (year, val)
    return out


def gather_bulk(members):
    cur, prior, fb = latest_target_years()
    print(f"  frames: target years CY{cur} (prior CY{prior}, fallback CY{fb})",
          file=sys.stderr)
    revenue = merged_frame(REVENUE_CONCEPTS, [cur, prior])
    revenue_prior = merged_frame(REVENUE_CONCEPTS, [prior, fb])
    flows = {name: merged_frame(cs, [cur, prior])
             for name, cs in FLOW_CONCEPTS.items()}
    dps = merged_frame(DPS_CONCEPTS, [cur, prior], unit="USD-per-shares")

    rows = []
    for cik, sector in members.items():
        if cik not in revenue:
            continue
        r_year, rev = revenue[cik]
        if not rev or rev <= 0:
            continue
        # growth needs the year strictly before the revenue year
        prev = revenue_prior.get(cik)
        growth = None
        if prev and prev[0] == r_year - 1 and prev[1]:
            growth = rev / prev[1] - 1.0
        def flow(name):
            hit = flows[name].get(cik)
            return hit[1] if hit and hit[0] == r_year else None
        op, ni, cfo, capex = (flow("operating_income"), flow("net_income"),
                              flow("cfo"), flow("capex"))
        fcf = (cfo - capex) if (cfo is not None and capex is not None) else cfo
        rows.append({
            "cik": cik, "sector": sector, "fy": r_year, "revenue": rev,
            "revenue_growth": growth,
            "operating_margin": (op / rev) if op is not None else None,
            "net_margin": (ni / rev) if ni is not None else None,
            "fcf_margin": (fcf / rev) if fcf is not None else None,
            "dividend": cik in dps and dps[cik][1] > 0,
        })
    return rows


# ---------------------------------------------------------------------------
# stage 3 — coarse pre-score, sector-relative
# ---------------------------------------------------------------------------
def band(val, lo, hi):
    if val is None:
        return None
    return max(0.0, min(1.0, (val - lo) / (hi - lo)))


def prescore(rows):
    by_sector = {}
    for row in rows:
        by_sector.setdefault(row["sector"], []).append(row)
    for sector_rows in by_sector.values():
        # sector percentile ranks per metric (None excluded)
        pct = {}
        for metric in BANDS:
            vals = sorted(r[metric] for r in sector_rows if r[metric] is not None)
            pct[metric] = vals
        for row in sector_rows:
            total, wsum = 0.0, 0.0
            for metric, (lo, hi) in BANDS.items():
                v = row[metric]
                absq = band(v, lo, hi)
                if absq is None:
                    continue
                vals = pct[metric]
                rank = 0.0
                if len(vals) > 1:
                    below = sum(1 for x in vals if x < v)
                    rank = below / (len(vals) - 1)
                w = PRESCORE_WEIGHTS[metric]
                total += w * (ABS_BLEND * absq + (1 - ABS_BLEND) * rank)
                wsum += w
            base = (total / wsum * 100) if wsum else 0.0
            row["prescore"] = round(
                min(100.0, base + (DIVIDEND_PAYER_BONUS if row["dividend"] else 0)), 1)
    return rows


# ---------------------------------------------------------------------------
# stage 4 — Alpaca tradability (shortlist finalists only)
# ---------------------------------------------------------------------------
def alpaca_tradable_set():
    """One bulk assets call -> set of active+tradable+fractionable symbols.
    Returns None (fail-open) if creds are missing or the call fails — the
    scout's per-ticker ma.py pass catches untradables downstream."""
    base = _ENV.get("ALPACA_PAPER_BASE_URL", "https://paper-api.alpaca.markets")
    base = base.rstrip("/")
    if base.endswith("/v2"):
        base = base[:-3]
    key, sec = _ENV.get("ALPACA_API_KEY"), _ENV.get("ALPACA_SECRET_KEY")
    if not (key and sec):
        return None
    try:
        d = _get_json(f"{base}/v2/assets?status=active&asset_class=us_equity",
                      headers={"APCA-API-KEY-ID": key, "APCA-API-SECRET-KEY": sec})
        return {a["symbol"] for a in d if a.get("tradable") and a.get("fractionable")}
    except Exception as e:
        print(f"  alpaca assets fetch failed ({e}) — skipping tradability filter",
              file=sys.stderr)
        return None


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------
def main(argv):
    force = "--force" in argv
    dry = "--dry-run" in argv
    cfg, screen_cfg = load_config()

    if not force and not dry and os.path.exists(UNIVERSE_PATH):
        with open(UNIVERSE_PATH) as fh:
            existing = json.load(fh)
        age_days = (time.time() - existing.get("generated_epoch", 0)) / 86400
        if age_days < screen_cfg["refresh_days"]:
            print(f"universe.json is {age_days:.0f}d old "
                  f"(< {screen_cfg['refresh_days']}d) — keeping. --force to refresh.")
            return 0

    print("stage 1: SIC sector membership …", file=sys.stderr)
    members = fetch_sic_members(screen_cfg["sic"], force=force)
    tmap = load_ticker_map()
    listed = {c: s for c, s in members.items() if c in tmap}
    print(f"  {len(members)} filers in scope, {len(listed)} with tickers",
          file=sys.stderr)

    print("stage 2: bulk fundamentals (XBRL frames) …", file=sys.stderr)
    rows = gather_bulk(listed)
    rows = [r for r in rows if r["revenue"] >= screen_cfg["min_revenue_usd"]]
    print(f"  {len(rows)} pass revenue floor "
          f"(${screen_cfg['min_revenue_usd']:,})", file=sys.stderr)

    print("stage 3: pre-score …", file=sys.stderr)
    rows = prescore(rows)

    print("stage 4: rank + tradability …", file=sys.stderr)
    tradable = alpaca_tradable_set()
    shortlist = []
    n = screen_cfg["top_n_per_sector"]
    counts = {}
    for sector in screen_cfg["sic"]:
        sector_rows = sorted((r for r in rows if r["sector"] == sector),
                             key=lambda r: -r["prescore"])
        counts[sector] = len(sector_rows)
        kept = 0
        for row in sector_rows:
            if kept >= n:
                break
            ticker = tmap[row["cik"]]
            if tradable is not None and ticker not in tradable:
                print(f"  {ticker}: not tradable/fractionable on Alpaca — skipped",
                      file=sys.stderr)
                continue
            shortlist.append({
                "ticker": ticker,
                "sector": "tech" if sector == "tech" else "food_staples",
                "cik": row["cik"], "fy": row["fy"],
                "prescore": row["prescore"], "dividend": row["dividend"],
                "revenue": row["revenue"],
                "metrics": {m: (round(row[m], 4) if row[m] is not None else None)
                            for m in BANDS},
            })
            kept += 1

    out = {
        "_note": ("Mechanical screen (scripts/screen.py). Pre-scores are a COARSE "
                  "filter only — the composite from score.py governs suggestions."),
        "generated": time.strftime("%Y-%m-%d", time.gmtime()),
        "generated_epoch": int(time.time()),
        "screened": {"filers_in_scope": len(listed),
                     "passed_revenue_floor": len(rows),
                     "per_sector": counts},
        "config": {k: screen_cfg[k] for k in
                   ("top_n_per_sector", "min_revenue_usd", "refresh_days")},
        "shortlist": shortlist,
    }
    if dry:
        json.dump(out, sys.stdout, indent=2)
        print()
    else:
        with open(UNIVERSE_PATH, "w") as fh:
            json.dump(out, fh, indent=2)
        print(f"wrote {UNIVERSE_PATH}: {len(shortlist)} candidates "
              f"({counts})")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
