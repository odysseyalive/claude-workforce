#!/usr/bin/env python3
"""selftest.py — no-network regression tests for the /invest scoring logic.

Run BEFORE and AFTER any calibration change (thresholds, weights, mappings):
    python3 scripts/selftest.py

Covers the pure functions only (no SEC/Alpaca calls):
  * reaction.classify        — the full classification matrix
  * reaction.confirm_threshold — volatility scaling, floor, cap
  * score.validate_cycle     — corroboration gate + flip-flop freeze
  * score.leaf_adjustments   — root gate, double-count guard, mappings
  * review.spearman          — rank correlation incl. ties
"""
import sys

sys.path.insert(0, __file__.rsplit("/", 1)[0])
from reaction import classify, confirm_threshold          # noqa: E402
from score import validate_cycle, leaf_adjustments        # noqa: E402
from review import spearman                                # noqa: E402

FAILURES = []


def check(name, got, want):
    if got != want:
        FAILURES.append(f"{name}: got {got!r}, want {want!r}")


# ---------------------------------------------------------------- classify
M = [  # polarity, reaction%, regime, trend_break, gap%, confirm%, expected
    ("positive",  3.0, "normal",    False,   0, 2.0, "confirming"),
    ("positive",  3.0, "depressed", True,  -20, 2.0, "confirming_reversal"),
    ("positive", -1.0, "normal",    False,   0, 2.0, "crowded"),
    ("positive", -1.0, "extended",  False,   5, 2.0, "crowded_extended"),
    ("positive", -1.0, "extended",  False,  30, 2.0, "crowded_reversion"),
    ("positive",  1.0, "normal",    False,  15, 2.0, "crowded"),
    ("positive",  1.0, "normal",    False,   0, 2.0, "none"),
    ("positive",  1.5, "normal",    False,   0, 1.2, "confirming"),   # vol-scaled
    ("positive",  1.5, "normal",    False,   0, 6.0, "none"),         # vol-scaled
    ("negative", -3.0, "normal",    False,   0, 2.0, "confirming"),
    ("negative", -1.5, "normal",    False,   0, 1.2, "confirming"),   # vol-scaled
    ("negative",  1.0, "normal",    False,   0, 2.0, "washed_out"),
    ("negative",  1.0, "depressed", False,  -5, 2.0, "washed_out_depressed"),
    ("negative",  1.0, "depressed", False, -20, 2.0, "washed_out_reversion"),
    ("negative", -1.0, "normal",    False, -20, 2.0, "washed_out"),
    ("negative", -1.0, "normal",    False,   0, 2.0, "none"),
]
for pol, rp, reg, tb, gap, cf, want in M:
    check(f"classify({pol},{rp},{reg},tb={tb},gap={gap},cf={cf})",
          classify(pol, rp, reg, tb, gap, cf), want)

# ------------------------------------------------------- confirm_threshold
flat = [100.0] * 200                       # zero volatility -> floor
check("threshold floor", confirm_threshold(flat, 199, 5), 1.0)
wild = [100.0 * (1.10 if i % 2 else 0.90) ** 1 for i in range(200)]
for i in range(1, 200):                    # alternating ±10% days -> cap
    wild[i] = wild[i - 1] * (1.10 if i % 2 else 1 / 1.10)
check("threshold cap", confirm_threshold(wild, 199, 5), 10.0)
check("threshold short-history fallback", confirm_threshold(flat[:10], 9, 5), 2.0)

# ----------------------------------------------------------- validate_cycle
EV2 = [{"source": "10-Q", "date": "2026-07-01", "type": "quantitative",
        "note": "inventory days +22% q/q"},
       {"source": "FT", "date": "2026-07-08", "type": "commentary",
        "note": "orders met with a shrug"}]
check("cycle none", validate_cycle("none", []), ("none", False, False))
check("cycle bare-string claim downgraded",
      validate_cycle("crested", []), ("mid", True, False))
check("cycle corroborated crested",
      validate_cycle({"read": "crested", "evidence": EV2}, []),
      ("crested", False, False))
check("cycle single source downgraded",
      validate_cycle({"read": "crested",
                      "evidence": [dict(EV2[0]), dict(EV2[0])]}, []),
      ("mid", True, False))
check("cycle no quantitative downgraded",
      validate_cycle({"read": "crested",
                      "evidence": [dict(EV2[1]),
                                   {**EV2[0], "type": "commentary"}]}, []),
      ("mid", True, False))
check("cycle undated downgraded",
      validate_cycle({"read": "early",
                      "evidence": [{**EV2[0], "date": None}, EV2[1]]}, []),
      ("mid", True, False))
check("cycle flip-flop frozen",
      validate_cycle({"read": "crested", "evidence": EV2},
                     ["crested", "mid", "crested"]),
      ("mid", False, True))
check("cycle stable history passes",
      validate_cycle({"read": "crested", "evidence": EV2},
                     ["mid", "crested", "crested"]),
      ("crested", False, False))

# --------------------------------------------------------- leaf_adjustments
strong, weak = 0.70, 0.40
a = leaf_adjustments(strong, {"expectation_reaction": "washed_out_reversion"})
check("reversion bonus (strong root)", a["expectation_reaction"], 6)
a = leaf_adjustments(weak, {"expectation_reaction": "washed_out_reversion"})
check("reversion bonus gated (weak root)", a["expectation_reaction"], 0)
a = leaf_adjustments(weak, {"expectation_reaction": "crowded_reversion"})
check("crowd penalty ungated", a["expectation_reaction"], -8)
a = leaf_adjustments(weak, {"expectation_reaction": "confirming"})
check("plain confirming ungated", a["expectation_reaction"], 2)
a = leaf_adjustments(strong, {"sentiment": -0.8,
                              "expectation_reaction": "washed_out"})
check("double-count halves weaker (sentiment)", a["sentiment"], 1.2)
check("double-count keeps stronger (reaction)", a["expectation_reaction"], 3)
a = leaf_adjustments(strong, {"sentiment": -1.0,
                              "expectation_reaction": "confirming"})
check("double-count halves weaker (reaction)", a["expectation_reaction"], 1.0)
check("double-count keeps stronger (sentiment)", a["sentiment"], 3.0)
a = leaf_adjustments(strong, {"sentiment": 0.5,
                              "expectation_reaction": "washed_out"})
check("opposite signs untouched", (a["sentiment"], a["expectation_reaction"]),
      (-0.75, 3))
a = leaf_adjustments(strong, {"cycle_read": {"read": "crested", "evidence": EV2}})
check("cycle crested weight", a["cycle_read"], -4)
check("cycle value surfaced", a["cycle_read_value"], "crested")
a = leaf_adjustments(strong, {"cycle_read": "crested"})
check("cycle uncorroborated scores 0", a["cycle_read"], 0)
check("cycle downgrade flagged", a["cycle_downgraded"], True)
a = leaf_adjustments(strong, {})
check("empty leaf all-neutral",
      (a["filing_change"], a["sentiment"], a["catastrophe"],
       a["expectation_reaction"], a["cycle_read"]), (0, 0.0, 0, 0, 0))

# ------------------------------------------------------------------ spearman
check("spearman perfect", spearman([1, 2, 3, 4], [10, 20, 30, 40]), 1.0)
check("spearman inverse", spearman([1, 2, 3, 4], [40, 30, 20, 10]), -1.0)
check("spearman too-few", spearman([1, 2], [1, 2]), None)
assert spearman([1, 1, 2, 3], [5, 5, 7, 9]) is not None   # ties don't crash

# ---------------------------------------------------------------- report
if FAILURES:
    print(f"FAIL — {len(FAILURES)} failure(s):")
    for f in FAILURES:
        print(f"  {f}")
    sys.exit(1)
print("selftest: all checks pass")
