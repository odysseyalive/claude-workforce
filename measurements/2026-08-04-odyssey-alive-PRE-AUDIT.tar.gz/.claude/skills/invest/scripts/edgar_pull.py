#!/usr/bin/env python3
"""edgar_pull.py <TICKER> — latest 10-K facts + Lazy-Prices filing-change input.

Requires edgartools (run via: uvx --from "edgartools[ai]" python3 edgar_pull.py ...)
and EDGAR_IDENTITY in the environment (SEC requires a self-identifying UA email).

Returns the latest 10-K's metadata, whether XBRL financials are available, and the
Risk Factors section length + a stable hash. Compare the hash/length across the two
most recent annual filings to compute the Lazy-Prices year-over-year textual-change
signal (mechanical; no AI). Big change in Risk Factors = a red-flag input.

This is a MECHANICAL gather helper (Layer 1). No scoring, no AI here.
"""
import hashlib
import json
import sys

try:
    from edgar import Company
except ImportError:
    print(json.dumps({"error": "edgartools not importable — run via "
          "uvx --from \"edgartools[ai]\" python3 edgar_pull.py <TICKER>"}))
    sys.exit(1)


def risk_factors_text(tenk):
    for attr in ("risk_factors",):
        try:
            v = getattr(tenk, attr)
            if v:
                return str(v)
        except Exception:
            pass
    return ""


def summarize_10k(ticker, filing):
    tenk = filing.obj()
    rf = risk_factors_text(tenk)
    financials_ok = False
    try:
        financials_ok = tenk.financials is not None
    except Exception:
        financials_ok = False
    return {
        "form": filing.form,
        "filing_date": str(filing.filing_date),
        "accession": filing.accession_no,
        "financials_available": financials_ok,
        "risk_factors_chars": len(rf),
        "risk_factors_sha256": hashlib.sha256(rf.encode("utf-8")).hexdigest()[:16] if rf else None,
    }


def main():
    if len(sys.argv) < 2:
        print("usage: edgar_pull.py <TICKER>", file=sys.stderr)
        sys.exit(2)
    ticker = sys.argv[1].upper()
    c = Company(ticker)
    tenks = c.get_filings(form="10-K")
    latest_two = tenks.latest(2)
    filings = latest_two if isinstance(latest_two, list) else [latest_two]
    out = {"ticker": ticker, "company": c.name, "filings": []}
    for f in filings:
        try:
            out["filings"].append(summarize_10k(ticker, f))
        except Exception as e:
            out["filings"].append({"accession": getattr(f, "accession_no", None),
                                   "error": type(e).__name__})
    # Lazy-Prices YoY hint: did Risk Factors change materially between the two 10-Ks?
    if len(out["filings"]) == 2 and all(x.get("risk_factors_chars") for x in out["filings"]):
        a, b = out["filings"][0], out["filings"][1]
        out["risk_factors_changed"] = a["risk_factors_sha256"] != b["risk_factors_sha256"]
        out["risk_factors_char_delta"] = a["risk_factors_chars"] - b["risk_factors_chars"]
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
