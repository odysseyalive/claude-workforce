#!/usr/bin/env bash
# Opportunity-Scout fetch helper — normalizes the scrape-friendly public JSON
# sources into a compact, dedup-ready TSV so the scout run doesn't hand-parse them.
#
# All sources here are PUBLIC (no login, no key). Per the skill's Public-Access Gate,
# ToS-walled sources (Upwork/LinkedIn/Indeed/Wellfound-detail/Facebook) are NOT here —
# those stay title+URL manual. Reddit blocks datacenter curl (403); fetch its
# `/search.json` via web_fetch (playwright) at runtime instead of here.
#
# Usage:
#   scout-fetch.sh n8n                       # n8n Community jobs board, newest-first, demand-side only
#   scout-fetch.sh github "<search query>"   # GitHub issues search (default: MCP bounty/for-hire)
#   scout-fetch.sh hn "<query>"              # Hacker News (Algolia) comments — "Who is hiring" etc.
#
# Output: TSV `date<TAB>source<TAB>title/snippet<TAB>url`, newest first.
# Freshness is the caller's job (index-format.md § Freshness): the `date` column is
# the POST creation date so aged posts can be flagged/dropped.

set -euo pipefail
UA="oa-opportunity-scout/1.0 (+contact: fmeetze@gmail.com)"

die() { echo "scout-fetch: $*" >&2; exit 2; }
command -v jq >/dev/null || die "jq not found"

cmd="${1:-}"; shift || true

case "$cmd" in
  n8n)
    # n8n Community "Jobs" category (Discourse). created_at is the true post date
    # (NOT the board bump time). Skip supply-side ("for hire" / "available for hire").
    url="https://community.n8n.io/c/jobs/13/l/latest.json"
    curl -s -A "$UA" --max-time 30 "$url" \
      | jq -r '
          .topic_list.topics[]?
          | select((.title|ascii_downcase) as $t
                   | ($t|test("for hire|available for|hire me|open to work"))|not)
          | [ (.created_at[0:10]), "n8n-board",
              .title,
              ("https://community.n8n.io/t/" + (.id|tostring)) ]
          | @tsv
        ' \
      || die "n8n fetch/parse failed"
    ;;

  github)
    # GitHub issues search — MCP / agent / web-dev demand posted as bounty / for-hire /
    # help-wanted issues. Public search API (unauth ~10 req/min — space calls).
    q="${1:-\"MCP server\" (bounty OR \"for hire\" OR hiring OR freelance) is:issue is:open}"
    enc=$(jq -rn --arg q "$q" '$q|@uri')
    curl -s -A "$UA" -H "Accept: application/vnd.github+json" --max-time 30 \
         "https://api.github.com/search/issues?q=${enc}&sort=created&order=desc&per_page=20" \
      | jq -r '
          if .message then error("github: " + .message)
          else .items[]?
            | [ (.created_at[0:10]), "github",
                (.title + "  [" + (.repository_url|sub("https://api.github.com/repos/";"")) + "]"),
                .html_url ]
            | @tsv
          end
        ' \
      || die "github fetch/parse failed (rate limit? space calls ~6s apart)"
    ;;

  hn)
    # Hacker News via Algolia — comments carry the monthly "Ask HN: Who is hiring?"
    # gigs (contract/remote/agent/MCP). Search comments, newest first.
    q="${1:-}"; [ -n "$q" ] || die "hn needs a query, e.g. hn \"MCP OR 'AI agent' contract\""
    enc=$(jq -rn --arg q "$q" '$q|@uri')
    curl -s -A "$UA" --max-time 30 \
         "https://hn.algolia.com/api/v1/search_by_date?query=${enc}&tags=comment&hitsPerPage=25" \
      | jq -r '
          .hits[]?
          | [ (.created_at[0:10]), "hn",
              ((.comment_text // "" | gsub("<[^>]*>";"") | gsub("&#x2F;";"/") | gsub("\n";" "))[0:180]),
              ("https://news.ycombinator.com/item?id=" + (.objectID|tostring)) ]
          | @tsv
        ' \
      || die "hn fetch/parse failed"
    ;;

  ""|-h|--help|help)
    grep '^#' "$0" | sed 's/^# \{0,1\}//'
    ;;

  *) die "unknown command '$cmd' (try: n8n | github | hn | help)" ;;
esac
