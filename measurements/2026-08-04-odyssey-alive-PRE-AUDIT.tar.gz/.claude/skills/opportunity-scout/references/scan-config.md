# Opportunity Scout — Scan Config
<!-- Enforcement: MEDIUM — the scoring + query backbone; hand-tunable. -->

The single place to tune what the scout looks for and how it scores. Edit this file as OA's positioning evolves; the workflow reads it every run.

## Service Lines (the scoring backbone)

Opportunities are scored against THESE, not generic relevance. Cross-check against `/business` (products/strategy) when positioning shifts.

**Ordered by what Francis actually delivers** (recalibrated 2026-07-06 — the top three are his real book of work; n8n was over-weighted before. See the memory note "delivery mix").

1. **MCP server / tool development** — hardcoded Model Context Protocol servers, tools, and client integrations. **Core.**
2. **AI-agent development / scripting** — custom-coded agents and agentic systems on the Claude API (orchestration, tool-use, agent scripts). **Core.**
3. **Web development** — websites and web apps for clients (Next.js, WordPress/Elementor, static/Hugo, etc.). **Core.**
4. **AI automation consulting / implementation** — "AI builds systems, not dependencies." General AI-automation delivery.
5. **Ticketing system integration** (event/venue ticketing platforms — Francis's Ticket Tomato experience is the anchor).
6. **Supabase / database-backed automation**
7. **Small-business process automation**
8. **n8n workflow automation** — **SECONDARY / adjacent.** Francis rarely takes pure-n8n work, so an n8n-*only* gig scores *adjacent at best*; an n8n post that's really agent / MCP / integration work scores on THOSE lines instead. Keep scanning the n8n board (it still surfaces agent/MCP-adjacent demand), just don't let pure-n8n dominate.
9. **Real estate tech / proptech** (RE Intelligence Platform pilots, agent-facing tools, brokerage automation) — pre-launch, so *long-shot* until launch.
10. **Vacation-rental / short-term-rental tech** (lower priority; adjacent to Francis's own property operation).

Capability keys (used by both fit-scoring and the partner taxonomy): `mcp`, `agents`, `web-dev`, `ai-automation`, `ticketing`, `supabase`, `smb-automation`, `n8n`, `proptech`, `str-tech`, `data`, `integrations`.

## Opportunity Types

- `rfp` — formal solicitations / procurement (businesses, municipalities, government).
- `gig` — short-term contract/freelance project work.
- `hiring` — companies hiring **fractional / contract / part-time** AI-automation help. NEVER full-time employment (Francis runs a consultancy). Contract-to-hire / ambiguous → surface with a `⚑ verify: contract?` flag; clearly-permanent FTE is discounted by engagement-fit and drops below the noise floor.

## Query Construction

Cross **type × service-keyword × geography** — never a flat query ("AI automation jobs" returns noise). Scale query count by type:
- **RFPs** → site-specific / procurement-portal searches (they don't SEO well).
- **Gigs** → platform-specific public search pages.
- **Hiring** → broader web search.

Example crossed queries (extend as needed) — **lead with the top-three lines (MCP / agents / web dev), n8n is secondary:**
- `"MCP server" OR "Model Context Protocol" developer contract OR freelance`
- `"MCP" tool developer hire Claude OR Anthropic`
- `"AI agent" developer contract OR freelance "Claude API"`
- `"agentic" OR "AI agent" build contract remote`
- `web developer contract Next.js OR WordPress remote`
- `freelance "web app" OR "web development" build contract`
- `ticketing system integration consultant`
- `AI automation consultant fractional`
- `"n8n" contract OR freelance` — SECONDARY: still run it, but score pure-n8n hits *adjacent* (Service Lines #8)
- `site:sam.gov "software" OR "artificial intelligence" services` (federal = low fit, cheap check)
- Local: `Tillamook OR Astoria OR "Lincoln City" web developer OR software OR automation RFP OR contract`, `Portland "AI agent" OR "web development" OR automation contract`

**Walled hits are logged, never silently skipped.** When discovery surfaces a *specific* listing on a login-walled platform (Upwork, LinkedIn, Indeed, Glassdoor, ZipRecruiter, …), do NOT fetch behind the wall (Public-Access Gate) — log it in `opportunity-index.md` as **title + URL** with a `⚑ walled — open manually` flag, fit-scored from whatever the public search snippet shows, and fold it into the run report. Only generic search-hub/aggregate pages (no specific listing) are dropped as noise.

## Fetch Tooling (scrape helpers)

`scripts/scout-fetch.sh` normalizes the scrape-friendly **public** JSON sources into compact TSV (`date <TAB> source <TAB> title/snippet <TAB> url`, newest-first) so the revisit leg doesn't hand-parse them:

- `bash scripts/scout-fetch.sh n8n` — n8n Community jobs board (Discourse `latest.json`); true `created_at` (not board-bump), builds `/t/<id>` URLs, supply-side filtered.
- `bash scripts/scout-fetch.sh github "<query>"` — GitHub issues search. **Low gig-signal** (mostly technical MCP issues, not contract work) — ecosystem awareness, not a lead source.
- `bash scripts/scout-fetch.sh hn "<query>"` — Hacker News via Algolia comments: the monthly "Who is hiring?" / "Seeking freelancer?" threads — the **best public demand surface** for the MCP/agent/web-dev lines. Filter DEMAND-side, skip "wants to be hired".

**Not covered by the script** (fetch another way, still no login): **Reddit** blocks datacenter curl (HTTP 403) → `web_fetch` its `r/<sub>/search.json`. **Public Notice Oregon** is session/postback-bound → playwright-drive per its source-index entry (pick "Call For Bids" → scrape `Search.aspx`). Walled platforms (Upwork/LinkedIn/Indeed/Wellfound-detail/Facebook) stay **title + URL manual** (Public-Access Gate).

## Home Region (local layer)

- **Anchor:** Rockaway Beach, OR.
- **Bounds:** north → Astoria (Clatsop Co.); south → Lincoln City (Lincoln Co.); east → Portland metro (Hwy 6/26 corridor). Spans Tillamook + Clatsop + Lincoln counties + Portland metro.
- **Places** (extend freely): Rockaway Beach, Tillamook, Manzanita, Wheeler, Garibaldi, Pacific City, Astoria, Seaside, Cannon Beach, Warrenton, Lincoln City, Newport, Hillsboro, Beaverton, Portland.
- **Rule:** anything inside the region is treated as `scope: local` and gets the local fit boost (below). The boost is uniform across the whole region — not a graduated radius. Discovery stays the three types scoped regionally; the scout does NOT prospect un-posted local businesses.

## Fit-Probability Calibration

The 0–1 fit score is a weighted blend of four factors (weights tunable):

| Factor | Weight | High → Low |
|--------|--------|------------|
| **Service-line alignment** | ~0.45 (dominant) | direct named match (MCP dev, AI-agent/Claude-API build, web dev, ticketing integration) → general AI/automation → pure-n8n or tangential |
| **Deliverability vs solo capacity** | ~0.25 | solo+AI deliverable → needs a skill a **bench partner covers** (near-full; fires partner-match) → needs a capability nobody on the bench has (big discount) |
| **Local proximity** | ~0.15 | in-region (boosted) → outside (baseline) |
| **Engagement fit** | ~0.15 | clean contract/fractional/biddable RFP → heavy enterprise/bonding or FTE-shaped (discounted) |

**Tiers:** `≥0.70` strong · `0.45–0.70` adjacent · below → long-shot. All three tiers are logged; only genuine noise (≈`<0.25`) is dropped.

**Deadline is NOT a fit factor** — it's a separate **actionability gate**: deadline passed → flush; too-soon-to-respond / closed → flag. Fit answers "is it a match"; actionability answers "can I still act."

Each logged opportunity carries a 1–3 sentence **"why this fits"** note — the thing Francis reads before deciding to act.

## Local Channels (human-in-the-loop + public)

- **Craigslist** — first-class public source (region gigs / computer / services / "for hire"). No login. The clean analogue of local "I need this" posts. Categories per board: `ggg` (gigs), `cpg` (computer gigs), `sad` (software/QA/DBA), `cps` (computer services wanted).
- **Newspaper classifieds + legal notices** — public, and the **legals carry public-notice RFPs** small agencies never post anywhere else. Ride the source-index entries each run: Tillamook Headlight-Herald, Tillamook County Pioneer, The Astorian, The News Guard (Lincoln City), Newport News-Times, and the statewide **Public Notice Oregon** aggregator.
- **Chambers / EDD boards** — public job + RFP boards: Tillamook Area Chamber, Astoria-Warrenton Area Chamber, Lincoln City Chamber, Col-Pac Economic Development District (regional RFPs).
- **Facebook** (Marketplace / local groups) — login-walled + anti-automation + ban risk. NO bot login/scrape/reply. The scout maintains a **human-in-the-loop checklist** here of the specific groups/searches worth Francis eyeballing; he pastes finds back and they're scored + logged normally. Public FB **Page** posts may be `web_fetch`ed on public URLs only.

**Manual-check checklist** (surface during every full run; extend/prune as Francis identifies what's useful):
- FB Marketplace → "services" filtered to Tillamook/Clatsop/Lincoln counties
- FB groups (suggestions — confirm real names): Tillamook County buy/sell/trade, Manzanita–Rockaway–Wheeler community, North Oregon Coast jobs/networking, Astoria/Warrenton community board
- Go Fractional jobs (bot-walled source, see source-index) · Tillamook Creamery careers (bot-walled)
- **Walled-board saved searches — the core lines (MCP / AI-agent / web-dev).** Francis's own logged-in browsing; the scout NEVER logs in (Public-Access Gate). Anything he pastes back gets scored + logged like any candidate. These are where the real contract demand for his work concentrates (2026-07-06 finding):
  - **Upwork** (sort by newest — `&sort=recency`):
    - MCP: `https://www.upwork.com/nx/search/jobs/?q=%22MCP%20server%22%20OR%20%22Model%20Context%20Protocol%22&sort=recency`
    - AI agent / Claude: `https://www.upwork.com/nx/search/jobs/?q=%22AI%20agent%22%20(Claude%20OR%20Anthropic)&sort=recency`
    - Web dev: `https://www.upwork.com/nx/search/jobs/?q=(Next.js%20OR%20WordPress%20OR%20%22web%20app%22)%20developer&sort=recency`
  - **LinkedIn Jobs** (contract filter `f_JT=C`, remote `f_WT=2`):
    - `https://www.linkedin.com/jobs/search/?keywords=%22MCP%22%20OR%20%22AI%20agent%22&f_JT=C&f_WT=2&sortBy=DD`
    - `https://www.linkedin.com/jobs/search/?keywords=Claude%20OR%20Anthropic%20developer&f_JT=C&sortBy=DD`
  - **Wellfound** (contract/fractional filter): search `MCP`, `AI agent`, `Claude` at `https://wellfound.com/jobs` — startup contract roles (detail behind login → paste title+URL).
  - **Contra** (already a scanned source, but the Claude/AI vertical is richer logged-in): `https://contra.com/hire/claude-freelancers` and the AI-agent vertical.
