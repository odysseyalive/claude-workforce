# Opportunity Scout — Credentialed Sources
<!-- Enforcement: HIGH — the SKILL.md Credential Guardrail Gate governs every entry here. -->

Most sources are public and need nothing. A few gate their listings behind a **free registration to read** or an **API key**. This file is the registry of those, and the procedure for wiring them — **legitimately only**.

## The Pattern (detect → guide → paste → reuse)

1. **Detect.** During `scout` / `add-source`, a source's listings need auth. Classify the auth need:
   - Free registration to **READ** a portal → LEGITIMATE.
   - An **API key** the source issues → LEGITIMATE.
   - Login required to scrape a **ToS-protected** site (Upwork, LinkedIn, Indeed, Facebook) → **FORBIDDEN.** Stop; log title + URL only (Public-Access Gate). Do not wire it here.
2. **Guide.** For a legitimate need, tell Francis the exact labeled key to add to `.env.local`, e.g.:
   ```
   OPPSCOUT_OREGONBUYS_KEY=…      # or the registration email/handle if the portal uses account-based read access
   ```
   Use the prefix `OPPSCOUT_<SOURCE>_…`. Explain in one line what the key unlocks.
3. **Never** create the account, type a password into a login form, or accept/store a raw password in any file. **The skill guides; Francis pastes.** He registers and adds the key himself.
4. **Record** the source in the registry below (label · what the key unlocks · env var name). **Reuse** the key on later runs — read it from `.env.local`, never re-prompt once present.

## Registry

_(Append one row per wired source. Empty until Francis wires the first one.)_

| Source | Unlocks | Env var | Added |
|--------|---------|---------|-------|
| SAM.gov | JSON search of federal contract opportunities — `api.sam.gov/opportunities/v2/search` | `OPPSCOUT_SAMGOV_KEY` | 2026-07-06 |

## Pending wiring — recommended (2026-07-06)

Detected needs awaiting Francis's paste. Once the key lands in `.env.local`, move the row up into the Registry.

1. **SAM.gov — Get Opportunities API** — *WIRED + verified 2026-07-06 (moved to Registry above).*
   - `OPPSCOUT_SAMGOV_KEY` is live in `.env.local` and the API answers. Query shape: `api.sam.gov/opportunities/v2/search?api_key=…&postedFrom=MM/dd/yyyy&postedTo=MM/dd/yyyy&title=<term>&ptype=o,p,k&limit=25` — `postedFrom`/`postedTo` are REQUIRED and must be `MM/dd/yyyy`.
   - **First-run finding (low fit):** a 30-day pull skews hard away from OA — `title=automation` returned only Building-Automation-System / HVAC facilities work; `artificial intelligence` returned only large DoD/VA AI programs (prime-contractor + clearance shaped); `software` returned commodity license / sole-source buys. None fit a solo AI-automation consultancy. Keep it on the revisit leg (cheap call) but expect rare hits — it will not carry the pipeline. Future tuning: filter by IT NAICS 541511/541512 + small-business set-asides rather than title keywords.

2. **Lincoln County bids** — *RESOLVED 2026-07-06: no credential needed after all.*
   - The 2026-07-01 "Euna/Ion Wave portal" lead was wrong (`col.ionwave.net` = Lincoln, Nebraska). Lincoln County OR posts bids **publicly** on its CivicPlus site — the scout reads them without auth.
   - Optional for Francis (email only, no account): subscribe at https://www.co.lincoln.or.us/list.aspx to the **County Administration** list ("Requests for Proposals and other postings") and **Public Works**. Allow `listserv@civicplus.com` past spam. No env var to add.

**Not wireable, ever (immutable directive):** Upwork, LinkedIn, Indeed, Facebook logins. Those hits are logged title + URL with a `⚑ walled — open manually` flag; Francis's own logged-in browsing (paste-back) is the coverage path.

## Hard rules (from the SKILL.md Credential Guardrail Gate)

- Legitimate auth only (free-read registration or API key). Never credentials to scrape a ToS-walled site.
- The skill NEVER creates accounts, NEVER handles/stores raw passwords, NEVER logs in on Francis's behalf.
- Keys live in `.env.local` (like `GMAIL_*`, `QUO_*`, `ZOHO_*`), never in this file or any index.
