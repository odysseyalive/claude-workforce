# Opportunity Scout — Index Format
<!-- Enforcement: MEDIUM — schemas + dedup/expiry/decay rules; the Insert-Only Index Gate governs all writes. -->

Three skill-local, model-facing markdown indexes. They are the scout's working memory (not a human report — the chat summary is the human surface). All writes are **insert-only** per the SKILL.md Insert-Only Index Gate: append entries / append update-notes / flush per the rules below / update machine fields only. Never rewrite an existing entry and never change a `STATUS`.

---

## opportunity-index.md

One entry per opportunity. Suggested entry shape:

```
## <title> — <org>
- found: 2026-07-01
- source: https://…       # REQUIRED — a real public listing/posting URL; never blank/"unknown"/bare domain
- type: rfp | gig | hiring
- scope: local | national
- fit: 0.86 (strong)   # 0–1 probability + tier
- why: <1–3 sentence "why this fits">
- deadline: 2026-07-20   # or "none"
- needs-partner: no      # or "yes → <partner name>"
- status: new            # new → reviewing → contacted → passed | won  (FRANCIS EDITS THIS)
- last-seen: 2026-07-01
- notes:
  - 2026-07-05: deadline moved to Aug 1 (update-note)
```

- `status` is **Francis's field** — the scout only ever writes `new` on creation; transitions are manual.
- **`source:` is REQUIRED and must be a real listing/posting URL** (Source-Link Required Gate, SKILL.md). An entry is never written without it, and every surfaced row (chat summary, `status`, `/agenda` feed) renders its `↗ <source url>`. A candidate with no resolvable URL is not logged — it goes to the human-review checklist instead. Never fabricate a URL.
- **Dedup:** primary key = `source` URL; secondary = fuzzy title + org. A re-seen listing with a changed deadline or a reappearance-after-gone → append a dated `notes:` update-note, NOT a new entry. Same job cross-posted (e.g. two boards) → one entry, alt source noted in `notes`.
- **Expire-flush:** an entry expires when its `deadline` has passed, OR (undated) it has gone `last-seen`-stale for **N=3 runs / ~21 days**. Flush = remove the whole entry — BUT preserve human-advanced entries: `reviewing` / `contacted` / `won` are NEVER auto-flushed (only `new` / `passed` expire out). When in doubt, keep.

---

## source-index.md

One entry per re-checkable **place to look** (not a single listing). Suggested shape:

```
## <label>
- url: https://…
- type: procurement | gig-board | careers | rfp-aggregator | craigslist | chamber | other
- scope: local | national
- provenance: discovered | user-seeded
- query-hint: https://…/careers?q=automation   # the exact sub-page to re-fetch each run
- last-checked: 2026-07-01
- yield: 3 (avg fit 0.61)   # aggregate of what it has produced
- consecutive-empty: 0
- status: active | decayed
```

- **Promotion (discovered):** a page earns an entry when it yields ≥1 opportunity at/above the **strong (or high-adjacent)** fit bar.
- **Auto-decay (discovered):** `status: decayed` / drop on a 404 or after **K=4** consecutive-empty checks. Silent.
- **User-seeded (longer leash + confirm):** `provenance: user-seeded` sources decay only after **~2× K** consecutive-empty checks, and the scout **asks Francis before dropping** one he added (AskUserQuestion). Never silently remove a hand-added source.

---

## partner-index.md

Francis's programmer/partner bench. Populated via `add-partner` (or by hand). Suggested shape:

```
## <name>
- url: https://www.linkedin.com/in/…
- abilities: [web-dev, integrations, …]   # capability keys from scan-config.md § Service Lines
- good-for: <the kinds of projects/service-lines this partner covers>
- seniority: <e.g. senior full-stack>
- availability: <e.g. big-project overflow>
- notes: <cross-refs, e.g. also in project h1websites.org>
```

- **Capability taxonomy:** `abilities` MUST use the capability keys from scan-config.md so partner-match is a clean lookup against an opportunity's required skills.
- Partner entries are stable/hand-curated — the scout never auto-invents a partner; `scout` only *names* existing bench members in a `needs-partner` flag.

---

## Run Bounds & State

A `scout` run has two legs — the **source-index revisit always completes**; **fresh discovery is bounded**.

- **Default weight = thorough:** ~30–40 prioritized discovery queries + deeper fetches. `--quick` → ~8–12 queries, favoring the curated source bench over broad discovery.
- **Per query:** scan ~top-10 results; `web_fetch` the ~3–5 most promising. Cap total fetches/run; **space same-domain fetches** (politeness). Never a walled page (Public-Access Gate).
- **Stop rule:** finish the revisit leg always; run discovery up to the budget but **stop early on diminishing returns** (queries stop surfacing anything new).
- **"New since last run":** the opportunity-index IS the seen-set (dedup by URL/title). A small **run-state marker** at the top of `opportunity-index.md` (`<!-- run-state: last-run=YYYY-MM-DD, runs=N -->`) lets the summary say "3 new since last run" and drives source `consecutive-empty` counting. No separate seen-set file.

---

## Freshness (post age, NOT board activity)

**Rule (learned 2026-07-01):** judge an opportunity's freshness by its **creation date**, never by a board's "latest activity" / bump time. Forum boards (Discourse, etc.) sort by last reply, so a months-old post with a fresh reply looks new but is almost certainly filled.

- For **Discourse boards** (e.g. n8n Community), read `created_at` from the JSON API (`<board>.json` → `.topic_list.topics[].created_at`), not the HTML list's relative time.
- **Actionability by age (default):** `created_at` ≤ ~3 wks → **fresh/active**; ~3–10 wks → log but tag `⚠ aged — verify still open`; > ~10 wks → **do not log** (or flush on reconcile) as effectively filled. Long-term/retainer posts get more leeway (verify rather than auto-flush).
- On a reconcile, re-check existing entries' `posted:` age and flush the ones past the window (masquerading freshness is the failure this guards against).

## Chat Summary (each `scout` run)

Diff, not dump — surface only what's **new/changed this run**; the full open list lives in `status`.

1. **Brief prose lead** — 1–2 sentences: what turned up + the standout.
2. **Fit-tier-grouped ranked list** — STRONG → ADJACENT → LONG SHOT. Each item: `[type · local|national]` title — org · deadline · `(0.NN)`; a 1-line why-fit note (the entry's `why:` summary); the source link `↗ <source url>` (the entry's `source:`); and `⚑ needs partner → <name>` when partner-match fired.
3. **Footer** — housekeeping (updates, expired-flushed count, sources promoted/decayed) + counts (`open · passed · won`) + a pointer to `/opportunity-scout status`.

Example:

```
3 new since your last scout (Fri) — standout is a City of Astoria ticketing RFP, local and in your wheelhouse.

STRONG
• [rfp · local] Ticketing platform integration — City of Astoria · due Jul 20   (0.86)
  Direct ticketing match; mirrors your Ticket Tomato work.
  ↗ https://oregonbuys.gov/rfp/astoria-ticketing
• [gig · national] n8n workflow build, contract — Acme Co (remote)              (0.74)
  Straight n8n automation build; clean remote contract.
  ↗ https://community.n8n.io/t/hiring-n8n-workflow-build/12345

ADJACENT
• [hiring · Portland] Fractional automation consultant — Metro startup          (0.58)
  General automation, no ticketing specificity.  ⚑ needs partner → Barak (web-dev)
  ↗ https://example.com/jobs/fractional-automation

LONG SHOT
• [gig · local] Proptech pilot advisor — Lincoln City brokerage                 (0.36)
  ↗ https://example.com/gigs/proptech-pilot

Updates: 1 (City of X RFP deadline → Aug 1). Flushed 2 expired. Promoted 1 source (OregonBuys).
Open: 14 · passed: 2 · won: 1 — full picture in /opportunity-scout status.
```

## Status Output (`status` mode)

Unlike the Chat Summary (diff of what's new this run), `status` shows the **full open list**. Same per-item shape as the Chat Summary so the two read consistently — and so does the `/agenda` Opportunities section, which renders these same entries.

Each open opportunity, grouped by fit tier (STRONG → ADJACENT → LONG SHOT):

- `[type · local|national]` title — org · `(0.NN)`
- the `why:` brief summary (1 line)
- the source link `↗ <source url>` (the entry's `source:`)
- `⚑ needs partner → <name>` when a partner-match is on the entry

Footer: the source bench + partner bench (per SKILL.md Workflow: Status) and the `open · passed · won` counts.

Example:

```
STRONG
• [hiring · national] Freelance AI Automation Engineer — TargetPatientsMD   (0.70)
  Claude-first n8n lead-gen automation; strong skills fit.
  ↗ https://community.n8n.io/t/hiring-freelance-ai-automation-engineer-remote/299853

ADJACENT
• [hiring · national] Sales Tech & Automation Specialist — sales agency      (0.62)
  Ongoing CRM + database automation; adjacent to core lines.
  ↗ https://community.n8n.io/t/hiring-sales-tech-automation-specialist-ongoing-remote-work-crm-databases/300286

Sources: 6 active (4 national · 2 local). Partners: 2 on bench.
Open: 2 · passed: 0 · won: 0
```
