# Partner Index

Francis's programmer/partner bench — used by `scout` partner-match when a job exceeds solo (Francis + AI) capacity. Populated via `/opportunity-scout add-partner <linkedin-url>` (or by hand). `abilities` use the capability keys from [references/scan-config.md](references/scan-config.md) § Service Lines so partner-match is a clean lookup. See [references/index-format.md](references/index-format.md) § partner-index.md for the schema.

> Policy (Francis, 2026-07-01): only include a partner whose profile can actually be established. Unverifiable seeds are dropped rather than carried as empty placeholders.

## Barak Tutterrow (H1 Websites LLC)
- url: https://www.linkedin.com/in/h1websites/
- abilities: [web-dev, integrations]
- good-for: web development / site builds / e-commerce / WordPress / PHP-backed sites; the go-to for the front-end + CMS half of a build
- seniority: senior — President/owner of H1 Websites LLC (Portland/Molalla OR, 15+ yrs; Google Partner)
- availability: big-project overflow (active collaborator, not always free)
- notes: CONFIRMED 2026-07-01 via public web (LinkedIn walled). Already collaborating in project `h1websites.org` (Viztech import / Amish furniture change-orders). Contact via h1websites.com. Stack: HTML/CSS/PHP/SQL, e-commerce, digital marketing. (H1 also does SEO/marketing — outside OA's own service lines, but relevant capability.)

## Sjoerd Tiemensma
- url: https://www.linkedin.com/in/sjoerd-tiemensma-67aa703a/
- abilities: [ai-automation, n8n, smb-automation]
- good-for: no-code / AI-native workflow automation (n8n + Make.com); content & document-generation automations; extra n8n/AI build hands when the automation itself is the heavy part
- seniority: senior — independent automation specialist; Make.com Level 5 Expert; active n8n writer/speaker (Medium "Use AI", Substack 2K+, London Prompt Engineering Conference 2026)
- availability: independent freelancer (Netherlands / remote)
- notes: CONFIRMED 2026-07-01 via public web (LinkedIn walled). Sites: tiemensma.dev · medium.com/@sjoerd.tiem · useai.substack.com · ko-fi.com/sjoti. Built an AI marketing-bureau demo (Reclamebureau Eva, for Jinek) and an audio→report doc-generation app; founder of the AI Productivity Hub (Skool). Peer-level independent — strongest exactly where OA is strong (n8n/AI automation), so best as overflow capacity on big automation builds rather than a different-skill complement.
