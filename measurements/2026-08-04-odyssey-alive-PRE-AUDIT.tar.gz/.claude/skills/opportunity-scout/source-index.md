# Source Index

Re-checkable places to look, revisited each `scout` run. Machine-maintained (insert-only) + hand-editable. See [references/index-format.md](references/index-format.md) § source-index.md for the schema, promotion, and decay rules. Pre-seeded below; `provenance: discovered` entries are added by promotion, `user-seeded` by `/opportunity-scout add-source`.

## National

## SAM.gov
- url: https://sam.gov/search/
- type: procurement
- scope: national
- provenance: user-seeded
- query-hint: https://sam.gov/search/?keywords=automation%20OR%20%22artificial%20intelligence%22
- last-checked: 2026-07-06
- yield: 0
- consecutive-empty: 1
- status: active
- notes: 2026-07-06 — the HTML search is JS-heavy and unreliable for machine reads. The clean path is the free **Get Opportunities API**: once `OPPSCOUT_SAMGOV_KEY` exists in `.env.local` (see references/credentialed-sources.md § Pending wiring), query `https://api.sam.gov/opportunities/v2/search?api_key=…&title=automation&ptype=o&limit=25` instead of the HTML page. Public HTML stays the fallback.
  - 2026-07-06 (KEY WIRED + first run): `OPPSCOUT_SAMGOV_KEY` is live and the API works. Correct query needs REQUIRED `postedFrom`/`postedTo` in `MM/dd/yyyy`: `…/v2/search?api_key=…&postedFrom=MM/dd/yyyy&postedTo=MM/dd/yyyy&title=<term>&ptype=o,p,k&limit=25`. First 30-day pull (automation / "artificial intelligence" / software): 0 OA-fit — federal work is Building-Automation-System/HVAC facilities, huge DoD/VA AI programs (primes + clearances), and commodity software-license/sole-source buys. None logged (all below the noise floor). Verdict: keep on the revisit leg (cheap API call) but it will not carry the pipeline; future tuning = IT NAICS 541511/541512 + small-biz set-asides instead of title keywords. See references/credentialed-sources.md § Registry.

## We Work Remotely
- url: https://weworkremotely.com/
- type: gig-board
- scope: national
- provenance: user-seeded
- query-hint: https://weworkremotely.com/remote-jobs/search?term=automation
- last-checked: never
- yield: 0
- consecutive-empty: 0
- status: active

## Contra
- url: https://contra.com/
- type: gig-board
- scope: national
- provenance: user-seeded
- query-hint: https://contra.com/search?q=automation
- last-checked: never
- yield: 0
- consecutive-empty: 0
- status: active

## Mac's List (Oregon)
- url: https://www.macslist.org/
- type: gig-board
- scope: national
- provenance: user-seeded
- query-hint: https://www.macslist.org/jobs?search=automation
- last-checked: never
- yield: 0
- consecutive-empty: 0
- status: active

## n8n Community — Jobs
- url: https://community.n8n.io/c/jobs/
- type: gig-board
- scope: national
- provenance: discovered
- query-hint: https://community.n8n.io/c/jobs/l/latest
- yield: 9 (full run 2026-07-01: 9 fresh on-target demand-side gigs logged; highest-signal source so far). Quick pass 2026-07-02: top-of-board was bumped older posts; 1 aged strong-fit (Claude API 31-agent, topic 286780) newly logged, no genuinely-fresh demand-side gig. Full run 2026-07-06: 4 fresh logged (Swiss plumbing/HVAC 302292, telecom-OSS 300396, $1,500/mo 299818, German 302210); 31-agent (286780) flushed as >10 wks. Quick pass 2026-07-14: 1 fresh logged (Yokeru integrations/voice-agent, 302688, adjacent 0.52); 302973 (ElevenLabs guidance) dropped — OP posted they moved to a different approach (closed); 303006 ($25 review) below noise floor. Quick pass 2026-07-29: 0 new demand-side — every topic in the latest slice was already adjudicated here. Two re-surfaced and stay UNLOGGED on the record already in this note: 302973 (ElevenLabs guidance, closed 07-14) and 304325 (Globi Guard free-design-partner pitch, below noise floor 07-23). 299853 + 300286 aged-flagged (~6 wks, absent from the latest slice). consecutive-empty → 3. Worth noting the yield note is doing real work now: both items would have been re-logged as fresh without it.
- last-checked: 2026-07-29
- consecutive-empty: 3
- status: active
- notes: promoted 2026-07-01. Public Discourse forum, no login. Use the `/l/latest` view + filter to recent (≤7d); skip supply-side "Available for hire"/"For Hire" posts. Per-topic URLs aren't exposed by the board fetch — log title as `find:` and click through.
  - 2026-07-20 (quick pass): 0 new demand-side. Board top was 303770 ("looking for guidance and mentor", supply-side) — everything else already logged. consecutive-empty → 1.
  - 2026-07-23 (quick pass): 0 new demand-side. Two posts newer than last run, both non-opportunities: 304500 (YIS Agency "offering assistance", supply-side) and 304325 ("Looking for 10 n8n Teams Building AI Agents" — vendor Globi Guard recruiting FREE design partners for their AI-authorization product; a product pitch, no paid work → below noise floor). consecutive-empty → 2.
  - 2026-07-06 (TOOLING + reweight): now fetched via `bash scripts/scout-fetch.sh n8n` — parses `created_at` (true post date, not board-bump), builds per-topic URLs (`/t/<id>`), and skips supply-side. Re-checked run #2: no NEW demand-side gigs beyond those already logged. Per the 2026-07-06 backbone recalibration, n8n is now a **SECONDARY** line — pure-n8n gigs score adjacent-at-best; keep the board for agent/MCP-adjacent posts, don't let it dominate.

## Go Fractional — Jobs
- url: https://www.gofractional.com/jobs
- type: gig-board
- scope: national
- provenance: discovered
- query-hint: https://www.gofractional.com/jobs
- last-checked: 2026-07-01
- yield: 0
- consecutive-empty: 0
- status: manual-check (bot-walled)
- notes: 2026-07-01 — a titles-capturing re-fetch hit a Cloudflare "Just a moment…" bot challenge. Per the ToS guardrail we do NOT bypass it, so this is a MANUAL-CHECK source: Francis browses it himself (like the FB checklist) and pastes anything relevant. The scout must not auto-fetch it. Relevant (251 fractional/contract-to-hire senior roles), just not machine-scrapable.

## Discogs (Zink Media)
- url: https://www.discogs.com/
- type: careers
- scope: national
- provenance: user-seeded
- query-hint: https://discogsinc.pinpointhq.com/
- last-checked: never
- yield: 0
- consecutive-empty: 0
- status: active
- notes: 2026-07-02 (user-seeded). Music-data/marketplace company; careers run through a Pinpoint ATS (discogsinc.pinpointhq.com) plus a RecruitiFi agency channel — they do use contractors. Watch for remote eng/data/automation-adjacent contract roles; most postings are FTE (discount those). Public ATS, no login.

## GitHub — MCP / Claude bounties + "for hire" issues
- url: https://github.com/
- type: gig-board
- scope: national
- provenance: user-seeded
- query-hint: https://github.com/search?q=%22MCP+server%22+%28bounty+OR+%22for+hire%22+OR+hiring%29&type=issues&s=created&o=desc
- last-checked: never
- yield: 0
- consecutive-empty: 0
- status: active
- notes: 2026-07-06 (user-seeded — MCP/agent/web-dev lane per delivery-mix recalibration). Public code-host search. MCP-dev demand often posts as bounty / help-wanted issues rather than job listings. Also try `"Model Context Protocol" freelance` and `type=repositories q="mcp" "hiring"`. Skip supply-side self-promo.
  - 2026-07-06 (first run via `scripts/scout-fetch.sh github`): LOW gig-signal — the issues search returns mostly technical MCP issues / bug reports / feature requests (GitHub is where MCP gets BUILT, not where the contract WORK is posted). Bounty-labeled gigs are rare. Keep as a light ecosystem-awareness check, not a primary lead source. last-checked 2026-07-06.

## Reddit — r/mcp + r/ClaudeAI (hiring posts)
- url: https://www.reddit.com/r/mcp/
- type: other
- scope: national
- provenance: user-seeded
- query-hint: https://www.reddit.com/r/mcp/search.json?q=hiring%20OR%20freelance%20OR%20bounty%20OR%20paid&restrict_sr=1&sort=new
- last-checked: 2026-07-29
- yield: 0
- consecutive-empty: 2
- status: active
- notes: 2026-07-06 (user-seeded — MCP/agent lane). Public JSON (`/search.json`) — no login. Mirror the same query on r/ClaudeAI and r/AI_Agents. Log demand-side "hiring/paid/bounty" posts; skip supply-side "I built…" / "for hire" self-promo.
- notes: 2026-07-29 — checked (revisit leg): search.json returned a non-JSON body (Reddit blocking the datacenter request again, the HTTP-403 pattern noted in scan-config.md § Fetch Tooling). Counted empty but the cause is the block, not an absence of posts — route this through web_fetch (playwright) rather than curl on the next full run.
  - 2026-07-20 (CHECKED via web_fetch — works): `r/mcp/search.json?q=hiring OR freelance OR bounty OR paid&sort=new` returns clean JSON through playwright stealth-render (plain curl still 403s). 25 newest posts, ALL supply-side/showcase ("I built X MCP server", pricing discussions, help-me-understand) — zero demand-side gigs. Also ran `r/AI_Agents/search.json` + fetched the two most recent **Weekly Hiring Thread**s (1v1pm5a 7/20 = automod only; 1uvfona 7/13 = one 7/18 demand comment, but explicitly FULL-TIME hybrid + equity for a Croatia/Serbia/Hungary startup → FTE, below the noise floor per Opportunity Types). The Weekly Hiring Thread is a cheap recurring surface worth re-checking each run: `https://www.reddit.com/r/AI_Agents/comments/<id>/weekly_hiring_thread.json?sort=new`. last-checked 2026-07-20, consecutive-empty 1.
  - 2026-07-06 (SCRAPE NOTE): Reddit hard-blocks datacenter curl — `/search.json` returns HTTP 403 even with a browser UA (and on old.reddit). So `scripts/scout-fetch.sh` does NOT cover Reddit; fetch the `/search.json` URLs via **web_fetch** (playwright stealth-render) at runtime instead, or skip. last-checked 2026-07-06 (not fetched — blocked).

## Y Combinator — Work at a Startup
- url: https://www.workatastartup.com/
- type: gig-board
- scope: national
- provenance: user-seeded
- query-hint: https://www.workatastartup.com/companies?query=AI%20agent (also run `MCP`, `Claude`, `web developer`)
- last-checked: never
- yield: 0
- consecutive-empty: 0
- status: active
- notes: 2026-07-06 (user-seeded — agent/startup lane). YC startup roles; filter to contract/fractional (most are FTE → discount by engagement-fit). Watch for AI-agent / Claude-API / MCP build roles. Public-ish; if a listing gates detail behind login, log title + URL.
  - 2026-07-06 (first fetch): the public board shows **FULL-TIME only** ($120K–$250K salaries), no contract/fractional surface — FTE is below OA's noise floor. Low value for a solo contractor; keep as a light check for the rare "contract/fractional" role, expect ~0 yield. last-checked 2026-07-06, consecutive-empty 1.

## Wellfound (AngelList Talent)
- url: https://wellfound.com/
- type: gig-board
- scope: national
- provenance: user-seeded
- query-hint: https://wellfound.com/ (search "AI agent" / "MCP" / "web developer"; contract filter)
- last-checked: never
- yield: 0
- consecutive-empty: 0
- status: manual-check (login-walled for detail)
- notes: 2026-07-06 (user-seeded — agent/startup lane). Startup contract/fractional roles, but detail is behind login → Public-Access Gate: log title + URL only, Francis opens manually. Do NOT auto-login.

## Codeable — WordPress / web-dev freelance
- url: https://codeable.io/
- type: gig-board
- scope: national
- provenance: user-seeded
- query-hint: https://codeable.io/ (curated WP/web project marketplace — confirm the public project-feed/apply path on first fetch)
- last-checked: never
- yield: 0
- consecutive-empty: 0
- status: active
- notes: 2026-07-06 (user-seeded — web-dev lane). WordPress-centric freelance marketplace — aligns with the Elementor/WordPress client base (H1 Websites reseller network, etc.). General web-dev demand is also covered by the existing We Work Remotely + Contra entries — run a `web developer` / `Next.js` keyword pass on those too, not just `automation`.

## Hacker News — "Who is hiring" / freelancer threads (Algolia)
- url: https://news.ycombinator.com/
- type: gig-board
- scope: national
- provenance: discovered
- query-hint: `bash scripts/scout-fetch.sh hn "<term>"` (Algolia comments API; monthly "Ask HN: Who is hiring?" + "Freelancer? Seeking freelancer?" threads)
- last-checked: 2026-07-29
- yield: 0
- consecutive-empty: 4
- status: decayed
- notes: 2026-07-29 — 4th consecutive empty → auto-decay per index-format.md § Auto-decay (K=4, discovered source). The Algolia comments query returns general HN discussion (this run: Claude-Code instruction-following chatter, metric-system threads), never the demand-side hiring posts, so the query-hint is the defect rather than the source. Re-promote if a hint targeting the monthly "Who is hiring?" / "Seeking freelancer?" thread ids is worked out.
- notes: 2026-07-20 (quick pass): `scout-fetch.sh hn "MCP OR agent OR freelance"` returned 10 comments, all supply-side "Wants to be hired" self-posts or old off-topic threads. 0 demand-side. consecutive-empty → 3 (one short of the K=4 decay bar, but this is a *discovered* source; the Algolia query terms may be the problem — try fetching the current month's "Ask HN: Who is hiring? (July 2026)" thread id directly, or hnhiring.com/july-2026, before letting it decay).
- notes: 2026-07-06 (PROMOTED — the best PUBLIC, scrapable demand surface for the MCP/agent/web-dev lines). Fetch via `scripts/scout-fetch.sh hn`. Filter to DEMAND-side ("Company | role | …", "Seeking freelancer") and skip supply-side ("Wants to be hired" / bare "Location:/Remote:" self-posts). Monthly cadence — the "Who is hiring?" + "Who wants to be hired?" threads open ~1st business day; freelancer thread too. First pass 2026-07-06: sample skewed supply-side, no clean demand gig logged, but the channel is live + cheap to re-check.

## Local / Regional

## OregonBuys (state eProcurement)
- url: https://oregonbuys.gov/
- type: procurement
- scope: local
- provenance: user-seeded
- query-hint: https://oregonbuys.gov/bso/view/search/external/advancedSearchBid.xhtml
- last-checked: never
- yield: 0
- consecutive-empty: 0
- status: active
- notes: 2026-07-06 — Francis registered as a supplier (Net 30 terms; NIGP codes in classes 918 consulting + 920 computer services). Bid notifications now arrive by email, driven by those codes — treat `oregonbuys.gov` notification emails as triage signals in /agenda, and paste interesting ones into the scout for scoring. The public advanced-search stays the scout's machine path; no login is ever used.

## Craigslist — Oregon Coast
- url: https://oregoncoast.craigslist.org/
- type: craigslist
- scope: local
- provenance: user-seeded
- query-hint: https://oregoncoast.craigslist.org/search/ggg?query=website
- last-checked: 2026-07-29
- yield: 0
- consecutive-empty: 4
- status: active
- notes: 2026-07-01 — prior boolean-OR query-hint returned nothing (Craigslist ignores that OR form). Broadened to a single term; also scan the `cpg` (computer gigs) + `sad` (software/admin) categories on next run. Empty here is a hint-tuning artifact, not a dead source.
- notes: 2026-07-09 — checked (revisit leg). gigs 'website' = zero local (regional recruiter spam only); computer-gigs = microtask/photo/survey noise. No OA-fit.
- notes: 2026-07-14 — checked (quick pass). gigs 'website' = no results. No OA-fit.
- notes: 2026-07-20 — checked (quick pass). gigs 'website' = zero on-board coast results; the page is regional spillover (rentatech.org recruiter spam, paid-survey microtasks, $100-per-article content mills, Eugene/Salem/Bend/Portland). No OA-fit. consecutive-empty → 3.
- notes: 2026-07-29 — checked (revisit leg): the ggg?query=website search returned no listing links (empty result set for the coast board this window). 4th consecutive empty; user-seeded, so the longer leash applies (decay at ~2K=8) — no drop, no confirm needed yet.

## Craigslist — Portland
- url: https://portland.craigslist.org/
- type: craigslist
- scope: local
- provenance: user-seeded
- query-hint: https://portland.craigslist.org/search/cpg?query=automation
- last-checked: 2026-07-29
- yield: 0
- consecutive-empty: 2
- status: active
- notes: 2026-07-01 — prior boolean-OR query-hint returned nothing (Craigslist ignores that OR form). Narrowed to a single term; run separate passes for `n8n` and `integration`. Empty here is a hint-tuning artifact, not a dead source.
- notes: 2026-07-29 — checked (revisit leg): cpg?query=automation returned no listing links this window. 2nd consecutive empty; user-seeded, longer leash, no action.

## Tillamook County / cities procurement
- url: https://www.tillamookcounty.gov/
- type: procurement
- scope: local
- provenance: user-seeded
- query-hint: https://www.tillamookcounty.gov/rfps
- last-checked: 2026-07-01
- yield: 0
- consecutive-empty: 0
- status: active
- notes: 2026-07-01 — resolved real RFP page (was homepage placeholder). County page showed "no active" at check; also mirror City of Tillamook at https://www.tillamookor.gov/rfps.

## Clatsop County / Astoria procurement
- url: https://www.clatsopcounty.gov/
- type: procurement
- scope: local
- provenance: user-seeded
- query-hint: https://www.clatsopcounty.gov/rfps
- last-checked: 2026-07-01
- yield: 0
- consecutive-empty: 0
- status: active
- notes: 2026-07-01 — corrected domain (was co.clatsop.or.us) + resolved real RFP page. Had active solicitations at check (executive search, custodial) — non-tech, but the page is live and worth revisiting.

## Lincoln County / Lincoln City–Newport procurement
- url: https://www.co.lincoln.or.us/
- type: procurement
- scope: local
- provenance: user-seeded
- query-hint: https://www.co.lincoln.or.us/966/Bids-RFPs
- last-checked: 2026-07-01
- yield: 0
- consecutive-empty: 0
- status: active
- notes: 2026-07-01 — resolved real Bids/RFPs page. County uses a Euna/Ion Wave registration portal for full detail (a candidate credential-source if it gates listings).
  - 2026-07-06 (correction, verified by live fetch): the Euna/Ion Wave lead was WRONG — `col.ionwave.net` is Lincoln, **Nebraska**. Lincoln County OR posts bids publicly on its CivicPlus site (`/Bids.aspx?BidID=…` under /966/Bids-RFPs) — no vendor portal, no registration gate. Alerts: CivicPlus Notify Me at https://www.co.lincoln.or.us/list.aspx — the "County Administration" list is explicitly "Requests for Proposals and other postings"; "Public Works" advertises bid opportunities (also advertised in the Daily Journal of Commerce). Scout keeps fetching the public page; Francis subscribes to the email lists himself.

## OregonBids — county/city aggregator
- url: https://www.oregonbids.com/
- type: rfp-aggregator
- scope: local
- provenance: discovered
- query-hint: https://www.oregonbids.com/government-agencies/tillamook/
- last-checked: 2026-07-01
- yield: 0 (aggregator; not yet extracted)
- consecutive-empty: 0
- status: active
- notes: promoted 2026-07-01. Single aggregator covering Tillamook/Clatsop/Lincoln county + city solicitations — one stop for the local RFP layer. Swap the `/government-agencies/<county>/` path per region.

## Prosper Portland / Metro procurement
- url: https://www.prosperportland.us/
- type: procurement
- scope: local
- provenance: user-seeded
- query-hint: https://www.prosperportland.us/ (opportunities/RFP page — confirm exact path on first fetch)
- last-checked: never
- yield: 0
- consecutive-empty: 0
- status: active

## McMenamins
- url: https://www.mcmenamins.com/jobs
- type: careers
- scope: local
- provenance: user-seeded
- query-hint: http://recruiting2.ultipro.com/MCM1001MCMEN
- last-checked: never
- yield: 0
- consecutive-empty: 0
- status: active
- notes: 2026-07-02 (user-seeded). 50+ Oregon/Washington locations (breweries, hotels, theaters, distilleries); jobs via UltiPro. Postings skew hospitality (cooks, front desk, servers) — LOW OA fit; watch for corporate/IT/systems/automation/data roles. Public portal, no login.

## Pelican Brewing Company
- url: https://pelicanbrewing.com/
- type: careers
- scope: local
- provenance: user-seeded
- query-hint: https://www.beachjobscalling.com/
- last-checked: never
- yield: 0
- consecutive-empty: 0
- status: active
- notes: 2026-07-02 (user-seeded). Pacific City / Tillamook-coast brewery; /careers 404s — jobs live at beachjobscalling.com (linked from the homepage). Brewery/hospitality hiring, LOW OA fit; watch for ops/systems/e-commerce roles. Verify the beachjobscalling query-hint on first revisit.

## Astoria Brewing Company
- url: https://astoriabrewingcompany.com/
- type: careers
- scope: local
- provenance: user-seeded
- query-hint: https://astoriabrewingcompany.com/ (careers path TBD — confirm once the site is back up)
- last-checked: never
- yield: 0
- consecutive-empty: 0
- status: active  ⚠ site unreachable 2026-07-02
- notes: 2026-07-02 (user-seeded). Site was DOWN at add time — could not fetch. Francis to call Matt McClure first thing 2026-07-03 to check status. Astoria brewpub; LOW OA fit (hospitality) but tracked per Francis. Resolve the real careers/RFP subpage once the site is reachable.
  - 2026-07-02 (relationship — reframes this entry): Francis built Astoria Brewing's FIRST website back in the early 2000s — warm existing relationship with Matt McClure. Their CURRENT site is poor (and was down at add time), so this is really a live WEBSITE-REDESIGN/REBUILD prospect (web-dev + SMB-automation), NOT just a hospitality-careers watch. Treat as a warm prospect; after Matt confirms status it likely becomes a logged opportunity. Discovery-only — no outreach from the scout.

## Astoria Museums (Clatsop County Historical Society)
- url: https://astoriamuseums.org/
- type: other
- scope: local
- provenance: user-seeded
- query-hint: https://astoriamuseums.org/ (no careers/RFP subpage exposed on the homepage — confirm employment / get-involved path on first fetch)
- last-checked: never
- yield: 0
- consecutive-empty: 0
- status: active
- notes: 2026-07-02 (user-seeded). 501(c)(3) running four Astoria museums (Flavel House, Heritage, Oregon Film, Uppertown Firefighters) with admissions/ticketing — a potential TICKETING-integration angle (service line #3, Ticket Tomato-adjacent), though a small-nonprofit budget skews it long-shot. Watch for RFPs / admissions-system or contract tech work. Homepage exposed no jobs/RFP link; resolve the subpage next revisit.

## Tillamook County Creamery Association (Tillamook)
- url: https://www.tillamook.com/
- type: careers
- scope: local
- provenance: user-seeded
- query-hint: https://www.tillamook.com/careers
- last-checked: never
- yield: 0
- consecutive-empty: 0
- status: manual-check (bot-walled)
- notes: 2026-07-02 (user-seeded). Large Tillamook dairy co-op (Francis's home county) — BEST OA fit of this local batch: a corporate org that plausibly hires contract/fractional IT, automation, supply-chain, or data help. Direct /careers fetch was bot-blocked 2026-07-02 (like Go Fractional) → treat as MANUAL-CHECK: Francis browses/pastes, or resolve the underlying ATS (Workday/Greenhouse) URL on a later pass. Do not auto-bypass the block.

## Bergerson Tile & Stone (Astoria)
- url: https://www.bergersontile.com/
- type: other
- scope: local
- provenance: user-seeded
- query-hint: https://www.bergersontile.com/ (Wix site — homepage bot-blocks fetch; resolve a contact/about path or manual-check)
- last-checked: never
- yield: 0
- consecutive-empty: 0
- status: manual-check (Wix bot-walled)
- notes: 2026-07-02 (user-seeded). Astoria tile/stone retailer + fabrication + cabinets + blinds + install (92353 Lewis and Clark Rd, Astoria OR; CCB#161184), on a basic Wix site. It has no careers/RFP portal, so it will NOT post listings — this is a PROSPECT watch (SMB-automation and/or website-rebuild, web-dev), same pattern as Astoria Brewing, not a listing feed. Wix homepage bot-blocked the fetch 2026-07-02 → manual-check. Discovery-only.

## Greenwood Cemetery (Astoria)
- url: https://www.greenwoodcemeteryastoria.org/
- type: other
- scope: local
- provenance: user-seeded
- query-hint: https://www.greenwoodcemeteryastoria.org/ (Wix single-page; the "Opportunities for Involvement" / Grave Search sections are on the homepage)
- last-checked: never
- yield: 0
- consecutive-empty: 0
- status: active
- notes: 2026-07-02 (user-seeded — WARM, friends of Francis; he'd like to help if possible). Historic Astoria pioneer cemetery run by Michael & Lynda Leamy; Oregon-registered non-profit (public cemetery, not a formal 501(c)(3)/(13)). Genuine OA-fit thread beyond goodwill: the online "Grave Search" records system = database-backed / records-search automation (service lines #4 supabase-db + #5 SMB-automation), plus a basic Wix site that could be improved (web-dev). Contacts on-site: astoriagreenwoodcemetery@gmail.com. Treat as a warm, likely pro-bono/goodwill prospect, NOT a listing feed. Discovery-only — no outreach from the scout; Francis handles any contact.

## Custom Excavating Inc. / Trails End Recovery (Warrenton)
- url: https://www.customexcavatinginc.com/
- type: other
- scope: local
- provenance: user-seeded
- query-hint: https://www.customexcavatinginc.com/ (contact/about section — no careers/RFP portal; prospect watch)
- last-checked: never
- yield: 0
- consecutive-empty: 0
- status: active
- notes: 2026-07-02 (user-seeded — WARM: Francis knows owner Dean Larson personally). Excavation + materials salvage + recycling/recovery (dba "Trails End Recovery") + landscaping-materials yard on an 8.5-acre Warrenton OR site; 25+ yrs in Clatsop County (in-region). No careers/RFP portal → PROSPECT watch, not a listing feed. OA-fit thread: SMB process automation (scheduling/dispatch, materials inventory + pricing) and/or website help (smb-automation, web-dev). Discovery-only — Francis handles any contact.

## Public Notice Oregon (statewide legals aggregator)
- url: https://publicnoticeoregon.com/
- type: rfp-aggregator
- scope: local
- provenance: user-seeded
- query-hint: https://publicnoticeoregon.com/ (search "request for proposals" — confirm the exact search path on first fetch)
- last-checked: 2026-07-29
- yield: 0
- consecutive-empty: 6
- status: active
- notes: 2026-07-29 — DRIVEN (playwright, mandatory gate). Browser free this run; no profile-lock contention. "Call For Bids" statewide via the Popular-Searches postback, then bumped to 50/page so the whole trailing ~2-month window (6/09–7/29) collapsed to one page — 32 unique notices, 0 tech/OA-fit. All construction/public-works: City of Camas fire-station MEP + citywide pedestrian crossings (repeating across DJC issues), Warm Springs 1st/3rd-year stocking surveys, McMinnville skatepark RFP + East McMinnville electric substation expansion, and the one home-region hit Headlight-Herald HH26-258 (Slab Creek Road bridge repair — same entry as every prior run). Valid empty. The tech filter was word-boundaried per the 07-27 note; zero false-positives this pass.
- notes: 2026-07-27 — DRIVEN (playwright, mandatory gate). Profile lock from this run's own leftover headless Chrome blocked the first two attempts; cleared it and completed the drive (same shared-context hazard logged 07-14/07-20/07-23, this time self-inflicted and resolvable). "Call For Bids" statewide, default trailing 2-month window (5/27–7/27), 3 pages / 27 unique notices scraped. 0 tech/OA-fit: City of Camas fire-station MEP + citywide pedestrian crossings, Warm Springs 1st/3rd-year stocking surveys, Sheridan skatepark RFP, East McMinnville electric substation expansion, and the home-region hit Headlight-Herald HH26-258 (Slab Creek Road bridge repair, construction — same entry as prior runs). Valid empty. NOTE for future runs: an /AI/i keyword filter false-positives on "Daily" in "Daily Journal of Commerce" — word-boundary the AI token.
- notes: 2026-07-21 — DRIVEN (playwright, per the mandatory gate): "Call For Bids" statewide, trailing 2 months (5/21–7/21), both result pages scraped. 0 tech/OA-fit; the only home-region hit was Headlight-Herald HH26-258 (Slab Creek Road bridge repair, construction). Also ran the tech-keyword "Any Words" search — 100 pages, all "application" false-positives (annexation/permit/board-vacancy), confirming Call-For-Bids is the higher-signal path. User-seeded → longer leash; no decay.
- notes: 2026-07-06 (user-seeded — local-channels expansion). ONPA statewide public-notice site: the legal notices every Oregon paper publishes, including small-agency RFPs that never reach OregonBuys or SAM. Public, no login. Filter to Tillamook/Clatsop/Lincoln county papers + tech-relevant keywords.
  - 2026-07-06 (first fetch, verified live): confirmed live — an ASP.NET search app with county/city/paper + date filters, and its paper list covers the whole home region (Daily Astorian, Headlight-Herald, News Guard, Newport News-Times, Oregonian, Portland Tribune, Daily Journal of Commerce). This is the CENTRAL legals layer — the coast weeklies' RFP/legal notices surface here, so it substitutes for their (nonexistent) online classifieds. The landing page is just the search form (postback-driven); machine extraction needs a submitted keyword+county search — resolve a GET query URL or use Smart Search on a later pass. No listings extractable from the landing page this run.
  - 2026-07-06 (SEARCH RESOLVED, browser-driven): the search is session/postback-bound (`/(S(<sessionid>))/Search.aspx`) — there is NO static/shareable GET query URL, so the repeatable mechanism is a **playwright drive** (like /site-debug), NOT web_fetch. PROCEDURE each run: (1) navigate `https://www.publicnoticeoregon.com/`; (2) either pick the **"Call For Bids"** option from the Popular-Searches `<select>` (id `ctl00_ContentPlaceHolder1_as1_ddlPopularSearches`) OR type a keyword in the Search box + choose Any/Exact, and optionally set the County filter to Tillamook/Clatsop/Lincoln; the select/Submit fires a postback to `Search.aspx`; (3) scrape the results table on `Search.aspx` — each row = Publication (`<strong>`) + date + notice-text snippet; (4) filter CLIENT-SIDE for tech/software/IT/website/automation keywords (the vast majority are construction/public-works bids). Default date range is trailing ~2 months. VERIFIED 2026-07-06: "Call For Bids" statewide returned 2 pages — Tillamook County appeared (Headlight-Herald: Slab Creek bridge repair; Fairgrounds electrical) proving home-region coverage, but **every** hit was construction/electrical/paving — zero tech/OA-fit this window (none logged; correctly below the noise floor). Realistic yield: low but non-zero (catches the rare small-agency website/software/IT RFP a paper prints as a legal notice). ALT (lower-touch): **Smart Search** free signup (`/SmartSearchSignup.aspx`) saves a keyword+county search and emails daily matches — the "Francis subscribes, pastes back" pattern (same as Lincoln County CivicPlus Notify Me); no scout login.
- notes: 2026-07-09 — checked (revisit leg). playwright-driven keyword 'website software technology computer internet application' (Any Words, 5/10-7/9): 20 notices, ALL false-positives on 'application' (volunteer/annexation/permit) — zero tech/web/IT RFP; coast papers absent this window.
- notes: 2026-07-14 — DRIVEN (playwright, mandatory gate). Navigated PNO → tech-keyword search 'website software technology computer internet application' (Any Words), County=Any, date range 5/15–7/14 → scraped Search.aspx (sorted new→old). Newest slice (all 2026-07-14) filtered client-side: fire-alarm 'integration' + HVAC Metasys controls (Tillamook SD9), abandoned-home/board-vacancy/mayor-vacancy notices, City of Prineville electrical-contractor RFP — zero genuine tech/web/IT/software/automation. 0 tech-fit this window (valid empty). Note: a concurrent web_fetch left the shared browser context locked, so deeper pagination past the newest page wasn't reachable this run; newest published slice was scanned and clean.
- notes: 2026-07-15 — DRIVEN (playwright, mandatory gate). Navigated PNO → tech-keyword search 'website software technology computer internet application' (Any Words), County=Any, date range 5/16–7/15 → scraped Search.aspx (sorted new→old, page 1 of 100 @10/page). Newest slice (all 2026-07-15) filtered client-side: Payette County BOCC zoning hearing (ID), Woodburn PD unclaimed property + part-time admin-assistant recruitment + abandoned manufactured home, Pacific Communities Health District board meeting (News Guard/Lincoln City), Lincoln County Planning Commission code-amendment hearing, Jefferson County Pony Butte Road repair bids, Rogue River hazard-planning work session — zero genuine tech/web/IT/software/automation. 0 tech-fit this window (valid empty).
- notes: 2026-07-20 — DRIVEN (playwright, mandatory gate). Navigated PNO → tech-keyword search 'website software technology computer internet application' (Any Words), County=Any, trailing 60-day range (5/20–7/20) → scraped Search.aspx sorted new→old, bumped to 50/page so page 1 covered 7/15–7/20 (the whole window since the last run). 58 notices scanned; 3 keyword hits, ALL false-positives — a Beaverton/Tigard TRUSTEE'S NOTICE OF SALE, a City of Redmond hearing held "via digital conference," and a Cove/Union County conditional-use hearing for an Array Digital Infrastructure data center (land-use, not a tech procurement). Rest were construction bids (Hoffman/Ida B. Wells HS earthwork, Klamath Falls SS4A intersections), foreclosures, and planning hearings. 0 tech-fit this window (valid empty). Home-region papers thin this window. Note: the shared playwright context was hijacked mid-run by a concurrent fetch (page navigated away to an unrelated site); the drive was restarted from scratch and completed — same shared-context hazard logged 2026-07-14.
  - notes: 2026-07-23 — NOT driven this quick pass: the shared playwright profile was locked by a concurrent live browser session (Chrome PID 38325, SingletonLock held — the same shared-context hazard logged 2026-07-14/07-20), so the mandatory drive could not acquire the browser without killing another session's instance (declined). last-checked stays 2026-07-21 (driven, 0 tech-fit, 2 days prior) — window recently covered; NOT recorded as a valid empty (absence of drive ≠ empty result). Re-drive on next run when the browser is free.
  - notes: 2026-07-16 — DRIVEN (playwright, mandatory gate). Navigated PNO → tech-keyword search 'website software technology computer internet application' (Any Words), County=Any, date range 5/16–7/16 → scraped Search.aspx (sorted new→old, page 1 of 100 @10/page). Newest slice (2026-07-15/16) filtered client-side: Western Lane Fire/EMS public hearing (Florence), multiple TRUSTEE'S NOTICE OF SALE foreclosures (Bend/Newberg), Newberg City Council de-annexation hearing, Redmond City Council hearing, Gearhart fire-ordinance first reading (Daily Astorian — home region present), Payette County (ID) BOCC zoning hearing, Woodburn PD unclaimed property + Woodburn Fire part-time admin-assistant recruitment — zero genuine tech/web/IT/software/automation. 0 tech-fit this window (valid empty).

## Tillamook Headlight-Herald — classifieds + legals
- url: https://www.tillamookheadlightherald.com/
- type: gig-board
- scope: local
- provenance: user-seeded
- query-hint: https://www.tillamookheadlightherald.com/classifieds/ (confirm exact path on first fetch; check the legals/public-notices section too)
- last-checked: 2026-07-09
- yield: 0
- consecutive-empty: 0
- status: active
- notes: 2026-07-06 (user-seeded — local-channels expansion). Home-county weekly: classifieds (help wanted / services wanted) + legal notices (local RFPs). Public.
- notes: 2026-07-09 — checked (revisit leg). classifieds page is a form-shell (no scrapeable online listings); legals surface via Public Notice Oregon. No OA-fit.

## Tillamook County Pioneer
- url: https://www.tillamookcountypioneer.net/
- type: gig-board
- scope: local
- provenance: user-seeded
- query-hint: https://www.tillamookcountypioneer.net/?s=hiring (site search; also try "request for proposals")
- last-checked: 2026-07-09
- yield: 0
- consecutive-empty: 0
- status: active
- notes: 2026-07-06 (user-seeded — local-channels expansion). Online-only county news site; runs community hiring/notice posts that never hit the print papers. Public.
- notes: 2026-07-09 — checked (revisit leg). site-search 'hiring' returned only non-tech posts (OSU Extension, ambulance, Spectrum field tech). No OA-fit.

## The Astorian — classifieds + legals
- url: https://www.dailyastorian.com/
- type: gig-board
- scope: local
- provenance: user-seeded
- query-hint: https://www.dailyastorian.com/classifieds/ (confirm exact path on first fetch; legals section carries Clatsop-area RFP notices)
- last-checked: 2026-07-09
- yield: 0
- consecutive-empty: 0
- status: active
- notes: 2026-07-06 (user-seeded — local-channels expansion). Clatsop County paper of record (Astoria/Warrenton/Seaside). Public.
- notes: 2026-07-09 — checked (revisit leg). /classifieds path 404s (WordPress VIP); legals via Public Notice Oregon. No OA-fit.

## The News Guard (Lincoln City) + Newport News-Times
- url: https://www.thenewsguard.com/
- type: gig-board
- scope: local
- provenance: user-seeded
- query-hint: https://www.thenewsguard.com/classifieds/ (confirm path; mirror the check at https://www.newportnewstimes.com/classifieds/)
- last-checked: 2026-07-09
- yield: 0
- consecutive-empty: 0
- status: active
- notes: 2026-07-06 (user-seeded — local-channels expansion). Lincoln County pair covering the south end of the home region. Public.
- notes: 2026-07-09 — checked (revisit leg). Newport News-Times /classifieds is a form-shell (Lincoln County Leader classifieds widget), no scrapeable listings. No OA-fit.

## Col-Pac Economic Development District
- url: https://nworegon.org/
- type: procurement
- scope: local
- provenance: user-seeded
- query-hint: https://nworegon.org/ (RFP/procurement page — confirm exact path on first fetch)
- last-checked: never
- yield: 0
- consecutive-empty: 0
- status: active
- notes: 2026-07-06 (user-seeded — local-channels expansion). Regional EDD for Clatsop/Columbia/Tillamook/western Washington counties — posts its own RFPs and links member-agency solicitations; also a warm-network layer (Francis's SBDC affiliation is adjacent). Public.

## Coast chambers — job/RFP boards (Tillamook · Astoria-Warrenton · Lincoln City)
- url: https://tillamookchamber.org/
- type: gig-board
- scope: local
- provenance: user-seeded
- query-hint: https://tillamookchamber.org/jobs/ (confirm path; mirror at https://oldoregon.com/ and https://lcchamber.com/ on the same pass)
- last-checked: never
- yield: 0
- consecutive-empty: 0
- status: active
- notes: 2026-07-06 (user-seeded — local-channels expansion). Three chamber boards where in-region small businesses post needs before any job site. One source entry, three URLs on the revisit pass. Public.

## North Coast Citizen (Manzanita) — classifieds + legals
- url: https://www.northcoastcitizen.com/
- type: gig-board
- scope: local
- provenance: user-seeded
- query-hint: https://www.tillamookheadlightherald.com/northcoastcitizen/ (Country Media network — the NCC section runs under the Headlight-Herald site; confirm the classifieds/legals path on first fetch)
- last-checked: never
- yield: 0
- consecutive-empty: 0
- status: active
- notes: 2026-07-06 (user-seeded — coast-papers expansion). Manzanita/Nehalem/north-Tillamook biweekly, Country Media (same network as the Tillamook Headlight-Herald). Classifieds (help/services wanted) + legal notices (small-agency RFPs). ⚑ Verify it's still publishing on first fetch — the standalone title may have folded into the Headlight-Herald network. Public.

## Cannon Beach Gazette — classifieds + legals
- url: https://www.cannonbeachgazette.com/
- type: gig-board
- scope: local
- provenance: user-seeded
- query-hint: https://www.cannonbeachgazette.com/classifieds/ (confirm exact path on first fetch; check the legals/public-notices section too)
- last-checked: 2026-07-06
- yield: 0
- consecutive-empty: 1
- status: active
- notes: 2026-07-06 (user-seeded — coast-papers expansion). Cannon Beach/Tolovana/Arch Cape biweekly (Clatsop County), Country Media. Classifieds + legal notices. Public.
  - 2026-07-06 (first fetch): `/classifieds` path 404s (Country Media network site — runs under the Headlight-Herald platform, no standalone classifieds path). Legal notices surface centrally via Public Notice Oregon. Resolve the network's real classifieds path on a later pass.

## Seaside Signal — classifieds + legals
- url: https://seasidesignal.com/
- type: gig-board
- scope: local
- provenance: user-seeded
- query-hint: https://seasidesignal.com/classifieds/ (confirm exact path on first fetch; legals section carries Seaside/Gearhart RFP notices)
- last-checked: 2026-07-06
- yield: 0
- consecutive-empty: 1
- status: active
- notes: 2026-07-06 (user-seeded — coast-papers expansion). Seaside/Gearhart weekly (Clatsop County). Classifieds + legal notices. Astoria itself is already covered by **The Astorian** (dailyastorian.com) above — not re-added here. Public.
  - 2026-07-06 (first fetch): `/classifieds` path 404s (WordPress VIP site — no online classifieds section). Seaside/Gearhart legal notices surface centrally via Public Notice Oregon; treat that as the RFP channel. Resolve a real classifieds/marketplace path on a later pass if one exists.

## The Oregonian / OregonLive (Portland) — classifieds + legals
- url: https://www.oregonlive.com/
- type: gig-board
- scope: local
- provenance: user-seeded
- query-hint: https://www.oregonlive.com/classifieds/ (confirm exact path on first fetch; OregonLive classifieds run through a marketplace — resolve the working search on first pass)
- last-checked: never
- yield: 0
- consecutive-empty: 0
- status: active
- notes: 2026-07-06 (user-seeded — coast-papers expansion). Portland metro paper of record. Classifieds (help/services wanted) + public notices. NOTE for RFPs specifically, the Portland **Daily Journal of Commerce** (djcoregon.com) is the trade paper that carries construction/agency bids (already referenced in the Lincoln County notes) — worth a companion check when scanning Portland. Public.
