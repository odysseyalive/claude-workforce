---
name: opportunity-scout
description: "Scouts external market opportunities for Odyssey Alive — contract/freelance gigs, RFPs, and companies hiring fractional AI-automation help — via web search, scored against OA's service lines and logged to skill-local indexes. Discovery-only: finds and tracks, never contacts. Modes: scout, status, add-partner, add-source. Usage: /opportunity-scout [mode] [args]"
allowed-tools: WebSearch, mcp__playwright-mcp__web_fetch, mcp__playwright-mcp__browser_navigate, mcp__playwright-mcp__browser_snapshot, mcp__playwright-mcp__browser_click, mcp__playwright-mcp__browser_type, Read, Write, Edit, Glob, Grep, Task, Skill
minimum-effort-level: high
lane: coding
strictness: standard
---

# Opportunity Scout

Passive, user-invoked market reconnaissance for Odyssey Alive (a **solo** consultancy — Francis + AI, with a small bench of programmer partners for large jobs). It surfaces **external** opportunities Francis doesn't know about yet — contract/freelance gigs, RFPs/procurement listings, and companies hiring **fractional/contract** AI-automation help — scores each against OA's service lines, tracks them in skill-local indexes, dedupes across runs, and reports what's new. It **finds and tracks only** — it never emails, pitches, replies, or touches a CRM.

## Usage

```
/opportunity-scout [mode] [args]
```

### Modes

| Mode | Command | Description |
|------|---------|-------------|
| `scout` | `/opportunity-scout` or `/opportunity-scout scout [--quick]` | Full run: revisit known sources + fresh web discovery → score → dedupe → log new/updated → flush expired → report what's new (default) |
| `status` | `/opportunity-scout status` | Read-only view of the current indexes (open opportunities grouped by fit tier, plus the source + partner benches). No search, no writes |
| `add-partner` | `/opportunity-scout add-partner <linkedin-url>` | Profile a person from a public URL into the partner bench (confirm-and-write) |
| `add-source` | `/opportunity-scout add-source <url>` | Reverse ingestion: investigate a company/portal/listing URL and index it as a source (+ log any live match) |

Default mode is `scout`.

---

<!-- origin: user | added: 2026-07-01 | immutable: true -->
## Directives

> **Discovery-only.** This skill finds and tracks opportunities — it NEVER emails, pitches, replies to, or otherwise contacts anyone, and it never touches a CRM. Outreach is Francis's manual action (optionally drafted later via other skills). No tool-driven reply or send on any channel.

> **No automated login or scraping of ToS-walled sites.** Never log in to, or scrape behind the login of, Upwork, LinkedIn, Indeed, Facebook (Marketplace/groups), or any site whose terms forbid automated access. Use public, search-indexed pages and `web_fetch` only. A listing that requires login to view details is logged as title + URL for Francis to open himself. Facebook local-needs posts are handled by a human-in-the-loop checklist (Francis eyeballs + pastes back), never a bot.

> **Insert-only index writes; never touch a hand-set STATUS.** When writing the opportunity, source, or partner indexes, only ADD new entries, append update-notes, or flush entries per the expiry rules. Never rewrite, reword, or delete an existing entry's content, and never change a `STATUS` field — STATUS transitions (new → reviewing → contacted → passed/won) are Francis's alone.

> **Credentials: guide and paste, legitimate auth only.** When a source needs authentication, DETECT the need and tell Francis the exact labeled key to add to `.env.local` himself — never create an account, never handle or store a raw password autonomously, never log in on his behalf. Only legitimate auth qualifies: a free registration to READ a portal, or an API key. Never credentials used to scrape a ToS-protected site.

*— Added 2026-07-01, source: user (opportunity-scout design workshop; ratified decisions).*
<!-- /origin -->

<!-- origin: user | added: 2026-07-09 | immutable: true -->

> **Drive Public Notice Oregon on every run — make it part of the script; it isn't low-yield when I live here.** The statewide legals aggregator (`publicnoticeoregon.com`) is a MANDATORY revisit-leg step on EVERY scout run — never optional, skippable, or throttled. Its search is session/postback-bound, so a plain `web_fetch` of a query-hint does NOT work (that is exactly why it got silently skipped once) — it REQUIRES a playwright drive: navigate the site → run a tech-keyword search (`website software technology computer internet application`, "Any Words") OR the "Call For Bids" popular search over the trailing ~2-month window → scrape the `Search.aspx` results table → filter client-side for genuine tech / web / IT / software / automation notices, discarding matches that only hit the word "application" (volunteer / annexation / permit applications). This is a PRIORITY local channel, not an afterthought: Francis lives and works on the Oregon coast, so local-agency RFPs and neighbor gigs are among the highest-value leads OA can win — never frame the local legals/classifieds layer as "low yield." The coast weeklies print classifieds/legals only a few times a week, so a daily drive is cheap and misses nothing. A scout run must never again silently skip this layer.

*— Added 2026-07-09, source: user instruction (inline; via /route → /skill-builder). Verbatim: "drive each run and have it part of the script … it isn't low yield when I live here … those prints only happen a few times a week." Full PNO drive procedure lives in `source-index.md` under the Public Notice Oregon entry.*
<!-- /origin -->

<!-- origin: user | added: 2026-07-13 | immutable: true -->

> **Every opportunity carries a real source link — no linkless entry, ever.** No opportunity is written to `opportunity-index.md` or surfaced anywhere (the `scout` chat summary, `status`, or the `/agenda` Opportunities feed) without a real, public listing/posting URL in its `source:` field. `source:` is REQUIRED on every entry — never blank, never "unknown", never a bare domain: it is the exact URL of the listing/posting (a login-walled listing is still logged as its title + the listing URL per the Public-Access Gate, so a resolvable URL always exists). A candidate whose URL cannot be captured — a mention with no linkable posting, an aggregator hit that resolves to no detail page — is NOT logged as an opportunity; capture it on the run's human-review checklist instead. `source` is also the dedup primary key, so a linkless entry is a data defect, not a valid record.

*— Added 2026-07-13, source: user instruction ("all opportunities should have links. if they don't that needs fixed in the skill").*
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Drive Public Notice Oregon on every run — make it part of the script; it isn't low-yield when I live here." -->
CHECKPOINT — Public-Notice-Oregon Mandatory-Drive Gate (fires in `scout` mode during the revisit leg, BEFORE the run is allowed to emit its report):
1. PRINCIPLE RESTATEMENT (habit-fighting — this step slipped once, 2026-07-09). The reflex is to `web_fetch` a source's query-hint URL and move on. For Public Notice Oregon that reflex FAILS SILENTLY: its search is session/postback-bound, so `web_fetch` returns only a form shell and the local legals/classifieds layer is skipped with NO error surfaced. Driving PNO is NOT optional and NOT throttleable — it is a priority local channel for a coast-based consultancy, never "low yield."
2. Before emitting the run report, CONFIRM PNO was DRIVEN this run via playwright (not `web_fetch`): navigate `publicnoticeoregon.com` → run the tech-keyword search (`website software technology computer internet application`, "Any Words") OR the "Call For Bids" popular search over the trailing ~2-month window → scrape the `Search.aspx` results table → filter client-side for genuine tech / web / IT / software / automation notices, discarding matches that only hit the word "application" (volunteer / annexation / permit).
3. IF the revisit leg completed without a playwright drive of PNO → STOP. The run is INCOMPLETE; drive PNO before reporting.
4. A genuine empty result (drove it, nothing tech-relevant this window) is a VALID outcome — record "PNO: driven, 0 tech-fit this window." ABSENCE of the drive is NOT an empty result and must never be reported as "nothing found."
5. Full drive mechanics live in `source-index.md` § Public Notice Oregon; this gate only guarantees the drive happens on every run.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Discovery-only. This skill finds and tracks opportunities — it NEVER emails, pitches, replies to, or otherwise contacts anyone..." -->
CHECKPOINT — Discovery-Only Gate (fires in every mode, before any outbound-capable action):
1. This skill's only writes are to its own indexes (`opportunity-index.md`, `source-index.md`, `partner-index.md`) and the credential-prompt to the user. It has no send/reply/post capability and must not acquire one.
2. IF any step would draft-and-send, reply, message, submit, or contact a person/org/listing → STOP. Report: "opportunity-scout is discovery-only; capture it and hand off outreach to Francis." Never send.
3. Drafting a reply for Francis to send himself is ALSO out of scope for this skill — do not produce outreach copy here.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "No automated login or scraping of ToS-walled sites..." -->
CHECKPOINT — Public-Access Gate (fires before every `web_fetch`):
1. Determine whether the target URL is reachable without login. IF it renders content logged-out → fetch it.
2. IF it requires login / presents an auth wall / is a known ToS-walled platform surface (Upwork, LinkedIn, Indeed, Facebook Marketplace or groups) → DO NOT log in and DO NOT attempt to bypass. Log the listing as title + URL only and move on.
3. NEVER submit credentials to fetch a page. Facebook local-needs coverage is the human-in-the-loop checklist (see Workflow: Scout), never an automated login.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Insert-only index writes; never touch a hand-set STATUS..." -->
CHECKPOINT — Insert-Only Index Gate (fires before every index write):
1. Permitted writes ONLY: (a) append a new entry, (b) append a dated update-note under an existing entry, (c) remove a whole entry during expiry-flush per index-format.md rules, (d) update the machine-owned `last-seen`/`last-checked`/`consecutive-empty`/`run-state` fields.
2. IF an edit would change the text of an existing entry, OR alter any `STATUS` value, OR delete a `reviewing`/`contacted`/`won` entry → STOP. That is Francis's data. Do not write it.
3. After any write, verify the line-count delta equals lines added (plus any authorized flush) — a net rewrite of existing content is a violation.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Credentials: guide and paste, legitimate auth only..." -->
CHECKPOINT — Credential Guardrail Gate (fires whenever a source needs auth):
1. Classify the auth need: (a) free registration to READ a portal, or (b) an API key → LEGITIMATE, continue. (c) login to scrape a ToS-protected site → FORBIDDEN, stop (Public-Access Gate).
2. For a legitimate need: tell Francis the exact labeled key to add to `.env.local` (e.g. `OPPSCOUT_<SOURCE>_KEY=…`) and record the source in `references/credentialed-sources.md`. Reuse the key on later runs.
3. NEVER create an account, NEVER type a password into a login form, NEVER accept or store a raw password in any file. The skill guides; Francis pastes.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Every opportunity carries a real source link — no linkless entry, ever." (2026-07-13). -->
CHECKPOINT — Source-Link Required Gate (fires in `scout`/`add-source` at extract, at every index write, and before any chat-summary / status / agenda-feed emit):
1. EXTRACT (Scout Step 3): for each candidate, capture its `source` URL alongside {title, org, type, deadline, summary, scope}. IF no real public listing/posting URL can be resolved for the candidate → do NOT create an opportunity entry; route it to the run's human-review checklist (the Facebook / local-needs handling) and move on. A blank, "unknown", "none", or bare-domain source is NOT a URL.
2. WRITE (Scout Step 5 / add-source): before appending or update-noting any `opportunity-index.md` entry, assert its `source:` line is a single `http(s)://…` listing URL. IF absent or non-URL → BLOCK the write (the entry is malformed; fix the extraction or drop the candidate). Never write an entry whose primary dedup key is empty.
3. EMIT (Chat Summary / Status / `/agenda` Opportunities): every surfaced row MUST render its `↗ <source url>` link. IF a row being surfaced has no `source:` URL → it is a data defect: do not surface it silently; repair the entry or omit it and note the omission. Downstream renderers (e.g. the `/agenda` feed) must map each entry's `source:` into the row's link field — a surfaced opportunity without a link is a bug, not a display choice.
4. This gate never fabricates a URL. A missing link is resolved by finding the real listing URL or by not logging the item — never by inventing, guessing, or substituting a homepage.
<!-- END ENFORCEMENT ANNOTATION -->

---

<!-- MODEL-LANE-GATE START — auto-generated by /skill-builder route embed; safe to replace -->
<!-- origin: skill-builder | modifiable: true -->
## Model-Lane Preflight

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: /skill-builder route embed (model-lane gate, slim form per the 2026-06-06 2-Brain Harness directive: gates are slimmed, never stripped — this block is the lane checkpoint that travels with the skill through EVERY entry path, including hand-run invocations, which are always permitted. It goes silent when /route already covered the endeavor. Advisory-only per the 2026-06-06 No-Switch-Prompt directive: the gate CANNOT switch the model and NEVER asks the user to — its entire output is one advisory line, which names the exact remedy informationally per the 2026-06-11 named-command advisory directive. -->
CHECKPOINT — Model-Lane Preflight Gate (slim, advisory-only; fires at the TOP of this skill's workflow, before any generative step):
1. SKIP silently IF ANY of: `/route` dispatched this invocation after running its own lane preflight (a lane advisory OR ask already printed, route otherwise ASSESSED the lane this turn, or it was deliberately suppressed — route's coverage extends to the whole endeavor whether route asked, matched, or the user declined, including skills this one chains); this skill's frontmatter sets `model-lane-gate: off`; the session is headless / non-interactive; this gate is executing inside a subagent (a subagent is already model-pinned via its own frontmatter); OR an advisory for this LANE already printed this endeavor AND the active model is unchanged (advise at most once per (lane, active-model) pair per endeavor).
2. Resolve this skill's lane (own `lane:` frontmatter → the Skill→Lane table in `.claude/skills/skill-builder/references/model-lanes.md` → NO LANE) and the lane's Preferred Model. IF no lane resolves OR the preferred-model cell is empty → silent no-op (correctly absent, not a gap). IF this skill declares per-function lanes AND the invocation's resolved mode has its own row → that function's lane governs; otherwise the skill-level lane covers all modes.
3. Read ACTIVE_MODEL from the session system-context line "The exact model ID is …" (strip `[1m]`/`[200k]`, lowercase — model-lanes.md § Active-Model Detection; never an env var or Bash probe). IF the Preferred Model is malformed or names a clearly superseded family → emit the one-line stale-mapping advisory and proceed; never advise from a stale mapping, never validate against a hardcoded list.
4. Compare. Match → silent no-op. Mismatch → print ONE advisory line and PROCEED: "Lane advisory: this skill declares the `<lane>` lane (preferred `<preferred>`); the active model is `<active>` — to align, run `/model <preferred>` and re-invoke; proceeding as-is." Naming the command is INFORMATIONAL (named-command advisory directive, 2026-06-11): NEVER an AskUserQuestion, never a blocking wait (No-Switch-Prompt directive, 2026-06-06). A skill can NEVER switch the session model and never asks the user to.
5. Primary-lane scope. This gate fires ONCE per invocation, for the resolved PRIMARY lane. Cross-lane mid-workflow steps never re-advise — they delegate via this skill's LANE-AGENT-EMBED Delegation Map when present (see .claude/skills/skill-builder/references/lane-delegation.md). Delegation is never a substitute for THIS gate: analytical primary work runs on the analytical main model — never a creative main session orchestrating analytical-pinned agents to dodge the lane.
<!-- END ENFORCEMENT ANNOTATION -->
<!-- /origin -->
<!-- MODEL-LANE-GATE END -->

<!-- origin: skill-builder | version: 1.0 | modifiable: true -->
## Workflow: Scout

Default mode. A **two-leg** run: always revisit the curated source bench, then bounded fresh discovery. Default weight is **thorough**; `--quick` runs a lighter pass (see index-format.md § Run Bounds).

**Grounding first:** read [references/scan-config.md](references/scan-config.md) (service lines, query templates, home region, fit calibration) and [references/index-format.md](references/index-format.md) (entry schemas, dedup, expiry, run bounds, summary format). State: "I will score against the service lines in scan-config.md and write per the schemas in index-format.md."

1. **Revisit leg (always completes).** Read `source-index.md`. For each active source, `web_fetch` its stored query-hint page (public only — Public-Access Gate). Extract candidate listings.
   - **Mandatory every run — Public Notice Oregon (playwright drive, NOT web_fetch).** Per the 2026-07-09 directive, `publicnoticeoregon.com` MUST be driven on every run: its search is session/postback-bound, so drive it with playwright (navigate → tech-keyword search `website software technology computer internet application` "Any Words", or the "Call For Bids" popular search, over the trailing ~2-month window → scrape `Search.aspx` → filter client-side for real tech/web/IT/software/automation, discarding "application"-only false-positives). This is the local legals/classifieds layer for a coast-based consultancy — a priority channel, never skipped. Full mechanics: `source-index.md` § Public Notice Oregon.
2. **Discovery leg (bounded).** Build queries by crossing **opportunity type × service keyword × geography** (national + home-region local passes) per scan-config.md — never flat queries. Run them via `WebSearch` up to the run budget; `web_fetch` the most promising results for real content. **Stop early on diminishing returns** (queries stop surfacing anything new); the revisit leg still always finishes.
3. **Extract + score.** For each candidate, extract {title, org, type, deadline, summary, source url, scope}. Compute the 0–1 **fit-probability** per scan-config.md § Fit Calibration; assign tier (strong/adjacent/long-shot). Drop genuine noise below long-shot.
4. **Promote sources.** A discovery page that yielded ≥1 at/above the strong (or high-adjacent) bar is **promoted** into `source-index.md` (`provenance: discovered`) with a query-hint + scope.
5. **Dedupe + write.** Against the existing indexes: dedupe by source URL (primary) + fuzzy title/company (secondary). New → append entry. Already-present but changed (deadline moved / reappeared) → append a dated update-note. Cross-posted same job → one entry, alt-source noted. Honor the **Insert-Only Index Gate**.
6. **Partner-match.** For any opportunity whose deliverability exceeds solo capacity, cross-reference `partner-index.md` and set `needs-partner` + candidate. (Never invents a partner — names only existing bench members; see add-partner to add one.)
7. **Flush expired + decay.** Apply expiry-flush to opportunities and auto-decay to discovered sources per index-format.md; user-seeded sources get the longer leash + confirm-before-drop.
8. **Report.** Emit the chat summary per index-format.md § Chat Summary: brief prose lead + fit-tier-grouped ranked list of what's **new/changed this run**, housekeeping footer, pointer to `status`.

> **Facebook / local-needs (human-in-the-loop).** During a run, surface the local-social checklist from scan-config.md § Local Channels — the specific FB groups/Marketplace searches worth Francis eyeballing. The scout NEVER logs into Facebook; it only reminds. Anything Francis pastes back is scored + logged like any other candidate.

## Workflow: Status

Read-only. Read all three indexes and present:
1. Open opportunities grouped by **fit tier** (strong → adjacent → long-shot), tagged `[type · local|national]`, with counts (`open · passed · won`). Render each item per [references/index-format.md](references/index-format.md) § Status Output — including the entry's `why:` brief summary and its `source:` link (`↗ <url>`).
2. The current **source bench** (national/local, discovered/user-seeded, last-checked) and **partner bench** (name + abilities).

No search, no writes.

## Workflow: add-partner

Profile a person from a public URL into `partner-index.md`. Never scrapes behind a login.

**Grounding:** read [references/index-format.md](references/index-format.md) § Partner Index for the schema + capability taxonomy.

1. Parse the handle/name from the URL. `web_fetch` the **public** profile only (logged-out; capture whatever renders — Public-Access Gate).
2. `WebSearch` to corroborate (portfolio, GitHub, company site — ToS-clean, often richer than the walled profile).
3. Distill a structured profile **aligned to the fit-scorer's capability taxonomy** (skills/stack tagged with the same service-line keys opportunities score on) + seniority + "good for" + availability.
4. **Present the draft to Francis to confirm/edit** — thin/walled public data degrades to a confirm-and-fill prompt; never fabricate a profile.
5. On confirmation, append the entry to `partner-index.md` (Insert-Only Index Gate).

## Workflow: add-source

Reverse ingestion — investigate a user-supplied URL and index it as a source.

**Grounding:** read [references/index-format.md](references/index-format.md) § Source Index and [references/scan-config.md](references/scan-config.md).

1. `web_fetch` the URL (public only). Classify it:
   - **Company/portal** → find its careers / RFP / procurement / vendor subpages; the re-checkable one becomes the **query-hint**.
   - **Single listing** → log the opportunity (fit-scored) AND note its parent site as a candidate source.
2. Judge relevance to OA's service lines + region; set `scope` (local|national).
3. Append to `source-index.md` with `provenance: user-seeded`, the query-hint, scope, and label (Insert-Only Index Gate).
4. **Log any live match immediately** — if the page currently shows a fitting listing, fit-score it into `opportunity-index.md` now.
5. IF the source's careers/RFP portal needs a free registration → fire the **Credential Guardrail Gate** (guide Francis to add the key to `.env.local`).
6. User-seeded sources then ride the normal `scout` revisit leg, with the longer decay leash + confirm-before-drop.

---

## Grounding

Before running any mode, read the relevant reference file and state which values will be used.

Reference files:
- [references/scan-config.md](references/scan-config.md) — service lines, platform list, query templates (type × service × geography), home-region definition, fit-probability calibration.
- [references/index-format.md](references/index-format.md) — the three index entry schemas, dedup rules, expiry-flush + source decay, run bounds + run-state, chat-summary format, partner capability taxonomy.
- [references/credentialed-sources.md](references/credentialed-sources.md) — the detect→guide-paste credential pattern and the registry of which sources have keys.

Data files (skill-local, model-facing working memory; insert-only per the Insert-Only Index Gate):
- `opportunity-index.md` · `source-index.md` · `partner-index.md`
<!-- /origin -->
