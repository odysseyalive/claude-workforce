<!-- run-state: last-run=2026-07-29, runs=20 -->
# Opportunity Index

Machine-maintained by `/opportunity-scout` (insert-only). `status` is Francis's field to edit. See [references/index-format.md](references/index-format.md) for the entry schema, dedup, and expiry rules.

> 2026-07-01 reconcile: n8n-board entries re-checked against topic `created_at` (not board bump time). Dead posts (>10 wks old) flushed; aged-but-plausible posts flagged. See index-format.md § Freshness.

## FRESH — active

## MCP Server Developer — AI Agent Governance Platform — Upwork gig
- found: 2026-07-29
- posted: unknown (walled — Upwork requires login for detail)
- source: https://www.upwork.com/freelance-jobs/apply/MCP-Server-Developer-Agent-Governance-Platform_~022036259195769679115/
- type: gig
- scope: national
- fit: 0.72 (strong)
- why: Direct hit on OA's #1 line — the client wants genuine production MCP server experience, specifically MCP sampling to intercept agent actions before execution. That is protocol-depth work rather than a setup/install task, which is where Francis's MCP builds actually differentiate. Listed <30 hrs/wk, 1–3 months; clean solo+AI deliverable.
- deadline: none visible
- needs-partner: no
- status: new
- last-seen: 2026-07-29
- notes:
  - 2026-07-29: ⚑ walled — open manually on Upwork for scope/rate/recency. Posting date not visible logged-out, so it is withheld from the /agenda Opportunities feed (undated leads are dropped there per the freshness rule).

## MCP Server Development & Plan — Upwork gig
- found: 2026-07-29
- posted: unknown (walled — Upwork requires login for detail)
- source: https://www.upwork.com/freelance-jobs/apply/MCP-Server-Development-Plan_~022005966859575393170/
- type: gig
- scope: national
- fit: 0.70 (strong)
- why: Build an MCP server plus the integration plan into an existing system — OA's #1 service line, and the "& Plan" framing suggests advisory scope alongside the build rather than a fixed-price break-fix. Listed >30 hrs/wk, 1–3 months under Web Development, so it also touches the web-dev line.
- deadline: none visible
- needs-partner: no
- status: new
- last-seen: 2026-07-29
- notes:
  - 2026-07-29: ⚑ walled — open manually on Upwork. >30 hrs/wk is a larger commitment than most Upwork MCP posts; verify it is project-shaped and not staffing-shaped before investing in a proposal. Undated → withheld from the /agenda Opportunities feed.

## AI Automation & Agent Developer — n8n + Claude API Specialist — Upwork gig
- found: 2026-07-28
- posted: unknown (walled — Upwork requires login for detail)
- source: https://www.upwork.com/freelance-jobs/apply/Automation-Agent-Developer-n8n-Claude-API-Specialist_~022069814012534831284/
- type: gig
- scope: national
- fit: 0.62 (adjacent)
- why: Claude API agent development is service line #2 (core), which lifts this above a pure-n8n post; the n8n layer is orchestration around the agent work rather than the deliverable itself. Solo-deliverable, clean freelance engagement.
- deadline: none visible
- needs-partner: no
- status: new
- last-seen: 2026-07-28
- notes:
  - 2026-07-28: ⚑ walled — open manually. Posting date not visible logged-out, so it is withheld from the /agenda Opportunities feed (undated leads are dropped there per the freshness rule) and lives here until Francis verifies it.

## Looking for n8n developer or team — urgent, portfolio required
- found: 2026-07-27
- posted: 2026-07-23 (new)
- source: https://community.n8n.io/t/304434
- type: gig
- scope: national
- fit: 0.30 (long shot)
- why: Demand-side n8n board post — "urgent need of an n8n expert or team," resume + portfolio required or the proposal is discarded. Pure-n8n with zero scope, budget, industry, or company named, and no agent/MCP/integration angle to score on the primary lines (Service Lines #8). Reads more like agency//staffing sourcing than a defined build. ⚑ thin listing — verify there's a real project behind it before spending time on a portfolio submission.
- deadline: none stated
- needs-partner: no
- status: new
- last-seen: 2026-07-27

## Expert n8n senior — migration d'une stack IA commerciale
- found: 2026-07-16
- posted: 2026-07-16 (new)
- source: https://community.n8n.io/t/303483
- type: gig
- scope: national
- fit: 0.42 (long shot)
- why: Fresh demand-side post (today) — senior n8n dev to migrate a commercial AI stack. Pure-n8n + migration work scores adjacent-at-best per Service Lines #8, and it's a French-language listing/client (logged title-only, not fetched). ⚑ French-language; confirm scope/rate before acting.
- deadline: none stated
- needs-partner: no
- status: new
- last-seen: 2026-07-16

## Claude MCP local Server setup and installation — Upwork gig
- found: 2026-07-15
- posted: unknown (walled — Upwork requires login for detail)
- source: https://www.upwork.com/freelance-jobs/apply/Claude-MCP-local-Server-setup-and-installation_~022075609484653445331/
- type: gig
- scope: national
- fit: 0.55 (adjacent)
- why: Client wants a local MCP server set up + installed so Claude Desktop can reach their tools/resources/prompt templates — on OA's MCP line but setup/install-weighted rather than a build. ⚑ walled — open on Upwork for scope/rate/recency; Upwork skews price-competitive.
- deadline: none visible
- needs-partner: no
- status: new
- last-seen: 2026-07-15

## Fix Claude Desktop ↔ WordPress MCP Adapter connection error — Upwork gig
- found: 2026-07-15
- posted: 2026-07-09 (~6 days)
- source: https://www.upwork.com/freelance-jobs/apply/Expert-Developer-SysAdmin-Needed-Fix-Claude-Desktop-WordPress-MCP-Adapter-Connection-Error_~022075191834275017099/
- type: gig
- scope: national
- fit: 0.45 (long shot)
- why: Troubleshoot a Claude Desktop ↔ WordPress MCP adapter connection error — touches the MCP line but a tiny break-fix ($20 fixed-price), not a build. ⚑ low rate + walled; open on Upwork only if the quick-fix framing holds.
- deadline: none visible
- needs-partner: no
- status: new
- last-seen: 2026-07-15

## Integrations & Prompt Engineer (voice-agent plumbing) — Yokeru
- found: 2026-07-14
- posted: 2026-07-09 (~5 days)
- source: https://community.n8n.io/t/integrations-prompt-engineer-remote-uk-hours-20-50-hr/302688
- type: hiring
- scope: national
- fit: 0.52 (adjacent)
- why: Contract/ongoing integrations role for Yokeru (yokeru.ai — AI welfare-call voice agents for care providers). Wants webhooks/serverless (AWS Lambda, n8n), REST APIs into CRMs/alarm platforms, and Retell/VAPI agent + prompt work — owns integrations end-to-end. Touches integrations + agents, but voice-agent/n8n-weighted (not Claude-API/MCP core). Headwinds: $20-50/hr (low for OA's model), UK-timezone overlap required, short paid trial → ongoing. Apply via form (integrations-apply.vercel.app), 10 min, show a Retell/VAPI/n8n build.
- deadline: none stated
- needs-partner: no
- status: new
- last-seen: 2026-07-14

## Custom MCP Server Development with Claude AI Integration — Upwork gig
- found: 2026-07-09
- posted: unknown (walled — Upwork requires login for detail)
- source: https://www.upwork.com/freelance-jobs/apply/Custom-MCP-Server-Development-with-Claude-Integration_~022041136439822041708/
- type: gig
- scope: national
- fit: 0.70 (strong)
- why: Direct hit on OA's #1 line — custom MCP server so a client can drive their systems from Claude, a clean solo+AI build. ⚑ walled — open on Upwork for scope/rate/recency; Upwork skews price-competitive.
- deadline: none visible
- needs-partner: no
- status: new
- last-seen: 2026-07-09
- notes: 2026-07-09 — Francis check: source link DEAD (posting taken down). Do not resurface; drop from any briefing.

## Claude Code Plugin / MCP Harness — Upwork gig
- found: 2026-07-09
- posted: unknown (walled — Upwork requires login for detail)
- source: https://www.upwork.com/freelance-jobs/apply/Claude-Code-Plugin-MCP-Harness_~022066214175174576806/
- type: gig
- scope: national
- fit: 0.66 (adjacent)
- why: Build a testing harness for MCP servers/plugins with Claude Code — squarely in OA's MCP + Claude Code tooling lane (exactly the kind of harness Francis builds). Desktop-app-dev framing, <30 hrs/wk, 1–3 months. ⚑ walled — verify scope/rate on Upwork.
- deadline: none visible
- needs-partner: no
- status: new
- last-seen: 2026-07-09
- notes: 2026-07-09 — Francis check: Upwork posting is ~3 weeks old (stale). `found` date ≠ posting date; not a fresh lead.

## Claude Code + MCP Setup Specialist — Quick Infrastructure Project (Urgent) — Upwork gig
- found: 2026-07-09
- posted: unknown (walled — Upwork requires login for detail)
- source: https://www.upwork.com/freelance-jobs/apply/Claude-Code-MCP-Setup-Specialist-Quick-Infrastructure-Project-Urgent_~022072080339169803773/
- type: gig
- scope: national
- fit: 0.58 (adjacent)
- why: Claude Code install/config + MCP server setup + GitHub repo management — on OA's MCP/Claude-tooling line but setup/DevOps-weighted rather than a build, and short (<1 month, urgent). Fast turnaround = low friction if rate holds. ⚑ walled — open on Upwork to judge.
- deadline: none visible
- needs-partner: no
- status: new
- last-seen: 2026-07-09

## MCP Developer — Build Custom Claude MCP Integration for Business Tools — Upwork gig
- found: 2026-07-07
- posted: unknown (walled — Upwork requires login for detail)
- source: https://www.upwork.com/freelance-jobs/apply/MCP-Developer-Build-Custom-Claude-MCP-Integration-for-Business-Tools_~022072263193693942605/
- type: gig
- scope: national
- fit: 0.70 (strong)
- why: Direct hit on the #1 core line — client wants a custom MCP server so Claude can read/write against their business-tool APIs, exactly OA's MCP-development lane and a clean solo+AI deliverable. Listed <30 hrs/wk, 1–3 months. ⚑ walled — open on Upwork for scope/rate/recency; Upwork skews price-competitive.
- deadline: none visible
- needs-partner: no
- status: new
- last-seen: 2026-07-07

## Front End Developer (React, AI Agents, MCP servers) — Red Oak Technologies (contract, Austin TX)
- found: 2026-07-07
- posted: unknown (walled — LinkedIn requires login for detail)
- source: https://www.linkedin.com/jobs/view/front-end-developer-react-ai-agents-mcp-model-context-protocol-servers-contract-at-austin-tx-at-red-oak-technologies-4328833183
- type: hiring
- scope: national
- fit: 0.58 (adjacent)
- why: Contract role blending React front-end with AI-agents + MCP servers — touches two core lines (web-dev + MCP/agents) but front-end-weighted and Austin-based (remote unconfirmed). ⚑ walled + ⚑ verify: contract? — open on LinkedIn for scope/location/rate.
- deadline: none visible
- needs-partner: no
- status: new
- last-seen: 2026-07-07

## Build MCP Server for a SaaS tool — Upwork gig
- found: 2026-07-06
- posted: unknown (walled — Upwork requires login for detail)
- source: https://www.upwork.com/freelance-jobs/apply/Build-Model-Context-Protocol-MCP-Server-for-SaaS-tool_~021902520794305531747/
- type: gig
- scope: national
- fit: 0.68 (adjacent)
- why: FIRST direct hit on the recalibrated #1 line — a client wanting an MCP server built for their SaaS tool (exactly OA's MCP-development lane, solo+AI deliverable). ⚑ walled — Upwork login needed for scope/rate/recency, and Upwork skews price-competitive; open manually to judge.
- deadline: none visible
- needs-partner: no
- status: new
- last-seen: 2026-07-06

## Freelancer Automation Developer (Make/Zapier/n8n) — Variacode
- found: 2026-07-06
- posted: unknown (walled — details require LinkedIn login)
- source: https://www.linkedin.com/jobs/view/freelancer-automation-developer-make-zapier-n8n-at-variacode-4238999911
- type: hiring
- scope: national
- fit: 0.68 (adjacent)
- why: Explicitly freelance automation developer naming Make/Zapier/n8n — clean service-line + engagement fit from the public snippet. ⚑ walled — open manually on LinkedIn to verify scope/rate/recency before acting.
- deadline: none visible
- needs-partner: no
- status: new
- last-seen: 2026-07-06

## Freelance AI Automation Engineer (Remote)
- found: 2026-07-01
- posted: 2026-06-17 (~2 wks)
- source: https://community.n8n.io/t/hiring-freelance-ai-automation-engineer-remote/299853
- type: hiring
- scope: national
- fit: 0.70 (strong)
- why: Explicitly freelance, AI/n8n automation, genuinely recent — clean fit and clean engagement.
- deadline: none stated
- needs-partner: no
- status: new
- last-seen: 2026-07-01
- notes:
  - 2026-07-29: ⚠ aged — posted 2026-06-17, now ~6 wks. Not in the n8n board's latest slice this run. Verify still open before pursuing; flush at the >10 wk mark if it stays quiet.

## Sales Tech & Automation Specialist — CRM + Databases (ongoing)
- found: 2026-07-01
- posted: 2026-06-20 (~11 days)
- source: https://community.n8n.io/t/hiring-sales-tech-automation-specialist-ongoing-remote-work-crm-databases/300286
- type: hiring
- scope: national
- fit: 0.62 (adjacent)
- why: CRM + database automation (Supabase-adjacent), ongoing/remote, recent — relevant; sales-tech framing is a step off the core n8n/ticketing lines.
- deadline: none stated
- needs-partner: no
- status: new
- last-seen: 2026-07-01

## AI Quoting Agent for Plumbing/HVAC (n8n) — Swiss end-client
- found: 2026-07-06
- posted: 2026-07-06 (new)
- source: https://community.n8n.io/t/hiring-n8n-developer-ai-quoting-agent-swiss-plumbing-hvac-paid-long-term/302292
- type: gig
- scope: national
- fit: 0.66 (adjacent)
- why: Direct n8n build — AI quoting agent matching supplier-catalog references + PDF quote generation, paid/long-term. Clean service-line fit (n8n + LLM + trades SMB). Headwinds: French-language intervention requests, and selection requires an unpaid working prototype ("no prototype = no conversation"). Direct end-client, WhatsApp contact.
- deadline: none stated
- needs-partner: no
- status: new
- last-seen: 2026-07-06

## Telecom OSS correlation — n8n + PostgreSQL PoC
- found: 2026-07-06
- posted: 2026-06-21 (~2 wks)
- source: https://community.n8n.io/t/looking-for-an-n8n-freelancer-consultant-with-telecom-oss-experience/300396
- type: gig
- scope: national
- fit: 0.60 (adjacent)
- why: Strong technical shape — n8n + REST API + PostgreSQL correlation workflows + AI agents (service lines n8n / supabase / integrations). Fixed-price/milestone PoC, telecom-domain-agnostic (no bidder has ONMSi/RFMS). Headwinds: India-timezone preference and already heavily bid (~15 responses), so likely well-progressed.
- deadline: none stated
- needs-partner: no
- status: new
- last-seen: 2026-07-06

## N8N AI Automation Developer (Remote) — $1,500/mo
- found: 2026-07-06
- posted: 2026-06-17 (~3 wks)
- source: https://community.n8n.io/t/n8n-ai-automation-developer-remote/299818
- type: hiring
- scope: national
- fit: 0.42 (long shot)
- why: Demand-side n8n/LLM automation, but salary-shaped at $1,500 USD/mo (via Wise), apply-by-Loom-to-Discord — a cheap ongoing-labor arrangement below OA's consulting model, not a project/fractional contract. ⚑ low rate.
- deadline: none stated
- needs-partner: no
- status: new
- last-seen: 2026-07-06

## Freiberuflicher n8n-Entwickler — komplexe Workflow-Automatisierung (DE)
- found: 2026-07-06
- posted: 2026-07-06 (new)
- source: https://community.n8n.io/t/302210
- type: gig
- scope: national
- fit: 0.48 (long shot)
- why: Fresh demand-side n8n freelance post (complex workflow automation), posted 2026-07-06. German-language listing/client — logged title-only (not fetched). ⚑ German-language; confirm scope/rate before acting.
- deadline: none stated
- needs-partner: no
- status: new
- last-seen: 2026-07-06

## AGED — verify before pursuing (older than 3 wks; may be filled)

## Reliable n8n developer — ongoing build + maintain
- found: 2026-07-01
- posted: 2026-05-26 (~5 wks — recently bumped)
- source: https://community.n8n.io/t/seeking-a-reliable-n8n-developer-for-ongoing-project-based-work-build-maintain/296828
- type: gig
- scope: national
- fit: 0.55 (adjacent) — downgraded on re-verify
- why: Re-verified 2026-07-01: this is WHITE-LABEL SUBCONTRACTING — technaros runs an AI consultancy and wants devs to build workflows in his sandbox and hand off documented JSON; HE keeps the client + production creds. Ongoing/recurring, but you don't own the client, so lower strategic fit for building OA's own base. ~5 wks old, no explicit close.
- deadline: none stated
- needs-partner: no
- status: new  ⚠ aged + white-label (subcontractor, not direct client)
- last-seen: 2026-07-01

<!-- FLUSHED 2026-07-20 (posted 2026-05-07, now ~10.5 wks — past the >10 wk freshness window per index-format.md § Freshness): "Long-term n8n + Postgres build — 50-state medical consulting practice" (topic 294834, was fit 0.80 strong/AGED); "AI Automation Engineer / n8n & AI Agent Developer" (topic 294904, was fit 0.55 adjacent/AGED, white-label contractor-bench). Both status:new, so expiry-flush eligible. -->
<!-- FLUSHED 2026-07-01 (created >10 wks ago, near-certainly filled): "HIRING: Freelance/Agency AI Automation Engineer (n8n/Make/APIs)" (2026-03-10); "[Hiring] n8n Automation Specialist — E-Commerce/Shopify" (2026-04-05); "Vapi + n8n + Twilio integration" (2025-11-19); "N8N+ AI Workflow Builder" (2025-10-22). Reason: board-bump masqueraded as freshness. -->
<!-- FLUSHED 2026-07-06 (created >10 wks ago per index-format.md § Freshness — ~12 wks + 54 replies): "Claude API + n8n Engineer — 31-Agent Business Intelligence System" (topic 286780, posted 2026-04-11). Was fit 0.72 strong but past the freshness window and heavily contested. -->
