# Today Briefing — Browser View Data Feed

Feeds the assembled `today` briefing to a local browser view so the briefing can be
read outside the cluttered terminal. **Additive:** the terminal briefing (the five-part
chart-first output governed by the Chart Output Gate) stays primary and is emitted
exactly as before. The browser view mirrors that same content — it never replaces it or
changes what gets assessed.

**The viewer is a committed local app**, not a template this step fills. It lives at the
repo root in `agenda/` (Tailwind CSS 4 + TypeScript, same brand system as the site), built
to `agenda/publish/`. This render step only writes the briefing **data**; the committed
`agenda/publish/index.html` + `app.js` render it. The page opens straight from a `file://`
link — no server. See [`agenda/README.md`](../../../../agenda/README.md) and the data
contract in [`agenda/src/types.ts`](../../../../agenda/src/types.ts).

## When it runs

At the end of `today` mode, after Step 6 (Synthesize and present) has produced the terminal
briefing and all its gates have passed. It reuses the already-assembled briefing data — do NOT
re-scan, re-fetch, or re-score.

**Skip** the write (and say so in one line) when: `--no-html` was passed, OR the run produced
no briefing (e.g. cancelled at the triage confirmation walk).

## Procedure

1. **Compute the output path.** `<repo-root>/agenda/publish/data/today.js`, where `<repo-root>`
   is the directory containing the site's `package.json` (i.e. `/home/francis/lab/odyssey-alive`).
   Stable filename — a re-run overwrites the same file so the page the user already opened
   refreshes on reload. Create `agenda/publish/data/` if it does not exist.

2. **Build the `AGENDA_DATA` object** from the SAME content as the terminal briefing (do not
   invent or drop anything — the browser view and the terminal output must agree). The shape is
   defined by [`agenda/src/types.ts`](../../../../agenda/src/types.ts):

   | Field | Content |
   |-------|---------|
   | `date` | Long date, e.g. `"Monday, July 6, 2026"`. |
   | `dateISO` | ISO date, e.g. `"2026-07-06"`. |
   | `dateline` | One short plain-text "state of the morning" line (the synopsis's first clause is fine). |
   | `synopsis` | The executive summary (today = one short paragraph). Use `\n\n` between paragraphs if more than one. |
   | `stats` | Array of `{ value, label, hot? }` for the day's shape — e.g. overdue count (`hot: true`), due-today count, awaiting count. Omit figures that are zero; empty array if nothing noteworthy. |
   | `clients` | Array of `{ name, items[] }`, most-urgent client first. Each item: `{ priority, item, itemUrl?, deadline, signal, signalUrl?, bumped? }`. `priority` ∈ `overdue · today · week · next · horizon`. `deadline` is ISO `YYYY-MM-DD` (or omitted). `bumped: true` pins the item to the top of its client group and cites the correspondence in `signal`. |
   | `awaiting` | Array of `{ to, re, asked, daysOut, followup }`, or `[]` (renders "None for today."). |
   | `clarifications` | Array of `{ recipient, channel, question, forTask }`, or `[]`. |
   | `opportunities` | Array of `{ fit, type, name, url?, note, date? }`. `fit` ∈ `strong · adjacent`. `url` is the entry's `source:` posting. **Mapping `source:` → `url` is MANDATORY on every surfaced row** (opportunity-scout Source-Link Required Gate): every opportunity in the scout index carries a real `source:` URL, so every row rendered here MUST carry that URL in `url`. A surfaced opportunity with no link is a defect — repair the mapping or omit the row; never surface an opportunity without its link. `date` is the lead's **real posting date** (ISO `YYYY-MM-DD`) — i.e. how old the gig is (the scout index's `posted:`), **NOT** the `found:` (discovery) date. The viewer drops any opportunity older than the freshness window (`FRESH_WINDOW_DAYS`, 3) relative to `dateISO`, same as the news + AI-releases rails — AND drops any opportunity with **no** `date`. That is deliberate: a walled/undated listing (e.g. a Cloudflare-blocked Upwork gig whose posting date and liveness can't be verified) must **not** be surfaced as a fresh lead — stamping it with today's `found` date fakes freshness (this bit us 2026-07-09: 3-week-old and already-removed Upwork gigs showed as "new"). Only include an opportunity when its **posting date is genuinely known and inside the window**; leave walled/undated leads for the scout index, not the daily briefing. Empty (or all-filtered) → "None new at the moment."; guard-skipped/failed → mirror the terminal note in a single-row note (`opportunities: []` plus a one-line terminal mention). |
   | `investment` | Optional. The `/invest` picture from Step 5.6: `{ budgetUsd, boughtThisWeek, holdings[], suggestions[], news[] }`. `holdings`: `{ stockId, name, plUsd, maDistPct, lastClose, ma200, ma20, score?, scoreHistory?, series? }`. `suggestions`: `{ stockId, name, reason, dividend, lastClose, ma200, ma20, maDistPct, score?, scoreHistory?, series?, pinned?, pinnedUntil? }`. A `pinned` suggestion is a user comparison pin (invest `pin` mode) — rendered with a distinct "📌 Pinned" chip, a "comparison only, through `pinnedUntil`" caption, and **no Buy button**; ranked by score among the picks but never the stable `top`. The `dividend` boolean is **factual — does it pay ANY dividend** (drives the "Dividend" vs "Growth" chip regardless of yield; a token payer like NVDA is still "Dividend"). The yield-based payer gate that governs the dividend-first score penalty is separate and lives inside `score.py` (`pays_dividend` vs the internal income-grade gate). The expandable panel renders `score` (composite 0–100) with its week-over-week trend from `scoreHistory` (`{week, score}[]` — a sparkline + delta once ≥2 weeks exist; "new — trend builds weekly" at 1), and a price line chart from `series` (`{date, close, ma20, ma200}[]`, ~6mo weekly, from `scripts/ma.py`). All three are optional — the panel degrades to just the numbers when absent. `news`: `{ headline, source, date, url?, stockId?, group? }` — mapped straight from `/invest`'s `data/news.json` (invest Directive 9: world/macro + company events affecting ratings, refreshed daily by `watch`/weekly by `scout`). `group` ∈ `subscription · world · company` files the item under a subheading in the news rail (paid publications → world/macro → company); missing → `world`. Per Directive 9 the news block is **never empty** on a normal run: if the day's gather returned nothing, carry the most recent `news.json` rather than sending `[]`. **Omit the whole `investment` field** only when `/invest` produced nothing at all (e.g. the scan errored), so the section stays hidden. Never fabricate figures: `plUsd` and the MA values come straight from the `/invest` ledger and `scripts/ma.py`. |
   | `calendar` | Optional. The Schedule section (Step 5.8): `{ appointments[] }`, sourced from Google Calendar via `/google-calendar agenda`. Each appointment: `{ date, title, time?, endTime?, allDay?, location?, url? }` — `date` is ISO `YYYY-MM-DD` (the event's local start day); `time`/`endTime` are display strings (`"9:00 AM"`), omitted for an all-day event (set `allDay: true`); `url` is the event's `htmlLink`. Query a window spanning the **1st of the current month through the end of the next month** (`--days ~50 --max 100`) so the calendar's month-forward navigation has data — NOT just the next 14 days. The viewer's month grid also overlays task deadlines from `clients[].items[].deadline`, so do NOT duplicate TODOs here — `appointments` is calendar events only. The Appointments panel shows today's + this week's events; the grid shows the whole month with prev/next nav. **Omit the whole `calendar` field** when `/google-calendar` wasn't queried or produced nothing (e.g. auth missing, `--no-calendar`), so the Schedule section stays hidden. Credential guard applies — headline/location text only, never credential-shaped bodies. |
   | `topStories` | Optional. The **Top Stories** rail (Step 5.9): an array of `{ headline, source, date, url, section? }` — the day's general news from **The New York Times** and the **Financial Times**, each `url` linking to the source article. `source` is the publication badge (`"NYT"` / `"Financial Times"`); `date` is the story's publish date (ISO `YYYY-MM-DD`); `section` is an optional desk label ("World", "Business"). Pulled from the two outlets' **public RSS feeds** (headline + link are free even when the article is paywalled) — never fabricate a headline or link. The viewer freshness-windows the rail (`FRESH_WINDOW_DAYS`, 3) and caps display at 8, so it carries **the day's** news; keep `dateISO` accurate. **Omit the whole field** (or send `[]`) when the gather was skipped (`--no-topstories`) or failed → the rail stays hidden. Credential guard applies — headline/section text only. |
   | `aiReleases` | Optional. The AI release watch (Step 5.7, [ai-releases.md](ai-releases.md)): `{ releases[], announcement? }`. `releases`: `{ vendor, headline, date, source, url, version? }` — new-model / new-tool / feature-rollout entries from the six fixed vendor feeds (Anthropic platform, Claude Code, OpenAI, xAI, DeepSeek, Qwen), deduped against the seen-index, newest first, display capped at 8, each `url` citing its release page (renders as the "AI Releases" rail section with a vendor badge per line). `announcement`: `{ kind, title, detail, date, url }` — ONLY a fresh (≤48h since first seen) MAJOR **Anthropic** announcement (new model launch or major new tool/capability); renders as the full-width bulletin band above Morning summary; other vendors never populate it. Omit `announcement` when nothing fresh qualifies (band stays hidden); omit the whole field when the watch never ran and no cache exists. |
   | `generatedAt` | `"generated H:MM AM/PM"`. |

   **Credential guard still applies:** put only headline text in the data; never emit
   credential-shaped body content (same rule as the terminal briefing).

### Correspondence deep-links

When a task cites linkable correspondence, populate the matching `…Url` field (`itemUrl`,
`signalUrl`, or an opportunity's `url`). The renderer wraps these in `target="_blank"
rel="noopener"` anchors automatically — never build the anchor markup here, only the URL.

- **Gmail** — the message's `link` field from `email-fetch.sh` (a `mail.google.com`
  `#search/rfc822msgid:` permalink).
- **Quo / OpenPhone** — the documented app scheme `openphone://message?number=<E.164, URL-encoded>`
  keyed to the contact's number. OpenPhone exposes **no web permalink to a specific thread**, so
  never invent a `my.openphone.com/…` / `app.openphone.com/…` URL.
- **iCloud** — no web URL exists; leave the field unset (plain text).

3. **Write the feed.** Write `window.AGENDA_DATA = <pretty-printed JSON>;` to the Step 1 path
   with the Write tool (a `.js` file, not JSON — the page loads it via a `<script>` tag so it
   works from a `file://` URL with no fetch and no server). The object is the briefing you just
   assembled; nothing else goes in the file.

4. **Print the link.** After the terminal briefing, append one line:

   ```
   📄 Browser view: file:///home/francis/lab/odyssey-alive/agenda/publish/index.html
   ```

   Use the real absolute `file://` path so it is clickable. This is the last thing the run emits.
   **If `agenda/publish/index.html` does not exist yet** (the viewer has never been built), still
   write the data, then add one line: `↳ first run: build the viewer once with
   \`pnpm --dir agenda install && pnpm --dir agenda build\``.

## Notes

- **Ordering vs. the Chart Output Gate:** the gate governs the *terminal* draft and must pass first.
  The data feed is written from that passed draft, so the two never diverge. The write is not itself
  a gate and never blocks the briefing — a failure degrades to a one-line
  "Browser view unavailable this run" note and the terminal briefing stands.
- **Source vs. build output:** `agenda/src/` is committed; `agenda/publish/` (including the
  `data/` feed) is gitignored and regenerated. To change the layout or add JS, edit `agenda/src/`
  and rebuild — do NOT hand-edit `agenda/publish/`.
- **Priorities mode** may reuse this viewer later; keep the `AGENDA_DATA` contract stable if that
  happens (update `types.ts`, `main.ts`, and this file together).
