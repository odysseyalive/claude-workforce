# Cleanup Workflow

Two-phase cleanup: (1) mark dateless TODOs as DONE, (2) archive DONE items older than 6 months.

### Phase 1: Mark TODOs without DEADLINE as DONE

A TODO without a `DEADLINE:` property on its next line is considered to have no due date. See [org-format.md](org-format.md) § "Date Patterns" for the full rule (inline timestamps are creation/context dates, not deadlines).

1. **Scan** — Find all `TODO` headlines across all org files
2. **Filter** — Identify TODOs where the immediately following line does NOT contain `DEADLINE:`
3. **Preview** — Display the list grouped by file
4. **Confirm** — Ask the user to confirm before making changes
5. **Execute** — Change `TODO` to `DONE` on each confirmed headline
6. **Report** — Show count of items changed per file

### Phase 2: Archive old DONE items

Archive DONE items older than 6 months. Follow the archive format, subtree extraction rules, age threshold, and removal order specified in [org-format.md](org-format.md) § "Archive Format".

1. **Scan** — Find all `DONE` headlines across all org files
2. **Filter old** — Items with dates older than 6 months (include DONE items with no date whose parent heading is old enough; skip dateless items with no datable parent)
3. **Preview** — Display count per file using "Archive Preview" format in [output-formats.md](output-formats.md) § "Output Formats"
4. **Confirm** — Ask the user to confirm
5. **Execute** — Append subtrees to `.org_archive`, remove from source (reverse line order)
6. **Report** — Items archived per file and archive file sizes
