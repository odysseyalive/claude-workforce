# Agenda — Security
<!-- Enforcement: HIGH — write-guard hook enforces, grounding check in SKILL.md -->

## Security: Sensitive Content

Many org files contain credentials, passwords, API keys, server IPs, and connection strings embedded in their content (not in TODO headlines). The skill must:

1. **Never display** content below a TODO headline beyond the headline text itself
2. **Never search for or extract** passwords, keys, tokens, or credentials
3. **Only modify** content on org files via the allow-list below

### Write Allow-List (triage + cleanup)

Enforced at write time by `hooks/triage-write-guard.sh`. These are the only edits permitted on `.org` files in the org directory:

1. **TODO ↔ DONE keyword swap** on a single headline (cleanup mode)
2. **DEADLINE insertion** — append a single `   DEADLINE: <YYYY-MM-DD Day>` line directly after a TODO headline
3. **DEADLINE date replacement** — change only the `<YYYY-MM-DD ...>` portion inside an existing `DEADLINE:` line
4. **End-of-file TODO append** — add a new `** TODO ... <YYYY-MM-DD Day>\n   DEADLINE: <...>\n   <summary>` subtree at the very end of the file
5. **Dated body note** — append a `   - YYYY-MM-DD: <text>` line under an existing TODO body, IF no credential keyword appears in the existing body (the hook checks)
6. **HOLD reason line** — insert a `   - HOLD: <reason>` line directly under a HOLD/TODO headline
7. **DONE subtree removal** (Phase 2 archive) — delete one complete `** DONE ...` subtree when its `old_string` contains **zero** `CLOCK:` lines. The deletion must be a single contiguous block starting with a DONE headline and ending at a same-or-shallower headline (or EOF). CLOCK-bearing subtrees remain blocked — those must be moved manually.

Anything else (including `Write` tool calls) on org files is blocked by the hook. The hook does NOT apply to `references/account-index.org` — that file is freely editable by the skill.

### Credential Guard Regex

The hook detects credential-shaped content via case-insensitive ERE: `(password|passwd|secret|token|api[_-]?key|^USER:|^PASS:|https?://[^[:space:]]*:[^[:space:]]*@)`. If a proposed Edit increases the count of matching lines (NEW > OLD), the edit is blocked.

### Time-Data Preservation Guard

The hook also blocks any Edit that would remove time-tracking data from an org file:

- **CLOCK count check:** if `new_string` has fewer `^\s*CLOCK:` lines than `old_string`, the edit is blocked
- **LOGBOOK count check:** if `new_string` has fewer `^\s*:LOGBOOK:` openings than `old_string`, the edit is blocked

These rails apply to ALL operations on org files (triage, cleanup keyword swaps, archive, manual edits routed through Edit). Time data — billable hours, tracked work, audit trail — never disappears from a file via this skill.

**Cleanup Phase 2 (archive) impact:** the standard archive flow extracts a DONE subtree, appends it to `<project>.org_archive`, then deletes it from the source `.org` file. The deletion goes through Pattern 7 (above), which permits removal only when the subtree contains **zero** `CLOCK:` lines. CLOCK-bearing subtrees are skipped — they remain in the source file regardless of age. To archive a CLOCK-bearing item anyway, the user must manually move it outside the hook's allow-list.

---

*Split from agenda/reference.md by skill-builder. Enforcement boundary: grounding.*
