# AI Release Watch

Feeds the browser view's **AI Releases** rail section and the **Anthropic major-announcement
banner** above Morning summary. Picks up new models, API/platform tools, and feature rollouts
across the vendor feeds as they ship, each entry citing a link back to its release page.
Runs as `today` Step 5.7; skipped by `--no-ai-releases`. **Browser-view only** — the terminal
briefing is unchanged, except a one-line mention when a fresh major Anthropic announcement or
a new frontier-model release landed since the last run.

## Sources (fixed — six vendors)

Six vendors, but a vendor may read more than one channel (OpenAI does — see below); multiple
channels for one vendor all dedup into that vendor's single `seen` bucket.

| Vendor | Feed URL | Fetch mechanics | Carries |
|--------|----------|-----------------|---------|
| Anthropic | `https://platform.claude.com/docs/en/release-notes/overview` | playwright `web_fetch` | New models, API/platform tools, significant changes. Dated entries, newest first. |
| Claude Code | `https://github.com/anthropics/claude-code/releases` | GitHub API: `curl -s "https://api.github.com/repos/anthropics/claude-code/releases?per_page=10"` → `tag_name`, `published_at`, `html_url`, `body`. Do NOT scrape the HTML page (dates don't survive extraction); `html_url` is the citation link. | CLI feature/tool rollouts per version tag. |
| OpenAI | **Three channels, one `seen.openai` bucket:** (1) developer changelog `https://platform.openai.com/docs/changelog` (serves at `developers.openai.com/api/docs/changelog`); (2) product/news `https://openai.com/news/` and the linked `/index/<slug>` announcement pages; (3) Help Center **Model release notes** `https://help.openai.com/en/articles/9624314-model-release-notes`. | playwright `web_fetch` on each channel; dedup all three into `seen.openai` (a launch seen on any channel never re-surfaces from another). | Developer changelog carries API models/endpoints/features (dated `Jul 6`-style headings). Consumer/model-family launches ship on the product + Help-Center channels FIRST and often never hit the developer changelog — read those two so a flagship GA can't slip through (e.g. GPT-5.6 Sol/Terra/Luna, 2026-07-09, which never appeared on the changelog). |
| xAI | `https://docs.x.ai/developers/release-notes` | playwright `web_fetch` | Grok models + xAI API features. Dated entries under month headings. |
| DeepSeek | `https://api-docs.deepseek.com/news/<slug>` | Sitemap discovery: `curl -s https://api-docs.deepseek.com/sitemap.xml \| grep -o 'https://api-docs.deepseek.com/news/[^<]*'` — slugs are `newsYYMMDD` (sortable). Fetch only slugs not in the seen-index; the item page is the citation link. There is no index page (`/news` 404s). | Model releases, API changes, deprecations. |
| Qwen | `https://qwen.ai/research` | JS-rendered SPA — `web_fetch` returns an empty shell. Use `browser_navigate` + `browser_snapshot`; entries carry `YYYY/MM/DD` dates and Release/Open-Source tags. (`qwen.ai/blog` is a dead route; `qwenlm.github.io/blog` is stale.) | Qwen model releases and research drops. |

## State — the seen-index

`.claude/skills/agenda/data/ai-releases.json` (skill-local, gitignored):

```json
{
  "last_checked": "YYYY-MM-DD",
  "seen": {
    "anthropic": ["2026-07-01|Access restored…", "2026-06-30|Claude Sonnet 5…"],
    "claude-code": ["v2.1.205", "v2.1.198", "v2.1.197"],
    "openai": ["2026-07-06|GPT-Realtime-2.1…"],
    "xai": ["2026-07-08|Grok 4.5…"],
    "deepseek": ["news260424"],
    "qwen": ["2026-06-22|Qwen-AgentWorld…"]
  },
  "announcement": { "...AnthropicAnnouncement", "first_seen": "YYYY-MM-DD" },
  "releases": [ "...AiRelease[] display cache, newest first" ]
}
```

**The seen-index is append-only and permanent.** Every entry ever surfaced gets a key here —
`vendor: [key, …]` where the key is the version tag (Claude Code), the news slug (DeepSeek),
or `date|headline-prefix` (date-keyed feeds). Entries age out of the display `releases` cache
but **never** leave `seen` — an old discovery must never resurface as new, no matter how the
display cache rotates. Missing/empty state → **bootstrap**: take the last 14 days of each feed
PLUS each feed's single newest entry (so every vendor is represented even if quiet).

## Procedure

1. **Read state** (bootstrap if absent).
2. **Gather each feed** per the fetch mechanics above. A single feed failing does not stop
   the others.
3. **Dedup against the seen-index** — drop anything whose key is already in `seen[vendor]`.
   Only genuinely-new entries proceed.
4. **Filter for the rail.** Keep entries that ship something: new models, new tools/
   capabilities, availability/deprecation changes, notable feature rollouts. Drop pure
   bug-fix releases and housekeeping. Summarize each kept entry to a one-line headline;
   set `vendor`, `source` (short citation label), `url`, and `version` where applicable.
5. **Dedup cross-feed twins** (e.g. a model launch announced on both an API changelog and
   a CLI release): keep the primary vendor entry, drop the duplicate — unless the second
   adds real substance.
6. **Classify MAJOR (Anthropic only).** An **Anthropic/Claude Code** entry is major ONLY if
   it is (a) a **new model launch** or (b) a **major new tool/capability** (public beta or GA
   of a named tool). When unsure → routine. Other vendors are never banner candidates —
   the banner is exclusively for Anthropic major announcements. A frontier-model release
   from another vendor (e.g. a new GPT/Grok/DeepSeek flagship) still earns its one-line
   terminal mention via Step 8.
6b. **Enrich major launches (any vendor).** For an entry that is a **new model or
   model-family launch/GA** — any vendor, not routine changelog features, patches, or
   housekeeping — do ONE lightweight verify-and-enrich pass before finalizing its headline:
   a single `WebSearch` for the launch plus one `web_fetch` of the most authoritative dated
   result (the official post, or a reputable dated write-up), then fold a couple of
   substantive facts into the one-line headline — **pricing ($/MTok)**, **context window**,
   and **one independent-benchmark or significance note** — keeping the citation in `url`.
   **Strictly gated to majors:** only a launch/GA triggers it (a feature/patch never does),
   so the daily run stays cheap. **Non-blocking:** a failed or empty fetch degrades to the
   plain Step 4 headline. This enriches the existing `aiReleases.releases[]` entry (richer
   `headline`, same `url`) — no schema change to [types.ts](../../../../agenda/src/types.ts).
7. **Banner rule.** `aiReleases.announcement` = the newest MAJOR Anthropic entry whose
   `first_seen` is **≤48h ago** (stamp `first_seen` on first sighting). Older majors drop
   back to the rail; omit the field entirely when nothing fresh qualifies.
8. **Rail list + terminal line.** Merge new entries into the display cache, newest first,
   keep the most recent 8. Append every surfaced entry's key to `seen[vendor]`. If anything
   NEW landed since the last run, add one terminal line to the briefing:
   `🆕 AI releases: <vendor> <headline> (+N more)` — new items only, never re-announce.
9. **Write** the updated state file, and emit the `aiReleases` object (per
   [html-render.md](html-render.md)) into `AGENDA_DATA`.

## Failure handling

Non-blocking, like the opportunity and invest scans: a feed failure → carry the cached
`releases` for that vendor (note it in one terminal line); omit `announcement` unless the
cached one is still ≤48h from `first_seen`. Never block the briefing on this step.
