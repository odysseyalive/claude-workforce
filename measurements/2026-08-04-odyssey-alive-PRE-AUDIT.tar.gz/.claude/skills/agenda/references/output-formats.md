# Agenda — Output Formats
<!-- Enforcement: MEDIUM — chart-output directive enforced via SKILL.md gate (priorities/today modes) -->

## Output Formats

### Archive Preview (Cleanup Phase 2, Step 4)

```
## Archive Preview — [N] DONE items older than 6 months

### projectname.org — [M] items to archive
- Line 45: "completed task headline" — 2025-08-12
...
```

### Review Output (Review mode, Step 3)

```
## Review: projectname.org — [N] TODOs

* Section Heading
  - [ ] Task headline — <2026-04-03>
  - [ ] Task headline — DEADLINE: 2026-04-08
```

---

## Triage Proposal Format

Display block per project file:

```
PROPOSED CHANGES

destinationcabo.org
  [+ DEADLINE]  "Send revised quote"      → 2026-05-08
                 (from Amy's email yesterday: "by Friday")
  [+ DEADLINE]  "Vendor follow-up"        → 2026-05-06 (today, no signal — discovery default)
  [~ DEADLINE]  "Site copy review"        → 2026-05-12  (was 2026-05-15; from Quo call transcript)
  [+ TODO]      "Confirm seating capacity with venue" <2026-05-06 Wed>
                 DEADLINE: <2026-05-09 Sat>
                 (source: Quo SMS, 2026-05-05 14:22)
  [+ NOTE]      "Site copy review"
                 - 2026-05-06: Amy confirmed deadline shifted to Friday.
  [+ EVENT]     "SBDC advising session — Q3 growth plan"  → 2026-05-09 10:00–11:00
                 Location: SBDC Tillamook / Zoom link
                 (calendar write via /google-calendar — not an org file; from sbdc.org invite 2026-05-06)

UNMAPPED CONTACTS (review separately)
  Quo SMS from +1-555-0301 — "Are you still doing those AI workshops?"  [kind_hint: work]
  Gmail from anna@unknownco.com — "Quote request for new website"        [kind_hint: work]

NOISE (dropped)
  3 newsletters, 1 CC'd FYI thread on tickettomato
```

After display, walk each non-noise proposal with the user via numbered options: `Accept`, `Edit date`, `Edit headline`, `Skip`, `Apply all remaining`. For a `[+ EVENT]` proposal the same walk applies (`Edit date` covers the start/end time; `Edit headline` covers the event title); accepting it dispatches `/google-calendar event` rather than writing an org file.

### Bulk Decision Codes (dateless-todo walk)

When walking a list of dateless TODOs, accept compact per-item codes so the user can decide many at once without one-by-one prompts:

| Code | Action |
|------|--------|
| `T` | Set DEADLINE to today |
| `F` | Set DEADLINE to end of this week (Friday) |
| `N` | Set DEADLINE to next Friday |
| `S` | Skip (leave dateless — no DEADLINE added) |
| `D` | Mark as DONE (TODO → DONE keyword swap, no DEADLINE added) |
| `H "<reason>"` | Mark as HOLD with reason (TODO → HOLD swap + insert `- HOLD: <reason>` line) |
| `YYYY-MM-DD` | Custom date |

Range syntax: `1-5 T, 6-14 F, 15 D, 16-20 N`. Mixed: `1 T, 2 S, 3 2026-05-20, 4-10 F`. Apply-all: `all T` (or any single code) shorthand.

For `H`, the reason goes in double quotes and may apply to a range: `1-5 H "blocked on Caffelli pause"`. If a user provides bare `H` without a reason, prompt for it before proceeding (a HOLD without context is just a TODO that won't show up).

### Duplicate TODOs

When the user flags two items as the same task (e.g., `17,19 (same task) F`), do NOT apply the same code to both. Instead:

1. Mark the **older** TODO as DONE (TODO → DONE keyword swap)
2. Apply the user-specified code to the **newer** TODO

Older = earlier creation date in the headline `<YYYY-MM-DD ...>` suffix. Rationale: the newer TODO carries current thinking; the older one is a duplicate remnant. Time data on the older TODO is preserved by the keyword swap (per the time-preservation guard).

The `D` code uses the write-guard Pattern 1 (keyword swap). The `H` code uses a two-step write: (1) keyword swap TODO → HOLD, then (2) insert the reason line directly under the headline. Both steps pass the write-guard hook (Patterns 1 and 6 respectively).

---

## Briefing Format (Step 6) — priorities mode

The agenda is rendered in five parts, in this order:

### 1. Synopsis (1-2 short paragraphs of prose)

A trusted-colleague morning brief. Lead with the overall shape of the day — what's on fire, what's quiet, any cross-cutting theme (e.g., "Two clients are waiting on quotes that touch the same vendor"). Do NOT enumerate every task here; the chart does that. Keep it under 120 words.

### 2. What's Needing Done (table, grouped by client)

For each client/project (most-urgent client first), emit a sub-table with the most urgent item at the top. Use this column shape:

```markdown
#### <Client / Project>

| Priority | Item | Deadline | Signal / Context |
|----------|------|----------|------------------|
| 🔴 Overdue | Send revised quote | 2026-05-15 | Amy email 2026-05-16: "still waiting" |
| 🟠 Today | Confirm vendor seating | 2026-05-18 | Quo SMS yesterday — venue asked for final count |
| 🟡 This week | Site copy review | 2026-05-22 | — |
| 🟢 Next week | Vendor follow-up | 2026-05-27 | — |
```

Rules:
- **Priority icons** map to the baseline rank: 🔴 Overdue, 🟠 Today, 🟡 This week, 🟢 Next week, ⚪ Horizon
- **Bumped items** (Step 3 of the workflow) get pinned to the top of their client group regardless of baseline DEADLINE rank, and the Signal/Context column MUST cite the email/SMS/call that triggered the bump
- **Client order:** the client whose top item has the most urgent (post-bump) priority sorts first
- **Signal/Context column:** one short line, source + gist (e.g., "Gmail 2026-05-17: deadline moved to Friday"). Empty `—` when the item has no recent correspondence
- Headline text in the Item column is the org-mode headline verbatim, truncated to ~60 chars if needed

### 3. Awaiting Correspondence (table)

Outbound items where a reply is pending. From Step 4 of the workflow.

> **Generated, never hand-written.** This table and § 4 below are produced by
> `scripts/attribution.py` (today-workflow.md § Step 5.95) and pasted verbatim. A row whose
> counterparty has no resolvable provenance pointer is dropped there; a null name renders as
> `Broom21 — unnamed contact`. Hand-authoring either table is the 2026-07-20 defect.

```markdown
### Awaiting Correspondence

| To | Re | Asked | Days Out | Suggested Follow-up |
|----|----|----|----------|---------------------|
| Amy (Destination Cabo) | revised quote | 2026-05-12 | 6 | Nudge today |
| South Lake Pools | landing page scope | 2026-05-15 | 3 | Let it ride |
```

If there are no awaiting items, emit the header followed by `None at the moment.`

### 4. Clarifications Needed (table)

Questions Francis should send before work can advance. From Step 5 of the workflow.

```markdown
### Clarifications Needed

| Recipient | Channel | Question | For Task |
|-----------|---------|----------|----------|
| Amy (Destination Cabo) | Email | Is the new deadline 2026-05-22 firm, or contingent on vendor confirmation? | Send revised quote |
| Vendor (Ticket Tomato) | SMS | What's the final seating capacity? | Confirm seating with venue |
```

If there are no clarifications needed, emit the header followed by `None at the moment.`

### 5. Opportunities (table)

The folded-in `/opportunity-scout` result (per SKILL.md § Opportunity-Scan Gate), placed last. Shows what's **new/changed since the last scout**, grouped by fit tier:

```markdown
### Opportunities

| Fit | Type | Opportunity | Note |
|-----|------|-------------|------|
| 🟢 Strong | gig · national | Long-term n8n + Postgres build | retainer-shaped; ⚑ needs partner |
| 🟡 Adjacent | hiring · Portland | Fractional automation consultant | — |
```

- Nothing new → emit the header followed by `None new at the moment.`
- Guard-skipped (scout ran in the last ~18h) → show current open highlights with a `(no fresh scan — last run <when>)` note.
- Scout failed → `Opportunities: unavailable this run.`
- Always point to `/opportunity-scout status` for the full board.

### Today Variant

Same five parts, narrower filter — only overdue + due-today + same-day-urgent correspondence. Synopsis is 1 short paragraph (not 2). The chart shows only today's items grouped by client. Awaiting Correspondence and Clarifications Needed sections are restricted to anything urgent enough to act on today (otherwise they show `None for today.`). The Opportunities section shows the scout's new/changed items or `None new at the moment.` If nothing is due and inbox is quiet, the synopsis is one sentence and the tables each show their empty placeholder.

---

*Split from agenda/reference.md by skill-builder. Enforcement boundary: grounding.*
