# Workflow: Priorities

Scan org files, gather recent email, SMS, and call signals, run the triage update-pass (with confirmation walk) so the org files reflect the latest correspondence, then assess against the freshened TODOs, apply correspondence-driven priority bumps, and present the agenda as a synopsis + chart grouped by client + Awaiting Correspondence + Clarifications Needed.

> **Flag:** `--no-triage` (alias `--no-update`) skips Step 1b entirely — the assessment runs against the Step 1 baseline scan as-is, with correspondence still surfaced as display-only bumps (the pre-Step-1b behavior). Use it for a fast read when you don't want a confirmation walk.

### Step 1: Gather org data (scan + extract)

1. **Scan** — Glob all `.org` files in the org directory (see [org-format.md](org-format.md) for path)
2. **Extract TODOs** — For each file, extract all `TODO` (and `HOLD`) headlines with their DEADLINE dates. This active-TODO set is both the assessment target AND the match target the Step 1b triage classifier needs (do not score yet — scoring moves to Step 1c so it sees any writes Step 1b applies).

### Step 1-zoho: Refresh Zoho time + tasks (freshen org from Zoho Books)

**Skip if `--no-triage` or `--no-sync` is set.** Otherwise, before triage and assessment, invoke `/timesheet pull` via the Skill tool — `Skill(skill=timesheet, args="pull")` — so the org files reflect the latest Zoho Books tasks and tracked time (timers run since the last run). This is an explicitly-named dispatch, so the Route Consultation gate is satisfied; do NOT freelance Zoho API calls here. The pull is additive (insert-only CLOCK / `:ZOHO_*:` writes per the timesheet sync model) and runs without per-item confirmation — it is NOT a triage write, so the triage confirmation-walk directive does not apply. If `/timesheet` reports nothing new, proceed silently. Any files it wrote must be re-read in Step 1c.

### Step 1a: Gather signals (shared payload)

This is the single canonical signal fetch for the whole run — both the Step 1b triage pass and the Step 2/2b/2.5 assessment consume it. Do NOT re-fetch later.

1. **Email — both inboxes (required).** Fetch the last 24-48h from Gmail (`imap.gmail.com`, `GMAIL_EMAIL` / `GMAIL_APP_PASSWORD` in `.env.local`) AND iCloud (`imap.mail.me.com`, `ICLOUD_EMAIL` / `ICLOUD_APP_PASSWORD`), filtering out promotions and spam. The immutable "Always query both inboxes" directive applies — never drop an inbox to dedupe a fetch. (`scripts/email-fetch.sh recent --hours 48 --max 100` covers both.)
2. **Quo SMS** — `scripts/quo-fetch.sh messages --since <ISO8601>` returns SMS to/from the configured inboxes.
3. **Quo calls + transcripts** — `scripts/quo-fetch.sh calls --since <ISO8601>` lists calls. For any call whose summary suggests urgency, deadline change, or an explicit ask, fetch the transcript via `scripts/quo-fetch.sh transcript <call-id>`. Use the auto-summary as the default signal; read the transcript only when the summary is ambiguous (see [signals.md](signals.md) § "Quo Signal Types").

**Window:** priorities uses a **48h** gather (its wider reach). The Step 1b triage sub-procedure classifies over whatever window it is handed — here, this 48h payload.

### Step 1b: Triage update-pass (freshen org files)

**Skip this step entirely if `--no-triage` is set.** Otherwise, run the **Triage workflow Steps 1-6** ([triage-workflow.md](triage-workflow.md)) as a sub-procedure so the org files reflect the latest correspondence before assessment:

- Supply the Step 1 active-TODO set and the Step 1a signal payload (do not re-gather — triage Step 1's fetch is satisfied by Step 1a).
- The full per-write **confirmation walk (triage Step 5) runs verbatim** — the orchestrator collects all proposals, walks them with the user, and no write happens without per-item approval (immutable "Triage writes are confirmed, never silent" directive). **This pauses for user input mid-`/agenda` before the chart appears.**
- Triage Step 7 (standalone report) is **suppressed** — its outcome folds into the assessment that follows.
- **Empty change set → silent no-op:** if no proposals are produced, emit no banner; proceed straight to Step 1c (no re-read needed — Step 1's scan is still current).

### Step 1c: Re-read and score

1. **Re-read (gated)** — IF Step 1b OR Step 1-zoho applied ≥1 write → re-Glob/re-extract the affected `.org` files (all-files is simpler and cheap) so the assessment sees freshened DEADLINEs, new TODOs, and pulled time. IF both were skipped or applied zero writes → reuse the Step 1 scan unchanged.
2. **Score and rank (baseline)** — Prioritize by:
   - **Overdue DEADLINEs** (highest priority — past due date)
   - **Due today** (second priority)
   - **Due this week** (third priority)
   - **Due next week** (fourth priority)

### Step 2: Match email signals against projects

Using the Step 1a email payload (do **not** re-fetch): cross-reference sender names and email subjects against org file project names. Look for urgency signals — client requests, deadline changes, payment issues, "ASAP", follow-ups — and note any email that raises or lowers the priority of an existing (now freshened) TODO.

### Step 2b: Match Quo signals against projects

Using the Step 1a Quo payload (do **not** re-fetch): normalize sender/recipient phone numbers and look them up in `references/account-index.org` to map SMS and call signals to projects.

### Step 2.5: Scan for untracked requests and updates

After matching all signals (email + SMS + call) against the freshened TODOs, make a pass for **untracked requests** and **CC'd updates** — see [signals.md](signals.md) § "Email Signal Types" for full definitions. (Most actionable untracked items will already have been written by Step 1b; what remains here are display-relevant notes, not new writes.)

### Step 3: Apply correspondence-driven priority bumps

For each client/project, evaluate whether recent correspondence (email, SMS, or call from Step 2 / 2b) temporarily elevates the priority of its next action:

1. **Bump triggers** — explicit "ASAP" / "EOD" / "today" / a named earlier deadline / a payment or blocker signal / a client question awaiting an answer
2. **Apply the bump** — move the affected item to the top of its client group regardless of baseline DEADLINE rank
3. **Record the why** — the bump must surface in the chart's Signal/Context column so the elevation is auditable

### Step 4: Assemble "Awaiting Correspondence"

Outbound items where Francis is waiting on a reply. Source:

1. Sent items in Gmail / iCloud over the last ~14 days with no inbound reply on the thread
2. Outbound Quo SMS over the last ~14 days with no inbound reply
3. Outbound calls flagged in org file body notes as "awaiting callback" or similar

For each, record: who it went to, what was asked (1 short line), how many days ago, and suggested follow-up timing (Nudge today / Nudge in 2-3 days / Let it ride). If a thread was already nudged, mark it.

**[today-workflow.md](today-workflow.md) § Step 4's two checks and § Step 5.95 apply here identically** — no reply exists (verified against the fetched thread, not an org note) and dates from real timestamps. Build `AwaitingRow`/`ClarificationRow` objects and render both tables through `scripts/attribution.py`; attribution is enforced there, not by remembering a rule. These were written up under `today` but are not today-specific; `priorities` had none of them, which is how the 2026-07-20 misattribution and the 2026-07-09 "Amy" row both reached the chart.

### Step 5: Assemble "Clarifications Needed"

For each ambiguity surfaced while building Steps 1-4 — missing scope, unclear deadline, conflicting signals between two sources, a project with no recent activity but an unscheduled TODO — propose a clarifying message Francis should send. Record: the recipient, the channel (email / SMS / call), the question to ask (1 short line), and which task/project it unblocks. Do NOT send anything; this is a proposal section.

### Step 5.5: Opportunity scan (SKILL.md § Opportunity-Scan Gate)

After the update-pass and before assembling the chart, fire `/opportunity-scout --quick` via the Skill tool (explicitly-named dispatch — do NOT freelance web search). **Guard:** skip the dispatch if `--no-scout` was passed OR the opportunity-scout run-state (`opportunity-index.md` top marker `last-run`) is within ~18h; on a guard-skip, still render the Opportunities section from the existing index. Capture the scout's "new since last run" result for the Opportunities section. Non-blocking: a scout failure degrades to "Opportunities: unavailable this run."

### Step 6: Synthesize and present

Render per the new chart format at [output-formats.md](output-formats.md) § "Briefing Format". The Chart Output Gate in SKILL.md enforces the structure — synopsis, "What's Needing Done" table grouped by client (priority-ordered, with correspondence-driven bumps surfaced in the Signal/Context column), "Awaiting Correspondence" table, "Clarifications Needed" table, and the **Opportunities** section (folded-in `/opportunity-scout` result).
