# Triage Workflow

Single mode that does all org file writes. Collects signals from email, Quo SMS, Quo call transcripts, Slack mentions/DMs, and dateless TODOs; classifies each via the `triage-classifier` agent; presents proposals; applies confirmed writes. See [signals.md](signals.md) § "Quo Signal Types", § "Slack Signal Types" and § "Triage Classification Categories" for full specifications.

> **Callable as a sub-procedure.** `priorities` and `today` invoke **Steps 1-6 of this workflow** as their update-pass (priorities/today Step 1b) so org files are freshened before assessment. When invoked as a pre-pass: (1) the caller MAY supply the already-gathered signal payload and active-TODO set — skip the Step 1 fetch for whichever inputs are provided, and honor the caller's window (priorities = 48h, today = 24h); (2) the **Step 5 confirmation walk always runs verbatim** — the pre-pass never silences it; (3) **Step 7 (report) is suppressed** — its outcome folds into the caller's assessment instead of printing a standalone report. Run standalone (`/agenda triage`), all seven steps execute and the window defaults to **7 days (168h)** — wide enough to catch a conversation from earlier in the week that a daily pass may have missed. (The `today` and `priorities` pre-passes keep their own tighter windows — 24h and 48h — since they run daily; the 7-day reach is the standalone default.)

## Step 1: Gather signals (parallel)

1. **Org TODOs — full active set per project.** Glob all `.org` files in the org directory. For each file, collect:
   - **Dateless TODOs** (`TODO` headlines with no `DEADLINE:` line immediately after) — candidates for `dateless-todo-discovery`
   - **All active headlines** (`TODO` and `HOLD`, with or without DEADLINEs) — used by the classifier as the match target for incoming email/SMS signals (the "intelligently add to proper open task" path)
The fetch windows below are the **standalone** default (7 days / 168h). When triage runs as a `today`/`priorities` pre-pass, the caller supplies its own payload and window (24h / 48h) and this Step 1 fetch is skipped for whatever it provides.

2. **Gmail + iCloud** — `bash scripts/email-fetch.sh recent --hours 168 --max 100` returns a JSON array of messages from both inboxes
3. **Quo messages** — `bash scripts/quo-fetch.sh messages --since <7d-ago>`
4. **Quo calls** — `bash scripts/quo-fetch.sh calls --since <7d-ago>`; for each call, fetch transcript and summary in parallel via `transcript <id>` and `summary <id>` subcommands
5. **Slack mentions + DMs** — `bash .claude/skills/slack/scripts/slack-fetch.sh review --since <7d-ago>`, all configured workspace accounts in one call (per the Slack Signal Gate: skip silently when no `SLACK_TOKEN_*` is configured; a fetch failure degrades to "Slack: unavailable this run")

`email-fetch.sh` reads `GMAIL_*` / `ICLOUD_*` from `.env.local` and uses IMAP `BODY.PEEK[]` so messages are not flipped to read. `quo-fetch.sh` reads `QUO_API_KEY` and respects `QUO_INBOX_IDS` (sentinel `0` or unset = all inboxes). `slack-fetch.sh` reads every `SLACK_TOKEN_<label>` (multi-account). See [integrations.md](integrations.md) § "Quo REST Integration", § "Email REST Integration" and § "Slack REST Integration" for env var details.

## Step 1.5: Deep-read recap / action-list emails (full-body swap)

`email-fetch.sh recent` returns only a **~600-char snippet** per message — a triage overview, not the whole email. That is fine for a one-ask message, but a **meeting recap, an action/"next steps" list, or a forwarded multi-topic thread** packs several distinct asks past the first 600 chars, and the classifier (Step 3) only sees what it is given. Snippet-only classification therefore surfaces the FIRST item and silently drops the rest. (Incident 2026-07-16: a forwarded Zoom meeting-summary listed four "Next steps for Francis"; only the first reached the org files. See SKILL.md Discovered Issues Log.)

Before routing, **deep-read the emails that look multi-item** and replace their `body` with the full text:

1. **Flag candidates.** An email signal is a deep-read candidate when EITHER:
   - its `subject` or `snippet` contains a recap/action-list marker (case-insensitive): `next step`, `action item`, `action list`, `meeting summary`, `meeting recap`, `recap`, `minutes`, `assets are ready`, `to-do`, `to do list`, `follow up` / `follow-up`, `forwarded message`, `fwd:`; OR
   - its `snippet` is **truncated** (length ≥ ~590 chars, i.e. it hit the snippet cap) AND its sender resolves to a project via Step 2's index lookup (a mapped work contact — don't deep-read truncated newsletters).

   This gate is deliberately bounded — it fetches full bodies only for the handful of messages that plausibly hide multiple asks, never for every email.
2. **Fetch the full body** for each flagged signal: `bash scripts/email-fetch.sh get --id <account:uid>` (the `id` is the one `recent` already emitted, e.g. `icloud:10346`). It returns `{…, "body", "body_len"}`, tag-stripping HTML-only mails (Zoom recaps have an empty `text/plain` part) so the "Next steps" list survives.
3. **Swap + mark.** Replace the signal's `body` with the fetched full body and set `deep_read: true` on it so Step 3 knows to extract **every** action item (not just the first). A `get` failure (auth/network/not-found) is non-fatal: keep the snippet body, note it, and proceed.

Quo/Slack signals already carry their full text (`quo-fetch.sh` returns whole SMS/transcripts; `slack-fetch.sh` returns whole messages) — this step is email-only.

## Step 2: Route each signal through the index

For every collected signal, resolve its project slug(s):

- **Email signals** → `index_lookup_email <from>` (the sender's email address)
- **Quo SMS / call signals** → `index_lookup_phone <from>` (digit-normalized)
- **Slack signals** → match `from` (sender real name) case-insensitively against `:ALIASES:` values in `account-index.org` (no helper function yet — grep the index); the signal's `account` label disambiguates same-name senders across workspaces

**A contact can map to more than one project.** The lookup helpers print **all** matching slugs, one per line — a shared number or email (e.g. a dev contractor relaying work for several clients) legitimately matches multiple project blocks. Collect every returned slug:

- **Exactly one slug** → set `project_slug` to it and attach that project's `existing_todos[]` (the common case).
- **Two or more slugs** → leave `project_slug = null` and instead attach `candidate_projects[]` — one entry per matched slug, each carrying that project's active TODO set. The classifier picks the right project (or emits one classification per project when the signal genuinely spans both) by content — named entities, product/site names, topic — since the phone/email alone cannot disambiguate.
- **No slug** → `project_slug = null`, no candidates: surfaces in the unmapped report.

For the email Choosable-Stripe-style signals (sender already known to the user but not yet in the index), the kind_hint from the classifier guides the prompt.

## Step 3: Classify

Per the **Non-Obvious Decision Gate** directive in skill-builder, classifying free-form text into action categories is a judgment call → **mandatory agent**. Spawn the `triage-classifier` agent (see [../agents/triage-classifier/AGENT.md](../agents/triage-classifier/AGENT.md)) with:

- The full signal payload (all email + Quo SMS + Quo calls + Slack mentions/DMs + dateless TODOs). For emails deep-read in Step 1.5, pass the **full body** and the `deep_read: true` flag — a deep-read message may contain several distinct asks and the classifier emits **one classification object per action item** (see AGENT.md § Multi-item extraction), not a single object for the whole email.
- For each signal with a resolved `project_slug`, the **complete active TODO set for that project** (TODO and HOLD, with subject + DEADLINE if any) so the classifier can match the signal against existing tasks. A deep-read recap frequently spans **multiple** projects (e.g. one Barak meeting touching both `dynamicmotorsports` and `amishfurniture`) — pass every mapped project's TODO set (via `candidate_projects[]` when the sender is shared) so each extracted item routes to the right file.

For a signal carrying `candidate_projects[]` (multiple index matches), pass every candidate's slug + active TODO set; the classifier selects the project by content and returns the chosen slug in `project_slug` (drawing `matched_todo` from that project's TODOs), or emits one classification per project when the message contains a distinct ask for each.

The classifier returns JSON with category, the resolved `project_slug`, proposed deadline, proposed headline, proposed summary, confidence, kind_hint, a `matched_todo` reference (for `deadline-suggestion` and body-update categories), and a `proposed_event` object (for the `calendar-invite` category — see [signals.md](signals.md) § Triage Classification Categories). This is the routing that powers "intelligently add to proper open task" — when a signal refines an existing task, the classifier returns that task's `{file, line}` and the proposal becomes a body-note update instead of a new TODO.

## Step 4: Build the change set

Group classifications by org file. For each:

- `dateless-todo-discovery` → propose `+ DEADLINE: <today>` under the existing TODO
- `deadline-suggestion` → propose `~ DEADLINE: <new-date>` on the matched TODO (or `+` if no DEADLINE existed)
- `new-task` → propose `+ TODO <headline> <today>` block at end of the project file
- **body update** (signal refines an existing TODO without changing its deadline — e.g., new info, status update, follow-up message) → propose `+ NOTE` appending `- <today>: <summary>` under the matched TODO body
- `calendar-invite` → propose `+ EVENT` — a Google Calendar event from `proposed_event` (title, start, end, location). **Dedup first:** query existing events for the target date via `/google-calendar agenda` (dispatched through the Skill tool); if a matching event already exists (same date + overlapping title), drop the proposal silently. This is a **calendar write, not an org write** — no org file is touched.
- `noise` → drop silently
- `unmapped` (project_slug null) with `kind_hint = work | congregational` → defer to "Unknown contacts" section of the report; ask the user whether to add to index

The body-update path is the "intelligently add to proper open task" routing: when the classifier returns a `matched_todo` and the signal isn't proposing a new deadline, append the dated note instead of creating a duplicate TODO. The write-guard hook's Pattern 5 enforces the format and the credential guard checks the existing body before approving the edit.

Use the proposal display format in [output-formats.md](output-formats.md) § "Triage Proposal Format".

## Step 5: Confirmation walk

Walk every proposed change with the user via numbered options: `Accept`, `Edit date`, `Edit headline`, `Skip`, `Apply all remaining`. The first time the user picks "Apply all remaining", subsequent same-shape proposals auto-apply.

For unknown contacts, ask: "Add `<contact>` to index under which project?" → empty input skips, project slug adds via `index_add_email` / `index_add_phone`.

## Step 6: Apply confirmed writes

Confirmed **org** writes are each a single Edit call that matches one of the patterns enforced by `hooks/triage-write-guard.sh`:

1. DEADLINE insertion under a TODO headline
2. DEADLINE date replacement
3. Append a new TODO subtree at end of file
4. Append a dated note `- YYYY-MM-DD: <text>` under an existing TODO body

If the write-guard hook blocks an update (credential-shaped content detected in the existing body), the proposal is moved to the manual-edit list in the final report.

A confirmed **calendar-invite** proposal is applied differently — it is **not** an org write and does not go through the write-guard. Create the event by dispatching `/google-calendar event` through the Skill tool (per the Route Consultation gate, this is an explicitly-named dispatch — do not freelance the Calendar API), passing the confirmed `proposed_event` fields (title, start, end, location). Agenda never writes the calendar event itself; `/google-calendar` owns that write and its own confirmation surface.

## Step 7: Report

Show counts per org file (deadlines added, deadlines updated, TODOs created, body notes appended), the count of **calendar events created** (via `/google-calendar`) and any invites skipped as duplicates, list any unmapped signals, and list any manual-edit blocks from the credential guard.
