# Agenda — Signal Types & Classification
<!-- Enforcement: MEDIUM — grounding check in SKILL.md, classifier agent enforces -->

## Email Signal Types (Step 2.5)

1. **Untracked requests** — Identify direct emails (To: Francis) from senders associated with org file projects that don't correspond to any open TODO. These are potential new tasks. Look for action language: requests, questions needing answers, asks for deliverables, scheduling.
2. **CC'd updates** — Identify threads where Francis is CC'd rather than a direct recipient. These are situational awareness — conversations happening around projects that may not require action but provide useful context (e.g., internal client discussions, vendor coordination, status updates between other parties).

---

## Quo Signal Types (Triage)

Triage mode collects three additional signal kinds via the Quo REST integration:

1. **SMS messages** — direct SMS to/from inboxes scanned by triage. Treat the message body the same way as an email body: look for explicit dates, asks, project references.
2. **Call summaries** — Quo's auto-generated 1–3 sentence summary of each call. Use as the primary signal for call-derived deadlines and new tasks; it's already condensed and signal-dense.
3. **Call transcripts** — full speech-to-text transcript. Read only when the summary is ambiguous or missing. Transcripts may include personal details that aren't actionable; the triage-classifier should mark these as `noise`.

Routing: the sender phone (for incoming) or recipient phone (for outgoing) is normalized to digits and looked up in `account-index.org`. Unmapped Quo signals receive `kind_hint = unknown | work | congregational` from the classifier and surface in the unknown-contacts section of the report.

---

## Slack Signal Types (Triage)

Triage collects two signal kinds via the shared `/slack` REST integration
(`.claude/skills/slack/scripts/slack-fetch.sh review`), swept across **every
configured workspace account** (`SLACK_TOKEN_<label>` keys in `.env.local`).
Skipped silently when no token is configured; a fetch failure degrades to
"Slack: unavailable this run" and triage proceeds.

1. **Mentions** — messages in channels the user is a member of that @-mention them. Treat the message body like an email body: look for explicit dates, asks, project references. Channel context (name) often carries the project hint.
2. **DMs / group DMs** — direct and group-DM messages from others in the window. Highest reply-expectation signal class; a direct question in a DM weights like a direct email.

Routing: the sender's **real name** (`from`) is matched case-insensitively against `:ALIASES:` values in `account-index.org`; the `account` label can disambiguate when two workspaces share a name. Unmapped Slack signals surface in the unknown-contacts section of the report with the classifier's `kind_hint`, same as email/Quo.

Slack is read-only input — agenda never posts to Slack; there is no Slack write path.

---

## Triage Classification Categories

Returned by the `triage-classifier` agent (`agents/triage-classifier/AGENT.md`):

| Category | When |
|----------|------|
| `deadline-suggestion` | Signal references an existing TODO AND mentions a date or resolvable relative timeframe. Action: `~ DEADLINE: <new>` or `+ DEADLINE: <new>` if missing |
| `body-update` | Signal refines an existing TODO without changing its deadline — new info, status update, follow-up message, "I sent the file you asked for", "client confirmed receipt". Action: `+ NOTE` appending `- <today>: <summary>` under the matched TODO body. **This is the "intelligently add to proper open task" routing.** |
| `new-task` | Signal contains a clear ask AND no existing TODO matches. Action: `+ TODO <headline> <today>` at end of project file |
| `dateless-todo-discovery` | Existing TODO with no DEADLINE encountered during scan. Action: `+ DEADLINE: <today>` |
| `calendar-invite` | Signal is a meeting/calendar **invitation** — an appointment or event ask carrying a date (and usually a time), from any sender (includes but is not limited to SBDC advisor invites, e.g. `sbdc.org`/`oregonsbdc.org`). Action: propose a Google Calendar event created via `/google-calendar` (event mode). This is a **calendar write, not an org write**, and it is skipped when a matching event already exists (dedup). |
| `noise` | Newsletters, marketing, automated notifications, vague references, CC'd FYIs without action. Also: **no-message missed calls** and Google Local Services "new call from a potential customer" notifications — real leads leave a message; a missed call with no voicemail/SMS follow-up is spam and is never surfaced as a lead or return-call item (user ruling 2026-07-06). Action: drop silently |

### Match priority for incoming signals

When a signal arrives with a resolved `project_slug`, the classifier MUST first attempt to match it to an existing TODO in that project before considering `new-task`:

1. Look at the active TODO/HOLD set for the project (provided in the input payload)
2. Score each candidate TODO by subject overlap, named-entity overlap, and topic similarity
3. If best match score ≥ a confidence threshold AND the signal mentions a date → `deadline-suggestion` (matched_todo set)
4. If best match score ≥ threshold AND no date is proposed → `body-update` (matched_todo set)
5. Otherwise → `new-task`

This ordering implements the user directive: "Prefer updating an existing TODO over creating a new one."

A signal that is itself a **meeting/calendar invitation** classifies as `calendar-invite` independently of TODO matching — the invite→event proposal is a separate output from any deadline/TODO proposal. If the same message also carries a distinct ask, it may additionally yield a `new-task`/`body-update`; the calendar-event proposal never suppresses those and vice-versa.

Conflict policy when two signals propose different deadlines for the same TODO: use the most recent signal's date and surface both in the proposal so the user sees the conflict.

---

## Headline Format for Auto-Created TODOs

Auto-created TODOs (`new-task` category) follow the project's existing headline convention:

```
** TODO <imperative headline text> <YYYY-MM-DD Day>
   DEADLINE: <YYYY-MM-DD Day>
   <1–3 sentence summary of the signal that prompted this TODO>
```

- The trailing `<YYYY-MM-DD Day>` on the headline is the **creation date**, not a deadline. This matches the inline-date convention seen in existing org files (`destinationcabo.org`, `dynamicmotorsports.org`, etc.).
- The DEADLINE goes on the next line, indented with three spaces, surrounded by `<>`.
- The summary body is 1–3 sentences. Never include source URLs, message IDs, full email subjects (which may contain credentials), or sender contact details beyond a name reference.
- Heading depth (`**` vs `***` etc.) defaults to `**`. If the file has a clear top-level structure (e.g., `* Section / ** TODO Item`), append at the file's root level (`*`) and let the user re-nest manually.

---

*Split from agenda/reference.md by skill-builder. Enforcement boundary: grounding.*
