# Today Workflow

A tighter, today-only variant of `priorities`. Same data sources, same chart-first contract — narrower filter.

> **Flag:** `--no-triage` (alias `--no-update`) skips Step 1b — the briefing runs against the Step 1 scan as-is, correspondence surfaced as display-only bumps. Use it for a fast read with no confirmation walk.

### Step 1: Gather org data (scan + extract)

1. **Scan** — Glob all `.org` files in the org directory (see [org-format.md](org-format.md))
2. **Extract** — Pull all `TODO` (and `HOLD`) headlines with their `DEADLINE:` and `SCHEDULED:` properties. This full active set is the match target the Step 1b triage classifier needs; the today-only display filter is applied later, in Step 1c. (Do not filter or score yet.)

### Step 1-zoho: Refresh Zoho time + tasks (freshen org from Zoho Books)

**Skip if `--no-triage` or `--no-sync` is set.** Otherwise, before triage and scoring, invoke `/timesheet pull` via the Skill tool — `Skill(skill=timesheet, args="pull")` — so the org files reflect the latest Zoho Books tasks and tracked time (e.g. timers run since yesterday). This is an explicitly-named dispatch, so the Route Consultation gate is satisfied; do NOT freelance Zoho API calls here. The pull is additive (insert-only CLOCK / `:ZOHO_*:` writes per the timesheet sync model) and runs without per-item confirmation — it is NOT a triage write, so the triage confirmation-walk directive does not apply. If `/timesheet` reports nothing new, proceed silently. Any files it wrote must be re-read in Step 1c.

### Step 1a: Gather signals (shared payload, 24h)

Single canonical fetch for the whole run — both Step 1b and Steps 2/2b consume it; do not re-fetch later. Windowed to **24h** (today's reach):

1. **Email — both inboxes (required)** — last 24h from Gmail AND iCloud (per `priorities` Step 1a; immutable "Always query both inboxes" applies). `scripts/email-fetch.sh recent --hours 24 --max 100`.
2. **Quo SMS + calls** — `scripts/quo-fetch.sh messages --since <24h-ago>` and `scripts/quo-fetch.sh calls --since <24h-ago>`; fetch transcripts for urgent/ambiguous call summaries.

`today` supplies this 24h payload to the triage sub-procedure directly (Step 1b), so triage's wider 7-day *standalone* default does not apply here — the caller's window governs.

### Step 1b: Triage update-pass (freshen org files, 24h)

**Skip entirely if `--no-triage` is set.** Otherwise run the **Triage workflow Steps 1-6** ([triage-workflow.md](triage-workflow.md)) as a sub-procedure against the Step 1 active-TODO set and the Step 1a (24h) signal payload:

- The **confirmation walk (triage Step 5) runs verbatim** — no write without per-item approval (immutable directive). **This pauses for user input before the briefing appears.**
- Triage Step 7 (report) is **suppressed**; outcome folds into the briefing.
- **Empty change set → silent no-op:** proceed straight to Step 1c.
- **Today-filter does NOT suppress triage writes:** triage may correctly write a DEADLINE for a future-dated task surfaced by a 24h signal even though that task won't appear in today's filtered chart. The today-only filter (Step 1c) governs only what the *assessment surfaces*, never what the update-pass is allowed to write.

### Step 1c: Re-read, filter to today, score

1. **Re-read (gated)** — IF Step 1b OR Step 1-zoho applied ≥1 write → re-Glob/re-extract the affected `.org` files. IF skipped or zero writes → reuse the Step 1 scan.
2. **Filter to today only** — Include an item only if:
   - Its `DEADLINE:` is overdue (any date before today), OR
   - Its `DEADLINE:` is today, OR
   - Its `SCHEDULED:` is today
3. **Exclude** — Items due later this week, next week, on the horizon, or with no date. Those belong to `priorities` and `cleanup` respectively.

### Step 2: Match email signals (today filter)

Using the Step 1a email payload (do **not** re-fetch), keep only messages that:

- Reference one of the org items surfaced in Step 1c, OR
- Carry a same-day urgency signal: an explicit "today" / "EOD" / "ASAP", a date matching today, or a direct request from a known contact that needs action before end of day

Drop background FYIs, newsletters, anything that doesn't demand action today.

### Step 2b: Match Quo signals (today filter)

Using the Step 1a Quo payload (do **not** re-fetch), keep only SMS and call signals that touch today's items or carry same-day urgency.

Apply the Step 2.5 scan from `priorities` (untracked requests + CC'd updates) against the same payload.

### Step 3: Apply correspondence-driven priority bumps

Same logic as `priorities` Step 3, applied to the today-only set.

### Step 4: Assemble "Awaiting Correspondence" (today filter)

Restricted to outbound items that are urgent enough to nudge today (>= 5 days out with no reply, or explicitly flagged as same-day blocker).

Build **`AwaitingRow` objects, not prose** ([`agenda/src/types.ts`](../../../agenda/src/types.ts)). Step 5.95 renders them; do not hand-write this table.

**Two mandatory checks before an outbound becomes an "awaiting" item** (both were violated on 2026-07-09 with the "Amy" line):
1. **No reply exists** — verified against the **fetched thread**, not the org body note. "Awaiting" means the recipient has NOT answered. If a later inbound reply from the same contact exists, it is NOT awaiting; drop it (or, if the reply hands the ball back to Francis, it's a follow-up TODO for triage). The 2026-07-20 Broom21 row passed the note and failed the thread — the contact had replied.
2. **Date by the real timestamp.** `asked` and `daysOut` come from the message's actual `createdAt`, never an assumed "today." Compute `daysOut` = (briefing date − send date). A text sent yesterday is `daysOut: 1`, not `0`, and the wording must not say "today."

Attribution (`to`/`toSource`) is enforced mechanically in Step 5.95 — no rule to remember here: name the counterparty only from a fetched artifact and record the pointer, or leave `to` null with a `toOrg` label.

### Step 5: Assemble "Clarifications Needed" (today filter)

Restricted to clarifications that unblock a today-only item. Build **`ClarificationRow` objects**, same contract; Step 5.95 renders them.

### Step 5.5: Opportunity scan (SKILL.md § Opportunity-Scan Gate)

After the Step 1b update-pass and before assembling the chart, fire `/opportunity-scout --quick` via the Skill tool (explicitly-named dispatch — do NOT freelance web search). **Guard:** skip the dispatch if `--no-scout` was passed OR the opportunity-scout run-state (`opportunity-index.md` top marker `last-run`) is within ~18h; on a guard-skip, still render the Opportunities section from the existing index. Capture the "new since last run" result. Non-blocking: a scout failure degrades to "Opportunities: unavailable this run."

### Step 5.6: Investment scan (`/invest`)

After the opportunity scan and before assembling the chart, surface the investment
picture. Fundamentals-first cadence: the score watchdog runs daily, the scout refresh
runs weekly (heavy live EDGAR + news calls, so never every day).

1. **Daily watchdog + daily news** — fire `/invest watch` via the Skill tool (explicitly-named
   dispatch, so the Route Consultation gate is satisfied; do NOT freelance Alpaca or
   EDGAR calls). It recomputes each held stock's composite score and returns any
   score-floor breach or red-flag alert (including catastrophe items) — alerts only,
   never a trade. It ALSO runs the daily **News Gather** (invest Directive 9) and
   overwrites `data/news.json` with the day's world/macro + company-rating news, so the
   agenda's Investment news is refreshed **every day**, even when there are no holdings.
2. **Weekly pick refresh** — read `.claude/skills/invest/data/suggestions.json`. IF its
   `week_of` is not the current ISO week OR `picks` is empty → fire `/invest scout` to
   refresh this week's ranked pick. OTHERWISE reuse the stored suggestions (the stable
   weekly pick never reshuffles mid-week).
3. **Guard** — skip both dispatches if `--no-invest` was passed; on a guard-skip, still
   render the Investment section from the existing ledger + suggestions.
4. **Capture** — holdings (from `data/holdings.json`), this week's suggestions, whether
   a buy was made this week, any watchdog alerts, and the day's news from
   `data/news.json` (invest Directive 9 — world/macro + company events affecting
   ratings, refreshed daily by `watch`/weekly by `scout`). Map `news.json` items
   straight into `investment.news[]`; this section is **never empty** — if a news
   gather genuinely returned nothing this run, carry the most recent `news.json` and
   note its date rather than dropping the block. The `/invest` skill NEVER buys here
   (buying requires an explicit `/invest spend`). Non-blocking: a failure degrades to
   "Investment: unavailable this run."
   - **Enrich EVERY suggestion, not just the top pick.** For each pick in
     `suggestions.json`, run `scripts/ma.py <ticker>` and attach `lastClose`, `ma20`,
     `ma200`, `maDistPct`, and `series` (plus `score`/`scoreHistory`) to its
     `investment.suggestions[]` entry — never fabricate, always from `ma.py`. A lean
     suggestion (score/dividend only) renders as "− vs 200-day" and expands to "price
     data unavailable this run" with no chart, so a top-pick-only enrichment leaves 7 of
     8 tickers dead. (Fixed 2026-07-09 — the viewer was correct; the feed was starved.)
   - **News freshness is enforced in the viewer.** `agenda/src/main.ts` drops any
     `investment.news[]` or `aiReleases.releases[]` item older than `FRESH_WINDOW_DAYS`
     (3) relative to `dateISO` — a daily paper carries only recent items. The feed may
     still carry the fuller set (e.g. the AI-releases rolling cache); the render windows
     it. Keep `dateISO` accurate or the window can't compute.

### Step 5.7: AI release watch

After the investment scan, run the AI release-watch gather per
[ai-releases.md](ai-releases.md): check the six fixed vendor feeds (Anthropic platform
release notes, Claude Code releases, OpenAI release channels — changelog + product/news +
Help Center model release notes, xAI release notes, DeepSeek news, Qwen research — per-feed
fetch mechanics in the reference), **dedup against the
seen-index** (an already-surfaced entry never resurfaces as new), fold genuinely-new
entries into the browser view's `aiReleases.releases` rail — each citing a link to its
release page — and set `aiReleases.announcement` ONLY for a fresh (≤48h since first seen)
MAJOR **Anthropic** announcement (a new model launch or a major new tool/capability),
which renders as the full-width bulletin above Morning summary. When anything new landed
since the last run, add the one-line `🆕 AI releases: …` mention to the terminal briefing
(new items only). **Guard:** skip with `--no-ai-releases`; on a guard-skip, still carry
the cached `releases` from the state file. Non-blocking: a feed failure degrades to that
vendor's cached entries with a one-line note.

### Step 5.8: Appointments & calendar (Google Calendar)

After the AI release watch and before assembling the chart, gather the day's calendar so
the browser view's **Schedule** band (month calendar + Appointments panel) can render.

1. **Fetch** — fire `/google-calendar agenda --days 50 --max 100` via the Skill tool
   (explicitly-named dispatch — the Route Consultation gate is satisfied; do NOT freelance
   Calendar API calls). The wide window (current month through the end of next month) is
   deliberate: the month grid's forward navigation needs next-month events, not just the
   next 14 days. READ mode only — never writes an event here.
2. **Map** each returned event into `calendar.appointments[]` per the html-render contract:
   `date` (ISO start day), `title` (summary), `time`/`endTime` (display strings; omit +
   set `allDay: true` for all-day events), `location`, and `url` (the event `htmlLink`).
   Do NOT copy TODOs here — the viewer overlays task deadlines from `clients[]` itself.
3. **Guard** — skip the dispatch if `--no-calendar` was passed OR no Google Calendar
   credentials are configured (the `/google-calendar check` / setup path errors); on a skip,
   **omit the `calendar` field entirely** so the Schedule section stays hidden. Non-blocking:
   a Calendar failure degrades to "Schedule: unavailable this run" and the briefing proceeds.

### Step 5.9: Top stories (NYT + FT)

After the calendar fetch and before assembling the chart, gather the day's top general
news for the browser view's **Top Stories** rail.

1. **Fetch** — pull the current top headlines from **The New York Times** and the
   **Financial Times** via their **public RSS feeds** (the headline + article link are free
   even though the full article is paywalled — no login needed, unlike the `/invest` FT
   full-text path). Retrieve each feed with `web_fetch` (playwright-mcp) or `curl`, then
   parse `<item>` `title` / `link` / `pubDate`:
   - NYT: `https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml` (Top Stories).
   - FT: `https://www.ft.com/rss/home` (Home/World).
   This is an explicitly-named fetch — the Route Consultation gate is satisfied; do NOT
   route it to a web-search skill.
2. **Map** the top ~4–6 per outlet (today's items only) into `topStories[]` per the
   html-render contract: `{ headline, source ("NYT" / "Financial Times"), date (ISO from
   `pubDate`), url (the article `link`), section? }`. Never invent a headline or link —
   only real feed entries.
3. **Guard** — skip the fetch if `--no-topstories` was passed; on a skip or a feed failure,
   **omit the `topStories` field** so the rail stays hidden. Non-blocking: a fetch failure
   degrades to "Top stories: unavailable this run" and the briefing proceeds.

### Step 5.10: Research Radar (`/research` content-idea scan)

After the top-stories fetch and before the attribution block, gather content-idea
candidates for the two focus categories so the browser view's **Research Radar** section
can render. This is a decision aid for NotebookLM triage, NOT a drafting step (immutable
directive "Research Radar in the today newspaper").

1. **Gather (two categories).** For **AI Transformation**, fire `/research transformation`
   via the Skill tool; for **Field Notes**, fire `/research fieldnotes`. Both are
   explicitly-named dispatches, so the Route Consultation gate is satisfied; do NOT
   freelance web search or Jina calls here. Scope each run to *surfacing candidate topics*,
   not drafting: ask for the most relevant / newsworthy angles, each with a
   one-to-two-sentence why-it-matters line and the fully-read source citations that make it
   stand out. `/research` owns its own read-before-cite and source-alignment gates; take
   only what it returns (no snippet-only sources).
2. **Map** each returned finding into `research.categories[]` per the html-render contract
   ([`agenda/src/types.ts`](../../../../agenda/src/types.ts)): one `ResearchCategory` per key
   (`ai-transformation`, `field-notes`) with its `label`, and one `ResearchTopic` per
   candidate carrying `topic`, `whyItMatters`, and `citations[]` (`title`, `url`, optional
   `source`, `date`). Every citation URL must be one `/research` actually read end-to-end;
   never fabricate a topic or a link.
3. **Guard.** Skip both dispatches if `--no-research` was passed; on a skip or a `/research`
   failure, **omit the `research` field entirely** so the section stays hidden. Non-blocking:
   a failure degrades to "Research Radar: unavailable this run" and the briefing proceeds.
   This rail never drafts or publishes; article creation stays with `/focus`.

### Step 5.95: Render the attribution block (single choke point)

The Awaiting + Clarifications sections are the only two that assert a **person's identity as something to act on**, and both outlets — the terminal briefing and the browser view — must descend from one validated object so they cannot disagree. Write the Step 4/5 rows to a scratch JSON file and render them:

```bash
python3 .claude/skills/agenda/scripts/attribution.py <rows.json>
```

Input: `{"dateISO": "...", "awaiting": [AwaitingRow], "clarifications": [ClarificationRow]}`. **stdout** is the two finished markdown tables — paste them into Step 6 verbatim; do not re-type or "improve" them. **stderr** lists any dropped row and why. Exit `0` clean, `1` rows dropped, `2` file missing, `3` unparseable.

The script drops any row naming a person without a **resolvable** pointer. An org pointer (`broom21.org:27`) is opened and read — the name must actually appear within ±4 lines. Other artifact forms (`quo:+1…`, `gmail:<id>`, `icloud:<id>`, `slack:…`) are shape-checked only, since those aren't on disk. A null name is legitimate and renders as `Broom21 — unnamed contact`. This is deliberately a resolver, not a presence check: the 2026-07-20 fabrication would have sailed through a presence check, because the pass that invents a name also invents a plausible `file:line` beside it.

**On exit 1, do not silently proceed.** Either supply a real pointer or re-emit the row with `to: null` plus a `toOrg` label, then re-run. Losing a pending item is a worse failure than an unnamed one — degrade, never drop. Run it again after any correction so what you paste matches what Step 7 ships.

Only these two sections are generated. The synopsis, the client chart, and every rail stay hand-written — this is scoped to the fields that name people.

### Step 6: Synthesize and present

Same chart-first contract as `priorities`. See [output-formats.md](output-formats.md) § "Today Variant" for the paragraph and table sizing. **The Awaiting Correspondence and Clarifications Needed tables are pasted verbatim from Step 5.95's stdout** — hand-authoring either one is the 2026-07-20 defect. If nothing is due and the inbox is quiet, the synopsis is one sentence and the tables each show their empty placeholder — including the **Opportunities** section, which shows "None new at the moment." when the scout surfaced nothing.

### Step 7: Feed the browser view (additive)

After the terminal briefing above is emitted and its gates have passed, also write the SAME briefing as data for the local browser view and print a clickable link, so it can be read outside the cluttered terminal. Follow [html-render.md](html-render.md): build the `window.AGENDA_DATA` object from the already-assembled briefing (no re-scan, re-fetch, or re-score). **`awaiting[]` and `clarifications[]` are copied from the Step 5.95 rows that survived validation** (`attribution.py --json` emits exactly that set) — never re-derived here, or the two outlets can drift apart again per the data contract in [`agenda/src/types.ts`](../../../../agenda/src/types.ts), write it to `<repo-root>/agenda/publish/data/today.js`, and append one `📄 Browser view: file://…/agenda/publish/index.html` line as the last output. The viewer (`agenda/`, a committed Tailwind + TS app) renders the feed; the page opens from a `file://` link with no server.

Include the `investment` field (Step 5.6 output) in the object per the html-render contract: holdings, this week's suggestions, budget, `boughtThisWeek`, and backing news. Omit the field entirely when `/invest` produced nothing, so the Investment section stays hidden.

Include the `aiReleases` field (Step 5.7 output) per the same contract: `releases` (the multi-vendor rail list, newest first) and `announcement` (only when a fresh major Anthropic announcement qualifies). Omit the field when the watch was skipped AND no cached releases exist.

Include the `calendar` field (Step 5.8 output) per the same contract: `appointments[]` mapped from `/google-calendar agenda`. Omit the field when Calendar was skipped/unconfigured or returned nothing, so the Schedule section stays hidden.

Include the `topStories` field (Step 5.9 output) per the same contract: `TopStory[]` mapped from the NYT + FT RSS feeds. Omit the field when the gather was skipped (`--no-topstories`) or failed, so the Top Stories rail stays hidden.

Include the `research` field (Step 5.10 output) per the same contract: `ResearchRadar` with `categories[]` for AI Transformation and Field Notes, each topic carrying `whyItMatters` + `citations[]`. Omit the field when the gather was skipped (`--no-research`) or failed, so the Research Radar section stays hidden.

This step is **additive and non-blocking**: the terminal briefing is primary and unchanged; a write failure degrades to a one-line "Browser view unavailable this run" note. Skip it (with a one-line mention) when `--no-html` was passed or no briefing was produced.
