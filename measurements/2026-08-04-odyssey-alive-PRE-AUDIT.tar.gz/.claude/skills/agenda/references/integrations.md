# Agenda — REST Integrations
<!-- Enforcement: LOW — config/grounding reference -->

## Email REST Integration

The `/agenda triage` workflow connects to Gmail and iCloud directly via IMAP — no MCP, no `/email` chain at runtime. All script logic lives in `scripts/email-fetch.sh`.

### Required env (in `.env.local` at repo root)

| Var | Purpose |
|-----|---------|
| `GMAIL_EMAIL` / `GMAIL_APP_PASSWORD` | Gmail IMAP auth (app-specific password from Google account settings) |
| `ICLOUD_EMAIL` / `ICLOUD_APP_PASSWORD` | iCloud IMAP auth (app-specific password from Apple ID settings) |

These vars are shared with the standalone `/email` skill — both skills read the same `.env.local`.

### Subcommands

| Subcommand | Output |
|------------|--------|
| `email-fetch.sh recent --since <ISO8601> [--max <n>]` | JSON array of messages from both inboxes since the given timestamp |
| `email-fetch.sh recent --hours <N> [--max <n>]` | Same, but window expressed in hours from now |

### Output shape (one object per message)

```json
{
  "id":        "gmail:<uid>" | "icloud:<uid>",
  "account":   "gmail" | "icloud",
  "from":      "sender@example.com",
  "from_name": "Sender Name" | null,
  "to":        ["recipient@example.com", ...],
  "cc":        [...],
  "subject":   "...",
  "snippet":   "first ~600 chars of plaintext body",
  "date":      "2026-05-06T09:14:00-07:00",
  "is_direct": true | false
}
```

`is_direct` is `true` if the user's address appears in `To:`. Used by the classifier to weight direct messages over CC'd ones.

### Implementation notes

- Both inboxes use `IMAP4_SSL` on port 993
- The fetch spec is **`BODY.PEEK[]`** (not `RFC822`) — iCloud's IMAP server returns empty `()` for `RFC822` but works correctly with `BODY[]`/`BODY.PEEK[]`. PEEK avoids marking messages as `\Seen`.
- Messages are sorted by `date` descending (most recent first) before output
- Body extraction prefers `text/plain` over `text/html`; HTML is stripped of tags and collapsed to whitespace if it's the only available body
- Per-message parse errors are logged to stderr (`WARN: ...`) and the message is skipped — partial output is preferred over total failure

---

## Quo REST Integration

The `/agenda` skill connects to Quo (formerly OpenPhone) directly via REST — no MCP dependency. All script logic lives in `scripts/quo-fetch.sh`.

### Required env (in `.env.local` at repo root)

| Var | Purpose |
|-----|---------|
| `QUO_API_KEY` | API key from Quo workspace settings (Owner/Admin) |
| `QUO_INBOX_IDS` | Optional. Comma-separated phone-number IDs to scan. Sentinel `0` (or unset) = all inboxes |

### Subcommands

| Subcommand | Output |
|------------|--------|
| `quo-fetch.sh check` | Probes auth mode (plain key vs `Bearer` prefix), caches result to `.quo-auth-mode` |
| `quo-fetch.sh inboxes` | JSON array of phone numbers (id, number, name) |
| `quo-fetch.sh messages --since <ISO8601>` | JSON array of messages across allow-listed inboxes |
| `quo-fetch.sh calls --since <ISO8601>` | JSON array of calls across allow-listed inboxes |
| `quo-fetch.sh transcript <call-id>` | Transcript JSON for a single call |
| `quo-fetch.sh summary <call-id>` | Summary JSON for a single call |

Pagination is handled inside the script via `nextPageToken` looping.

### Shared with /quo

This script is shared, not duplicated. The `/quo` skill is the **contact-first front-end** over the same `scripts/quo-fetch.sh`: it resolves a person by name (via the Quo MCP `list-contacts`/`get-contact` tools, which this script does not provide) and then calls these same subcommands for bulk retrieval. `/agenda triage` keeps calling the script directly for its batch, all-inbox, `--since` scan keyed to `account-index.org` (number → project slug). Triage is **not** routed through `/quo`. Keep the script in place — both consumers reference it by path.

---

## Slack REST Integration

The `/agenda triage` workflow reads Slack via the `/slack` skill's script — shared, not duplicated (the quo-fetch.sh precedent). All script logic lives in `.claude/skills/slack/scripts/slack-fetch.sh`.

### Required env (in `.env.local` at repo root)

| Var | Purpose |
|-----|---------|
| `SLACK_TOKEN_<label>` | One Slack **user** OAuth token (`xoxp-…`) per workspace account; any number of accounts. Labels are lowercased (`SLACK_TOKEN_ODYSSEY` → account `odyssey`) |
| `SLACK_USER_TOKEN` | Legacy single-account form; maps to account `default` |

**No token configured = source skipped silently.** Triage never blocks or nags over Slack absence. Setup walkthrough: `/slack` skill `reference.md` § Setup.

### Subcommand triage uses

| Subcommand | Output |
|------------|--------|
| `slack-fetch.sh review --since <ISO8601>` | `{window_since, channels_scanned, mentions[], dms[]}` — mentions of the authed user across member channels + all DM/group-DM activity, every account, names resolved |

Each message: `{account, channel, channel_type, from, ts_iso, text}`.

### Shared with /slack

`/slack` is the interactive front-end (review digest, one-conversation history, search) over the same script. `/agenda triage` keeps calling the script directly for its batch `--since` sweep — triage is **not** routed through `/slack`, and `/slack review` remains read-only human-facing surfacing while triage stays the only writer (the same read-vs-write boundary as `/quo review` vs triage).

---

## Account-Routing Index

Path: `references/account-index.org`

Maps emails and phone numbers to project org files so triage can route incoming signals. Each top-level `* <slug>` heading is a project; the slug must match an `.org` filename (without the extension).

### Schema

```org
* slug-name
  :PROPERTIES:
  :EMAILS:    addr1@example.com, addr2@example.com
  :PHONES:    +1-503-555-0100, 503-555-0200
  :ALIASES:   "Display Name", "Initials"
  :KIND:      work | congregational
  :END:
```

- `:EMAILS:` and `:PHONES:` are comma-separated. Phones are stored in any human-readable format; lookup digit-normalizes both sides before comparison.
- `:KIND:` is used by the unknown-contact prompt to suggest a default (work or congregational) when proposing the contact for addition.
- The index file is freely editable by the skill (the write-guard hook excludes it). Manual edits with any text editor also work.

### Helper functions (sourced from `scripts/index-lib.sh`)

| Function | Purpose |
|----------|---------|
| `index_lookup_email <email>` | Print matching project slug(s), one per line (empty if none) |
| `index_lookup_phone <phone>` | Print matching project slug(s), one per line, digit-normalized (empty if none) |
| `index_list_projects` | Print all project slugs, one per line |
| `index_get_property <slug> <name>` | Print a property value |
| `index_add_email <slug> <email>` | Idempotent append |
| `index_add_phone <slug> <phone>` | Idempotent append |

### Seeding congo from PDF

`scripts/seed-congo-from-pdf.sh` runs `pdftotext -layout` on the latest `Person Contact Information All Groups - Everyone*.pdf` in `~/Documents/win10/`, extracts every email and phone from the text, and merges them into the `* congo` block. Idempotent — re-running adds new contacts without duplicating.

---

*Split from agenda/reference.md by skill-builder. Enforcement boundary: grounding.*
