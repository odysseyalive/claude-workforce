# Agenda — Org File Format
<!-- Enforcement: MEDIUM — grounding check in SKILL.md -->

## Source Resolution

The org directory is **not hardcoded** — resolve it from `.env.local` before any read or write. Two keys drive it (the immutable directive in SKILL.md § Directives is the contract):

- **`ORG_DIR`** — absolute path to this host's org directory. Defaults to the local Insync path below when unset.
- **`AGENDA_SOURCE`** — who keeps `ORG_DIR` fresh:

| `AGENDA_SOURCE` | Meaning | What the gate does |
|---|---|---|
| `local` (or unset) | An external syncer (Insync, or a continuous `rclone`) keeps `ORG_DIR` fresh. | Use `ORG_DIR` directly — no sync call. |
| `server` | This host **owns** the sync. | Run the **Server sync bracket** below (pull → gated-delete → read → … → push → gated-delete). A failed pull → **STOP** (never read stale data). |
| anything else | Unrecognized. | **STOP** — report `AGENDA_SOURCE` is not `local` or `server`. |

### Server sync bracket (`AGENDA_SOURCE=server`)

Fires **once per run, owned by the entry skill** (a chained `/timesheet` must not re-run it). `org-sync.sh` lives at the project root beside `zoho-token.sh`. The copy is additive and never deletes on its own; **whole-directory** (`.git` included, so git rollback works on the server); **deletions are always gated behind a user confirmation**.

1. **Pull** (before the first read): `bash scripts/org-sync.sh pull` — additive `copy --update` of the whole org dir from Drive. Pull failure → **STOP**.
2. **Gated delete, incoming**: `bash scripts/org-sync.sh deletions`. For each `DRIVE_DELETED <file>` line (an org file present here but removed from Drive), **ask the user** (AskUserQuestion) before removing it; on approval run `bash scripts/org-sync.sh delete-local <file>`. Do this **before reading** so retired files aren't processed. No `DRIVE_DELETED` lines → nothing to ask.
3. **Read / triage / write** against `ORG_DIR` as normal.
4. **Push** (end, only if ≥1 org write happened): `bash scripts/org-sync.sh push` — additive copy back to Drive.
5. **Gated delete, outgoing**: `bash scripts/org-sync.sh deletions`. For each `LOCAL_DELETED <file>` (an org file on Drive but removed here), **ask** before running `bash scripts/org-sync.sh delete-remote <file>` (goes to Drive trash, recoverable).

Deletion scope is `*.org` / `*.org_archive` only — `.git` and other files sync additively and are never offered for deletion. The script only detects and executes; the okay-to-delete decision is **always** a user confirmation.

**Default local path** (the `ORG_DIR` fallback):

```
/home/francis/Insync/fmeetze@gmail.com/Google Drive/gdrive/org/
```

Each `.org` file corresponds to a project or client. The filename (minus `.org`) is the project identifier.

---

## TODO Keywords

Org-mode keywords used in these files:

| Keyword | Meaning |
|---------|---------|
| `TODO` | Active task |
| `HOLD` | Paused / blocked task — not actionable until something changes |
| `DONE` | Completed task |

Headlines follow the pattern: `*+ KEYWORD headline text [optional <date>]`

### HOLD format

When marking a task HOLD, the reason goes on the line directly below the headline as an org list item:

```
** HOLD Caffelli PR Reviews <2026-04-20 Mon>
   - HOLD: blocked on vendor response — re-evaluate 2026-05-15
   :LOGBOOK:
   ...
```

The reason is plain text. No DEADLINE is required on a HOLD item (and `agenda` does not propose one). When a HOLD task becomes actionable again, swap the keyword back to TODO; the reason line is preserved as historical context (the user can clean it up manually if desired).

HOLD items are **excluded** from `priorities`, `today`, and `cleanup` (those workflows only scan for `TODO` headlines), so a HOLD task won't surface as urgent or get marked DONE by Phase 1 of cleanup.

---

## Date Patterns

### Inline date (on the headline itself)
```
** TODO Some task <2026-04-03 Fri>
```
Pattern: `<\d{4}-\d{2}-\d{2}[^>]*>`

### DEADLINE (on the line after the headline)
```
** TODO Some task
   DEADLINE: <2026-04-03 Fri>
```

### SCHEDULED (on the line after the headline)
```
** TODO Some task
   SCHEDULED: <2026-04-03 Fri>
```

A TODO is considered **without a due date** if it has no `DEADLINE:` on the immediately following line. Inline timestamps like `<2026-04-03 Fri>` are creation/context dates, NOT due dates. Only the `DEADLINE:` property counts as a due date for cleanup purposes.

---

## Fuzzy File Matching

For the `review` mode, match user input to org filenames:

| Input | Matches |
|-------|---------|
| `tt` | `tickettomato.org` |
| `oa` | `odysseyalive.org` |
| `dm` | `dynamicmotorsports.org` |
| `dc` | `destinationcabo.org` |

Match strategy: substring match first, then initials. If ambiguous, present options and ask.

---

## Archive Format

Archive files use the standard org-mode archive convention:

- **Archive file:** `projectname.org_archive` (same directory as the source `.org` file)
- **Subtree extraction:** The full subtree from the headline through all child content until the next sibling or higher-level heading
- **Append, don't overwrite:** Always append to the archive file (create if it doesn't exist)
- **Age threshold:** 6 months from today's date. A DONE item is "old" if its most recent date (inline, DEADLINE, or SCHEDULED) is before the threshold.
- **Removal order:** When removing multiple subtrees from a single file, process in reverse line order (highest line number first) to preserve line numbers for earlier removals.

### Subtree boundary detection

A subtree starting at `** DONE some task` on line N ends at the line before:
- The next heading at depth `**` or `*` (same level or higher), OR
- End of file

Everything between (inclusive of line N) is the subtree.

---

*Split from agenda/reference.md by skill-builder. Enforcement boundary: grounding.*
