#!/usr/bin/env bash
# One-shot (and idempotent on re-run) seed of the * congo block in
# account-index.org from the Tillamook congregation contact PDF.
#
# Usage:
#   seed-congo-from-pdf.sh [--clean-self] [path-to-pdf]
#
# Default PDF path: latest "Person Contact Information All Groups - Everyone*.pdf"
# in ~/Documents/win10/.
#
# Flags:
#   --clean-self   Before seeding, sweep the * congo block and remove any
#                  emails matching GMAIL_EMAIL/ICLOUD_EMAIL/CONTACT_EMAIL
#                  /AGENDA_SELF_EMAILS, and any phones matching
#                  AGENDA_SELF_PHONES. Useful after adding new self
#                  identifiers to .env.local.
#
# Behavior:
#   1. (Optional) Clean self entries from the existing congo block
#   2. pdftotext -layout the PDF to a temp file
#   3. Extract every email and phone from the text
#   4. Normalize, dedupe, and exclude self identifiers
#   5. Merge into the :EMAILS: and :PHONES: properties of the * congo block
#      via index-lib.sh (idempotent — never duplicates)
#   6. Delete the temp file
#   7. Report counts

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/index-lib.sh"

# Load self-identity from .env.local so we don't seed Francis's own contacts
# into a project block. Auto-pulls GMAIL_EMAIL, ICLOUD_EMAIL, CONTACT_EMAIL.
# Extra self-identifiers go in AGENDA_SELF_EMAILS / AGENDA_SELF_PHONES
# (comma-separated).
load_self_identity() {
  local env_file=""
  for candidate in \
    "$PWD/.env.local" \
    "$(git -C "$PWD" rev-parse --show-toplevel 2>/dev/null)/.env.local" \
    "$HOME/lab/odyssey-alive/.env.local"
  do
    [[ -n "$candidate" && -f "$candidate" ]] && { env_file="$candidate"; break; }
  done
  if [[ -n "$env_file" ]]; then
    # shellcheck disable=SC1090
    set -a; source "$env_file"; set +a
  fi
}
load_self_identity

# Build self-email list (lowercased), tab-separated
SELF_EMAILS=""
for var in GMAIL_EMAIL ICLOUD_EMAIL CONTACT_EMAIL; do
  v="${!var:-}"
  [[ -n "$v" ]] && SELF_EMAILS+="$(printf '%s' "$v" | tr '[:upper:]' '[:lower:]')"$'\t'
done
if [[ -n "${AGENDA_SELF_EMAILS:-}" ]]; then
  while IFS= read -r e; do
    e="$(printf '%s' "$e" | tr '[:upper:]' '[:lower:]' | tr -d '[:space:]')"
    [[ -n "$e" ]] && SELF_EMAILS+="$e"$'\t'
  done <<< "${AGENDA_SELF_EMAILS//,/$'\n'}"
fi

# Build self-phone list (digit-normalized), tab-separated
SELF_PHONES=""
if [[ -n "${AGENDA_SELF_PHONES:-}" ]]; then
  while IFS= read -r p; do
    p="$(printf '%s' "$p" | tr -cd '0-9')"
    [[ -n "$p" ]] && SELF_PHONES+="$p"$'\t'
  done <<< "${AGENDA_SELF_PHONES//,/$'\n'}"
fi

is_self_email() {
  local needle; needle="$(printf '%s' "$1" | tr '[:upper:]' '[:lower:]')"
  [[ "$SELF_EMAILS" == *"${needle}"$'\t'* ]]
}

is_self_phone() {
  local needle; needle="$(printf '%s' "$1" | tr -cd '0-9')"
  [[ -z "$needle" ]] && return 1
  # Match by trailing digits (handles +1 vs 10-digit difference)
  while IFS= read -r self; do
    [[ -z "$self" ]] && continue
    if [[ "$self" == *"$needle" || "$needle" == *"$self" ]]; then
      return 0
    fi
  done <<< "$(printf '%s' "$SELF_PHONES" | tr '\t' '\n')"
  return 1
}

CLEAN_SELF=0
PDF_PATH=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --clean-self) CLEAN_SELF=1; shift ;;
    -h|--help)
      grep -E '^# ' "$0" | sed 's/^# //; s/^#$//'
      exit 0 ;;
    -*)
      echo "ERROR: unknown flag: $1" >&2; exit 2 ;;
    *)
      [[ -n "$PDF_PATH" ]] && { echo "ERROR: extra positional arg: $1" >&2; exit 2; }
      PDF_PATH="$1"; shift ;;
  esac
done

if (( CLEAN_SELF )); then
  removed_emails=0
  removed_phones=0

  for var in GMAIL_EMAIL ICLOUD_EMAIL CONTACT_EMAIL; do
    v="${!var:-}"
    [[ -z "$v" ]] && continue
    before="$(index_get_property congo EMAILS)"
    index_remove_email congo "$v"
    after="$(index_get_property congo EMAILS)"
    [[ "$before" != "$after" ]] && removed_emails=$((removed_emails + 1))
  done

  if [[ -n "${AGENDA_SELF_EMAILS:-}" ]]; then
    while IFS= read -r e; do
      e="$(printf '%s' "$e" | tr -d '[:space:]')"
      [[ -z "$e" ]] && continue
      before="$(index_get_property congo EMAILS)"
      index_remove_email congo "$e"
      after="$(index_get_property congo EMAILS)"
      [[ "$before" != "$after" ]] && removed_emails=$((removed_emails + 1))
    done <<< "${AGENDA_SELF_EMAILS//,/$'\n'}"
  fi

  if [[ -n "${AGENDA_SELF_PHONES:-}" ]]; then
    while IFS= read -r p; do
      p="$(printf '%s' "$p" | tr -cd '0-9')"
      [[ -z "$p" ]] && continue
      before="$(index_get_property congo PHONES)"
      index_remove_phone congo "$p"
      after="$(index_get_property congo PHONES)"
      [[ "$before" != "$after" ]] && removed_phones=$((removed_phones + 1))
    done <<< "${AGENDA_SELF_PHONES//,/$'\n'}"
  fi

  echo "Cleanup: $removed_emails emails removed, $removed_phones phones removed"
fi

if [[ -z "$PDF_PATH" ]]; then
  # Match any "<prefix> Person Contact Information All Groups - Everyone.pdf"
  # — the prefix is usually a month/year ("May 2026 ..."), but accept anything.
  PDF_PATH="$(find "$HOME/Documents/win10" -maxdepth 1 -type f \
                -iname "*Person*Contact*Information*All*Groups*Everyone*.pdf" \
                -printf '%T@ %p\n' 2>/dev/null \
              | sort -rn | head -1 | cut -d' ' -f2- || true)"
fi

if [[ -z "$PDF_PATH" || ! -f "$PDF_PATH" ]]; then
  echo "ERROR: contact PDF not found. Pass a path or place it at:" >&2
  echo "  ~/Documents/win10/<prefix> Person Contact Information All Groups - Everyone.pdf" >&2
  exit 2
fi

if ! command -v pdftotext >/dev/null 2>&1; then
  echo "ERROR: pdftotext not installed (poppler-utils)" >&2
  exit 2
fi

TMP_TXT="$(mktemp -t agenda-seed-congo.XXXXXX.txt)"
trap 'rm -f "$TMP_TXT"' EXIT

pdftotext -layout "$PDF_PATH" "$TMP_TXT"

# Extract emails (case-insensitive, normalized to lowercase)
mapfile -t EMAILS < <(
  grep -oE '[A-Za-z0-9._+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}' "$TMP_TXT" \
    | tr '[:upper:]' '[:lower:]' \
    | sort -u
)

# Extract phones — match common formats:
#   503-403-9491
#   (503) 377-2270
#   458-246-1910
#   503.812.8985
# Skip obvious malformed entries (fewer than 7 digits after normalization).
mapfile -t PHONES < <(
  grep -oE '\(?[0-9]{3}\)?[ .-]?[0-9]{3}[ .-]?[0-9]{4}' "$TMP_TXT" \
    | python3 -c '
import sys, re
seen = set()
for line in sys.stdin:
    digits = re.sub(r"\D", "", line)
    if len(digits) < 10:
        continue
    if digits in seen:
        continue
    seen.add(digits)
    # Format as 503-403-9491
    print(f"{digits[-10:-7]}-{digits[-7:-4]}-{digits[-4:]}")
'
)

added_emails=0
skipped_emails=0
self_emails=0
for e in "${EMAILS[@]}"; do
  if is_self_email "$e"; then
    self_emails=$((self_emails + 1))
    continue
  fi
  before="$(index_get_property congo EMAILS)"
  index_add_email congo "$e"
  after="$(index_get_property congo EMAILS)"
  if [[ "$before" == "$after" ]]; then
    skipped_emails=$((skipped_emails + 1))
  else
    added_emails=$((added_emails + 1))
  fi
done

added_phones=0
skipped_phones=0
self_phones=0
for p in "${PHONES[@]}"; do
  if is_self_phone "$p"; then
    self_phones=$((self_phones + 1))
    continue
  fi
  before="$(index_get_property congo PHONES)"
  index_add_phone congo "$p"
  after="$(index_get_property congo PHONES)"
  if [[ "$before" == "$after" ]]; then
    skipped_phones=$((skipped_phones + 1))
  else
    added_phones=$((added_phones + 1))
  fi
done

echo "Seeded congo from: $PDF_PATH"
echo "  emails:  $added_emails added, $skipped_emails already present, $self_emails self-excluded"
echo "  phones:  $added_phones added, $skipped_phones already present, $self_phones self-excluded"
echo "Index:    $(index_path)"
