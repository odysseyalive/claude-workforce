#!/usr/bin/env bash
# Email REST/IMAP integration for the /agenda skill.
# Self-contained: reads GMAIL_* and ICLOUD_* credentials from .env.local.
# Pulls last-N messages from both inboxes, returns JSON array of signals.
#
# Usage:
#   email-fetch.sh recent --since <ISO8601> [--max <n>]
#   email-fetch.sh recent --hours <N> [--max <n>]
#   email-fetch.sh get --id <account:uid>          # full body of one message
#
# `recent` returns a ~600-char snippet per message (a triage overview). When a
# message is a meeting recap / action list / forwarded multi-topic thread, that
# snippet truncates everything past the first item — use `get --id <account:uid>`
# (the id echoed by `recent`) to pull the COMPLETE body. HTML-only emails (e.g.
# Zoom meeting-summary mails, whose text/plain part is empty) are tag-stripped to
# readable text so the full "Next steps" / action list survives.
#
# Env (loaded from .env.local in repo root):
#   GMAIL_EMAIL, GMAIL_APP_PASSWORD     — Gmail (IMAP at imap.gmail.com:993)
#   ICLOUD_EMAIL, ICLOUD_APP_PASSWORD   — iCloud (IMAP at imap.mail.me.com:993)
#
# Output: single JSON array, one object per message:
# {
#   "id":          "gmail:<uid>" | "icloud:<uid>",
#   "account":     "gmail" | "icloud",
#   "from":        "sender@example.com",
#   "from_name":   "Sender Name" | null,
#   "to":          ["recipient@example.com", ...],
#   "cc":          [...],
#   "subject":     "...",
#   "snippet":     "first ~600 chars of plaintext body",
#   "date":        "ISO 8601",
#   "is_direct":   true | false   (user's email in To: or as primary recipient),
#   "link":        Gmail web permalink (search:rfc822msgid) | null   (null for iCloud — no web URL)
# }

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

load_env() {
  local env_file=""
  for candidate in \
    "$PWD/.env.local" \
    "$(git -C "$PWD" rev-parse --show-toplevel 2>/dev/null)/.env.local" \
    "$HOME/lab/odyssey-alive/.env.local"
  do
    [[ -n "$candidate" && -f "$candidate" ]] && { env_file="$candidate"; break; }
  done
  if [[ -z "$env_file" ]]; then
    echo "ERROR: .env.local not found" >&2; exit 2
  fi
  # shellcheck disable=SC1090
  set -a; source "$env_file"; set +a
}

cmd_recent() {
  local since="" hours="" max=50
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --since) since="$2"; shift 2 ;;
      --hours) hours="$2"; shift 2 ;;
      --max)   max="$2"; shift 2 ;;
      *) echo "ERROR: unknown arg: $1" >&2; exit 2 ;;
    esac
  done

  load_env

  # Compute SINCE in IMAP format (DD-Mon-YYYY)
  local since_imap
  if [[ -n "$since" ]]; then
    since_imap="$(date -d "$since" +"%d-%b-%Y" 2>/dev/null || true)"
  elif [[ -n "$hours" ]]; then
    since_imap="$(date -d "$hours hours ago" +"%d-%b-%Y" 2>/dev/null || true)"
  else
    since_imap="$(date -d "1 day ago" +"%d-%b-%Y")"
  fi
  if [[ -z "$since_imap" ]]; then
    echo "ERROR: could not compute SINCE date" >&2; exit 2
  fi

  for missing in \
    "${GMAIL_EMAIL:+x}gmail-email" \
    "${GMAIL_APP_PASSWORD:+x}gmail-pass" \
    "${ICLOUD_EMAIL:+x}icloud-email" \
    "${ICLOUD_APP_PASSWORD:+x}icloud-pass"
  do
    if [[ "${missing:0:1}" != "x" ]]; then
      echo "ERROR: required env var missing: $missing" >&2; exit 2
    fi
  done

  python3 - "$since_imap" "$max" <<'PYEOF'
import imaplib, email, json, os, sys, re
from email.header import decode_header
from email.utils import parsedate_to_datetime, getaddresses
from urllib.parse import quote

since_imap = sys.argv[1]
max_msgs = int(sys.argv[2])

ACCOUNTS = [
    {"name": "gmail",  "host": "imap.gmail.com",     "user_var": "GMAIL_EMAIL",  "pass_var": "GMAIL_APP_PASSWORD"},
    {"name": "icloud", "host": "imap.mail.me.com",   "user_var": "ICLOUD_EMAIL", "pass_var": "ICLOUD_APP_PASSWORD"},
]

def decode_str(s):
    if s is None:
        return ""
    if isinstance(s, bytes):
        try: return s.decode("utf-8", errors="replace")
        except Exception: return s.decode("latin-1", errors="replace")
    if not isinstance(s, str):
        # Defensive: some IMAP servers / message parsers return ints or tuples
        return str(s)
    try:
        parts = decode_header(s)
    except Exception:
        return s
    out = []
    for chunk, enc in parts:
        if isinstance(chunk, bytes):
            try: out.append(chunk.decode(enc or "utf-8", errors="replace"))
            except Exception:
                try: out.append(chunk.decode("latin-1", errors="replace"))
                except Exception: out.append("")
        elif isinstance(chunk, str):
            out.append(chunk)
        else:
            out.append(str(chunk))
    return "".join(out)

def extract_text(msg):
    """Extract a plain-text snippet, preferring text/plain over text/html."""
    if msg.is_multipart():
        plain = None
        html = None
        for part in msg.walk():
            ct = part.get_content_type()
            if ct == "text/plain" and plain is None:
                try: plain = part.get_payload(decode=True).decode(part.get_content_charset() or "utf-8", errors="replace")
                except Exception: pass
            elif ct == "text/html" and html is None:
                try: html = part.get_payload(decode=True).decode(part.get_content_charset() or "utf-8", errors="replace")
                except Exception: pass
        text = plain or html or ""
    else:
        try: text = msg.get_payload(decode=True).decode(msg.get_content_charset() or "utf-8", errors="replace")
        except Exception: text = msg.get_payload() or ""
    if "<" in text and ">" in text:
        text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:600]

def fetch_account(acct):
    user = os.environ[acct["user_var"]]
    pw   = os.environ[acct["pass_var"]]
    results = []
    try:
        m = imaplib.IMAP4_SSL(acct["host"], 993)
        m.login(user, pw)
        m.select("INBOX")
        _, data = m.search(None, f'(SINCE {since_imap})')
        nums = data[0].split()
        # Take most recent up to max_msgs
        for num in nums[-max_msgs:]:
            try:
                # BODY.PEEK[] works on both Gmail and iCloud and doesn't flip
                # messages to \Seen. RFC822 returns empty () on iCloud.
                _, fdata = m.fetch(num, "(BODY.PEEK[])")
                if not fdata or not fdata[0]:
                    continue
                # fdata[0] may be tuple (bytes, bytes) or sometimes other shape
                if isinstance(fdata[0], tuple) and len(fdata[0]) >= 2:
                    raw = fdata[0][1]
                else:
                    continue
                if not isinstance(raw, (bytes, bytearray)):
                    continue
                msg = email.message_from_bytes(bytes(raw))
            except Exception as e:
                sys.stderr.write(f"WARN: {acct['name']} msg {num!r} fetch error: {e}\n")
                continue
            try:
                from_raw = decode_str(msg.get("From", ""))
                from_addrs = getaddresses([from_raw])
                from_name = from_addrs[0][0] if from_addrs else ""
                from_email = from_addrs[0][1] if from_addrs else from_raw
                to_addrs = [a for _, a in getaddresses([decode_str(msg.get("To", ""))])]
                cc_addrs = [a for _, a in getaddresses([decode_str(msg.get("Cc", ""))])]
                subject = decode_str(msg.get("Subject", ""))
                try:
                    dt = parsedate_to_datetime(msg.get("Date", ""))
                    date_iso = dt.isoformat()
                except Exception:
                    date_iso = ""
                user_lower = user.lower()
                is_direct = any(a.lower() == user_lower for a in to_addrs)
                snippet = extract_text(msg)
                # Gmail exposes a stable web permalink via the RFC822 Message-ID
                # (mail.google.com search:rfc822msgid). iCloud has no such web URL.
                msgid = (msg.get("Message-ID", "") or "").strip()
                link = None
                if acct["name"] == "gmail" and msgid:
                    link = "https://mail.google.com/mail/u/0/#search/rfc822msgid:" + quote(msgid, safe="")
            except Exception as e:
                sys.stderr.write(f"WARN: {acct['name']} msg {num!r} parse error: {e}\n")
                continue
            results.append({
                "id":        f"{acct['name']}:{num.decode()}",
                "account":   acct["name"],
                "from":      from_email.lower(),
                "from_name": from_name or None,
                "to":        [a.lower() for a in to_addrs],
                "cc":        [a.lower() for a in cc_addrs],
                "subject":   subject,
                "snippet":   snippet,
                "date":      date_iso,
                "is_direct": is_direct,
                "link":      link,
            })
        m.logout()
    except Exception as e:
        sys.stderr.write(f"WARN: {acct['name']} fetch failed: {e}\n")
    return results

merged = []
for a in ACCOUNTS:
    merged.extend(fetch_account(a))
merged.sort(key=lambda x: x.get("date") or "", reverse=True)
json.dump(merged, sys.stdout)
PYEOF
}

cmd_get() {
  local id=""
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --id) id="$2"; shift 2 ;;
      *) echo "ERROR: unknown arg: $1" >&2; exit 2 ;;
    esac
  done
  if [[ -z "$id" || "$id" != *:* ]]; then
    echo "ERROR: get requires --id <account:uid> (e.g. icloud:10346)" >&2; exit 2
  fi

  load_env

  local acct="${id%%:*}"
  case "$acct" in
    gmail)
      : "${GMAIL_EMAIL:?ERROR: GMAIL_EMAIL missing}" "${GMAIL_APP_PASSWORD:?ERROR: GMAIL_APP_PASSWORD missing}" ;;
    icloud)
      : "${ICLOUD_EMAIL:?ERROR: ICLOUD_EMAIL missing}" "${ICLOUD_APP_PASSWORD:?ERROR: ICLOUD_APP_PASSWORD missing}" ;;
    *) echo "ERROR: unknown account in id: $acct (expected gmail|icloud)" >&2; exit 2 ;;
  esac

  python3 - "$id" <<'PYEOF'
import imaplib, email, json, os, sys, re, html
from email.header import decode_header
from email.utils import parsedate_to_datetime, getaddresses

full_id = sys.argv[1]
acct, uid = full_id.split(":", 1)

HOSTS = {
    "gmail":  {"host": "imap.gmail.com",   "user_var": "GMAIL_EMAIL",  "pass_var": "GMAIL_APP_PASSWORD"},
    "icloud": {"host": "imap.mail.me.com", "user_var": "ICLOUD_EMAIL", "pass_var": "ICLOUD_APP_PASSWORD"},
}

def decode_str(s):
    if s is None:
        return ""
    if isinstance(s, bytes):
        try: return s.decode("utf-8", errors="replace")
        except Exception: return s.decode("latin-1", errors="replace")
    if not isinstance(s, str):
        return str(s)
    try:
        parts = decode_header(s)
    except Exception:
        return s
    out = []
    for chunk, enc in parts:
        if isinstance(chunk, bytes):
            try: out.append(chunk.decode(enc or "utf-8", errors="replace"))
            except Exception:
                try: out.append(chunk.decode("latin-1", errors="replace"))
                except Exception: out.append("")
        elif isinstance(chunk, str):
            out.append(chunk)
        else:
            out.append(str(chunk))
    return "".join(out)

def strip_html(raw):
    # Drop script/style, turn breaks + block-closers into newlines, unescape entities.
    t = re.sub(r"(?is)<(script|style).*?</\1>", "", raw)
    t = re.sub(r"(?i)<br\s*/?>", "\n", t)
    t = re.sub(r"(?i)</(p|div|tr|li|h[1-6]|td|table|ul|ol|blockquote)>", "\n", t)
    t = re.sub(r"<[^>]+>", " ", t)
    t = html.unescape(t)
    t = re.sub(r"[ \t]+", " ", t)
    t = re.sub(r"\n[ \t]+", "\n", t)
    t = re.sub(r"\n{3,}", "\n\n", t)
    return t.strip()

def full_body(msg):
    plains, htmls = [], []
    if msg.is_multipart():
        for p in msg.walk():
            ct = p.get_content_type()
            if p.get_content_maintype() == "multipart":
                continue
            if p.get("Content-Disposition", "").lower().startswith("attachment"):
                continue
            try:
                payload = p.get_payload(decode=True)
                if payload is None:
                    continue
                text = payload.decode(p.get_content_charset() or "utf-8", errors="replace")
            except Exception:
                continue
            if ct == "text/plain":
                plains.append(text)
            elif ct == "text/html":
                htmls.append(text)
    else:
        try:
            payload = msg.get_payload(decode=True)
            text = payload.decode(msg.get_content_charset() or "utf-8", errors="replace") if payload else (msg.get_payload() or "")
        except Exception:
            text = msg.get_payload() or ""
        if msg.get_content_type() == "text/html":
            htmls.append(text)
        else:
            plains.append(text)
    plain = "\n".join(t for t in plains if t and t.strip())
    if plain.strip():
        body = re.sub(r"\n{3,}", "\n\n", plain).strip()
    else:
        body = strip_html("\n".join(htmls))
    return body

cfg = HOSTS[acct]
user = os.environ[cfg["user_var"]]
pw   = os.environ[cfg["pass_var"]]
try:
    m = imaplib.IMAP4_SSL(cfg["host"], 993)
    m.login(user, pw)
    m.select("INBOX")
    # BODY.PEEK[] fetches the whole message without flipping it to \Seen.
    _, fdata = m.fetch(uid, "(BODY.PEEK[])")
    raw = None
    for part in (fdata or []):
        if isinstance(part, tuple) and len(part) >= 2 and isinstance(part[1], (bytes, bytearray)):
            raw = bytes(part[1]); break
    if raw is None:
        sys.stderr.write(f"ERROR: message {full_id} not found or empty\n"); sys.exit(4)
    msg = email.message_from_bytes(raw)
    from_addrs = getaddresses([decode_str(msg.get("From", ""))])
    from_name = from_addrs[0][0] if from_addrs else ""
    from_email = (from_addrs[0][1] if from_addrs else "").lower()
    subject = decode_str(msg.get("Subject", ""))
    try:
        date_iso = parsedate_to_datetime(msg.get("Date", "")).isoformat()
    except Exception:
        date_iso = ""
    body = full_body(msg)
    m.logout()
    json.dump({
        "id": full_id, "account": acct,
        "from": from_email, "from_name": from_name or None,
        "subject": subject, "date": date_iso,
        "body": body, "body_len": len(body),
    }, sys.stdout)
except SystemExit:
    raise
except Exception as e:
    sys.stderr.write(f"ERROR: get {full_id} failed: {e}\n"); sys.exit(4)
PYEOF
}

main() {
  local sub="${1:-}"
  [[ -z "$sub" ]] && { echo "Usage: $0 recent --since <ISO8601> | --hours <N> [--max <n>]  |  $0 get --id <account:uid>" >&2; exit 2; }
  shift
  case "$sub" in
    recent) cmd_recent "$@" ;;
    get)    cmd_get "$@" ;;
    *) echo "ERROR: unknown subcommand: $sub" >&2; exit 2 ;;
  esac
}

main "$@"
