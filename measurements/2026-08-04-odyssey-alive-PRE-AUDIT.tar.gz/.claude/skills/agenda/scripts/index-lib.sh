#!/usr/bin/env bash
# Account-routing index helpers for the /agenda skill.
# Source this file from other scripts; it does not run standalone.
#
# Index format: org-mode file at .claude/skills/agenda/references/account-index.org
# Each top-level "* slug" heading is a project; properties drawer lists
# :EMAILS:, :PHONES:, :ALIASES:, :KIND:.
#
# Public functions:
#   index_path                       — print path to account-index.org
#   index_lookup_email <email>       — print matching project slug(s), one per line (empty if none)
#   index_lookup_phone <phone>       — print matching project slug(s), one per line, digit-normalized (empty if none)
#   index_list_projects              — print all project slugs, one per line
#   index_get_property <slug> <name> — print the value of a property for a project
#   index_add_email <slug> <email>   — append email to a project (idempotent)
#   index_add_phone <slug> <phone>   — append phone to a project (idempotent)
#   index_normalize_phone <phone>    — strip non-digits

# Library — do NOT enable `set -e`/`set -u` here; it would mutate the caller.
# Path detection: works whether sourced from bash or invoked via `bash -c`.
_index_lib_src="${BASH_SOURCE[0]:-$0}"
_index_lib_dir="$(cd "$(dirname "$_index_lib_src")" && pwd)"
_index_skill_dir="$(dirname "$_index_lib_dir")"

index_path() {
  printf "%s/references/account-index.org" "$_index_skill_dir"
}

index_normalize_phone() {
  printf "%s" "$1" | tr -cd '0-9'
}

# Awk filter that yields lines: <slug>\t<property>\t<value>
_index_emit_kv() {
  awk '
    /^\* / { slug = $2; in_props = 0; next }
    /^[[:space:]]*:PROPERTIES:/ { in_props = 1; next }
    /^[[:space:]]*:END:/ { in_props = 0; next }
    in_props && /^[[:space:]]*:[A-Z]+:/ {
      key = $1; sub(/^:/, "", key); sub(/:$/, "", key)
      $1 = ""
      val = $0
      sub(/^[[:space:]]+/, "", val)
      print slug "\t" key "\t" val
    }
  ' "$(index_path)"
}

index_list_projects() {
  awk '/^\* / { print $2 }' "$(index_path)"
}

index_get_property() {
  local slug="$1" key="$2"
  _index_emit_kv | awk -F'\t' -v s="$slug" -v k="$key" '$1 == s && $2 == k { print $3 }'
}

# Returns ALL matching project slugs, one per line, in index file order. A
# contact (number/email) shared across projects yields multiple lines; the
# triage classifier disambiguates by content (see triage-workflow.md Step 2/3).
index_lookup_email() {
  local needle="$1"
  needle="$(printf "%s" "$needle" | tr '[:upper:]' '[:lower:]')"
  _index_emit_kv | awk -F'\t' -v n="$needle" '
    $2 == "EMAILS" {
      v = tolower($3)
      gsub(/[[:space:]]/, "", v)
      n_count = split(v, arr, ",")
      for (i = 1; i <= n_count; i++) {
        if (arr[i] == n) { print $1; next }
      }
    }
  '
}

index_lookup_phone() {
  local needle; needle="$(index_normalize_phone "$1")"
  [[ -z "$needle" ]] && return 0
  _index_emit_kv | awk -F'\t' -v n="$needle" '
    $2 == "PHONES" {
      v = $3
      gsub(/[^0-9,]/, "", v)
      n_count = split(v, arr, ",")
      for (i = 1; i <= n_count; i++) {
        if (length(arr[i]) > 0 && (arr[i] == n || index(arr[i], n) > 0 || index(n, arr[i]) > 0)) {
          print $1; next
        }
      }
    }
  '
}

# Append a value to a property line for a slug. Creates the property line if
# missing. Idempotent: refuses to add a duplicate.
_index_append_property_value() {
  local slug="$1" key="$2" value="$3"
  local path; path="$(index_path)"
  local existing; existing="$(index_get_property "$slug" "$key")"

  # Idempotency check (case-insensitive for emails, digit-normalized for phones)
  local needle="$value"
  if [[ "$key" == "EMAILS" ]]; then
    needle="$(printf "%s" "$value" | tr '[:upper:]' '[:lower:]')"
    local lower_existing; lower_existing="$(printf "%s" "$existing" | tr '[:upper:]' '[:lower:]')"
    if printf "%s" "$lower_existing" | grep -qFw "$needle"; then return 0; fi
  elif [[ "$key" == "PHONES" ]]; then
    needle="$(index_normalize_phone "$value")"
    local norm_existing
    norm_existing="$(printf "%s" "$existing" | tr ',' '\n' | while read -r p; do index_normalize_phone "$p"; echo; done | tr '\n' ',')"
    if printf "%s" "$norm_existing" | grep -qFw "$needle"; then return 0; fi
  fi

  # Build new property value
  local new_value
  if [[ -z "$existing" ]]; then
    new_value="$value"
  else
    new_value="${existing}, ${value}"
  fi

  # Use python for the in-place update — awk in-place editing is fragile
  python3 - "$path" "$slug" "$key" "$new_value" <<'PYEOF'
import sys, re
path, slug, key, new_val = sys.argv[1:5]
with open(path, "r", encoding="utf-8") as f:
    text = f.read()

# Find the project block
heading_re = re.compile(r"(?m)^\* " + re.escape(slug) + r"\b.*$")
m = heading_re.search(text)
if not m:
    sys.exit(f"ERROR: project '{slug}' not found in index")

block_start = m.end()
next_heading = re.search(r"(?m)^\* ", text[block_start:])
block_end = block_start + next_heading.start() if next_heading else len(text)
block = text[block_start:block_end]

prop_line_re = re.compile(r"(?m)^([ \t]*:" + re.escape(key) + r":)([ \t]*)(.*)$")
pm = prop_line_re.search(block)

if pm:
    new_block = block[:pm.start()] + f"{pm.group(1)}    {new_val}" + block[pm.end():]
else:
    # Insert before :END:
    end_re = re.compile(r"(?m)^([ \t]*):END:")
    em = end_re.search(block)
    if not em:
        sys.exit(f"ERROR: project '{slug}' has no :PROPERTIES: drawer")
    indent = em.group(1) or "  "
    insertion = f"{indent}:{key}:    {new_val}\n"
    new_block = block[:em.start()] + insertion + block[em.start():]

new_text = text[:block_start] + new_block + text[block_end:]
with open(path, "w", encoding="utf-8") as f:
    f.write(new_text)
PYEOF
}

index_add_email() {
  local slug="$1" email="$2"
  _index_append_property_value "$slug" "EMAILS" "$email"
}

index_add_phone() {
  local slug="$1" phone="$2"
  _index_append_property_value "$slug" "PHONES" "$phone"
}

# Remove a value from a property line. No-op if the value isn't present.
# Email match is case-insensitive; phone match is digit-normalized.
_index_remove_property_value() {
  local slug="$1" key="$2" value="$3"
  local path; path="$(index_path)"
  python3 - "$path" "$slug" "$key" "$value" <<'PYEOF'
import sys, re
path, slug, key, target = sys.argv[1:5]
with open(path, "r", encoding="utf-8") as f:
    text = f.read()

heading_re = re.compile(r"(?m)^\* " + re.escape(slug) + r"\b.*$")
m = heading_re.search(text)
if not m:
    sys.exit(f"ERROR: project '{slug}' not found")

block_start = m.end()
nh = re.search(r"(?m)^\* ", text[block_start:])
block_end = block_start + nh.start() if nh else len(text)
block = text[block_start:block_end]

prop_re = re.compile(r"(?m)^([ \t]*:" + re.escape(key) + r":)([ \t]*)(.*)$")
pm = prop_re.search(block)
if not pm:
    sys.exit(0)  # nothing to remove
items = [v.strip() for v in pm.group(3).split(",") if v.strip()]

def norm_email(s): return s.lower()
def norm_phone(s): return re.sub(r"\D", "", s)

if key == "EMAILS":
    norm = norm_email
elif key == "PHONES":
    norm = norm_phone
else:
    norm = lambda s: s

target_n = norm(target)
kept = [v for v in items if norm(v) != target_n]
if len(kept) == len(items):
    sys.exit(0)  # not present
new_value = ", ".join(kept)
new_block = block[:pm.start()] + f"{pm.group(1)}    {new_value}" + block[pm.end():]
new_text = text[:block_start] + new_block + text[block_end:]
with open(path, "w", encoding="utf-8") as f:
    f.write(new_text)
PYEOF
}

index_remove_email() {
  _index_remove_property_value "$1" "EMAILS" "$2"
}

index_remove_phone() {
  _index_remove_property_value "$1" "PHONES" "$2"
}
