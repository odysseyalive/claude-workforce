#!/usr/bin/env python3
"""Attribution choke point for /agenda's Awaiting Correspondence + Clarifications Needed.

Both outlets of the briefing (the terminal tables and the browser view) descend from ONE
validated object so they cannot disagree. Reads the row set, drops any row that asserts a
person's name without a resolvable provenance pointer, prints the two ready-to-paste
markdown tables on stdout and a drop report on stderr.

Why this exists: on 2026-07-20 the briefing credited a Broom21 item to "Barak Tutterrow",
a name that appeared in no source artifact. The failure was UNAWARE fabrication, so asking
the writer to double-check itself does not work -- an introspection task fails where an
observation task succeeds. Hence the resolver below: an org pointer is opened and read.
A presence-only check would be theater, because the same pass that invents a name will
invent a file:line beside it.

Usage:
    attribution.py <rows.json>            # tables -> stdout, drops -> stderr
    attribution.py <rows.json> --json     # validated rows as JSON -> stdout (for today.js)

Input JSON: {"dateISO": "YYYY-MM-DD", "awaiting": [AwaitingRow], "clarifications": [ClarificationRow]}
Contract:   agenda/src/types.ts

Exit codes: 0 = all rows valid | 1 = at least one row dropped (tables still printed)
            2 = input file missing/unreadable | 3 = input unparseable
"""

import json
import os
import re
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[4]

# Shapes a provenance pointer may take. An org pointer is additionally RESOLVED (opened and
# read); the others are fetched artifacts not on disk, so only their shape can be checked.
ORG_PTR = re.compile(r"^(?P<file>[A-Za-z0-9._-]+\.org):(?P<line>\d+)$")
OTHER_PTR = re.compile(r"^(quo:\+?[0-9]{7,}|gmail:[0-9A-Za-z._-]+|icloud:[0-9A-Za-z._-]+|slack:[^\s]+|account-index\.org:[^\s].*)$")

# How far from the cited line the name may appear. Org bodies wrap a note across a few
# lines, so an exact-line match would produce false drops.
CONTEXT = 4


def org_dir() -> Path:
    """Resolve ORG_DIR the same way the rest of /agenda does (.env.local)."""
    env = REPO / ".env.local"
    if env.exists():
        for line in env.read_text(errors="replace").splitlines():
            if line.startswith("ORG_DIR="):
                return Path(line.split("=", 1)[1].strip().strip('"').strip("'"))
    return Path("/home/francis/Insync/fmeetze@gmail.com/Google Drive/gdrive/org")


def name_tokens(name: str):
    """Significant tokens of a display name, ignoring the parenthetical org.

    "Barak Tutterrow (H1 Websites)" -> ["barak", "tutterrow"]
    """
    bare = re.sub(r"\(.*?\)", " ", name)
    return [t for t in re.findall(r"[A-Za-z][A-Za-z'-]+", bare.lower()) if len(t) > 2]


def resolve(name: str, source: str):
    """Return (ok, detail). An org pointer is opened and read; other forms are shape-checked."""
    if not source or not str(source).strip():
        return False, "no provenance pointer"

    source = str(source).strip()
    m = ORG_PTR.match(source)
    if not m:
        if OTHER_PTR.match(source):
            return True, "pointer shape valid (artifact not on disk)"
        return False, f"pointer {source!r} is not an artifact reference"

    path = org_dir() / m.group("file")
    if not path.exists():
        return False, f"org file {m.group('file')} does not exist"

    lines = path.read_text(errors="replace").splitlines()
    idx = int(m.group("line")) - 1
    if not (0 <= idx < len(lines)):
        return False, f"{source} is past end of file ({len(lines)} lines)"

    window = "\n".join(lines[max(0, idx - CONTEXT): idx + CONTEXT + 1]).lower()
    toks = name_tokens(name)
    if not toks:
        return False, f"no checkable name tokens in {name!r}"
    if any(t in window for t in toks):
        return True, f"name attested at {source}"
    return False, f"none of {toks} appear within +/-{CONTEXT} lines of {source}"


def check(rows, name_field, source_field, org_field, label):
    """Split rows into (kept, dropped). A null name is legitimate and always kept."""
    kept, dropped = [], []
    for i, r in enumerate(rows):
        who = r.get(name_field)
        if who is None or who == "":
            if not r.get(org_field):
                dropped.append((f"{label}[{i}]", "(unnamed)",
                                f"name is null and no {org_field} label given - "
                                f"row would render with no identity at all"))
                continue
            kept.append(r)
            continue
        ok, detail = resolve(who, r.get(source_field))
        if ok:
            kept.append(r)
        else:
            dropped.append((f"{label}[{i}]", who, detail))
    return kept, dropped


def display(r, name_field, org_field):
    who = r.get(name_field)
    if who:
        return who
    org = r.get(org_field)
    return f"{org} — unnamed contact" if org else "Unnamed contact"


def cell(v):
    return str(v if v is not None else "").replace("|", "\\|").replace("\n", " ").strip()


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    as_json = "--json" in sys.argv[1:]
    if not args:
        print(__doc__, file=sys.stderr)
        return 2

    src = Path(args[0])
    if not src.exists():
        print(f"ERROR: {src} not found", file=sys.stderr)
        return 2
    try:
        data = json.loads(src.read_text())
    except Exception as e:
        print(f"ERROR: {src} is not valid JSON: {e}", file=sys.stderr)
        return 3

    awaiting, drop_a = check(data.get("awaiting", []) or [], "to", "toSource", "toOrg", "awaiting")
    clar, drop_c = check(data.get("clarifications", []) or [], "recipient", "recipientSource",
                         "recipientOrg", "clarifications")
    drops = drop_a + drop_c

    if as_json:
        print(json.dumps({"awaiting": awaiting, "clarifications": clar}, indent=2))
    else:
        out = ["### Awaiting Correspondence", ""]
        if awaiting:
            out += ["| To | Re | Asked | Days Out | Suggested Follow-up |",
                    "|----|----|-------|----------|---------------------|"]
            for r in awaiting:
                out.append(f"| {cell(display(r,'to','toOrg'))} | {cell(r.get('re'))} | "
                           f"{cell(r.get('asked'))} | {cell(r.get('daysOut'))} | {cell(r.get('followup'))} |")
        else:
            out.append("None for today.")
        out += ["", "### Clarifications Needed", ""]
        if clar:
            out += ["| Recipient | Channel | Question | For Task |",
                    "|-----------|---------|----------|----------|"]
            for r in clar:
                out.append(f"| {cell(display(r,'recipient','recipientOrg'))} | {cell(r.get('channel'))} | "
                           f"{cell(r.get('question'))} | {cell(r.get('forTask'))} |")
        else:
            out.append("None for today.")
        print("\n".join(out))

    if drops:
        print(f"\nDROPPED {len(drops)} row(s) - unverifiable attribution:", file=sys.stderr)
        for where, who, why in drops:
            print(f"  {where}: {who!r} -> {why}", file=sys.stderr)
        print("\nSurface these in the briefing rather than silently losing them: re-emit each "
              "with the name set to null plus an org label, or supply a real provenance pointer.",
              file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
