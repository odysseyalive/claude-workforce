#!/usr/bin/env bash
# Quo (formerly OpenPhone) REST integration for the /agenda skill.
# Self-contained: reads QUO_API_KEY (and optionally QUO_INBOX_IDS) from .env.local.
# No MCP dependency.
#
# Usage:
#   quo-fetch.sh inboxes
#   quo-fetch.sh messages --since <ISO8601> [--inbox <id>]
#   quo-fetch.sh calls    --since <ISO8601> [--inbox <id>]
#   quo-fetch.sh transcript <call-id>
#   quo-fetch.sh summary    <call-id>
#   quo-fetch.sh check        # probe auth mode and cache result
#
# Env (loaded from .env.local in the project root):
#   QUO_API_KEY      required
#   QUO_INBOX_IDS    optional, comma-separated. "0" or unset = all inboxes.
#
# Output: one JSON document per call (paginated results merged into a single array).

set -euo pipefail

BASE_URL="https://api.openphone.com/v1"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_DIR="$(dirname "$SCRIPT_DIR")"
AUTH_MODE_FILE="$SKILL_DIR/.quo-auth-mode"

# ------- env loading --------------------------------------------------------
load_env() {
  local env_file=""
  for candidate in \
    "$PWD/.env.local" \
    "$(git -C "$PWD" rev-parse --show-toplevel 2>/dev/null)/.env.local" \
    "$HOME/lab/odyssey-alive/.env.local"
  do
    [[ -n "$candidate" && -f "$candidate" ]] && { env_file="$candidate"; break; }
  done

  if [[ -z "$env_file" ]]; then
    echo "ERROR: .env.local not found (looked in CWD, repo root, ~/lab/odyssey-alive)" >&2
    exit 2
  fi

  # shellcheck disable=SC1090
  set -a; source "$env_file"; set +a

  if [[ -z "${QUO_API_KEY:-}" ]]; then
    echo "ERROR: QUO_API_KEY not set in $env_file" >&2
    exit 2
  fi
}

# ------- auth probe ---------------------------------------------------------
auth_header() {
  local mode="${1:-}"
  if [[ -z "$mode" ]]; then
    if [[ -f "$AUTH_MODE_FILE" ]]; then
      mode="$(cat "$AUTH_MODE_FILE")"
    else
      mode="$(probe_auth_mode)"
      printf "%s" "$mode" > "$AUTH_MODE_FILE"
    fi
  fi
  case "$mode" in
    plain)  printf "Authorization: %s" "$QUO_API_KEY" ;;
    bearer) printf "Authorization: Bearer %s" "$QUO_API_KEY" ;;
    *) echo "ERROR: unknown auth mode: $mode" >&2; exit 2 ;;
  esac
}

probe_auth_mode() {
  local code
  code="$(curl -sS -o /dev/null -w "%{http_code}" \
    -H "Authorization: $QUO_API_KEY" \
    "$BASE_URL/phone-numbers" || true)"
  if [[ "$code" == "200" ]]; then
    printf "plain"
    return 0
  fi
  code="$(curl -sS -o /dev/null -w "%{http_code}" \
    -H "Authorization: Bearer $QUO_API_KEY" \
    "$BASE_URL/phone-numbers" || true)"
  if [[ "$code" == "200" ]]; then
    printf "bearer"
    return 0
  fi
  echo "ERROR: auth probe failed (both plain and Bearer returned non-200)" >&2
  exit 3
}

# ------- HTTP helper --------------------------------------------------------
http_get() {
  local path="$1"
  local query="${2:-}"
  local url="$BASE_URL$path"
  [[ -n "$query" ]] && url="$url?$query"
  curl -sS -H "$(auth_header)" "$url"
}

# Paginated fetch: yields one JSON array merging all pages of `data`.
# Pages accumulate in a temp file and merge via slurp — passing grown arrays
# as jq arguments trips ARG_MAX. Fails loudly when the API returns an error
# body instead of a data page (previously a 400 was silently coerced to []).
http_get_paginated() {
  local path="$1"
  local query="${2:-}"
  local page_token=""
  local pages; pages="$(mktemp)"
  local page resp

  while :; do
    if [[ -n "$page_token" ]]; then
      page="${query}${query:+&}pageToken=${page_token}"
    else
      page="$query"
    fi
    resp="$(http_get "$path" "$page")"
    if ! printf "%s" "$resp" | jq -e 'has("data")' >/dev/null 2>&1; then
      echo "ERROR: $path returned an error response:" >&2
      printf "%s\n" "$resp" >&2
      rm -f "$pages"
      exit 4
    fi
    printf "%s" "$resp" | jq -c '.data // []' >> "$pages"
    page_token="$(printf "%s" "$resp" | jq -r '.nextPageToken // empty')"
    [[ -z "$page_token" ]] && break
  done
  jq -cs 'add // []' "$pages"
  rm -f "$pages"
}

# ------- inbox filter -------------------------------------------------------
# Returns the list of phoneNumberId values to scan, one per line.
resolve_inboxes() {
  local raw="${QUO_INBOX_IDS:-0}"
  if [[ "$raw" == "0" || -z "$raw" ]]; then
    http_get_paginated "/phone-numbers" | jq -r '.[].id'
  else
    printf "%s\n" "${raw//,/$'\n'}" | sed 's/[[:space:]]//g' | grep -v '^$'
  fi
}

# ------- participant enumeration --------------------------------------------
# /messages and /calls now REQUIRE a `participants` filter, so a windowed
# sweep must first enumerate who was active: conversations updated in the
# window → unique participant numbers, one per line.
resolve_participants() {
  local id="$1" since_enc="$2"
  http_get_paginated "/conversations" "phoneNumberId=${id}&updatedAfter=${since_enc}&maxResults=100" \
    | jq -r '[.[].participants[]] | unique | .[]'
}

# Windowed fetch shared by messages/calls: for each inbox, enumerate active
# participants, fetch per participant, then dedupe (group conversations can
# return the same item under several participants) and sort newest-first.
# The CLI keeps --since; the API-side filter is createdAfter (`since` is now
# silently ignored by the API and returns full history).
fetch_windowed() {
  local path="$1" since="$2" inbox="$3"
  local results; results="$(mktemp)"
  local ids
  if [[ -n "$inbox" ]]; then
    ids="$inbox"
  else
    ids="$(resolve_inboxes)"
  fi
  local since_enc="${since//+/%2B}"

  while IFS= read -r id; do
    [[ -z "$id" ]] && continue
    local participants; participants="$(resolve_participants "$id" "$since_enc")"
    while IFS= read -r p; do
      [[ -z "$p" ]] && continue
      local q="phoneNumberId=${id}&participants=${p//+/%2B}&createdAfter=${since_enc}&maxResults=100"
      http_get_paginated "$path" "$q" >> "$results"
      printf "\n" >> "$results"
    done <<< "$participants"
  done <<< "$ids"
  jq -cs 'add // [] | unique_by(.id) | sort_by(.createdAt) | reverse' "$results"
  rm -f "$results"
}

# ------- subcommands --------------------------------------------------------
cmd_check() {
  load_env
  rm -f "$AUTH_MODE_FILE"
  local mode; mode="$(probe_auth_mode)"
  printf "%s" "$mode" > "$AUTH_MODE_FILE"
  echo "auth mode: $mode (cached to $AUTH_MODE_FILE)"
}

cmd_inboxes() {
  load_env
  http_get_paginated "/phone-numbers"
}

cmd_messages() {
  load_env
  local since="" inbox=""
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --since) since="$2"; shift 2 ;;
      --inbox) inbox="$2"; shift 2 ;;
      *) echo "ERROR: unknown arg: $1" >&2; exit 2 ;;
    esac
  done
  [[ -z "$since" ]] && { echo "ERROR: --since required (ISO 8601)" >&2; exit 2; }

  fetch_windowed "/messages" "$since" "$inbox"
}

cmd_calls() {
  load_env
  local since="" inbox=""
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --since) since="$2"; shift 2 ;;
      --inbox) inbox="$2"; shift 2 ;;
      *) echo "ERROR: unknown arg: $1" >&2; exit 2 ;;
    esac
  done
  [[ -z "$since" ]] && { echo "ERROR: --since required (ISO 8601)" >&2; exit 2; }

  fetch_windowed "/calls" "$since" "$inbox"
}

cmd_transcript() {
  load_env
  local id="${1:-}"
  [[ -z "$id" ]] && { echo "ERROR: call id required" >&2; exit 2; }
  http_get "/call-transcripts/${id}"
}

cmd_summary() {
  load_env
  local id="${1:-}"
  [[ -z "$id" ]] && { echo "ERROR: call id required" >&2; exit 2; }
  http_get "/call-summaries/${id}"
}

# ------- dispatch -----------------------------------------------------------
main() {
  local sub="${1:-}"
  [[ -z "$sub" ]] && { echo "Usage: $0 {check|inboxes|messages|calls|transcript|summary} [args]" >&2; exit 2; }
  shift
  case "$sub" in
    check)      cmd_check "$@" ;;
    inboxes)    cmd_inboxes "$@" ;;
    messages)   cmd_messages "$@" ;;
    calls)      cmd_calls "$@" ;;
    transcript) cmd_transcript "$@" ;;
    summary)    cmd_summary "$@" ;;
    *) echo "ERROR: unknown subcommand: $sub" >&2; exit 2 ;;
  esac
}

main "$@"
