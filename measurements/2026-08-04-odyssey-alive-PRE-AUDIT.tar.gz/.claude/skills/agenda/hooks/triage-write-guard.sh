#!/usr/bin/env bash
# PreToolUse hook for the /agenda skill.
# Guards Edit/Write calls against unintended modifications of .org files in
# the org directory. Allows only a small set of triage/cleanup operations.
#
# Contract:
#   - stdin: JSON with { tool_name, tool_input }
#   - exit 0: approve
#   - exit 2: block (stderr message shown to model)
#
# Allowed patterns on Edit (where target file is *.org under the org directory):
#   1. TODO <-> DONE keyword swap on a single headline
#   2. Insert a "DEADLINE: <YYYY-MM-DD ...>" line directly after a TODO headline
#   3. Replace the date inside an existing "DEADLINE: <...>" line
#   4. Append a new "* TODO ... <YYYY-MM-DD ...>\n  DEADLINE: <...>\n  <summary>" subtree
#      at the very end of the file (old_string must end with EOF marker pattern)
#   5. Append a dated note line "  - YYYY-MM-DD: <text>" under an existing TODO body
#      (only when no credential keyword appears in old or new content)
#   8. Zoho-sync structural insert (timesheet bidirectional pull) — insert-only,
#      drawer-balanced, closed-CLOCK-only. Permits adding a closed CLOCK line into a
#      :LOGBOOK:, a :ZOHO_*: identity property in a :PROPERTIES: drawer, or a new
#      :LOGBOOK:/headline carrying these. Time data can only be ADDED, never removed.
#
# Disallowed:
#   - Write tool on existing org files (force edits through Edit for diff visibility)
#   - Any edit whose new_string contains credential keywords not present in old_string

set -u
CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is 2>/dev/null) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR

# Resolve the org directory from .env.local so this guard protects the SAME dir
# the /agenda and /timesheet gates read (server source, or a relocated local dir).
# One source of truth. NOTE: the default path contains a space ("Google Drive") —
# only surrounding quotes / trailing CR are stripped, never internal spaces.
ORG_DIR="$(grep -E '^[[:space:]]*ORG_DIR=' "${CLAUDE_PROJECT_DIR:-.}/.env.local" 2>/dev/null \
  | tail -1 | sed -E 's/^[[:space:]]*ORG_DIR=//; s/\r$//; s/^"(.*)"$/\1/; s/^'"'"'(.*)'"'"'$/\1/')"
ORG_DIR="${ORG_DIR:-/home/francis/Insync/fmeetze@gmail.com/Google Drive/gdrive/org}"
ORG_DIR="${ORG_DIR%/}"   # strip any trailing slash so "$ORG_DIR"/*.org matches
INDEX_PATH="${CLAUDE_PROJECT_DIR:-.}/.claude/skills/agenda/references/account-index.org"

INPUT="$(cat 2>/dev/null)" || exit 0

# Parse tool name, file path, old/new strings
read_field() {
  printf '%s' "$INPUT" | python3 -c "
import json, sys
try:
    data = json.load(sys.stdin)
    parts = '$1'.split('.')
    cur = data
    for p in parts:
        if cur is None: break
        cur = cur.get(p) if isinstance(cur, dict) else None
    if cur is None: print('')
    else: print(cur)
except Exception:
    pass
" 2>/dev/null
}

TOOL_NAME="$(read_field tool_name)"
FILE_PATH="$(read_field tool_input.file_path)"

# Only guard Edit and Write
case "$TOOL_NAME" in
  Edit|Write) ;;
  *) exit 0 ;;
esac

# Only guard files under the org directory (the index file is excluded —
# it's a routing table the skill manages directly).
case "$FILE_PATH" in
  "$ORG_DIR"/*.org) ;;
  *) exit 0 ;;
esac

# Index file is not a project org file — allow freely
[[ "$FILE_PATH" == "$INDEX_PATH" ]] && exit 0

# Block Write outright on org files in the org directory
if [[ "$TOOL_NAME" == "Write" ]]; then
  cat >&2 <<EOF
BLOCKED: Write to $FILE_PATH is not allowed.
Org files in $ORG_DIR may contain credentials below TODO headlines.
Use Edit (with explicit old_string/new_string) so the diff is auditable, or
restrict the file path to the agenda skill's index file.
EOF
  exit 2
fi

# Edit path — extract old/new strings
OLD="$(read_field tool_input.old_string)"
NEW="$(read_field tool_input.new_string)"

# Credential regex — block if NEW introduces credential markers OLD didn't have.
# Use POSIX ERE with -i for case-insensitive matching.
CRED_RE='(password|passwd|secret|token|api[_-]?key|^USER:|^PASS:|https?://[^[:space:]]*:[^[:space:]]*@)'
old_creds="$(printf '%s' "$OLD" | grep -ciE "$CRED_RE" || true)"
new_creds="$(printf '%s' "$NEW" | grep -ciE "$CRED_RE" || true)"
if (( new_creds > old_creds )); then
  cat >&2 <<EOF
BLOCKED: Edit to $FILE_PATH introduces credential-shaped content.
This guard prevents accidental writes of passwords, tokens, or auth URLs
into a project org file. Review the new_string and remove credential lines,
or use Edit only for the headline/DEADLINE change.
EOF
  exit 2
fi

# Time-data preservation — block any Edit that decreases CLOCK: line count.
# CLOCK lines record billable / tracked time and must never be removed by
# any agenda operation (cleanup, triage, archive).
old_clocks="$(printf '%s' "$OLD" | grep -cE '^[[:space:]]*CLOCK:' || true)"
new_clocks="$(printf '%s' "$NEW" | grep -cE '^[[:space:]]*CLOCK:' || true)"
if (( new_clocks < old_clocks )); then
  cat >&2 <<EOF
BLOCKED: Edit to $FILE_PATH would remove time-tracking data.
old_string contains $old_clocks CLOCK: line(s); new_string contains $new_clocks.
CLOCK entries record billable / tracked work and must be preserved through
every operation. Adjust the edit so the CLOCK count is unchanged or higher.
EOF
  exit 2
fi
# Also block any decrease in :LOGBOOK: / :END: pairings as a structural rail
old_logbook="$(printf '%s' "$OLD" | grep -cE '^[[:space:]]*:LOGBOOK:' || true)"
new_logbook="$(printf '%s' "$NEW" | grep -cE '^[[:space:]]*:LOGBOOK:' || true)"
if (( new_logbook < old_logbook )); then
  cat >&2 <<EOF
BLOCKED: Edit to $FILE_PATH would remove a :LOGBOOK: block.
LOGBOOK drawers contain CLOCK entries and must be preserved.
EOF
  exit 2
fi

# Pattern checks — at least one must match.
# 1) Keyword swap among {TODO, HOLD, DONE} on a single headline.
#    The headline text and depth markers must remain identical — only the
#    keyword token changes.
swap_ok=0
if [[ "$OLD" =~ ^([[:space:]]*\*+[[:space:]])(TODO|HOLD|DONE)([[:space:]].*)$ ]]; then
  old_prefix="${BASH_REMATCH[1]}"
  old_keyword="${BASH_REMATCH[2]}"
  old_rest="${BASH_REMATCH[3]}"
  if [[ "$NEW" =~ ^([[:space:]]*\*+[[:space:]])(TODO|HOLD|DONE)([[:space:]].*)$ ]]; then
    new_prefix="${BASH_REMATCH[1]}"
    new_keyword="${BASH_REMATCH[2]}"
    new_rest="${BASH_REMATCH[3]}"
    if [[ "$old_prefix" == "$new_prefix" && "$old_rest" == "$new_rest" \
          && "$old_keyword" != "$new_keyword" ]]; then
      swap_ok=1
    fi
  fi
fi

# 2) DEADLINE insertion: NEW differs from OLD by exactly one inserted line
#    that matches "<indent>DEADLINE: <YYYY-MM-DD ...>" and the line before
#    the insertion point is a TODO/DONE headline. Works whether the headline
#    is at the end of OLD or in the middle (with surrounding context).
deadline_insert_ok=0
if [[ "$OLD" =~ \*+[[:space:]](TODO|DONE)[[:space:]] ]] && \
   [[ "$NEW" =~ DEADLINE:[[:space:]]\<[0-9]{4}-[0-9]{2}-[0-9]{2} ]]; then
  deadline_insert_ok="$(python3 - "$OLD" "$NEW" <<'PY'
import sys, re, difflib
old = sys.argv[1].split('\n')
new = sys.argv[2].split('\n')
sm = difflib.SequenceMatcher(a=old, b=new, autojunk=False)
inserted = []
ok = True
for tag, i1, i2, j1, j2 in sm.get_opcodes():
    if tag == 'equal':
        continue
    if tag == 'insert':
        # Note position in NEW for context check
        inserted.append((i1, j1, j2))
        continue
    # Any delete or replace disqualifies this pattern
    ok = False
    break
if not ok or len(inserted) != 1:
    print(0); sys.exit()
i1, j1, j2 = inserted[0]
ins_lines = new[j1:j2]
if len(ins_lines) != 1:
    print(0); sys.exit()
line = ins_lines[0]
if not re.match(r'^\s+DEADLINE:\s+<\d{4}-\d{2}-\d{2}[^>]*>\s*$', line):
    print(0); sys.exit()
# Line before insertion in NEW must be a TODO/DONE headline
if j1 == 0:
    print(0); sys.exit()
prev = new[j1-1]
if not re.match(r'^\s*\*+ (TODO|DONE) ', prev):
    print(0); sys.exit()
print(1)
PY
)"
fi
[[ "$deadline_insert_ok" == "1" ]] || deadline_insert_ok=0

# 3) DEADLINE date replacement: only the date inside <> changes
deadline_replace_ok=0
if [[ "$OLD" =~ ^([[:space:]]*DEADLINE:[[:space:]]\<)[0-9]{4}-[0-9]{2}-[0-9]{2}([^\>]*\>[[:space:]]*)$ ]] && \
   [[ "$NEW" =~ ^([[:space:]]*DEADLINE:[[:space:]]\<)[0-9]{4}-[0-9]{2}-[0-9]{2}([^\>]*\>[[:space:]]*)$ ]]; then
  deadline_replace_ok=1
fi

# 4) EOF append of a new TODO subtree
#    OLD ends the file; NEW = OLD + new TODO block
#    NOTE: $OLD is quoted inside ${NEW#...} so it strips as a LITERAL prefix,
#    not a glob pattern. CLOCK timestamps contain "[...]" which bash would
#    otherwise read as a glob character class, breaking prefix detection and
#    falsely blocking any append whose anchor tail includes a CLOCK line.
eof_append_ok=0
if [[ "${NEW#"$OLD"}" != "$NEW" ]]; then
  appended="${NEW#"$OLD"}"
  if [[ "$appended" =~ \*+[[:space:]]TODO[[:space:]].*\<[0-9]{4}-[0-9]{2}-[0-9]{2}[^\>]*\> ]] && \
     [[ "$appended" =~ DEADLINE:[[:space:]]\<[0-9]{4}-[0-9]{2}-[0-9]{2} ]]; then
    eof_append_ok=1
  fi
fi

# 5) Dated body note: NEW = OLD + "\n  - YYYY-MM-DD: <text>"
#    $OLD quoted for literal prefix strip (see Pattern 4 note re: CLOCK "[...]").
note_append_ok=0
if [[ "${NEW#"$OLD"}" != "$NEW" ]]; then
  appended="${NEW#"$OLD"}"
  if [[ "$appended" =~ ^[[:space:]]*$'\n'[[:space:]]+\-[[:space:]][0-9]{4}-[0-9]{2}-[0-9]{2}: ]]; then
    note_append_ok=1
  fi
fi

# 6) HOLD reason line: NEW differs from OLD by exactly one inserted line
#    matching "<indent>- HOLD: <text>" directly after a HOLD/TODO headline.
hold_reason_ok=0
if [[ "$NEW" =~ -[[:space:]]HOLD: ]]; then
  hold_reason_ok="$(python3 - "$OLD" "$NEW" <<'PY'
import sys, re, difflib
old = sys.argv[1].split('\n')
new = sys.argv[2].split('\n')
sm = difflib.SequenceMatcher(a=old, b=new, autojunk=False)
inserted = []
ok = True
for tag, i1, i2, j1, j2 in sm.get_opcodes():
    if tag == 'equal':
        continue
    if tag == 'insert':
        inserted.append((i1, j1, j2))
        continue
    ok = False
    break
if not ok or len(inserted) != 1:
    print(0); sys.exit()
i1, j1, j2 = inserted[0]
ins_lines = new[j1:j2]
if len(ins_lines) != 1:
    print(0); sys.exit()
line = ins_lines[0]
if not re.match(r'^\s+- HOLD: \S.*$', line):
    print(0); sys.exit()
if j1 == 0:
    print(0); sys.exit()
prev = new[j1-1]
if not re.match(r'^\s*\*+ (TODO|HOLD|DONE) ', prev):
    print(0); sys.exit()
print(1)
PY
)"
fi
[[ "$hold_reason_ok" == "1" ]] || hold_reason_ok=0

# 7) DONE subtree removal (cleanup Phase 2 archive): NEW = OLD with one
#    contiguous block deleted, where the deleted block starts with a
#    "** DONE ..." headline, contains zero CLOCK lines, is a complete
#    subtree (no peers/ancestors inside the deletion), and the deletion
#    ends at a same-or-shallower headline (or EOF).
#    The CLOCK==0 invariant is the trust boundary: time-tracking data is
#    never lost via this pattern.
done_archive_ok=0
if [[ "$OLD" =~ \*+[[:space:]]DONE[[:space:]] ]]; then
  done_archive_ok="$(python3 - "$OLD" "$NEW" <<'PY'
import sys, re, difflib
old = sys.argv[1].split('\n')
new = sys.argv[2].split('\n')
sm = difflib.SequenceMatcher(a=old, b=new, autojunk=False)
deleted = []
ok = True
for tag, i1, i2, j1, j2 in sm.get_opcodes():
    if tag == 'equal':
        continue
    if tag == 'delete':
        deleted.append((i1, i2))
        continue
    # Any insert or replace disqualifies this pattern
    ok = False
    break
if not ok or len(deleted) != 1:
    print(0); sys.exit()
i1, i2 = deleted[0]
del_lines = old[i1:i2]
if not del_lines:
    print(0); sys.exit()
# First line must be a DONE headline
m = re.match(r'^(\*+)\s+DONE\s', del_lines[0])
if not m:
    print(0); sys.exit()
depth = len(m.group(1))
# No CLOCK lines in deleted block (already gated upstream, re-checked here)
if any(re.match(r'^\s*CLOCK:', l) for l in del_lines):
    print(0); sys.exit()
# Subtree completeness: any subsequent headline within deleted block must be deeper
for l in del_lines[1:]:
    m2 = re.match(r'^(\*+)\s', l)
    if m2 and len(m2.group(1)) <= depth:
        print(0); sys.exit()
# Line in OLD after the deletion must be a same-or-shallower headline, or EOF
if i2 < len(old):
    nxt = old[i2]
    # Allow trailing blank line followed by headline or EOF, but the immediate
    # post-deletion line is what difflib aligned on. Tolerate one trailing blank.
    if nxt.strip() == '' and i2 + 1 < len(old):
        nxt = old[i2 + 1]
    elif nxt.strip() == '' and i2 + 1 >= len(old):
        print(1); sys.exit()
    m3 = re.match(r'^(\*+)\s', nxt)
    if not m3:
        print(0); sys.exit()
    if len(m3.group(1)) > depth:
        print(0); sys.exit()
print(1)
PY
)"
fi
[[ "$done_archive_ok" == "1" ]] || done_archive_ok=0

# 8) Zoho-sync structural insert (timesheet bidirectional pull): NEW = OLD with
#    one or more INSERTED blocks (no deletions / replacements), where every inserted
#    line is a Zoho-sync-shaped line and every inserted block is drawer-balanced
#    relative to its insertion context in NEW. Permits exactly three shapes:
#      a. a closed "CLOCK: [start]--[end] => H:MM" line into a :LOGBOOK: drawer
#      b. a :PROPERTIES: drawer and/or ":ZOHO_*: <id>" identity line under a headline
#      c. a new :LOGBOOK: drawer (with closed CLOCK lines), or a new TODO/HOLD/DONE
#         headline carrying these drawers
#    Insert-only + closed-CLOCK-only + drawer-balanced means tracked time can only be
#    ADDED, never lost or corrupted, and a CLOCK can only land inside a LOGBOOK. The
#    CLOCK/LOGBOOK count rails above still apply (an insert only increases counts).
zoho_sync_ok=0
if [[ "$NEW" == *"CLOCK:"* || "$NEW" == *":ZOHO_"* || "$NEW" == *":PROPERTIES:"* || "$NEW" == *":LOGBOOK:"* ]]; then
  zoho_sync_ok="$(python3 - "$OLD" "$NEW" <<'PY'
import sys, re, difflib
old = sys.argv[1].split('\n')
new = sys.argv[2].split('\n')
# Compare lines with trailing whitespace ignored: the Edit tool silently strips
# trailing whitespace from an anchor line, which would otherwise register as a
# REPLACE and disqualify an otherwise insert-only append. rstrip-only equality is
# safe — no time data lives in trailing whitespace, CLOCK_RE already tolerates it,
# and any genuine content change still shows as a replace/delete and stays blocked.
# Indices from the opcodes map positionally to the originals, so the shape checks
# below still read the real `new` lines.
old_cmp = [l.rstrip() for l in old]
new_cmp = [l.rstrip() for l in new]
sm = difflib.SequenceMatcher(a=old_cmp, b=new_cmp, autojunk=False)

CLOCK_RE = re.compile(r'^\s*CLOCK: \[\d{4}-\d{2}-\d{2} \w{2,3} \d{2}:\d{2}\]--\[\d{4}-\d{2}-\d{2} \w{2,3} \d{2}:\d{2}\] => \d+:\d{2}\s*$')
PROP_RE  = re.compile(r'^\s*:PROPERTIES:\s*$')
LOG_RE   = re.compile(r'^\s*:LOGBOOK:\s*$')
END_RE   = re.compile(r'^\s*:END:\s*$')
ZOHO_RE  = re.compile(r'^\s*:ZOHO_[A-Z0-9_]+:\s+\S.*$')
HEAD_RE  = re.compile(r'^\*+ (TODO|HOLD|DONE) \S')
ANYHEAD_RE = re.compile(r'^\*+ ')
BLANK_RE = re.compile(r'^\s*$')

inserts = []
for tag, i1, i2, j1, j2 in sm.get_opcodes():
    if tag == 'equal':
        continue
    if tag == 'insert':
        inserts.append((i1, j1, j2))
        continue
    print(0); sys.exit()       # any delete or replace disqualifies this pattern

if not inserts:
    print(0); sys.exit()

def drawer_context(lines, upto):
    # enclosing drawer state at position `upto` in NEW (scan upward to first boundary)
    for k in range(upto - 1, -1, -1):
        l = lines[k]
        if LOG_RE.match(l):  return 'LOGBOOK'
        if PROP_RE.match(l): return 'PROPERTIES'
        if END_RE.match(l):  return None
        if ANYHEAD_RE.match(l): return None
    return None

for (i1, j1, j2) in inserts:
    state = drawer_context(new, j1)
    start_state = state
    for line in new[j1:j2]:
        if BLANK_RE.match(line):
            continue
        if ANYHEAD_RE.match(line):
            if state is not None:        # cannot open a headline inside a drawer
                print(0); sys.exit()
            if not HEAD_RE.match(line):  # only TODO/HOLD/DONE headlines
                print(0); sys.exit()
            continue
        if PROP_RE.match(line):
            if state is not None: print(0); sys.exit()
            state = 'PROPERTIES'; continue
        if LOG_RE.match(line):
            if state is not None: print(0); sys.exit()
            state = 'LOGBOOK'; continue
        if END_RE.match(line):
            if state is None: print(0); sys.exit()
            state = None; continue
        if CLOCK_RE.match(line):
            if state != 'LOGBOOK': print(0); sys.exit()   # a CLOCK must land in a LOGBOOK
            continue
        if ZOHO_RE.match(line):
            if state != 'PROPERTIES': print(0); sys.exit()  # an ID must land in PROPERTIES
            continue
        print(0); sys.exit()             # any other line shape disqualifies
    if state != start_state:             # inserted block must be drawer-balanced
        print(0); sys.exit()
print(1)
PY
)"
fi
[[ "$zoho_sync_ok" == "1" ]] || zoho_sync_ok=0

if (( swap_ok || deadline_insert_ok || deadline_replace_ok || eof_append_ok || note_append_ok || hold_reason_ok || done_archive_ok || zoho_sync_ok )); then
  exit 0
fi

cat >&2 <<EOF
BLOCKED: Edit to $FILE_PATH does not match an allowed agenda write pattern.
Allowed patterns:
  1. Keyword swap among {TODO, HOLD, DONE} on a single headline
  2. Insert "DEADLINE: <YYYY-MM-DD ...>" line directly after a TODO headline
  3. Replace the date inside an existing DEADLINE: <...> line
  4. Append a new TODO subtree (with creation date and DEADLINE) at end of file
  5. Append a dated note "  - YYYY-MM-DD: <text>" under an existing TODO body
  6. Insert a "  - HOLD: <reason>" line directly under a HOLD/TODO headline
  7. Delete a complete DONE subtree containing zero CLOCK entries (Phase 2 archive)
  8. Zoho-sync insert (timesheet pull): add a closed CLOCK line into a :LOGBOOK:,
     a ":ZOHO_*: <id>" property in a :PROPERTIES: drawer, or a new :LOGBOOK:/headline
     carrying these — insert-only, drawer-balanced, closed CLOCK lines only
If you intend a different operation, the user must edit the file manually.
EOF
exit 2
