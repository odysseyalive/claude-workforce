#!/bin/bash
# Hook: Inject today's date as ground truth when /agenda is invoked.
# Prevents the model from guessing "today" when filtering org TODOs.
# Event: UserPromptSubmit
set -u
CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is 2>/dev/null) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR

INPUT=$(cat 2>/dev/null) || exit 0

PROMPT=$(printf '%s' "$INPUT" | python3 -c '
import json, sys
try:
    data = json.load(sys.stdin)
    print(data.get("prompt", ""))
except Exception:
    pass
' 2>/dev/null)

# Only fire for /agenda invocations
if ! printf '%s' "$PROMPT" | grep -qE '(^|[[:space:]])/agenda(\b|$)'; then
    exit 0
fi

TODAY=$(date +"%Y-%m-%d (%A)")
ISO=$(date +"%Y-%m-%dT%H:%M:%S%z")

cat <<EOF
GROUND TRUTH FOR /agenda: Today is ${TODAY}. Current timestamp: ${ISO}.

Use this date as the literal anchor for "today", "overdue", "this week", "due today", and similar temporal language. Do not infer the date from prior context or conversation history. If additional date arithmetic is needed (e.g., "due this week" window), run the Bash \`date\` tool explicitly.
EOF

exit 0
