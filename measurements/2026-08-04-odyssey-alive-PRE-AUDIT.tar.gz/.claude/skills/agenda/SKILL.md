---
name: agenda
description: "Org-mode project prioritization, triage, and cleanup. Modes: priorities, today, triage, index, cleanup, review, sync. Usage: /agenda [mode] [args]"
allowed-tools: Read, Glob, Grep, Edit, Bash, Task
minimum-effort-level: high
strictness: standard
---

# Agenda

Org-mode task management: prioritize active projects, triage incoming signals into deadlines and new TODOs, clean up stale items, review per-project TODOs.

## Modes

| Mode | Command | Description |
|------|---------|-------------|
| `priorities` | `/agenda` or `/agenda priorities` | Run the triage update-pass (confirmation walk), then rank active projects by urgency. `--no-triage` skips the update-pass |
| `today` | `/agenda today` | Run the triage update-pass (confirmation walk, 24h), then today-only briefing: overdue + due-today TODOs and same-day-urgent email. Also writes a data feed for the local browser view (`agenda/publish/data/today.js`) and prints a clickable `file://` link to `agenda/publish/index.html`. `--no-triage` skips the update-pass; `--no-html` skips the browser view; `--no-invest` skips the `/invest` scan (holdings + weekly pick in the browser view's Investment section); `--no-ai-releases` skips the AI release watch (browser view's AI Releases rail + Anthropic major-announcement banner); `--no-calendar` skips the Google Calendar fetch (browser view's Schedule band — month calendar + Appointments); `--no-topstories` skips the NYT + FT top-news fetch (browser view's Top Stories rail); `--no-research` skips the `/research` content-idea scan (browser view's Research Radar section) |
| `triage` | `/agenda triage` | Scan email + Quo + Slack + dateless TODOs; propose DEADLINE additions, deadline updates, and new TODOs; apply confirmed writes |
| `index` | `/agenda index [subcommand]` | Manage the account-routing index (email/phone → project) |
| `cleanup` | `/agenda cleanup` | Mark dateless TODOs as DONE |
| `review` | `/agenda review [file]` | Show all TODOs for one project |
| `sync` | `/agenda sync` | Bare org file-sync with Google Drive: run the Server sync bracket (pull → gated-delete incoming → push → gated-delete outgoing) standalone, no triage/assessment. Only acts when `AGENDA_SOURCE=server`; `local`/unset is a no-op advisory |

---

<!-- origin: user | added: 2026-05-18 | immutable: true -->
## Directives

> **Chart-first agenda display.** After all the information is put together for the agenda (and everything is updated as needed in the org files), a paragraph or two synopsis is fine, but show what's needing done in chart form, separated by client, with the highest priority items at the top. Email, text and call correspondence may influence the temporary prioritization of certain tasks. This is all part of the agenda display.

> **Awaiting Correspondence section.** There needs to be a section on awaiting correspondence — outbound items where a reply is pending.

> **Clarifications Needed section.** Based off the assessment collected, there may need to be some correspondence made for clarifications. That needs a section all its own — proposing the question and the recipient.

*— Added 2026-05-18, source: user instruction (via /route to /skill-builder optimize agenda)*
<!-- /origin -->

<!-- origin: user | added: 2026-06-26 | immutable: true -->

> **Check `AGENDA_SOURCE` before accessing org files.** Before touching any org file, read `AGENDA_SOURCE` from `.env.local` and resolve the org directory from it: `local` (or unset) → the local org directory; `server` → the synced server org directory (`ORG_DIR`, kept in sync with Google Drive). Any other value → stop.

*— Added 2026-06-26, source: user instruction (via /route → /skill-builder inline; local/server source switch). Reworded 2026-06-26 to wire the `server` source — deliberate checksum override, user-approved.*
<!-- /origin -->

<!-- origin: user | added: 2026-04-03 | immutable: true -->

> **Pre-approved operations:** All org file reads and edits are pre-approved. Do not ask for permission to scan or modify TODO states in org files.

> **Never output credentials or secrets.** Org files may contain server credentials, passwords, API keys, and connection strings. Never display, copy, relocate, or include these in any output. When showing TODO items, show only the headline text.

> **Always query both inboxes.** When gathering email context for `priorities` or `today`, query Gmail (MCP) AND iCloud (IMAP) every time. iCloud credentials are configured in `.env.local`. Never skip an inbox.

> **Triage writes are confirmed, never silent.** In `triage` mode, every proposed change to an org file (DEADLINE addition, deadline update, new TODO, body note) goes through user confirmation before any Edit. The orchestrator collects all proposals first, then walks them with the user. No write happens before approval.

> **Auto-created TODO headlines end with the creation date.** Use the project's existing format: `** TODO <headline text> <YYYY-MM-DD Day>`. The DEADLINE goes on the next line. Auto-created TODOs include a 1–3 sentence summary in the body capturing the signal that prompted them. Never include the source URL or message ID.

> **Prefer updating an existing TODO over creating a new one.** When a triage signal references the same project AND refines an existing task (new deadline, status update, new info), append a dated note `- YYYY-MM-DD: <text>` under the existing TODO body instead of creating a new TODO. If the existing body contains credential-shaped content (the `triage-write-guard.sh` hook will detect this), drop the update to the unmapped report and require manual editing.

> **Never remove anything that has time attached to it.** Org-mode `:LOGBOOK:` blocks and `CLOCK:` entries (billable / time-tracked work) must be preserved through every operation. No keyword swap, no archive, no cleanup, and no triage write may decrease the count of `CLOCK:` lines under any heading. The `triage-write-guard.sh` hook enforces this — an Edit whose new_string has fewer CLOCK entries than its old_string is blocked. Cleanup Phase 2 (archive) skips any DONE item whose subtree contains `CLOCK:` entries; those stay in the source file regardless of age.

*— Added 2026-04-03, source: user instruction*
*— iCloud directive added 2026-04-20, source: user instruction*
*— Triage directives added 2026-05-06, source: user instruction*
*— Time-data preservation directive added 2026-05-06, source: user instruction*
<!-- /origin -->

<!-- origin: user | added: 2026-06-22 | immutable: true -->

> **Assessment modes freshen org files first.** Before `priorities` or `today` produce their assessment, they run the triage update-pass — the same signal-gather → classify → **confirmation walk** → confirmed-write sequence as `triage` mode — so the org files reflect the latest email, text, and call correspondence, then score against the freshened TODOs. The triage confirmation walk runs verbatim; no write happens without per-item user approval. A user may skip the pass with `--no-triage`. When the pass proposes nothing, it is a silent no-op.

*— Added 2026-06-22, source: user instruction ("wire it with the confirmation walk")*
<!-- /origin -->

<!-- origin: user | added: 2026-07-01 | immutable: true -->

> **Calendar invites in triage.** During the triage update-pass, detect meeting/calendar invitations in the email scan (calendar/appointment invites from any sender — including but not limited to SBDC, e.g. `sbdc.org`/`oregonsbdc.org`). For each new invite, propose a Google Calendar event as a triage write — created via `/google-calendar` (event mode), carrying the invite's title, date/time, and location/link. Like every triage write it goes through the confirmation walk (never silent) and is skipped when a matching event already exists. Calendar-event creation is an additional triage output alongside DEADLINE additions and new TODOs; agenda never writes the event itself.

*— Added 2026-07-01, source: user instruction (inline; broadened from SBDC-only to all meeting invites per user selection)*
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Calendar invites in triage." (2026-07-01). -->
CHECKPOINT — Calendar-Invite Gate (fires during triage Steps 3–6; also when triage runs as the priorities/today update-pass):
1. When the triage-classifier returns a `calendar-invite` classification, treat its `proposed_event` as a proposed calendar write and surface it in the confirmation walk as a `[+ EVENT]` proposal alongside DEADLINE/TODO/NOTE proposals. It is NEVER silent — the immutable "Triage writes are confirmed, never silent" directive governs calendar writes too.
2. DEDUP before proposing: query existing events for the event's date via `/google-calendar agenda` (Skill dispatch). IF a matching event exists (same date + overlapping title) → drop the proposal silently; never double-book.
3. Applying a confirmed calendar-invite is a `/google-calendar event` dispatch through the Skill tool — NOT an org-file Edit, and NOT subject to `triage-write-guard.sh`. Agenda never writes the event itself. IF any step attempts to write the event into an org file → STOP; route it to `/google-calendar`.
4. A calendar-invite is independent of TODO matching: it never suppresses a `new-task`/`body-update` the same message also warrants, and vice-versa.
5. IF `proposed_event` has a date but no time → carry the date into the confirmation walk and confirm the time with the user before dispatch; never invent a time.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- origin: user | added: 2026-07-01 | immutable: true -->

> **Opportunity scan on assessment runs.** When `today` or `priorities` runs, after the triage update-pass and before the chart is assembled, also fire `/opportunity-scout --quick` — UNLESS a scout already ran in the last ~18h (dedup on repeated same-day calls) or `--no-scout` was passed. Fold its "new since last run" result into the briefing as an **Opportunities** section (placed after Clarifications Needed): the fit-tier-grouped new/changed items, or "None new at the moment." Discovery-only — agenda never contacts anyone on the scout's behalf, and never blocks the briefing on it.

*— Added 2026-07-01, source: user instruction (inline; integrate opportunity-scout into agenda assessment runs — today + priorities, `--quick` + 18h guard, folded Opportunities section, per user selection)*
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Opportunity scan on assessment runs." (2026-07-01). -->
CHECKPOINT — Opportunity-Scan Gate (fires in today and priorities, between the triage update-pass and chart assembly):
1. AFTER the triage update-pass completes and BEFORE the chart is assembled, fire `/opportunity-scout --quick` via the Skill tool — an explicitly-named dispatch (the Route Consultation gate is satisfied; do NOT freelance web search here).
2. GUARD — skip the scout dispatch IF ANY of: `--no-scout` was passed; OR the opportunity-scout run-state (`opportunity-index.md` top marker `last-run`) is within the last ~18h. On a guard-skip, still render the Opportunities section from the existing index (new-since-last-run = none; show current open highlights).
3. Fold the result into the briefing as an **Opportunities** section placed AFTER "Clarifications Needed": the fit-tier-grouped new/changed items from this run, or "None new at the moment." when empty.
4. NON-BLOCKING + discovery-only: agenda never contacts anyone via the scout; a scout failure degrades to "Opportunities: unavailable this run" and the agenda proceeds.
5. `--no-triage` and `--no-scout` are independent — neither implies the other.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- origin: user | added: 2026-07-13 | immutable: true -->

> **Slack in triage.** *"I have a really useful skill called agenda triage that pulls in quite a few correspondence points to keep my tasks up-to-date. I'd like to add slack to the mix."* — *"keep in mind. I'll have multiple acounts I'm pulling in data for."* Slack is a triage signal source alongside email and Quo: during signal gathering, sweep mentions + DMs across every configured Slack workspace account via the `/slack` skill's shared `slack-fetch.sh review` script (tokens live in `.env.local` as `SLACK_TOKEN_<label>`, never in skill files). When no Slack token is configured, the source is skipped silently — never blocking, never nagging.

*— Added 2026-07-13, source: user (skill creation request for /slack + agenda wiring, via /route → /skill-builder; multi-account instruction same session)*
<!-- /origin -->

<!-- origin: user | added: 2026-07-20 | immutable: true -->

> **Never name a counterparty the source data didn't name.** *"but Barak has nothing to do with Broom21"* — *"I can't even find the email"*

*— Added 2026-07-20, source: user bug report (inline). The user's words above are verbatim; the rule text below is machine-authored from that report and is NOT the user's wording.*

Derived rule (machine-owned): a person's name may appear in an **Awaiting Correspondence** `to`, a **Clarifications Needed** `recipient`, or a task `signal` ONLY when that exact name is present in an artifact actually fetched this run — the message thread itself (Quo/email/Slack), the org body note, or the account-index block for that project. Never infer identity from an adjacent table row, from who is frequently involved in other projects, or from the project's usual contact. When no name is attested, say so honestly (`Broom21 contact (+1-503-201-8088)`) and leave the name field null — **degrade, never drop**: the pending item still surfaces, only the invented name disappears. Absence from the account index is NOT grounds to drop a row; a brand-new contact named in an SMS is fully attested.

This is enforced structurally, not by prose: `AwaitingRow.to` and `ClarificationRow.recipient` are nullable in [`agenda/src/types.ts`](../../../agenda/src/types.ts) and each carries a required `toSource` / `recipientSource` provenance pointer whenever the name is non-null. `renderAwaiting` / `renderClarifications` in `agenda/src/main.ts` DROP any row asserting a name without its source, the same way an undated opportunity is dropped. Filling the name now costs a second field that must be derived from real fetched data.
<!-- /origin -->

<!-- origin: user | added: 2026-07-23 | immutable: true -->

> **Research Radar in the today newspaper.** *"add the research option for both AI Transformation and Field Notes sections? then include those two sections in my agenda newspaper with the most relevant topics ... a brief explanation on why the article matters ... links to each of the articles (webpages) that makes this idea stand out ... take the article info and the citations and copying them over to notebookllm ... to help me decide on newsworthy articles."* — *"to publish on my website"*

*— Added 2026-07-23, source: user feature request (via /route → /skill-builder intent-router). Approach "research rail in the agenda newspaper" and scope "research / decision aid only" ratified via AskUserQuestion this session. The user's words above are verbatim; the rule below is machine-authored from that request and is NOT the user's wording.*

Derived rule (machine-owned): the `today` browser view (the "newspaper") carries a **Research Radar** section with two category groups — **AI Transformation** (from `/research transformation`) and **Field Notes** (from `/research fieldnotes`). Each group lists the most relevant / newsworthy candidate topics for that focus category; each topic carries (1) a one-to-two-sentence why-it-matters line and (2) links to the fully-read source article(s) that make the idea stand out — formatted so the topic + citations can be copied into NotebookLM to evaluate newsworthiness. Gathered in [today-workflow.md](references/today-workflow.md) Step 5.10 and rendered from `AgendaData.research` ([`agenda/src/types.ts`](../../../agenda/src/types.ts)); the `--no-research` flag skips the gather, and the section stays hidden when empty. This rail is **discovery / decision-aid only** — it never drafts or publishes; article creation stays with `/focus`. Every citation obeys the `/research` read-before-cite directive (no snippet-only sources).
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Slack in triage." (2026-07-13). -->
CHECKPOINT — Slack Signal Gate (fires during triage Step 1; also when triage runs as the priorities/today update-pass):
1. During Step 1 signal gathering, IF at least one `SLACK_TOKEN_<label>` (or legacy `SLACK_USER_TOKEN`) is set in `.env.local` → run `bash .claude/skills/slack/scripts/slack-fetch.sh review --since <window-start-ISO8601>` alongside the email and Quo fetches, honoring the caller's window (today = 24h, priorities = 48h, standalone triage = 7d / 168h). Triage calls the script DIRECTLY — never through the interactive `/slack` skill (the quo-fetch.sh precedent).
2. IF no Slack token is configured → skip this source silently. No warning, no block, no setup nag.
3. The returned `mentions[]` and `dms[]` join the signal payload as `slack` signals. Route each by matching `from` (the sender's real name) case-insensitively against the account-routing index `:ALIASES:` values; unmapped senders land in the unknown-contacts report, same as email/Quo.
4. Slack is READ-ONLY input: agenda never posts to Slack and there is no Slack write path. Proposals derived from Slack signals go through the same confirmation walk as every other triage write.
5. A slack-fetch failure (auth, network, scope) degrades to "Slack: unavailable this run" in the report and triage proceeds — never abort the pass over a source failure.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directives: "Chart-first agenda display..." (2026-05-18), "Awaiting Correspondence section" (2026-05-18), "Clarifications Needed section" (2026-05-18). -->
CHECKPOINT — Chart Output Gate (priorities and today modes; triage and other modes keep their own output contracts):
1. Before emitting the agenda to the user, verify the draft contains all five structural elements in order:
   a. **Synopsis** — 1 to 2 short paragraphs of plain prose at the top.
   b. **What's Needing Done** — a table grouped by client/project. Highest-priority items at the top of each group. Clients ordered most-urgent-first.
   c. **Awaiting Correspondence** — a table of outbound items where a reply is pending.
   d. **Clarifications Needed** — a table of questions Francis should send out before work can advance.
   e. **Opportunities** — the `/opportunity-scout` result folded in per the Opportunity-Scan Gate (fit-tier-grouped new/changed items, or "None new at the moment."). Present on today/priorities runs unless `--no-scout` disabled it; a scout failure renders "Opportunities: unavailable this run" rather than omitting the heading.
2. IF the synopsis is missing OR longer than 2 paragraphs → STOP. Trim or write the synopsis.
3. IF "What's Needing Done" is not a Markdown table OR is not grouped by client (per-client subheader or grouping column) OR is not priority-ordered within each client → STOP. Restructure.
4. IF a recent email / Quo SMS / Quo call from a client mentions urgency, a new deadline, or an explicit ask → that client's next action MUST appear at or near the top of its group with the correspondence cited in the Signal/Context column. Failure to elevate = STOP and re-sort.
5. IF "Awaiting Correspondence" section is missing → STOP. Assemble it from the outbound-message scan (see Workflow: Priorities, Step 4).
6. IF "Clarifications Needed" section is missing → STOP. Assemble it from the assessment gaps surfaced in Step 5.
6b. IF either of those two tables was hand-authored rather than pasted from `scripts/attribution.py` stdout (today-workflow.md § Step 5.95) → STOP and render them through the script. Those are the only two sections that assert a person's identity as something to act on, and both outlets must descend from the same validated rows. A named counterparty with no resolvable provenance pointer is dropped there — degrade to an unnamed org label, never silently lose the item. (2026-07-20 incident.)
7. IF either new section legitimately has zero items, emit the section heading with a single-line "None at the moment." rather than omitting the heading.
8. IF all conditions pass → CONTINUE and emit the agenda.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Assessment modes freshen org files first." (2026-06-22). -->
CHECKPOINT — Freshness Gate (priorities and today modes; runs BEFORE the Chart Output Gate):
1. IF mode is `priorities` or `today` AND `--no-triage` (alias `--no-update`) is NOT set → the triage update-pass (triage-workflow.md Steps 1-6) MUST have run, against the signals gathered this turn, before any baseline score is consumed by the assessment. Skipping it = STOP and run the update-pass.
2. IF the triage pass proposed ≥1 change → the confirmation walk (triage Step 5) MUST have executed and each write MUST have been individually approved. A silent write = STOP (violates the immutable "Triage writes are confirmed, never silent" directive).
3. IF ≥1 triage write was applied → the affected org files MUST be re-read and re-scored before the assessment ranks anything. Scoring stale (pre-write) data = STOP and re-read.
4. IF the change set was empty (no proposals) → the pass is a silent no-op: emit no "nothing to triage" banner and proceed straight to the assessment on the already-current Step 1 scan (no re-read needed).
5. IF `--no-triage` is set → skip the update-pass entirely and assess against the Step 1 baseline scan as-is.
6. After this gate passes, the Chart Output Gate runs against the freshened data.
<!-- END ENFORCEMENT ANNOTATION -->

---

<!-- origin: skill-builder | version: 1.1 | modifiable: true -->
## Workflow: Priorities

Scan org files plus recent email, SMS, and call signals to build a complete picture, run the triage update-pass (confirmation walk) so the org files reflect the latest correspondence, apply correspondence-driven priority bumps, then present the agenda as a synopsis + chart grouped by client + Awaiting Correspondence + Clarifications Needed.

**Grounding:** Read [references/priorities-workflow.md](references/priorities-workflow.md) for the full procedure (Step 1 org-data scan, Step 1b triage update-pass with confirmation walk, Step 1c re-read + score, Step 2/2b email + Quo signal gathering, Step 2.5 untracked-request scan, Step 3 correspondence-driven priority bumps, Step 4 Awaiting Correspondence, Step 5 Clarifications Needed, Step 6 synopsis + chart presentation). The Freshness Gate and Chart Output Gate above enforce the update-then-assess ordering and the output structure. `--no-triage` skips Step 1b.

## Workflow: Today

**Grounding:** Read [references/today-workflow.md](references/today-workflow.md) for the full today-only briefing procedure (org-data today filter, Step 1b 24h triage update-pass with confirmation walk, Step 1c re-read + score, 24h email + Quo scope, same chart-first contract as `priorities`, Step 7 browser-view render). `--no-triage` skips Step 1b; `--no-html` skips Step 7; `--no-invest` skips the Step 5.6 investment scan; `--no-ai-releases` skips the Step 5.7 AI release watch ([references/ai-releases.md](references/ai-releases.md) — six fixed vendor feeds deduped against a permanent seen-index → browser view's AI Releases rail + Anthropic-only major-announcement banner); `--no-calendar` skips the Step 5.8 Google Calendar fetch (browser view's Schedule band — interactive month calendar + Appointments panel, via `/google-calendar`); `--no-topstories` skips the Step 5.9 NYT + FT top-news fetch (browser view's Top Stories rail); `--no-research` skips the Step 5.10 `/research` content-idea scan (browser view's Research Radar section, per [references/today-workflow.md](references/today-workflow.md) Step 5.10).

After the terminal briefing, `today` also writes the same content as a data feed for a local browser view and prints a clickable `file://` link — the terminal output is cluttered to read directly. This is additive and non-blocking (the terminal briefing is unchanged and primary). The viewer is a committed Tailwind + TypeScript app at the repo root in `agenda/` (built to `agenda/publish/`, opens from a `file://` link, no server); the render step writes `agenda/publish/data/today.js` and the page renders it. The write procedure is [references/html-render.md](references/html-render.md); the data contract is [`agenda/src/types.ts`](../../../agenda/src/types.ts).

## Workflow: Cleanup

**Grounding:** Read [references/cleanup-workflow.md](references/cleanup-workflow.md) for the two-phase cleanup procedure (Phase 1: mark dateless TODOs as DONE; Phase 2: archive DONE items older than 6 months).

## Workflow: Review

Show all TODOs for a specific project file.

1. **Resolve file** — Match the argument to an org filename (fuzzy: `tt` matches `tickettomato.org`, `oa` matches `odysseyalive.org`). If ambiguous, ask.
2. **Extract** — Pull all TODO headlines with their depth level, dates, and DEADLINE/SCHEDULED
3. **Present** — Display organized by heading hierarchy using the "Review Output" format in [references/output-formats.md](references/output-formats.md) § "Output Formats"
4. **Summary** — Total TODOs, overdue count, dateless count

## Workflow: Triage

**Grounding:** Read [references/triage-workflow.md](references/triage-workflow.md) for the full triage procedure (signal gathering, index routing, classification, change-set assembly, confirmation walk, write application, reporting).

## Workflow: Index

Direct management of the account-routing index at `references/account-index.org`. See [references/integrations.md](references/integrations.md) § "Account-Routing Index" for the full schema.

### Subcommands

| Command | Action |
|---------|--------|
| `/agenda index` | Show summary: project count, contact counts per project, last-modified time |
| `/agenda index add <email-or-phone> <project-slug>` | Add a contact to a project block (idempotent — duplicates skipped) |
| `/agenda index seed-congo` | Run `bash scripts/seed-congo-from-pdf.sh` to bulk-import congregational contacts from the latest PDF in `~/Documents/win10/` |
| `/agenda index review-unknowns` | Replay unmapped signals from the most recent triage report and prompt for assignment |

For `add`, infer phone vs email by content (`@` present → email, else digit-extracted as phone). Validate that the project slug matches an existing block in `account-index.org` — if not, ask whether to create a new block.

## Workflow: Sync

Run the **Server sync bracket** standalone — a bare org file-sync between the local org dir and Google Drive, with no triage, scan, or assessment. This exposes the same bracket the assessment/triage modes (and a chained `/timesheet`) run internally, for when you just want to reconcile the org files with Drive.

1. **Resolve source** — read `AGENDA_SOURCE` + `ORG_DIR` from `.env.local` (per [references/org-format.md](references/org-format.md) § Source Resolution).
   - `local`/unset → **no-op advisory**: an external syncer owns the org dir; report that there is nothing for `/agenda` to sync and stop.
   - any value other than `local`/`server` → **STOP**; report `AGENDA_SOURCE` is unrecognized.
   - `server` → continue to Step 2.
2. **Run the bracket** (per [references/org-format.md](references/org-format.md) § Server sync bracket), in order, via `scripts/org-sync.sh`:
   a. **Pull** `bash scripts/org-sync.sh pull`. A failed pull → **STOP** (never push over an unsynced remote).
   b. **Incoming deletions** `bash scripts/org-sync.sh deletions` → **ask before any `delete-local`** (AskUserQuestion; deletions are always user-confirmed, never silent).
   c. **Push** `bash scripts/org-sync.sh push`.
   d. **Outgoing deletions** `bash scripts/org-sync.sh deletions` → **ask before any `delete-remote`**.
3. **Report** what moved each way and any deletions confirmed/declined.

Standalone-only: unlike the assessment modes, `sync` does no signal-gather, scoring, or org writes of its own — it only moves existing files. The bracket still runs **once per run**; do not re-run it from a chained skill in the same turn.
<!-- /origin -->

<!-- origin: skill-builder | version: 1.0 | modifiable: true -->
## Grounding

Before accessing org files, **resolve the source first** — read `AGENDA_SOURCE` + `ORG_DIR` from `.env.local` and follow [references/org-format.md](references/org-format.md) § Source Resolution: `local`/unset → read `ORG_DIR` directly; `server` → run the **Server sync bracket** (pull → gated-delete incoming → read → push-if-written → gated-delete outgoing; **deletions are always user-confirmed via AskUserQuestion**, never silent); any other value → STOP. The bracket runs **once per `/agenda` run** — a chained `/timesheet` must not re-run it. Then read org-format.md for the directory path, date patterns, and TODO keyword rules, and state: "I will scan [PATH] for [PURPOSE]". Other domains live in `references/signals.md` (signal types and classifier categories), `references/integrations.md` (email/Quo/Slack REST + account-routing index), `references/output-formats.md` (briefing, review, triage proposal, bulk-decision codes), `references/html-render.md` (the additive `today` browser-view data feed for the committed `agenda/` viewer), `references/security.md` (write allow-list and credential guard), and `references/triage-workflow.md` (the full triage orchestration when running `/agenda triage`).
<!-- /origin -->

---

## Discovered Issues Log

### 2026-07-20 — Awaiting Correspondence invented a counterparty; existing check #1 also failed *(RESOLVED 2026-07-20)*

**Symptom:** The `today` briefing's first Awaiting Correspondence row read "Barak Tutterrow (H1 Websites) — Ionos account 2FA code for Broom21 site access, asked Jul 14 · 6 days out." The user: *"but Barak has nothing to do with Broom21"* and *"I can't even find the email."*

**The index was NOT at fault** (the user's first hypothesis, and the obvious one to check): `account-index.org`'s `* broom21` block lists only van@broom21.com / whiteglove@broom21.com / +1-503-201-8088; `index_lookup_phone` for Barak's number returns mjbowmanllc/dynamicmotorsports/amishfurniture and never broom21; "Barak" appears nowhere in `broom21.org`.

**Two independent failures in one row:**
1. **Fabricated counterparty.** The org note the row was built from says only `- 2026-07-14: SMS thread w/ broom21 contact …` — no person is named. The real Quo thread is Francis (+1-971-257-5489) ↔ +1-503-201-8088 (Van/Zach at Broom21). The name "Barak Tutterrow" was borrowed from the three adjacent Barak rows in the same table. Root cause is not a missing rule but **required-field completion pressure**: `AwaitingRow.to` was a non-optional string, there was no representable value for "counterparty unknown," so the highest-probability in-context string got laundered into the field — structurally identical to the 2026-07-09 opportunity-date bug (undated leads stamped with the found-date to satisfy freshness), which was also fixed structurally.
2. **Check #1 ("No reply exists") was violated — and it already existed.** The thread shows Francis asking for the code 7/13 23:43, the contact answering 7/14 01:04 *"Sorry I just saw the message. And I don't see a code."*, then two further unanswered Francis outbounds. A reply existed and the ball was back with Francis, so this was never an awaiting item — it is a follow-up Francis owes. Note the lesson: check #1 was added after the 2026-07-09 "Amy" incident, sat three lines above the row it governed, and failed anyway eleven days later. **A third prose check would have been theater.**

**Fix (structural, plus the directive):**
- `agenda/src/types.ts` — `AwaitingRow.to` and `ClarificationRow.recipient` are now `string | null`, with optional `toOrg`/`recipientOrg` labels and a `toSource`/`recipientSource` provenance pointer (org `file.org:LINE`, `quo:<number>`, email id, Slack ref) **required whenever the name is non-null**.
- `agenda/src/main.ts` — `renderAwaiting` and `renderClarifications` DROP any row asserting a name with no source, mirroring the existing undated-opportunity drop; a null name renders honestly as "Broom21 — unnamed contact". Fabricating a name now also requires fabricating a grep-checkable file:line.
- Clarifications got the same guard deliberately: its `recipient` is an instruction to **send**, so a borrowed name aims a real outbound at the wrong person — higher stakes than a mislabeled backlog row.
- New immutable directive above ("Never name a counterparty the source data didn't name").

**Deliberately NOT done:** gating on "the name must exist in the account index." That would have blocked nothing here (the index is correct and Barak is in it three times) while silently dropping new inbound leads, shared-number contacts, vendor/support queues, and anything from a fresh Slack/email thread — a worse, invisible failure. The test is provenance, not membership.

**Second pass, same day — the first fix only covered one of two outlets.** The renderer guard above protects the *browser view*. The **terminal briefing is the primary output** and is free-form prose with no code path, so the identical fabricated row would still have printed. Worse, the first pass answered a prose-check failure by adding a fourth prose check (a five-sentence Step 4 item) — precisely what the entry above calls theater. Fixed properly:
- **`scripts/attribution.py`** is now the single choke point. It takes the Step 4/5 rows and emits the two finished markdown tables on stdout (pasted verbatim into the terminal briefing) plus a drop report on stderr; `--json` emits the surviving rows for `today.js`. Both outlets now descend from one validated object and cannot diverge. Wired as today-workflow.md § Step 5.95, with Chart Output Gate clause 6b.
- **It resolves, it doesn't just check presence.** An org pointer is opened and the name must appear within ±4 lines; other artifact forms are shape-checked. This matters because the failure was *unaware* fabrication — asking a confident writer to doubt itself fails, so the check must be an observation, not an introspection. Verified: the real defect row (`Barak Tutterrow` + `broom21.org:27`) is dropped, while an attested Barak row, a null-name row, and a brand-new contact carrying `quo:+1…` all survive. A presence-only check would have passed the defect, since the pass that invents a name also invents a plausible `file:line`.
- **Scope held to two sections.** Only Awaiting and Clarifications assert a person's identity as something to act on; the synopsis, client chart, and rails stay hand-written. Step 4's prose shrank from four checks to two plus a pointer, so this pass left the skill *shorter*.
- **Rejected: a PreToolUse hook on `today.js`.** Hooks match Edit/Write but not Bash, and `today.js` is written by a Bash heredoc — that exact bypass happened this same session with an unrelated hook. It would have been theater.
- **Note:** the 2026-07-20 directive block above still describes only the renderer half. It is immutable (`origin: user`), so it was left byte-for-byte intact rather than reworded; this log entry is the fuller record.

### 2026-07-16 — triage classified from the email SNIPPET only; multi-item recap lost 3 of 4 asks *(RESOLVED 2026-07-16)*

**Symptom:** A forwarded Zoom "meeting assets/recap" email from Barak Tutterrow (2026-07-15) carried an explicit **"Next steps for Francis"** list of four action items (contact the AutoBuy vendor `jared@autobuy.com`; compare Liquid Web vs Wind Haven hosting for the estimator; add bed-size selection; add a "standard hardware included" note) plus per-topic summaries. The `today` triage update-pass surfaced only the **first** item (AutoBuy stale-listings); the other three were invisible until the full body was fetched by hand. The user noticed the task lists hadn't been updated.

**Two causes:**
1. **Snippet-only classification.** `email-fetch.sh recent` returns a **~600-char snippet** per message, and Step 3 fed that snippet to the classifier as the signal `body`. Everything past the first ~600 chars — i.e. most of a multi-item recap — never reached the classifier. There was **no full-body fetch path** (`email-fetch.sh` had only `recent`).
2. **HTML-only body.** Zoom meeting-summary emails have an **empty `text/plain` part** (HTML only), so even a naive body read returns nothing; the summary lives entirely in the tag-laden HTML part.

**Fix (three files + this log):**
- **`scripts/email-fetch.sh` — new `get --id <account:uid>` subcommand** returns one message's **full** body (not truncated), preferring `text/plain` and **tag-stripping HTML-only mails** (drops script/style, `<br>`/block-closers → newlines, unescapes entities) so the "Next steps" list survives. Verified against the Barak mail: 4997-char body containing "Next steps", `jared@autobuy.com`, "Liquid Web", and "bed size".
- **`triage-workflow.md` — new Step 1.5 (Deep-read).** Before routing, flag emails that look multi-item (recap/action-list markers in subject/snippet: `next step`, `action item`, `meeting summary/recap`, `assets are ready`, `follow up`, `forwarded message`/`fwd:`, etc. — OR a snippet truncated at the ~590-char cap from an index-mapped sender), fetch their full body via `get --id`, swap it into the signal `body`, and set `deep_read: true`. Bounded so it never full-body-fetches every email (e.g. truncated newsletters are skipped). Step 3 now passes the full body + flag and expects one object per action item.
- **`agents/triage-classifier/AGENT.md` — Multi-item extraction rule.** `deep_read: true` (or a plainly enumerated ask list) → emit **one classification object per action item**, each routed independently through Match Priority (a recap often spans multiple projects), de-duplicated against existing TODOs. Input schema gains `deep_read`; the "one object per signal" framing is relaxed to "one or more."

**Net:** a meeting recap now yields a proposal per action item through the normal confirmation walk, instead of collapsing to its first line.

### 2026-07-13 — triage missed a shared-contact conversation; short lookback window *(RESOLVED 2026-07-13)*

**Symptom:** A multi-day SMS/call thread with Barak Tutterrow (2026-07-09, about the dynamicmotorsports autabuy feed + amish work) never updated the relevant TODOs.

**Two independent causes:**
1. **Shared-contact routing collision.** Barak's number `+1-503-570-4252` (and email `barak@h1websites.com`) is listed in three project blocks — `mjbowmanllc`, `dynamicmotorsports`, `amishfurniture`. `index_lookup_phone`/`index_lookup_email` (`scripts/index-lib.sh`) `exit`ed on the **first** match, always returning `mjbowmanllc` (first in file order) — which has zero active TODOs. So every Barak signal routed to an empty project and the classifier never saw the DMS/amish TODOs it should have updated. **Fix:** both lookups now print **all** matching slugs (`next` instead of `exit`). When >1 slug returns, triage Step 2/3 hands the classifier `candidate_projects[]` (each slug + its TODO set) and it disambiguates by content (site/product/entity), returning the chosen `project_slug`; distinct asks across candidates emit one classification each. Updated: `index-lib.sh`, `triage-workflow.md` Step 2/3, `triage-classifier/AGENT.md` input schema + Match Priority, `integrations.md` helper table, and the `account-index.org` caveat comments (which had *documented* the first-block behavior as a known landmine).
2. **Lookback too short.** Standalone `/agenda triage` scanned only 24h, so a run on the 13th couldn't see the 9th at all. **Fix:** standalone triage window widened to **7 days (168h)** — `triage-workflow.md` line 5 + Step 1 fetch commands, `SKILL.md` Slack gate. The `today` (24h) and `priorities` (48h) daily pre-passes are unchanged (they run daily; widening those re-scans a week each run and lengthens the confirmation walk — left as a follow-up option).

Verified: `index_lookup_phone +15035704252` → `mjbowmanllc / dynamicmotorsports / amishfurniture`; `index_lookup_email barak@h1websites.com` → `dynamicmotorsports / amishfurniture`; unique numbers still return one slug; unmapped returns empty; `bash -n` clean.

### 2026-07-09 — browser view: only the top pick had chart data; stale AI-releases showed as "news" *(RESOLVED 2026-07-09)*

**Symptom:** In the `today` browser view, (1) 7 of 8 investment tickers showed "− vs 200-day" and expanded to "price data unavailable this run" with no chart — only the top pick (MSFT) had a live chart; and (2) the AI Releases rail displayed weeks-old entries (DeepSeek Apr 24, Qwen Jun 22, Anthropic Jun 30/Jul 1) that read as "old news."

**Two causes (both data/procedure, not viewer bugs — verified live in-browser):**
1. **Feed starved to the top pick.** The Step 5.6 capture ran `scripts/ma.py` for the top pick only, so the other 7 `investment.suggestions[]` shipped lean (score/dividend only). The viewer *correctly* degrades a lean suggestion — but that meant 7 dead tickers. **Fix:** enrich EVERY suggestion via `ma.py` (`lastClose/ma20/ma200/maDistPct/series`) — see today-workflow.md Step 5.6 #4.
2. **No freshness window anywhere.** Neither `renderNews` nor `renderAiReleases` filtered by date; the AI rail showed its rolling last-8 regardless of age. **Fix:** added `withinFreshWindow()` + `FRESH_WINDOW_DAYS = 3` in `agenda/src/main.ts`, applied to the fundamental-news rail, the AI-releases rail, **and the Anthropic major-announcement banner** (`renderAnnouncement` — the banner is `first_seen ≤48h`-gated, so a model launched >3d ago but first-seen yesterday leaked a stale-dated band; now suppressed when its `date` is outside the window), all keyed off `dateISO`. Rebuilt `agenda/publish/`. Verified in-browser: all 8 tickers render charts; AI rail shows only Jul 6–9 items; the Jun 30 Sonnet 5 banner is suppressed.

**Test-harness note:** playwright-mcp blocks `file:` navigation, so the viewer must be served over HTTP to inspect it (`python3 -m http.server` from `agenda/publish/`). Chrome HTTP-caches `app.js` aggressively — after a rebuild, load from a **fresh port** (new origin = no cached bundle) or the page silently runs the stale bundle.

### 2026-07-07 — `today` browser view drops Investment + News when `/invest watch` is skipped *(RESOLVED 2026-07-07)*

**Symptom:** In the `today` browser view, the **Investment section rendered empty (header only) AND the News rail disappeared entirely** — recurring ("all the news is gone again"). The terminal briefing looked fine; only the viewer lost both blocks together.

**Two compounding causes:**
1. **Render crash (why BOTH vanished).** The viewer's `renderSuggestion` calls `.toFixed()` on each pick's `lastClose/ma20/ma200/maDistPct`. When `today.js` carried **lean suggestions** (only `stockId/score/dividend`, missing the MA numbers), `.toFixed(undefined)` threw mid-render. Because `render()` runs `renderInvestment` immediately before `renderNews`, the throw killed the news rail too — collateral damage, not a news bug.
2. **Skipped `/invest watch` (why the feed was lean + no FT prompt).** The assessment run **skipped the Step 5.6 `/invest watch` dispatch** (reused a day-old `news.json` to avoid a "redundant" heavy call). That daily News Gather is what (a) establishes the **FT SSO session** — so the FT login was never triggered — and (b) yields enriched suggestions. Reusing left stale FP/Trends news and a lean, crash-inducing feed.

**Fix:**
- **Never skip `/invest watch` on a `today`/`priorities` run unless `--no-invest`.** Reusing `news.json` because it "looks current" is NOT a valid skip — the gather is the daily FT refresh + login trigger + data enrichment, not just a news copy. (Guard also recorded in memory `feedback_agenda-invest-watch-required`.)
- **Enrich suggestions with `scripts/ma.py` before writing `today.js`** so each pick carries `lastClose/ma200/ma20/maDistPct` + `series` (never fabricate — run `ma.py`).
- **Hardened the viewer (durable):** `money`/`pct` in `agenda/src/main.ts` are now null-safe (`—` on non-finite), and `maPanel`'s price/number/chart block is gated behind a `hasPrices` check → a lean/partial feed degrades to "price data unavailable" instead of throwing and taking Investment + News down. Rebuilt `agenda/publish/`. Verified in-browser: both sections render, FT news leads the rail, no console errors.

### 2026-06-25 — write-guard falsely blocks appends whose anchor includes a CLOCK line *(RESOLVED 2026-06-25)*

**Symptom:** During `/agenda triage`, confirmed body-note (Pattern 5) and EOF new-TODO (Pattern 4) writes were blocked ("does not match an allowed agenda write pattern") whenever the `old_string` anchor's tail included a `:LOGBOOK:`/`CLOCK:` block — e.g. appending to `amishfurniture.org`, whose file tail is a CLOCK/`:END:` block. Notes appended after plain prose lines passed; notes appended after a CLOCK line did not.

**Cause:** Patterns 4 and 5 detect a pure append with `${NEW#$OLD}` using **`$OLD` unquoted**, so bash treats it as a glob pattern. CLOCK timestamps contain `[2026-06-24 Wed 16:34]` — the `[...]` is a glob character class, so the literal prefix never strips, `${NEW#$OLD}` returns `$NEW` unchanged, and the `!= "$NEW"` append test fails. Any anchor tail containing a CLOCK line (very common in these org files) silently failed.

**Fix:** Quote the pattern in both checks — `${NEW#"$OLD"}` — so the prefix strips literally, not as a glob. Verified with `bash -n` and by re-applying the two blocked amish writes (stain-colors note + homepage punch-list TODO). Unrelated note: Pattern 4/5 still require `new_string` to reproduce `old_string` byte-for-byte (pure append); anchors ending in trailing whitespace can fail because the editor normalizes it away — pick a clean anchor line.

### 2026-06-05 — `quo-fetch.sh messages` silently returns `[]` (OpenPhone API change) *(RESOLVED 2026-06-05)*

**Symptom:** `quo-fetch.sh messages --since <ISO8601>` returned an empty array for any window, even when SMS existed. `/quo` and `/agenda triage` saw zero text signals.

**Cause:** Three OpenPhone API changes hit at once. (1) `GET /v1/messages` and `GET /v1/calls` now **require a `participants` array** — the script's old query got a 400. (2) `http_get_paginated`'s `jq '.data // []'` swallowed the error body into an empty array, so nothing surfaced. (3) The `since` query param is now **silently ignored** (returns full history); the working filter is `createdAfter`.

**Fix:** `http_get_paginated` now exits 4 with the error body on stderr when a response has no `data` key, and accumulates pages in a temp file (the old `--argjson` merge tripped ARG_MAX on large windows). New `resolve_participants` enumerates active participants per inbox via `GET /v1/conversations?updatedAfter=…`, and shared `fetch_windowed` fetches `/messages` or `/calls` per participant with `participants=` + `createdAfter=`, then dedupes by `.id` (group conversations) and sorts newest-first. CLI interface unchanged (`--since` maps to `createdAfter`), so `/agenda triage` and `/quo` callers need no changes. Verified: 136 msgs / 14 calls over a 2-day window, per-contact counts match the MCP path exactly, bad input fails loudly.

---

### 2026-05-18 — Phase 2 archive blocked by write-guard hook *(RESOLVED 2026-05-18)*

**Symptom:** `/agenda cleanup` Phase 2 (archive DONE items older than 6 months) was blocked end-to-end by `hooks/triage-write-guard.sh`. The hook's allow-list did not include subtree removal, so deleting an archived DONE block from the source `.org` file failed.

**Fix:** Added Pattern 7 to the hook — permits deletion of a complete `** DONE ...` subtree when the `old_string` contains zero `CLOCK:` lines and the deletion ends at a same-or-shallower headline (or EOF). CLOCK-bearing subtrees remain blocked by the upstream time-data preservation check. Documented in `references/security.md`. Verified with 4 hook test cases (clean deletion passes; CLOCK-bearing, TODO-rooted, and partial-body deletions all blocked).

---

<!-- ROUTE-EMBED START — auto-generated by /skill-builder route embed; safe to replace -->
<!-- origin: skill-builder | modifiable: true -->
## Route Consultation

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: /skill-builder route embed. Closes the dispatch-bypass gap: a /route announcement is not a substitute for a Skill tool call, and consulting /route does not license the caller to execute the target skill's procedure manually. -->
CHECKPOINT — Skill Routing Gate:
1. During this skill's workflow, IF a step requires research, web search, lookup, analysis, or any follow-up NOT already covered by an explicit tool or skill name → STOP before improvising.
2. Already-named exception. IF the current workflow step EXPLICITLY names tools or skills (e.g., "use Read", "spawn the X agent", "invoke /[skill]") → execute as written. Do NOT consult `/route` for steps already determined. Skip to your skill's next step.
3. Otherwise → invoke `/route <task description>` via the Skill tool. `/route` reads its index and either returns a target skill or reports "no match."
4. Dispatch Required. IF `/route` returns a target → the IMMEDIATE next tool call MUST be `Skill(skill=<target>, args=<derived>)`. Do NOT execute the target skill's procedure steps yourself with raw Edit / Write / Bash / Task / Agent / Read calls. The target skill's gates (asset backups, agent panels, exit tests, cascade steps, frontend-design reviews, immutable-directive checks) ONLY fire when its SKILL.md is loaded via Skill — running steps manually silently skips every gate.
5. Bypass detection. IF a Skill dispatch was just announced (yours or `/route`'s) and the next tool call is non-Skill work germane to the routed task → STOP. Print verbatim: "Route dispatch announced but Skill call skipped. Invoking Skill tool now." then issue the Skill call.
6. No-match path. IF `/route` returns "no match" → proceed with the most direct, manual approach. Document the gap; the user may want to register a skill.
7. Follow-ups loop back. After the dispatched skill returns, IF further follow-up is needed → consult `/route` again via Skill. Do not freelance the next step.
8. Auto-mode override clause. Auto-mode ("execute immediately", "prefer action over planning") does NOT override clauses 4–5. Auto-mode chooses WHAT to do; once a routing decision is on the table, the only valid next action is Skill invocation.
<!-- END ENFORCEMENT ANNOTATION -->
<!-- /origin -->
<!-- ROUTE-EMBED END -->
