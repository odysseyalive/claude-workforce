# Overbuilt Prose Detection

**Severity: SHOULD FIX (individual) / MUST FIX (clustered — 3+ signals in same passage)**

Overbuilt prose is a recurring AI drift pattern. The drafting agent falls into it even when directives are in context. The test is simple: **read the sentence aloud. If you'd pause to restructure mid-sentence, flag it.**

**Individual signals are not tells. Only clustering is.** A single parallel construction or rhetorical reversal may be deliberate craft. Three or more overbuilt signals in the same passage (2-3 paragraphs) is the actual AI tell — the architecture stacking up in ways no person talks. Flag individual instances as SHOULD FIX. Escalate to MUST FIX only when they cluster.

## Voice Protection

**Before flagging, check the voice profile.** Some patterns that look "constructed" on paper are how the author actually talks. These are protected:

- **First-person discovery openings** ("I keep hearing," "I was reading," "I went looking") — matches voice characteristic #1 (Curiosity-Driven Discovery)
- **Vulnerability and uncertainty** ("I don't know how you prepare," "That's the part I can't get past") — matches The Humility Test and voice characteristic #8 (Measured Skepticism)
- **Conversational rhythm** ("None of them coordinated. They didn't need to.") — matches sentence structure guidance (mix short declarative with longer meditative)
- **Rhetorical questions** ("The interesting part?") — matches voice characteristic #9 (Rhetorical Questions)
- **Progressive argument building** (personal observation → context → broader implication) — matches voice characteristic #5
- **Satirical wit** ("Two hundred and eighty-five billion dollars vanished anyway," "The algorithm was the easy part.") — matches voice characteristic #10. Test: does removing the humor weaken the argument?

If a flagged pattern matches a documented voice characteristic, reduce severity to CONSIDER. The evaluator catches AI drift, not the author's personality.

**Voice protection is individual, not structural.** A protected device still counts toward cluster density totals. Protection reduces individual severity to CONSIDER. Cluster density catches architectural stacking. A passage with 4 individually justified devices still reads as AI. Protection says "this device is the author's personality." Cluster density says "this many devices in this small a space is not." Space them across sections.

## Cluster Density

The difference between craft and AI:

| Density | Severity | Example |
|---------|----------|---------|
| 1 signal in a passage | CONSIDER | A single chiasmus in a reflective paragraph — likely deliberate |
| 2 signals in a passage | SHOULD FIX | Parallel construction + triple cascade — worth noting, may be craft |
| 3+ signals in a passage | MUST FIX | Chiasmus + parallel construction + compound structure + stacked clauses — this is the AI architecture tell |

**The context test:** Ornate prose during a reflective or scene-setting passage is more likely craft. Ornate prose during an urgent or direct passage is more likely overbuilt. Weight severity accordingly.

## Functional Rhetoric

**Before flagging a device, ask: is this doing work the plain version can't?**

Wit, humor, and rhetorical form aren't decoration. They're how the argument lands psychologically. "Squirrel on espresso" in "Finding Tamanawas" lowers the reader's guard so Carl Jung and the collective unconscious can land without resistance. "Wages were going up, taxes were going up, and growth wasn't" in "The Perfect Storm" makes the reader *feel* the economic squeeze — the reversal IS the argument.

| Decorative (flag it) | Functional (protect it) |
|---|---|
| Device exists for show — the plain version carries the same meaning | Device carries meaning the plain version loses |
| Reader notices the technique | Reader feels the effect without noticing the mechanism |
| Remove it and the argument stays intact | Remove it and the argument loses force or the reader disengages |
| Stacked for impressiveness | Earns trust, creates intimacy, or makes complex ideas accessible |

**The test:** Rewrite the flagged sentence as plain prose. If the argument still lands with the same force, the device was decorative — flag it. If something is lost (emotional resonance, reader trust, the feeling of the idea), the device is functional — protect it.

This is especially important for Francis's voice. His wit and humor aren't separate from his arguments. They're the vehicle that makes serious ideas (AI displacement, cultural preservation, economic convergence) accessible to readers who would bounce off academic prose. Stripping the rhetoric strips the persuasion.

## Ungrounded Devices

**Severity: SHOULD FIX**

A literary device (allusion, extended metaphor, borrowed phrase) needs its **ground** within 2-3 sentences. Ground is I.A. Richards' term (1934) for the shared similarity between tenor (the concept) and vehicle (the image). Without it, the device is decorative — the reader has to translate back to the argument with no building block nearby.

**The test:** Can the reader map the device to the argument without reaching? If the concrete referent isn't established within 2-3 sentences, the ground is missing.

| Grounded | Ungrounded |
|---|---|
| Allusion followed by its concrete mapping | Allusion that assumes the reader will connect it to the argument |
| Metaphor whose vehicle echoes language already in the piece | Metaphor whose vehicle introduces a new domain with no anchor |
| Borrowed phrase with the referent restated in the author's own terms | Borrowed phrase left to do the work on its own |

**Why this matters:** Ungrounded devices aren't wrong — they're unanchored. The allusion may be apt, the metaphor may be clever, but if the reader has to supply the connection, the device serves the writer's satisfaction, not the reader's understanding.

## Metaphor Activation

**Severity: SHOULD FIX in key positions (opening, closing, section pivot) / CONSIDER in body**

A metaphor is activated when it enacts the concept — the reader experiences the physical reality of the image. A metaphor is inert when it labels the concept — the reader decodes it back to the literal meaning and gains nothing sensory.

**The test:** Can you swap the metaphor for its literal meaning and lose nothing sensory? If yes, it's inert.

| Activated (protect) | Inert (flag) |
|---|---|
| "cable attached" — sees the physical state, enacts connection | "cable" as decoration — just labels connection |
| "The floor dropped out" — feels the fall | "Things fell apart" — decodes to "it went badly" |
| "He threaded the needle" with specifics of what was threaded | "He threaded the needle" as shorthand for "it was difficult" |
| "The ice was already cracking under them" — hears/sees it | "They were on thin ice" — labels danger without sensory detail |

**Activation means committing to the metaphor's physical reality.** Add the verb, state, or sensory detail that makes the reader see the image instead of translating past it.

**Key positions** (opening line, closing line, section pivots) carry more weight because they're where the reader enters, leaves, or reorients. An inert metaphor in a key position wastes the highest-leverage real estate in the piece.

## What to Detect

| Signal | Example |
|--------|---------|
| **Nested conditionals** | "If X, then Y, and if Y, then Z" |
| **Parallel constructions for rhetorical effect** | "The fear arrives faster than... The bounce arrives faster than..." |
| **Triple-or-more cascades** | "Not X. Not Y. Not Z." used for dramatic build |
| **3+ dependent clauses before the point lands** | Sentences where the reader must hold multiple ideas in memory before the payoff |
| **Chiasmus / rhetorical mirroring** | "He didn't create the storm. He named it." — A-B / B-A reversal structure. AI overuses this for false profundity. |
| **Literary device density** | 5 devices in 5 sentences (chiasmus + metaphor extension + antithesis + epistrophe + false profundity). More than 2 distinct literary devices in a single paragraph is an AI tell. |
| **Stacked appositive chains** | "a market that had been pricing certainty into a business model that was always more fragile than it looked" |
| **Compound structures doing double duty** | One sentence trying to carry two ideas that would land better as two sentences |
| **Front-loaded information density** | One sentence packing timeline, platform, statistic, and context: "I read X's resignation letter the morning it hit X." Let one sentence do one job. |
| **Stripped texture words** | Missing conversational words like "other," "too," "also," "actually" that AI removes as redundant but that make prose sound spoken: "A million people did" vs. "A million other people did, too" |
| **Redundant reintroduction** | Re-introducing, re-naming, or re-explaining something the reader already has from the surrounding text. If a blockquote names Mythos Preview, the next sentence doesn't need "a model called Mythos Preview." If you wrote "None of it was trained for," you don't also need to explain what emerged. Trust the reader to track the conversation. |
| **Temporal scaffolding** | Constructing before/after/by-the-time relationships the narrative sequence already carries: "I'd already X before Y," "By the time X happened, Y was already Z," "After doing X, I realized Y." AI builds chronological scaffolding because it doesn't trust paragraph order to convey sequence. Cut the scaffolding and let the narrative carry the timeline. If the reader can infer the order from where sentences appear, the temporal construction is structural, not informational. |

## Overbuilt vs. Spoken

| Overbuilt | Spoken |
|-----------|--------|
| "Written so that if the crawler extracts it and attributes it, the passage still makes sense standing alone." | "If an AI lifts it out of your page, does it still make sense on its own?" |
| "The citation system rewards what good journalism has always rewarded: claims you can check." | "Turns out AI has the same instinct." |
| "A market that had been pricing certainty into a business model that was always more fragile than it looked." | "Wall Street priced in certainty. The business model was never that stable." |
| "The fear arrives faster than the fundamentals justify. The bounce arrives faster than the recovery warrants." | "Stock drops before the damage is real. Then it recovers before anything's actually fixed." |
| "But your own work is the argument for why the function you held can't go empty." | "But everything you published says someone needs to be doing what you were doing." |
| "His entire career at Anthropic was built on one principle." | "He kept proving the same thing." |
| "Multiple AI models critiquing each other over several rounds converge on more accurate answers than any single model alone." | "When multiple AI models critique each other over several rounds, they land on more accurate answers than any single model." |
| "His team analyzed 1.5 million real conversations and documented what happens when AI stops pushing back." | "His team analyzed 1.5 million real conversations, and what they found is what happens when AI stops pushing back." |

## Why This Matters

Vocabulary can be simple and the sentence can still be overbuilt. The problem isn't fancy words. It's architectural: sentences built like logical staircases instead of things a person would say. Prefer direct questions over embedded conditionals. Prefer two short sentences over one long one that does double duty.
