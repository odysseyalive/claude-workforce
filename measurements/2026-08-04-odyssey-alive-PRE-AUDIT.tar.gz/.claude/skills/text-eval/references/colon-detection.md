# Colon Detection

**Severity: MUST FIX**

Colons used for rhetorical emphasis are an AI tell. Most people don't use them in speech or casual writing. The pattern is always the same: setup clause, colon, punchline. It's a constructed move that sounds like a machine landing a point.

## What to Detect

Search the article body for `:` characters. Exclude frontmatter, URLs, timestamps, and list introductions. Flag every colon that does rhetorical work.

```bash
# Search for colons in body text (skip frontmatter between --- markers)
grep -n ':' [file]
```

**Flag these (rhetorical colons):**
- "The result: a seamless experience"
- "Here's the truth: it doesn't work"
- "And here's the part that should keep everyone up at night: those interactions received higher approval ratings"
- "The most effective use cases depend on exactly what you were building: isolated agents"

**Don't flag these (mechanical colons):**
- List introductions: "Three things matter:"
- Timestamps: "2026-02-17T14:00:00"
- URLs: "https://example.com"
- Dialogue attribution: `"We do better with debate," co-author James Evans said.`
- Image alt text and frontmatter fields

**Required output format:**
```
Colon check: [count] rhetorical colons found
- Line X: "[quoted phrase with colon]"
- Line Y: "[quoted phrase with colon]"
```

If zero found, report: `Colon check: 0 found`

## Fixes

Replace rhetorical colons with:
- A period and new sentence: "The result: seamless." → "The result was seamless."
- A question mark: "Here's the part that matters: X." → "Here's the part that matters. X." or "The part that matters? X."
- Restructuring: "It depends on what you were building: isolated agents." → "It works the same way you did. Isolated agents."
