# Text-Eval Invocation Guide

## Finding Sibling Articles

Before invoking, find the 3 most recent articles in the same category (by date, whether past or future-scheduled) using:
```bash
grep -l 'category: "[same-category]"' content/focus/*.mdx
```
Then sort by date and pick the 3 closest.

## Launch All Three Agents in Parallel

**Agent 1: Character Scanner** (mechanical, no judgment)
```
Task tool with subagent_type: "general-purpose"
Prompt: "Scan this text for prohibited characters: [file path].
Read .claude/skills/text-eval/agents/character-scanner/AGENT.md for instructions.
Return findings in the specified output format."
```

**Agent 2: Prose Evaluator** (voice, overbuilt prose, AI patterns, flow)
```
Task tool with subagent_type: "general-purpose"
Prompt: "Evaluate this text for overbuilt prose and voice alignment: [file path].
Read .claude/skills/text-eval/agents/prose-evaluator/AGENT.md for instructions.
Also read .claude/skills/voice/SKILL.md, .claude/skills/writing/SKILL.md,
and files in .claude/skills/text-eval/references/ for evaluation criteria.
Return findings in the specified output format."
```

**Agent 3: Structure Checker** (cross-article repetition, structure, description)
```
Task tool with subagent_type: "general-purpose"
Prompt: "Check this article's structure and cross-article repetition: [file path].
Read .claude/skills/text-eval/agents/structure-checker/AGENT.md for instructions.
Also read these sibling articles for repetition checking:
- [sibling 1 path]
- [sibling 2 path]
- [sibling 3 path]
Return findings in the specified output format."
```

## Collecting Results

After all three agents return, combine into a unified report using [output-format.md](output-format.md). All MUST FIX flags first, then SHOULD FIX and CONSIDER. Note strengths.
