# Structure Check

For focus articles, cross-reference `/focus` skill.

- [ ] Opens with scene, not thesis?
- [ ] Single unifying thread that recurs?
- [ ] Ideas emerge from experience rather than announced?
- [ ] Sections build momentum, not topic-change?
- [ ] Loop closes at end?
- [ ] Under 600 words?
- [ ] Exactly 2 inline images (plus hero)?

## Description/Summary Check

- [ ] Creates curiosity gap rather than explaining content?
- [ ] Uses inviting language ("Step into...", "Discover...") rather than declarative?
- [ ] Avoids "This article explores..." or "Learn how..." framing?
