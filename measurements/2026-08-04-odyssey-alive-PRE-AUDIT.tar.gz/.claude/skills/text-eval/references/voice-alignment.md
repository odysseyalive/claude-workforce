# Voice Alignment

Cross-reference `/voice` and `/writing` skills for full guidelines.

| Criterion | What to Flag |
|-----------|--------------|
| **First-person presence** | Missing "I" in first three paragraphs. Reads like observation from nowhere. |
| **First-person sustain** | Author appears early but vanishes for the rest of the article. If "I" appears only once or twice in the entire body, the piece reads like a research briefing, not a person thinking out loud. Flag when first-person markers are absent from the middle and closing sections. **Remediation: ask Francis how he encountered the material or what stopped him, then use his actual words. Never invent a personal connection to fix this flag.** |
| **Discovery framing** | Data and studies introduced as announcements ("Researchers found...") rather than encounters ("I've been sitting with a study that..."). Francis discovers things — he doesn't present them. **Remediation: reframe how the data is introduced (e.g., "I've been sitting with a study" vs. "Researchers ran an experiment"), but do not invent how Francis found it. If unsure, ask him.** |
| **Fabricated experience** | First-person claims about Francis's actions, clients, or experiences ("I've watched this with clients," "I worked on a project where...") that were not explicitly provided by the user. Text-eval should flag any first-person experience claim that doesn't trace back to something Francis actually said in the session. The writing skill directive is clear: "Never fabricate Francis's actions or experiences." Strong first-person presence is good, but only when it's real. |
| **Overcorrection swing** | When fixing a flagged issue (thin voice, vague reference, etc.), the fix introduces a new problem in the opposite direction — fabricating experience to add voice, adding hyperbole to replace vagueness, over-explaining to fix ambiguity. The remediation for any flag must not create a new flag. When unsure how to fix something without introducing a new problem, ask Francis. |
| **Texture and specificity** | Abstract nouns without concrete grounding. "Innovation" without the innovator. |
| **Metaphors doing work** | Decorative metaphors that don't carry conceptual weight. |
| **Invites vs. explains** | Descriptions that summarize rather than create curiosity gaps. |
| **Rhythm variation** | All sentences similar length. No mix of short declarative and longer meditative. |
| **Staccato opening** | First three paragraphs are all short and declarative, reading like bullet points. Openings must breathe. |
| **Cold concept drops** | Borrowed phrase or framework introduced without grounding the reader in how the author encountered it. |
| **Approachable complexity** | Technical jargon without grounding. Francis makes difficult concepts accessible through everyday experience while keeping wit and humor. "Three layers deep with no breadcrumbs" works; "recursive self-orchestration with context compression" doesn't. |
