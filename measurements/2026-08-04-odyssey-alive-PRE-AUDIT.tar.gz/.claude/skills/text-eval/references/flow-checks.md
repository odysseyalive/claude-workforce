# Flow and Connectivity Checks

Scan for passages where ideas collide without connective tissue. The reader shouldn't have to build the bridge between sentences.

| Pattern | Example | Problem |
|---------|---------|---------|
| **Orphaned statements** | "Then I added X. Y has a texture." | Reader must infer that X relates to Y. Make the connection explicit. |
| **Compressed bullets as prose** | Short declarative sentences that read like a list pretending to be paragraphs | Missing the "because", "which means", "so that" connectors |
| **Ungrounded borrowed concepts** | A quoted phrase from a source appears in the opening with no context for how the author found it, then gets reused in the next section as if the reader already owns it | The reader hasn't been given time to arrive at the concept |
| **Topic collisions** | Sentence A introduces concept, Sentence B assumes understanding | No bridge explaining how A leads to B |
| **Dangling references** | "I wrote about this recently." (no link), "This is where X comes in." (vague "this") | Reader doesn't know what "this" or "it" refers to |
| **Product/tool drops** | Beautiful insight immediately followed by "I use Tool X for this" | Tonal whiplash; promotional feel breaks the flow |

**When flagging flow issues:**
```
**Flow break** — Lines X-Y: "[quoted passage]"
- Reader must infer: [what the reader has to figure out]
- Suggestion: [how to make the connection explicit]
```

**Why this matters:** Punchy, short sentences feel dynamic but can become jerky when the implicit logic isn't obvious. The goal is prose that flows, not bullet points in paragraph form.
