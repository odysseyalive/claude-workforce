# Copy-Truth Dimension (interface copy only)
<!-- Enforcement: HIGH — applied by the structure-checker agent ONLY when the text under evaluation is user-facing UI copy with a known render context. -->

text-eval normally evaluates prose where there is no rendered surface (focus articles, newsletters, correspondence) — copy-truth does not apply there. This dimension fires **only** when the text under evaluation is user-facing interface copy (a component string, hero, button/aria label, empty-state, form-status message, or email) AND its render context is known. Otherwise, skip it silently — do not PASS-noise on every article.

## When to apply
Apply IF the evaluation target is interface copy with a known component/flow. Skip IF it is body prose, or if no render context is available (note "copy-truth: not applicable — no render context").

## What to check
A condensed form of `/copy-truth`'s two passes (full procedure: `.claude/skills/copy-truth/references/ground-truth-model.md`):

1. **Functional-vs-brand scope gate.** Only falsifiable functional claims are in scope. Brand/aspirational copy ("AI automation that understands how your business actually works") is out of scope for claim-vs-behavior.
2. **Claim-vs-behavior (Pass A).** Reconstruct what the interface lets the visitor do, and what each action actually accomplishes, from the component's conditional branches, submit handler, and server action — do NOT trust the copy's self-description. A string that tells the visitor an action did something it didn't (e.g. "Subscribe and you're on the list" when signup runs a double opt-in that stays pending until confirmed) is **MUST FIX**. Since the site has no login, the common defect is claim-vs-*outcome*, not claim-vs-permission.
3. **Referential clarity (Pass B).** Every pro-form resolves to a single antecedent; check coordination/attachment. Ambiguous → **SHOULD FIX**, escalating to MUST FIX when the competing readings differ in truth value.

## Severity and the counterbalance gate
Report in the shared MUST FIX / SHOULD FIX / CONSIDER vocabulary. A copy-truth claim-vs-behavior MUST FIX is never demoted by the human-presence directive (text-eval SKILL.md): human-presence scoring never lowers it. Whether prose sounds human has no bearing on whether a UI claim is true.

## Escalation
For a deep pass, the orchestrating skill should delegate to `/copy-truth check <file:line>`, which spawns the context-isolated `interface-claim-auditor`. This dimension is the lightweight in-line check; the standalone gate is authoritative.
