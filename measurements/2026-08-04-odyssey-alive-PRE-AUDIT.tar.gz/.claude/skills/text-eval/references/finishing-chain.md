# Content Finishing Chain

Shared protocol for all content skills. Replaces ad-hoc text-eval instructions.

---

## The Chain

### 1. Run text-eval

Invoke `/text-eval` on the content (three agents in parallel, per `invocation.md`).

### 2. Triage

| Severity | Action |
|----------|--------|
| MUST FIX | Mandatory. Cannot ship with unresolved MUST FIX flags. |
| SHOULD FIX | Mandatory. Fix unless there's a deliberate craft reason not to. If skipped, state why in the fix report. |
| CONSIDER | Fix if the change improves the content. Only skip with a stated reason. |

**Severity determines order, not whether something gets fixed.** All guidelines exist to be followed 100% of the time. A CONSIDER flag that reflects a directive-level rule (pronouns, em-dashes, client language) is still mandatory — the severity only indicates how much context the fixer needs before acting.

### 3. Fix cycle

Plan fixes for **all** severity levels in a single atomic pass. Do not fix them one at a time — fixing A can introduce B, and serial fixes compound drift. Read all flags across all severities, plan the fixes together, apply them in one edit. MUST FIX items are addressed first within the plan, but SHOULD FIX and CONSIDER items are included in the same pass.

### 4. Re-validate

Re-run text-eval on the fixed text. If new MUST FIX flags appear (introduced by the fix pass), return to step 3.

**Max 3 cycles.** If MUST FIX flags persist after 3 cycles, present the content to the user with the remaining flags noted and ask for guidance.

### 5. Present

Show the user the final content. If any flags were intentionally skipped, list them with the stated reason. The user confirms or overrides.

---

## Content-Type Calibration

Not all content types need the same depth of evaluation. Use the appropriate calibration:

| Content Type | Calibration |
|--------------|-------------|
| **Focus articles** | Full evaluation. All three agents, all severity levels, full fix cycle. |
| **Newsletter teasers** | Single-signal severity (no cluster escalation). Skip cross-article repetition check — teasers are standalone. |
| **Social posts** | Character scan + metaphor activation only. Posts are 1-3 sentences; structure and repetition flags carry minimal weight. |
| **Presentation slides** | Per-slide evaluation. Cross-slide repetition check replaces cross-article. Structure check adapted for slide density (fewer words per unit). |

---

## Integration with Existing Validators

The finishing chain handles text-eval. Content skills may have additional validators that run before or after:

- **Promote:** Social-validator (Stage 1) runs **before** the finishing chain. Fix platform-mechanic issues first, then run the chain.
- **Newsletter:** Voice-validator runs **before** the chain. Newsletter-editor runs **after** the chain (final pre-send verification).
- **Present:** Slide-evaluator and voice-validator run **before** the chain.
- **Focus:** Preflight validator, reference verifier, and LLM meta generation run **in parallel with** the chain.

The finishing chain is the last thing that touches prose. Nothing modifies content after it passes.
