# Flag Severity

Flags are categorized by severity. This is not optional.

## MUST FIX (blocking)
These flags **must be resolved before presenting the article to the user.** The writing agent must fix them and re-run evaluation. Do not present content with unresolved MUST FIX flags.

- **Em-dashes** (hard rule, zero tolerance)
- **Rhetorical colons** (hard rule, zero tolerance; see [colon-detection.md](colon-detection.md))
- **Staccato opening** (first three paragraphs reading like bullet points)
- **Cold concept drops** (borrowed phrase introduced without grounding)
- **Ungrounded borrowed concepts** (quoted phrase reused before reader owns it)
- **Compressed bullets as prose** (short declarative sentences pretending to be paragraphs)
- **Unnatural references** (logically valid but linguistically dead constructions like "in between," "the former/latter," "as mentioned above"; see [ai-patterns.md](ai-patterns.md))
- **Unresolved wit referent** (caption or epigram imitating the form of a wit beat whose referents don't map to anything in the scene or argument — "wit-shaped noise." Single-line content is exempt from cluster density: one unresolved referent IS the flag. Genuine wit beats pass by construction — every referent resolves; see [ai-patterns.md](ai-patterns.md))
- **Fabricated experience** (first-person claims about Francis's actions, clients, or experiences not provided by the user; see [voice-alignment.md](voice-alignment.md))
- **Hyperbolic scope** (inflated claims like "companies everywhere," "the entire industry" when evidence supports only a few examples; see [ai-patterns.md](ai-patterns.md))
- **Overcorrection swing** (fix for one flag introduces a new problem — fabrication to add voice, hyperbole to replace vagueness, over-explanation to fix ambiguity; see [voice-alignment.md](voice-alignment.md))
- **Overbuilt prose cluster** (3+ overbuilt signals in same passage; see [overbuilt-prose.md](overbuilt-prose.md) § "Cluster Density")

## SHOULD FIX (strong recommendation)
These flags should be fixed unless there's a deliberate craft reason not to. If left unfixed, explain why in the evaluation.

- **First-person sustain** (author appears once early then vanishes — article reads like a briefing, not a person thinking)
- **Discovery framing** (studies and data presented as announcements rather than encounters)
- **Overbuilt prose** (individual sentences no one would say aloud; see [overbuilt-prose.md](overbuilt-prose.md))
- **Flow breaks** (ideas colliding without connective tissue)
- **Thesis-first structure**
- **Abstracting humans** (organizations doing things instead of people)
- **Heady abstraction** (jargon without grounding)
- **Rhythm variation** (all sentences similar length)
- **Inert metaphor in key position** (opening, closing, or section pivot uses a metaphor that labels instead of enacts; see [overbuilt-prose.md](overbuilt-prose.md) § "Metaphor Activation")

## CONSIDER (advisory)
These flags prompt human judgment. Present them but don't block on them.

- **Balanced hedging**
- **The triple beat**
- **Inert metaphor in body prose** (body-text metaphor that labels instead of enacts; see [overbuilt-prose.md](overbuilt-prose.md) § "Metaphor Activation")

## Voice Protection Gate
**Before assigning severity, check the voice profile.** If a flagged pattern matches a documented voice characteristic from `/voice` (e.g., curiosity-driven openings, progressive argument building, rhetorical questions, measured skepticism), reduce its severity to CONSIDER regardless of its default category. The evaluator protects the author's voice — it does not sand it off.

**Protected devices still count toward cluster density totals.** Voice protection lowers individual severity but does not remove the device from passage-level cluster counting. See `overbuilt-prose.md` § "Voice Protection" for the full rule.
