# Evaluation Output Format

The orchestrator collects results from all three agents and presents a unified report:

```
## Text Evaluation

### Character-Level Scan (from character-scanner)
Em-dash check: [count] found
- Line X: "[quoted phrase]"

Colon check: [count] rhetorical colons found
- Line X: "[quoted phrase]"

Source attribution check: [count] issues found

### Human Markers Assessment (from prose-evaluator)
[List which markers are present. If 4+ are strong, include over-correction warning.]

### Prose Evaluation (from prose-evaluator)

#### Overbuilt Prose
[count] sentences flagged
- Clustered (MUST FIX): [count in passages with 3+ signals]
- Individual (SHOULD FIX): [count of isolated instances]
- Voice-protected (CONSIDER): [count matching voice characteristics]

1. **Line X:** "[quoted sentence]"
   - Signal: [which detection signal]
   - Cluster: [isolated / clustered with X other signals in same passage]
   - Severity: [MUST FIX / SHOULD FIX / CONSIDER]
   - Suggestion: [spoken alternative]

#### Metaphor Activation
[count] metaphors assessed
- Activated (no action): [count]
- Inert in key position (SHOULD FIX): [count]
- Inert in body (CONSIDER): [count]

1. **Line X:** "[quoted metaphor]"
   - Status: [activated / inert]
   - Position: [key position / body]
   - Severity: [SHOULD FIX / CONSIDER / none]
   - Suggestion: [activated alternative, if inert]

#### Voice / AI Patterns / Flow
[3-5 combined advisory flags]

### Structure & Repetition (from structure-checker)

#### Cross-Article Repetition
[count] repetitions found
- "[phrase]" <- also in [sibling slug]

#### Structure Check
[checklist with pass/fail]

#### Description Check
[checklist with pass/fail]

#### Purpose Field Check
[checklist with pass/fail]

#### FAQ Field Check
[checklist with pass/fail per item]

### Strengths
[2-3 things that work well and should be preserved]

### Recommendation
[Keep as-is / Minor adjustments suggested / Consider revision]
```
