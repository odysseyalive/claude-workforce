# Cross-Article Repetition

When sibling articles (same category) are available, check for repetition across the neighborhood.

| Pattern | Example | Severity |
|---------|---------|----------|
| **Word whiskers** | "room to think in" appearing in 3 consecutive articles | MUST FIX |
| **Concept duplication** | Two articles both arguing "the gap is absorption, not capability" | MUST FIX (abandon or re-angle) |
| **Metaphor reuse** | Same metaphor carrying weight in multiple pieces | MUST FIX |
| **Structural echo** | Two articles opening with a statistic, or both closing with a question | SHOULD FIX |
| **Phrase echoes** | Similar turns of phrase ("quiet arithmetic," "quiet rebellion") | SHOULD FIX |
| **Callback as crutch** | Same previous article referenced in two or more subsequent pieces | MUST FIX |

**Why this matters:** A reader who follows the publication sees every article. Repeated phrases and concepts signal a machine, not a mind. Each article must earn its own language.
