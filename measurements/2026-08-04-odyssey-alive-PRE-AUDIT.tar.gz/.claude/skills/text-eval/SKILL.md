---
name: text-eval
description: Evaluate text for AI generation tells and voice alignment. Run as Task agent for unbiased assessment.
allowed-tools: Read, Glob, Grep, Task
minimum-effort-level: high
strictness: standard
---

# Text Evaluation Protocol

**IMPORTANT:** Run this evaluation as a **Task agent** to ensure context isolation. The agent evaluates without being influenced by the conversation that created the content.

---

<!-- origin: user | added: 2026-02-12 | immutable: true -->
## Directives

> **"Em-dashes have zero tolerance. Every em-dash must be flagged. This applies to all content types: prose, slide headings, bullet points, presentation titles. No exceptions for 'visual separators' or format-specific rationalizations."**

*— 2026-02-14, source: audit + presentation audit (agent rationalized em-dashes as visual separators)*

> **"MUST FIX flags are blocking. They must be resolved before presenting content to the user. This is not a suggestion."**

*— 2026-02-12, source: audit*

> **"Character checks come first. Always perform literal character searches before subjective evaluation. Do not skip. Do not assume the text is clean."**

*— 2026-02-12, source: audit*

> **"Report ALL MUST FIX flags. No cap. Limit SHOULD FIX and CONSIDER to 3-5 combined. The selectivity rule gates advisory flags, not blocking ones."**

*— 2026-02-17, source: audit + text-eval session (3-5 cap caused agent to stop at 2 when 7+ existed)*

> **"One pass, then stop. Present evaluation once. Fix MUST FIX items. Human decides on the rest."**

*— 2026-02-12, source: audit*

> **"Voice characteristics are protected. When a flagged pattern matches a documented voice characteristic from /voice, it cannot be MUST FIX. Reduce to CONSIDER at most. The evaluator catches AI drift, not the author's personality."**

*— 2026-02-19, source: "The Perfect Storm" overcorrection stripped Francis's voice markers*

> **"Individual signals are not tells. Only clustering is. A single parallel construction or rhetorical reversal is craft. Three or more AI-pattern signals in the same passage is a tell. Severity follows density, not detection."**

*— 2026-02-19, source: stylometric research (Nature 2025), >20% false positive rate when individual signals treated as tells*

> **"Check for human presence, not just AI absence. First-person voice, lived experience, genuine commitment to positions, irregular rhythm, and texture words are positive signals that counterbalance AI-pattern flags. A piece with strong human markers and a few rhetorical devices is human writing, not AI writing."**

*— 2026-02-19, source: editorial research on human-presence optimization*
<!-- /origin -->

A copy-truth claim-vs-behavior MUST FIX is never demoted by human presence — whether prose sounds human has no bearing on whether a UI claim is true.

<!-- origin: user | added: 2026-06-12 | immutable: true -->
> **"The new sentence is also an AI tell, 'Two desks. I never got up from mine.' It presents the same confused pattern of thought as the previous sentence, 'The research came back from a model the article never met.' Identify these style of AI patterns and add it to the skill that is supposed to prevent AI tells like this."**

*— Added 2026-06-12, source: user instruction (inline, via /route → skill-builder). Both captions passed validation twice in one session. The identified pattern — "wit-shaped noise," an epigram imitating the form of a wit beat whose referents don't resolve — is cataloged in references/ai-patterns.md, enforced as MUST FIX in references/flag-severity.md (single-line content exempt from cluster density), and checked by prose-evaluator Step 1f and edit-validator Check 4.*
<!-- /origin -->

---

## How to Invoke

After generating written content, launch **three specialized agents in parallel** (Character Scanner, Prose Evaluator, Structure Checker) using the Task tool. Each agent has `context: none` for unbiased evaluation.

See [references/invocation.md](references/invocation.md) for agent templates, sibling article discovery, and result collection.

---

## When to Run

After writing or editing focus articles, newsletters, social media content, emails, or any substantive text.

---

## Grounding

Read files in [references/](references/) for evaluation criteria before running. Key files: [voice-alignment.md](references/voice-alignment.md), [ai-patterns.md](references/ai-patterns.md), [overbuilt-prose.md](references/overbuilt-prose.md), [colon-detection.md](references/colon-detection.md), [flow-checks.md](references/flow-checks.md), [flag-severity.md](references/flag-severity.md), [output-format.md](references/output-format.md). Cross-reference `/voice` and `/writing` for voice guidelines.

---

## Flag Severity

**Grounding:** See [references/flag-severity.md](references/flag-severity.md) for the complete MUST FIX / SHOULD FIX / CONSIDER lists with descriptions.

**Key rules:** MUST FIX flags are blocking (fix before presenting). Voice Protection Gate applies before severity assignment. If a flagged pattern matches a `/voice` characteristic, reduce to CONSIDER.

---

## Important Notes

- **Specificity over vagueness.** "This feels AI-ish" is useless. "The triple-beat structure in lines 12-15 creates predictable rhythm" is actionable.
- **Preserve what works.** Note strengths so revisions don't accidentally remove them.
- **Invisible-Unicode contamination is a category, not individual flags.** When the Character Scanner agent detects zero-width chars (U+200B–D, U+FEFF), narrow no-break spaces (U+202F), Tag-block characters (U+E0000–E007F, used in LLM ASCII smuggling), bidi controls (U+202A–E, U+2066–9, Trojan Source attacks), or Private Use Area codepoints (U+E000–F8FF, an npm-malware vector), report them as a *cluster* and recommend `/steganographer scrub` to strip the entire class at once. The canonical regex set + per-codepoint reporting lives in `.claude/skills/steganographer/scripts/scrub.js`. Reporting "U+200B at position 142" is less useful than "12 zero-width characters detected → run scrub to remove."

---

## Project Memory

Text-eval rules are shaped by documented patterns. Before adjusting severity thresholds or adding new checks, read `.claude/skills/awareness-ledger/ledger/index.md` (especially DEC-voice-protection-gate, DEC-validator-overcorrection, PAT-overbuilt-prose-drift). The validator's behavior is calibrated by these records.

---

