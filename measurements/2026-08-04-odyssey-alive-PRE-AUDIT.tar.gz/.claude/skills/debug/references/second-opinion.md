# Second Opinion Protocol

**If a fix attempt fails on the first try AND subsequent attempts also fail, STOP and trigger a second opinion.**

This isn't about admitting defeat—it's about recognizing that fresh perspective often reveals what familiarity obscures.

## When to Trigger

- First fix attempt doesn't resolve the issue
- Second or third attempt with variations also fails
- You find yourself trying similar approaches repeatedly
- The user explicitly asks for a "second opinion"

## How to Trigger

Use the Task tool to launch the research-assistant agent. Provide comprehensive context:

```
Task tool with subagent_type: "general-purpose"
prompt: "Read .claude/skills/debug/agents/research-assistant/AGENT.md for instructions, then investigate:
```

```
## Problem Summary
[Describe the issue being debugged]

## What Has Been Tried
1. [First approach and why it failed]
2. [Second approach and why it failed]

## Current Hypothesis
[What we currently think is wrong]

## Relevant Files
- [File paths and key snippets]
- [Error messages observed]

## Environment
- Next.js 16.1.0, React 19.2.3
- Tailwind CSS 4
- [Any other relevant details]

## Request
Search for similar issues and alternative approaches.
```

## User Trigger Phrases

- "Get a second opinion"
- "Fresh eyes on this"
- "What are we missing?"
