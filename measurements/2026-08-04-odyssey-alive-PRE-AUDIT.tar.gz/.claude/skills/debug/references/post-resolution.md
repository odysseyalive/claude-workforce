# Post-Resolution Capture

**After resolving a debugging session, capture what was learned.** Diagnostic findings evaporate at session end. This step prevents re-investigating the same issue.

When a fix is confirmed working, append a structured entry:

```markdown
### [Date] — [Brief title]
**Problem:** [What broke and how it manifested]
**Root cause:** [What was actually wrong]
**Fix:** [What resolved it]
**Lesson:** [What to check first next time]
```

**Where to write:** If the awareness-ledger skill exists, create an incident record there. Otherwise, add to the Discovered Issues Log in the relevant skill file (per CLAUDE.md: "Log failures").

**When to skip:** Trivial typos, config mistakes with obvious fixes, or issues already documented.
