# Roadmap

What's built, what's planned, in honest order.

---

## Shipped (v1)

- `trends` mode, LLM-synthesis variant. Pre-registered corpora, ingest script, briefing template, ledger.
- FP corpus (single source) as baseline.

## Next (v1.1, near-term)

- **Multi-source corpora.** Add FT, Economist, Bloomberg Opinion, Stratechery, The Information YAMLs. Required for cross-source confidence framing.
- **Lookback comparison.** When prior scans exist for the same corpus, the synthesis step references them for §3 (Trends Strengthening) and §4 (Trends Fading).
- **RSS-only sources** (no paywall reader required) wired through ingest.

## Mechanical signal layer (v2)

The synthesis is currently LLM-direct. v2 adds quantified mechanical signals so the briefing can say "phrase X appeared 8× this period vs 2× in the prior 30 days" instead of "the framing has hardened."

Stack (per agent research):

- **n-gram + KeyBERT** for novel-phrase velocity vs rolling-30-day baseline
- **BERTopic incremental + `topics_over_time`** for topic clusters and semantic drift
- **JSD on topic-mixture vectors** for "is today's corpus different from last month's"
- **`ruptures` PELT** for retrospective change-point detection on multi-month series
- **Alibi Detect MMDDrift** on sentence-transformer embeddings for semantic drift

Dependencies: Python venv with sentence-transformers, bertopic, keybert, ruptures, alibi-detect, scipy. Approx 2 GB install (model weights).

Decision gate: build v2 only after running v1 for 4+ weeks. Need real ledger history to know which mechanical signals matter.

## Other modes (planned, not built)

In rough build-order of expected ROI:

1. **`scrub`** — strip outbound watermarks from your own AI content. Text: regex-strip zero-width + paraphrase. Image: `noai-watermark` or 2-step img2img@0.02 + `exiftool -all=`. Daily-use ROI on every focus article + watercolor publish.

2. **`scan`** — hidden-layer scan of any URL. Invisible Unicode, homoglyphs, Tag block (U+E0000–E007F), bidi controls, C2PA metadata via `c2patool`, acrostic null-check with ≥6-letter + paragraph-anchored + stoplist discipline. Logs every scan to ledger including nulls.

3. **`forensics`** — file-level inspection of inbound PDFs / Office docs / emails. Pipeline drafted (pdfid → pdf-parser → qpdf → peepdf-3 → mutool → exiftool → X-Ray for redaction failures → OCR-vs-text diff). Office: unzip + grep for w:ins/w:del/comments/customXml. Email: eml-parser + dkimpy + tracking-pixel scan.

4. **`monitor`** — periodic brand-impersonation + homoglyph watch. dnstwist + urlscan.io + Sherlock + WhatsMyName + changedetection.io. $0/mo stack.

5. **`predict`** — prediction-market cross-venue divergence + topic-bounded GDELT anomaly. Refuses to run without pre-registered hypothesis + falsification criterion. Last priority; only build when a specific hypothesis demands it.

## Coordination layer (cross-mode, v3)

CooRTweet methodology in Python, igraph Leiden community detection, optional BLOC behavioral fingerprints, DISARM tagging via MISP taxonomy. Lives across `trends` (narrative coalescence) and `monitor` (coordinated impersonation). Build only on a multi-source corpus with cross-platform coverage (e.g., Bluesky firehose + RSS news).

## Cut from scope (with reasons)

- **X scraping** — $5k/mo for usable access, TOS-hostile, replication crisis
- **General "predict events from sentiment"** — Fragile Families (Salganik 2020) verdict; loses to morning FT
- **Hawkes cascade modeling** — overkill, brittle out-of-sample
- **Per-account bot scoring** — Botometer frozen May 2023; field has shifted to group coordination
- **Standalone acrostic mode** — base-rate noise too high (5.5% for 4-letter); only as sub-check inside `scan`
- **cuGraph / GPU stacks** — not needed under ~500k nodes

## When to revisit this roadmap

After 4 weeks of v1 use. The honest test: is the ledger producing reads you'd send to a colleague? If yes, build v2's mechanical layer. If no, the format needs revision before more machinery.
