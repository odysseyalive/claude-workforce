# Briefing Template

The horizon-scan output format. Adapted from UK GO-Science Trend Deck, Sitra Weak Signals, and WEF Global Risks Report conventions. Tone: Friday-afternoon analyst memo. Specific, sourced, willing to say "I don't know."

---

## Format

```markdown
# <Corpus-Name> Horizon Scan — YYYY-MM-DD to YYYY-MM-DD — N articles, M authors

## 1. Scan Note

Two to four sentences. What the corpus said this period. What it didn't
say that you expected it to. Set the period's character in one read.

## 2. Emerging Signals

For each (≤5 signals):

**Signal A — <one-line phrase, present tense, declarative>**

- Evidence: <2–4 citations with author + headline + date; direct quotes
  preferred when they capture the framing>
- STEEP: <Social | Technical | Economic | Environmental | Political>
  (one or more, comma-separated)
- Horizon: <near (0–1y) | medium (1–5y) | far (5y+)>
- Confidence: <single weak signal | corroborated within source |
  corroborated cross-source>
- So what: <one sentence — implication for the reader, not a prediction>

## 3. Trends Strengthening

Signals from prior scans that gained evidence this period. Cite the prior
scan's date + the new evidence. If this is the first scan in the ledger,
write: *(First scan — no prior ledger entries.)*

## 4. Trends Fading

Signals tracked previously that lost evidence or got contradicted. Null
findings matter. If first scan: *(First scan — no prior ledger entries.)*

## 5. Cross-Cutting Theme

One paragraph. The connective tissue across this period's signals — the
"narrative" in Shiller's sense. Written as observation, not prophecy.
Optional fictional-future framing (Sitra IF* style) clearly marked as
hypothetical. Maximum one such framing per briefing.

## 6. What This Scan Cannot Tell You

Two to four sentences. Absent sources, blind spots, corpus limits, what
would change the read. This is the honesty gate. Mandatory.

## 7. Source Ledger

Source list with last-fetched timestamps. Counts: N articles total, M
fetched as full body, N–M fetched as RSS metadata only. List authors.
```

---

## Notes on each section

**Scan Note (§1).** Lead with what's *unusual* about this period, not with the topic distribution. "Six days, 25 articles, and an editorial corpus that has stopped hedging" beats "Coverage centered on Iran (X articles), China (Y articles)..." If nothing is unusual, say so: "A quiet period. No coalescing themes."

**Emerging Signals (§2).** Cap at 5. Each must pass three tests:
1. **Source-anchored** — at least one direct citation, preferably with quote
2. **Non-obvious** — if a regular reader of the corpus would already know it, omit
3. **Falsifiable** — the "so what" is testable against future corpus or world events

If fewer than 5 signals pass these tests, ship fewer. Padding the list with weak signals is the failure mode.

**Cross-Cutting Theme (§5).** This is the *fascinating-read* hinge. The signals do the work; the theme makes them mean something. The Sitra fictional-future framing is allowed once per briefing and must be clearly marked (`*Looking back from <year>, the <period> moment was...*`). Never use it to assert a prediction.

**What This Scan Cannot Tell You (§6).** Failure modes to name explicitly:
- Single-source corpora: declare it; FP-only is FP's editorial line, not establishment consensus.
- Missing perspectives: if the corpus is US/EU-centered, name what's absent (China, Russia, Global South domestic outlets).
- Time-window thinness: a 7-day scan can't see slow shifts.
- Confirmation chains: when the corpus's sources cite each other heavily, name it.

**Source Ledger (§7).** Always include fetch timestamps. Distinguish full-body from RSS-only. List every author once. The ledger is what makes the scan auditable when reviewed months later.

---

## Tone

- Specific. "FP designated *Paywall Free + Post to Buffer*" beats "FP promoted heavily."
- Sourced. Every claim traces.
- Confident where evidence is strong; "I don't know" where it isn't.
- No prophet voice. No "this means we are entering a new era of...".
- No casualty figures, dates, prices, or election predictions in any signal.

## What this template is not

- Not a market forecast.
- Not a policy recommendation.
- Not a takedown or endorsement of any source.
- Not a substitute for reading the articles — it's a reader's index of *what the corpus is telling you that you might not have noticed*.
