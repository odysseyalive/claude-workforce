# Weekly review cadence

The ledger compounds. The skill's value materializes over weeks of repeated scans — each new briefing can reference prior entries, surface "Trends Strengthening" / "Trends Fading," and graduate single-corpus signals to cross-corpus confidence as patterns recur.

**Recommended Monday-morning review ritual** (~15 minutes of attention, ingest + synthesis takes ~10 minutes of compute):

```
/steganographer trends foreign-policy
/steganographer trends geopolitics
/steganographer trends narrative-economics
/steganographer trends tech-industry
```

Run them in that order — `foreign-policy` first establishes the editorial-line baseline; the other three then have something to cross-corroborate against. The synthesis step references prior ledger entries by filename when surfacing strengthened/fading trends; the cross-corpus value compounds quickly (the May 2026 seeding round demonstrated four-corpus convergence on Iran/Hormuz inside a single day).

**Why not cron / `/schedule`?** Two reasons:
1. The synthesis step (Claude reading the corpus + writing the briefing) is the value layer. Cron-driven ingest without synthesis just accumulates `corpus.json` files. A scheduled remote agent could do both, but the `foreign-policy` corpus requires authenticated Playwright credentials at `~/.config/playwright-mcp/secrets.env` which don't travel to remote runners.
2. Active reading of the briefings — the ritual of opening them on Monday — is itself part of the loop. Automation that produces briefings nobody reads is a worse outcome than no automation.

If you want partial automation, `/schedule` can drive the three non-FP corpora as remote-agent runs and leave FP as a local manual invocation. Worth doing only after 4+ weeks of manual cadence proves the briefings are still being read.

**4-week checkpoint.** After 4 weekly review rounds, audit the ledger:
- Which signals fired persistently (high cross-corpus, high week-over-week)? → real
- Which signals fired once and never returned? → noise
- Which corpora produce the same content week after week with no novel pattern? → drop or replace
- Which corpora keep surfacing signals first? → expand

That audit is the input to deciding whether v2's mechanical signal layer (BERTopic + KeyBERT + JSD) is worth building.
