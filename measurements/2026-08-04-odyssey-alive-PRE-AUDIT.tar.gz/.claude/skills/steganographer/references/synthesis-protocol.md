# Synthesis Protocol

How Claude reads a fetched corpus and produces a horizon-scan briefing. Read this *after* [briefing-template.md](briefing-template.md).

---

## Step 1 — Read everything

For the run's `corpus.json`:

- Read every article that has a `body` field. These are your quotable sources.
- Read every article's `title`, `description`, `author`, `pubDate`, `categories` even when body is absent. RSS metadata can support framing claims; it cannot support direct quotes.
- Note which articles failed to fetch and which were paywalled-preview-only. Flag in §7.

Do not skim. The whole point of bounded corpora is that the corpus is small enough to read in full.

## Step 2 — Inventory before interpreting

Before drafting any signal, list mechanically:

1. **Topic distribution** — what's the corpus about, in 5–8 clusters?
2. **Author distribution** — who wrote what; identify any single-author dominance
3. **Category distribution** — Argument vs Analysis vs Report vs World Brief
4. **Editorial markers** — `Paywall Free`, `Editors' Picks`, `Post to Buffer`, image-prominence; these encode editorial weight
5. **Recurring nouns and verbs** — what words show up unusually often across multiple articles? (Manual diachronic check until v2 ships KeyBERT.)
6. **Absences** — what topics this publication usually covers are missing?

This inventory is *not* in the briefing. It's prep. The briefing is what you find that's worth telling someone who already read the corpus.

## Step 3 — Identify signal candidates

A signal candidate is a pattern that meets all three:

- **Source-anchored** — at least one quotable article supports it
- **Non-obvious** — a careful reader of the corpus wouldn't already say "obviously"
- **Falsifiable** — the "so what" is testable later

Common candidate classes:

- **Editorial-register shifts** — vocabulary that's harder, softer, more certain, more hedged than the publication's baseline ("failure," "humiliated," "breaking," "alarming," "remarkable")
- **Cross-desk convergence** — independent contributors landing on the same verb or frame inside a short window
- **Topic concentration anomalies** — a single topic occupying more share than the publication usually allocates
- **Absences** — recurring beats that went silent
- **Editorial-amplification signals** — paywall-free designations, Buffer queuing, image prominence
- **Source-citation patterns** — when the corpus's articles cite the same external evidence, the chain is shorter than it looks

## Step 4 — Apply confidence framing

Three tiers, mechanical:

- `single weak signal` — supported by 1 article in the corpus
- `corroborated within source` — supported by ≥2 articles in the same publication
- `corroborated cross-source` — supported by ≥2 articles across ≥2 publications

A single-source corpus *cannot produce* cross-source confidence. Say so in §6.

## Step 5 — Cap at five signals, ship fewer if needed

Padding kills the briefing. If three signals pass the three tests in Step 3, ship three. A briefing with three strong signals and an honest §6 beats one with five and two weak.

## Step 6 — Draft the cross-cutting theme last

§5 is the fascinating-read hinge. Write it after §2 is locked. The theme is the connective tissue across the signals you actually shipped — never a frame imported from outside the corpus.

Optional fictional-future framing (Sitra IF\* style) is allowed *once* per briefing, must be clearly marked as hypothetical:

> *Looking back from 2027, the May 2026 FP issues were the moment the foreign-policy consensus visibly fractured — not because new evidence arrived, but because senior editors stopped writing around it.*

Never use it to assert a prediction.

## Step 7 — Write the honesty gate (§6)

Mandatory. Name the failure modes:

- If single-source corpus: say so
- If US/EU-centered: name what's absent (China, Russia, Global South domestic outlets)
- If short window: say so
- If sources cite each other heavily: say so
- If a signal's strongest evidence is only RSS metadata, not a fetched body: say so

This section is what makes the ledger trustworthy when read months later.

## Step 8 — Write the source ledger (§7)

- Every article cited or used for framing
- Fetch timestamps
- Distinguish full-body fetches from RSS-only
- List all authors once
- Total counts

## Step 9 — Save the briefing

Output path: `scans/YYYY-MM-DD-<corpus>-<short-slug>.md`

The slug is 2–4 words derived from the cross-cutting theme, lowercased and hyphenated. Example: `2026-05-18-foreign-policy-editorial-line-hardens.md`.

Append a one-line index entry to `scans/index.md`:

```markdown
- [2026-05-18 — foreign-policy editorial line hardens](2026-05-18-foreign-policy-editorial-line-hardens.md) — 25 articles, 4 signals, single-source corpus
```

## Step 10 — Echo the briefing path

Final action: tell the user where the briefing was saved so they can open it. Do not paste the full briefing into the chat unless asked.

---

## Failure modes to avoid

- **Synthesizing from titles when bodies were available.** Read the bodies. The reason this skill exists is to surface what titles miss.
- **Inventing signals to fill the template.** Three real signals beats five mediocre.
- **Predicting events.** "FP will pivot next week" is not a signal; "FP's verb-register has hardened this period" is.
- **Quoting from RSS descriptions as if they were body text.** RSS descriptions are author-written but tiny; quote bodies for evidence, descriptions only for context.
- **Importing your priors.** The briefing reflects the corpus. If the corpus doesn't support a frame you brought in, drop the frame.
- **Skipping §6.** The honesty gate is the most important section. Skipping it turns the skill into Web Bot.
