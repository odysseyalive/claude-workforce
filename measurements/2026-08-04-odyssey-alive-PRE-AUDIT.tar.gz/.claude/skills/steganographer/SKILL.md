---
name: steganographer
description: Hidden-layer scanner with a ledger. Modes: trends (diachronic corpus analysis → horizon-scan briefing), scrub (strip outbound watermarks from AI content). Future: scan, forensics, monitor, predict.
allowed-tools: Read, Write, Edit, Glob, Grep, Bash, mcp__jina__*
minimum-effort-level: high
strictness: standard
---

# Steganographer

A hidden-layer scanner for the modern web with a compounding ledger. v1 implements **`trends`** (diachronic linguistic analysis over a bounded, pre-registered corpus, producing horizon-scan briefings in the foresight tradition of UK GO-Science, Sitra, WEF Global Risks) and **`scrub`** (strips outbound watermarks and invisible-Unicode payloads from text and images before publish).

Other modes (`scan`, `forensics`, `monitor`, `predict`) are designed but not yet built. See [references/roadmap.md](references/roadmap.md).

---

## Usage

### trends mode

```
/steganographer trends <corpus-name> [--lookback-days N]
```

- `<corpus-name>` — basename of a YAML file under `corpora/` (e.g., `foreign-policy` for `corpora/foreign-policy.yaml`)
- `--lookback-days N` — window of articles to include. Default: per-corpus (typically 7; narrative-economics uses 14).

Examples:

```
/steganographer trends foreign-policy
/steganographer trends geopolitics --lookback-days 14
```

### scrub mode

```
/steganographer scrub <path>                    # auto-detect by MIME
/steganographer scrub --text "..."              # inline text
/steganographer scrub --stdin                   # read text from stdin
/steganographer scrub <path> --write-back       # overwrite input (with .bak backup)
```

**Text inputs** are scanned for invisible Unicode payloads and stripped in-place. Five classes detected:
- Zero-width (U+200B ZWSP, U+200C ZWNJ, U+200D ZWJ, U+2060 WJ, U+FEFF BOM) — common Claude/GPT contamination
- Narrow NBSP (U+202F) — GPT-5 default-output quirk
- Tag block (U+E0000–U+E007F) — ASCII smuggling for LLM prompt injection
- Bidi controls (U+202A–E, U+2066–9) — Trojan Source attacks
- Private Use Area (U+E000–U+F8FF) — npm-malware vector (Veracode May 2025)

Each codepoint stripped is reported by class + count to stderr. Cleaned text goes to stdout (or replaces the file with `--write-back`).

**Image inputs** are scrubbed via `exiftool -all=` (strips EXIF, XMP, IPTC, C2PA manifests). Requires `exiftool` (Arch: `sudo pacman -S perl-image-exiftool`). The script:
1. Pre-reads metadata to detect known generators (Google/SynthID, OpenAI/C2PA, Midjourney, Adobe Firefly, Stable Diffusion/Flux) and reports source-detection hints
2. Strips all metadata
3. Reports honest limits: invisible pixel watermarks (SynthID, Stable Signature) survive metadata stripping; regen via img2img@0.02 with style LoRA is the only known practical removal (v2 will integrate `noai-watermark` or `wiltodelta/remove-ai-watermarks`)

For Nano Banana / Gemini output specifically, plan to regen end-to-end rather than scrub if provenance matters — SynthID is non-configurable on that endpoint and survives exiftool.

Examples:

```
/steganographer scrub draft-focus-article.md
/steganographer scrub public/static/hero-image.png --write-back
echo "Some Claude-generated text" | /steganographer scrub --stdin > clean.txt
```

---

## Workflow

When invoked with `/steganographer trends <corpus>`:

1. **Read the corpus YAML** at `corpora/<corpus>.yaml`. Validate it has `sources` and a `lookback_days` default.

2. **Run the ingest script:**
   ```bash
   node .claude/skills/steganographer/scripts/ingest.js <corpus> [--lookback-days N]
   ```
   Output: `scans/.runs/<timestamp>-<corpus>/corpus.json` containing per-article: title, link, author, pubDate, categories, description, body (when fetched).

3. **Read the briefing template** at [references/briefing-template.md](references/briefing-template.md) and the synthesis protocol at [references/synthesis-protocol.md](references/synthesis-protocol.md).

4. **Read the corpus.json** produced by ingest. Read every article body that was fetched. Do not summarize from titles alone for any claim that names a source — a citation must trace to a fetched body or to the article's RSS description.

5. **Synthesize** following the protocol. Produce a briefing in the template format. Every signal must include source citations, STEEP category, horizon, confidence framing, and "so what."

6. **Write the briefing** to `scans/YYYY-MM-DD-<corpus>-<short-slug>.md`. Update `scans/index.md` with a one-line entry.

7. **Echo the briefing path** so the user can open it.

---

<!-- origin: user | added: 2026-06-04 | immutable: true -->
## Discipline (binding)

These are the guardrails. Violating them defeats the skill's purpose; the output becomes pareidolia.

- **No event predictions.** No dates, prices, casualty figures, election outcomes. The output reports *signals coalescing*, never "X will happen."
- **Every claim source-anchored.** Each signal cites at least one corpus article (fetched body preferred; RSS description acceptable for context, not for quoted material). Quoted text must come from a fetched body.
- **Confidence framing is mandatory per signal.** Three tiers: `single weak signal` (one article) | `corroborated within source` (≥2 articles same publication) | `corroborated cross-source` (≥2 publications). Cross-source confidence is only available when the corpus has multiple publications.
- **"What This Scan Cannot Tell You" is mandatory.** This section is the anti-Web-Bot guardrail — it forces the skill to disclose its own thinness. Name the absent sources, the blind spots, the corpus limits.
- **Null findings are valid output.** If the period produces no notable signals, the briefing says so plainly. Do not invent signals to fill the template.
- **No bonus interpretation.** If the corpus doesn't say it, the briefing doesn't either. Speculative chains ("this suggests X, which may indicate Y") are not allowed past the "so what" line of a single signal.
- **Single-source corpora are demonstrations, not signal.** A briefing built on one publication is editorial-line analysis of *that publication*, not an emergent-trend read. The skill says this out loud in the briefing.

*— Marked sacred 2026-06-04 via /skill-builder audit (user-confirmed). Source: skill design guardrails; wording preserved verbatim.*
<!-- /origin -->

---

## Honest scope (v1)

The mechanical signal layer specified in the design (BERTopic incremental topic modeling, KeyBERT novel-phrase velocity vs rolling-30-day baseline, JSD on topic-mixture vectors, `ruptures` PELT change-point detection) is **not implemented in v1**. The current `trends` mode does ingest mechanically and synthesis via Claude reading the bodies directly.

This means:
- Quantified phrase-velocity claims ("'humiliation' appeared 8× this period vs 2× in prior 30 days") are not available yet — synthesis is qualitative.
- Rolling baseline comparison requires manual reference to prior ledger entries.
- Cross-corpus trend deltas are reader-driven.

These are tracked in [references/roadmap.md](references/roadmap.md) for v2.

---

## Ledger

```
scans/
├── index.md                                  # chronological + by-corpus
├── YYYY-MM-DD-<corpus>-<slug>.md             # one per scan, includes nulls
└── .runs/                                    # raw fetched corpora (gitignorable)
    └── <timestamp>-<corpus>/corpus.json
```

The value compounds. Six months in, you can read the index and see which signals fired, which faded, which were noise. The honesty section of each briefing is the longitudinal antidote to confirmation bias.

---

## Corpora

Pre-registered source lists live in [corpora/](corpora/):

| Corpus | Sources | Lookback | Notes |
|---|---|---|---|
| `foreign-policy` | Foreign Policy | 7d | Single-source baseline — editorial-line analysis only, no cross-source confidence available |
| `geopolitics` | Just Security, War on the Rocks, Defense One | 7d | Security/defense/national-security legal analysis. Cross-source corroboration partner for `foreign-policy` |
| `tech-industry` | Hacker News (titles only), Simon Willison, MIT Tech Review | 7d | Practitioner blogs + frontier news aggregation + mainstream tech journalism |
| `narrative-economics` | Marginal Revolution, Calculated Risk, The Big Picture (Ritholtz) | 14d | Economic-commentary blogs in the Shiller "narrative economics" vein. Longer window because macro narratives coalesce slower than news cycles |

Adding a corpus: copy any existing YAML, change `name`, `sources`, `lookback_days`. The `paywall_reader: true` setting routes through `scripts/read-paywalled.js` (which works for free sites too and returns cleaner text than raw HTTP). Add authentication only for sites in the SITES{} table of that script.

---

## Weekly review cadence

The ledger compounds; the skill's value materializes over weeks of repeated scans. See [references/cadence.md](references/cadence.md) for the recommended Monday-morning review ritual, the cron/`/schedule` rationale, and the 4-week checkpoint audit.

---

## Related

- `scripts/ingest.js` — RSS pull + paywall-aware body fetch
- Reuses `/scripts/read-paywalled.js` for authenticated sites (FP credentials in `~/.config/playwright-mcp/secrets.env`)
- [references/briefing-template.md](references/briefing-template.md) — horizon-scan output format
- [references/synthesis-protocol.md](references/synthesis-protocol.md) — how to read the corpus and produce the briefing
- [references/roadmap.md](references/roadmap.md) — mechanical signal layer + other modes
