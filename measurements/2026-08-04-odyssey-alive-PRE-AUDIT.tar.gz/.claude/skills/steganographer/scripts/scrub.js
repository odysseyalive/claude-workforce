#!/usr/bin/env node
/**
 * Steganographer scrub mode.
 * Strips outbound watermarks from AI-generated content before publish.
 *
 * Usage:
 *   scrub.js <path>                    # auto-detect by MIME
 *   scrub.js --text "..."              # inline text
 *   scrub.js --stdin                   # read text from stdin
 *   scrub.js <path> --write-back       # overwrite input (with .bak backup)
 *
 * Text mode: regex-strips invisible Unicode (zero-width, narrow NBSP,
 *   Tag block U+E0000-U+E007F for ASCII smuggling, bidi controls). Reports
 *   per-codepoint counts to stderr. Writes cleaned text to stdout.
 *
 * Image mode: shells out to `exiftool -all=` to strip C2PA + EXIF + XMP +
 *   IPTC metadata. Reports a SynthID risk advisory if file hints at a known
 *   generator (Nano Banana / Gemini, DALL-E, Midjourney, etc). Requires
 *   exiftool: `sudo pacman -S perl-image-exiftool` (Arch) or equivalent.
 */

const fs = require('fs');
const cp = require('node:child_process');

const STRIP_CLASSES = {
  'zero-width':   { re: /[​-‍⁠﻿]/gu, codes: ['U+200B ZWSP','U+200C ZWNJ','U+200D ZWJ','U+2060 WJ','U+FEFF BOM'] },
  'narrow-nbsp':  { re: /[ ]/gu, codes: ['U+202F narrow NBSP (GPT-5 quirk)'] },
  'tag-block':    { re: /[\u{E0000}-\u{E007F}]/gu, codes: ['U+E0000-U+E007F (ASCII smuggling)'] },
  'bidi-control': { re: /[‪-‮⁦-⁩]/gu, codes: ['U+202A-E + U+2066-9 (bidi override / Trojan Source)'] },
  'pua-block':    { re: /[\u{E000}-\u{F8FF}]/gu, codes: ['U+E000-U+F8FF Private Use Area (npm-attack vector)'] },
};

function log(msg) { process.stderr.write(msg + '\n'); }

function parseArgs(argv) {
  const args = argv.slice(2);
  let input = null;
  let mode = null; // 'file' | 'text' | 'stdin'
  let writeBack = false;
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '--text') { mode = 'text'; input = args[++i]; }
    else if (a === '--stdin') { mode = 'stdin'; }
    else if (a === '--write-back') { writeBack = true; }
    else if (!a.startsWith('--')) { mode = 'file'; input = a; }
  }
  if (!mode) {
    process.stderr.write('Usage:\n  scrub.js <path>\n  scrub.js --text "..."\n  scrub.js --stdin\n  scrub.js <path> --write-back\n');
    process.exit(1);
  }
  return { mode, input, writeBack };
}

function scrubText(text) {
  let cleaned = text;
  const report = {};
  let totalRemoved = 0;
  for (const [name, { re, codes }] of Object.entries(STRIP_CLASSES)) {
    const matches = cleaned.match(re);
    if (matches && matches.length) {
      const byCodepoint = {};
      for (const m of matches) {
        const cp = 'U+' + m.codePointAt(0).toString(16).toUpperCase().padStart(4, '0');
        byCodepoint[cp] = (byCodepoint[cp] || 0) + 1;
      }
      report[name] = { count: matches.length, codes, byCodepoint };
      totalRemoved += matches.length;
      cleaned = cleaned.replace(re, '');
    }
  }
  return { cleaned, report, totalRemoved };
}

function fileMime(filePath) {
  try {
    const r = cp.spawnSync('file', ['-b', '--mime-type', filePath], { encoding: 'utf-8' });
    return (r.stdout || '').trim();
  } catch { return null; }
}

function exiftoolAvailable() {
  const r = cp.spawnSync('exiftool', ['-ver'], { encoding: 'utf-8' });
  return r.status === 0;
}

function detectImageProvenance(filePath) {
  // Pre-strip metadata read to identify likely generator
  const r = cp.spawnSync('exiftool', ['-a', '-G1', '-s', filePath], { encoding: 'utf-8' });
  const out = r.stdout || '';
  const hints = [];
  if (/Google|Gemini|SynthID|Nano Banana|Imagen/i.test(out)) hints.push('Google (SynthID likely present — invisible, no public detector, regen-only removal)');
  if (/DALL[- ]?E|OpenAI/i.test(out)) hints.push('OpenAI (C2PA likely present — metadata only, will be stripped)');
  if (/Midjourney/i.test(out)) hints.push('Midjourney (IPTC DigitalSourceType tag likely — will be stripped)');
  if (/Adobe Firefly|Adobe Photoshop AI/i.test(out)) hints.push('Adobe (C2PA + IPTC + potentially invisible pixel watermark)');
  if (/Stable Diffusion|invisible-watermark|Flux/i.test(out)) hints.push('Stable Diffusion / Flux family (DWT-DCT watermark — easy to defeat by regen)');
  if (/c2pa|jumbf/i.test(out)) hints.push('C2PA manifest detected — metadata only, will be stripped');
  return { hints };
}

function scrubImage(filePath, writeBack) {
  if (!exiftoolAvailable()) {
    log('ERROR: exiftool not installed. Image scrub requires it.');
    log('  Arch:    sudo pacman -S perl-image-exiftool');
    log('  Debian:  sudo apt install libimage-exiftool-perl');
    log('  macOS:   brew install exiftool');
    process.exit(2);
  }
  const { hints } = detectImageProvenance(filePath);
  log(`Image: ${filePath}`);
  log(`Source-detection hints:`);
  if (hints.length) for (const h of hints) log(`  ⚠ ${h}`); else log('  (no recognizable generator hints in metadata)');

  const target = writeBack ? filePath : filePath.replace(/(\.[^.]+)?$/, '.scrubbed$1');
  if (!writeBack) {
    fs.copyFileSync(filePath, target);
  }
  // -all= strips all metadata; -overwrite_original prevents .orig backup file
  // (we already made our own copy if not write-back)
  const args = ['-all=', '-overwrite_original', target];
  const r = cp.spawnSync('exiftool', args, { encoding: 'utf-8' });
  if (r.status !== 0) {
    log(`exiftool failed: ${r.stderr || r.stdout}`);
    process.exit(1);
  }
  log(`Stripped metadata. Output: ${target}`);
  log('');
  log('Limits (honest):');
  log('  - Strips EXIF, XMP, IPTC, C2PA manifests — yes.');
  log('  - Strips invisible pixel watermarks (SynthID, Stable Signature) — NO.');
  log('  - For Nano Banana / Gemini output, SynthID survives exiftool. Regen via');
  log('    img2img@0.02 with style LoRA + alpha-channel notch is the only known');
  log('    practical removal. v2 will integrate noai-watermark or wiltodelta repo.');
  log('  - If publishing as your own work where provenance matters, regen end-to-end');
  log('    rather than scrub.');
}

(async () => {
  const { mode, input, writeBack } = parseArgs(process.argv);

  let textInput = null;
  if (mode === 'text') textInput = input;
  else if (mode === 'stdin') {
    const chunks = [];
    for await (const chunk of process.stdin) chunks.push(chunk);
    textInput = Buffer.concat(chunks).toString('utf-8');
  } else if (mode === 'file') {
    if (!fs.existsSync(input)) {
      log(`File not found: ${input}`); process.exit(1);
    }
    const mime = fileMime(input);
    log(`Detected MIME: ${mime || 'unknown'}`);
    if (mime && mime.startsWith('image/')) {
      scrubImage(input, writeBack);
      return;
    }
    // Default: read as text
    textInput = fs.readFileSync(input, 'utf-8');
  }

  const { cleaned, report, totalRemoved } = scrubText(textInput);

  log(`Scrubbed ${totalRemoved} invisible-character codepoint(s):`);
  for (const [name, info] of Object.entries(report)) {
    log(`  ${name}: ${info.count} removed`);
    for (const [cp, ct] of Object.entries(info.byCodepoint)) log(`    ${cp}: ${ct}`);
  }
  if (totalRemoved === 0) log('  (nothing found — text is clean)');

  if (mode === 'file' && writeBack) {
    fs.copyFileSync(input, input + '.bak');
    fs.writeFileSync(input, cleaned);
    log(`Wrote cleaned text to ${input} (backup: ${input}.bak)`);
  } else {
    process.stdout.write(cleaned);
  }
})().catch(e => { log(`fatal: ${e.stack || e.message}`); process.exit(1); });
