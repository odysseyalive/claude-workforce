#!/usr/bin/env node
/**
 * Steganographer trends-mode ingest.
 * Reads a corpus YAML, pulls RSS, fetches article bodies (via paywall
 * reader where configured), writes structured corpus.json to a run dir.
 *
 * Subprocess invocation: spawnSync with explicit args array (no shell).
 * URLs come from RSS feeds we control; not user input. Safe form.
 *
 * Usage:
 *   node ingest.js <corpus-name> [--lookback-days N]
 *
 * Output:
 *   stdout: absolute path to corpus.json
 *   stderr: progress logs
 *   files:  scans/.runs/<timestamp>-<corpus>/corpus.json
 */

const fs = require('fs');
const path = require('path');
const cp = require('node:child_process');

const SKILL_DIR = path.resolve(__dirname, '..');
const REPO_ROOT = path.resolve(SKILL_DIR, '..', '..', '..');
const PAYWALL_READER = path.join(REPO_ROOT, 'scripts', 'read-paywalled.js');
const PARALLEL = 3;

function log(msg) { process.stderr.write(`[ingest] ${msg}\n`); }

function parseArgs(argv) {
  const args = argv.slice(2);
  let corpusName = null;
  let lookbackDays = null;
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '--lookback-days') lookbackDays = parseInt(args[++i], 10);
    else if (!a.startsWith('--')) corpusName = a;
  }
  if (!corpusName) {
    process.stderr.write('Usage: ingest.js <corpus-name> [--lookback-days N]\n');
    process.exit(1);
  }
  return { corpusName, lookbackDays };
}

// Strict-subset YAML parser. Supports top-level scalars and a single
// `sources:` list of inline-keyed objects. Quoted strings preserved as-is.
function parseCorpusYaml(text) {
  const out = { sources: [] };
  const lines = text.split('\n');
  let inSources = false;
  let cur = null;
  for (let raw of lines) {
    const line = raw.replace(/\r$/, '');
    if (!line.trim() || line.trim().startsWith('#')) continue;
    if (/^sources\s*:/.test(line)) { inSources = true; continue; }
    if (!inSources) {
      const m = line.match(/^([a-z_]+)\s*:\s*(.*)$/i);
      if (m) {
        const v = m[2].trim();
        out[m[1]] = /^\d+$/.test(v) ? parseInt(v, 10) : v.replace(/^["']|["']$/g, '');
      }
      continue;
    }
    if (/^\s*-\s*([a-z_]+)\s*:\s*(.*)$/i.test(line)) {
      const m = line.match(/^\s*-\s*([a-z_]+)\s*:\s*(.*)$/i);
      cur = {};
      out.sources.push(cur);
      cur[m[1]] = coerceScalar(m[2]);
    } else if (/^\s+([a-z_]+)\s*:\s*(.*)$/i.test(line) && cur) {
      const m = line.match(/^\s+([a-z_]+)\s*:\s*(.*)$/i);
      cur[m[1]] = coerceScalar(m[2]);
    }
  }
  return out;
}

function coerceScalar(v) {
  v = v.trim().replace(/^["']|["']$/g, '');
  if (v === 'true') return true;
  if (v === 'false') return false;
  if (/^\d+$/.test(v)) return parseInt(v, 10);
  return v;
}

async function fetchText(url) {
  const r = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 steganographer-ingest' } });
  if (!r.ok) throw new Error(`HTTP ${r.status} for ${url}`);
  return r.text();
}

// Minimal RSS 2.0 + Atom 1.0 parser. WordPress, standard RSS, and Atom feeds.
function decodeEntities(s) {
  if (!s) return s;
  return s
    .replace(/&#0*38;/g, '&').replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&#0*39;|&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(parseInt(n, 10)));
}

function parseRss(xml) {
  const items = [];
  const isAtom = /<feed\b[^>]*\bxmlns=['"]http:\/\/www\.w3\.org\/2005\/Atom['"]/.test(xml);
  const blockRe = isAtom ? /<entry\b[\s\S]*?<\/entry>/g : /<item\b[\s\S]*?<\/item>/g;
  const blocks = xml.match(blockRe) || [];
  for (const block of blocks) {
    const get = (tag) => {
      const m = block.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`));
      if (!m) return null;
      return m[1].replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1').trim();
    };
    const cats = [];
    if (isAtom) {
      const catRe = /<category\b[^>]*term="([^"]+)"/g;
      let m;
      while ((m = catRe.exec(block)) !== null) {
        if (!cats.includes(m[1])) cats.push(m[1]);
      }
    } else {
      const catRe = /<category[^>]*>([\s\S]*?)<\/category>/g;
      let m;
      while ((m = catRe.exec(block)) !== null) {
        const c = m[1].replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1').trim();
        if (c && !cats.includes(c)) cats.push(c);
      }
    }
    let link = null;
    if (isAtom) {
      const lm = block.match(/<link\b[^>]*\bhref="([^"]+)"/);
      link = lm ? lm[1] : null;
    } else {
      link = get('link');
    }
    let author = isAtom
      ? (block.match(/<author\b[\s\S]*?<name>([\s\S]*?)<\/name>/) || [])[1]
      : (get('dc:creator') || get('author'));
    items.push({
      title: decodeEntities(get('title')),
      link: decodeEntities(link),
      author: author ? author.trim() : null,
      pubDate: get('pubDate') || get('published') || get('updated'),
      description: decodeEntities(get('description') || get('summary')),
      categories: cats,
    });
  }
  return items;
}

function findPlaywrightNodePath() {
  if (process.env.PLAYWRIGHT_NODE_PATH) return process.env.PLAYWRIGHT_NODE_PATH;
  const home = process.env.HOME;
  const root = path.join(home, '.npm', '_npx');
  if (!fs.existsSync(root)) return null;
  for (const d of fs.readdirSync(root)) {
    const nm = path.join(root, d, 'node_modules');
    if (fs.existsSync(path.join(nm, 'playwright'))) return nm;
  }
  return null;
}

function fetchBodyPaywall(url) {
  if (!fs.existsSync(PAYWALL_READER)) {
    log(`paywall reader not found at ${PAYWALL_READER}`);
    return null;
  }
  const nodePath = findPlaywrightNodePath();
  const env = { ...process.env };
  if (nodePath) env.NODE_PATH = nodePath;
  const r = cp.spawnSync('node', [PAYWALL_READER, url], { env, encoding: 'utf-8', timeout: 60000 });
  if (r.status !== 0) {
    log(`paywall reader failed for ${url}: ${(r.stderr || '').split('\n')[0]}`);
    return null;
  }
  return (r.stdout || '').trim() || null;
}

async function fetchBodyPlain(url) {
  try {
    return await fetchText(url);
  } catch (e) {
    log(`plain fetch failed for ${url}: ${e.message}`);
    return null;
  }
}

function withinLookback(pubDateStr, lookbackDays) {
  const d = new Date(pubDateStr);
  if (isNaN(d.getTime())) return false;
  const cutoff = Date.now() - lookbackDays * 86400 * 1000;
  return d.getTime() >= cutoff;
}

async function pMap(items, limit, fn) {
  const out = new Array(items.length);
  let i = 0;
  const workers = Array(Math.min(limit, items.length)).fill(0).map(async () => {
    while (true) {
      const idx = i++;
      if (idx >= items.length) return;
      out[idx] = await fn(items[idx], idx);
    }
  });
  await Promise.all(workers);
  return out;
}

(async () => {
  const { corpusName, lookbackDays: lbOverride } = parseArgs(process.argv);
  const corpusPath = path.join(SKILL_DIR, 'corpora', `${corpusName}.yaml`);
  if (!fs.existsSync(corpusPath)) {
    process.stderr.write(`Corpus YAML not found: ${corpusPath}\n`);
    process.exit(1);
  }
  const corpus = parseCorpusYaml(fs.readFileSync(corpusPath, 'utf-8'));
  const lookback = lbOverride || corpus.lookback_days || 7;

  log(`corpus: ${corpus.name} | lookback: ${lookback}d | sources: ${corpus.sources.length}`);

  const allArticles = [];
  for (const src of corpus.sources) {
    log(`fetching RSS: ${src.rss_url}`);
    let rss;
    try {
      rss = await fetchText(src.rss_url);
    } catch (e) {
      log(`RSS fetch failed for ${src.id}: ${e.message}`);
      continue;
    }
    const items = parseRss(rss);
    const inWindow = items.filter(it => it.pubDate && withinLookback(it.pubDate, lookback));
    log(`  ${src.id}: ${items.length} items in feed, ${inWindow.length} in lookback window`);

    if (src.fetch_full_body) {
      log(`  fetching ${inWindow.length} bodies via ${src.paywall_reader ? 'paywall reader' : 'plain'} (parallel ${PARALLEL})`);
      const bodies = await pMap(inWindow, PARALLEL, async (it) => {
        if (src.paywall_reader) return fetchBodyPaywall(it.link);
        return fetchBodyPlain(it.link);
      });
      inWindow.forEach((it, i) => { it.body = bodies[i]; });
      const fetched = inWindow.filter(it => it.body).length;
      log(`  fetched ${fetched}/${inWindow.length} bodies successfully`);
    }
    inWindow.forEach(it => { it.source_id = src.id; it.source_name = src.name; });
    allArticles.push(...inWindow);
  }

  const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const runDir = path.join(SKILL_DIR, 'scans', '.runs', `${ts}-${corpus.name}`);
  fs.mkdirSync(runDir, { recursive: true });
  const outPath = path.join(runDir, 'corpus.json');

  const out = {
    corpus: corpus.name,
    description: corpus.description || null,
    lookback_days: lookback,
    fetched_at: new Date().toISOString(),
    sources: corpus.sources.map(s => ({ id: s.id, name: s.name, domain: s.domain })),
    article_count: allArticles.length,
    full_body_count: allArticles.filter(a => a.body).length,
    articles: allArticles,
  };

  fs.writeFileSync(outPath, JSON.stringify(out, null, 2));
  log(`wrote ${allArticles.length} articles (${out.full_body_count} with bodies) to corpus.json`);
  process.stdout.write(outPath + '\n');
})().catch(e => {
  process.stderr.write(`fatal: ${e.stack || e.message}\n`);
  process.exit(1);
});
