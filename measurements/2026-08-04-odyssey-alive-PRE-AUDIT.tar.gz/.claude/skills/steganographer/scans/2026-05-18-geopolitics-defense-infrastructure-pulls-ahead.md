# Geopolitics Horizon Scan — 2026-05-11 to 2026-05-18 — 50 articles, 30+ contributors, 3 sources

*Multi-source corpus: Just Security (10 articles, 7 full bodies), War on the Rocks (20 articles, 20 full bodies), Defense One (20 articles, 20 full bodies). 47 of 50 bodies fetched (3 Just Security URLs failed on HTML-entity-encoded query strings — known ingest bug, not blocking). Cross-source confidence framing available where signals appear in ≥2 sources or corroborate a prior-scan entry from the `foreign-policy` corpus.*

## 1. Scan Note

Eight days, 50 articles, three publications that are all *of the defense and legal-analysis ecosystem* rather than outside it — and a corpus that is no longer asking whether the 2017–2026 US foreign-policy posture is failing. It is asking *what comes next*. WoR is publishing lessons-learned papers from a war that is still ongoing. Defense One is tracking a Congressional revolt over a Pentagon drawdown that breaches statutory minimums. Just Security is maintaining a 800-case litigation tracker. The expert infrastructure has moved past acknowledgment and is already drafting the next system, quietly, in technical journals, while the editorial press (per yesterday's [foreign-policy scan](2026-05-18-foreign-policy-consensus-fracture.md)) is still narrating the close of the old one.

## 2. Emerging Signals

**Signal A — "Cheap kill at scale" has been ratified into US Pacific Command doctrine; the drone-vs-traditional-assault economics is no longer a research question but a doctrinal premise.**

- Evidence:
  - Hlad (Defense One, May 16): Indo-Pacific Command leader Adm. Samuel Paparo at AUSA's Land Forces Pacific symposium identified one of three "meta-trends" reshaping warfare as *"the commoditization—and by commoditization, I mean everybody has it—of small, cheap unmanned systems. ... Proliferated unmanned systems have made cheap kill, at scale more possible, more probable. Has made a traditional assault—ground assault, air assault, airborne assault, amphibious assault—much more costly than is in our formal doctrine."* He cited Ukraine: Russians lose "approximately 100 human beings per square kilometer of ground that they take and that then they subsequently lose."
  - Deptula (WoR, May 18): "Missiles Aren't Strategy: Lessons From Iran for a Pacific Air War."
  - Steckler (WoR, May 18): "Army Aviation's Wasted Decade: Lessons for the Next Generation of Drone Integration."
  - Jung (WoR, May 15): "South Korea's 500,000 Drone Warriors Will Be a Hollow Force" — even allied drone surges are now subject to critique on quality grounds.
  - Multiple Defense One pieces: "Air Force MQ-9 downs aerial targets with cheap air-to-air missiles," "US infantry's drone-warfare experiments are getting bigger," "Drone boats make debut in Navy's 30-year shipbuilding plan."
- STEEP: Technical, Military
- Horizon: near (already shaping FY27 budget requests and posture statements)
- Confidence: corroborated cross-source (Defense One + WoR, ≥7 articles)
- So what: when a combatant commander's keynote contains the phrase "cheap kill at scale" and three independent lessons-learned papers run inside seven days, the framing has been internalized. The doctrinal pivot is no longer aspirational; it's now the premise that subsequent procurement, training, and force-design arguments are made *from*. Worth watching whether the FY27 NDAA reflects this premise structurally or whether legacy-program inertia overrides it.

**Signal B — Congress has moved into open contestation with the Pentagon over the Europe drawdown. (Strengthens prior FP Signal B; now elevated to cross-source.)**

- Evidence:
  - Myers (Defense One, May 15): HASC Chairman Mike Rogers (R-Ala.) at hearing on canceled Poland deployment — *"It is not the fault of the people in front of us today that we've had this apparent deviation, but know: we are going to mandate that the department follow the statutory minimums that are set in statute on force posture. And if there are attempted deviations, we will remedy them and impose a pain when—if—they aren't complied with."* Same article: U.S. troops in Europe will fall below the **legal mandate of 76,000** if the recently-announced 5,000-troop German withdrawal completes.
  - Novelly (Defense One, May 15): Hegseth has ordered a sweeping, open-ended review of the Pentagon's legal system after gutting a Congressionally-created oversight panel. Retired Air Force lawyer Steve Lepper: *"What the Pentagon here is doing is, they're basically wrestling from Congress this oversight of the JAG Corps and substituting his own panel for the panel they dismantled."*
  - Cross-reference: the prior [foreign-policy scan, Signal B](2026-05-18-foreign-policy-consensus-fracture.md) flagged the German withdrawal and Poland cancellation as a single FP-sourced signal. Defense One now anchors it independently and adds the Congressional response.
- STEEP: Political, Military
- Horizon: near (legal-minimum breach mechanics will trigger in weeks, not months)
- Confidence: **corroborated cross-source** (FP-ledger + Defense One; statutory-minimum citation independently verified)
- So what: the friction has moved from "Trump administration vs. allies" to "Trump administration vs. its own legislature." HASC chairmen do not threaten "pain" at hearings absent a credible coalition behind them. Statutory minimums are about to be tested — either via appropriations conditioning, a contempt finding, or court action. Allies and adversaries will price the *intra-government* contestation, not just the executive posture.

**Signal C — Asian allies are quietly refusing US Hormuz operations; the alliance machinery the US assumed it had in the Indo-Pacific does not exist when tested.**

- Evidence:
  - Samaan (WoR, May 13): *"On May 4, 2026, a South Korean vessel came under fire in the Strait of Hormuz, leading President Donald Trump to urge the government in Seoul to join the U.S.-led operation to secure the waterway. The South Korean government politely replied it would 'review' the American proposal."* Samaan's thesis: *"The closure of the Strait of Hormuz, the worst maritime crisis in decades, is fundamentally an Asian problem, yet Asia is almost entirely absent from the debate over how to resolve it."*
  - Same article: Singapore Foreign Minister Vivian Balakrishnan — *"the closure of the Strait of Hormuz is, in a sense, an Asian crisis."* But: *"Indonesia's finance minister sparked a diplomatic kerfuffle when he publicly flirted with the idea of imposing a toll on vessels crossing the Strait of Malacca — an idea immediately condemned by Malaysia and Singapore."* The chain-reaction risk has been named publicly.
  - Cross-reference: the [foreign-policy scan, Signal A](2026-05-18-foreign-policy-consensus-fracture.md) noted NATO allies denying Trump's de-mine request, after which Trump denied requesting assistance. The pattern repeats in Asia with politer diction ("review the proposal") and the same outcome.
- STEEP: Political, Military, Economic
- Horizon: medium (rewriting Indo-Pacific planning assumptions takes 6–12 months)
- Confidence: corroborated within source (WoR primary; FP-ledger entry contextualizes)
- So what: US Indo-Pacific strategy has assumed an Asian functional equivalent of NATO's collective-action machinery. Hormuz revealed it does not exist. The post-2017 "Quad-plus" architecture appears load-bearing on paper but is not, in this case, structurally so. Worth watching whether Taiwan-contingency planning assumptions are quietly revised over the next two quarters and whether RAND, CNAS, or CSIS publish on this gap.

**Signal D — Litigation has become a structural feature of US foreign-policy execution. (Cross-corroborates FP Signal D; magnitude now numerically anchored.)**

- Evidence:
  - Just Security (May 18, "Litigation Tracker: Legal Challenges to Trump Administration Actions"): *"Total number of cases currently tracked: 800."* The fact that JS is *maintaining a living, searchable tracker for executive-action challenges* is the structural signal; the count is the magnitude. Cases span Civil Liberties, DEIA, Enforcement, Federalism, Immigration, International Institutions, Trade Law, Transparency, and Structure of Government.
  - Kausner (WoR, May 18, "Regulatory Friendly Fire: How ITAR Undermines the Alliance It Was Built to Protect"): *"The arms export system designed to protect American military superiority now risks ceding it."* He cites: *"Arab partners expended hundreds of high-end interceptors to combat low-cost drones during Operation Epic Fury"* and that allied governments increasingly "look inward" because U.S. export licenses take months while software-centric weapons iterate in weeks.
  - Michel (Just Security, May 18, "The United States: Sanctions Implementer and Sanctions Safe Haven?"): argues sanctions are temporarily effective on individual networks but networks rebuild, and the US itself is structurally permissive of sanctioned-actor wealth concealment via its real-estate and shell-company regimes.
  - Cross-reference: [FP scan, Signal D](2026-05-18-foreign-policy-consensus-fracture.md) flagged judicial-executive friction as showing up beneath every economic story; geopolitics corpus extends this to arms transfers, sanctions, and tariff authority.
- STEEP: Political, Legal, Economic
- Horizon: medium (legal cases shape posture options on rolling 6-month cycles)
- Confidence: **corroborated cross-source** (Just Security + WoR + FP-ledger)
- So what: US foreign-policy capacity now travels through a legal/regulatory medium that is contested, brittle, and explicitly tracked. The traditional "policy → execution" pipeline has been replaced by "policy → litigation → execution." Allies have to forecast not just US intent but US legal capacity at any given moment. 800 active executive-action lawsuits is the operational reality. The "Donroe Doctrine" coined in the FP scan now has a procedural counterweight: the courts.

**Signal E — Golden Dome's CBO estimate ($1.2T) is the next major budget fight, with a 7× gap from Trump's promised number.**

- Evidence:
  - Novelly (Defense One, May 12): *"The Golden Dome missile-defense system would cost $1.2 trillion to build out, far more than the White House has budgeted, according to a new estimate by Congressional researchers. ... nearly seven times larger than President Trump's original promise to build it for $175 billion. ... fifteen times larger than the $79 billion the administration plans to spend in the Golden Dome for America account over the next five years."* And: *"$730 billion would purchase only enough space-based interceptors to destroy about 10 incoming ballistic missiles."* The program's own leader has conceded that space-based interceptors "may be too costly to build."
  - Defense One (May 14): "Golden Dome defenders push back on $1.2T cost estimate" — the same-day defense response is itself the budget-fight signal.
  - Context: Myers (Defense One, May 12): "Congress waits on Iran-war costs while mulling $1.5T defense request" — the Golden Dome figure is being introduced into a budget cycle that already has unresolved Iran-war supplementals stacking up.
- STEEP: Political, Economic, Military
- Horizon: medium (FY27 NDAA cycle is the resolution venue)
- Confidence: single weak signal — but a CBO-cost-naming event with a 7× gap from the announced figure is itself a structural signal; CBO numbers anchor the subsequent Hill debate
- So what: the Golden Dome cost gap is too large to absorb through routine budget reconciliation. Either Congress funds a fraction (announcement signal: the program is cosmetic), the administration descopes publicly (announcement signal: the missile-defense premise was overpromised), or both. The CBO number is the negotiating floor for everything that follows. Worth tracking whether the FY27 NDAA carries a Golden Dome line and at what number.

## 3. Trends Strengthening

- **FP Signal B (Pentagon withdrawals from Europe)** → strengthened. Defense One independently anchors the 76,000-troop statutory minimum and reports HASC Chairman Rogers' explicit "pain" threat at hearing. Single-source FP signal now **elevated to cross-source confidence.**
- **FP Signal D (judicial-executive friction)** → strengthened. Just Security's 800-case tracker provides the numerical anchor the FP scan lacked, and the WoR ITAR piece + JS sanctions-safe-haven piece show the friction extending to arms transfers and sanctions enforcement.

## 4. Trends Fading

- **FP Signal C (AI-slop / meme propaganda as serious analytical category)** → not present in the geopolitics corpus. The defense and legal-analysis communities have not yet adopted the meme-warfare frame. The lag is striking given how fast WoR usually picks up doctrinal vocabulary from public-facing analysis. Two readings possible: (a) FP Signal C was idiosyncratic to ISD-adjacent disinformation analysts and won't generalize; (b) the geopolitics corpus is one cycle behind on this specifically. Re-check at next scan.

## 5. Cross-Cutting Theme

Two corpora, one underlying current: **the editorial press is narrating the close of the 2017–2026 foreign-policy system; the expert infrastructure has already moved past it.** Where the [foreign-policy scan](2026-05-18-foreign-policy-consensus-fracture.md) showed FP's verbs hardening ("greatest failure," "remarkably banal," "humiliated"), the geopolitics corpus shows the *next layer of consequences materializing as routine work*: doctrine being rewritten around drone economics, Congress moving on statutory-minimum breaches, 800 cases tracked in a living database, the Indo-Pacific alliance machinery being audited in real time after its Hormuz failure, the Golden Dome budget being formally costed at 7× its announced number. The corpus is not editorializing about failure. It is *operationalizing the new posture's premises*. *Looking back from 2027, May 2026 may read as the inflection week when the surface narrative caught up with what the technical and legal classes had been quietly building toward for months — and the geopolitics-corpus signal will be a cleaner leading indicator than the editorial-press signal, because the expert infrastructure has fewer reasons to perform hesitation.*

## 6. What This Scan Cannot Tell You

The corpus is not independent of the institution it covers. War on the Rocks and Defense One are *of* the Pentagon's intellectual and audience ecosystem; their critiques of Hegseth and force posture are internal-family critique, not adversarial. Just Security is a Reichman-affiliated, Carnegie-funded law school adjunct; its 800-case tracker is methodologically disclosed but the inclusion criteria are not independently audited. No Chinese, Iranian, Russian, Korean, Japanese, or Indian defense-press perspectives are present — Signal C in particular needs a Korean or Japanese counter-read before being treated as cross-spectrum. The "lessons from Iran" framing across WoR (Deptula, Steckler) and FP assumes a war that is meaningfully closed for analytical purposes; the war remains ongoing and the lessons may be premature, captured-by-narrative, or both. The Golden Dome cost gap signal rests on one CBO estimate that the administration disputes — wait one cycle for whether the program leader's costly-to-build admission persists. Three of ten Just Security articles failed to fetch (RSS HTML-entity URL bug); their content is not represented here.

This is the second scan in the steganographer ledger. Two data points do not establish a trend. The "strengthened" entries in §3 should be re-checked at the next pull of either corpus; the "fading" entry in §4 needs a second cycle before it's anything but absence.

## 7. Source Ledger

- **Feeds:**
  - `https://www.justsecurity.org/feed/` — 10 items, 7 bodies fetched, 3 failed on URL encoding (Carter "Overcoming Crime and Corruption"; Jennings "Early Edition May 15"; Just Security "Digest May 11-15")
  - `https://warontherocks.com/feed/` — 100 items in feed, 20 in 7-day lookback, all 20 bodies fetched
  - `https://www.defenseone.com/rss/all/` — 25 items in feed, 20 in 7-day lookback, all 20 bodies fetched
- **Total:** 50 articles, 47 with full bodies
- **Period covered:** 2026-05-11 to 2026-05-18 (8 days)
- **Fetch time:** 2026-05-18T22:25:10Z
- **Run dir:** `.claude/skills/steganographer/scans/.runs/2026-05-18T22-25-10-geopolitics/`
- **Contributors (≥30):** Carpenter, Karlshoej-Pedersen, Hooper, Watt, Michel, Jennings, Carter, Just Security (institutional), Jung, Bowen, Deptula, Steckler, Kausner, WOTR Staff, Varfolomeeva, Evans, Neslony, Isler, Itani, Termine, Goldenziel, Donovan, Coates Ulrichsen, Faisal, McNeil, Samaan, Friedman, DiMolfetta, Novelly, Myers, Hlad, Tucker, Williams, Montgomery
- **Cross-references:** [foreign-policy scan, 2026-05-18](2026-05-18-foreign-policy-consensus-fracture.md) (yesterday's single-source FP scan; signals corroborated in §3)
