# Narrative-Economics Horizon Scan — 2026-05-04 to 2026-05-18 — 25 articles, 2 contributors, 2 sources (1 dead)

*Two-source effective corpus: Marginal Revolution (15 articles) and The Big Picture / Ritholtz (10). The third configured source, Calculated Risk, returned zero in-window items — the blog announced its end on 2026-01-12 ("After 21 years of writing this blog almost daily, I've decided to stop writing the daily updates") and migrated to Substack newsletters. Also: my Atom-feed detector requires double-quoted xmlns; CR's feed uses single quotes, so the parser would not have recognized it as Atom even if it had been active. Both issues are documented below. 25 of 25 bodies fetched.*

## 1. Scan Note

A thin corpus with a structural impedance mismatch. MR and Ritholtz are both link-curator-format blogs (daily "assorted links" / "10 AM Reads" roundups), where the signal lives in *what gets aggregated* rather than in any single piece's thesis — exactly the synthesis pattern that v1's LLM-direct approach handles poorly, and that v2's mechanical signal layer (BERTopic + KeyBERT + JSD over a curated stream) was designed for. The scan still produced two genuinely useful findings — both are *cross-corpus corroborations* of signals already surfaced in the [foreign-policy](2026-05-18-foreign-policy-consensus-fracture.md) and [geopolitics](2026-05-18-geopolitics-defense-infrastructure-pulls-ahead.md) ledgers — plus one structural observation about the corpus itself. New native signals are smaller and more tentative than in the prior scans.

## 2. Emerging Signals

**Signal A — Asian-trade narrative is entering the economic-commentary layer; corroborates geopolitics Signal C ("Asia is acting differently").**

- Evidence:
  - Cowen (MR, May 17, "South Korea facts of the day"): a historically-framed defense of trade-deficit-tolerant development. *"Even in the early 1970s, South Korea was still poorer than the North ... There was no consensus that East Asia would do better than Latin America."* The piece's framing of South Korea's deficit history reads as direct counterargument to current US tariff discourse. The top comment names it explicitly: *"What if South Korea had obsessed over its trade deficits the way Long Face obsesses over our trade deficits?"*
  - Ritholtz (May 17, "10 Sunday Reads"): lead bullet — *"Trump's China Trip Underscores How Power Has S[hifted]"* (RSS preview truncates).
  - Cross-reference: [geopolitics scan, Signal C](2026-05-18-geopolitics-defense-infrastructure-pulls-ahead.md) (Samaan WoR piece on South Korea politely declining Hormuz; Asian alliance machinery shown not to exist when load-tested). The economic-commentary layer is now picking up the same Asian-realignment theme on a different evidence base (trade-deficit history rather than naval coordination).
- STEEP: Economic, Political
- Horizon: medium (narratives at this stage typically need 60–90 days to cohere into broader commentary consensus)
- Confidence: **corroborated cross-corpus** (narrative-economics + geopolitics-ledger, on different evidence)
- So what: when an Asian-realignment frame surfaces simultaneously in the defense-analytical literature (load-test failure) and the economic-commentary layer (historical-revisionist defense of deficit-tolerant development), the consensus shift is broader than either field alone. Cowen specifically is often early on East-Asia narrative inflections. Worth watching whether FT, Economist, or WSJ opinion pages adopt the deficit-historical reframing in the next 30 days.

**Signal B — AI has become the explicit cognitive substrate of economic-research curation, not just a topic *of* economic research.**

- Evidence:
  - Cowen (MR, May 16, "Revealing Life Preferences Through LLMs"): NBER working paper using *GPT-5.4 as a research substrate* to predict human life-course preferences. *"A person's choice is better predicted by the LLM's choice than by another person's choice over the same stories ... LLM responses offer a scalable and cost-effective complement to existing methods for studying human preferences."*
  - Tabarrok (MR, May 17, "Dwarkesh in the Datacenter"): explicitly economic framing — *"It's extraordinary how much compute goes into finance. (I once predicted that the finance AIs would be the first to become conscious, since they have the most compute.)"*
  - Cowen (MR, May 18, "Monday assorted links"): items 1–3 are all AI-economics — a new newsletter "AI and agentic coding, filtered for economists," "Can AI replace Richard Hanania?," "Using AI agents for economic preco[mputation]."
- STEEP: Technical, Economic, Social
- Horizon: near (already in motion)
- Confidence: single weak signal at the per-corpus level — MR is one source — but striking because the framing change is *meta* (AI as research medium, not research topic)
- So what: when an NBER paper uses an LLM as a stand-in for human preference elicitation, and a leading economics blog treats this as routine ("here is some Weberian verstehen ... but from unexpected quarters"), the economics profession has crossed a methodological threshold. This is the analogue of when survey-research methodology accepted internet panels as primary data. Worth tracking whether more NBER/AEA/QJE papers adopt LLM-as-substrate methodology in the next 12 months — that would mark formal acceptance.

**Signal C — Single weak signal: SEC's semiannual-earnings proposal + Trump's 3,700 trades = a coming market-microstructure governance fight.**

- Evidence: Ritholtz (May 15, "Good Quarterly Earnings Behavior"): *"The SEC has proposed allowing companies to move to semiannual earnings reporting"* — argued against on transparency/volatility/insider-trading grounds. Plus (May 18, "10 Monday AM Reads"): lead bullet *"Trump's More Than 3,700 Trades Astonish Wall Street Insiders."*
- STEEP: Political, Economic
- Horizon: medium (SEC rulemaking cycles)
- Confidence: single weak signal — one source, one specialized angle
- So what: market-microstructure governance is shifting under a president who is himself an active trader. The combination is not in itself a finding, but it's the kind of pairing that becomes obvious-in-retrospect. The geopolitics and foreign-policy corpora do not surface this at all — making it a candidate "single-corpus original signal" worth tracking even at low confidence.

## 3. Trends Strengthening

- **[Geopolitics Signal C](2026-05-18-geopolitics-defense-infrastructure-pulls-ahead.md) (Asian alliance reluctance / "Asia is acting differently")** → strengthened from a different evidentiary direction. The defense-analyst version was naval-coordination failure; the economic-commentary version is trade-deficit-history reframing. Two different fields, same underlying realignment.

## 4. Trends Fading

- **[Foreign-policy Signal C](2026-05-18-foreign-policy-consensus-fracture.md) (AI slop / meme propaganda as serious analytical category)** → still absent in this corpus, as in geopolitics. Two scans now without corroboration. Not yet "fading" — could be (a) idiosyncratic to ISD-adjacent disinformation analysts; (b) the topic-domain mismatch (econ blogs don't cover propaganda); (c) genuinely premature. Recheck at next FP scan.

## 5. Cross-Cutting Theme

This scan's most useful function was *not* native discovery — it was *cross-corroboration*. The South Korea / Asian-realignment thread appears in three corpora across two distinct fields (defense-analysis evidence, economic-commentary evidence, editorial verb-register evidence). When a single underlying shift surfaces across three independent analytical communities on three different evidence bases inside a 7-day window, the shift is *real* in a way that single-source detection cannot establish. This is the multi-corpus value the skill was built to deliver, and it materializes only when the ledger has more than one scan to compare against. *Looking back from 2027, May 2026 may be remembered as the moment the "Asia is hedging the US" narrative crystallized — and the leading indicator was not in any single publication's argument but in the joint convergence pattern across the defense, economic, and editorial commentary layers.* The scan also exposes a v1 design constraint that wasn't visible before: link-curator publications need the mechanical signal layer (BERTopic + KeyBERT) to be analytically tractable; LLM-direct synthesis on them produces signals that are smaller and more easily-rationalized than the corpus actually supports.

## 6. What This Scan Cannot Tell You

**Two-source corpus.** Three was the design intent; Calculated Risk is dead since 2026-01-12 and migrated to Substack newsletters at `economicweekly.substack.com` and `calculatedrisk.substack.com`. **The corpus YAML needs replacement** with a live source — candidates: Slow Boring (Yglesias), Noahpinion (Smith), Conversable Economist (Taylor), Klement on Investing, or one of the Substack successors above. **Parser bug**: my Atom detector requires double-quoted xmlns; Calculated Risk's Blogger feed uses single quotes. Even if the blog had been active, the parser would have skipped it. Two-character fix; will ship with the next ingest update.

**MR is heavily Tyler Cowen's personal lens.** Cowen amplifies what *he* finds notable, which is often early but is also idiosyncratic. The "Detroit resurgence" signal (two MR posts in one week) is exactly the kind of pattern that could be either (a) early-narrative-emergence on a regional economic story or (b) Cowen-spent-a-weekend-in-Michigan. The skill cannot distinguish these without longitudinal MR baseline data. I omitted Detroit from §2 for this reason.

**Link-curator format limits.** Ritholtz's "10 [Day] AM Reads" posts are seven of his ten articles — these have very low individual signal (one-line link descriptions) but high meta-signal (*what categories of links get curated this week*). The v1 LLM-synthesis approach cannot extract the meta-signal cleanly. v2's mechanical layer (KeyBERT novel-phrase extraction on curated link descriptions across a rolling baseline) would.

**No FT, Economist, Bloomberg Opinion, or financial-press primary coverage.** The corpus only represents the *blog-commentary* layer of narrative economics, not the institutional-press layer where many narratives form first. Adding even one paid-RSS-accessible source would substantially change the cross-source confidence available.

**14-day lookback produced only 25 articles.** Both active sources are lower-volume than expected. The skill assumed news-cycle-volume sources; econ-commentary blogs publish less. Either the lookback default should extend to 30 days for this corpus, or the corpus needs more sources.

**No new-signal high-confidence finding.** Signals A and B are corroborations of prior-scan or methodological-meta observations; Signal C is single-source and weak. A scan with zero confident-novel findings is a valid honest output — but it's worth naming.

## 7. Source Ledger

- **Feeds:**
  - `https://marginalrevolution.com/feed` — 15 items in feed, 15 in 14-day lookback, all 15 bodies fetched
  - `https://www.calculatedriskblog.com/feeds/posts/default` — **0 items returned**; blog dormant since 2026-01-12; parser also has Atom-detection bug for single-quoted xmlns
  - `https://ritholtz.com/feed/` — 10 items in feed, 10 in 14-day lookback, all 10 bodies fetched
- **Total:** 25 articles, 25 with full bodies
- **Period covered:** 2026-05-04 to 2026-05-18 (14 days)
- **Fetch time:** 2026-05-18T22:48:12Z
- **Run dir:** `.claude/skills/steganographer/scans/.runs/2026-05-18T22-48-12-narrative-economics/`
- **Contributors (2):** Tyler Cowen and Alex Tabarrok (MR); Barry Ritholtz (TBP)
- **Cross-references:**
  - [foreign-policy scan, 2026-05-18](2026-05-18-foreign-policy-consensus-fracture.md) — Signal C "AI slop" still absent in this corpus
  - [geopolitics scan, 2026-05-18](2026-05-18-geopolitics-defense-infrastructure-pulls-ahead.md) — Signal C "Asia acting differently" strengthened here (Cowen's South Korea piece + Ritholtz's China-trip framing)
