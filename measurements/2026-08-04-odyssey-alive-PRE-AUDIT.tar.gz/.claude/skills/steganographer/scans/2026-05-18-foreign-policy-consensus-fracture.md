# Foreign Policy Horizon Scan — 2026-05-13 to 2026-05-18 — 25 articles, 26 contributors

*Single-source corpus. FP RSS only. Authentication-gated; 25 of 25 bodies fetched, though 16 returned paywalled-preview-length and 9 returned full-text bodies (>5KB). All five "anchor signal" articles cited below are quoted from fetched bodies or full-text previews containing the cited material.*

## 1. Scan Note

Six days, 25 articles, 26 contributors across the Argument / Analysis / World Brief / Latin America Brief desks — and an editorial corpus that has stopped hedging. FP's writers this period are converging on a single thesis through five different angles: that the Trump foreign-policy posture is failing simultaneously across Iran, China, Lebanon, Cuba, and the NATO alliance, and the failure is no longer being framed as "controversial" but as visibly *systemic*. The notable absences: no FP piece arguing a contrarian case for the administration's approach, and no positive coverage of any major bilateral outcome from the Beijing summit.

## 2. Emerging Signals

**Signal A — The hedge-language has been retired.**

- Evidence:
  - Agrawal (editor-in-chief, May 18): "Iran Could Be Trump's *Greatest Failure*. A lot of things have gone horribly wrong—and it's not over yet."
  - Agrawal again (May 18, "What Happened When Trump Met Xi"): reduces the entire summit to a diplomat's two-word summary — *"'Beans and Boeings.' That's what one diplomat told me last week's summit ... amounted to."*
  - Palmer (deputy editor, May 15): the Trump-Xi summit was "*Remarkably Banal*."
  - Heller (May 15): Trump is "*humiliating the Lebanese government*"; Lebanon negotiations are "*Breaking the Country*."
  - Clarke/Broekaert (May 15): the 2026 counterterrorism strategy is "*Alarming*" — "riddled with partisanship, misplaced assumptions, and a failure to grasp the nuance of terrorists' ideology ... appears to mis-prioritize the most imminent terrorist threats."
  - Simon (May 14): Israel's Lebanon strategy is "*Self-Defeating*."
  - Kampfner (May 14): "*Why Keir Starmer Will Fall*."
- STEEP: Political
- Horizon: near (already in motion)
- Confidence: corroborated within source (7+ articles, 4 desks, including both the editor-in-chief and deputy editor)
- So what: FP historically *leads* US-establishment realignment by weeks. This is the verb register the publication adopts after privately concluding a posture is unrecoverable. The October 2009 / February 2017 / March 2020 equivalents preceded broader-media framing shifts by 30–60 days each. Worth watching whether the FT and Economist editorial pages follow inside the next month.

**Signal B — Rhetorical posture is producing real Pentagon withdrawals from Europe.**

- Evidence:
  - Sharp (May 15, "Ratcliffe's Trip to Havana"): "the Pentagon said it will withdraw 5,000 U.S. troops from Germany after German Chancellor Friedrich Merz said that Iran had 'humiliated' the United States." Same article: U.S. Defense Secretary Hegseth "abruptly canceled the deployment of 4,000 U.S. troops to Poland on Thursday, without citing a reason." The Polish defense minister said Warsaw had received assurances "the Americans do not plan to systematically reduce the U.S. presence in Poland" — but the action is the data.
  - Agrawal (May 18): "Trump asked NATO allies in Europe to help the White House forcibly reopen and de-mine the Strait of Hormuz. Upon realizing that no help would be forthcoming, he denied ever requesting assistance."
  - Sharp (May 15) confirms: "an apparent larger realignment of U.S. forces in Europe, as Trump stresses that the continent needs to take on greater responsibility for its own security amid the White House's growing ire toward NATO allies over their perceived lack of support for U.S. actions against Iran."
- STEEP: Political, Military
- Horizon: near (9,000 troops in motion over two weeks)
- Confidence: corroborated within source (2 articles cite the cascade independently)
- So what: rhetorical reciprocity has crossed into materiel reciprocity. When a chancellor's word ("humiliated") triggers a 5,000-troop withdrawal inside two weeks, the alliance is no longer being managed at the diplomatic-friction layer — it is being managed at the force-posture layer. Allies and adversaries will price this. Worth watching whether NATO Article 4 consultations are quietly initiated by any frontier state in the next 60 days.

**Signal C — "AI slop" has entered the foreign-affairs vocabulary as a serious analytical category.**

- Evidence: Benzoni (May 18, Institute for Strategic Dialogue researcher publishing in FP — not in a security blog): *"If you want to understand the future of propaganda, stop reading serious-minded reports about Russia and start watching Iranian Lego diss rap videos, looking at embassy shitposts, and consuming pro-Iran AI slop. A hundred days ago, Iran was a pariah state massacring protesters en masse. Today, it's the internet's main character. ... The Trump administration churns out its own AI slop, its own combative memes, its own shitposts. None of it lands. This kind of propaganda works best when it's punching up, and you're not punching up when you're the one dropping the bombs."*
- STEEP: Technical, Social, Political
- Horizon: near
- Confidence: single weak signal (one article), but striking source (ISD analyst — a mainstream disinformation think-tank — placing this argument in FP's Argument section)
- So what: disinformation analysis is bending toward acknowledging that the dominant propaganda mode of 2026 is meme/AI-generated, not the Russia-firehose model the field built its frameworks for. State-vs-state contests are now partly being fought in AI-content terrain that the analytical establishment has only just acknowledged. Direct intersection with the steganographer skill's own threat model. Worth watching whether Graphika and DFRLab publish methodology updates in the next two quarters.

**Signal D — Judicial-vs-executive friction is becoming the unmentioned co-author of every economic story.**

- Evidence:
  - Sharp (May 18, G-7 Finance): "In February, the European Union paused work on implementing a trade deal with the United States after the U.S. Supreme Court ruled against Trump's sweeping tariffs. In response, the White House has threatened to increase duties on European vehicles by 10 percentage points."
  - Sharp (May 14, Beijing summit): "several U.S. court rulings against the president's ability to impose sweeping tariffs on China and other countries, Trump faced extra pressure going into the summit to secure big economic wins."
  - Implicit in Osborn (May 15, Argentina): the U.S. Treasury and IMF as backstop options for Milei's Argentina presuppose unconstrained US capacity — quietly contradicted by these court rulings.
- STEEP: Political, Economic
- Horizon: medium (legal cases shape policy options on 6-month rolling basis)
- Confidence: corroborated within source (2 articles + 1 implicit)
- So what: every Trump-economic-leverage story has an unstated footnote — "subject to court rulings against tariff authority." Reporting that doesn't surface the constitutional layer is going to read incomplete six months from now. The diplomatic counterparts already know this; the framing is starting to surface in FP.

**Signal E — "Donroe Doctrine" has been named.**

- Evidence: Sharp (May 15, Ratcliffe): "For months, the Trump administration has pushed for regime change in Cuba as part of the White House's larger '*Donroe Doctrine*.'" Quoted with single quotes as a coined term, not yet in scare-quotes-of-disavowal. Same article documents the operational reality: US forces seized Venezuelan President Nicolás Maduro in January; took control of Caracas's oil industry; blockaded Cuba; Cuban energy minister reports "no fuel oil, absolutely no diesel" with blackouts at 20-22 hours. Cuban president called it a "genocidal energy blockade."
- STEEP: Political, Economic
- Horizon: medium (a coined-and-named doctrine becomes a frame for everything subsequent)
- Confidence: single weak signal (one article — *but* the naming event itself is the signal; you only see it once)
- So what: when a publication of FP's weight starts using "Donroe Doctrine" without scare quotes, the regional-policy consensus has crystallized. This is how Brzezinski's "Grand Chessboard" terminology entered the lexicon. Track whether the term shows up in two more FP pieces inside 30 days; if it does, it has graduated from coinage to consensus vocabulary.

## 3. Trends Strengthening

*First scan — no prior ledger entries to compare.*

## 4. Trends Fading

*First scan — no prior ledger entries to compare.*

## 5. Cross-Cutting Theme

Five signals, one current: **FP's editorial class has stopped pretending the Trump foreign-policy posture is salvageable, and the language shift is itself the news.** The articles aren't reporting new facts — the Iran war's costs, the Beijing summit's emptiness, the Lebanon photo-op humiliations, the counterterrorism strategy's gaps, the Cuba blockade's collapse mechanics, the Pentagon's quiet European drawdown — these have all been observable for weeks. What's new is the *vocabulary*. "Greatest failure." "Remarkably banal." "Breaking the country." "Self-defeating." "Alarming." "Beans and Boeings." "Donroe Doctrine." "Humiliated." This is the register elite publications adopt *after* they have privately concluded a thing. The corpus is not showing us the events; it is showing us *the moment the analytical class acknowledges them* — which historically leads broader-media framing by two to six weeks and policy-establishment realignment by one to three months. *Looking back from 2027, the May 2026 FP issues will likely read as the inflection week the foreign-policy consensus visibly fractured — not because new evidence arrived, but because the senior editors stopped writing around it.*

## 6. What This Scan Cannot Tell You

**Single-source corpus.** FP-internal consensus is not the same as US-establishment consensus — FP could be leading, lagging, or speaking only to itself. Conservative foreign-policy outlets (National Review, Commentary, the Federalist), Trump-adjacent commentary (Compact, IM-1776), and centrist defense publications (Foreign Affairs, War on the Rocks) are entirely absent and would likely refute or reframe Signals A and B. The "humiliation" and "fracture" frames may also be partly a function of FP's editorial-pool composition rather than a genuine cross-spectrum read. Chinese and Iranian domestic-language outlets are absent; their internal framing of the same events would be informative and we have none of it. Replicate against the FT, the Economist, Bloomberg Opinion, and at minimum National Review and Foreign Affairs before treating any of this as cross-source signal. Sixteen of the 25 articles returned paywalled-preview-length bodies (not full text); their quoted material is verifiable in preview, but supporting context within their full bodies was not read.

## 7. Source Ledger

- **Feed:** https://foreignpolicy.com/feed/ pulled 2026-05-18T21:59:40Z
- **Article count:** 25
- **Full-body fetches (>5KB):** 9 — Sharp×3 ("G-7 Finance," "Ratcliffe Havana," "Day 1 Beijing"), Agrawal ("Iran Could Be Trump's Greatest Failure"), Osborn ("Argentina Milei Malaise"), Kuntz, Gady, Devermont, plus partial mid-body Sharp ("Trump-Xi summit report")
- **Paywalled-preview fetches (1-2KB):** 16 — including all quoted material above from Benzoni ("Vibe War"), Palmer ("Remarkably Banal"), Heller ("Lebanon Breaking"), Clarke/Broekaert ("Counterterrorism Alarming"), Simon ("Self-Defeating"), Kampfner ("Starmer Will Fall"), Agrawal ("Trump Met Xi" — Beans and Boeings)
- **Contributors (26):** Agrawal, Hockenos, Benzoni, Karr, Zelizer, Kerry, Aceng, Sharp, Kuntz, Hoffman, Ghosh, Mills, Gady, Palmer, Devermont, Farshneshani, Lynk, Heller, Osborn, Clarke, Broekaert, Haltiwanger, Iyengar, Simon, Ganguly, Chatterjee, Kampfner, Gbadamosi
- **Period:** 2026-05-13 to 2026-05-18 (6 days)
- **Run dir:** `.claude/skills/steganographer/scans/.runs/2026-05-18T21-59-40-foreign-policy/`
