# Voicemail KB Reference

## Source-of-Truth Map

The KB lives at `library/voicemail-assistant-knowledge-base.md`. Each section below maps to the file(s) that own the canonical facts. When `sync` runs, it walks this table.

| KB Section | Canonical source(s) | What to verify |
|---|---|---|
| § 1 Identity and Contact | `src/lib/schema.ts` (organizationSchema, founderSchema), `src/components/marketing/ContactContent.tsx` | Phone, email, LinkedIn URLs, address, response time |
| § 2 Who Francis Is | `src/components/editorial/AboutContent.tsx` (milestones array) | Years, bio facts, BridgeSense, side projects |
| § 3 What Odyssey Alive Does | `src/components/marketing/ServicesContent.tsx`, `.claude/skills/business/references/products.md` | Service tiers, "available now" vs "coming 2026", current client work |
| § 4 Pricing | `src/components/marketing/ServicesContent.tsx` (pricing block, $3K starting, $3-12K typical) | Price ranges, what's included, free discovery call |
| § 5 Process | `src/components/marketing/ServicesContent.tsx` (processSteps array) | Five steps, durations, descriptions |
| § 6 Tools and Technology | `src/components/marketing/ServicesContent.tsx` (tools section) | Tool list (n8n, Supabase, Claude API, etc.) |
| § 7 Who's a Good Fit | `src/components/marketing/HomeContent.tsx` (FAQs), `.claude/skills/business/references/strategy.md` | Target client profile |
| § 8 FAQ | `src/components/marketing/ServicesContent.tsx` (faqs array), `src/components/marketing/HomeContent.tsx` (homepageFaqs) | Question wording, answer accuracy |
| § 9 Caller Intents | (skill-owned, no canonical source) | Coverage of common call types |
| § 10 Information to Capture | (skill-owned) | Form completeness |
| § 11 Things the Assistant Should NOT Do | Combined sources plus project memory | Guardrails consistent with brand |
| § 12 Brand Voice Cues | `.claude/skills/voice/`, `.claude/skills/writing/` | Voice consistency |
| § 13 Soundbites | All of the above | Quotability and accuracy |

## Files referenced by sync

Sync reads these files directly. If a path moves, update this list.

* `src/lib/schema.ts`
* `src/components/marketing/HomeContent.tsx`
* `src/components/marketing/ServicesContent.tsx`
* `src/components/marketing/ContactContent.tsx`
* `src/components/editorial/AboutContent.tsx`
* `.claude/skills/business/references/products.md`
* `.claude/skills/business/references/revenue.md`
* `.claude/skills/business/references/timeline.md`
* `.claude/skills/business/references/strategy.md`
* `.claude/skills/business/references/financials.md`

## SBDC Firewall

The KB must never market SBDC consulting as an Odyssey Alive offering.

**Allowed framing:**
* "Francis teaches at the Tillamook County SBDC separately, but Odyssey Alive is the private consulting business."
* Acknowledging SBDC only when a caller specifically asks about it.

**Forbidden framing:**
* "Odyssey Alive offers SBDC consulting."
* "Through SBDC, Francis provides..."
* Anything that conflates the two practices in a marketing voice.
* Quoting the $65/hr SBDC rate as Odyssey Alive pricing.

Source: feedback memory `feedback_sbdc-conflict-of-interest.md` in user auto-memory.

## Voice Anchors

The KB powers a voice agent. Every answer should pass these tests:

* **Reads aloud cleanly.** No awkward phonetics, no sentence too long for one breath.
* **Plain-spoken.** No jargon a caller would not know.
* **Warm, not salesy.** Confident, not aggressive.
* **Respects time.** Short answer first, offer to elaborate.
* **No em-dashes or en-dashes.** Use periods, commas, or colons. (Project-wide rule, enforced by `/writing` hook.)

The voice profile lives in `.claude/skills/voice/`. The writing protocol lives in `.claude/skills/writing/`. The `/edit` skill is the gateway for all prose changes.

## Section Order Convention

When `add-faq` or `update` adds new entries, preserve the existing section numbering (1-13). New top-level sections require an explicit user request. Sub-bullets and table rows can be added freely within a section.

## When in doubt

Sync reports drift. Update fixes drift. Review catches what sync misses (voice fitness, intent gaps). When the three modes disagree, the human (Francis) decides.
