---
name: voicemail-kb
description: "Maintain the Odyssey Alive voicemail assistant knowledge base. Modes: update, add-faq, sync, review. Usage: /voicemail-kb [mode] [args]"
allowed-tools: Read, Glob, Grep, Edit, Write, Bash, Task
minimum-effort-level: high
strictness: standard
---

# Voicemail KB

Maintain `library/voicemail-assistant-knowledge-base.md`. That file backs the inbound-call voice agent for Odyssey Alive.

## Usage

```
/voicemail-kb [mode] [args]
```

### Modes

| Mode | Command | Description |
|------|---------|-------------|
| `update` | `/voicemail-kb update [section]` | Edit a specific section (pricing, contact, FAQ, etc.). Routes prose changes through `/edit`. |
| `add-faq` | `/voicemail-kb add-faq [question]` | Add a new Q and A entry to section 8. Routes through `/edit`. |
| `sync` | `/voicemail-kb sync` | Diff KB against site sources and business plan refs. Report drift, do not auto-fix. |
| `review` | `/voicemail-kb review` | Full audit: factual drift, intent gaps, voice fitness. Spawns evaluation agents. |

If no mode is given, print this table and exit.

---

<!-- origin: user | added: 2026-05-06 | immutable: true -->
## Directives

> **"All prose edits to the KB route through /edit. The KB has a specific voice (warm, plain-spoken, no jargon) and any new or revised text must clear the writing kernel before being committed."**

> **"SBDC and Odyssey Alive are kept distinct. The KB never markets SBDC as part of Odyssey Alive's offering. If sync detects SBDC framing drift, flag it as a violation, not a suggestion."**

> **"The website (odysseyalive.com src/), src/lib/schema.ts, and .claude/skills/business/references/ are the source of truth for facts. The KB mirrors those. It does not invent new facts. When sync finds a conflict, site state is canonical."**

*. Added 2026-05-06, source: project conventions plus Francis directive*
<!-- /origin -->

---

<!-- origin: skill-builder | version: 1.0 | modifiable: true -->
## Workflow: update

1. Read `library/voicemail-assistant-knowledge-base.md`.
2. Locate the section the user named. If ambiguous, grep `## ` headers and ask which section.
3. State to the user: "Editing section: [name]. Current content:" and paste the current text.
4. Capture the requested change. If the change touches prose (FAQ answers, soundbites, descriptions, voice cues), invoke `/edit` to load the writing kernel before drafting the replacement. Mechanical changes (phone number, URL, date) skip `/edit`.
5. Apply the edit via the Edit tool.
6. Run a scoped `review` pass on the affected section to catch regressions.
7. Report what changed in one or two sentences.

## Workflow: add-faq

1. Read `library/voicemail-assistant-knowledge-base.md`. Locate section 8 "Frequently Asked Questions".
2. If the question was passed as an argument, use it. Otherwise ask the user for the question.
3. Invoke `/edit` to draft a voice-checked answer that fits the established `**Q:** ... **A:** ...` format.
4. Append the new Q and A in alphabetical or topical order with the existing entries (keep similar topics together).
5. If the new FAQ produces a quotable phrase, also update section 13 "Quick-Reference Soundbites".
6. Report the addition.

## Workflow: sync

Detect drift between the KB and its sources of truth. Read-only; never auto-fix.

1. Read the KB.
2. Read each source listed in `reference.md` § "Source-of-Truth Map".
3. For each KB fact, locate the corresponding fact in the source. Use grep where helpful.
4. Diff. Categorize each finding:
   * **VIOLATION** (SBDC framing crossover): KB markets SBDC as part of Odyssey Alive
   * **DRIFT**: site says X, KB says Y
   * **GAP**: site has new fact not in KB
   * **ORPHAN**: KB has fact not present in any source (may be intentional, flag for human review)
5. Output a drift report grouped by severity. Use line numbers in both KB and source.
6. End with: "Run `/voicemail-kb update [section]` to address each finding. Drift fixes route through `/edit` so prose stays voice-checked."
7. Do not modify any file.

## Workflow: review

**Scoped-run precheck:** When review runs scoped (chained from update step 6), limit the audit to the affected section and spawn ONLY the agent whose domain the change touches — factual/intent changes → switchboard-veteran; prose/soundbite changes → spoken-word-editor. The full parallel spawn below is for an explicit user-invoked `review`.

Full audit pass. Spawn two evaluation agents in parallel using the Task tool, each with `subagent_type: "general-purpose"` and `context: none`:

1. **switchboard-veteran** — audits for stale dates, internal contradictions, missing caller intents, FAQ gaps, and SBDC framing violations. See [agents/switchboard-veteran/AGENT.md](agents/switchboard-veteran/AGENT.md).
2. **spoken-word-editor** — audits each FAQ answer and soundbite for spoken rhythm, awkward phonetics, breath length, ear-confusing jargon, pronunciation traps, and canned-sounding lines. See [agents/spoken-word-editor/AGENT.md](agents/spoken-word-editor/AGENT.md).

Synthesize both reports:
* SBDC violations are MUST FIX. Surface immediately at the top of the report.
* Factual issues recommend `update [section]`.
* Voice issues recommend `update [section]` (which routes through `/edit`).
* If both agents return PASS, report "KB clean" and stop.

---

## Grounding

Read [reference.md](reference.md) before running `sync` or `review`. It maps each KB section to the file that owns the source of truth and lists the exact paths to grep.

See [reference.md](reference.md) for the source-of-truth map and SBDC firewall rules.
<!-- /origin -->
