#!/bin/bash
# Hook: SBDC firewall tripwire — advise when 'SBDC' enters the voicemail KB
# Skill: /voicemail-kb
# Scope: library/voicemail-assistant-knowledge-base.md only
# Rationale: sacred directive — "SBDC and Odyssey Alive are kept distinct. The KB
#   never markets SBDC as part of Odyssey Alive's offering." Mention-vs-framing is a
#   semantic call (owned by sync's VIOLATION categorization + the switchboard-veteran
#   agent), so this layer is a deterministic ADVISORY tripwire, never a hard block.
# Rule reference: shell-safety R3, R5, R7
CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR

INPUT=$(cat 2>/dev/null) || exit 0

FILE_PATH=$(echo "$INPUT" | grep -oP '"file_path"\s*:\s*"[^"]*"' | head -1 | sed 's/.*"file_path"\s*:\s*"//;s/"$//')

if ! echo "$FILE_PATH" | grep -q 'library/voicemail-assistant-knowledge-base\.md$'; then
  exit 0
fi

INPUT="$INPUT" python3 << 'PYTHON_SCRIPT'
import os
import json
import re
import sys

def main():
    try:
        data = json.loads(os.environ.get('INPUT', '{}'))
    except Exception:
        return 0

    tool_input = data.get('tool_input', data)
    file_path = tool_input.get('file_path', '')
    if not re.search(r'library/voicemail-assistant-knowledge-base\.md$', file_path):
        return 0

    # Inspect only NEW text: Write -> content; Edit -> new_string.
    new_text = tool_input.get('content', '') or tool_input.get('new_string', '')
    if not new_text:
        return 0

    # Word-boundary, case-insensitive. SBDC has no business in the OA KB.
    if not re.search(r'\bSBDC\b', new_text, re.IGNORECASE):
        return 0

    msg = (
        "FIREWALL TRIPWIRE: 'SBDC' is entering the voicemail knowledge base. "
        "Per the sacred directive, the KB must never frame SBDC as part of Odyssey Alive's "
        "offering. Confirm this mention is not framing-crossover before committing. If unsure, "
        "treat it as a VIOLATION (not a suggestion) and run `/voicemail-kb sync` or "
        "`/voicemail-kb review` to adjudicate. Route any prose fix through `/edit`."
    )
    print(json.dumps({"additionalContext": msg}))
    return 0

sys.exit(main())
PYTHON_SCRIPT
exit 0
