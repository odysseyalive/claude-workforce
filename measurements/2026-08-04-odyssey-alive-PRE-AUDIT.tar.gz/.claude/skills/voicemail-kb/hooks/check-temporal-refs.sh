#!/bin/bash
# Hook: Validate temporal claims in the voicemail KB against date anchors
# Scope: library/voicemail-assistant-knowledge-base.md only
CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR

INPUT=$(cat 2>/dev/null) || exit 0

FILE_PATH=$(echo "$INPUT" | grep -oP '"file_path"\s*:\s*"[^"]*"' | head -1 | sed 's/.*"file_path"\s*:\s*"//;s/"$//')

if ! echo "$FILE_PATH" | grep -q 'library/voicemail-assistant-knowledge-base\.md$'; then
  exit 0
fi

INPUT="$INPUT" python3 << 'PYTHON_SCRIPT'
import os
import json
import re
import sys
from datetime import datetime, date

def main():
    try:
        data = json.loads(os.environ.get('INPUT', '{}'))
    except Exception:
        return 0

    tool_input = data.get('tool_input', data)
    file_path = tool_input.get('file_path', '')

    if not re.search(r'library/voicemail-assistant-knowledge-base\.md$', file_path):
        return 0

    content = tool_input.get('content', '')
    edit_mode = False
    new_string = ''

    if not content:
        old_string = tool_input.get('old_string', '')
        new_string = tool_input.get('new_string', '')
        if not (file_path and old_string):
            return 0
        try:
            with open(file_path) as f:
                content = f.read()
            content = content.replace(old_string, new_string, 1)
            edit_mode = True
        except Exception:
            return 0

    if not content:
        return 0

    today = date.today()
    anchor_year = today.year
    anchor_month = today.month

    MONTHS = {
        'january': 1, 'february': 2, 'march': 3, 'april': 4,
        'may': 5, 'june': 6, 'july': 7, 'august': 8,
        'september': 9, 'october': 10, 'november': 11, 'december': 12,
    }

    PHRASES = [
        (r'a\s+few\s+days\s+(?:ago|later|after|before|earlier)', 2, 10, 'a few days'),
        (r'several\s+days\s+(?:ago|later|after|before|earlier)', 3, 14, 'several days'),
        (r'a\s+(?:few|couple(?:\s+of)?)\s+weeks\s+(?:ago|later|after|before|earlier)', 10, 35, 'a few weeks'),
        (r'several\s+weeks\s+(?:ago|later|after|before|earlier)', 21, 63, 'several weeks'),
        (r'a\s+(?:few|couple(?:\s+of)?)\s+months\s+(?:ago|later|after|before|earlier)', 45, 150, 'a few months'),
        (r'several\s+months\s+(?:ago|later|after|before|earlier)', 90, 300, 'several months'),
        (r'(?:a|one)\s+week\s+(?:ago|later|after|before|earlier)', 5, 10, 'one week'),
        (r'two\s+weeks?\s+(?:ago|later|after|before|earlier)', 10, 21, 'two weeks'),
        (r'three\s+weeks?\s+(?:ago|later|after|before|earlier)', 18, 28, 'three weeks'),
        (r'(?:a|one)\s+month\s+(?:ago|later|after|before|earlier)', 25, 45, 'one month'),
        (r'two\s+months?\s+(?:ago|later|after|before|earlier)', 50, 75, 'two months'),
        (r'three\s+months?\s+(?:ago|later|after|before|earlier)', 75, 110, 'three months'),
        (r'six\s+months?\s+(?:ago|later|after|before|earlier)', 160, 210, 'six months'),
        (r'(?:a|one)\s+year\s+(?:ago|later|after|before|earlier)', 330, 400, 'one year'),
    ]

    parts = content.split('---')
    if len(parts) >= 3:
        body = '---'.join(parts[2:])
    else:
        body = content

    clean_lines = []
    for line in body.split('\n'):
        stripped = line.strip()
        if stripped.startswith('!['):
            continue
        if stripped.startswith('<!--'):
            continue
        clean_lines.append(line)
    body = '\n'.join(clean_lines)
    body_lower = body.lower()

    month_positions = []
    for month_name, month_num in MONTHS.items():
        for m in re.finditer(r'\b' + month_name + r'\b', body_lower):
            after = body[m.end():m.end() + 10].strip()
            year_match = re.match(r'(\d{4})', after)
            if year_match:
                year = int(year_match.group(1))
            else:
                if month_num > anchor_month:
                    year = anchor_year - 1
                else:
                    year = anchor_year
            month_positions.append({
                'month': month_num,
                'year': year,
                'pos': m.start(),
                'name': month_name,
            })

    month_positions.sort(key=lambda x: (x['pos'], -len(x['name'])))
    deduped = []
    last_end = -1
    for mp in month_positions:
        if mp['pos'] >= last_end:
            deduped.append(mp)
            last_end = mp['pos'] + len(mp['name'])
    month_positions = deduped

    errors = []
    today_dt = datetime(today.year, today.month, today.day)

    for pattern, min_days, max_days, label in PHRASES:
        for match in re.finditer(pattern, body_lower):
            match_pos = match.start()
            phrase_text = match.group(0)

            if edit_mode and new_string:
                if not re.search(pattern, new_string.lower()):
                    continue

            nearby = [mp for mp in month_positions
                      if match_pos - 500 <= mp['pos'] <= match_pos + 500]

            anchor_dt = None
            if len(nearby) >= 1:
                nearby.sort(key=lambda mp: abs(mp['pos'] - match_pos))
                m1 = nearby[0]
                try:
                    anchor_dt = datetime(m1['year'], m1['month'], 15)
                except Exception:
                    continue
                anchor_label = f"{m1['name'].capitalize()} {m1['year']}"
            else:
                anchor_dt = today_dt
                anchor_label = "today"

            delta_days = abs((today_dt - anchor_dt).days)

            if delta_days < min_days or delta_days > max_days:
                approx_months = round(delta_days / 30.44, 1)
                errors.append(
                    f'"{phrase_text}" measured against {anchor_label} '
                    f'(actual gap: ~{delta_days} days / ~{approx_months} months). '
                    f'Expected range for "{label}": {min_days}-{max_days} days.'
                )

    if errors:
        for e in errors:
            print(f'BLOCKED: Temporal mismatch: {e}', file=sys.stderr)
        return 2

    return 0

sys.exit(main())
PYTHON_SCRIPT

exit $?
