#!/bin/bash
# Hook: Block permanent audio file saves per /say directive
# Scope: Bash commands involving audio output (curl to file, ffmpeg output, etc.)

# Crash sentinel — if this hook itself errors, other hooks can detect it
CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR

_pass() { echo '{"continue":true,"suppressOutput":true,"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"allow","permissionDecisionReason":""}}'; exit 0; }

INPUT=$(cat 2>/dev/null) || _pass

# Only check Bash commands that might produce audio files
if ! echo "$INPUT" | grep -qiE '(\.mp3|\.wav|\.ogg|\.m4a|\.aac|audio)'; then
  _pass
fi

# Allow /tmp paths — that's where ephemeral audio belongs
if echo "$INPUT" | grep -qE '(/tmp/|mktemp)'; then
  _pass
fi

# Allow piping to ffplay/mpv (streaming, no save)
if echo "$INPUT" | grep -qE '(ffplay|mpv)\s+.*-'; then
  _pass
fi

# Block audio file writes to permanent locations
if echo "$INPUT" | grep -qiE '(-o\s+|>\s*)[^/]*\.(mp3|wav|ogg|m4a|aac)'; then
  echo "BLOCKED: Audio files must not be saved permanently. Use /tmp for ephemeral files or pipe directly to player. Per /say directive." >&2
  exit 2
fi

_pass
