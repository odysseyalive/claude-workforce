# Say Reference

## SSML Pacing Reference

The Dragon HD voice handles emotion and tone automatically. Only use pacing markup where it aids comprehension.

**Pedagogical patterns** — for study content:
```xml
<!-- Define/key-point: slow down with pauses -->
<break time="500ms"/><prosody rate="-15%">A potlatch is a ceremonial feast.</prosody><break time="300ms"/>

<!-- Repeat: say it twice -->
Masi.<break time="400ms"/>Masi.

<!-- Spell out -->
<prosody rate="-30%">P. O. T. L. A. T. C. H.</prosody>

<!-- Question: slight slowdown -->
<prosody rate="-5%">What do you think happens next?</prosody>

<!-- Recall: pause before -->
<break time="400ms"/><prosody rate="-5%">Remember when we discussed kinship?</prosody>

<!-- Slow/new vocab -->
<break time="300ms"/><prosody rate="-20%">New vocabulary: ikanum means story.</prosody><break time="300ms"/>
```

**Standard SSML** (passed through directly):
```xml
<break time="500ms"/>
<emphasis level="strong">key term</emphasis>
<prosody rate="slow">slower speech</prosody>
<say-as interpret-as="characters">TTS</say-as>
```
