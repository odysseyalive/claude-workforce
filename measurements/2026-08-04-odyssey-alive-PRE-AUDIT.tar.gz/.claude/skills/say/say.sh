#!/usr/bin/env bash
# TTS playback via Azure Speech Service
# Usage: say.sh "text to speak"
# Or pipe SSML body: echo "ssml content" | say.sh --ssml

set -a && . ~/.env && set +a

# Kill any existing ffplay to prevent overlap/interruption
pkill -f "ffplay.*tts-" 2>/dev/null
pkill -f "ffplay.*-nodisp" 2>/dev/null

TEXT="$1"

if [ "$1" = "--ssml" ]; then
  SSML_BODY=$(cat)
else
  # Escape XML special chars in plain text
  TEXT=$(echo "$TEXT" | sed 's/&/\&amp;/g; s/</\&lt;/g; s/>/\&gt;/g; s/"/\&quot;/g')
  SSML_BODY="$TEXT"
fi

curl -s -N -X POST \
  "https://${AZURE_SPEECH_REGION}.tts.speech.microsoft.com/cognitiveservices/v1" \
  -H "Ocp-Apim-Subscription-Key: ${AZURE_SPEECH_KEY}" \
  -H "Content-Type: application/ssml+xml" \
  -H "X-Microsoft-OutputFormat: audio-24khz-48kbitrate-mono-mp3" \
  -d "<speak version=\"1.0\" xmlns=\"http://www.w3.org/2001/10/synthesis\" xml:lang=\"en-US\"><voice name=\"en-US-Phoebe:DragonHDLatestNeural\"><prosody pitch=\"-5Hz\" rate=\"1.0\">${SSML_BODY}</prosody></voice></speak>" \
  | ffplay -nodisp -autoexit -loglevel quiet -
