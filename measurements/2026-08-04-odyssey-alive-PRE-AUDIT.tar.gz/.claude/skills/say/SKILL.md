---
name: say
description: "Text-to-speech playback using Azure Speech Service. Usage: /say [text to speak]"
allowed-tools: Bash, Task
minimum-effort-level: medium
strictness: standard
---

# Say

Speak text aloud using Azure Speech Service via REST API.

## Usage

```
/say [text to speak]
```

The entire argument after `/say` is the text to be spoken aloud.

<!-- origin: user | added: 2026-02-02 | immutable: true -->
## Directives

> **Never save audio files permanently. Always generate to /tmp and delete after playback.**

*-- Added 2026-02-02, source: user instruction*

> **Use the Phoebe Dragon HD voice (en-US-Phoebe:DragonHDLatestNeural) at -5Hz pitch by default.**

*-- Updated 2026-02-02, source: user instruction*

> **Always display the complete text to the user BEFORE starting audio playback.**

*-- Added 2026-02-02, source: user instruction*

> **Run TTS playback via a Task agent (subagent_type: Bash) to keep mpv output off the main screen. Do not run as a background process -- the agent runs in the foreground so playback is interruptible.**

*-- Updated 2026-02-02, source: user instruction*
<!-- /origin -->

## Workflow

Use the `say.sh` wrapper script. The script path is:
`$CLAUDE_PROJECT_DIR/.claude/skills/say/say.sh`

**Plain text (no SSML)** -- run via Task agent:

```
Task(subagent_type: Bash, prompt: 'Run this command: bash "$CLAUDE_PROJECT_DIR/.claude/skills/say/say.sh" "TEXT_HERE"')
```

**With SSML pacing markup** (`<break>`, `<prosody>`, etc.) -- run via Task agent:

```
Task(subagent_type: Bash, prompt: 'Run this command: cat <<\'BODY_END\' | bash "$CLAUDE_PROJECT_DIR/.claude/skills/say/say.sh" --ssml
SSML_CONTENT_HERE
BODY_END')
```

## Grounding

Before using SSML markup, read [reference.md](reference.md) § "SSML Pacing Reference" for pedagogical patterns and standard SSML elements.

## Behavior

1. **Display the complete text** to the user first (as regular output text).
2. **Run TTS playback** via a Task agent (subagent_type: Bash) to keep mpv output off the main screen.
3. For study content, use pedagogical patterns to improve retention.
4. For conversational text, most text should be plain -- no markup needed.
5. Do not over-mark.

## Enforcement

| Mechanism | Purpose | Blocks |
|-----------|---------|--------|
| `hooks/no-permanent-audio.sh` | Prevent saving audio files to permanent locations | Bash commands writing audio outside /tmp |
| `agents/tts-validator/AGENT.md` | Validate display-before-play, voice selection, Task agent routing | N/A (context: none) |
