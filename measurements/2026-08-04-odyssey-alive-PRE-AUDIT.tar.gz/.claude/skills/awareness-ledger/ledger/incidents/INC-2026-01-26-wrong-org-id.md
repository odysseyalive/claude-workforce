# INC-2026-01-26-wrong-org-id

**Status:** resolved
**Tags:** zoho, timesheet, api, organization-id
**Related:** INC-2026-01-26-zoho-task-response-format

## What Happened
Zoho API calls used wrong organization ID (765429142 instead of 660295414), causing all API requests to fail or return data from the wrong organization.

## Timeline
| Time/Commit | Event |
|-------------|-------|
| 2026-01-26 | API calls returning unexpected results |
| 2026-01-26 | Discovered wrong org ID was being used |
| 2026-01-26 | Added explicit directive to timesheet SKILL.md |
| 2026-01-26 | Created validate-org-id.sh hook for enforcement |

## Root Cause
Organization ID was hallucinated or pulled from incorrect context. No enforcement existed to validate the ID before API calls.

## Contributing Factors (Swiss Cheese Layers)
1. **No single source of truth** -- Org ID wasn't pinned in a directive
2. **No enforcement** -- No hook to catch wrong IDs before they reached the API

## Resolution
Added org ID as an explicit directive in timesheet SKILL.md. Created `hooks/validate-org-id.sh` PreToolUse hook on Bash matcher to block any Zoho API call with an incorrect organization_id.

## Lessons Learned
> **"Critical IDs must be pinned in directives AND enforced by hooks. Directives alone aren't enough -- the agent can still hallucinate past them."**
*-- Captured 2026-01-26, source: timesheet debugging session*

## Prevention
Hook `validate-org-id.sh` blocks Bash commands containing wrong org IDs. Directive at top of timesheet SKILL.md makes the correct ID explicit.
