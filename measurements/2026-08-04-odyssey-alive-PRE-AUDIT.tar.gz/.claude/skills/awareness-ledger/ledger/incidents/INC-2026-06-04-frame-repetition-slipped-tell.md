# INC-2026-06-04-frame-repetition-slipped-tell

**Status:** resolved
**Tags:** text-eval, voice, validation, edit, focus, ai-tells, drift
**Related:** PAT-2026-06-04-cluster-vs-spread-tells, DEC-2026-06-04-model-switch-not-for-inline-drafting, PAT-2026-02-07-overbuilt-prose-drift, DEC-2026-02-19-voice-protection-gate

## What Happened
The long-form focus article "will-ai-stall-itself" reached a near-final, validated draft carrying a single significance-announcing sentence-frame repeated six times, roughly once per section: "Here is the thing nobody says out loud", "the part I keep turning over is stranger than the size of it", "Here is what your weightless answer actually requires", "That is the part the brochures skip", "This is where the abstraction lands", and "the part that nagged at me most". The voice-evaluator and the text-eval structure-checker each PASSED the draft twice. Francis identified it by eye as an AI tell.

## Timeline
| Time/Commit | Event |
|-------------|-------|
| Draft v1 (~600w) | "the part I keep turning over" + "Here is the thing" present; voice/text-eval PASS |
| Draft v2 (long-form, ~1100w) | Frame family grew to 6 instances across the new sections; voice/text-eval PASS again |
| Review | Francis flags "the part I keep turning over is stranger than the size of it" as AI; scan reveals a 6-instance family |
| Fix | /edit de-crutched all six down to ~1 |

## Root Cause
The voice-evaluator and structure-checker detect CLUSTERED AI signals (3+ in one passage). A single frame repeated evenly across the document, one per section, never clusters in any passage, so every per-passage check passes. No validator owned whole-document frame repetition.

## Contributing Factors (Swiss Cheese Layers)
1. **Validator scope** — both AI-tell checks are passage-local by design, and that locality is itself a load-bearing voice protection (DEC-2026-02-19-validator-overcorrection).
2. **Long-form amplification** — expanding 600w to 1100w added sections, and each new section reused the same frame, growing the family from 2 to 6 without any single passage clustering.
3. **Discovery-voice camouflage** — the frame family overlaps with the author's Curiosity-Driven Discovery voice, so spot-reading any single instance reads as "voice," not formula.

## Resolution
Added text-eval structure-checker **Step 3d "Significance-Announcing Frame Repetition (whole-document)"** with a meta-frame-vs-discovery-beat definitional gate and thresholds 3 SHOULD / 4+ MUST (short-form), 3-4 / 5+ (long-form). Added an **edit-validator Check 4 pointer** to catch a re-introduced frame at edit time. voice-evaluator left passage-scoped on purpose. The article itself was de-crutched via /edit (6 instances down to ~1).

## Lessons Learned
> **"A single AI-tell frame spread one-per-section is invisible to every passage-level / cluster check, yet a human reads it instantly as AI. Whole-piece formula must be caught at whole-document scope, gated on meta-frame vs discovery-beat so it does not strip authentic voice."**
*— Captured 2026-06-04, source: Francis review of "will-ai-stall-itself"*

## Prevention
See PAT-2026-06-04-cluster-vs-spread-tells (the reusable detection rule + voice-protection gate) and DEC-2026-06-04-model-switch-not-for-inline-drafting (why the fix belongs in the validator, not a drafting-model switch). The generic version of the rule is to be added upstream in claude-enforcer's references/eval-rubrics.md, since local edits to skill-builder are overwritten on update.
