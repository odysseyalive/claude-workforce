# INC-2026-01-26-zoho-task-response-format

**Status:** resolved
**Tags:** zoho, timesheet, api, jq
**Related:**

## What Happened
Zoho Books API task list responses use `.task[]` (singular), not `.tasks[]` (plural). JQ queries using `.tasks[]` silently returned empty results, causing task lookups to fail.

## Timeline
| Time/Commit | Event |
|-------------|-------|
| 2026-01-26 | Task matcher agent jq queries returned empty results |
| 2026-01-26 | Discovered API uses `.task` not `.tasks` in response |
| 2026-01-26 | Fixed in task-matcher agent and reference.md |

## Root Cause
Assumed Zoho API response key was `.tasks[]` (plural, consistent with REST conventions). Actual key is `.task[]` (singular, Zoho's convention).

## Contributing Factors (Swiss Cheese Layers)
1. **API documentation gap** -- Zoho docs inconsistent on response key naming
2. **Silent failure** -- jq returns empty on missing keys instead of erroring

## Resolution
Updated all jq queries in task-matcher agent and reference.md to use `.task[]`.

## Lessons Learned
> **"Always verify Zoho API response structure with a raw curl before building jq pipelines."**
*-- Captured 2026-01-26, source: timesheet debugging session*

## Prevention
Verify response keys with raw API calls before writing jq queries. Documented in timesheet/references/api.md.
