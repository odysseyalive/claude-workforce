# Awareness Ledger Index

*Auto-generated. Last updated: 2026-07-20*

## By Tag

- **opportunity-scout:** DEC-2026-07-01-opportunity-scout-skill
- **skill-creation:** DEC-2026-07-01-opportunity-scout-skill
- **market-recon:** DEC-2026-07-01-opportunity-scout-skill
- **agenda:** DEC-2026-07-01-agenda-calendar-invite-triage
- **triage:** DEC-2026-07-01-agenda-calendar-invite-triage
- **google-calendar:** DEC-2026-07-01-agenda-calendar-invite-triage
- **calendar:** DEC-2026-07-01-agenda-calendar-invite-triage
- **cross-skill:** DEC-2026-07-01-agenda-calendar-invite-triage

- **ynab:** DEC-2026-06-18-bank-reassessment-expense-index
- **budget:** DEC-2026-06-18-bank-reassessment-expense-index
- **expenses:** DEC-2026-06-18-bank-reassessment-expense-index
- **subscriptions:** DEC-2026-06-18-bank-reassessment-expense-index
- **reconciliation:** DEC-2026-06-18-bank-reassessment-expense-index
- **zoho:** INC-2026-01-26-zoho-task-response-format, INC-2026-01-26-wrong-org-id
- **timesheet:** INC-2026-01-26-zoho-task-response-format, INC-2026-01-26-wrong-org-id, INC-2026-01-26-task-matcher-skipped, PAT-2026-07-20-clock-overlap-is-legitimate
- **org-mode:** PAT-2026-07-20-clock-overlap-is-legitimate
- **clock:** PAT-2026-07-20-clock-overlap-is-legitimate
- **concurrency:** PAT-2026-07-20-clock-overlap-is-legitimate
- **directives:** PAT-2026-07-20-clock-overlap-is-legitimate
- **enforcement:** PAT-2026-07-20-clock-overlap-is-legitimate
- **api:** INC-2026-01-26-zoho-task-response-format, INC-2026-01-26-wrong-org-id
- **workflow:** INC-2026-01-26-task-matcher-skipped
- **agent:** INC-2026-01-26-task-matcher-skipped
- **analytics:** PAT-2026-03-04-faster-than-thought-launch-day, PAT-2026-04-25-cf-attribution-window-cap
- **faster-than-thought:** PAT-2026-03-04-faster-than-thought-launch-day
- **article-launch:** PAT-2026-03-04-faster-than-thought-launch-day, PAT-2026-04-01-the-dose-deep-engagement, PAT-2026-04-25-cf-attribution-window-cap
- **the-dose:** PAT-2026-04-01-the-dose-deep-engagement
- **engagement:** PAT-2026-04-01-the-dose-deep-engagement
- **content-performance:** PAT-2026-03-04-faster-than-thought-launch-day, PAT-2026-04-01-the-dose-deep-engagement, PAT-2026-04-25-cf-attribution-window-cap
- **cloudflare:** PAT-2026-03-04-faster-than-thought-launch-day, PAT-2026-04-01-the-dose-deep-engagement, PAT-2026-04-25-cf-attribution-window-cap
- **ga4:** PAT-2026-03-04-faster-than-thought-launch-day, PAT-2026-04-01-the-dose-deep-engagement, PAT-2026-04-25-cf-attribution-window-cap
- **attribution:** PAT-2026-04-25-cf-attribution-window-cap
- **measurement:** PAT-2026-04-25-cf-attribution-window-cap
- **text-eval:** DEC-2026-02-19-voice-protection-gate, DEC-2026-02-19-validator-overcorrection, PAT-2026-02-07-overbuilt-prose-drift, INC-2026-06-04-frame-repetition-slipped-tell, PAT-2026-06-04-cluster-vs-spread-tells, PAT-2026-06-12-wit-shaped-noise
- **voice:** DEC-2026-02-19-voice-protection-gate, DEC-2026-02-19-validator-overcorrection, PAT-2026-02-07-overbuilt-prose-drift, INC-2026-06-04-frame-repetition-slipped-tell, PAT-2026-06-04-cluster-vs-spread-tells, DEC-2026-06-04-model-switch-not-for-inline-drafting, PAT-2026-06-12-wit-shaped-noise
- **writing:** DEC-2026-02-19-voice-protection-gate, PAT-2026-02-07-overbuilt-prose-drift, DEC-2026-03-23-edit-skill-creation, FLW-2026-03-23-content-pipeline-evolution
- **validation:** DEC-2026-02-19-voice-protection-gate, DEC-2026-02-19-validator-overcorrection, INC-2026-06-04-frame-repetition-slipped-tell, PAT-2026-06-04-cluster-vs-spread-tells, DEC-2026-06-04-model-switch-not-for-inline-drafting, PAT-2026-06-12-wit-shaped-noise
- **quality:** DEC-2026-02-19-validator-overcorrection
- **drift:** PAT-2026-02-07-overbuilt-prose-drift, INC-2026-06-04-frame-repetition-slipped-tell, PAT-2026-06-04-cluster-vs-spread-tells, PAT-2026-06-12-wit-shaped-noise
- **ai-tells:** INC-2026-06-04-frame-repetition-slipped-tell, PAT-2026-06-04-cluster-vs-spread-tells, PAT-2026-06-12-wit-shaped-noise
- **captions:** PAT-2026-06-12-wit-shaped-noise
- **model-selection:** DEC-2026-06-04-model-switch-not-for-inline-drafting
- **edit:** DEC-2026-03-23-edit-skill-creation, FLW-2026-03-23-content-pipeline-evolution
- **focus:** DEC-2026-03-23-edit-skill-creation, FLW-2026-03-23-content-pipeline-evolution
- **promote:** DEC-2026-03-23-edit-skill-creation, FLW-2026-03-23-content-pipeline-evolution
- **newsletter:** DEC-2026-03-23-edit-skill-creation, FLW-2026-03-23-content-pipeline-evolution
- **present:** DEC-2026-03-23-edit-skill-creation
- **content-pipeline:** DEC-2026-03-23-edit-skill-creation, FLW-2026-03-23-content-pipeline-evolution
- **seo:** DEC-2026-03-25-aeo-seo-deployment
- **aeo:** DEC-2026-03-25-aeo-seo-deployment
- **geo:** DEC-2026-03-25-aeo-seo-deployment
- **indexnow:** DEC-2026-03-25-aeo-seo-deployment
- **search:** DEC-2026-03-25-aeo-seo-deployment
- **discovery:** DEC-2026-03-25-aeo-seo-deployment
- **self-heal:** DEC-2026-03-30-self-heal-removal
- **skill-builder:** DEC-2026-03-30-self-heal-removal, DEC-2026-06-04-model-switch-not-for-inline-drafting
- **skill-system:** DEC-2026-03-30-self-heal-removal
- **research:** FLW-2026-03-23-content-pipeline-evolution, DEC-2026-06-30-research-impassable-paywall-exclusion
- **paywall:** FLW-2026-03-23-content-pipeline-evolution, DEC-2026-06-30-research-impassable-paywall-exclusion
- **sources:** DEC-2026-06-30-research-impassable-paywall-exclusion
- **citations:** DEC-2026-06-30-research-impassable-paywall-exclusion
- **revenue:** DEC-2026-04-17-skill-productization-service
- **skill-productization:** DEC-2026-04-17-skill-productization-service
- **business-expansion:** DEC-2026-04-17-skill-productization-service
- **student-constraints:** DEC-2026-04-17-skill-productization-service

## By Status

### Active

- [DEC-2026-07-01-opportunity-scout-skill](decisions/DEC-2026-07-01-opportunity-scout-skill.md) -- Built /opportunity-scout: discovery-only market recon (gigs/RFPs/hiring) with 3 skill-local indexes, a 0–1 fit spine, local-market emphasis, partner bench, and ToS-safe/credential-guardrail boundaries
- [DEC-2026-07-01-agenda-calendar-invite-triage](decisions/DEC-2026-07-01-agenda-calendar-invite-triage.md) -- /agenda triage proposes Google Calendar events for meeting invites (all senders, SBDC a named example); write delegated to /google-calendar, confirmation-walked + dedup-guarded
- [DEC-2026-06-30-research-impassable-paywall-exclusion](decisions/DEC-2026-06-30-research-impassable-paywall-exclusion.md) -- /research drops impassable-paywall sources at discovery; passable premium feeds (FP, TJ) exempt; reader-accessibility scope deferred
- [DEC-2026-06-18-bank-reassessment-expense-index](decisions/DEC-2026-06-18-bank-reassessment-expense-index.md) -- 3-mo bank reconciliation; corrected stale targets + added 9 untracked subs; held discretionary leaks as targets to close
- [DEC-2026-02-19-voice-protection-gate](decisions/DEC-2026-02-19-voice-protection-gate.md) -- Downgraded overbuilt prose to SHOULD FIX; added Voice Protection Gate to text-eval
- [DEC-2026-02-19-validator-overcorrection](decisions/DEC-2026-02-19-validator-overcorrection.md) -- Raise flagging threshold when strong voice markers are present
- [DEC-2026-03-23-edit-skill-creation](decisions/DEC-2026-03-23-edit-skill-creation.md) -- Created /edit as content revision gateway; all edits route through writing kernel
- [DEC-2026-03-25-aeo-seo-deployment](decisions/DEC-2026-03-25-aeo-seo-deployment.md) -- Created /seo superseding /geo; IndexNow live, AEO + SEO + GEO unified
- [DEC-2026-03-30-self-heal-removal](decisions/DEC-2026-03-30-self-heal-removal.md) -- Removed /self-heal; functions covered by debug + awareness-ledger + verify
- [DEC-2026-04-17-skill-productization-service](decisions/DEC-2026-04-17-skill-productization-service.md) -- Revenue expansion via skill-building service; async-first, fits student constraints
- [PAT-2026-02-07-overbuilt-prose-drift](patterns/PAT-2026-02-07-overbuilt-prose-drift.md) -- Drafting agent drifts to overbuilt prose despite directives; enforcement needed in validator
- [PAT-2026-03-04-faster-than-thought-launch-day](patterns/PAT-2026-03-04-faster-than-thought-launch-day.md) -- Crawler visibility precedes human traffic on article launch day
- [PAT-2026-04-01-the-dose-deep-engagement](patterns/PAT-2026-04-01-the-dose-deep-engagement.md) -- Practitioner vulnerability register drives 2-3x deeper engagement than observational pieces
- [PAT-2026-04-25-cf-attribution-window-cap](patterns/PAT-2026-04-25-cf-attribution-window-cap.md) -- Per-article CF attribution unrecoverable past 9 days on this zone tier; tight cadence overlaps post-windows
- [FLW-2026-03-23-content-pipeline-evolution](flows/FLW-2026-03-23-content-pipeline-evolution.md) -- Current content pipeline: research > focus > voice/writing > image > edit > text-eval > promote/newsletter
- [PAT-2026-06-04-cluster-vs-spread-tells](patterns/PAT-2026-06-04-cluster-vs-spread-tells.md) -- Cluster vs spread AI tells; whole-document frame repetition needs whole-doc scope + a meta-frame gate
- [DEC-2026-06-04-model-switch-not-for-inline-drafting](decisions/DEC-2026-06-04-model-switch-not-for-inline-drafting.md) -- Model switching can't target inline drafting; catch AI-tells at the validator, not the model
- [PAT-2026-06-12-wit-shaped-noise](patterns/PAT-2026-06-12-wit-shaped-noise.md) -- One-line captions evade cluster rules; wit-shaped noise (form without resolvable referents) needs its own MUST FIX referent test
- [PAT-2026-07-20-clock-overlap-is-legitimate](patterns/PAT-2026-07-20-clock-overlap-is-legitimate.md) -- Overlapping org CLOCK ranges are legitimate concurrent work; the overlap warning is a model reflex no skill ever asked for

### Resolved

- [INC-2026-01-26-zoho-task-response-format](incidents/INC-2026-01-26-zoho-task-response-format.md) -- Zoho API uses `.task` not `.tasks` in responses
- [INC-2026-01-26-wrong-org-id](incidents/INC-2026-01-26-wrong-org-id.md) -- Wrong organization ID used in Zoho API calls
- [INC-2026-01-26-task-matcher-skipped](incidents/INC-2026-01-26-task-matcher-skipped.md) -- Task matcher agent step skipped, causing duplicate tasks
- [INC-2026-06-04-frame-repetition-slipped-tell](incidents/INC-2026-06-04-frame-repetition-slipped-tell.md) -- A 6-instance significance-announcing frame passed two validators twice; fixed via structure-checker Step 3d

### Under Review

*No records yet.*

## By Type

### Decisions

- [DEC-2026-07-01-agenda-calendar-invite-triage](decisions/DEC-2026-07-01-agenda-calendar-invite-triage.md) -- Added a /agenda triage capability that proposes calendar events for email meeting invites; broadened from SBDC-only to all invites at ratification; event write delegated to /google-calendar (not an org write), wired through classifier + workflow + output-formats + CHECKPOINT + route triggers
- [DEC-2026-06-30-research-impassable-paywall-exclusion](decisions/DEC-2026-06-30-research-impassable-paywall-exclusion.md) -- /research excludes only IMPASSABLE paywalls (can't read past) at discovery; FP/Trends Journal (passable) exempt; reader-accessibility and hard-exclusion scopes considered and deferred
- [DEC-2026-06-18-bank-reassessment-expense-index](decisions/DEC-2026-06-18-bank-reassessment-expense-index.md) -- 3-mo bank reconciliation against the YNAB expense index; corrected stale targets, added 9 untracked subscriptions, held discretionary overages as leaks to close
- [DEC-2026-02-19-voice-protection-gate](decisions/DEC-2026-02-19-voice-protection-gate.md) -- Downgraded overbuilt prose to SHOULD FIX; added Voice Protection Gate to text-eval
- [DEC-2026-02-19-validator-overcorrection](decisions/DEC-2026-02-19-validator-overcorrection.md) -- Raise flagging threshold when strong voice markers are present
- [DEC-2026-03-23-edit-skill-creation](decisions/DEC-2026-03-23-edit-skill-creation.md) -- Created /edit as content revision gateway
- [DEC-2026-03-25-aeo-seo-deployment](decisions/DEC-2026-03-25-aeo-seo-deployment.md) -- AEO/SEO/GEO unified under /seo; IndexNow deployed
- [DEC-2026-03-30-self-heal-removal](decisions/DEC-2026-03-30-self-heal-removal.md) -- Removed /self-heal; covered by debug + ledger + verify
- [DEC-2026-04-17-skill-productization-service](decisions/DEC-2026-04-17-skill-productization-service.md) -- Revenue expansion via skill-building service; async-first
- [DEC-2026-06-04-model-switch-not-for-inline-drafting](decisions/DEC-2026-06-04-model-switch-not-for-inline-drafting.md) -- Model switching can't target inline drafting; catch AI-tells at the validator

### Patterns

- [PAT-2026-02-07-overbuilt-prose-drift](patterns/PAT-2026-02-07-overbuilt-prose-drift.md) -- Drafting agent drifts to overbuilt prose despite directives; enforcement needed in validator
- [PAT-2026-03-04-faster-than-thought-launch-day](patterns/PAT-2026-03-04-faster-than-thought-launch-day.md) -- Crawler visibility precedes human traffic on article launch day
- [PAT-2026-04-01-the-dose-deep-engagement](patterns/PAT-2026-04-01-the-dose-deep-engagement.md) -- Practitioner vulnerability register drives 2-3x deeper engagement than observational pieces
- [PAT-2026-04-25-cf-attribution-window-cap](patterns/PAT-2026-04-25-cf-attribution-window-cap.md) -- Per-article CF attribution unrecoverable past 9 days on this zone tier; tight cadence overlaps post-windows
- [PAT-2026-06-04-cluster-vs-spread-tells](patterns/PAT-2026-06-04-cluster-vs-spread-tells.md) -- Cluster vs spread AI tells; whole-document frame repetition needs whole-doc scope + a meta-frame gate
- [PAT-2026-06-12-wit-shaped-noise](patterns/PAT-2026-06-12-wit-shaped-noise.md) -- One-line captions evade cluster rules; wit-shaped noise (form without resolvable referents) needs its own MUST FIX referent test
- [PAT-2026-07-20-clock-overlap-is-legitimate](patterns/PAT-2026-07-20-clock-overlap-is-legitimate.md) -- Overlapping org CLOCK ranges are legitimate concurrent work; the overlap warning is a model reflex no skill ever asked for

### Flows

- [FLW-2026-03-23-content-pipeline-evolution](flows/FLW-2026-03-23-content-pipeline-evolution.md) -- Current content pipeline with /edit gateway, --long support, paywall reader

## Relationship Map

```
INC-2026-01-26-zoho-task-response-format
  <- INC-2026-01-26-wrong-org-id (same debugging session)
  <- INC-2026-01-26-task-matcher-skipped (same debugging session)

PAT-2026-02-07-overbuilt-prose-drift
  -> DEC-2026-02-19-voice-protection-gate (pattern prompted the decision)
  -> DEC-2026-02-19-validator-overcorrection (overcorrection from fixing the pattern)

DEC-2026-02-19-voice-protection-gate
  <-> DEC-2026-02-19-validator-overcorrection (companion decisions, same session)
  <- PAT-2026-02-07-overbuilt-prose-drift (root pattern)

DEC-2026-03-23-edit-skill-creation
  <- DEC-2026-02-19-voice-protection-gate (voice enforcement drove need for edit gateway)
  -> FLW-2026-03-23-content-pipeline-evolution (changed the pipeline)

DEC-2026-03-25-aeo-seo-deployment
  <- PAT-2026-03-04-faster-than-thought-launch-day (crawler patterns informed SEO strategy)

PAT-2026-04-01-the-dose-deep-engagement
  <- PAT-2026-03-04-faster-than-thought-launch-day (builds on launch-day pattern)
  <- DEC-2026-02-19-voice-protection-gate (voice register is what drives depth)

FLW-2026-03-23-content-pipeline-evolution
  <- DEC-2026-03-23-edit-skill-creation (edit gateway added to flow)
  <- DEC-2026-02-19-voice-protection-gate (voice enforcement shapes flow)

PAT-2026-04-25-cf-attribution-window-cap
  <- PAT-2026-04-01-the-dose-deep-engagement (depth pattern depends on per-article measurement; cap limits validation)
  <- PAT-2026-03-04-faster-than-thought-launch-day (launch-day crawler signals also affected by retention cap)

INC-2026-06-04-frame-repetition-slipped-tell
  -> PAT-2026-06-04-cluster-vs-spread-tells (incident generalized into the detection rule)
  -> DEC-2026-06-04-model-switch-not-for-inline-drafting (incident ruled out model-switch as the fix)
  <- PAT-2026-02-07-overbuilt-prose-drift (same drift family, now caught whole-document)

PAT-2026-06-04-cluster-vs-spread-tells
  <-> DEC-2026-06-04-model-switch-not-for-inline-drafting (fix is validator coverage, not model choice)
  <- DEC-2026-02-19-voice-protection-gate (meta-frame gate preserves the voice protection)

PAT-2026-06-12-wit-shaped-noise
  <- INC-2026-06-04-frame-repetition-slipped-tell (same family: a tell shape the validators had no scope for)
  <- PAT-2026-06-04-cluster-vs-spread-tells (cluster rules' blind spot at single-line length)
  <- PAT-2026-02-07-overbuilt-prose-drift (drift family root)
  <- DEC-2026-02-19-voice-protection-gate (referent test is near-binary, so voice protection is preserved)
```

## Statistics

| Type | Total | Active | Resolved | Deprecated |
|------|-------|--------|----------|------------|
| Incidents | 4 | 0 | 4 | 0 |
| Decisions | 8 | 8 | 0 | 0 |
| Patterns | 7 | 7 | 0 | 0 |
| Flows | 1 | 1 | 0 | 0 |
