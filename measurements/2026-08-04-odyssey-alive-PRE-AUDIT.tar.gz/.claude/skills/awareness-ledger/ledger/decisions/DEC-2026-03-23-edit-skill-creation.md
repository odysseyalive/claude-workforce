# DEC-2026-03-23-edit-skill-creation

**Status:** accepted
**Tags:** edit, writing, focus, promote, newsletter, present, content-pipeline
**Related:** DEC-2026-02-19-voice-protection-gate, PAT-2026-02-07-overbuilt-prose-drift

## Context

Content edits were being applied directly without loading the writing kernel first. This caused voice drift and inconsistent prose quality across the pipeline, because the writing directives weren't in context during revision.

## Decision Drivers

- Voice drift during edits (writing kernel not loaded)
- Multiple entry points for content modification (focus, promote, newsletter, present, standalone)
- Need for a single gateway to ensure consistent voice enforcement

## Decision

Chosen option: **Create /edit as a content revision gateway**, because it provides a single choke point that always loads the writing kernel before any content modification.

*— Captured 2026-03-23, source: skill-builder pipeline improvements session*

## Consequences

- All content edits now route through /edit, which chains to /voice and /writing
- CLAUDE.md rule added: "Route all content edits through /edit"
- Exception carved for mechanical changes (typos, dates, URLs)
- edit-validator agent created for quality assessment

## Confirmation Criteria

Voice drift incidents during editing should drop to zero. If /edit adds friction without catching real issues, reconsider.
