# DEC-2026-03-25-aeo-seo-deployment

**Status:** accepted
**Tags:** seo, aeo, geo, indexnow, search, discovery
**Related:** PAT-2026-03-04-faster-than-thought-launch-day

## Context

Site needed structured data, IndexNow integration, and AI Engine Optimization (AEO) alongside traditional SEO to improve discovery by both search engines and AI systems. The existing /geo skill was too narrow (GEO-only).

## Decision Drivers

- AI-powered search engines (Perplexity, ChatGPT Search, Google AI Overviews) pulling from structured data
- Need for llms.txt, enhanced schema markup, and IndexNow ping on deploy
- /geo skill scope was limited to GEO evaluation only

## Decision

Chosen option: **Create /seo skill superseding /geo**, because it unifies AEO + SEO + GEO evaluation under a single skill with calibration mode.

*— Captured 2026-03-25, source: AEO/SEO implementation session*

## Consequences

- /seo skill created with modes: evaluate, --all, --calibrate
- /geo deprecated (redirect stub remains)
- IndexNow integration deployed and live
- Schema markup enhanced with Article, WebSite, Organization types
- llms.txt route added for AI crawler guidance

## Confirmation Criteria

Monitor crawler traffic patterns in /analytics. AEO improvements should show in AI citation visibility within 30-60 days.
