# DEC-2026-06-04-model-switch-not-for-inline-drafting

**Status:** accepted
**Tags:** skill-builder, focus, voice, model-selection, validation
**Related:** INC-2026-06-04-frame-repetition-slipped-tell, PAT-2026-06-04-cluster-vs-spread-tells

## Context
Hypothesis raised during a /debug session: AI-tell prose slips through because content drafting runs on a model that produces overbuilt prose instead of switching to a writing-tuned model (the 4.6-for-writing / 4.7-for-code instinct from "The Dress Rehearsal", Apr 2026). The question: does per-step model switching for content generation exist, or can it be wired up?

## Options Considered
### Option A: Wire an automatic model switch for content-generation steps (skill or hook)
- Good, because it would target the suspected root cause at draft time.
- Bad, because it is impossible. Confirmed via claude-code-guide: a Skill or a hook CANNOT change the main-loop / session model mid-session. Inline drafting is done by the main loop. The repo has zero `model:` fields on any agent, no model config in settings, no model-switching hook.

### Option B: Manually /model to a writing model before drafting
- Good, because it is the only session-wide lever that works.
- Bad, because it is manual, easy to forget, and session-wide rather than per-step.

### Option C: Delegate drafting to a model-pinned Task subagent
- Good, because subagents DO support model overrides (`CLAUDE_CODE_SUBAGENT_MODEL` > per-call model > frontmatter `model:` > inherit).
- Bad, because it trades away the interactive workshop drafting that produced good results on "will-ai-stall-itself".

### Option D: Catch AI-tells at the validator (model-independent)
- Good, because validators run regardless of which model drafted; even a "better" model emits formula sometimes.
- Good, because it fixes the actual observed gap (PAT-2026-06-04-cluster-vs-spread-tells).

## Decision
Chosen: **Option D (primary), with B available on demand.** Do not rely on per-step model switching to prevent AI-tells — it cannot target inline drafting at all. Catch tells at the validator. If a specific drafting model is wanted, set it session-wide via /model before drafting (B), or delegate to a pinned subagent (C, accepting the loss of interactive drafting).

## Consequences
- The frame-repetition gap is fixed in text-eval/edit, not by model config (see INC + PAT).
- Future "the AI sounds like AI" reports should investigate validator coverage FIRST, model second.
- Current top model is Opus 4.8; the 4.6/4.7 lane instinct predates it and is not a configured mechanism in this repo.

## Confirmation Criteria
A future content-generation AI-tell is caught by the validator (structure-checker Step 3d / edit-validator pointer) regardless of which model drafted it, with no model-switch having been configured.
