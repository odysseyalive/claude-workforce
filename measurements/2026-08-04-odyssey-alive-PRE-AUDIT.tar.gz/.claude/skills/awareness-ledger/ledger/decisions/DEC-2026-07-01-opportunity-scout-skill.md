# DEC-2026-07-01-opportunity-scout-skill

**Status:** accepted
**Tags:** opportunity-scout, skill-creation, market-recon, indexes, credentials

## Context

Francis wanted a market-recon skill (spec: `opportunity-scout-skill-spec.md`) that scouts external opportunities — contract/freelance gigs, RFPs, and fractional-consultant hiring — for his solo consultancy (Francis + AI, with a small partner bench). Routed via `/route` → skill-builder `new`. The spec was workshopped extensively before building; several of its assumptions didn't fit this project and were changed with the user.

## Decision Drivers

- The spec was partly written against a generic/template context (referenced non-existent `sales:*` / `small-business:*` skills and a HubSpot CRM; assumed direct Google Drive persistence). This project has none of those and uses a specific org/web/credential stack.
- Francis steered the architecture during the workshop: model-facing skill-local indexes over org/Drive; a self-improving source map; a partner bench; local-market emphasis; and a hard line against ToS-violating automation.

## Decision

Built `/opportunity-scout` (lane: coding) with four modes — `scout` (default), `status`, `add-partner <url>`, `add-source <url>` — and **three model-facing, skill-local indexes**: `opportunity-index` (expire-flush), `source-index` (auto-decaying + fit-promoted, pre-seeded national + Oregon-coast/Portland-metro sources incl. Craigslist), `partner-index` (bench, 4 LinkedIn seeds profiled via `add-partner`). A single **0–1 fit-probability** (service-line 0.45 / deliverability 0.25 / local 0.15 / engagement 0.15) is the spine — it ranks opportunities, gates source promotion, and fires partner-match; deadline is a separate actionability gate. Home region anchored on Rockaway Beach (Astoria→Lincoln City→Portland), uniform local boost.

Four immutable directives with Opus CHECKPOINTs enforce the ratified boundaries: **discovery-only** (no outreach/replies/CRM, ever), **no automated login/scrape of ToS-walled sites** (LinkedIn/Upwork/Indeed/Facebook — public + human-in-the-loop only), **insert-only index writes** (never touch Francis's hand-set STATUS), and **credential guardrail** (detect auth need → guide Francis to paste a labeled key into `.env.local`; never auto-create accounts or handle raw passwords; legit free-registration/API-key auth only).

*— Captured 2026-07-01, source: user spec + multi-round design workshop + ratified plan (`~/.claude/plans/could-you-review-the-crispy-kernighan.md`).*

## Consequences

- Web tooling = native `WebSearch` + playwright `web_fetch` (public pages only); no Jina/`/research` dependency. Facebook local-needs handled by a human-in-the-loop checklist, not a bot.
- The opportunity + source indexes are `.gitignore`d (churn each run); partner-index stays tracked. `.directives.sha` generated; registered in `/route`; MODEL-LANE-GATE embedded (coding lane preferred = `claude-opus-4-8`, currently == active, so a silent no-op).
- Boundary is deliberately discovery-only: any outreach/reply is Francis's manual action. Expanding to draft/send was considered and declined.

## Confirmation Criteria

First real `scout` run validates query crossing, ToS-safe fetching, fit-scoring, dedup, and expiry. If double-bookings or FTE noise appear, tune dedup / engagement-fit in `scan-config.md`. Partner abilities get filled by running `add-partner` on the four seeds.
