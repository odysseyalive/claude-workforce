# DEC-2026-02-19-validator-overcorrection

**Status:** active
**Tags:** text-eval, voice, validation, quality
**Related:** DEC-2026-02-19-voice-protection-gate, PAT-2026-02-07-overbuilt-prose-drift

## Decision
When strong voice markers are present, raise the threshold for flagging. Optimizing for "doesn't sound like AI" produces worse writing than optimizing for "sounds like a person thinking." The validator must protect the author's voice, not just catch AI drift.

## Context
Text-eval flagged authentic voice characteristics in "The Perfect Storm" as AI tells. The overcorrected revision was worse than the original -- it had been stripped of the first-person discovery, vulnerability, and conversational rhythm that made the piece work.

## Alternatives Considered
1. **Treat all rhetorical devices as potential AI tells** -- Rejected. This was the existing behavior that caused the overcorrection. It optimizes for the wrong target (absence of AI signals) rather than the right one (presence of human voice).
2. **Whitelist specific devices** -- Rejected as too rigid. Voice is contextual, not a checklist.

## Consequences
- The evaluation frame shifted from "detect AI tells" to "protect human voice while detecting AI clustering."
- Threshold for flagging is raised when the evaluator detects strong, consistent voice markers in a piece.
- This principle now guides all text-eval agent behavior alongside the Voice Protection Gate mechanism.
