# DEC-2026-06-30-research-impassable-paywall-exclusion

**Status:** accepted
**Tags:** research, paywall, sources, citations
**Related:** [FLW-2026-03-23-content-pipeline-evolution]

## Context

During a `/research transformation` session, a Bloomberg article surfaced as a strong source for a focus article ("The Gray Beards Come Back"). Bloomberg is a hard paywall the Playwright fetch could not get past — only the free preview paragraph was readable. The user then asked to "update the research skill to exclude paywall articles." This collided with an existing, deliberate capability: `/research`'s Premium Source Pulse (`references/premium-feeds.md`) and Paywall Fallback (`references/paywall-auth.md`) intentionally read SOME paywalled sources (Foreign Policy, Trends Journal) in full via authenticated/headless scripts and treat them as first-class sources.

## Decision Drivers

- A source we cannot fully read can't be verified or cited (reinforces the existing "every URL that may become a citation must be fully read" directive), and shouldn't waste a drafting cycle by being surfaced as a finding.
- The premium-source machinery (FP, TJ) is recent and deliberate — a blanket "no paywalls" rule would tear out working, valued capability.
- Three scopes were on the table: (1) exclude only impassable paywalls; (2) reader-accessibility — never cite ANY paywall even ones we can read, because most readers can't reach it; (3) hard exclusion of all paywalled sources including FP/TJ.

## Decision

Chosen option: **Scope (1) — exclude only IMPASSABLE paywalls.** Articles behind a paywall the premium-source authentication and the Playwright fallback cannot get past (only a preview/abstract readable) are dropped at the discovery stage — not surfaced, not built into a finding, not cited as supporting context. Paywalls we hold authenticated access to and can read end-to-end (FP, Trends Journal) are explicitly exempt: the test is full-text access, not the mere presence of a paywall.

Rejected scope (2) reader-accessibility and scope (3) hard exclusion: both would have removed value (cutting sources we can legitimately read and verify) for a problem that was really about *unreadable* sources.

*— Captured 2026-06-30, source: user directive + clarifying-question scoping during /research session*

## Consequences

- New directive added to `/research` SKILL.md's immutable Directives block; `.directives.sha` regenerated.
- `references/premium-feeds.md` and `references/paywall-auth.md` unchanged and still accurate (they describe passable paywalls the directive exempts).
- The `source-verifier` agent already flags inaccessible/paywalled sources as `UNVERIFIABLE` after attempting the fallback — consistent with the directive; not modified this session.

## Confirmation Criteria

If the user later wants reader-accessibility enforcement (scope 2) — citing only sources a reader can reach — revisit and widen the directive; this DEC records that scope (2) was considered and deliberately deferred.
