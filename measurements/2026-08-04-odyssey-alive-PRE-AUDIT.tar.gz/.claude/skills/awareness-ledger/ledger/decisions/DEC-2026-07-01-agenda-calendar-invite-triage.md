# DEC-2026-07-01-agenda-calendar-invite-triage

**Status:** accepted
**Tags:** agenda, triage, google-calendar, calendar, cross-skill

## Context

During a `/agenda today` session the user asked (via `/route` → skill-builder) to "add an option to the agenda triage to create calendar items for SBDC meeting invites that come in from Email." The intent-router classified it `add-directive-to-existing` (target `/agenda`, `inline`) at 0.80 confidence, over a runner-up (0.50) that correctly flagged a cross-skill wrinkle: the *detection* of an invite lives in agenda triage, but the *event write* belongs to `/google-calendar`.

## Decision Drivers

- The trigger and detection are squarely agenda-triage domain (it already scans both inboxes and classifies signals); the calendar write is squarely `/google-calendar` domain. Reinventing calendar writes inside agenda would duplicate capability and split ownership.
- The memory/ledger precedent "tasks belong to /agenda" generalizes: agenda owns capture/triage; the actual side-effecting write is delegated to the owning skill.
- Scope question surfaced at ratification: SBDC-only vs. all meeting invites. The user chose **broaden to all invites** (SBDC becomes a named example, e.g. `sbdc.org`/`oregonsbdc.org`, not the whole scope).

## Decision

Chosen: a new immutable `/agenda` directive **"Calendar invites in triage"** — during the triage update-pass, any meeting/calendar invitation detected in the email scan proposes a Google Calendar event created via `/google-calendar` (event mode), routed through the confirmation walk (never silent) and dedup-guarded against existing events. Agenda never writes the event itself; the write is delegated to `/google-calendar`.

Wired end-to-end (not directive-only): a `calendar-invite` classification category (`signals.md` + `triage-classifier` AGENT.md with a `proposed_event` field), the change-set/apply/report path in `triage-workflow.md`, a `[+ EVENT]` proposal shape in `output-formats.md`, an enforcement CHECKPOINT beneath the directive, and refreshed `/route` triggers. `.directives.sha` regenerated (5 blocks; existing 4 hashes reproduced before trusting the new one).

*— Captured 2026-07-01, source: user directive + AskUserQuestion ratification (modify-vs-create via intent-router agent; SBDC-only vs. all-invites scope choice)*

## Consequences

- `/agenda` triage now emits calendar-event proposals alongside DEADLINE/TODO/NOTE proposals; the calendar write is a `/google-calendar event` Skill dispatch, outside `triage-write-guard.sh` (which governs org writes only).
- Dedup relies on `/google-calendar agenda` returning existing events for the target date; a same-date + overlapping-title match drops the proposal silently.
- Date-only invites (no time) are confirmed with the user before dispatch — the classifier never invents a time.

## Confirmation Criteria

If double-bookings appear, tighten the dedup match (title similarity threshold / time-overlap check). If the user later wants invites captured as org TODOs *in addition to* calendar events, that is a separate additive change — this DEC records that the calendar-event proposal is independent of TODO matching and does not currently also create a TODO.
