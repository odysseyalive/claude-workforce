# DEC-2026-04-17-skill-productization-service

**Status:** accepted
**Tags:** revenue, skill-productization, business-expansion, student-constraints
**Related:** business skill, skill-builder

## Context

Francis is a student (8 credit hours/term) running Odyssey Alive as an AI automation consulting business. Current income includes a $72K/year ticketing agency retainer and SBA consulting at $65/hr. Constraints: limited time, no cash for investment, need additional income streams that fit existing capabilities.

## Options Considered

### Option A: Skill Productization Service
- Good, because: leverages 30+ existing skills as proof of expertise
- Good, because: async delivery fits student schedule
- Good, because: zero cash investment required
- Good, because: natural extension of SBA consulting
- Bad, because: requires building client base from scratch

### Option B: Claude Code Skill Marketplace (Passive)
- Good, because: passive income after initial creation
- Bad, because: requires marketplace/distribution infrastructure
- Bad, because: longer build time before revenue

### Option C: Content Licensing
- Good, because: leverages existing 22+ articles
- Bad, because: lower price points, harder to scale
- Bad, because: commoditizes thought leadership

### Option D: Live Coaching/Workshops
- Good, because: higher perceived value
- Bad, because: conflicts with student schedule
- Bad, because: not async, violates time constraints

## Decision

Chosen option: **Option A (Skill Productization Service)**, because:
1. Immediate revenue potential with zero investment
2. Async-first model compatible with student schedule
3. Builds on existing skill-builder expertise (30+ skills built)
4. Natural upsell path from SBA workshops
5. Creates case studies for Option B later

## Consequences

- Created `/skill-productization` skill with intake, audit, proposal, deliver modes
- Service tiers: Audit ($150-300), Custom Skill ($500-1,500), Full System ($2,500-5,000)
- All deliverables are async (Loom videos, written audits)
- Marketing via focus articles and SBA workshops

## Confirmation Criteria

- First paying client within 60 days
- $2,000+ revenue from this service within 6 months
- At least one testimonial for social proof
- Service does not interfere with academic schedule
