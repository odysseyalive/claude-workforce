# DEC-2026-02-19-voice-protection-gate

**Status:** active
**Tags:** text-eval, voice, writing, validation
**Related:** DEC-2026-02-19-validator-overcorrection, PAT-2026-02-07-overbuilt-prose-drift

## Decision
Downgraded "overbuilt prose" from MUST FIX to SHOULD FIX (MUST FIX only when 3+ signals cluster in same passage). Added Voice Protection Gate, Human Markers Assessment, and Cluster Density to all three text-eval agents. Individual rhetorical devices are not AI tells -- only clustering is. Voice characteristics must be protected from the evaluator.

## Context
The text-eval validator overcorrected on "The Perfect Storm" article. It flagged Francis's authentic voice (first-person discovery, vulnerability, conversational rhythm) as "overbuilt prose" and "formula repetition." The revision stripped the article's humanity. The original was better than the "corrected" version.

## Alternatives Considered
1. **Keep MUST FIX severity** -- Rejected because it caused the validator to strip authentic voice markers indiscriminately.
2. **Remove overbuilt prose detection entirely** -- Rejected because the pattern is real (surfaced in two prior articles). The detection was correct, the severity was wrong.

## Consequences
- All three text-eval agents (prose-evaluator, structure-checker, and the coordination layer) now include Voice Protection Gate, Human Markers Assessment, and Cluster Density checks.
- Overbuilt prose flags only escalate to MUST FIX when 3+ signals cluster in the same passage.
- Individual rhetorical devices (first-person discovery, vulnerability, conversational rhythm) are protected as voice markers, not flagged as AI tells.
