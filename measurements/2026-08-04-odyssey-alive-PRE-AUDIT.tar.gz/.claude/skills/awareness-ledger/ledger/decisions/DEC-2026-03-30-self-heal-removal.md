# DEC-2026-03-30-self-heal-removal

**Status:** accepted
**Tags:** self-heal, skill-builder, skill-system
**Related:** []

## Context

The /self-heal skill was created as a standalone diagnostic and self-repair system. Over time, its responsibilities were absorbed by other mechanisms: the awareness ledger captures incidents and decisions, skill-builder's verify command handles health checks, and the debug skill covers problem-solving workflows.

## Decision Drivers

- Overlapping responsibility with awareness-ledger (incident capture), skill-builder verify (health checks), and debug (problem-solving)
- Self-heal was rarely invoked standalone
- Maintaining a separate skill with agents, procedures, and templates added maintenance burden without proportional value

## Decision

Chosen option: **Remove /self-heal entirely**, because its functions are covered by existing skills.

*— Captured 2026-03-30, source: skill system cleanup*

## Consequences

- /self-heal skill directory removed
- skill-builder procedures/self-heal.md and references/self-heal-templates.md removed
- No dangling references found in remaining skills or CLAUDE.md
- Diagnostic workflows handled by: /debug (active debugging), /awareness-ledger (incident capture), /skill-builder verify (health check)

## Confirmation Criteria

If a gap in self-diagnostic capability surfaces, reconsider whether debug + awareness-ledger + verify is sufficient coverage.
