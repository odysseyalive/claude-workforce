# DEC-2026-06-18-bank-reassessment-expense-index

**Status:** accepted
**Tags:** ynab, budget, expenses, bills, subscriptions, reconciliation, references/bills.md
**Related:** —

## Context

A 3-month export of Community Business Checking (Mar 18 – Jun 17, 2026; 365 real
transactions) was reconciled against the YNAB expense index in
`.claude/skills/ynab/references/bills.md` to find where spending was leaking. Two
structural facts framed everything:

- **The account is commingled.** Groceries, dining, pets, vet, kids' tuition (Lane),
  and personal Apple Cash transfers all run through *business* checking alongside
  business SaaS.
- **It is chronically overdrawn.** Closed March at −$2,553, sat at −$6.17 at export
  time, and absorbed **$196 in overdraft/NSF fees** over the quarter, plus dribbling
  foreign-transaction fees ("SVC CHG INTRNTL TRAN").

The index's subscription list and several budget targets had drifted from reality
(last updated January 2026).

## Options Considered

### Option A: Raise every over-target category to match actuals
- Good, because the index would then reflect real spend.
- Bad, because Dining/Groceries/Shopping are *behavioral overages*, not stale
  estimates. Inflating their targets to match the leak launders overspending into
  "plan" and defeats the purpose of the reassessment.

### Option B: Correct only the factually-stale targets; hold discretionary targets and flag the leaks
- Good, because it separates "the index was wrong" (fixed costs, missing subs) from
  "the behavior was wrong" (discretionary blowout) — two different remedies.
- Good, because it preserves the budget targets as a plan to steer toward.
- Bad, because the index now shows a deliberate gap between target and actual that a
  future reader must understand is intentional.

## Decision

Chosen option: **Option B.** Updated `references/bills.md`:

1. **Added 9 untracked SaaS subscriptions** absent from the index but running through
   the account: Twilio, Jina.AI, Quo/OpenPhone, DocuSign, FS\*Enlight, Google Cloud
   (metered), Prime Video rentals (Facebook Ads/OpenRouter were already listed).
   Monthly subscription total raised **$1,010 → $1,260**.
2. **Flagged — NOT added as recurring** — two one-time hits pending verification:
   **Enagic** ($276.40, water-ionizer MLM?) and **TrendsJournal.com** ($149.00,
   possibly annual). **Update (same day): both marked CANCELLATION PENDING** at the
   user's request — see Follow-Up below.
3. **Corrected stale fixed-cost targets:** Utilities **$650 → $790**, Insurance
   **$115 → $145**. Plan total **$7,059 → $7,479**.
4. **Held discretionary targets, flagged the overages:** Dining $217 (running
   ~$629/mo, ~3× over — the single biggest leak), Groceries $758 (~$1,090/mo, +44%),
   Shopping $200 (~$415/mo, ~2×).

## Consequences

- The index now distinguishes corrected estimates from leaks-to-close.
- Recommended remediation, in priority order: (1) stop the overdraft fees (fastest
  dollar, account is structurally negative); (2) audit orphan SaaS (Enagic,
  TrendsJournal, idle Google Cloud, Prime Video rentals); (3) cut dining;
  (4) de-commingle business and personal spending.
- **Caveat for any future reconciliation:** this export is ONE account. Rent
  ($2,300/mo target) is mostly paid elsewhere — only ~$155/mo of rent hit business
  checking — so the full household picture requires the second account's export.

## Confirmation Criteria

Next quarter's reconciliation shows: overdraft fees at $0, subscription line items
matching the index (Enagic/TrendsJournal resolved one way or the other), and dining
trending toward the $217 target rather than 3× it. If discretionary actuals stay 2–3×
over, the targets are fiction and the de-commingling/budgeting approach needs revisiting.

## Follow-Up — Enagic / TrendsJournal cancellation (2026-06-18)

User requested both be cancelled; status set to **CANCELLATION PENDING** in
`bills.md`. Neither could be cancelled programmatically (external vendor portals,
no account access, outward-facing action). Open actions for the user, with caveats:

- **Enagic ($276.40)** — ⚠️ **Verify finance status before acting.** Most likely an
  installment payment on a financed Kangen water ionizer, not a discretionary sub.
  Cancelling a finance plan ≠ stopping a subscription — it could mean defaulting on a
  purchase contract (credit impact / balance acceleration). Confirm via Enagic
  distributor account or Enagic USA (310) 542-7700; if financed, pursue payoff, not
  cancellation.
- **TrendsJournal.com ($149.00)** — Likely annual auto-renew (Gerald Celente). Action
  is turning off auto-renew (trendsjournal.com account or support@trendsjournal.com),
  not an urgent cancel; won't bill again until ~next year.
- **Rocket Money** ($9/mo, already subscribed) can action both and audit the rest of
  the SaaS stack.

Resolve to "cancelled" or "kept" in next quarter's reconciliation.
