# PAT-2026-04-25-cf-attribution-window-cap

**Status:** active
**Tags:** [analytics, cloudflare, ga4, attribution, measurement, content-performance, article-launch]
**Related:** [PAT-2026-04-01-the-dose-deep-engagement, PAT-2026-03-04-faster-than-thought-launch-day, DEC-2026-03-25-aeo-seo-deployment]

## Pattern
Per-article server-side attribution on Cloudflare is unrecoverable past ~9 days due to the zone tier's `httpRequestsAdaptiveGroups` retention cap. When publishing cadence is tight (multiple articles inside a 14-day post-release window), CF traffic spikes cannot be cleanly assigned to a single release after the fact — post-windows overlap and the per-path data is gone. GA4 per-page is the only longitudinal signal available, but its sample sizes are tiny (single-digit to low-double-digit page views per article) and bot-blind. The two sources together provide complementary but partial coverage; neither alone supports confident per-article attribution at a 30-day horizon.

## Evidence
1. **CF zone-tier cap observed 2026-04-25** — Querying `httpRequestsAdaptiveGroups` for any window starting more than ~9 days back returned: `"zone X cannot request data older than 1w1d, but your query requests data from 4w2d19h21m3s ago"`. The 30-day per-path query had to fall back to a 7-day window. — 2026-04-25
2. **Overlapping post-windows in March-April 2026 cohort** — 6 articles in 30 days (03-27 to 04-25), with at most 9 days between releases. The April 14 traffic peak (736 PV) sat inside both The Dose's 14-day post-window (day +14) and The Fortress's (day +4). Attribution was a judgment call (Fortress, by recency) rather than a measurement.
3. **CF/GA4 magnitude gap** — 30-day CF total: 15,584 page views. GA4 total: 387 page views. The ~98% gap is bots/crawlers/AI scrapers (78% automated + 5.7% verified bot in CF's bot-management decision data). GA4 is the only human signal but is sample-starved per article. — 2026-04-25
4. **Daily CF aggregates persist** — `httpRequests1dGroups` (the daily endpoint, used by the report mode) does work past 9 days, so total daily traffic is available for the full 30 days. The cap is specific to per-path/per-dimension adaptive groups. — 2026-04-25

## Counter-Evidence
1. **Recent-window attribution is fine** — When a single article is the only release in the past 7-9 days, CF per-path data answers attribution cleanly. The cap only bites when cadence is tight or analysis is retrospective.
2. **Cloudflare paid tiers** — Higher Cloudflare plans extend the adaptive-groups retention window. Upgrading is an option if measurement becomes a binding constraint.

## Applicability
- **When to use:** Planning analytics work, scoping evaluation reports, setting expectations for content-impact analysis. If the question is "what did article X do over its first 30 days on CF," the answer is "not retrievable past the first 9; use GA4 longitudinally and pull CF live within the window."
- **When NOT to use:** Within the 9-day window for any single article, CF per-path is reliable. Don't apply this cap as a reason to skip analysis when the data is still in scope.

## Mitigations
- **Pull-and-store per-article CF data within the 9-day window** — If long-horizon attribution matters, the analytics skill should snapshot per-path counts at day +7 and day +14 (while still inside the window) and persist to disk. The current skill does not do this.
- **Lean on GA4 for longitudinal** — GA4 retains per-page data well past 9 days. Accept the smaller sample sizes and treat percentages as directional.
- **Stagger releases when measurement matters** — If a specific article needs clean attribution, give it ~10+ days of solo post-window before the next release. Trades cadence for measurability.

## Confidence
HIGH — the cap is API-confirmed (explicit error message), the overlap is observed in this period's data, and the workaround (live snapshotting) is actionable. The pattern will recur every time cadence stays tight on this CF tier.
