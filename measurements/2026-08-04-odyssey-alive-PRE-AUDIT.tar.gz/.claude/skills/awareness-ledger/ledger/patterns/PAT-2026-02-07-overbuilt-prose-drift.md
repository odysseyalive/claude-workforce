# PAT-2026-02-07-overbuilt-prose-drift

**Status:** active
**Tags:** writing, text-eval, voice, drift
**Related:** DEC-2026-02-19-voice-protection-gate, DEC-2026-02-19-validator-overcorrection

## Pattern
The drafting agent falls into overbuilt prose even when the /writing directive is in context. Directives alone don't prevent it. Enforcement must live in the validator (text-eval), not just the instructions.

## Evidence
1. **"Your Page's Resume"** -- First observed instance of overbuilt prose despite /writing directive being active. -- 2026-02-07
2. **"The SaaSpocalypse"** -- Same drift recurred in an independent article, confirming the pattern is systematic, not a one-off. -- 2026-02-07

## Counter-Evidence
1. **Overcorrection risk** -- After adding enforcement to text-eval, the validator overcorrected on "The Perfect Storm" (see DEC-2026-02-19-validator-overcorrection). The fix introduced a new problem: stripping authentic voice. Calibration matters as much as detection.

## Applicability
- **When to use:** Any time the drafting agent produces content. Assume prose will drift toward overbuilt unless actively checked by the validator.
- **When NOT to use:** Don't use this pattern to justify aggressive pruning of voice markers. The correction for overbuilt prose must not strip humanity from the writing.

## Follow-Up
- Monitor text-eval performance after the Voice Protection Gate changes to confirm the balance holds.
- If overbuilt prose resurfaces despite text-eval enforcement, investigate whether the drafting agent's system prompt needs structural changes (not just directive additions).

## Confidence
HIGH -- confirmed across two independent articles, root cause identified (directives insufficient without enforcement)
