# PAT-2026-06-12-wit-shaped-noise

**Status:** active
**Tags:** text-eval, voice, validation, ai-tells, drift, captions, focus, edit
**Related:** INC-2026-06-04-frame-repetition-slipped-tell, PAT-2026-06-04-cluster-vs-spread-tells, PAT-2026-02-07-overbuilt-prose-drift, DEC-2026-02-19-voice-protection-gate

## Pattern

Two coupled findings from the same failure:

**1. Wit-shaped noise (the AI tell).** AI imitates the FORM of a wit beat — clipped fragment, possessive twist, personification — without verifying that the metaphor's referents resolve. The line sounds clever, then collapses under "wait, what?" Both instances copied the structure of a working caption in the same article ("Two roads. I'd been pretending they were one.") — borrowed form, absent thought. The user named it "the same confused pattern of thought." The test: every noun, pronoun, possessive, and personified entity must map to exactly one thing in the scene or argument.

**2. The one-line validator gap (the structural cause).** One-line content (captions, epigrams) structurally evades cluster-density rules: a single line can never accumulate the 3+ signals that escalate to MUST FIX, and a caption rides along as "body text" with no dedicated check. The validation pipeline CLAIMED caption coverage (focus/references/validation.md said text-eval owned the caption tests) but no evaluator agent actually read captions.md or ran a caption step. Claimed coverage is not wired coverage.

## Evidence

1. **"The research came back from a model the article never met."** — two-brains.mdx caption, drafted at article creation, passed full validation (2026-06-11). The article personified as an agent that "meets" models; the vantage point belongs to no one.
2. **"Two desks. I never got up from mine."** — replacement caption produced via /edit (2026-06-12), would have passed edit-validator (validation interrupted by user). "Mine" claims a desk when the image's two desks represent the two models; the possessive has no stable referent.
3. **Wiring trace (2026-06-12 placement consult):** prose-evaluator had no caption step; its grounding pointed at a nonexistent reference.md; edit-validator Check 4's clustering rule cannot fire on one line; focus/references/validation.md over-claimed text-eval's caption scope.

## Counter-Evidence

1. **Genuine wit beats pass the referent test by construction** — "Two roads. I'd been pretending they were one." resolves cleanly (roads = the two model specializations, established by the image and the argument). The test is near-binary, so voice-protection false positives are unlikely. No instances of a legitimate Francis caption failing the test yet observed.

## Applicability

- **When to use:** Any single-line content — image captions, epigraphs, pull quotes, slide titles, one-line social hooks. Single-line content gets the referent test with a cluster-density exemption: one unresolved referent IS the flag (MUST FIX). Also at draft time: if a caption copies the structure of a working caption nearby, check it extra hard.
- **When NOT to use:** Body prose pronoun sloppiness is the existing "Vague pronoun referents" pattern (antecedent exists but is far away). Wit-shaped noise is different: the referent doesn't exist anywhere because the thought is confused. Don't conflate severity paths.

**Enforcement (wired 2026-06-12):** ai-patterns.md "Wit-shaped noise" row; flag-severity.md MUST FIX "Unresolved wit referent"; prose-evaluator Step 1f (caption/epigram referent resolution); edit-validator Check 4 extension (single-line cluster exemption); captions.md test #4 (referent test) with renumbered touchpoints in focus workflow.md, validation.md, reference.md; user directive in text-eval SKILL.md.

## Confidence

HIGH — two confirmed instances in one session, root cause traced to specific unwired checks, fix verified against both instances and against the working caption as a negative control.
