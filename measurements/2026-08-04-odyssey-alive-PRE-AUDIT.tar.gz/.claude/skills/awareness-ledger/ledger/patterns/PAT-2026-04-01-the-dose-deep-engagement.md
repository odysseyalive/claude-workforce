# PAT-2026-04-01-the-dose-deep-engagement

**Status:** active
**Tags:** [analytics, article-launch, the-dose, content-performance, engagement, voice, cloudflare, ga4]
**Related:** [PAT-2026-03-04-faster-than-thought-launch-day, DEC-2026-02-19-voice-protection-gate]

## Pattern
Articles written from practitioner vulnerability — first-person stakes inside a technical problem, not analysis from above it — produce dramatically deeper engagement than observational pieces. "The Dose" hit 675s avg session duration (11+ minutes) on its first readers with 100% engagement, and 314s overall across its first 48 hours. This is the highest engagement depth of any article in the March 2026 cohort, despite having no promotion cycle yet.

## Evidence
1. **675s avg duration on first readers** — March 30 GA4 data shows 2 sessions, 100% engagement, 11+ minutes avg. These are people reading carefully, not skimming. — 2026-03-30
2. **314s overall avg duration** — Across all 14 GA4 page views in 48 hours, readers averaged 5+ minutes. For comparison, the month's top-volume article (The Broken Rung, 39 views) averaged 186s. — 2026-04-01
3. **67% engagement rate** — Double The Broken Rung's 39%. Small sample but consistent with the depth signal. — 2026-04-01
4. **Accelerating crawler pickup** — 26 CF path requests on launch day, 48 on day 2. Steeper than Faster Than Thought's 46 on launch day. AEO/IndexNow infrastructure working. — 2026-04-01
5. **Corroborating articles** — Faster Than Thought (86% engagement, 131s), No Brakes (80%, 185s), The Compliance Funnel (29% but 219s depth) all share the practitioner-vulnerability register. Articles in observational mode (The Quick Last Prompt: 6s, The Island: 6s) bounce immediately. — 2026-04-01
6. **Referral sources: direct only** — No social promotion has landed. The engagement is organic/direct, not driven by promotional context-setting. — 2026-04-01
7. **The Dress Rehearsal: 802s avg session, 100% engagement** — 5 GA4 page views in the first 2 days post-release (April 23), averaging 13+ minutes per session at 100% engagement. Tiny sample, but the depth signal mirrors The Dose's launch-window numbers and reinforces the practitioner-vulnerability register hypothesis. — 2026-04-25
8. **The Fortress: 186s avg, 50% engagement** — Same April-window cohort, 6 page views, 3+ minute average. Continues the pattern of practitioner-register pieces holding readers. — 2026-04-25
9. **The Trojan Combine: 19s avg, 42.9% engagement** — 15 page views but shallow dwell. The article drew curiosity volume but not commitment, suggesting register or hook didn't land in the same way. Useful negative case. — 2026-04-25

## Counter-Evidence
1. **Tiny sample size** — 14 GA4 page views across 3 days. A few long sessions could skew the average dramatically. Need post-promotion data to validate.
2. **Pre-publish traffic anomaly** — 8 GA4 page views on March 30, before the March 31 publish date. Could be testing/preview traffic inflating early engagement numbers.
3. **No promotion baseline yet** — Can't compare promoted vs organic engagement until the promotion cycle runs. The Broken Rung's lower engagement rate may partly reflect a wider, less self-selected audience.

## Applicability
- **When to use:** Choosing article register and topic framing. When deciding between "here's what's happening in AI" (observational) vs "here's what I carry as someone inside this" (practitioner vulnerability), the data favors the latter for engagement depth. Also relevant when evaluating text-eval output — the voice protection gate exists precisely to protect this register.
- **When NOT to use:** Volume-focused goals. Practitioner vulnerability may attract a smaller, deeper audience. If the goal is reach over resonance, a different register may perform better. Also don't apply to side-quest content, which serves a different purpose.

## Follow-Up
- Post-promotion check (by 2026-04-08): Re-run `/analytics article-impact the-dose` after social promotion to measure whether promoted traffic maintains the engagement depth or dilutes it.
- Cross-article comparison: When 3+ more articles publish, compare engagement depth by register (practitioner vulnerability vs observational vs analytical) to validate or refine the pattern.

## Confidence
MEDIUM-HIGH — consistent signal now visible across The Dose, The Dress Rehearsal, The Fortress, Faster Than Thought, No Brakes, and Compliance Funnel. Counter-cases (The Trojan Combine, observational pieces) clarify the boundary. Sample sizes per article remain small; pattern is strong but each individual article still tiny-N.
