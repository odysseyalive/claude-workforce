# PAT-2026-03-04-faster-than-thought-launch-day

**Status:** active
**Tags:** [analytics, article-launch, faster-than-thought, content-performance, cloudflare, ga4]
**Related:** []

## Pattern
Article launch day shows strong crawler/bot visibility before human promotion drives GA4-measurable traffic. "Faster Than Thought" hit 1,308 Cloudflare unique visitors on launch day (2x the next highest day in the window), but zero GA4 page views for the article path — indicating bot discovery outpaces human discovery when no promotion has occurred.

## Evidence
1. **Cloudflare uniques spike** — 1,308 on Mar 4 vs. 766 on Mar 2 (next highest). 2x jump coincides with article publish. — 2026-03-04
2. **46 path-specific requests** — `/focus/faster-than-thought` received 46 Cloudflare requests on day 1, all server-side (bots/crawlers). — 2026-03-04
3. **Zero GA4 article views** — No client-side JavaScript fired for the article path, confirming no human readers yet. — 2026-03-04
4. **Site-wide engagement peaked** — 36.4% GA4 engagement rate on launch day, 166s avg session duration. Best engagement in the 8-day window. — 2026-03-04
5. **Bot traffic dominance** — 84% non-human traffic (45% automated, 29% likely automated, 9% verified bot). Consistent with pro-bot/GEO strategy. — 2026-03-04

## Counter-Evidence
1. **Single data point** — This is one article on one day. The crawler spike could correlate with other factors (e.g., Mar 2 also saw high requests at 6,303 without a new article). Need more launch-day comparisons to confirm the pattern.

## Applicability
- **When to use:** Evaluating launch-day performance of new articles. Expect crawler visibility first, human traffic after promotion. Don't judge an article's potential by day-1 GA4 numbers alone.
- **When NOT to use:** Articles that are pre-promoted (newsletter teaser, social pre-share) before publish — those may show simultaneous bot + human traffic.

## Follow-Up
- 7-day check (by 2026-03-11): Re-run `/analytics article-impact faster-than-thought` after promotion to measure human impact.
- Topic has strong news-peg potential (AI in military operations, Anthropic/Iran strikes). Compare against typical article performance once promotion cycle completes.

## Confidence
LOW — single observation, needs validation across future launches
