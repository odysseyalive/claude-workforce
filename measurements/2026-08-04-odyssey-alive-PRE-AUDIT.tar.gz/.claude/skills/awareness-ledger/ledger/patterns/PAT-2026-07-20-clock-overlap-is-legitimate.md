# PAT-2026-07-20-clock-overlap-is-legitimate

**Status:** active
**Tags:** timesheet, org-mode, clock, concurrency, directives, enforcement
**Related:** INC-2026-01-26-task-matcher-skipped

## Pattern
Overlapping org `CLOCK:` ranges in Francis's time data are legitimate concurrent work, not a data error. Francis routinely runs more than one job at a time, so two blocks covering the same wall-clock minutes are expected, and a day's summed CLOCK time may exceed elapsed wall-clock time.

The recurring failure is on the assistant's side: noticing an intersection between two time ranges *feels* like a finding, so the model surfaces it as a warning and offers to "fix" it — even though no skill instructs it to check for overlap at all. The check is a reflex, not a requirement. Dedup identity in `/timesheet` has always been `task_id` + `log_date` + `duration` (sync-model.md § Idempotency); time-range intersection is not a key and must never become one.

## Evidence
1. **Two `/timesheet log` runs, same session** -- After logging 22:03–22:53 to "tax refund calculation hardening" and 22:52–23:20 to "Live Server Update", the assistant twice flagged the one-minute intersection and offered to adjust a CLOCK line. Francis's correction: "I often run more than one job at a time. Please don't be concerned about overlap anymore." -- 2026-07-20
2. **Prior occurrence, months earlier** -- `time-sync-state.json:495` carries the note "overlaps TicketTomato converge-search block 10:20-13:21; posted as-is per user confirmation", showing the same friction was raised and waved off in an earlier session. -- 2026-06
3. **No skill ever asked for the check** -- A read-only classifier sweep of `/timesheet`, `/agenda`, and `/estimate` found zero overlap-detection logic. `agenda/hooks/triage-write-guard.sh` (lines 111–131) only blocks edits that *decrease* CLOCK line count. The warning was improvised each time. -- 2026-07-20

## Counter-Evidence
1. **Downstream consumers that sum hours** -- `/estimate` (SKILL.md lines 39–51) sums CLOCK hours per task type with no concurrency handling. Overlap is correct as *logged* data, but any consumer treating logged hours as elapsed capacity will overstate available time. The pattern licenses ignoring overlap, not assuming hours equal wall-clock.

## Applicability
- **When to use:** Any mode of `/timesheet` (`push`, `pull`, `sync`, `status`, `log`) and any reading of org CLOCK data. Treat time-range intersection as a non-event: no warning, no question, no report mention, no adjustment.
- **When NOT to use:** Don't extend this into "time data never needs scrutiny." Genuine defects — a duplicate post keyed on `task_id`+`log_date`+`duration`, a CLOCK line that lost time, a phantom Zoho entry — remain real findings. This pattern narrows one specific reflex, not the skill's diligence.

## Follow-Up
- The rule is captured as the Concurrent-Work Directive in `.claude/skills/timesheet/SKILL.md` § Directives (immutable, checksum-protected) with an enforcement-annotation CHECKPOINT beneath it, because prose alone had already failed twice.
- If an overlap warning surfaces again despite the annotation, the next escalation is structural — the reflex would then be surviving an explicit literal-execution gate, which is worth investigating rather than patching with more prose.

## Confidence
HIGH -- observed twice in one session plus a documented earlier occurrence, with the root cause confirmed by inspection (no skill mandates the check; it is a model-side reflex).
