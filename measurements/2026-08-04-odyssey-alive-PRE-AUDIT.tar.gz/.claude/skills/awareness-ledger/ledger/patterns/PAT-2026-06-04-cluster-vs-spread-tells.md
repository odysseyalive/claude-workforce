# PAT-2026-06-04-cluster-vs-spread-tells

**Status:** active
**Tags:** text-eval, voice, validation, edit, ai-tells, drift, quality
**Related:** INC-2026-06-04-frame-repetition-slipped-tell, DEC-2026-06-04-model-switch-not-for-inline-drafting, PAT-2026-02-07-overbuilt-prose-drift, DEC-2026-02-19-voice-protection-gate, DEC-2026-02-19-validator-overcorrection

## Pattern
AI tells come in two shapes, and passage-level validators only see one. **CLUSTERED** tells (3+ signals stacked in a single passage) are caught by per-passage cluster checks. **SPREAD** tells — the SAME sentence-frame repeated evenly across a whole document, roughly one instance per section — never cluster in any passage and slip through every per-passage check, yet read strongly as AI to a human. Whole-piece formula must therefore be detected at WHOLE-DOCUMENT scope, as a separate check from per-passage clustering.

The voice-safe way to detect spread tells is a **definitional gate**, not a count threshold:
- **META-FRAME (count it):** a content-free signpost whose only job is "pay attention, something matters here" — "Here is the thing", "This is where", "the part that nagged at me", "What's strange is", "stranger than".
- **DISCOVERY BEAT (do NOT count):** a content-bearing first-person discovery — "I was reading X when a number stopped me". This is the author's Curiosity-Driven Discovery voice, not formula.

The gate is what prevents the validator from stripping authentic voice (the DEC-2026-02-19-validator-overcorrection failure mode). The count threshold is secondary; do not lean on a high threshold to do the voice-protection job.

## Evidence
1. **INC-2026-06-04-frame-repetition-slipped-tell** — a 6-instance frame family passed two validators twice; a human caught it instantly. (2026-06-04)
2. **PAT-2026-02-07-overbuilt-prose-drift** — prior evidence that drift must be caught in the validator, not by directives alone. (2026-02-07)

## Counter-Evidence
1. **Over-flag risk** — without the meta-frame gate, this check would flag legitimate recurring discovery voice as formula, repeating the "Perfect Storm" overcorrection (DEC-2026-02-19-validator-overcorrection). The definitional gate, not the count, is the mitigation. (2026-06-04)

## Applicability
- **When to use:** evaluating any whole piece (focus article, long-form, newsletter) for AI-tell formula. Run a whole-document frame-repetition scan IN ADDITION TO per-passage cluster checks. Implemented as text-eval structure-checker Step 3d.
- **When NOT to use:** single-passage edits — edit-validator can only check the frame an edit introduces, not the whole doc (it carries a scoped pointer instead). Do not loosen voice-evaluator's passage-locality to chase this; keep responsibilities separate.

## Confidence
HIGH
