# FLW-2026-03-23-content-pipeline-evolution

**Status:** active
**Tags:** focus, writing, edit, content-pipeline, research, paywall
**Related:** DEC-2026-03-23-edit-skill-creation, DEC-2026-02-19-voice-protection-gate

## Flow Description

The content creation pipeline evolved significantly in March 2026, adding new capabilities and enforcement points. This flow captures the current state after multiple incremental changes.

## Steps

| Step | Action | Code Path | Notes |
|------|--------|-----------|-------|
| 1 | /research gathers sources | `.claude/skills/research/` | Paywall reader via Playwright added for FP/TJ |
| 2 | /focus drafts article | `.claude/skills/focus/` | --long flag added (1200 words, 2-3 images) |
| 3 | /voice + /writing kernel loaded | `.claude/skills/voice/`, `/writing/` | Always loaded before drafting |
| 4 | /image generates watercolors | `.claude/skills/image/` | Chains to /image-eval |
| 5 | /edit validates revisions | `.claude/skills/edit/` | New gateway, loads writing kernel |
| 6 | /text-eval assesses output | `.claude/skills/text-eval/` | All severity levels now mandatory in finishing chain |
| 7 | /promote creates social posts | `.claude/skills/promote/` | Name drops must be household-recognizable |
| 8 | /newsletter summarizes for Mailchimp | `.claude/skills/newsletter/` | |

## Environmental Conditions

- Word count hook is advisory (exit 0 with WARNING), not blocking
- Finishing chain runs text-eval on all severity levels, not just MUST FIX
- Paywall reader requires Playwright installed (`npx playwright install chromium`)
- RSS pulse pre-search available via site /feed route

## Edge Cases

- Side quest articles (`sideQuest: true`) skip some SEO requirements
- Long-form articles have different image count (2-3 vs exactly 2)
- Mechanical edits (typos, dates, URLs) bypass /edit gateway
