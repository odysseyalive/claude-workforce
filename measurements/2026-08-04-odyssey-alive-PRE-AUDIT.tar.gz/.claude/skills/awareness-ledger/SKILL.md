---
name: awareness-ledger
description: "Institutional memory for your project. Commands: record, consult, review. Usage: /awareness-ledger [command] [args]"
allowed-tools: Read, Glob, Grep, Write, Edit, Task
minimum-effort-level: high
strictness: standard
---

# Awareness Ledger

Institutional memory that persists across sessions. Records incidents, decisions, patterns, and flows so diagnostic findings and architectural decisions survive context boundaries.

## Commands

| Command | Purpose |
|---------|---------|
| `/awareness-ledger record [type]` | Create a new record (INC, DEC, PAT, FLW) |
| `/awareness-ledger consult [topic]` | Query the ledger for relevant history |
| `/awareness-ledger review` | Health check: stale entries, missing links, statistics |

---

<!-- origin: user | added: 2026-02-25 | immutable: true -->
## Directives

> **"Capture is always user-confirmed. Agents suggest, user decides. Never auto-record."**

*— Added 2026-02-25, source: initial creation*

> **"Consultation happens during planning, not at edit time. The ledger shapes the plan, not the code."**

*— Added 2026-02-25, source: initial creation*
<!-- /origin -->

---

### Auto-Consultation (READ)

During research and planning — before formulating any plan, recommendation, or code change proposal — automatically consult the ledger:

1. **Index scan** — Read `ledger/index.md` and match tags against the files, directories, and components under discussion. This is free — the index is small.
2. **Record review** — If matching records exist, read the full record files. Incorporate warnings, known failure modes, and relevant decisions into your thinking before presenting any plan.
3. **Agent escalation** — If high-risk overlap is detected (matching INC records with active status, or multiple record types matching the same change area), spawn consultation agents proportionally per [references/consultation-protocol.md](references/consultation-protocol.md).

Skip auto-consultation for `.claude/` infrastructure files, trivial edits (typos, formatting), and areas with no tag overlap in the index.

### Auto-Capture Suggestion (WRITE)

When the current conversation produces institutional knowledge, suggest recording it **after** resolving the immediate issue. Never interrupt active problem-solving to suggest capture.

Automatically suggest capture when you encounter:
- **Bug investigation** with timeline, root cause analysis, or contributing factors → INC record
- **Architectural decisions** with trade-offs discussed and option chosen → DEC record
- **Recurring patterns** observed across multiple instances → PAT record
- **User/system flows** traced step-by-step with code paths → FLW record

---

## Ownership Boundary: Ledger vs. Auto Memory

Claude Code's auto memory (at `~/.claude/projects/<project>/memory/`) and the awareness-ledger are complementary, not redundant. Before capturing, decide which system owns the fact:

- **Auto memory owns** per-user-per-machine ergonomics: writing preferences, notation rules, humor calibration, tool aliases, invocation habits, transient session state. These do not travel via git and should not.
- **The ledger owns** project-shareable records (INC, DEC, PAT, FLW). These travel with the repo and must be visible to teammates, CI, and fresh checkouts.

When a fact straddles both (e.g. an architectural decision the maintainer also wants always-loaded), the **ledger record is canonical**. The memory entry references the ledger ID (e.g. `See DEC-2026-03-23-edit-skill-creation`) instead of re-narrating the facts. This keeps one source of truth and avoids silent drift between narrative memory and structured record.

Rule of thumb: if losing the fact on a laptop reinstall would hurt the project, it belongs in the ledger.

---

## Record Command

When invoked with `/awareness-ledger record [type]`:

1. Validate the type (INC, DEC, PAT, FLW)
2. Read the template from [references/templates.md](references/templates.md)
3. Generate an ID: `[TYPE]-YYYY-MM-DD-slug`
4. Walk through the template fields with the user
5. Write to `ledger/[type-plural]/[id].md`
6. Update `ledger/index.md`

---

## Consult Command

When invoked with `/awareness-ledger consult [topic]`:

1. Read `ledger/index.md` for tag matching
2. Identify matching records by tag, file path, or domain overlap
3. If matches found, read full records
4. Spawn agents proportionally (see [references/consultation-protocol.md](references/consultation-protocol.md))
5. Synthesize findings into consultation briefing format

**Grounding:** Read [references/consultation-protocol.md](references/consultation-protocol.md) for proportional agent spawning rules and briefing format.

---

## Review Command

When invoked with `/awareness-ledger review`:

1. Count records by type and status
2. Flag stale records (active status, no related records, >90 days old)
3. Check for broken cross-references (related fields pointing to non-existent records)
4. Report tag distribution and coverage gaps
5. Regenerate `ledger/index.md` if needed

---

## Agents

| Agent | Persona | Reads | Focus |
|-------|---------|-------|-------|
| [regression-hunter](agents/regression-hunter/AGENT.md) | Veteran QA engineer | incidents/, flows/ | Past incidents overlapping with current change |
| [skeptic](agents/skeptic/AGENT.md) | Epistemologist | decisions/, patterns/ | Counter-evidence and challenged assumptions |
| [premortem-analyst](agents/premortem-analyst/AGENT.md) | Risk specialist (Klein methodology) | Full index | Imagines the change already failed |

---

## Grounding

Read the relevant reference file before using its content:
- [references/templates.md](references/templates.md) — Record type templates (INC/DEC/PAT/FLW), status lifecycle, index rules
- [references/consultation-protocol.md](references/consultation-protocol.md) — Agent spawning rules, briefing format, proportional overhead
- [references/capture-triggers.md](references/capture-triggers.md) — Conversation signals that suggest a record should be created

---


---

<!-- ROUTE-EMBED START — auto-generated by /skill-builder route embed; safe to replace -->
<!-- origin: skill-builder | modifiable: true -->
## Route Consultation

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: /skill-builder route embed. Closes the dispatch-bypass gap: a /route announcement is not a substitute for a Skill tool call, and consulting /route does not license the caller to execute the target skill's procedure manually. -->
CHECKPOINT — Skill Routing Gate:
1. During this skill's workflow, IF a step requires research, web search, lookup, analysis, or any follow-up NOT already covered by an explicit tool or skill name → STOP before improvising.
2. Already-named exception. IF the current workflow step EXPLICITLY names tools or skills (e.g., "use Read", "spawn the X agent", "invoke /[skill]") → execute as written. Do NOT consult `/route` for steps already determined. Skip to your skill's next step.
3. Otherwise → invoke `/route <task description>` via the Skill tool. `/route` reads its index and either returns a target skill or reports "no match."
4. Dispatch Required. IF `/route` returns a target → the IMMEDIATE next tool call MUST be `Skill(skill=<target>, args=<derived>)`. Do NOT execute the target skill's procedure steps yourself with raw Edit / Write / Bash / Task / Agent / Read calls. The target skill's gates (asset backups, agent panels, exit tests, cascade steps, frontend-design reviews, immutable-directive checks) ONLY fire when its SKILL.md is loaded via Skill — running steps manually silently skips every gate.
5. Bypass detection. IF a Skill dispatch was just announced (yours or `/route`'s) and the next tool call is non-Skill work germane to the routed task → STOP. Print verbatim: "Route dispatch announced but Skill call skipped. Invoking Skill tool now." then issue the Skill call.
6. No-match path. IF `/route` returns "no match" → proceed with the most direct, manual approach. Document the gap; the user may want to register a skill.
7. Follow-ups loop back. After the dispatched skill returns, IF further follow-up is needed → consult `/route` again via Skill. Do not freelance the next step.
8. Auto-mode override clause. Auto-mode ("execute immediately", "prefer action over planning") does NOT override clauses 4–5. Auto-mode chooses WHAT to do; once a routing decision is on the table, the only valid next action is Skill invocation.
<!-- END ENFORCEMENT ANNOTATION -->
<!-- /origin -->
<!-- ROUTE-EMBED END -->
