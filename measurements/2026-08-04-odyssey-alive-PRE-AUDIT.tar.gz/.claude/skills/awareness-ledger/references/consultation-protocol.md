# Consultation Protocol

## Triage Rules

When consulting the ledger, follow proportional escalation:

1. **Index scan** — Read `ledger/index.md`, match tags against current context
2. **If no matches** — Report "No records match." Skip agents. Zero overhead.
3. **If matches found** — Read matching records, then spawn agents proportionally

## Proportional Agent Spawning

| Match Scope | Agents Spawned | Rationale |
|-------------|----------------|-----------|
| No records match | None | Zero overhead |
| Only incidents/flows match | Regression Hunter only | Single perspective |
| Only decisions/patterns match | Skeptic only | Single perspective |
| Risk/failure language detected | Premortem Analyst only | Targeted premortem |
| Multiple record types match | All three agents (full panel) | Cross-referencing needed |

## Agent Invocation

For each agent to spawn:

```
Task tool with subagent_type: "general-purpose"
Prompt: "Read .claude/skills/awareness-ledger/agents/[agent-name].md for instructions.
        Context: [describe what is being changed and why]
        Matching records: [list record IDs]
        Read each matching record file. Return findings per your instructions."
```

## Synthesis Rules

After agents return:
- **All agents agree** → HIGH confidence warning
- **Agents disagree** → The disagreement IS the signal. Present both sides.
- **Single agent, clear finding** → Report as consideration, not warning

## Briefing Format

```markdown
## Ledger Consultation

### Warnings (HIGH confidence — agents agree)
- **[Warning]** — [record reference] — [explanation]

### Considerations (agents disagree)
- **[Topic]**
  - Regression Hunter: [finding]
  - Skeptic: [finding]
  - Premortem Analyst: [finding]

### Context (relevant records, no warnings)
- [ID] — [why relevant]

### Capture Opportunity
[If the conversation revealed knowledge not yet in the ledger]
- Suggested type: [INC/DEC/PAT/FLW]
- Suggested ID: [auto-generated]
- Confirm to record, or skip.
```
