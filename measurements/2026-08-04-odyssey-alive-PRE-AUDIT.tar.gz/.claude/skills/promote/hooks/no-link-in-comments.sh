#!/bin/bash
# Hook: Block "link in comments" phrases per /promote directive
# Scope: Project content files only (skips .claude/ infrastructure)
CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR

INPUT=$(cat 2>/dev/null) || exit 0

# Scope check: skip .claude/ infrastructure files
FILE_PATH=$(echo "$INPUT" | grep -oP '"file_path"\s*:\s*"[^"]*"' 2>/dev/null | head -1 | sed 's/.*"file_path"\s*:\s*"//;s/"$//')
if echo "$FILE_PATH" | grep -q '\.claude/' 2>/dev/null; then
  exit 0
fi

# Check for "link in comments" and variations
if echo "$INPUT" | grep -qi "link in \(the \)\?comments\|check \(the \)\?comments\|comment for \(the \)\?link\|link below\|link in \(my \)\?bio" 2>/dev/null; then
  echo "BLOCKED: Do not reference 'link in comments' or similar. Put the link in the first comment silently, per /promote directive." >&2
  exit 2
fi
exit 0
