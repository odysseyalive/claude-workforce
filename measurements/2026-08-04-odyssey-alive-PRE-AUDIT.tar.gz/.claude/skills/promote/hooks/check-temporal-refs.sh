#!/bin/bash
# Hook: Flag unresolved relative date phrases in social media content
# These phrases become stale once published. Require absolute dates instead.
# Scope: Social post content written via Write or Edit tool
CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR

INPUT=$(cat 2>/dev/null) || exit 0

# Extract file path from tool JSON
FILE_PATH=$(echo "$INPUT" | grep -oP '"file_path"\s*:\s*"[^"]*"' | head -1 | sed 's/.*"file_path"\s*:\s*"//;s/"$//')

# Scope check: skip infrastructure files and the internal /agenda dashboard
# (agenda/ is a local briefing tool whose whole purpose is temporal — not outbound content;
# .org files are internal org-mode records with dated note lines, never LinkedIn content)
if echo "$FILE_PATH" | grep -qE '\.claude/|(^|/)agenda/|\.org(_archive)?$'; then
  exit 0
fi

# Get content from Write or Edit tool
CONTENT=$(echo "$INPUT" | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    inp = data.get('tool_input', data)
    print(inp.get('content', inp.get('new_string', '')))
except:
    pass
" 2>/dev/null)

if [ -z "$CONTENT" ]; then
  exit 0
fi

# Check for relative temporal phrases that become stale in published content
PHRASES=$(echo "$CONTENT" | grep -inP '\b(this week|this month|this year|today|yesterday|tomorrow|last week|last month|next week|next month)\b' | head -5)

if [ -n "$PHRASES" ]; then
  echo "BLOCKED: Relative date phrases found in social post content. Replace with absolute dates (e.g., 'March 25' instead of 'this week'). CLAUDE.md rule: temporal references are literal." >&2
  echo "$PHRASES" >&2
  exit 2
fi

exit 0
