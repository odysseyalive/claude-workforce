# Skill Chaining Order

**Before writing any content:**

1. Invoke `/voice` — Load Francis's authentic voice
2. Read `.claude/skills/promote/references/social-writing.md` — Five writing directives for short-form social
3. Read `.claude/skills/promote/references/social-coherence.md` — Seven structural rules for connected social posts
4. Read `.claude/skills/voice/references/satirical-wit.md` — Read the before/after examples until you feel the difference between a flat hook and one with punch

**After reading references, before writing any posts:**
5. Run the Hook Workshop (see SKILL.md § Hook Workshop)

**After writing content:**
6. Run validation (see [validation.md](validation.md))

**Optional:** Run Trend Pulse between steps 2 and 3. **Grounding:** [trends.md](trends.md)
