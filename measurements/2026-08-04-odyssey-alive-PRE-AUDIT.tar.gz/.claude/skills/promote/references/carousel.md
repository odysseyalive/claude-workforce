# Carousel Generation

## When to Offer

Articles with strong data contrasts (e.g., $200B vs 17 hires), stat-by-stat narratives, step-by-step frameworks, or before/after comparisons. The content must build tension slide by slide.

**When NOT to offer:** Reflective essays, personal narratives, opinion pieces where the insight lives in the prose rhythm, not in extractable data points.

## How to Generate

1. **Write the slide content** (6-8 slides). One idea per slide. Numbers should be the biggest visual element on data slides.
2. **Create an HTML file** at `assets/carousels/[slug].html` using brand styles:
   - 1080x1080px slides with `@page { size: 1080px 1080px; margin: 0; }` and `page-break-after: always`
   - Brand colors from `globals.css` (cream `#F7EDE2`, coral `#FFA07A`, brand-black `#4A3828`, accent `#FFE0A8`, bg `#FDF8F0`)
   - Fonts: Playfair Display (serif, headlines/numbers), Inter (sans, body text) via Google Fonts import
   - **Typography must be large and readable.** Headlines: minimum 64px. Body text: minimum 36px. Stats/numbers: 80-120px. Slide text should be comfortably readable on a phone screen without zooming. When in doubt, go bigger.
   - Vary slide backgrounds for visual rhythm (cream, white, dark, coral)
   - Include `ODYSSEY ALIVE` brand mark and slide numbers on each slide
3. **Add watercolor backgrounds from the article's existing images.** Reuse the hero and inline images as subtle slide backgrounds. Do not generate new images. Use a `.slide-bg` layer with low opacity (0.15-0.3) and a `.slide-bg-overlay` gradient for text legibility. Balance: aim for ~half the slides with watercolor backgrounds, half clean. Bookend the carousel (slides 1 and 8) with the hero image. Use inline images on middle slides where the image concept matches the slide content.
4. **Preview in browser** to verify layout, readability, and watercolor balance
5. **Generate PDF** with headless Chromium:
   ```bash
   chromium --headless --no-sandbox --disable-gpu \
     --print-to-pdf="assets/carousels/[slug].pdf" \
     --no-pdf-header-footer --print-to-pdf-no-header \
     file:///[absolute-path]/assets/carousels/[slug].html
   ```
6. **Verify** the PDF has the correct page count and 810x810pt dimensions (`pdfinfo [file].pdf`)
7. Upload the PDF to LinkedIn as a document post

**Output:** Both `assets/carousels/[slug].html` (source) and `assets/carousels/[slug].pdf` (uploadable) are generated. The HTML is the source of truth for future edits.

## What NOT to Include

> **No URLs in carousel PDFs.** Links inside PDF document posts are not clickable or tappable on LinkedIn. They're dead text. The article link belongs in the first comment on the companion text post, not on the slides. The final slide should close with the message, not a CTA.

*— Added 2026-03-03, source: first carousel build for "Your AI Has Amnesia"*

---
*Split from SKILL.md by skill-builder optimize. Enforcement boundary: none.*
