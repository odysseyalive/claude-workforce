# Humor Workshop (Optional)

**Optional: Humor Workshop** (connective wit)

After Stage 1 passes, offer the humor workshop before proceeding to Stage 2:

"Posts passed platform validation. Want to workshop any humor using `/wit humor`? The Connector agent can map bridges between the article's themes and your posts."

If Francis accepts:
1. Run `/wit humor` on the post set, using the source article as context for the Connector agent.
2. The Connector maps semantic fields from the article's major themes and looks for bridge words that could connect ideas across or within posts.
3. Workshop the connections with Francis per the humor workflow (Phase 1-3).
4. Apply accepted humor, then proceed to Stage 2.

If Francis declines or doesn't respond, proceed directly to Stage 2.
