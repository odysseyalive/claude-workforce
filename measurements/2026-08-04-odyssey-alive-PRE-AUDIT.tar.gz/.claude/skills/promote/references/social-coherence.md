# Social Coherence Rules

Seven structural rules distilled from the writing kernel for short-form social posts. These govern how sentences connect and build, not how they're punctuated. For mechanical rules (em-dashes, colons, texture words), see [social-writing.md](social-writing.md).

> **Every sentence connects to the one before it.** A social post is a paragraph, not a list. Each sentence should build on, respond to, or complicate the previous one. If you can reorder sentences without losing meaning, the post is disconnected. Bad: fact, fact, fact. Good: observation, implication, escalation.

> **Ground every reference before using it.** If you mention "those apps" or "that study," the noun must already exist in the post. No forward references. No assumed context. The reader arrived two seconds ago and knows nothing about the article. Every demonstrative ("those," "that," "this") must point to something already on screen.

> **Data is discovery, not report.** Statistics enter as things Francis found, not things he's briefing. Don't drop numbers cold. One sentence names the source conversationally, the next carries the number, the next carries the implication. "Stack Overflow asked developers if they trust AI. 29% said yes. Down 11 points from last year." Not: "Stack Overflow found 84% of developers use AI tools, but only 29% trust them, down 11 points in a single year."

> **One thread, one takeaway.** A social post can hold one idea with two or three supporting beats. Not two ideas with one and a half beats each. If you have two good angles, write two posts. The reader should be able to say what the post was about in one sentence. If they can't, the post tried to do too much.

> **Progressive build, not parallel facts.** Sentences should escalate or deepen. The last sentence of the body should feel like an arrival, not an addition. The quiet escalation technique from satirical-wit.md is the model: facts in ascending order, where the progression IS the argument. Each sentence raises the stakes or tightens the lens.

> **Let ideas land.** If a stat is surprising, give it one sentence of space before pivoting to the next fact. In five to eight sentences, "landing" means one sentence of implication or reaction before moving on. Don't rush past the thing that matters. The pause is where the reader thinks.

> **The aloud test.** Read the post aloud. If it sounds like a person telling a colleague what they found, it works. If it sounds like a slide deck with periods instead of bullets, it doesn't. The ear catches what the eye forgives.
