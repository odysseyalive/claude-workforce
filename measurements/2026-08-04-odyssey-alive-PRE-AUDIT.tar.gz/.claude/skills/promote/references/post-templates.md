# Post Structure Templates

## LinkedIn Personal Profile

**The first sentence IS the post.** LinkedIn truncates at ~140-210 characters (device-dependent). Everything after "See more" requires a tap. The first sentence must stop a thumb. It should land above LinkedIn's "See more" fold (~140 characters). What goes in that sentence is a creative decision, not a formula. Sometimes it's a witty observation. Sometimes it's a jarring fact. Sometimes it's a question. The only test: would someone tap "See more"?

**The hook is wit, not information.** The first sentence should make someone smirk, wince, or feel implicated. The article's data comes after the fold. If the first sentence reads like a news brief ("X organization found Y"), it's information-first. Rewrite it.

**Total length: 5-8 sentences, 500-900 characters.** Francis doesn't conform to LinkedIn essay culture. But dwell time (31-60 seconds) is the silent distribution multiplier, and saves (5x more powerful than likes) reward reference-value content. 5-8 sentences gives dwell time enough to work with without padding. Research shows 800-1,000 characters optimal (AuthoredUp, 3M+ posts).

```
[First sentence: stop the thumb. ~140 characters. Must work alone above the fold.]

[5-6 more sentences: support, context, or a second wit beat. New information, not repetition.]

---
[First comment: Link to article (no announcement, just the link)]
```

**Example (good — Understated Absurdity technique):**
> UC Berkeley found the most productive employees their companies have ever measured. They also found 83 percent of them are burned out. Somebody should probably look into whether those are related. The tools did everything they promised. Product managers wrote code. Designers did engineering. People sent prompts during lunch, between meetings, right before bed. Five seconds felt like nothing. Eight months later, the pauses were gone.

**Why this works:**

- You smirk before you know the details. Two facts stated plain, and your brain does the math.
- "Somebody should probably look into whether those are related" is deadpan that earns the tap.
- After the fold, the post escalates with specifics (who did what, the five-second detail) — new information, not repetition.
- ~530 characters, 9 sentences. Enough substance for dwell time without padding.

**Previous example (still valid — Self-Implicating "We"):**
> My mechanic works from outside the engine. Where he can actually see what he's doing.
>
> Novel concept for AI architecture, apparently. When the model manages itself, you're three layers deep with no breadcrumbs.
>
> Yes, I suppose I have a gripe.

**Previous example (still valid):**
> My mechanic works from outside the engine. Where he can actually see what he's doing.
>
> Novel concept for AI architecture, apparently. When the model manages itself, you're three layers deep with no breadcrumbs.
>
> Yes, I suppose I have a gripe.

## LinkedIn Company Page

Same first-sentence framework, "we" perspective. Same length range (500-900 characters).

```
[First sentence: stop the thumb. ~140 characters. "We" perspective. Must work alone above the fold.]

[5-6 more sentences: support, context, or a second wit beat. New information, not repetition.]

---
[First comment: Link to article (no announcement)]
```

## Platform Creation Steps

### Step 1: Write LinkedIn Personal Profile Post

The conference hallway. Professional curiosity. Your highest-reach platform.

- **First sentence must stop a thumb.** ~140 characters to land above the "See more" fold. What goes in that sentence is a creative decision. The only test: would someone tap "See more"?
- **Wit before information.** The hook leads with punch. The stat or source comes after the fold.
- 5-8 sentences total, 500-900 characters (research shows 800-1,000 optimal)
- After the fold: support, context, or a second wit beat. New information, not repetition.
- Link in first comment silently (no "link in comments" language)
- **Shareability check:** Would a reader forward this to a colleague? If not, sharpen the hook.
- **Dwell time check:** Is there enough substance after "See more" to hold someone for 30+ seconds?

### Step 2: LinkedIn Carousel (When Applicable)

For articles with frameworks, step-by-step insights, data, or strong visual structure.

- Generate 6-8 slide outline (title + one key point per slide)
- Large, readable text. One idea per slide.
- Carousels get 2-3x more dwell time (15-20 seconds vs 8-10 for text)
- Average 1,387 impressions vs 589 for text-only
- Upload as PDF. User creates the actual PDF from the slide outline.
- **Not every article needs a carousel.** Only offer when the content has clear slide-worthy structure.

### Step 3: Adapt for LinkedIn Company Page

Company voice, "we" perspective. Space 3-7 days after personal post.

- **Present the article, don't retell it.** Followers see both profiles. If the company post repeats the same stats and data, it reads as a duplicate. The personal post tells the story. The company post takes a position on the topic and frames the article.
- State what the company thinks, not what the study found. Let the article carry the data.
- Company page reaches ~5% of followers vs personal's 20-30%
- Use this for content that establishes company authority, not individual perspective

### Step 4: Adapt for Instagram

The gallery opening. Design for DM shares.

- **DM sends are the #1 algorithm signal** (3-5x weight of likes, 50% more than saves)
- Create content someone would forward to a colleague via DM
- Hero image required. Consider carousel (up to 10 slides) for framework-style articles.
- **Keyword-rich caption.** Instagram is a search engine now. Use terms your audience searches for ("AI automation for small business"), not hashtags.
- 3-5 niche hashtags max. No hashtag-stuffing.
- No "link in bio" CTA (suppresses reach)
- Use Stories with Link Sticker for traffic
- End on the image, not a verbal close

### Step 5: Adapt for X/Twitter

The bar argument. Sharp and committed. **Only if Premium subscription is active.**

- Distill to the sharpest, most provocative take from the article
- Text-only. No links in main tweet (severe reach penalty, zero engagement for non-Premium)
- Add link in reply only (just the URL, no preamble)
- Commit to the take. No hedging. The room respects conviction.
- **The real X strategy is engagement, not posting.** Spend more time replying to others than posting. Replies weighted 13.5-75x more than likes.

### Step 6: Adapt for Facebook (Optional)

The block party. Warm and familiar. **Consider Group posting over Page posting.**

- Page organic reach is 1.65%. Groups consistently outperform Pages.
- If posting to Page: include hero image (text-only gets deprioritized), link in first comment
- If posting to Group: more conversational, community-oriented framing
- Reels see 67% more reach (15-30 seconds optimal) but require video content
- A slightly warmer, more relatable tone fits this room

**Why this order works:** LinkedIn personal profile has the highest organic reach for B2B (20-30% of network). Writing for your best-performing platform first produces the strongest version. Adapting outward preserves quality while fitting each room.
