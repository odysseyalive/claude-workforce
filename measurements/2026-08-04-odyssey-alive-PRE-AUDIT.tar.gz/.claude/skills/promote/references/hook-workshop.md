# Hook Workshop

**This step is mandatory before drafting any posts.** The article's own wit is the primary source material for hooks. Do not default to personal confession or earnest vulnerability.

### Step 1: Mine the Article

Read the source article and extract:
- **Wit beats** — Lines that use understated absurdity, quiet escalation, rhetorical undercuts, Trojan observations, or self-implicating humor. These are the lines that make you smirk or wince when you read them.
- **The sharpest image or metaphor** — The single visual or comparison that carries the most weight.
- **The most surprising fact** — The stat or detail that would stop a thumb.

List these explicitly before proceeding. If the article has no wit beats, the Hook Workshop creates them using the techniques from `satirical-wit.md`. But most articles already have the raw material.

### Step 2: Generate Candidate Hooks

Write 3-5 candidate hooks for the LinkedIn Personal post. Each must:
- Use a **different** satirical-wit technique (understated absurdity, quiet escalation, self-implicating "we", Trojan observation, rhetorical undercut, compassionate absurdist)
- Land in 1-2 sentences, under ~140 characters for the first sentence
- Draw from the article's own wit beats when possible, adapting for social brevity

**Do NOT label the techniques in the output.** Present the hooks as options, not a taxonomy exercise.

### Step 3: Present Candidates

Show the candidate hooks to Francis. He picks one (or asks for more). The selected hook becomes the foundation for the LinkedIn Personal post, and the remaining platforms adapt from there.

**Anti-pattern: earnest confession as hook.** "I spent years doing X. Now I do Y." is vulnerability, not wit. Self-implication means standing *inside the absurdity* — "We keep buying the thing before we've figured out what the last thing does." The humor is the vehicle. If the hook could appear in a sincere LinkedIn post about personal growth, it's not wit-first.
