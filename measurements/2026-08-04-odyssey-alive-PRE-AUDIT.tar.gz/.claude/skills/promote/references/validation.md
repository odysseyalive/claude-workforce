# Validation (Two-Stage)

**Stage 1: Social Validator** (platform mechanics)
```
Agent tool: "Read .claude/skills/promote/agents/social-validator/AGENT.md for instructions,
        then validate these social media posts: [posts]. Return PASS or ISSUES FOUND."
```

**When Stage 1 returns ISSUES FOUND:**
1. Re-read voice guidelines, social-writing, social-coherence, and satirical-wit to re-ground in voice before revising.
2. Rewrite the failing posts from scratch against the one-viral-point and wit-first directives. Do not patch — patching produces differently-bad posts.
3. Re-run Stage 1 on the rewritten posts.
4. Proceed to Stage 2 only when Stage 1 passes.

**Optional: Humor Workshop** (connective wit)

After Stage 1 passes, offer the humor workshop before proceeding to Stage 2. **Grounding:** [humor-workshop.md](humor-workshop.md) — offer phrasing, accept/decline branches.

**Stage 2: Content Finishing Chain** (AI-tell detection)

Run per `.claude/skills/text-eval/references/finishing-chain.md`. Content type: **social post**.
