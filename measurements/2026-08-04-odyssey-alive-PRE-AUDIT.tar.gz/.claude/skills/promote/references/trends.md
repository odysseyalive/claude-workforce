# Trend Pulse: Platform Trend Sources

## Purpose

Fetch current social media engagement trends before writing posts. Use trend data to inform hook structure and topic framing — never to override voice or generate content directly.

## Fetch Order

Fetch the source for the platform you're writing for. If writing for all platforms, fetch in this order:

1. **LinkedIn** — Taplio (primary, always fetch first)
2. **X/Twitter** — Trends24
3. **Instagram** — Later.com Reels Trends
4. **Facebook** — Turrboo

If any fetch fails, skip that platform's trend input and proceed. Trends are supplementary context, not a dependency.

---

## LinkedIn: Taplio

**URL:** `https://taplio.com/trending`

**How to fetch:**
```
Use Jina read_url tool with URL: https://taplio.com/trending
```

**What you get:**
- Trending topics with category labels (AI, Financial, Brand, Email, etc.)
- Example viral posts with actual engagement counts (likes, comments)
- Post text showing what structures are performing

**How to parse:**
1. Scan the returned content for topic categories
2. Identify 2-3 categories relevant to the article's subject matter
3. Note the high-engagement posts — look for patterns in:
   - Hook style (question, observation, contrast, story opener)
   - Post length (short punch vs. medium narrative)
   - Structure (single idea vs. list vs. thread)
   - Engagement ratio (likes-to-comments indicates discussion value)

**Room context:** LinkedIn is the conference hallway. People came ready to listen. Trends here lean professional curiosity — insights, observations, lessons. Filter for hooks that sound like a smart person thinking out loud, not a marketer announcing.

---

## X/Twitter: Trends24

**URL:** `https://trends24.in/`

**How to fetch:**
```
Use Jina read_url tool with URL: https://trends24.in/
```

**What you get:**
- Live trending topics and hashtags across 400+ global locations
- Hourly trend breakdowns showing momentum
- Trend duration showing what sustains vs. what spikes and dies

**How to parse:**
1. Scan for trending topics relevant to the article's subject
2. Note which topics have sustained presence (hours, not minutes) — these indicate real conversation, not just news spikes
3. Look for adjacent trends that could serve as entry points for the article's core idea
4. Ignore celebrity/entertainment trends unless the article genuinely connects

**Room context:** X is the argument at the bar. The room is smaller now and respects conviction. Trends here move fast and reward sharp takes. Use trending topics as conversation entry points, not as content to react to generically.

**Supplementary sources (one-time reads, not recurring fetches):**
- **Buffer's 1M tweet analysis** (`buffer.com/resources/best-time-to-post-on-twitter-x`) — Text posts get 30% more engagement than video on X. Best posting time: 9am Wednesday. Confirms text-first strategy.
- **TianPan.co algorithm breakdown** (`tianpan.co/blog/2025-09-15-twitter-s-recommendation-algorithm`) — Exact engagement scoring weights. Retweets weighted "Very High," replies "High," bookmarks "Medium." Early engagement matters disproportionately due to logarithmic scaling.

---

## Instagram: Later.com Reels Trends

**URL:** `https://later.com/blog/instagram-reels-trends`

**How to fetch:**
```
Use Jina read_url tool with URL: https://later.com/blog/instagram-reels-trends
```

**What you get:**
- Weekly updated trending Reels formats and editing styles
- Associated trending audio/music for each format
- Post counts per trend (ranging from dozens to 800K+)
- Monthly roundups with tactical descriptions

**How to parse:**
1. Scan for trending formats that could carry the article's core idea visually
2. Note which audio tracks are gaining momentum — relevant for Stories with Link Sticker
3. Identify format patterns (before/after, day-in-the-life, trio format) that fit the article's narrative
4. Check post counts to distinguish established trends from emerging ones

**Room context:** Instagram is the gallery opening. Visual storytelling is the entire point. Trend data here informs *visual format choices* more than text hooks. A trending Reel format or audio track is the Instagram equivalent of a LinkedIn hook — it's what stops the scroll.

**Supplementary sources:**
- **Social Insider benchmarks** (`socialinsider.io/social-media-benchmarks/instagram`) — Engagement rates from 31M posts: Reels 2.08%, Carousels 1.7%, Images 1.17%. Confirms Reels-first strategy.
- **Metricool** (`metricool.com/how-to-find-current-instagram-reels-trends`) — Monthly trending hashtags and songs. Useful if Later.com fetch fails.
- **Hootsuite Social Trends 2026** (`hootsuite.com/research/social-trends`) — Cultural macro-trends (chaos culture, cozy vibes, nostalgia) that explain why certain aesthetics resonate. Strategic context, not tactical.

---

## Facebook: Turrboo

**URL:** `https://turrboo.com/blog/facebook-trends`

**How to fetch:**
```
Use Jina read_url tool with URL: https://turrboo.com/blog/facebook-trends
```

**What you get:**
- Trending content formats with examples (meme reels, local humor, photo dumps, text skits, life hacks)
- Hashtag trends
- Engagement tactics and content hooks that are performing

**How to parse:**
1. Scan for format trends relevant to the article's subject
2. Note which content types are getting algorithmic favor (Reels see 67% more reach than static posts)
3. Look for engagement patterns — Facebook rewards comments and shares more than likes
4. Identify if the article's topic connects to any community-driven trends

**Room context:** Facebook is the neighborhood block party. The crowd skews older, values authenticity, and responds to warmth over polish. Trends here are more community-driven and less centrally trackable than other platforms. Use trend data loosely — Facebook success comes from feeling local and relatable, not from riding viral formats.

**Supplementary sources:**
- **Async/Podcastle** (`async.com/blog/facebook-trends`) — 20+ specific trending formats with how-to breakdowns. More detailed format catalog.
- **Social Media Examiner** (`socialmediaexaminer.com/facebook-content-strategy-2025-whats-actually-working-right-now`) — Algorithm context explaining which content types are currently favored and why.
- **Ramdam** (`ramd.am/blog/trends-meta`) — Bi-weekly Meta trend updates with specific audio recommendations. Covers both Facebook and Instagram.

---

## How Trends Inform Posts

### DO
- Notice which hook styles are getting traction and consider similar structures
- Identify trending topic angles that naturally connect to the article's subject
- Observe post lengths and formats that are performing — adjust within voice constraints
- Note conversation-starting patterns (posts with high comment ratios)
- Use platform-specific trend data for platform-specific posts (Instagram trends inform Instagram posts, not LinkedIn posts)

### DON'T
- Copy trending post structures verbatim
- Force a trending topic into an unrelated article
- Sacrifice voice authenticity for trend alignment
- Add trending hashtags or engagement bait
- Let trends override the 4-5 sentence LinkedIn constraint
- Treat trend data as prescriptive — it's observational input only
- Apply one platform's trends to another platform's post

## Voice Protection

Trend data enters the workflow at the same level as the article read — it's input context. The voice and writing skills remain the authority on how posts sound. If a trending pattern conflicts with voice guidelines, voice wins.
