# Platform Technical Data

## Visual Media by Platform

**Every post should include a visual recommendation.** The watercolor hero images are a brand differentiator. Use them, but adapt presentation to the room.

**LinkedIn:**
- Default: Include the hero image as-is. The watercolor style stands out against stock photos and AI slop.
- The image draws the eye; the text does the thinking. No text overlays needed.

**X/Twitter:**
- Default: Text-only. No image in the main tweet.
- Exception: If the article's visual is striking enough to stop a scroll, include it. But text-only usually performs better here.

**Facebook:**
- Default: Include the hero image. Text-only posts get deprioritized by the algorithm.
- Consider a text overlay with one line from the hook if the image alone doesn't convey the topic. Keep it clean, not cluttered.
- If the article lends itself to short-form video or a Reel (67% more reach), suggest that as an option.

**Instagram:**
- Default: Hero image required. This is the gallery. No image, no post.
- Consider a square crop (1:1) for feed presence or a carousel (up to 10 slides) if the article has multiple inline images.
- Stories with Link Sticker are the traffic driver. Suggest a Story version using the hero image with minimal text overlay.
- The caption supports the image. If the image doesn't carry the post on its own, it's the wrong image.

**General rule:** Always state which visual approach you recommend and why. Don't just attach the hero image silently.

## Platform Technical Notes (February 2026)

**LinkedIn:**

- Links in main post get ~60% less reach. Put link in first comment silently (no announcement).
- Never say "link in comments" or any variation.
- **"See more" truncation at ~140-210 characters** (device-dependent, mobile truncates earlier). The first sentence must land subject + wit above this fold. — *Sources: Supergrow, Digital Blacksmiths, LigoSocial (2025)*
- **Optimal post length: 800-1,000 characters** (AuthoredUp, 3M+ posts) to **1,200-1,800 characters** (Digital Blacksmiths). For Francis's dense, punchy voice: **500-900 characters, 5-8 sentences** (see post-templates.md for canonical length target). — *Sources: AuthoredUp, van der Blom Algorithm InSights 2025 (1.8M posts), Stefan Buss (March 2026)*
- **Saves are the #1 engagement signal in 2026.** One save drives ~5x more reach than a like, ~2x more than a comment. Saves reward reference-value content. — *Source: van der Blom Algorithm InSights 2025, Stefan Buss (March 2026)*
- **Dwell time is the #2 hidden ranking signal.** Posts with 61+ seconds dwell time: 15.6% engagement. Under 3 seconds: 1.2%. Sweet spot: 31-60 seconds.
- **Document carousels get 2-3x more dwell time** than text or images. Average 1,387 impressions vs 589 for text-only.
- **Personal profiles reach 20-30% of network.** Company pages reach ~5% of followers (down 60-66% since 2024).
- **Reply to comments within 15 minutes** for a 90% algorithmic boost.
- **The Golden Hour:** Most reach is determined in the first 60-90 minutes after posting.
- LinkedIn generates 80% of all B2B social media leads. 277% more leads than Facebook and Twitter combined.

**X/Twitter:**

- **Premium is required.** Free accounts: <100 impressions/post. Premium ($8/mo): ~600. Premium+ ($16/mo): ~1,550.
- Since March 2026, non-Premium accounts posting links see zero median engagement.
- X announced link penalty removal October 2025, but data still shows massive disparity.
- Text-only tweets with link in reply is the only viable strategy.
- **Algorithm weights:** Replies that get author engagement +75x, direct replies +13.5x, profile engagement +12x, 2+ min dwell time +10x, likes +1x.
- **Spend 70% engaging, 30% creating.** Reply to larger accounts in your space. Reply engagement is the primary growth lever.
- Avoid spam patterns: rapid follow/unfollow, repeated content, >3 hashtags trigger visibility filtering.

**Facebook:**

- **Page organic reach: 1.65%** and declining. Groups consistently outperform Pages.
- Group posts rank higher in Feed due to "meaningful interaction" signals.
- Reels see 67% more reach than regular posts. 15-30 seconds optimal (45% higher engagement than longer).
- **Meta's UTIS model (Jan 2026):** Surveys users about Reel relevance. Saves and shares are the most powerful signals.
- Same-day Reels get 50% more distribution than older content.
- Consider creating a niche Group (e.g., "AI for Small Business") rather than posting to Page.

**Instagram:**

- **DM shares (sends) are the #1 algorithm signal.** 3-5x more weight than likes. 50% more weight than saves.
- **Sends per reach** is the most powerful signal for reaching new audiences.
- Instagram is now a search engine. Keyword-rich captions get 30% more reach than hashtag-heavy posts.
- Carousels: 10.15% engagement. Single images: 7%. Reels: 6% (but better for discovery).
- Carousels get a "second chance" — if someone scrolls past, Instagram may reshow starting from slide 2.
- 3-5 niche hashtags max combined with keyword-rich captions. More than 5 may reduce reach.
- "Link in bio" CTAs suppress reach.
- Use Stories with Link Sticker for traffic.

## Algorithm Signal Weights by Platform

| Platform | Top Signal | 2nd Signal | 3rd Signal |
|----------|-----------|------------|------------|
| **LinkedIn** | Saves (5x likes, 2x comments) | Dwell time (31-60 sec sweet spot) | Meaningful comments (15+ words, within 15 min) |
| **X/Twitter** | Reply chains (+75x) | Direct replies (+13.5x) | Dwell time 2+ min (+10x) |
| **Instagram** | DM sends (3-5x likes) | Watch time | Likes per reach |
| **Facebook** | Saves and shares | Watch time / completion rate | Community engagement (Groups) |

## Posting Frequency

- **Personal Profile:** 3-5 posts per week (LinkedIn is the priority)
- **Company Page:** 1-2 posts per week (adaptations of personal content)
- **X/Twitter:** 1x/day posting max, 3-5x/day engagement (replies, quote tweets)
- **Instagram:** 2-3 posts per week, daily Stories
- **Facebook:** 1-2 per week if using Groups, skip Page-only posting
- **Dual Posts:** Never same day. Space by 3-7 days minimum.
