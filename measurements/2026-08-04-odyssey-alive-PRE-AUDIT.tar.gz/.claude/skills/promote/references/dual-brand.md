# Dual-Brand Strategy

## Strategy Table

| Destination | Strategic Goal | Perspective |
|-------------|---------------|-------------|
| **Personal Profile** | Build thought leadership | First-person singular ("I") |
| **Company Page** | Build company credibility | First-person plural ("We") |

## Routing Decisions

**Post on PERSONAL Profile if:** Content is primarily about unique perspective, speculative/experimental, establishes YOU as individual expert.

**Post on COMPANY Page if:** Content demonstrates company expertise, case study/client result, establishes the COMPANY as authority.

**Post on BOTH (with adaptations) if:** Core insight is valuable to both audiences. **RULE:** Never identical text. **TIMING:** Space by 3-7 days minimum. Personal first, company later.

**Personal profile is the priority.** Personal profiles reach 20-30% of their network vs company pages reaching 5% of followers. Company page content should be reposts or adaptations of personal content, not original posts.

**The company page presents, it doesn't retell.** Many followers see both the personal profile and the company page. If the company post repeats the same data points (stats, study details, specific facts), it reads as a duplicate, not a second perspective. The personal post tells the story. The company post takes a position on it. Frame the article, state what the company thinks about the topic, and let the article do the rest. Don't rehash the data the reader already saw.

**LinkedIn Carousel Option:** For articles with strong data contrasts, stat-by-stat narratives, or frameworks that build slide by slide, generate an uploadable carousel PDF. Carousels get 2-3x more dwell time and ~1,387 avg impressions vs 589 for text posts. See [carousel.md](carousel.md) for when to offer and how to build.

## Platform Personality

Every platform is a room at a party. The message adapts to the room, not just the character limit. Use these identities to shape tone, not just format.

| Platform | The Room | What Works Here |
|----------|----------|-----------------|
| **LinkedIn** | The conference hallway | Professional curiosity. People came ready to listen. Ideas that might help. Grounded observations over announcements. |
| **X/Twitter** | The argument at the bar | Sharp, fast, committed takes. No hedging. The room is smaller now, so every word earns its place. |
| **Facebook** | The neighborhood block party | Familiar, warm, slightly nostalgic. Local and relatable beats polished. The crowd skews older and values authenticity. |
| **Instagram** | The gallery opening | Visual storytelling is the entire point. Words support the image, not the other way around. Aesthetic presence matters as much as the idea. |

**When writing for each platform, inhabit the room.** A conference hallway observation doesn't work at the gallery opening. A gallery caption doesn't work at the bar. Same core insight, different conversational energy.
