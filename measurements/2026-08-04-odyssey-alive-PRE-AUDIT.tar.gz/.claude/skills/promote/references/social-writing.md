# Social Writing Directives

Five rules extracted from the full writing protocol that apply to short-form social posts. For long-form article writing, use `/writing` instead.

> **No em-dashes.** Use periods or commas instead. Em-dashes are an AI tell.

> **No colons for emphasis or setup.** "The result: a seamless experience" is a constructed move. Use a period and a new sentence. Mechanical colons (lists, timestamps) are fine.

> **One sentence, one job.** Don't front-load timeline, platform, action, and context into one sentence. Let each sentence do one thing. But "one job" doesn't mean "one fact." A sentence can connect two ideas with "but," "and," or "now" when they flow as one thought. Fragment-stacking (fact-period-fact-period-fact-period) reads like bullet points, not speech. If the sentence sounds like someone talking, it's doing one job even if it carries two ideas.

> **Don't strip the texture words.** "Other," "too," "also," "actually," "just" are how people talk. They're texture, not filler.

> **Never compact voice to fit length.** When a post is too long, cut a whole idea, not the rhythm. Reduce scope, not voice.
