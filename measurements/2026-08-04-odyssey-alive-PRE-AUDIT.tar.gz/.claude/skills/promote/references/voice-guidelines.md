# Social Voice Guidelines

## The Voice Carries Through

- **First-person presence.** Use "I" naturally. "I've been thinking about..." not "This article explores..."
- **Transparent thinking.** Show the thought process. "This got me thinking..."
- **Invite, don't explain.** Create curiosity gaps. Don't summarize conclusions.
- **Texture and specificity.** Concrete details, not abstractions.
- **Wit without performance.** Sharp observations, not LinkedIn-speak.
- **No em-dashes.** Use periods or commas instead. (See [social-writing.md](social-writing.md) for all mechanical rules.)
- **First sentence carries the weight.** LinkedIn truncates at ~140-210 characters. The first sentence must land above the fold. If someone reads only that sentence, they should know the topic AND want to tap "See more."
- **The hook must have punch.** The before/after examples in `satirical-wit.md` show what punch looks like. If the hook reads like a report setup, a news brief, or something a PR department wrote, it's flat. Rewrite until it makes someone smirk, wince, or feel implicated. Don't taxonomize it.
- **Approachable complexity.** Make difficult concepts accessible through everyday grounding. "Three layers deep with no breadcrumbs" beats "recursive self-orchestration with context compression."
- **Metaphors must work.** If a metaphor doesn't do conceptual heavy-lifting, cut it. The mechanic metaphor illuminates; "digital matryoshka dolls" just sounds clever.
- **Self-aware wryness.** "Yes, I suppose I have a gripe" is the right energy for closing. Invites without announcing.
- **The post sells one idea, not the article.** If someone reads only the post and never clicks, the post succeeded. The article is a bonus. Pick the single most interesting, shareable, or provocative insight. Let the rest go.

## The Test

Read it aloud. Does it sound like a curious person thinking out loud, or a marketing department announcing content?

## What to Avoid

- Generic business voice ("We're excited to share...")
- Declarative announcements ("AI designed a bracket that was 40% lighter")
- Explaining what the reader will learn
- Hashtag-stuffing or engagement-bait questions
- Any phrase that could appear in a press release
- **Decorative metaphors** that sound clever but don't do conceptual work (e.g., "digital matryoshka dolls")
- **Heady technical jargon** — ground difficult concepts in everyday experience
- **Performative hedging** before critique ("The benchmark numbers are impressive, but...")
- **"Link in comments"** or any variation (see [post-templates.md](post-templates.md) for link placement rules)
- **Long LinkedIn essays** (see [post-templates.md](post-templates.md) for length targets)
- **Report-style hooks** — "X organization spent Y time studying Z" is a news brief, not a social post. The hook must have punch, not just information.
