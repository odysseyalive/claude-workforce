# Engagement & Shareability

## Shareability Design

**The #1 algorithm signal across platforms is now some form of sharing.** On Instagram it's DM sends. On Facebook it's shares and saves. On LinkedIn it's dwell time and comments. On X it's reply chains.

Every post should pass this test: **"Would someone forward this to a colleague or friend?"**

**Content patterns that get shared:**
- Counterintuitive observations ("The companies best at AI adoption are the ones that almost didn't try")
- Frameworks people can use immediately
- "I didn't know that" moments with specific data
- Wry observations that make someone think "this is exactly what I've been saying"

**Content patterns that DON'T get shared:**
- Announcements ("We published a new article")
- Generic insights ("AI is changing everything")
- Self-promotion without value
- Content that requires reading the article to understand the post

**The post must be valuable on its own.** The article link is a bonus for people who want more, not a dependency.

## LinkedIn Carousel Format

**When to offer a carousel:** Articles with frameworks, step-by-step processes, data comparisons, checklists, or strong conceptual structure. Not every article needs one.

**Carousel slide outline format:**

```
Slide 1: Hook / Title
[Article title or provocative reframing of the core insight]

Slide 2: The Problem
[One sentence describing the tension or gap]

Slides 3-6: Key Insights (one per slide)
[Each slide: bold headline + 1-2 supporting sentences]

Slide 7: The Takeaway
[One grounded observation that sticks]

Slide 8: CTA (subtle)
[Curiosity-driven close, e.g., "The full story is in the comments." or just your name/brand]
```

**Design notes for the user:**
- Large, readable text (minimum 24pt equivalent)
- One idea per slide. If it needs two ideas, make two slides.
- Use brand colors (cream background, coral accents)
- Watercolor hero image on slide 1 if it works at the smaller size
- Upload as PDF to LinkedIn

**Performance data:** Carousels average 1,387 impressions, 15-20 seconds dwell time. Text-only: 589 impressions, 8-10 seconds. The dwell time difference is what drives algorithmic distribution.

## Engagement Workflow

**Pre-post engagement (15 minutes before posting):**

| Platform | What to do |
|----------|-----------|
| **LinkedIn** | Comment substantively on 3-5 posts in AI/consulting space. Not "Great post!" but genuine thoughts. |
| **X/Twitter** | Reply to 3-5 threads from accounts in your space. Add value, don't just agree. |
| **Instagram** | Like and comment on 5-10 posts from accounts in your niche. Engage with Stories. |
| **Facebook** | Comment in relevant Groups. Share a useful observation in a discussion thread. |

**Post-post engagement (within 15 minutes of posting):**

| Platform | What to do |
|----------|-----------|
| **LinkedIn** | Reply to every comment. Ask follow-up questions. The algorithm measures this. |
| **X/Twitter** | Reply to your own tweet with the link. Engage with anyone who responds. Quote-tweet relevant conversations. |
| **Instagram** | Reply to every comment. Engage with Stories from people who engaged with your post. |
| **Facebook** | Reply to comments. If in a Group, continue the conversation. |

**Why this matters:** Algorithms reward active participants, not broadcasters. Engaging before posting warms the algorithm to your account. Engaging after posting triggers distribution boosts. This is not optional.
