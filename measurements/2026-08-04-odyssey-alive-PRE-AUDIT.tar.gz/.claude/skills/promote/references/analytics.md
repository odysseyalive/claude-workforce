# Analytics & API Integration

## Overview

This document tracks API integration options for pulling social media performance data and site analytics. The goal: understand what's working, stop guessing, and inform future content strategy.

## API Feasibility by Platform

### Tier 1: Meta APIs (Instagram + Facebook) — DO THIS FIRST

**Cost:** Free
**Approval:** 2-7 days (single approval covers both platforms)
**Data available:**
- Per-post: views, reach, saves, shares, likes, comments
- Reels: plays, reach, shares, saves
- Stories: exits, impressions, reach, replies
- Account-level: audience size, reach, follower demographics

**Requirements:**
- Instagram Business or Creator account (free to switch)
- Connected Facebook Page
- Meta Developer App with approved permissions
- Permissions needed: `instagram_basic`, `instagram_manage_insights`, `pages_show_list`, `pages_read_engagement`, `read_insights`

**Approval process:**
1. Create Meta Developer App at developers.facebook.com
2. Request Advanced Access for insight permissions
3. Submit screencast demonstrating how you use each permission
4. Business Verification may be required (submit business documents)
5. Clear use case: "Track my own business's post performance"

**Important (Nov 2025):** Meta deprecated `page_fans`, `impressions` and legacy metrics. Use `page_media_view` and `post_media_view` instead. Build against API v24.0+.

**Existing MCP servers:**
- `duhlink/instagram-analytics` — Instagram analytics MCP server
- `Social Analytics RapidAPI MCP` — Multi-platform via RapidAPI (paid third-party)

**Status:** Not yet set up. Priority: HIGH.

---

### Tier 2: LinkedIn — USE NATIVE EXPORT

**Cost:** API is custom-priced (not published). Approval takes 3-6 months.
**Recommendation:** Skip direct API. Use LinkedIn's native analytics instead.

**Why direct API is impractical:**
- Requires registered legal entity (LLC, Corp, etc.)
- 3-6 month approval with multiple review rounds
- Custom pricing negotiated with LinkedIn
- Designed for tools companies (Hootsuite, Buffer), not individual businesses
- Must upgrade to Standard tier within 12 months or lose access

**Practical alternatives:**
- **LinkedIn native analytics:** Dashboard shows post impressions, engagement, followers directly
- **CSV export:** Company page admin can export analytics data
- **Buffer/Hootsuite:** If using these tools, their LinkedIn API access gives you analytics exports
- **Manual tracking:** Screenshot or log key metrics weekly. Low-tech but sufficient for a single business.

**Data you can get natively (no API needed):**
- Post impressions and reach (personal and company)
- Engagement rate, clicks, reactions, comments
- Follower demographics and growth
- Content performance comparison

**Status:** Use native dashboard. API not worth pursuing.

---

### Tier 3: X (Twitter) — USE FREE DASHBOARD

**Cost:** $200/month minimum (Basic tier) for meaningful read access
**Recommendation:** Use free analytics.x.com dashboard instead.

**API tier details:**

| Tier | Cost | Analytics Capability |
|------|------|---------------------|
| Free | $0 | Write-only. ~1,500 reads/month. Cannot meaningfully pull analytics. |
| Basic | $200/mo | Per-tweet public + non-public metrics. 30-day window. 10,000 tweet reads. |
| Pro | $5,000/mo | Full analytics. Historical data. 1M tweet reads. |
| Enterprise | $42,000+/mo | Complete data streams. |

**Why API is impractical:**
- $200/month for what you get free on the dashboard
- Non-public metrics (impressions, clicks) limited to 30-day window
- Pay-per-use beta (Nov 2025) could change the economics, but not yet broadly available

**Practical alternative:**
- **analytics.x.com** — Free web dashboard with per-tweet impressions, engagement, clicks
- For a single business tracking its own content, this is sufficient

**Status:** Use free dashboard. API not worth $200/mo for a single account.

---

### Cloudflare API — HIGH PRIORITY

**Cost:** Free (all features available on free plan)
**Setup:** Minutes (API token creation in dashboard)
**Data available:**
- **GraphQL Analytics API:** Page views, requests, bandwidth by URL path, time period, country, browser, device. Query `httpRequestsAdaptiveGroups` and `httpRequests1dGroups` datasets.
- **Web Analytics:** Client-side page views and visitor metrics via JS snippet (free) or automatic setup (proxied domains)
- **Zone settings:** SSL mode, security level, cache settings, development mode, firewall rules, WAF — all manageable via API
- **DNS management:** Full DNS record CRUD, analytics, optimization recommendations
- **Cache management:** Purge all cache, purge by URL, purge by tag
- **Workers/KV/R2/D1:** Full management if using Cloudflare compute/storage

**Authentication:**
- Create API tokens at dash.cloudflare.com/profile/api-tokens
- Scoped permissions (read-only analytics, full zone admin, etc.)
- Use `Authorization: Bearer <token>` header

**Official MCP Server:** `@cloudflare/mcp-server-cloudflare`
- **This is an official Cloudflare-maintained MCP server** on npm
- Install: `npx @cloudflare/mcp-server-cloudflare`
- Capabilities: Analytics retrieval, Workers management, KV/R2/D1 management, DNS, cache purge
- Can be configured in Claude Code's MCP settings

**13 Specialized MCP Servers (May 2025):**
| Server | What it does |
|--------|-------------|
| **DNS Analytics** | DNS performance reports, optimization recommendations |
| **Workers Observability** | Logs, analytics, error traces for Workers |
| **Audit Logs** | Query account audit logs, generate reports |
| **Browser Rendering** | Headless browser, screenshots, markdown conversion |
| **Radar** | Global internet traffic data |
| **AI Gateway** | Inspect AI Gateway logs and model responses |
| **Container** | Sandboxed development environments |
| **CASB** | SaaS security scanning (Zero Trust) |
| **Digital Experience Monitoring** | Performance/availability trends |
| **Documentation** | Developer docs reference |
| **Workers Bindings** | D1, R2, KV management during development |
| **AutoRAG** | RAG query tools |

**GraphQL query examples:**

Top 10 URLs by traffic (last 7 days):
```graphql
{
  viewer {
    zones(filter: { zoneTag: "YOUR_ZONE_ID" }) {
      httpRequestsAdaptiveGroups(
        filter: { datetime_gt: "2026-02-06T00:00:00Z", datetime_lt: "2026-02-13T00:00:00Z" }
        limit: 10
        orderBy: [sum_edgeResponseBytes_DESC]
      ) {
        count
        sum { edgeResponseBytes }
        dimensions { clientRequestPath }
      }
    }
  }
}
```

Daily unique visitors and page views:
```graphql
{
  viewer {
    zones(filter: { zoneTag: "YOUR_ZONE_ID" }) {
      httpRequests1dGroups(
        filter: { date_gt: "2026-02-06", date_lt: "2026-02-13" }
        orderBy: [date_ASC]
      ) {
        sum { requests pageViews bytes }
        uniq { uniques }
        dimensions { date }
      }
    }
  }
}
```

**MCP server setup for Claude Code:**
```json
{
  "mcpServers": {
    "cloudflare-dns-analytics": {
      "url": "https://dns-analytics.mcp.cloudflare.com/sse"
    }
  }
}
```

**Active API token permissions:**
- Zone: Read
- Analytics: Read
- Cache Purge: Edit
- DNS: Edit
- AI Crawl Control: Write
- Bot Management: Edit

**Token stored in:** `.env.local` as `CLOUDFLARE_API_TOKEN`, `CLOUDFLARE_ZONE_ID`, `CLOUDFLARE_ACCOUNT_ID`

**Rate limit:** 1,200 requests per 5 minutes (all plans).

**AI Crawl Control — API settings (Feb 2026):**
- `ai_bots_protection`: `disabled` — no blanket bot blocking
- `crawler_protection`: `enabled` — AI Labyrinth catches malicious scrapers only
- `is_robots_txt_managed`: `false` — no training-crawler blocks injected into robots.txt
- `cf_robots_variant`: `off` — no Content Signals Policy injected
- **Per-crawler block/allow toggles: Dashboard-only.** No REST API. Not used (pro-bot).

**Bot strategy: Fully pro-bot.**
Every bot is welcome — training, search, assistant, whatever comes next.
Bots that train on content → models cite content → drives traffic.
The wildcard `User-agent: * Allow: /` in robots.txt is the auto-adjust
mechanism. New bot technologies get full access without a code change.
No blocklist. No training-crawler blocks. Only `/api/`, `/_next/`, and
`/lore-keepers/` are excluded (internal paths, not bot-specific).

AI Labyrinth stays active to catch genuinely malicious scrapers (DDoS,
credential stuffing) — that's security, not bot policy.

**Practical use cases for Odyssey Alive:**
1. **Track article performance:** Query page views per focus article URL (`/focus/*` paths)
2. **Cache purge on deploy:** `POST /zones/:zone_id/purge_cache` after builds
3. **Development mode toggle:** `PATCH /zones/:zone_id/settings/development_mode` (3-hour bypass)
4. **Security monitoring:** Check threats, adjust security level
5. **DNS management:** Programmatic record updates as infrastructure evolves
6. **Bot management:** Toggle AI Labyrinth, managed robots.txt, blanket bot protection

**Note:** REST analytics endpoints are being deprecated. Migrate to GraphQL by December 1, 2026.

**Status:** Integrated. Token active. Analytics verified. Bot defense configured.

---

## Integration Strategy

### Phase 1: Manual Baseline (Now)
- Log key metrics weekly from native dashboards (LinkedIn, X, Instagram, Facebook)
- Track: impressions, engagement rate, saves/shares, link clicks
- Use a simple spreadsheet to identify what content types perform best

### Phase 2: Meta API Integration (Next)
- Set up Meta Developer App
- Get Instagram + Facebook insights permissions approved
- Build or configure MCP server for pulling analytics into Claude Code
- Automate weekly performance reports

### Phase 3: Performance-Informed Promotion (Future)
- Feed analytics data back into the promote skill
- Before writing new posts, review what performed well and why
- Adjust content format, hook style, and platform emphasis based on data
- Track engagement over time to measure the impact of strategy changes

## MCP Server Options

| Server | Platforms | Type | Notes |
|--------|-----------|------|-------|
| **duhlink/instagram-analytics** | Instagram | Official API | Direct integration, free |
| **Social Analytics RapidAPI** | LinkedIn, FB, IG | Third-party | Paid via RapidAPI |
| **social-cli-mcp** | Twitter, Reddit, LI, IG | Posting | No analytics |
| **Xpoz MCP** | Twitter, IG, TikTok | Read/query | Some analytics |
