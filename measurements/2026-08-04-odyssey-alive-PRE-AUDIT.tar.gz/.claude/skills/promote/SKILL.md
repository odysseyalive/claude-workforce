---
name: promote
description: Create social media posts to promote focus articles. Master skill that chains to /voice, /writing, and /text-eval.
allowed-tools: Read, Glob, Grep, Write, Bash, WebSearch, Skill, Task
minimum-effort-level: xhigh
strictness: standard
---

# Social Media Promotion Workflow

**This is a master skill.** For newsletter creation, use `/newsletter` instead. For LinkedIn-only promotion with VP-of-Engineering audience lock, use `/linkedin-promote` (or invoke this skill with `--linkedin-only [slug]`, which delegates entirely to `/linkedin-promote`).

## LinkedIn Personal — delegated to /linkedin-promote

The LinkedIn Personal Profile post is the highest-leverage output of this workflow. As of 2026-04-25, that drafting is delegated to `/linkedin-promote`, which adds VP-of-Engineering audience lock, practitioner-vulnerability register selection, and a concrete organic posting plan on top of this skill's directive infrastructure.

**Two invocation modes:**

- **Cross-platform (default):** `/promote [slug]` — produces LinkedIn Personal (via `/linkedin-promote`) + LinkedIn Carousel + LinkedIn Company + Instagram + X + Facebook adaptations. The LinkedIn Personal step calls `/linkedin-promote` internally and uses its output as the canonical version, then adapts to the other platforms from there.
- **LinkedIn-only:** `/promote --linkedin-only [slug]` — short-circuits to `/linkedin-promote [slug]` and skips cross-platform adaptation entirely. Same output as invoking `/linkedin-promote` directly.

`/linkedin-promote` inherits all directives in this file (wit-first, shareability, name-drop, message-lands) — they run at validation time. It does not duplicate them.

## Skill Chaining

**Grounding:** [references/chain.md](references/chain.md) — full chain order (voice → writing references → satirical-wit → hook workshop → validation), including the optional Trend Pulse insertion point.

---

## Hook Workshop

**This step is mandatory before drafting any posts.** The article's own wit is the primary source material for hooks. Do not default to personal confession or earnest vulnerability.

**Grounding:** [references/hook-workshop.md](references/hook-workshop.md) — Step 1 (Mine the Article), Step 2 (Generate Candidate Hooks), Step 3 (Present Candidates), and the earnest-confession anti-pattern.

---

<!-- origin: user | added: 2026-03-23 | immutable: true -->
## Directives

> **No hedging before critique.** Commit to the observation.
> **LinkedIn personal profile first, always.** Personal profiles get 7-8% engagement vs 1-2% for company pages. Write personal first, adapt outward.
> **Design for shareability.** Every post must pass the "would someone forward this to a colleague?" test. DM shares are the #1 signal on Instagram (3-5x weight of likes) and saves/shares are the top signals on Facebook and LinkedIn.
> **X requires Premium.** Without Premium ($8/mo), posts get <100 impressions. Do not invest time writing X content without a Premium subscription.
> **Instagram uses keywords, not hashtags.** Write keyword-rich captions optimized for search. 3-5 niche hashtags max. No hashtag-stuffing.
> **Engagement is part of the workflow, not optional.** Every promote session includes pre-post and post-post engagement steps. Posting without engaging is broadcasting into a void.
> **Never tell the audience where the link is.** Put the article link in the first comment silently. Never write "link in comments," "link in bio," "check the comments," or any variant. The post sells the idea; the link is discoverable, not announced.

*— Enforced via hook: `hooks/no-link-in-comments.sh` (blocks Write)*

> **The hook is 1-2 sentences, max. It delivers the wit before the fold. No buildup, no setup, no throat-clearing. If the hook needs a third sentence to land, the first two aren't sharp enough.**
> **One viral point per post.** Pick the single most shareable insight from the article. Everything else supports that one point. If you're trying to fit more than one stat, you're summarizing, not promoting. If a reader can't say what the post was about in one sentence, it tried to do too much.
> **Wit-first hooks.** The hook leads with punch, not information. The fact can come after the fold. If the first sentence reads like a news brief, a report setup, or a PR statement, rewrite it until it makes someone smirk, wince, or feel implicated. The data supports the wit. The wit does not support the data.
> **When natural, name drop — cite a recognizable name or stat from the article.** Posts with recognizable industry names drove higher engagement on LinkedIn. But the name drop serves the post, not the other way around. If including it disrupts the hook or forces an information-first opening, skip it. A post with punch and no name drop outperforms a post with a name drop and no punch.
> **Always make sure the post is clear and the message lands — not ambiguous or cryptic.** Curiosity gaps are good. Ambiguity is not. The post does not need to summarize the article. It needs to make one point clearly enough that a reader gets it without clicking. This applies to all posts, no matter what platform or how small.

*— Added 2026-03-23, source: user instruction (inline, LinkedIn engagement data)*

> **Every post must read as connected prose, not a list of facts with periods.** If sentences can be reordered without losing meaning, the post is broken. Grounding: `references/social-coherence.md`.

*— Added 2026-03-23, source: user feedback on "No Brakes" promotion where posts were disjointed data stacks*

For em-dash, length, and cross-platform rules, see [references/post-templates.md](references/post-templates.md).
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Design for shareability. Every post must pass the 'would someone forward this to a colleague?' test. DM shares are the #1 signal on Instagram (3-5x weight of likes) and saves/shares are the top signals on Facebook and LinkedIn." -->
CHECKPOINT — Shareability Gate:
1. For each post draft, name the specific type of colleague a reader would forward this TO (e.g., "a peer who just hired their first AI role", "a friend wrestling with the same vendor decision", "a manager who keeps defending outdated process").
2. IF the forward recipient can only be described in generic terms ("anyone in tech", "people who care about AI", "professionals") → STOP. The post lacks a specific hook. Rewrite until a specific reader-and-recipient pair is obvious.
3. Apply the forward test as a hypothetical: would the recipient feel this was sent TO them (gift, implication, argument they're having, thing they've been trying to explain), or would it feel generic? IF the test fails → STOP and rewrite.
4. Scan for share-friction patterns: promotional tone ("Exciting to share...", "Proud to announce"), lecture stance ("Here's what you need to know..."), or first-person hero framing ("I did X and the results were..."). These reduce forwardability. IF present → STOP and rewrite with observation/implication framing instead.
5. IF the post names a specific recipient, passes the forward test, and avoids share-friction patterns → CONTINUE to the next directive gate.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "When natural, name drop — cite a recognizable name or stat from the article. Posts with recognizable industry names drove higher engagement on LinkedIn. But the name drop serves the post, not the other way around. If including it disrupts the hook or forces an information-first opening, skip it. A post with punch and no name drop outperforms a post with a name drop and no punch." -->
CHECKPOINT — Name-Drop Fit Gate:
1. For each post draft, scan the source article for recognizable names or stats: household-recognizable company names, publicly-known people, widely-cited statistics.
2. IF the article contains at least one recognizable name/stat AND the current post has no name drop → draft an alternate version that incorporates the name naturally.
3. For EACH name-drop candidate version, compare to the wit-first draft against these tests: (a) does the hook still land in 1-2 sentences, (b) does the first sentence still punch (smirk/wince/implication), (c) does the name appear after the punch rather than leading with information.
4. IF the name-drop version fails test (a) or (b) → discard the name-drop version. Use the original wit-first version. Never include a name drop that forces an information-first opening.
5. IF the name-drop version passes all three tests → use it.
6. IF the article contains no recognizable names/stats → proceed with the wit-first draft unchanged. Do NOT invent recognizability.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Always make sure the post is clear and the message lands — not ambiguous or cryptic. Curiosity gaps are good. Ambiguity is not. The post does not need to summarize the article. It needs to make one point clearly enough that a reader gets it without clicking. This applies to all posts, no matter what platform or how small." -->
CHECKPOINT — Message-Lands Gate:
1. For each post draft, state in one sentence what point the reader should get from this post alone (without clicking through to the article).
2. Re-read the post as a fresh reader. IF the one-point statement from step 1 cannot be recovered from the post text alone → STOP and revise.
3. Distinguish curiosity gap from ambiguity: a curiosity gap is a specific claim with withheld detail (e.g., "The thing that broke the process was the thing everyone was proud of"). Ambiguity is a vague reference without a claim (e.g., "Sometimes things aren't what they seem"). IF the post uses ambiguity rather than a curiosity gap → STOP and rewrite around a specific claim.
4. IF the post tries to convey more than one distinct point → STOP. Pick the sharpest and cut the rest; multi-point posts fail the lands test.
5. IF a reader cannot paraphrase the post's point in one sentence after reading once → STOP and revise.
6. IF the post conveys exactly one specific claim AND uses curiosity gaps (not ambiguity) AND a cold reader can paraphrase the point → CONTINUE to Stage 1 validator.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Wit-first hooks. The hook leads with punch, not information. The fact can come after the fold. If the first sentence reads like a news brief, a report setup, or a PR statement, rewrite it until it makes someone smirk, wince, or feel implicated. The data supports the wit. The wit does not support the data." -->
CHECKPOINT — Wit-First Hook Gate:
1. For each post draft, extract the first sentence as the hook.
2. Classify the hook against these FAIL patterns:
   a. Opens with a statistic or data point presented flatly ("X% of companies...", "Studies show...", "New research reveals...")
   b. Opens with an announcement frame ("I recently wrote about...", "Here's why...", "Today, I want to talk about...")
   c. Opens with a report-setup phrase ("It's become clear that...", "We're living in a world where...", "The reality is...")
   d. Opens with a PR-voice phrase ("Exciting news...", "Proud to share...", "Pleased to announce...")
3. IF the hook matches any FAIL pattern → STOP. Rewrite the hook using one of the satirical-wit techniques (understated absurdity, quiet escalation, rhetorical undercut, Trojan observation, self-implicating "we", compassionate absurdist).
4. IF the hook lands on a stat or information before it has produced a smirk/wince/implication response in the reader → STOP. Reorder so the punch comes first and the data follows after the fold.
5. Apply the reader reaction test: Would a reader plausibly react with a smirk, wince, or "that's me" recognition within the first sentence? IF NO → STOP and rewrite.
6. IF the hook passes all three checks (no FAIL pattern, punch before data, reader reaction test passes) → CONTINUE to Stage 1 validator.
<!-- END ENFORCEMENT ANNOTATION -->

---

## Workflow

<!-- MODEL-LANE-GATE START — auto-generated by /skill-builder route embed; safe to replace -->
<!-- origin: skill-builder | modifiable: true -->
## Model-Lane Preflight

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: /skill-builder route embed (model-lane gate, slim form per the 2026-06-06 2-Brain Harness directive: gates are slimmed, never stripped — this block is the lane checkpoint that travels with the skill through EVERY entry path, including hand-run invocations, which are always permitted. It goes silent when /route already covered the endeavor. Advisory-only per the 2026-06-06 No-Switch-Prompt directive: the gate CANNOT switch the model and NEVER asks the user to — its entire output is one advisory line, which names the exact remedy informationally per the 2026-06-11 named-command advisory directive. -->
CHECKPOINT — Model-Lane Preflight Gate (slim, advisory-only; fires at the TOP of this skill's workflow, before any generative step):
1. SKIP silently IF ANY of: `/route` dispatched this invocation after running its own lane preflight (a lane advisory OR ask already printed, route otherwise ASSESSED the lane this turn, or it was deliberately suppressed — route's coverage extends to the whole endeavor whether route asked, matched, or the user declined, including skills this one chains); this skill's frontmatter sets `model-lane-gate: off`; the session is headless / non-interactive; this gate is executing inside a subagent (a subagent is already model-pinned via its own frontmatter); OR an advisory for this LANE already printed this endeavor AND the active model is unchanged (advise at most once per (lane, active-model) pair per endeavor).
2. Resolve this skill's lane (own `lane:` frontmatter → the Skill→Lane table in `.claude/skills/skill-builder/references/model-lanes.md` → NO LANE) and the lane's Preferred Model. IF no lane resolves OR the preferred-model cell is empty → silent no-op (correctly absent, not a gap). IF this skill declares per-function lanes AND the invocation's resolved mode has its own row → that function's lane governs; otherwise the skill-level lane covers all modes.
3. Read ACTIVE_MODEL from the session system-context line "The exact model ID is …" (strip `[1m]`/`[200k]`, lowercase — model-lanes.md § Active-Model Detection; never an env var or Bash probe). IF the Preferred Model is malformed or names a clearly superseded family → emit the one-line stale-mapping advisory and proceed; never advise from a stale mapping, never validate against a hardcoded list.
4. Compare. Match → silent no-op. Mismatch → print ONE advisory line and PROCEED: "Lane advisory: this skill declares the `<lane>` lane (preferred `<preferred>`); the active model is `<active>` — to align, run `/model <preferred>` and re-invoke; proceeding as-is." Naming the command is INFORMATIONAL (named-command advisory directive, 2026-06-11): NEVER an AskUserQuestion, never a blocking wait (No-Switch-Prompt directive, 2026-06-06). A skill can NEVER switch the session model and never asks the user to.
5. Primary-lane scope. This gate fires ONCE per invocation, for the resolved PRIMARY lane. Cross-lane mid-workflow steps never re-advise — they delegate via this skill's LANE-AGENT-EMBED Delegation Map when present (see .claude/skills/skill-builder/references/lane-delegation.md). Delegation is never a substitute for THIS gate: analytical primary work runs on the analytical main model — never a creative main session orchestrating analytical-pinned agents to dodge the lane.
<!-- END ENFORCEMENT ANNOTATION -->
<!-- /origin -->
<!-- MODEL-LANE-GATE END -->



**Creation order:** LinkedIn Personal (via `/linkedin-promote`) → LinkedIn Carousel (when applicable) → LinkedIn Company → Instagram → X/Twitter → Facebook.

**Step 1 (LinkedIn Personal) is delegated.** Invoke `/linkedin-promote [slug]` and use its output as the canonical LinkedIn Personal post. Do not draft a parallel version. Subsequent platform adaptations (Carousel, Company, IG, X, FB) start from the LinkedIn Personal output and adapt the voice, length, and structure per platform.

If the user invoked `/promote --linkedin-only [slug]`, stop after Step 1 and return the `/linkedin-promote` output unchanged.

**Grounding (read before writing):**
- [references/voice-guidelines.md](references/voice-guidelines.md) — Social voice rules, anti-patterns, examples
- [references/post-templates.md](references/post-templates.md) — Per-platform structure, length targets, examples
- [references/dual-brand.md](references/dual-brand.md) — Personal vs. company routing, pronoun rules
- [references/platform-data.md](references/platform-data.md) — Image recommendations, algorithm signals
- [references/engagement.md](references/engagement.md) — Pre/post engagement steps (non-negotiable)
- [references/carousel.md](references/carousel.md) — When to offer, how to build

---

## Validation

**Grounding:** [references/validation.md](references/validation.md) — Stage 1 (Social Validator agent), Stage 1 failure recovery (rewrite-don't-patch rule), optional Humor Workshop, and Stage 2 (Content Finishing Chain).

---

## Post-Action Capture

After creating promotional content, if engagement patterns emerge (hook performance, platform-specific results, audience response patterns), suggest recording in the awareness ledger (PAT record). Never auto-record — ask the user first.

---

## Revision Phase

When the user requests changes to any social post after presentation:
1. Invoke `/edit` in chained mode with content type `social-post`.
2. `/edit` applies the change with social writing context loaded, runs the edit-validator.
3. Re-present the modified post(s).

---


---

<!-- ROUTE-EMBED START — auto-generated by /skill-builder route embed; safe to replace -->
<!-- origin: skill-builder | modifiable: true -->
## Route Consultation

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: /skill-builder route embed. Closes the dispatch-bypass gap: a /route announcement is not a substitute for a Skill tool call, and consulting /route does not license the caller to execute the target skill's procedure manually. -->
CHECKPOINT — Skill Routing Gate:
1. During this skill's workflow, IF a step requires research, web search, lookup, analysis, or any follow-up NOT already covered by an explicit tool or skill name → STOP before improvising.
2. Already-named exception. IF the current workflow step EXPLICITLY names tools or skills (e.g., "use Read", "spawn the X agent", "invoke /[skill]") → execute as written. Do NOT consult `/route` for steps already determined. Skip to your skill's next step.
3. Otherwise → invoke `/route <task description>` via the Skill tool. `/route` reads its index and either returns a target skill or reports "no match."
4. Dispatch Required. IF `/route` returns a target → the IMMEDIATE next tool call MUST be `Skill(skill=<target>, args=<derived>)`. Do NOT execute the target skill's procedure steps yourself with raw Edit / Write / Bash / Task / Agent / Read calls. The target skill's gates (asset backups, agent panels, exit tests, cascade steps, frontend-design reviews, immutable-directive checks) ONLY fire when its SKILL.md is loaded via Skill — running steps manually silently skips every gate.
5. Bypass detection. IF a Skill dispatch was just announced (yours or `/route`'s) and the next tool call is non-Skill work germane to the routed task → STOP. Print verbatim: "Route dispatch announced but Skill call skipped. Invoking Skill tool now." then issue the Skill call.
6. No-match path. IF `/route` returns "no match" → proceed with the most direct, manual approach. Document the gap; the user may want to register a skill.
7. Follow-ups loop back. After the dispatched skill returns, IF further follow-up is needed → consult `/route` again via Skill. Do not freelance the next step.
8. Auto-mode override clause. Auto-mode ("execute immediately", "prefer action over planning") does NOT override clauses 4–5. Auto-mode chooses WHAT to do; once a routing decision is on the table, the only valid next action is Skill invocation.
<!-- END ENFORCEMENT ANNOTATION -->
<!-- /origin -->
<!-- ROUTE-EMBED END -->
