# Self-Heal History

## 2026-03-13: Facebook post too vague

**Friction:** First Facebook revision replaced storytelling with abstract stats (liability caps, percentages) when fixing cross-platform duplication.
**Verdict:** REASONING_CAUSED — skill instructions were adequate. Voice guidelines already say "texture and specificity over abstractions." Facebook platform guide already says "warm, relatable, authentic."
**Lesson:** When differentiating across platforms, find a different person or angle, don't remove the human element. The fix was Erin Kistler's story instead of Mobley's, not stats instead of story.
**Patch:** None (no skill change needed).

## 2026-03-13: Assumed gender pronouns for named individual

**Friction:** Used she/her pronouns for Erin Kistler based on name and source article language. User corrected to they/them.
**Verdict:** SKILL_CAUSED — no instruction existed in any content-producing skill about pronoun usage for third parties.
**Patch:** APPLIED — Added "Referring to People" section to voice/SKILL.md (between Indigenous Language Integration and The Humility Test). Covers all downstream skills since focus, promote, and newsletter all chain through voice.
