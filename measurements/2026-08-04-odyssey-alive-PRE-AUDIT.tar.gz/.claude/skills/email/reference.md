# Email Reference
<!-- Enforcement: MEDIUM — grounding check in SKILL.md -->

## IMAP Accounts

Both Gmail and iCloud are accessed via IMAPS on port 993 with app-specific passwords loaded from `.env.local`.

| Account | Host | Port | Env vars | Draft folder |
|---------|------|------|----------|--------------|
| Gmail | `imap.gmail.com` | 993 | `GMAIL_EMAIL`, `GMAIL_APP_PASSWORD` | `[Gmail]/Drafts` |
| iCloud | `imap.mail.me.com` | 993 | `ICLOUD_EMAIL`, `ICLOUD_APP_PASSWORD` | `Drafts` |

### Credentials Setup

**Gmail** — Requires 2-Step Verification on the Google account. Generate an app-specific password at https://myaccount.google.com/apppasswords (name it "Claude Code email" or similar). The 16-character password goes in `.env.local`:

```
GMAIL_EMAIL=fmeetze@gmail.com
GMAIL_APP_PASSWORD=<16-char app password>
```

**iCloud** — Generate at Apple ID → Sign-In & Security → App-Specific Passwords. Store in `.env.local`:

```
ICLOUD_EMAIL=<user's icloud address>
ICLOUD_APP_PASSWORD=<app-specific password>
```

### Gmail-Specific Notes

- Special folders use the `[Gmail]/` prefix: `[Gmail]/Drafts`, `[Gmail]/Sent Mail`, `[Gmail]/All Mail`, `[Gmail]/Trash`, `[Gmail]/Spam`.
- `INBOX` is the primary folder and works like a standard IMAP folder.
- Gmail's labels are exposed as folders; messages can appear in multiple label-folders. Use `[Gmail]/All Mail` when you want the whole archive without label filtering.
- Gmail supports standard IMAP SEARCH plus extensions (`X-GM-RAW` for Gmail search syntax, `X-GM-THRID` for thread IDs, `X-GM-LABELS` for labels). Prefer standard SEARCH criteria for portability.

### Shared IMAP Fetch Script Pattern

Parameterize host and credential env vars; same code works for both accounts.

```bash
# Fetch recent unread (last 24h) from one account
HOST="$1"; USER_VAR="$2"; PASS_VAR="$3"
python3 -c "
import imaplib, email, os, datetime
from email.header import decode_header

m = imaplib.IMAP4_SSL('$HOST', 993)
m.login(os.environ['$USER_VAR'], os.environ['$PASS_VAR'])
m.select('INBOX')

since = (datetime.date.today() - datetime.timedelta(days=1)).strftime('%d-%b-%Y')
_, nums = m.search(None, f'(UNSEEN SINCE {since})')

for num in nums[0].split()[:20]:
    _, data = m.fetch(num, '(RFC822.HEADER)')
    msg = email.message_from_bytes(data[0][1])
    subj = decode_header(msg['Subject'])[0][0]
    if isinstance(subj, bytes): subj = subj.decode()
    print(f'{msg[\"From\"]} | {subj} | {msg[\"Date\"]}')

m.logout()
"
```

Invoke per account:

```bash
# Gmail
bash fetch.sh imap.gmail.com GMAIL_EMAIL GMAIL_APP_PASSWORD

# iCloud
bash fetch.sh imap.mail.me.com ICLOUD_EMAIL ICLOUD_APP_PASSWORD
```

### IMAP Search Patterns

| Need | IMAP SEARCH command |
|------|-------------------|
| Unread | `(UNSEEN)` |
| From sender | `(FROM "sender@example.com")` |
| Since date | `(SINCE 01-Apr-2026)` |
| Subject match | `(SUBJECT "keyword")` |
| Combined | `(UNSEEN FROM "client" SINCE 01-Apr-2026)` |
| Gmail-only: raw Gmail query | `(X-GM-RAW "has:attachment newer_than:7d")` |

### Draft Composition via IMAP APPEND

To save a draft without sending, build an RFC 5322 message and APPEND it to the account's Drafts folder:

```python
import imaplib, email.message, time
msg = email.message.EmailMessage()
msg['From'] = os.environ['GMAIL_EMAIL']
msg['To'] = 'recipient@example.com'
msg['Subject'] = 'Draft subject'
msg.set_content('Draft body')

m = imaplib.IMAP4_SSL('imap.gmail.com', 993)
m.login(os.environ['GMAIL_EMAIL'], os.environ['GMAIL_APP_PASSWORD'])
m.append('[Gmail]/Drafts', r'(\Draft)', imaplib.Time2Internaldate(time.time()), msg.as_bytes())
m.logout()
```

Swap the folder name to `Drafts` for iCloud. The user opens their mail client to review and send — this skill never sends directly.

---

## Optional: SMTP (for future direct-send)

The skill does not send mail itself (drafts only). If that changes, SMTP connection details are:

| Account | Host | Port | Security |
|---------|------|------|----------|
| Gmail | `smtp.gmail.com` | 587 | STARTTLS |
| Gmail | `smtp.gmail.com` | 465 | SSL |
| iCloud | `smtp.mail.me.com` | 587 | STARTTLS |

Auth uses the same app-specific password as IMAP.

---

## Security

- Never output app-specific passwords or the contents of `.env.local`
- Never store credentials in skill files — only in `.env.local`
- Draft messages are saved via IMAP APPEND, never auto-sent — user sends manually

---

*Created by skill-builder. Enforcement boundary: grounding.*
