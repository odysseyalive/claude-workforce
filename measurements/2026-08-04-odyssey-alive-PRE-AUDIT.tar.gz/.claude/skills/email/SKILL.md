---
name: email
description: "Email triage and search across Gmail and iCloud. Modes: triage, search, draft. Usage: /email [mode] [args]"
allowed-tools: Read, Grep, Bash, Task
minimum-effort-level: high
strictness: standard
---

# Email

Unified inbox access across Gmail and iCloud, both via IMAP. Supports triage, search, and draft composition.

## Usage

```
/email [mode] [args]
```

### Modes

| Mode | Command | Description |
|------|---------|-------------|
| `triage` | `/email` or `/email triage` | Show recent unread messages ranked by importance |
| `search` | `/email search [query]` | Search across both inboxes |
| `draft` | `/email draft [context]` | Draft a reply or new message |

Default mode is `triage` if not specified.

---

<!-- origin: user | added: 2026-04-03 | immutable: true -->
## Directives

> **Pre-approved operations:** All Gmail MCP calls and iCloud IMAP reads are pre-approved. Do not ask for permission to search, read, or list messages.

> **Natural prose output.** Never present email summaries as bullet lists or tables. Write in natural paragraphs — as if briefing someone over coffee. Lead with what matters most, weave in context, mention sender names naturally.

> **Never output credentials.** iCloud app-specific passwords and any authentication tokens must never appear in output.

*— Added 2026-04-03, source: user instruction*
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Natural prose output. Never present email summaries as bullet lists or tables. Write in natural paragraphs — as if briefing someone over coffee. Lead with what matters most, weave in context, mention sender names naturally." -->
CHECKPOINT — Prose Output Gate:
1. Before emitting the email summary to the user, scan the full draft for formatting patterns.
2. IF any line begins with `- `, `* `, `• `, or numbered-list markers as list items → STOP. Rewrite as connected prose sentences.
3. IF the draft contains Markdown table syntax (`|`, `|---|`) → STOP. Convert rows into sentences.
4. IF the draft uses `## ` or `### ` headers keyed to individual messages or senders → STOP. Remove and merge into paragraphs.
5. IF sender names are absent from the prose (references use "the sender", "a message", etc. without names) → STOP. Rewrite weaving in actual sender names naturally.
6. IF the most urgent or actionable item is not the opening sentence of the first paragraph → STOP. Reorder so the lead matches urgency.
7. IF none of the above conditions triggered → CONTINUE and emit the briefing.
<!-- END ENFORCEMENT ANNOTATION -->

---

<!-- origin: skill-builder | version: 1.0 | modifiable: true -->
## Workflow: Triage

Surface the most important unread messages across both inboxes.

1. **Fetch Gmail** — Run the IMAP fetch script (see [reference.md](reference.md) § "IMAP Accounts") against `imap.gmail.com` using `GMAIL_EMAIL` / `GMAIL_APP_PASSWORD`, IMAP SEARCH `UNSEEN`, max 20 results
2. **Fetch iCloud** — Same IMAP fetch script against `imap.mail.me.com` using `ICLOUD_EMAIL` / `ICLOUD_APP_PASSWORD`, IMAP SEARCH `UNSEEN`, max 20 results
3. **Merge and rank** — Combine results, prioritize by:
   - **Known contacts** (people in org files or prior correspondence) over unknown
   - **Direct messages** over CC/BCC
   - **Action-bearing subjects** (invoice, deadline, urgent, request, review) over informational
   - **Recency** as tiebreaker
4. **Read key messages** — For the top 5-7 most important, fetch full message body to understand context
5. **Present** — Write a natural prose briefing:
   - Lead with the most urgent or actionable item
   - Group related messages into narrative flow
   - Mention sender names, subject context, and what (if anything) needs a response
   - Close with anything that can safely be ignored or batched for later

---

## Workflow: Search

Search across both inboxes for a specific topic, sender, or keyword.

1. **Parse query** — Interpret the user's natural language search intent
2. **Gmail search** — Run IMAP SEARCH against `imap.gmail.com` with the translated criteria (see [reference.md](reference.md) § "IMAP Search Patterns")
3. **iCloud search** — Run IMAP SEARCH against `imap.mail.me.com` with equivalent criteria
4. **Merge results** — Combine, deduplicate (same subject+sender+date), sort by relevance
5. **Present** — Summarize findings in natural prose — what was found, from whom, when, and what the thread context is

---

## Workflow: Draft

Compose or reply to a message.

1. **Context** — If replying, fetch the original thread via IMAP by Message-ID on the relevant account (Gmail: `imap.gmail.com`, iCloud: `imap.mail.me.com`)
2. **Determine account** — Reply from the same account that received the original. For new messages, ask which account to send from.
3. **Compose** — Draft the message following the user's voice (chain to `/voice` and `/writing` if content is substantive)
4. **Present** — Show the draft for review
5. **Send or save** — Save the draft via IMAP APPEND to the account's Drafts folder (Gmail: `[Gmail]/Drafts`, iCloud: `Drafts`). User sends manually from the mail client.

---

## Chaining: Agenda Integration

When called from `/agenda priorities` or `/agenda today`, this skill runs a scoped triage:

1. **Fetch recent** — Last 24-48 hours of email from both inboxes via IMAP (Gmail at `imap.gmail.com`, iCloud at `imap.mail.me.com`)
2. **Match against projects** — Cross-reference sender names and subjects against org file project names
3. **Return context** — Pass back a summary of email activity relevant to active TODO items, noting any urgency signals (e.g., "client asked for update", "deadline moved up", "payment pending")
4. **Flag untracked requests** — Identify direct emails (To: Francis) from project-associated senders that don't match any open TODO headline. These are potential new tasks — flag them with sender, subject, and the org project they relate to.
5. **Surface CC'd threads** — Identify threads where Francis is CC'd (not a direct recipient). Summarize what the conversation is about and which project it relates to. These are situational awareness, not action items.

The agenda skill uses this context to adjust priority ranking, surface new requests, and weave email signals into its prose output.
<!-- /origin -->

---

<!-- origin: skill-builder | version: 1.0 | modifiable: true -->
## Grounding

Before accessing email:
1. Read [reference.md](reference.md) for IMAP host/credential configuration for Gmail and iCloud
2. State: "I will query [ACCOUNT] for [PURPOSE]"

See [reference.md](reference.md) for IMAP hosts, credential env vars, and shared IMAP script pattern.
<!-- /origin -->

---

## Discovered Issues Log

*(none yet)*

---

<!-- ROUTE-EMBED START — auto-generated by /skill-builder route embed; safe to replace -->
<!-- origin: skill-builder | modifiable: true -->
## Route Consultation

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: /skill-builder route embed. Closes the dispatch-bypass gap: a /route announcement is not a substitute for a Skill tool call, and consulting /route does not license the caller to execute the target skill's procedure manually. -->
CHECKPOINT — Skill Routing Gate:
1. During this skill's workflow, IF a step requires research, web search, lookup, analysis, or any follow-up NOT already covered by an explicit tool or skill name → STOP before improvising.
2. Already-named exception. IF the current workflow step EXPLICITLY names tools or skills (e.g., "use Read", "spawn the X agent", "invoke /[skill]") → execute as written. Do NOT consult `/route` for steps already determined. Skip to your skill's next step.
3. Otherwise → invoke `/route <task description>` via the Skill tool. `/route` reads its index and either returns a target skill or reports "no match."
4. Dispatch Required. IF `/route` returns a target → the IMMEDIATE next tool call MUST be `Skill(skill=<target>, args=<derived>)`. Do NOT execute the target skill's procedure steps yourself with raw Edit / Write / Bash / Task / Agent / Read calls. The target skill's gates (asset backups, agent panels, exit tests, cascade steps, frontend-design reviews, immutable-directive checks) ONLY fire when its SKILL.md is loaded via Skill — running steps manually silently skips every gate.
5. Bypass detection. IF a Skill dispatch was just announced (yours or `/route`'s) and the next tool call is non-Skill work germane to the routed task → STOP. Print verbatim: "Route dispatch announced but Skill call skipped. Invoking Skill tool now." then issue the Skill call.
6. No-match path. IF `/route` returns "no match" → proceed with the most direct, manual approach. Document the gap; the user may want to register a skill.
7. Follow-ups loop back. After the dispatched skill returns, IF further follow-up is needed → consult `/route` again via Skill. Do not freelance the next step.
8. Auto-mode override clause. Auto-mode ("execute immediately", "prefer action over planning") does NOT override clauses 4–5. Auto-mode chooses WHAT to do; once a routing decision is on the table, the only valid next action is Skill invocation.
<!-- END ENFORCEMENT ANNOTATION -->
<!-- /origin -->
<!-- ROUTE-EMBED END -->
