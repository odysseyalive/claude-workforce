# Architecture overview

The component's behavior is ground truth. Every user-facing string is gated against it.

```
┌──────────────────────────────────────────────────────────────────┐
│  What the interface actually does (read-only ground truth)         │
│  component source: conditional branches, form/submit handlers,     │
│  server-action outcomes, external integration behavior             │
│  (Mailchimp double opt-in, Turnstile, SMTP), the user flow         │
└──────────────────────────────────────────────────────────────────┘
                                │
            ┌───────────────────┼────────────────────┐
            ▼                   ▼                    ▼
 ┌──────────────────┐  ┌─────────────────┐  ┌──────────────────┐
 │ MDX / page copy  │  │ component-       │  │ emails / CTAs    │
 │ hero text        │  │ embedded strings │  │ form-status      │
 │                  │  │ (.tsx subtitles, │  │ messages         │
 │                  │  │  hints, empty-   │  │                  │
 │                  │  │  states, labels) │  │                  │
 └─────────┬────────┘  └────────┬────────┘  └────────┬─────────┘
           └───────────────────┬┴────────────────────┘
                               ▼
                  interface-claim-auditor (context: none)
                   pass A: claim-vs-behavior
                   pass B: referential/parse ambiguity
                               │
                               ▼
              MUST FIX / SHOULD FIX / CONSIDER verdict
              (caller applies the fix via /edit + /voice + /wit)
```

## Failure modes by location, ranked

1. **Functional instructions / CTAs** ("Subscribe to get Focus in your inbox" when the form runs a double opt-in and the visitor is not subscribed until they confirm) — highest damage. Tells the visitor an action accomplished something it didn't; produces confused replies and dead ends.
2. **Empty-state / hint / form-status copy** — second. Read precisely when the visitor is waiting on an outcome; a false claim here compounds the confusion.
3. **Button / link / aria labels** — third. A label that names an action the control doesn't perform (the "Accept" button that only dismissed a notice).
4. **Service / feature descriptions** — fourth. Overstating what an engagement or automation delivers erodes trust without an immediate dead end.
