# Ground-Truth Model
<!-- Enforcement: HIGH — the four reads + two passes are the executable core of the check/gate/sweep modes and the interface-claim-auditor agent. -->

copy-truth has **no single artifact** for its ground truth — it is *what the component does when it renders and when the visitor acts*, reconstructed from source. Establish it with four reads, then run two comparison passes. This file is the procedure; the `interface-claim-auditor` agent executes it under context isolation.

This site has no login. The actor table that a permissioned app needs (logged-out / member / admin) usually collapses to a **single actor: any visitor**. The truth that bites on this site is therefore rarely *who can do it* and almost always *what the action actually accomplishes* — a form that runs a double opt-in, a button that only dismisses a notice, a CTA that opens an email instead of booking anything. Read 2 builds an outcome table, not an auth table.

---

## Establishing "what the interface actually does" for a string S

### Read 1 — Locate S and its render scope
1. Grep the literal string for its file + line (`rg -n "<text>"`). If invoked with `file:line`, start there.
2. Identify the enclosing component and **which JSX subtree S labels**. Scope matters: a `<HeroHeader>` subtitle describes the *whole page below it*; a `<p>` inside a form's `status === "success"` branch describes *only the post-submit state*; a `<p>` inside an empty-state describes *only the nothing-here case*. A claim true for one scope can be false for another.

### Read 2 — Map the behavior into a capability/outcome table
Enumerate the branches and handlers in that subtree that decide what renders and what an action actually does:
- **State branches:** `status === "idle" | "loading" | "success" | "error"`, empty-states (`if (x.length === 0)`), client guards (cookie-consent gate, Turnstile token present).
- **Form/submit handlers:** what the `onSubmit` / server action in `src/lib/actions` actually does. Trace it one hop: does newsletter signup subscribe immediately, or set Mailchimp `status: "pending"` (double opt-in) and email a confirmation? Does the contact form book a call, or send an email via SMTP?
- **External integration behavior:** Mailchimp pending vs subscribed, SMTP send vs queue, Turnstile pass/fail. This is load-bearing truth the copy often gets wrong.

Output a small **capability/outcome table**. Because there is usually one actor, the truth lives in the *outcome* column:

| Actor | Can do on this surface | What the action actually accomplishes |
|---|---|---|
| any visitor | submit the newsletter form | Mailchimp signup with `status: "pending"`; subscription is NOT active until they confirm from the email |
| any visitor | submit the contact form | sends an email to Francis via SMTP; no call is booked, no instant reply is guaranteed |

### Read 3 — Extract the action claims in S
Tokenize S into:
- **Action claims** — the verbs the copy says the visitor can perform and the outcome it implies ("subscribe", "you're on the list", "book a call", "get an instant quote").
- **Implied subject/outcome** — who the sentence addresses and what state it presupposes results ("Subscribe to get Focus in your inbox" presupposes that submitting *makes you subscribed*).
- **Pro-forms and their candidate antecedents** (hand off to Pass B).

### Read 4 — Collect honest sibling strings
Other strings on the same surface that already describe the flow correctly are corroborating ground truth **and the model for a truthful rewrite**. Example: the newsletter form's own success message, "Check your inbox to confirm your subscription," states the real rule that an over-eager CTA contradicts. The contact form's confirmation copy is the honest sibling for any CTA that overpromises an instant response.

---

## Pass A — claim-vs-behavior
For each action claim in S:
1. Find the capability/outcome-table row(s) that grant it.
2. Determine the **visitor the string is shown to** (from S's render scope, Read 1). On a no-login site this is almost always the generic visitor; the render scope still matters (a string inside the `success` branch is read only by someone who already submitted).
3. Decide:
   - The claim holds for the visitor and the action's real outcome → OK.
   - The claim asserts a capability the visitor does not have, OR an **outcome the action does not produce**, and S does not say so → **MUST FIX** (the copy tells the visitor they did something they didn't).
   - The claim is true but the *path* it implies is wrong (e.g. "book a call" when the button only opens an email form) → **MUST FIX** if it sends the visitor down a dead end, else SHOULD FIX.

Worked example A (newsletter CTA): "Subscribe to get Focus in your inbox." Outcome table: submitting sets Mailchimp `status: "pending"` and emails a confirmation; the visitor is not subscribed until they confirm. The CTA implies the act of submitting subscribes them. Mismatch → **MUST FIX**. Truthful rewrite, grounded in the success-message sibling: name the real step (e.g. "Subscribe, then confirm from your inbox to start getting Focus.").

Worked example B (the cookie banner that motivated this skill): the button labeled "Accept" wrote a localStorage flag and dismissed the notice. The label claims a consent action the control never performed (nothing was gated on it). Label-claim vs control-behavior mismatch → **MUST FIX**. Truthful rewrite, grounded in what the button actually does: "Got it" (acknowledgement, not consent).

## Pass B — referential/parse ambiguity
Apply [ambiguity-patterns.md](ambiguity-patterns.md). Independent of behavior:
- Every pro-form (one / it / them / this / that) must resolve to a **single** noun phrase in S. Two or more candidates → ambiguous.
- Coordination/attachment: does a trailing verb phrase attach to the main verb or a nested one?
- Severity: ambiguous → **SHOULD FIX**; escalate to **MUST FIX** when the competing readings differ in truth value.

---

## Output contract
- Findings in MUST FIX / SHOULD FIX / CONSIDER vocabulary (`.claude/skills/text-eval/references/flag-severity.md`).
- For each finding: the quoted span, which read/pass produced it, and why.
- A single proposed truthful rewrite grounded in the sibling strings — **proposed, never applied**. The caller applies it via `/edit`.

## Scope bound (how far to trace)
Behavior sometimes spans files (a server action's integration call, a component's guard). Cap tracing at **the component plus its directly-referenced handler / server action (one import hop)**. If the truth depends on logic beyond that hop, report it as an open question rather than guessing — do not silently assume.
