# Ambiguity Patterns
<!-- Enforcement: HIGH — Pass B of the ground-truth model; the interface-claim-auditor applies this checklist to every string. -->

Pass B is independent of behavior: a string can be perfectly truthful and still be unparseable on first read. This file is the checklist. It also draws the **functional-claim vs brand-claim** line that keeps the gate from flagging aspirational marketing copy on a site whose whole hero is a value proposition.

---

## 1. Anaphora — every pro-form needs one antecedent

A pro-form (a word standing in for a noun) must resolve to a **single** noun phrase already in the sentence. List the candidates; if more than one fits grammatically, it's ambiguous.

| Pro-form | Check |
|---|---|
| `one` | "and we'll send **one** over" → candidates: the noun(s) introduced earlier. If two count nouns precede it (project, quote), it's ambiguous. |
| `it` / `its` | Resolve to the nearest agreeing singular. Flag if two singulars compete. |
| `them` / `they` | Resolve to a plural antecedent. Flag if the plural is only implied. |
| `this` / `that` | Especially slippery — often refers to a whole clause, not a noun. Flag bare demonstratives with no clear referent. |
| `here` / `there` | Locational pro-forms on a multi-section page. Flag when the place is not named. |

**Worked example.** "Tell us about your project and we'll send a quote or a call plan — pick whichever **one** works." Candidates for *one*: `quote` and `call plan`. Two candidates → ambiguous. If the two readings also imply different next steps for the visitor (a document vs a scheduled call), the ambiguity has functional consequences → escalate **SHOULD FIX → MUST FIX**.

## 2. Attachment / coordination — where does the tail attach?

When a sentence coordinates verb phrases or trails a modifier, check what it attaches to.

- **Coordination scope:** "Subscribe to read Focus **or book** a call." Does "or book" coordinate with "Subscribe" (subscribe OR book) or with "read" (read-Focus OR book-a-call)? Both parse. Flag when the verb's scope is structurally ambiguous and the readings imply different visitor actions.
- **Dangling modifiers:** a trailing clause ("…, before you commit") that could modify more than one preceding element.
- **List terminators:** "X, Y or Z" where Z could be a third list item or a fresh independent clause.

## 3. Severity rules for Pass B
- Ambiguous antecedent or attachment, both readings equally true → **SHOULD FIX** (clarity).
- Ambiguous, and the competing readings **differ in truth value** → **MUST FIX** (one reading is a false claim).
- Mild awkwardness with a single obvious reading → **CONSIDER**.

---

## 4. Functional-claim vs brand-claim (scope gate — read before flagging Pass A)

copy-truth gates **functional claims**, not brand promises. Misapplying it would flag the home-page value proposition as a "lie," which it is not. This matters more on a marketing site than on an app: most of the hero copy here is brand.

A string is a **functional claim** (in scope for Pass A) when it asserts something **falsifiable about what the interface lets the visitor do or what an action accomplishes** — an instruction, a capability, an outcome, a state, a count, a guarantee. Test: *could I open the site, take the action, and find this true or false?*
- "Subscribe to get Focus in your inbox" — functional (I can submit and check whether it subscribes me or runs a double opt-in).
- "Book a free consultation" — functional (does the button book, or send an email?).
- "We reply within one business day" — functional (a checkable guarantee).

A string is a **brand/aspirational claim** (out of scope for Pass A; Pass B still applies) when it expresses a value, mood, mission, or promise that isn't a checkable interface behavior.
- "AI automation that understands how your business actually works" — brand. Not a UI capability; do not flag as claim-vs-behavior.
- "I shadow your team before touching a single API" — brand framing of the approach, not a screen affordance.

**Boundary cases:** a sentence can do both. "Start your automation journey — get in touch" pairs a brand verb ("Start your automation journey") with a functional claim ("get in touch" — checkable: does the control open a contact path?). Split it: gate the functional half, leave the brand half. When genuinely unsure, treat it as brand and report it as a CONSIDER note rather than a MUST FIX — the gate should not litigate marketing tone (that's `/wit` + `/voice`).
