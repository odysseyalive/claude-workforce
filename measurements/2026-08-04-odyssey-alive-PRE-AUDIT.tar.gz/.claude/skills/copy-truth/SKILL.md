---
name: copy-truth
description: "UI-copy truth enforcement for the Odyssey Alive site. The interface's actual behavior is ground truth; copy that claims a capability the screen does not back up is a defect, not a wording preference. Modes: check, audit, sweep, gate. Usage: /copy-truth [mode] [args]"
allowed-tools: Read, Glob, Grep, Task
minimum-effort-level: high
strictness: standard
---

# Copy Truth

The cross-cutting copy-vs-behavior policy for the Odyssey Alive website. Owned by this skill; consumed by `edit` (edit-validator Check 6), `text-eval` (structure-checker), the site-copy authoring gate, and a `copy-truth`-tagged Playwright regression spec.

Every other copy gate on this site checks **form**: `/voice` asks *does it sound like Francis*, `/text-eval` asks *is it free of AI tells*, `/wit` asks *does the humor land*. None ask *is the claim true about what the interface does*. That blind spot shipped the cookie banner whose "Accept" button only wrote a localStorage flag and dismissed the notice (it gated nothing), under a message that said the site collected analytics to improve its content while Google Analytics loaded with no consent at all. The copy read cleanly and passed every voice gate. It was still untrue about what the screen did. This skill makes the **interface's behavior the ground truth** and gates copy against it.

## Usage

```
/copy-truth [mode] [args]
```

| Mode | Effect |
|---|---|
| `check <string \| file:line>` | **Default.** Validate ONE user-facing string against the component/flow it renders in. Reports claim-vs-behavior mismatches and referential/parse ambiguity, each at a severity (MUST FIX / SHOULD FIX / CONSIDER), plus a proposed truthful rewrite grounded in the surface's honest sibling strings. This is what callers invoke. |
| `audit [path-glob]` | Read-only report over a set of files (default: all user-facing copy). Lists findings; proposes nothing to apply. The diagnostic analog of `check`. |
| `sweep` | Whole-site pass that includes component-embedded `.tsx` strings (subtitles, hints, empty-states, form-status messages, button/aria labels), not just MDX. The mode that closes the scope gap between page copy and component copy. Uses a claim heuristic by default (imperatives, capability verbs, pronouns/pro-forms); `sweep --exhaustive` checks every string and fast-PASSes non-claims. |
| `gate <changed-files>` | Thin programmatic entrypoint for callers (edit-validator, the Playwright exit-gate): runs `check` on every user-facing string in a changeset and returns PASS / ISSUES in flag-severity vocabulary. `sweep` is `gate` over the whole site; `audit` is `gate` without a verdict. |

Default mode is `check`.

---

<!-- origin: user | added: 2026-05-27 | immutable: true -->
## Directives

> **The interface's actual behavior is the ground truth. Copy that asserts a capability or outcome the screen does not back up for the visitor it is shown to is a defect, not a wording preference — gate it the way the no-em-dashes hook gates against a character rule.**

*— Added 2026-05-27, source: user — on discovering that copy generated through the full creative pipeline (/voice, /edit, /text-eval) still shipped a cookie banner whose "Accept" button only dismissed a notice and a message that claimed analytics consent the code never gated, because no gate checked copy against what the UI does.*

> **This is a read-only gate. It reports a verdict and may propose a truthful rewrite, but it NEVER writes shipped copy. The fix is applied by the caller through `/edit` (+ `/voice` + `/wit`), so the voice and AI-tell gates still run on the replacement. copy-truth holds no Edit/Write tool.**

*— Added 2026-05-27, source: design — keep the truth gate from becoming a copy-author that bypasses the voice pipeline.*
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "The interface's actual behavior is the ground truth. Copy that asserts a capability or outcome the screen does not back up for the visitor it is shown to is a defect, not a wording preference." -->
CHECKPOINT — Ground-Truth Gate (fires in check / gate / sweep on every user-facing string S):
1. Establish behavior before judging wording. Run the four reads in [references/ground-truth-model.md](references/ground-truth-model.md): locate S and its render scope; map the conditional branches, form/submit handlers, and server-action outcomes into a capability/outcome table; extract S's action claims; collect honest sibling strings on the same surface. Do NOT skip to reading S in isolation — that is the failure this gate exists to prevent.
2. Pass A (claim-vs-behavior): for each action claim in S, find the row in the capability/outcome table that grants it. IF S asserts a capability the visitor does not have, OR an outcome the action does not actually produce (e.g. "subscribe and you're on the list" when the handler triggers a double opt-in that stays pending until confirmed) → emit MUST FIX.
3. Pass B (referential/parse ambiguity): apply [references/ambiguity-patterns.md](references/ambiguity-patterns.md). Each pro-form (one/it/them/this) must resolve to a unique noun phrase; flag attachment/coordination ambiguity. Ambiguous → SHOULD FIX, escalating to MUST FIX when the competing readings differ in truth value.
4. IF S is brand/aspirational copy (not a falsifiable functional claim) per the functional-vs-brand test in ambiguity-patterns.md → do NOT flag it as a claim-vs-behavior defect. Report it as out of scope.
5. Report every finding in MUST FIX / SHOULD FIX / CONSIDER vocabulary (`.claude/skills/text-eval/references/flag-severity.md`) so all callers speak one language. Propose a truthful rewrite, but do not apply it.
<!-- END ENFORCEMENT ANNOTATION -->

---

## Architecture overview

The component's behavior is ground truth; every user-facing string is gated against it. See [references/architecture.md](references/architecture.md) for the data-flow diagram and the ranked failure-modes-by-location list.

---

## Reuse in other skills

- **`edit`**: `edit-validator` runs a conditional Copy-Truth check (Check 6) when the changed passage is interface copy.
- **`text-eval`**: the `structure-checker` agent applies `references/copy-truth.md` when the text under evaluation is interface copy with a known render context; a copy-truth MUST FIX is on the never-demote list of the Human Presence Counterbalance gate.
- **Site authoring + regression**: the `/edit` copy-truth step (Step 4) and edit-validator Check 6 run `/copy-truth check` on each user-facing functional claim before copy is written to a shipped file; the `@copy-truth` Playwright regression (`pnpm test:copy-truth`, `tests/copy-truth/`) backstops it at runtime so a fixed string cannot silently regress. This repo has no `@playwright/test` runner, so the regression is a CommonJS node script driving the system `playwright` library (the `/site-debug` idiom), not a `.spec.ts`.

## Grounding

- [references/ground-truth-model.md](references/ground-truth-model.md) — the four reads (locate, capability/outcome table, claim extraction, sibling check) + the two comparison passes
- [references/ambiguity-patterns.md](references/ambiguity-patterns.md) — anaphora + attachment checklist, and the functional-claim vs brand-claim distinction
- [agents/interface-claim-auditor/AGENT.md](agents/interface-claim-auditor/AGENT.md) — the context-isolated reviewer that owns pass A + pass B

## What this skill does NOT do

- Decide form or server behavior. The components and server actions in `src/lib/actions` own that; copy-truth only asserts the copy matches whatever they actually do.
- Author or reword shipped copy. The truthful rewrite is a proposal; `/edit` + `/voice` + `/wit` apply it so the voice and AI-tell gates still run.
- Check voice, AI tells, or humor. Those are `/voice` / `/text-eval` / `/wit`.
- Flag brand or aspirational marketing copy as a functional defect (see the functional-vs-brand test).

---

<!-- ROUTE-EMBED START — auto-generated by /skill-builder route embed; safe to replace -->
<!-- origin: skill-builder | modifiable: true -->
## Route Consultation

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: /skill-builder route embed. Closes the dispatch-bypass gap: a /route announcement is not a substitute for a Skill tool call, and consulting /route does not license the caller to execute the target skill's procedure manually. -->
CHECKPOINT — Skill Routing Gate:
1. During this skill's workflow, IF a step requires research, web search, lookup, analysis, or any follow-up NOT already covered by an explicit tool or skill name → STOP before improvising.
2. Already-named exception. IF the current workflow step EXPLICITLY names tools or skills (e.g., "use Read", "spawn the X agent", "invoke /[skill]") → execute as written. Do NOT consult `/route` for steps already determined. Skip to your skill's next step.
3. Otherwise → invoke `/route <task description>` via the Skill tool. `/route` reads its index and either returns a target skill or reports "no match."
4. Dispatch Required. IF `/route` returns a target → the IMMEDIATE next tool call MUST be `Skill(skill=<target>, args=<derived>)`. Do NOT execute the target skill's procedure steps yourself with raw Edit / Write / Bash / Task / Agent / Read calls. The target skill's gates (asset backups, agent panels, exit tests, cascade steps, frontend-design reviews, immutable-directive checks) ONLY fire when its SKILL.md is loaded via Skill — running steps manually silently skips every gate.
5. Bypass detection. IF a Skill dispatch was just announced (yours or `/route`'s) and the next tool call is non-Skill work germane to the routed task → STOP. Print verbatim: "Route dispatch announced but Skill call skipped. Invoking Skill tool now." then issue the Skill call.
6. No-match path. IF `/route` returns "no match" → proceed with the most direct, manual approach. Document the gap; the user may want to register a skill.
7. Follow-ups loop back. After the dispatched skill returns, IF further follow-up is needed → consult `/route` again via Skill. Do not freelance the next step.
8. Auto-mode override clause. Auto-mode ("execute immediately", "prefer action over planning") does NOT override clauses 4–5. Auto-mode chooses WHAT to do; once a routing decision is on the table, the only valid next action is Skill invocation.
<!-- END ENFORCEMENT ANNOTATION -->
<!-- /origin -->
<!-- ROUTE-EMBED END -->
