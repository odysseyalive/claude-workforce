# Slack Skill Reference
<!-- Enforcement: LOW — REST integration contract and setup; no hook attached -->

## REST integration

Skill-local, no MCP dependency. One script:

- `scripts/slack-fetch.sh` — the operations (`check`, `channels`, `messages`,
  `review`, `search`). Self-locates `.env.local` (CWD → repo root →
  `~/lab/odyssey-alive`) and discovers **accounts** from it: every
  `SLACK_TOKEN_<label>=xoxp-…` key is one workspace account (labels are
  lowercased; legacy `SLACK_USER_TOKEN` maps to label `default`). Every command
  sweeps all accounts unless `--account <label>` narrows it, and every output
  row carries its `account` label. Caches the authed user ID and the workspace
  user directory per account, locally (gitignored).

| Command | Returns / does |
|---------|----------------|
| `slack-fetch.sh check` | `auth.test` result — workspace, authed user, user ID; refreshes the user-directory cache |
| `slack-fetch.sh channels` | Conversations the user is a member of (`users.conversations`): id, name, type |
| `slack-fetch.sh messages --target <name\|id> [--since ISO8601] [--limit N]` | History for one channel/group/DM (`conversations.history`), names resolved |
| `slack-fetch.sh review [--since ISO8601 \| --days N]` | Aggregate digest: `{window_since, channels_scanned, mentions, dms}` — mentions of the authed user across member channels + all DM/group-DM activity in the window, all accounts |
| `slack-fetch.sh search --q "<query>"` | `search.messages` results (full Slack search syntax) |

Output is one JSON document per call (Slack API responses reshaped to a compact,
name-resolved form). All operations are read-only — the token needs no write
scopes and the script contains no posting code.

## Setup — adding a Slack account (exact steps)

This is the canonical walkthrough, linked from the Slack block in `.env.local`.
Battle-tested 2026-07-13 on the Tickettomato workspace — the gotchas below are
ones actually hit during that setup.

The skill needs a **Slack USER token** (`xoxp-…`) from a private Slack app
installed to each workspace you want swept. A *user* token (not a bot token) is
required so the integration sees the same channels and DMs Francis sees — a bot
token only sees channels the bot was invited to, which defeats a correspondence
sweep.

Slack tokens are **per-workspace**: repeat these steps once for every account
(workspace), giving each its own `SLACK_TOKEN_<label>` line in `.env.local`.

1. **Signed into the target workspace**, go to **https://api.slack.com/apps** →
   **Create New App** → *From scratch*. Name it something like
   `agenda-triage-reader`, pick the workspace.

   > ⚠ **Wrong-dialog trap:** if you see a modal titled **"Generate an
   > app-level token"** offering scopes like `connections:write` /
   > `authorizations:read` / `app_configurations:write`, that is the WRONG
   > token (an `xapp-…` Socket Mode token — it cannot read messages). Cancel
   > it. The token we need lives on the **OAuth & Permissions** page, next
   > step.

2. In the app's left sidebar: **OAuth & Permissions** → scroll to **Scopes**.
   There are TWO lists — use **User Token Scopes** (the lower one), NOT Bot
   Token Scopes. Click **Add an OAuth Scope** and add all ten:
   - `channels:read`, `channels:history` — public channels
   - `groups:read`, `groups:history` — private channels
   - `im:read`, `im:history` — DMs
   - `mpim:read`, `mpim:history` — group DMs
   - `users:read` — resolve user IDs to names
   - `search:read` — the `search` mode
3. Scroll to the top of that same page → **Install to Workspace** → authorize.
   (If the workspace restricts apps this reads "Request to Install" and an
   admin must approve.)
4. Copy the token labeled **User OAuth Token** — it starts `xoxp-`. Ignore any
   Bot User OAuth Token (`xoxb-`). Add a line to `.env.local` at the repo root
   (never anywhere else — per the skill's immutable directive, all connection
   info lives in `.env.local`, never in skill files). Pick a short label per
   workspace:

```
SLACK_TOKEN_TICKETTOMATO=xoxp-...
SLACK_TOKEN_CLIENTX=xoxp-...
```

   Labels are lowercased by the script (`--account tickettomato`). The legacy
   single-account key `SLACK_USER_TOKEN` also works, as account `default`.
   Placeholder values (anything not starting with `xox`) are skipped with a
   stderr warning — an unconfigured placeholder line never breaks a sweep or
   a triage run.

5. Verify auth:

```bash
bash .claude/skills/slack/scripts/slack-fetch.sh check
```

   Every configured workspace should print with its authed user. Then run a
   real sweep and confirm messages come back:

```bash
bash .claude/skills/slack/scripts/slack-fetch.sh review --days 3
```

6. **Wire triage routing.** Slack signals route to projects by matching the
   sender's real name against `:ALIASES:` in
   `.claude/skills/agenda/references/account-index.org`. Add the names of the
   people in this workspace to the right project block (e.g. `"Matt Lindell"`
   → `tickettomato`). Unmapped senders aren't lost — they land in the triage
   unknown-contacts report — but aliased senders route automatically.

> ⚠ **Added a scope after installing?** It does nothing until you click
> **Reinstall to Workspace** (Slack shows a yellow banner on the OAuth page).
> The old token keeps working but WITHOUT the new scope — `missing_scope`
> errors after adding scopes mean the reinstall step was skipped. After
> reinstall, re-check the User OAuth Token value; it usually stays the same,
> but if it changed, update `.env.local`.

> **Free-plan workspaces:** history API access is limited to what the plan
> retains (~90 days on free plans) — fine for triage windows measured in days.

### Adding another account later (quick checklist)

1. api.slack.com/apps (signed into that workspace) → new app *From scratch*
2. OAuth & Permissions → **User Token Scopes** → add the ten scopes above
3. Install to Workspace → copy the **`xoxp-`** User OAuth Token
4. New `SLACK_TOKEN_<LABEL>=xoxp-…` line in `.env.local`
5. `bash .claude/skills/slack/scripts/slack-fetch.sh check`
6. Add that workspace's people to `:ALIASES:` in agenda's `account-index.org`

## API endpoints used

Base: `https://slack.com/api/` — all GET/POST form-encoded, `Authorization: Bearer` header.

- `auth.test` — token probe; yields the authed `user_id`
- `users.list` — user directory (id → real name), cached
- `users.conversations` — conversations the user is a member of (paginated, `types=public_channel,private_channel,mpim,im`)
- `conversations.history` — messages in one conversation (`oldest=<unix ts>`)
- `search.messages` — workspace search (user tokens only)

Slack timestamps are unix-epoch strings (`"1720900000.123456"`); the script
converts `--since` ISO8601 → epoch and renders `ts_iso` back out.

## /agenda triage consumption contract

`/agenda triage` (and the `today`/`priorities` update-pass) consumes Slack the
same way it consumes Quo — by running the fetch script directly during signal
gathering:

```bash
bash .claude/skills/slack/scripts/slack-fetch.sh review --since <window-start-ISO8601>
```

- `mentions[]` and `dms[]` are the signal stream: each item has `account`,
  `channel`, `from`, `ts_iso`, `text`, `channel_type`. The sweep covers every
  configured account in one call.
- Signals route to projects via the account-routing index (`/agenda index`) —
  Slack identities map by the sender's real name / email where the index has
  them; unmapped senders land in the triage unmapped report, same as email/Quo.
- The wiring itself (signals.md, integrations.md, triage-workflow.md rows in
  `/agenda`) is applied on the agenda side; this section only fixes the
  contract so that wiring has a stable interface.

## Local state (gitignored, never committed)

Per account label:

- `.slack-id-cache-<label>` — authed user ID from `auth.test`
- `.slack-users-cache-<label>` — user directory (id → name), refreshed by `check` or when >7 days old

Delete either cache to force re-resolution. The token itself is NEVER cached —
it is read from `.env.local` on every run.
