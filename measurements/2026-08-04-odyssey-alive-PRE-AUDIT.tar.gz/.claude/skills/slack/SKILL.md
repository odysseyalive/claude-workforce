---
name: slack
description: "Slack correspondence source — read recent mentions, DMs, and channel messages via a skill-local REST integration; feeds /agenda triage. Modes: review, messages, search, check. Usage: /slack [mode] [args]"
allowed-tools: Read, Glob, Grep, Bash
minimum-effort-level: high
---

# Slack

Read Francis's Slack workspace via a skill-local REST integration (no MCP
dependency) — recent mentions, direct messages, and channel history — and
surface what needs a reply. This is a correspondence *source* skill in the same
family as `/email` and `/quo`: `/agenda triage` consumes its output as one more
signal stream. Read-only: this skill never posts, edits, or deletes anything on
Slack.

## Usage

```
/slack [mode] [args]
```

### Modes

| Mode | Command | Description |
|------|---------|-------------|
| `review` | `/slack review [--since ISO8601 \| --days N] [--account <label>]` | Sweep recent mentions + DMs across ALL configured workspace accounts, ranked by what needs a reply (default window: 48h). The Slack analogue of `/quo review`; also the digest `/agenda triage` consumes |
| `messages` | `/slack messages <channel-or-person> [--since ISO8601] [--account <label>]` | Recent history for one channel, group, or DM conversation |
| `search` | `/slack search "<query>" [--account <label>]` | Search messages across the workspace(s) (Slack search syntax supported) |
| `check` | `/slack check` | Probe auth on every configured account: verifies each token, prints workspace + user identity, refreshes the user-directory caches |

Default mode is `review` if not specified.

---

<!-- origin: user | added: 2026-07-13 | immutable: true -->
## Directives

> **"I have a really useful skill called agenda triage that pulls in quite a few correspondence points to keep my tasks up-to-date. I'd like to add slack to the mix. Can you walk me through getting what I need from slack and helping me bake that into the agenda triage?"**

*— Added 2026-07-13, source: user (skill creation request, via /route → /skill-builder intent router)*

> **"just make sure that the needed info for connection is in .env.local and not baked into the skill intself."**

*— Added 2026-07-13, source: user (mid-creation instruction). All connection material — the Slack tokens and any workspace-specific values — lives in `.env.local` at the repo root, never in skill files or scripts. Scripts read it at runtime; skill files may name the env KEYS but never their values.*

> **"keep in mind. I'll have multiple acounts I'm pulling in data for."**

*— Added 2026-07-13, source: user (mid-creation instruction). The skill is multi-account by design: every `SLACK_TOKEN_<label>` key in `.env.local` is one workspace account; all modes sweep every account unless `--account <label>` narrows the run, and every message in the output carries its `account` label.*
<!-- /origin -->

---

<!-- origin: skill-builder | version: 1.0 | modifiable: true -->
## Workflow

All operations run through `scripts/slack-fetch.sh`, which self-locates
`.env.local` (CWD → repo root → `~/lab/odyssey-alive`) and discovers accounts
from it: every `SLACK_TOKEN_<label>=xoxp-…` key is one workspace account
(legacy `SLACK_USER_TOKEN` maps to the label `default`). All modes sweep every
account; `--account <label>` narrows to one. No credential ever appears in
skill files, script defaults, or output. If the script errors with a
missing-credential message, route the user to [reference.md](reference.md)
§ Setup.

### Preflight (first run / auth doubt)

```bash
bash scripts/slack-fetch.sh check
```

Verifies the token (`auth.test`), prints the workspace and authed user, and
refreshes the user-directory cache used to render names. On `invalid_auth` or
`missing .env.local` → reference.md § Setup.

### review — needs-reply sweep (default; consumed by /agenda triage)

1. Resolve the window: `--since <ISO8601>` or `--days N` (default 2 days).
2. Run:

```bash
bash scripts/slack-fetch.sh review --since "2026-07-11T00:00:00-07:00"
```

3. The script returns one JSON document: `{window_since, channels_scanned,
   mentions: [...], dms: [...]}` — each message carries `account`, `channel`,
   `channel_type`, `from` (real name), `ts_iso`, `text`.
4. Present a digest ranked by what needs a reply: direct questions and asks
   first, FYI/ambient mentions after. Group by conversation. Never dump raw
   JSON at the user.
5. **Never output credentials or secrets.** Slack messages can contain tokens,
   passwords, and connection strings pasted by teammates — quote only the
   headline ask, not credential-shaped content.

### messages — one conversation

```bash
bash scripts/slack-fetch.sh messages --target "general" --since "2026-07-06T00:00:00-07:00"
bash scripts/slack-fetch.sh messages --target "Jane Doe"      # DM by person name
```

`--target` accepts a channel name, channel ID, or a person's name (resolved to
their DM via the user-directory cache). Summarize the thread chronologically.

### search — workspace search

```bash
bash scripts/slack-fetch.sh search --q "invoice from:@jane after:2026-07-01"
```

Passes the query to Slack's `search.messages` (full Slack search syntax works).
Report matches with conversation, author, date.

### Error handling

- `missing .env.local` / `SLACK_USER_TOKEN not set` → reference.md § Setup.
- `invalid_auth` / `token_revoked` → the token was rotated or revoked; re-mint
  per reference.md § Setup and update `.env.local`.
- `missing_scope` → the app lacks a required user-token scope; the error names
  the scope — add it per reference.md § Setup step 3 and reinstall the app.
- Any other `{"ok":false,"error":...}` Slack response is passed through — read
  `.error` and report it.
<!-- /origin -->

---

<!-- origin: skill-builder | version: 1.0 | modifiable: true -->
## Grounding

Before running any operation, read [reference.md](reference.md) for the env
keys, required token scopes, script contract, and the `/agenda triage`
consumption contract. State: "I will use [VALUE] for [PURPOSE], found under
[SECTION]".

See [reference.md](reference.md) for setup and the REST integration contract.
<!-- /origin -->
