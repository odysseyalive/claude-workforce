#!/usr/bin/env bash
# Slack REST integration for the /slack skill. READ-ONLY — no posting code.
#
# Multi-account: every SLACK_TOKEN_<label>=xoxp-... line in .env.local is one
# workspace account; all commands sweep every account unless --account <label>
# narrows it. Legacy single-token key SLACK_USER_TOKEN maps to label "default".
# Tokens live ONLY in .env.local (immutable skill directive) — never cached,
# never printed, never baked into this script.
#
# Usage:
#   slack-fetch.sh check
#   slack-fetch.sh channels [--account <label>]
#   slack-fetch.sh messages --target <channel-name|channel-id|person-name> [--account <label>] [--since <ISO8601>] [--limit N]
#   slack-fetch.sh review   [--since <ISO8601> | --days N] [--account <label>]
#   slack-fetch.sh search   --q "<query>" [--account <label>]
#
# Output: one JSON document per call.

set -euo pipefail

API="https://slack.com/api"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_DIR="$(dirname "$SCRIPT_DIR")"
USERS_CACHE_MAX_AGE_DAYS=7

die() { echo "ERROR: $*" >&2; exit 1; }

command -v jq >/dev/null 2>&1 || die "jq is required"
command -v curl >/dev/null 2>&1 || die "curl is required"

# ---------------------------------------------------------------- env / tokens
load_env() {
  local candidate found=""
  for candidate in \
    "$PWD/.env.local" \
    "$(git -C "$PWD" rev-parse --show-toplevel 2>/dev/null || true)/.env.local" \
    "$HOME/lab/odyssey-alive/.env.local"
  do
    if [[ -n "$candidate" && -f "$candidate" ]]; then
      # shellcheck disable=SC1090
      set -a; source "$candidate"; set +a
      found="$candidate"
      break
    fi
  done
  [[ -n "$found" ]] || die "missing .env.local (looked in CWD, repo root, ~/lab/odyssey-alive) — see reference.md § Setup"

  ACCOUNT_LABELS=()
  local var label value
  while IFS= read -r var; do
    label="${var#SLACK_TOKEN_}"
    label="$(tr '[:upper:]' '[:lower:]' <<<"$label")"
    value="${!var}"
    if [[ "$value" != xox* ]]; then
      # Placeholder or malformed (real Slack tokens start with xox) — skip silently
      # so unconfigured accounts never break a sweep or a triage run.
      echo "WARN: skipping account '$label' — token is a placeholder (does not start with xox)" >&2
      continue
    fi
    ACCOUNT_LABELS+=("$label")
    eval "TOKEN_${label}=\"\${$var}\""
  done < <(compgen -A variable | grep '^SLACK_TOKEN_' || true)

  if [[ -n "${SLACK_USER_TOKEN:-}" && "$SLACK_USER_TOKEN" == xox* ]]; then
    ACCOUNT_LABELS+=("default")
    TOKEN_default="$SLACK_USER_TOKEN"
  fi

  [[ ${#ACCOUNT_LABELS[@]} -gt 0 ]] || die "no usable SLACK_TOKEN_<label> (or SLACK_USER_TOKEN) in .env.local — placeholders still unset? see reference.md § Setup"
}

token_for() { local v="TOKEN_$1"; printf '%s' "${!v}"; }

# Narrow ACCOUNT_LABELS by --account.
filter_accounts() {
  local want="$1" l ok=""
  [[ -z "$want" ]] && return 0
  want="$(tr '[:upper:]' '[:lower:]' <<<"$want")"
  for l in "${ACCOUNT_LABELS[@]}"; do [[ "$l" == "$want" ]] && ok="yes"; done
  [[ -n "$ok" ]] || die "unknown account '$want' (known: ${ACCOUNT_LABELS[*]})"
  ACCOUNT_LABELS=("$want")
}

# ---------------------------------------------------------------- API helpers
# api <label> <method> [--data-urlencode k=v ...]   (GET; Slack methods are GET-safe for reads)
api() {
  local label="$1" method="$2"; shift 2
  local resp
  resp="$(curl -sS -G -H "Authorization: Bearer $(token_for "$label")" "$@" "$API/$method")" \
    || die "curl failed for $method ($label)"
  if [[ "$(jq -r '.ok' <<<"$resp")" != "true" ]]; then
    die "$method failed for account '$label': $(jq -r '.error // "unknown"' <<<"$resp")"
  fi
  printf '%s' "$resp"
}

iso_to_epoch() { date -d "$1" +%s 2>/dev/null || die "cannot parse ISO8601 timestamp: $1"; }

# ---------------------------------------------------------------- caches
id_cache_file()    { printf '%s/.slack-id-cache-%s' "$SKILL_DIR" "$1"; }
users_cache_file() { printf '%s/.slack-users-cache-%s' "$SKILL_DIR" "$1"; }

auth_info() {  # <label> → {user_id, team, team_id, user} (cached)
  local label="$1" f; f="$(id_cache_file "$label")"
  if [[ ! -s "$f" ]]; then
    api "$label" auth.test | jq '{user_id, team, team_id, user}' >"$f"
    chmod 600 "$f"
  fi
  cat "$f"
}

refresh_users_cache() {  # <label> — id → display name map
  local label="$1" f cursor="" page merged='{}'
  f="$(users_cache_file "$label")"
  while :; do
    if [[ -n "$cursor" ]]; then
      page="$(api "$label" users.list --data-urlencode "limit=200" --data-urlencode "cursor=$cursor")"
    else
      page="$(api "$label" users.list --data-urlencode "limit=200")"
    fi
    merged="$(jq -s '.[0] * (.[1].members | map({(.id): (.profile.real_name // .real_name // .name)}) | add // {})' \
      <(printf '%s' "$merged") <(printf '%s' "$page"))"
    cursor="$(jq -r '.response_metadata.next_cursor // ""' <<<"$page")"
    [[ -z "$cursor" ]] && break
  done
  printf '%s' "$merged" >"$f"
  chmod 600 "$f"
}

users_map() {  # <label> — cached map, refreshed when stale/absent
  local label="$1" f; f="$(users_cache_file "$label")"
  if [[ ! -s "$f" ]] || [[ -n "$(find "$f" -mtime +"$USERS_CACHE_MAX_AGE_DAYS" 2>/dev/null)" ]]; then
    refresh_users_cache "$label"
  fi
  cat "$f"
}

# ---------------------------------------------------------------- conversations
member_conversations() {  # <label> → JSON array [{id,name,type,user}]
  local label="$1" cursor="" page all='[]'
  while :; do
    if [[ -n "$cursor" ]]; then
      page="$(api "$label" users.conversations \
        --data-urlencode "types=public_channel,private_channel,mpim,im" \
        --data-urlencode "exclude_archived=true" \
        --data-urlencode "limit=200" --data-urlencode "cursor=$cursor")"
    else
      page="$(api "$label" users.conversations \
        --data-urlencode "types=public_channel,private_channel,mpim,im" \
        --data-urlencode "exclude_archived=true" \
        --data-urlencode "limit=200")"
    fi
    all="$(jq -s '.[0] + (.[1].channels | map({id, name: (.name // null), user: (.user // null),
      type: (if .is_im then "im" elif .is_mpim then "mpim" elif .is_private then "private_channel" else "public_channel" end)}))' \
      <(printf '%s' "$all") <(printf '%s' "$page"))"
    cursor="$(jq -r '.response_metadata.next_cursor // ""' <<<"$page")"
    [[ -z "$cursor" ]] && break
  done
  printf '%s' "$all"
}

history_since() {  # <label> <channel_id> <oldest_epoch> [limit] → raw messages array
  local label="$1" chan="$2" oldest="$3" limit="${4:-200}"
  api "$label" conversations.history \
    --data-urlencode "channel=$chan" \
    --data-urlencode "oldest=$oldest" \
    --data-urlencode "limit=$limit" | jq '.messages // []'
}

# Shape raw messages: real human messages only, name-resolved, ISO timestamps.
# shape <account> <channel_label> <channel_type> <users_map_json> <exclude_uid>
shape() {
  jq --arg account "$1" --arg chan "$2" --arg ctype "$3" --argjson users "$4" --arg self "$5" '
    map(select(.type == "message" and (.subtype == null or .subtype == "thread_broadcast")
               and .user != null and .user != $self))
    | map({account: $account, channel: $chan, channel_type: $ctype,
           from: ($users[.user] // .user),
           ts_iso: ((.ts | split(".")[0] | tonumber) | todate),
           text: .text})
    | sort_by(.ts_iso)'
}

# Resolve `from` values that are still raw user IDs (e.g. external users in
# Slack Connect shared channels, absent from users.list) via users.info,
# and persist the resolutions into the per-account users cache.
augment_names() {  # <label> <json-array-with-.from> → array with names patched
  local label="$1" arr="$2" id info patch='{}' f
  local ids
  ids="$(jq -r 'map(.from) | unique | .[] | select(test("^U[A-Z0-9]{6,}$"))' <<<"$arr")"
  if [[ -z "$ids" ]]; then printf '%s' "$arr"; return 0; fi
  while IFS= read -r id; do
    if info="$(api "$label" users.info --data-urlencode "user=$id" 2>/dev/null)"; then
      patch="$(jq --argjson u "$(jq '.user' <<<"$info")" \
        '. + {($u.id): ($u.profile.real_name // $u.real_name // $u.name)}' <<<"$patch")"
    fi
  done <<<"$ids"
  if [[ "$patch" != '{}' ]]; then
    f="$(users_cache_file "$label")"
    jq -s '.[0] * .[1]' "$f" <(printf '%s' "$patch") >"$f.tmp" && mv "$f.tmp" "$f" && chmod 600 "$f"
  fi
  jq --argjson names "$patch" 'map(.from = ($names[.from] // .from))' <<<"$arr"
}

# ---------------------------------------------------------------- commands
cmd_check() {
  local out='[]' label info
  for label in "${ACCOUNT_LABELS[@]}"; do
    info="$(auth_info "$label")"
    refresh_users_cache "$label"
    out="$(jq -s --arg a "$label" '.[0] + [(.[1] + {account: $a, users_cached: true})]' \
      <(printf '%s' "$out") <(printf '%s' "$info"))"
  done
  jq '{ok: true, accounts: .}' <<<"$out"
}

cmd_channels() {
  local out='[]' label convs users
  for label in "${ACCOUNT_LABELS[@]}"; do
    users="$(users_map "$label")"
    convs="$(member_conversations "$label" | jq --arg a "$label" --argjson users "$users" \
      'map({account: $a, id, type, name: (.name // ($users[.user] // .user))})')"
    out="$(jq -s '.[0] + .[1]' <(printf '%s' "$out") <(printf '%s' "$convs"))"
  done
  jq '{channels: .}' <<<"$out"
}

cmd_messages() {
  local target="$1" since="$2" limit="$3"
  local oldest=0; [[ -n "$since" ]] && oldest="$(iso_to_epoch "$since")"
  local label convs users match cid cname ctype msgs self
  for label in "${ACCOUNT_LABELS[@]}"; do
    users="$(users_map "$label")"
    convs="$(member_conversations "$label")"
    # id exact → channel name exact → person name (their DM), case-insensitive
    match="$(jq --arg t "$target" --argjson users "$users" '
      (map(select(.id == $t)) +
       map(select((.name // "" | ascii_downcase) == ($t | ascii_downcase))) +
       map(select(.user != null and (($users[.user] // "" | ascii_downcase) == ($t | ascii_downcase)))))
      | first // empty' <<<"$convs")"
    if [[ -n "$match" ]]; then
      cid="$(jq -r '.id' <<<"$match")"
      ctype="$(jq -r '.type' <<<"$match")"
      cname="$(jq -r --argjson users "$users" '.name // ($users[.user] // .id)' <<<"$match")"
      self="$(auth_info "$label" | jq -r '.user_id')"
      msgs="$(history_since "$label" "$cid" "$oldest" "$limit")"
      # For a directed conversation view, include own messages too (self filter off).
      local res marr
      res="$(jq --arg account "$label" --arg chan "$cname" --arg ctype "$ctype" --argjson users "$users" --arg self "$self" '
        {account: $account, channel: $chan, channel_type: $ctype,
         messages: (map(select(.type == "message" and (.subtype == null or .subtype == "thread_broadcast") and .user != null))
           | map({from: ($users[.user] // .user), me: (.user == $self),
                  ts_iso: ((.ts | split(".")[0] | tonumber) | todate), text: .text})
           | sort_by(.ts_iso))}' <<<"$msgs")"
      marr="$(augment_names "$label" "$(jq '.messages' <<<"$res")")"
      jq --argjson m "$marr" '.messages = ($m | sort_by(.ts_iso))' <<<"$res"
      return 0
    fi
  done
  die "no channel or person matching '$target' in any account (try: slack-fetch.sh channels)"
}

cmd_review() {
  local since="$1"
  local oldest; oldest="$(iso_to_epoch "$since")"
  local label users convs self mentions='[]' dms='[]' scanned=0
  local row cid cname ctype raw shaped
  for label in "${ACCOUNT_LABELS[@]}"; do
    users="$(users_map "$label")"
    self="$(auth_info "$label" | jq -r '.user_id')"
    convs="$(member_conversations "$label")"
    while IFS= read -r row; do
      cid="$(jq -r '.id' <<<"$row")"
      ctype="$(jq -r '.type' <<<"$row")"
      cname="$(jq -r --argjson users "$users" '.name // ($users[.user] // .id)' <<<"$row")"
      if ! raw="$(history_since "$label" "$cid" "$oldest")"; then
        # e.g. channel_not_found on an IM with a deactivated user/bot —
        # skip the one conversation, never abort the whole sweep.
        echo "WARN: skipping '$cname' ($cid, $label) — history unavailable" >&2
        continue
      fi
      scanned=$((scanned + 1))
      if [[ "$ctype" == "im" || "$ctype" == "mpim" ]]; then
        shaped="$(shape "$label" "$cname" "$ctype" "$users" "$self" <<<"$raw")"
        dms="$(jq -s '.[0] + .[1]' <(printf '%s' "$dms") <(printf '%s' "$shaped"))"
      else
        shaped="$(shape "$label" "$cname" "$ctype" "$users" "$self" <<<"$raw" \
          | jq --arg self "$self" 'map(select(.text | contains("<@" + $self + ">")))')"
        mentions="$(jq -s '.[0] + .[1]' <(printf '%s' "$mentions") <(printf '%s' "$shaped"))"
      fi
      sleep 0.2   # stay under Slack tier-3 rate limits on big workspaces
    done < <(jq -c '.[]' <<<"$convs")
  done
  # Resolve external-user IDs (Slack Connect senders absent from users.list),
  # per account so the right token is used.
  local sub rest
  for label in "${ACCOUNT_LABELS[@]}"; do
    sub="$(jq --arg a "$label" 'map(select(.account == $a))' <<<"$mentions")"
    rest="$(jq --arg a "$label" 'map(select(.account != $a))' <<<"$mentions")"
    sub="$(augment_names "$label" "$sub")"
    mentions="$(jq -s '.[0] + .[1]' <(printf '%s' "$rest") <(printf '%s' "$sub"))"
    sub="$(jq --arg a "$label" 'map(select(.account == $a))' <<<"$dms")"
    rest="$(jq --arg a "$label" 'map(select(.account != $a))' <<<"$dms")"
    sub="$(augment_names "$label" "$sub")"
    dms="$(jq -s '.[0] + .[1]' <(printf '%s' "$rest") <(printf '%s' "$sub"))"
  done
  jq -n --argjson mentions "$mentions" --argjson dms "$dms" \
        --arg window "$since" --argjson scanned "$scanned" \
        '{window_since: $window, channels_scanned: $scanned,
          mentions: ($mentions | sort_by(.ts_iso)), dms: ($dms | sort_by(.ts_iso))}'
}

cmd_search() {
  local query="$1" out='[]' label page
  for label in "${ACCOUNT_LABELS[@]}"; do
    page="$(api "$label" search.messages --data-urlencode "query=$query" --data-urlencode "count=20")"
    page="$(jq --arg a "$label" '(.messages.matches // []) | map({account: $a,
      channel: (.channel.name // .channel.id), from: (.username // .user),
      ts_iso: ((.ts | split(".")[0] | tonumber) | todate), text: .text, permalink})' <<<"$page")"
    out="$(jq -s '.[0] + .[1]' <(printf '%s' "$out") <(printf '%s' "$page"))"
  done
  jq '{matches: .}' <<<"$out"
}

# ---------------------------------------------------------------- arg parsing
CMD="${1:-}"; shift || true
[[ -n "$CMD" ]] || die "usage: slack-fetch.sh <check|channels|messages|review|search> [options]"

ACCOUNT="" SINCE="" DAYS="" TARGET="" QUERY="" LIMIT=200
while [[ $# -gt 0 ]]; do
  case "$1" in
    --account) ACCOUNT="${2:?}"; shift 2 ;;
    --since)   SINCE="${2:?}";   shift 2 ;;
    --days)    DAYS="${2:?}";    shift 2 ;;
    --target)  TARGET="${2:?}";  shift 2 ;;
    --q)       QUERY="${2:?}";   shift 2 ;;
    --limit)   LIMIT="${2:?}";   shift 2 ;;
    *) die "unknown option: $1" ;;
  esac
done

load_env
filter_accounts "$ACCOUNT"

case "$CMD" in
  check)    cmd_check ;;
  channels) cmd_channels ;;
  messages) [[ -n "$TARGET" ]] || die "messages requires --target"; cmd_messages "$TARGET" "$SINCE" "$LIMIT" ;;
  review)
    if [[ -z "$SINCE" ]]; then
      DAYS="${DAYS:-2}"
      SINCE="$(date -d "-${DAYS} days" -Iseconds)"
    fi
    cmd_review "$SINCE" ;;
  search)   [[ -n "$QUERY" ]] || die "search requires --q"; cmd_search "$QUERY" ;;
  *) die "unknown command: $CMD" ;;
esac
