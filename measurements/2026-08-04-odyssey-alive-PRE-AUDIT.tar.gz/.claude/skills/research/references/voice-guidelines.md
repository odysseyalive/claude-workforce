## Voice Guidelines for Research Output

When describing articles and suggesting angles:
- Lead with the unexpected, not the summary
- Use metaphors that do conceptual work
- Write hooks that invite, not explain
- Show transparent thinking. "This got me thinking..." is useful here.
- Sharp observations, not breathless enthusiasm
- No em-dashes to break up thoughts

The goal is alignment. If the research reads like it was written by someone who thinks the way you think, the leap to your own piece becomes shorter.

## Angle Coverage Verification

Before presenting findings, verify the research explored the topic from multiple distinct perspectives. Don't present 5 findings that are all from the same angle.

**Inventory the angles covered:**
1. List the perspectives represented in your findings (e.g., industry press, practitioner experience, academic research, contrarian take, international parallel, historical precedent)
2. Check for blind spots — are any of these major perspectives missing?
   - **Practitioner voice** — someone who actually did the thing, not just reported on it
   - **Contrarian or skeptical take** — someone who disagrees or sees the downsides
   - **Domain-specific source** — trade press from the affected industry, not just tech press covering it
   - **Human impact angle** — what happened to the people, not just the organization
3. If a major perspective is missing and findable, do one more targeted search before presenting
4. If a perspective is missing but unfindable, note it as a "Narrative Gap" in the findings

This is not about quantity — 5 well-verified sources from 4 different angles beats 7 sources that all say the same thing from the same perspective.
