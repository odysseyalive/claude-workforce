# The Odyssey Test Filter

**Groundwork:** Is this about how to apply, refine, or deploy AI tools? Does it help someone do the work — not observe the consequences of others doing it?

**Transformation:** Is there a specific artifact? Did something collide? Does it reveal how organizations actually work?

**Field Notes:** Does this reveal a pattern about human systems worth noticing?

See [quality.md § Quality Signals](quality.md#quality-signals) for additional quality criteria.
