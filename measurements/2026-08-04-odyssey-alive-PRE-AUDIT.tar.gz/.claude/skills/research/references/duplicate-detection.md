# Duplicate Topic Detection (Pre-Search Gate)

**Before presenting any findings, scan the neighborhood to prevent duplicate angles.**

1. **Glob** `content/focus/*.mdx` and read frontmatter (title, description, date, category) for all articles dated within 2 months forward and 2 months back of the research date.
2. **Read** the opening 2-3 paragraphs of each article in the matching category to understand the central angle.
3. **Build an exclusion list** of covered angles: the core phenomenon, argument, or observation each article addresses.
4. **Filter findings** against the exclusion list before presenting. If a finding's central angle substantially overlaps with a covered angle, exclude it silently.
5. **If all findings are excluded**, tell the user the available angles have been covered recently and ask for a different direction.

**The duplicate test:** Would a regular reader say "didn't you already write about this?" If yes, it's a duplicate. Shared industry context is not duplication — only shared central arguments or phenomena.
