# Premium Source Feeds

## Pulse Procedure (Pre-Search)

Before web searches, poll RSS feeds from subscribed premium sources to see what they're currently covering. This surfaces relevant paywalled content that web search might miss.

1. Read feeds via `mcp__jina__read_url` — see § "Feed URLs" below
2. Scan headlines for relevance to the current research mode/topic
3. Flag any articles that directly relate — these become candidate sources
4. For flagged articles, read full content via the paywall fallback script (see [paywall-auth.md](paywall-auth.md))

**This step is lightweight (2 fast HTTP reads) and runs before the main search to inform query formulation.** Premium source headlines often reveal angles that general web search surfaces days later.

## Feed URLs

Read all feeds in a single parallel call via `mcp__jina__read_url` with an array:

```
["https://foreignpolicy.com/feed/", "https://trendsjournal.com/feed/", "https://vibegraveyard.ai/feed.xml", "https://odysseyalive.com/feed"]
```

**Note:** The Odyssey Alive feed is included to cross-reference what's already been published — this feeds into duplicate detection, not as a source for new findings.

## Source Profiles

### Foreign Policy (`foreignpolicy.com/feed/`)
- **Publishes:** Daily, ~5-10 articles/day
- **Strength:** Geopolitical analysis, international relations, policy argument
- **Best for:** Transformation mode (organizational/systemic consequences), Field Notes (pattern recognition in global systems)
- **Paywall:** Most articles gated; some labeled "paywall-free"
- **Feed returns:** ~25 most recent articles with title, URL, date

### Trends Journal (`trendsjournal.com/feed/`)
- **Publishes:** Weekly batch (Tuesdays), plus intermittent video/media posts
- **Strength:** Economic trend forecasting, contrarian market analysis, consumer behavior shifts
- **Best for:** Transformation mode (economic disruption), Groundwork (market-driven tool adoption patterns)
- **Paywall:** All articles gated behind WooCommerce subscription
- **Feed returns:** ~10 most recent articles with title, URL, date

### Vibe Graveyard (`vibegraveyard.ai/feed.xml`)
- **Publishes:** Ongoing; 145+ incidents cataloged as of 2026-04-01
- **Strength:** Curated catalog of AI failures — hallucinated citations, vibe-coded security breaches, chatbot meltdowns, agent hijacking, executive AI missteps
- **Best for:** Transformation mode (collision stories with specific artifacts), Field Notes (patterns in AI failure modes across industries)
- **Paywall:** None — fully open, no login required
- **Feed returns:** Incident reports with title, URL, date, severity ratings (Oopsie / Facepalm / Catastrophic)
- **Reading:** Use `mcp__jina__read_url` directly — no Playwright needed
- **Note:** References within stories still need independent verification per OSINT framework. The site curates and categorizes incidents but is not a primary source itself.

## Relevance Filtering

When scanning feed headlines against the research topic:

**Include if:**
- Headline directly names the phenomenon being researched
- Headline covers the same industry/sector from a different angle
- Headline reveals a consequence or second-order effect of the research topic

**Exclude if:**
- Headline is about a completely unrelated domain
- Headline is a media appearance or video cross-post (common on TJ)
- Headline duplicates a source already found via web search

## Reading Flagged Articles

Articles flagged as relevant need full text retrieval via Playwright:

```bash
NODE_PATH=$(npm root -g) node scripts/read-paywalled.js "<article-url>"
```

These articles then enter the normal verification pipeline — they must still be fully read before citation and count toward the 3-source minimum like any other source.
