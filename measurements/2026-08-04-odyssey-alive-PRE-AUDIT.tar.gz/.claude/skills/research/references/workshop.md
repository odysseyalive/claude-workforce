# Workshop Mode Reference

Workshop mode is a conversational phase that sits between research findings and article drafting. Its purpose is to draw out the author's perspective through discussion so that by the time `/focus` begins, the spine, angle, and discovery arc are already established through natural conversation — not bolted on after the fact.

## When to Activate

Workshop activates after initial research findings have been presented and the user has selected a topic (or asks to workshop a topic). Invoked via `/research workshop`.

It also activates via the **Draft-First Entry** below, when Francis asks for a preliminary draft before he's ready to talk through the angle in the abstract.

## Draft-First Entry

Some topics are easier to react to than to discuss cold. If Francis asks for a preliminary draft before workshopping — instead of, or in the middle of, the standard findings-then-workshop sequence — that's not a deviation from this skill, it's a second entry point.

**Trigger:** Francis says something to the effect of "draft it first, then let's talk" — he wants a concrete artifact to push against rather than an open question.

**Procedure:**
1. Hand off to `/focus create` with the selected finding, its verified sources, and the working angle from the research presentation (not yet Francis's own angle — the research-stage hypothesis only). Tell `/focus` explicitly that no spine has been gathered yet.
2. `/focus` Phase 1c (get Francis's spine) detects the missing-spine condition and drafts a **preliminary draft**: full body, real sources, real images — built around the research-stage angle, with the closing section left as an explicit placeholder naming what's still missing (see [../../focus/references/workflow.md](../../focus/references/workflow.md) § Phase 1c, "Draft-First Branch"). Everything mechanical (word count, image count, references, voice, wit) still applies in full — only the spine-dependent closing stays open.
3. Once the draft exists, run `/research workshop` against it. This is the SAME 7-move toolkit as the standard entry, with one change of anchor: instead of opening cold ("what's your instinct on this?"), Room Exploration (move 4) opens on the draft itself — "Here's what's there. What's missing? What would you add, cut, or argue with?" The draft is the room; Francis's reactions to specific passages are the exploration.
4. The rest of the methodology is unchanged: Paired Contrasts, Self-Reference Bridges, and Graduated Recall all still apply, now anchored on draft passages instead of raw findings. Workshop Exit conditions (clear angle, grounded in sources, discovery arc, audience fit validated) are unchanged.
5. On exit, generate the normal Workshop Handoff Brief. Hand it back to `/focus` to fill in the placeholder closing section and run Phase 3 validation on the now-complete draft.

**What stays the same as the standard entry:** the core principle (the author's perspective is discovered through conversation, not assigned after research), all 7 conversational moves, the agent dispatch table, and the exit conditions. Only the anchor changes — a draft instead of a blank page.

## Core Principle

**The author's perspective is discovered through conversation, not assigned after research.** Sources inspire the story. The workshop ensures the author has internalized the material and found their own angle before a single word is drafted.

## The 7 Conversational Moves

These are a toolkit, not a rigid sequence. The conversation leads. Use the moves that serve the discussion — skip moves that don't fit. The facilitator reads the room.

### 1. Prior Knowledge
**Ask what Francis already thinks before showing findings.**

Before revealing source details, ask: "What's your instinct on this? What have you seen in your own work?" This surfaces pre-existing mental models that the article should build on, not ignore.

*Why it matters:* If the article contradicts what Francis already knows from client work without acknowledging it, the piece will feel dishonest. If it aligns, the sources become evidence for his existing insight.

### 2. Room Construction
**Reorganize findings into thematic rooms.**

Take the 5-7 research findings and cluster them into 3-4 "rooms" — thematic groupings with narrative threads between them. Name each room with a tension or question, not a topic label.

*Bad room name:* "AI in Healthcare"
*Good room name:* "The doctors who automated their expertise and then couldn't explain their own decisions"

Present the rooms as a map: "Here's what I found, organized by the tensions I see. Which room do you want to walk through first?"

### 3. Generation / Anticipation
**Ask Francis to predict findings before revealing them.**

Before opening a room, ask: "What do you think the research found about [tension]?" His prediction creates a gap between expectation and reality that drives engagement — both in the conversation and later in the article.

### 4. Room Exploration + Elaborative Interrogation
**Walk through findings one at a time with probing questions.**

Present one finding. Then ask:
- "Why does this matter to you?"
- "What's the angle only you would see here?"
- "Does this match what you've seen with clients?"
- "What would your skeptical reader say about this?"

Don't move to the next finding until the current one has been fully explored or explicitly set aside.

### 5. Paired Contrasts
**Surface tensions between contradicting sources.**

When two sources disagree, present them side by side: "Source A says X. Source B says Y. What do you think is actually happening?" Contradictions are where the most interesting articles live — they force the author to take a position.

### 6. Self-Reference Bridges
**Connect findings to Francis's client work and lived experience.**

Ask: "Have you seen this play out with a client?" or "Does this remind you of anything from your own experience?" These bridges turn abstract findings into concrete stories. The best focus articles are grounded in specific observation, not general research.

### 7. Graduated Recall
**Circle back to earlier findings as new discussion reshapes understanding.**

As the conversation develops, return to earlier rooms: "Remember when we talked about [earlier finding]? Does that look different now after what you said about [recent insight]?" This builds the discovery arc — the journey from first impression to deeper understanding.

## Conversational Principles

1. **Follow energy.** If Francis lights up about a finding, stay there. If he's flat, move on. The article will be strongest where his genuine interest lives.

2. **Let silence work.** After a question, wait. Don't fill the gap with more information. The author's best insights come after a pause, not during a data dump.

3. **Name what you see.** "You keep coming back to the idea that small firms are more nimble — is that the spine?" Reflecting patterns back helps the author recognize their own angle.

4. **Protect surprises.** If Francis says something unexpected or contradictory, don't smooth it over. That's probably the article. "Wait — you just said the opposite of what the research suggests. Tell me more about that."

5. **Don't draft during workshop.** No outlines, no structure suggestions, no "this could be your opening." The workshop discovers; the draft builds. Mixing them collapses the creative space.

## Agent Dispatch

Three specialist agents can be dispatched during natural conversation breaks. They observe and report — the facilitator decides what to do with their findings.

| Agent | When to Dispatch | What It Does |
|-------|-----------------|--------------|
| [research-librarian](../agents/research-librarian/AGENT.md) | When a gap emerges (claim without evidence, new angle needs grounding) | Fetches additional sources to fill the gap |
| [viral-scout](../agents/viral-scout/AGENT.md) | After a rich exchange where Francis said something striking | Flags Francis's own words with stop-scrolling potential |
| [audience-analyst](../agents/audience-analyst/AGENT.md) | When an angle starts crystallizing | Evaluates fit against target audience |

**Dispatch cadence:** 1-2 dispatches per workshop, not after every exchange. Agents deploy at natural breaks — after exploring a room, when an angle crystallizes, or when the conversation hits a lull. The facilitator weaves agent findings into conversation naturally, not as formal reports.

**How to dispatch:** Run agents as background Task agents. Continue the conversation while they work. When results return, incorporate relevant findings into the next conversational move.

## Workshop Exit

The workshop is complete when:
1. Francis has articulated a clear angle in his own words
2. The angle is grounded in specific sources (not just opinion)
3. There's a discovery arc (how his understanding shifted during the conversation)
4. The audience fit has been validated (by agent or by discussion)

When these conditions are met, generate a **Workshop Handoff Brief** (see [workshop-handoff.md](workshop-handoff.md)) and present it to Francis for confirmation before handing off to `/focus`.

## What Workshop Is Not

- **Not an interview.** Don't interrogate. Converse.
- **Not a brainstorm.** Don't generate options. Discover the one angle that's already there.
- **Not a form to fill out.** The handoff brief is generated from conversation, not dictated into fields.
- **Not mandatory for every article.** Some topics arrive with a clear spine already. Workshop is for topics where the angle needs to be found.
