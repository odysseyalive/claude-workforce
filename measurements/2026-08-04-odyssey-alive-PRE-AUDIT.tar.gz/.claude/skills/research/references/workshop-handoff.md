# Workshop Handoff Brief

This is the output format for a completed workshop session. It bridges the gap between `/research workshop` and `/focus create`, giving the drafter everything discovered through conversation.

## When Generated

At the end of a workshop session, after Francis confirms the angle. The facilitator generates this from the conversation — it should feel like a summary of what was discussed, not a form that was filled out.

## Format

```markdown
## Workshop Handoff Brief

**Topic:** [Working topic in plain language]
**Research Mode:** [groundwork | transformation | fieldnotes]
**Date:** [Workshop date]

### Spine
[1-2 sentences. The core argument in Francis's own words, quoted directly from the conversation where possible. This is what the article is about at its deepest level.]

### Angle
[1-2 sentences. What makes this article distinctly Francis's — the perspective that no one else would bring. Often the gap between what the research says and what Francis has seen.]

### Discovery Arc
[3-5 bullet points tracing how Francis's understanding shifted during the conversation. This becomes the article's narrative structure — the reader follows the same journey.]

- Started thinking: [initial assumption or instinct]
- Then encountered: [finding or tension that complicated the picture]
- Which led to: [deeper insight or reframing]
- Landing on: [the position the article will take]

### Audience
[1-2 sentences. Who specifically needs to read this and why. Should be concrete enough to picture a person, not a demographic.]

### Viral Hook
[The single most stop-scrolling moment from the conversation — quoted directly from Francis. This may become the article's opening, a pull quote, or a social post.]

### Source Foundation
[List of 3-5 key sources that ground the angle, with 1-sentence notes on what each contributes to the argument.]

- [Source title](URL) — [what it contributes]
- [Source title](URL) — [what it contributes]
- [Source title](URL) — [what it contributes]

### Unresolved Tensions
[0-3 tensions that emerged but weren't fully resolved. These are features, not bugs — they give the article nuance and prevent it from becoming a lecture.]

- [Tension 1: e.g., "The data says X but Francis's client experience says Y — article should acknowledge both"]
```

## How /focus Consumes This

When `/focus create` is invoked with a Workshop Handoff Brief in context:

1. **Phase 1c (spine question) is skipped.** The spine was already discovered through conversation — asking again would produce a thinner answer than what the workshop surfaced.
2. **The discovery arc becomes the article structure.** The drafter organizes around Francis's journey, not the source order.
3. **The viral hook is preserved verbatim** in the draft (as opening, pull quote, or wherever it lands best).
4. **Unresolved tensions are woven in**, not resolved — they give the article its texture.
5. **Source foundation is the starting bibliography.** Additional sources may be added during drafting, but these are the core.

## Quality Check

Before handing off, the facilitator should verify:

- [ ] Spine is in Francis's words, not a summary of research
- [ ] Angle couldn't be written by someone else with the same sources
- [ ] Discovery arc has genuine movement (not just "I learned things")
- [ ] At least 3 sources are on-topic and accessible
- [ ] Viral hook is a direct quote, not a polish
