## Groundwork Topic Areas

- **Context and prompting strategies** — how to give AI better rooms to work in, persistent context, system design
- **Trust and architecture** — simpler models, harnesses over capabilities, reliability patterns
- **AI tool decisions** — crawlers, SEO implications, platform choices, when to block vs allow
- **Research and workflow** — using AI as research partner, productivity patterns
- **Content and audience strategy** — where to publish, attention patterns, reaching the right people
- **Deployment and rollout patterns** — how to move from pilot to production, scaling what works
- **Refinements and iterations** — improving existing AI implementations, tuning workflows, fixing what's broken
- **Application opportunities** — new ways to apply AI tools to specific business problems

### What Groundwork Is NOT

Groundwork is NOT about:
- Workforce displacement or structural labor consequences (→ transformation)
- Organizational culture shifts caused by AI adoption (→ transformation)
- Historical parallels to past technology adoption (→ transformation)
- Reskilling, role evolution, or workforce preparation narratives (→ transformation)

**The litmus test:** Groundwork helps someone DO the work. Transformation helps someone UNDERSTAND what the work is doing to them and their organization.

### Groundwork Search Focus

- Tool comparisons and practical recommendations
- Deployment patterns and rollout strategies
- Prompt engineering and context architecture techniques
- Integration how-tos with real-world outcomes
- "Here's how we use it" practitioner stories
- Platform and tool refinement announcements that affect implementation

---

## Groundwork Queries

```
"AI tool comparison practical [date]"
"how we use AI workflow [date]"
"AI deployment rollout production [date]"
"LLM prompting strategies business [date]"
"AI integration how-to [date]"
"MCP context architecture implementation [date]"
site:stackoverflow.blog AI tools [date]
site:thenewstack.io AI deployment [date]
```

---

## Groundwork Sources

- Practitioner blogs
- Developer-focused publications (Stack Overflow, The New Stack, Dev.to)
- Tool documentation and release notes
- "How we built it" and "how we use it" posts
- Platform announcements with implementation implications
