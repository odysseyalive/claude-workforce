# Paywall Authentication Reference

## How It Works

The `scripts/read-paywalled.js` script uses Playwright headless Chromium with a persistent browser profile at `~/.cache/ms-playwright/mcp-reader-profile/`. Once logged into a site, the session persists across runs until cookies expire.

Credentials are stored in `~/.config/playwright-mcp/secrets.env` (owner-only permissions, not in repo).

## Usage

```bash
# Auto-detect paywall and login if needed
NODE_PATH=$(npm root -g) node scripts/read-paywalled.js "<url>"

# Force login for a domain before reading
NODE_PATH=$(npm root -g) node scripts/read-paywalled.js "<url>" --login <domain>
```

## Detection Signals (Unknown Domains)

- Content suspiciously short relative to article title/topic
- "Subscribe to continue," "Members only," or similar paywall markers
- Truncation mid-sentence or mid-paragraph

## Registered Domains

| Domain | Login URL | Auth Type | Notes |
|--------|-----------|-----------|-------|
| foreignpolicy.com | /login/ | Email + password | Standard form, some articles free |
| trendsjournal.com | /my-account/ | WooCommerce (username + password) | Cookie consent dismissed first, all articles gated |

## Session Expiry

If a previously authenticated domain starts showing paywalls again:
- The session has expired
- Re-run with `--login <domain>` to re-authenticate
- The persistent profile will save the new session

## Adding New Domains

1. Add credentials to `~/.config/playwright-mcp/secrets.env` (KEY=value format)
2. Add site config to `SITES` object in `scripts/read-paywalled.js`:
   - `loginUrl` — the login page URL
   - `emailKey` / `passwordKey` — keys from secrets.env
   - `emailSelector` / `passwordSelector` / `submitSelector` — CSS selectors for the login form
   - `preCookieSelector` (optional) — CSS selector to dismiss cookie consent before login
3. Add the domain to the "Known paywalled domains" list in SKILL.md § "Paywall Fallback"
4. Add a row to the Registered Domains table above
5. Test with `--login <domain>` to verify the flow works
