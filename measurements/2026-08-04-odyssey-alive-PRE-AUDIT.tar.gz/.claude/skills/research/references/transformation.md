## Seat-Bracket Criteria

What makes a transformation story:

1. **A specific, tangible artifact** — a part, a device, a policy, a failed rollout. Something you can point to.
2. **AI as catalyst** — AI designed, optimized, or enabled something new.
3. **Organization couldn't absorb it** — the gap between what AI made possible and what human systems could receive.
4. **The collision reveals truth** — friction exposes how organizations actually work, not how they claim to work.
5. **Human systems under pressure** — institutional memory, supplier relationships, regulatory frameworks, workforce patterns.
6. **Viral potential** — names a pattern people recognize but haven't articulated. "That's exactly what happened to us."

### Transformation Search Focus

- Specific artifacts where AI was the catalyst for a collision
- Failed or stalled implementations where the technology worked but the organization couldn't absorb
- Moments where friction exposed hidden dependencies or assumptions
- Stories with a "how do we make this?" question that revealed something larger

---

## Transformation Queries

```
"AI manufacturing implementation failed [date]"
"generative design production challenges [date]"
"AI supply chain disruption [date]"
"automated logistics problems [date]"
"AI healthcare implementation barriers [date]"
"AI infrastructure project stalled [date]"
site:supplychaindive.com AI [date]
site:industryweek.com AI implementation [date]
site:modernhealthcare.com AI [date]
```

---

## Domains for Transformation Stories

For AI-related collisions, focus on:

| Domain | What to Look For |
|--------|------------------|
| **Manufacturing** | AI-designed parts meeting production reality |
| **Supply chain** | AI-optimized logistics meeting supplier relationships |
| **Global trade** | AI forecasting meeting tariffs, sanctions, policy shifts |
| **Product distribution** | Automation meeting last-mile reality |
| **Healthcare/medical devices** | AI diagnostics meeting FDA, procurement, clinical workflow |
| **Construction/infrastructure** | AI design meeting codes, permitting, labor practices |
| **Energy/grid** | AI optimization meeting regulatory frameworks, infrastructure limits |
| **Agriculture/food systems** | AI farming tech meeting generational practice, labor |
| **Logistics/ports** | AI scheduling meeting customs, container choreography |
| **Legacy systems** | AI modernization meeting institutional memory in code |
| **Global economy** | AI-driven decisions meeting currency, cross-border friction |

---

## Transformation Sources

- Industry trade publications (not tech press)
- Supply chain news
- Manufacturing journals
- Healthcare/medtech coverage
- Construction trades
- Energy sector news
- Agriculture publications
- Logistics/shipping coverage

**Key insight:** Look for stories buried in specialist press that mainstream hasn't noticed.
