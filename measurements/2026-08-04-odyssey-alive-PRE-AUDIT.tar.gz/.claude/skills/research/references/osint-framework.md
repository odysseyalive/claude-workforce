# OSINT Analytical Framework

Adapted from the CIA ARC System (Andrew Bustamante, EverydaySpy). Applied as an active analytical lens during research — not theory to read, but steps to execute.

## When to Activate

Run the OSINT checklist at two points:

1. **Pre-search** (steps 1-2): Before formulating queries, surface your own assumptions and sharpen your questions
2. **Post-discovery** (steps 3-5): Before presenting findings, verify facts, evaluate data, and pressure-test through deliberate framing

---

## Step 1: Surface Assumptions (Pre-Search)

Before searching, ask yourself:

- **What do I already believe about this topic?** Name it explicitly. If you assume AI is disrupting manufacturing, that's an assumption — not a finding.
- **What outcome am I expecting to find?** If you're searching to confirm something, you've already failed. Search to discover.
- **What would surprise me?** The most valuable findings are the ones that contradict your starting position.

**The rule:** An assumption is a belief accepted as truth without proof. An assessment is truth reached through objective, observable evidence. Research produces assessments, not assumptions.

**Application:** Write down 1-2 assumptions you hold about the topic before you search. After research, check whether your findings confirmed or challenged them. If everything confirmed your priors, your search was too narrow.

---

## Step 2: Ask the Right Questions (Query Formulation)

Bad research questions generalize. Good research questions are specific and accurate.

| Bad Query Pattern | Why It Fails | Better Query |
|-------------------|-------------|-------------|
| "AI disrupting industry" | Too broad, returns hype | "AI implementation failed [specific sector] [date]" |
| "Why is AI changing everything" | Assumes conclusion | "What happened when [company] deployed AI in [process]" |
| "AI benefits for business" | Confirmation-seeking | "AI deployment unexpected consequences [date]" |

**Application:** For each search angle, formulate at least one query that could surface a contrarian or unexpected result. If all your queries point the same direction, add one that points the other way.

---

## Step 3: Categorize Before You Cite (Fact Checking)

When evaluating a source, classify every claim into one of three categories:

| Category | Definition | Action |
|----------|-----------|--------|
| **Verified fact** | Can be confirmed with independent evidence | Cite with confidence |
| **Unverified claim** | Plausible but no independent confirmation | Note as unverified; do not build narrative on it alone |
| **Assertion** | Opinion, hypothesis, or feeling stated as fact | Use for perspective only; never cite as evidence |

**Application:** When the source-verifier agent runs, it checks URL accuracy. This step checks *claim accuracy* — does the source's own argument hold up, or is it assertions dressed as facts?

**Red flags for assertions posing as facts:**
- No named source or attribution
- Emotional or urgent language
- Statistics without methodology or collection context
- Claims that "everyone knows" or "it's obvious that"

---

## Step 4: Interrogate the Numbers (Data Evaluation)

When a source includes data, statistics, or metrics, check three things:

1. **Source:** Who produced this number? Do they have a stake in the outcome?
2. **Context:** What's the baseline? "50% increase" means nothing without knowing increase from what. A sensational stat often hides a small absolute number.
3. **Collection method:** How was this measured? Self-reported surveys, controlled experiments, and observational data produce very different reliability levels.

**Application:** If a finding's hook relies on a statistic, verify the stat's source and context before presenting. A finding built on a bad number is a bad finding. Note data quality in the Source Quality field of the output format.

---

## Step 5: Deliberate Framing (Pre-Presentation)

Before presenting findings, apply deliberate framing — the research equivalent of deliberate dialogue:

- **What perspective is missing?** (Already partially covered by the voice-guidelines angle coverage check — this reinforces it with intent)
- **Who would disagree with this finding, and why?** If you can't name a reasonable objection, you haven't looked hard enough.
- **What question does this raise that it doesn't answer?** That's your Narrative Gap — name it honestly.

**Deliberate framing prompts:**
- "I wonder what someone in [affected role] would say about this..."
- "What if the opposite were true — what evidence would I expect to see?"
- "How did the original author come to this conclusion?"

**Application:** For each finding, spend 30 seconds on the contrarian position before writing the Possible Take. This prevents narrative tunnel vision — the research equivalent of reactive dialogue.

---

## Quick Reference: The 5-Step Checklist

```
PRE-SEARCH
[ ] Named my assumptions about this topic
[ ] Formulated at least one contrarian query
[ ] Questions are specific, not generalizing

POST-DISCOVERY
[ ] Classified claims as fact / unverified / assertion
[ ] Checked data sources, context, and collection methods
[ ] Identified the missing perspective for each finding
[ ] Named a reasonable objection to each finding
```
