## Example Output Formats

### Groundwork Example

```
## 1. [Article Title]
**Source:** Publication Name | [Link]

**Hook:** A team at a mid-size manufacturer documented every prompt failure for six months. The pattern that emerged wasn't about AI. It was about how they'd been explaining things to each other all along.

**Odyssey Angle:** This is context architecture in practice. The thread: what your prompts reveal about your organizational communication.

**Possible Take:** The article frames this as prompt engineering. But what if it's actually organizational self-discovery? The AI became a mirror.

**Solution Gesture:** Close by suggesting that better prompts start with better questions about how your team already communicates. This connects to Odyssey's work building organizational readiness without being prescriptive.

**Source Quality:** [credibility, data, unique perspectives]

**Narrative Gaps:** [what the source doesn't explain]

**Independent On-Topic Sources:** [N] accessible, on-topic URLs verified | SUFFICIENT or INSUFFICIENT FOR ARTICLE

---
```

### Transformation Example

```
## 1. [Article Title]
**Source:** Trade Publication | [Link]

**Hook:** A port authority deployed AI scheduling that worked perfectly. The longshoremen's union didn't object to the technology. They objected to what it revealed about how decisions had actually been made for decades.

**Odyssey Angle:** Artifact: the scheduling algorithm. Collision: institutional memory vs. optimization. What it reveals: the invisible contracts that organizations run on.

**Possible Take:** The article focuses on labor relations. The deeper story: AI made visible the informal negotiation layer that kept the system running.

**Solution Gesture:** Point toward the value of making informal processes explicit before optimizing them. Connects to Odyssey's approach of understanding how things actually work first.

**Source Quality:** [credibility, data, unique perspectives]

**Narrative Gaps:** [what the source doesn't explain]

**Independent On-Topic Sources:** [N] accessible, on-topic URLs verified | SUFFICIENT or INSUFFICIENT FOR ARTICLE

---
```

### Field Notes Example

```
## 1. [Article Title]
**Source:** Publication Name | [Link]

**Hook:** [The unexpected observation that makes this interesting]

**Odyssey Angle:** [What pattern about human systems does this expose?]

**Possible Take:** [A question or tension worth exploring]

**Source Quality:** [credibility, data, unique perspectives]

**Narrative Gaps:** [what the source doesn't explain]

**Independent On-Topic Sources:** [N] accessible, on-topic URLs verified | SUFFICIENT or INSUFFICIENT FOR ARTICLE

---
```
