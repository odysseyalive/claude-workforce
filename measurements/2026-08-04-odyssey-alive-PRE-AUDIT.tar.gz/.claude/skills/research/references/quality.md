## Quality Signals

### Strong Candidates

- Challenge assumptions without being contrarian for its own sake
- Include specific data, names, or examples (not just abstractions)
- Written by someone with evident expertise or experience
- Raise questions rather than just providing answers
- Have a "I didn't know that" or "I never thought of it that way" quality
- Feature a tangible artifact (for Transformation track)

### Weak Candidates

- Summarize without adding perspective
- Use buzzwords without substance
- Feel like content marketing dressed as journalism
- Miss the human element entirely
- Could have been written about any company or any technology
- Lack specific examples or artifacts

---

## What to Avoid

- "10 AI tools to boost productivity" listicles
- Breathless hype about AI capabilities
- Generic business transformation content
- Articles that treat technology as inevitable and humans as obstacles
- Pure technical deep-dives without human context
- Anything that could have been written by prompt-stuffing ChatGPT
- Political framing or advocacy
- Stories without specific artifacts or examples
