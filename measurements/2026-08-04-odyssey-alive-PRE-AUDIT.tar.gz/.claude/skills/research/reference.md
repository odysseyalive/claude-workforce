# Research Skill Reference

## Pipeline Mapping

Research mode determines article category. This is a direct mapping, not a suggestion.

| Research Mode | Publication Day | Frontmatter Category | Focus |
|---------------|-----------------|----------------------|-------|
| `groundwork` | Tuesday | `groundwork` | Application opportunities, refinements, rollouts |
| `transformation` | Friday | `ai-transformation` | Collision stories with artifacts |
| `fieldnotes` | Any | `field-notes` | Anthropological observation |
| `workshop` | N/A | N/A | Conversational exploration of selected topic → handoff brief |

## Mode-Specific Guidance

| Mode | Purpose | Framing | Reference |
|------|---------|---------|-----------|
| Groundwork (Tue) | Application opportunities, refinements, rollouts | Humble, grounded, "here's how to do the work" | [groundwork.md](references/groundwork.md) |
| Transformation (Fri) | Collision stories, seat bracket model | Anthropological, non-political | [transformation.md](references/transformation.md) |
| Field Notes | Anthropological observation on user topic | Patterns in human systems | N/A |
| Workshop | Conversational exploration of selected topic | Facilitated discussion, author's perspective first | [workshop.md](references/workshop.md) |

## Workshop Agents

These agents are dispatched during `/research workshop` at natural conversation breaks. See [references/workshop.md](references/workshop.md) for dispatch timing and cadence.

| Agent | Purpose | Reference |
|-------|---------|-----------|
| Research Librarian | Fetch additional sources when gaps emerge mid-conversation | [agents/research-librarian/AGENT.md](agents/research-librarian/AGENT.md) |
| Viral Scout | Flag Francis's own words with stop-scrolling potential | [agents/viral-scout/AGENT.md](agents/viral-scout/AGENT.md) |
| Audience Analyst | Evaluate emerging angle against target audience | [agents/audience-analyst/AGENT.md](agents/audience-analyst/AGENT.md) |
