---
name: research
description: Content research for Odyssey Alive. Modes: groundwork, transformation, fieldnotes, workshop.
allowed-tools: Read, Glob, Grep, Bash, mcp__jina__*
minimum-effort-level: high
strictness: standard
---

# Content Research

**This is a master skill.** When invoked, it discovers articles and stories that could inspire focus content.

## Pipeline

**Research mode determines article category.** See [reference.md](reference.md) § "Pipeline Mapping" for the mode → category → publication day mapping.

---

## Usage

```
/research [mode] [date|subject]
/research workshop
```

Default: Prompts for which track if not specified.

**Workshop mode** activates after initial findings have been presented and a topic is selected. It runs a conversational exploration that draws out the author's perspective before drafting begins. See [references/workshop.md](references/workshop.md) for the full methodology and [references/workshop-handoff.md](references/workshop-handoff.md) for the output format that bridges to `/focus`.

---

<!-- origin: user | added: 2026-02-12 | immutable: true -->
## Directives

> **"Every URL that may become a citation must be fully read before it can be used. Search result summaries, Jina snippets, and metadata descriptions are not source material. They are discovery tools only."**

*— Added 2026-02-12, source: skill-builder audit (extracted from Source Verification Hard Rule)*

> **"All content tracks are non-political and neutral. We observe, describe, and notice patterns. We do not advocate, judge, or take sides."**

*— Added 2026-02-12, source: skill-builder audit (extracted from Core Principle: Anthropological Neutrality)*

> **"Every research finding presented to the user must include a count of independent, accessible, on-topic source URLs that were fully read. If a finding has fewer than 3 such sources, it must be flagged as 'insufficient for focus article' in the presentation. Do not present a finding as article-ready when it relies on a single source. A source is 'on-topic' only if its primary subject matter directly relates to the finding's hook and angle — tangentially related articles about the same industry or technology do not count."**

*— Added 2026-03-09, source: user directive after single-source topic wasted a full article drafting cycle*

> **"Before presenting findings, scan all existing focus articles dated within 2 months forward and 2 months back of the research date. Read the frontmatter (title, description, category) and opening paragraphs of each. If a research finding's central angle, core argument, or primary phenomenon duplicates or substantially overlaps with an existing or scheduled article, exclude it from the findings. Do not present it as an option. If all findings are excluded due to overlap, tell the user that the available angles have already been covered and ask for a different direction. A near-miss is not a duplicate — the test is whether a reader would say 'didn't you already write about this?' If the answer is yes, it's a duplicate."**

*— Added 2026-03-09, source: user directive after research surfaced angles already covered by existing articles*

> **"Cited articles should inspire and shape the narrative, NOT the other way around. Article subjects should not be assumed and transmuted just to 'prove a point' or fulfill requirements. The sources guide the story. If the sources don't support the angle, the angle changes or dies. Never bend a source's subject matter to fit a predetermined narrative."**

*— Added 2026-03-09, source: user directive after article drafted around a forced narrative with off-topic sources bent to fit*

> **"Groundwork is about application opportunities, refinements, and rollouts — how to use AI tools, deployment patterns, practical implementation. It is NOT about organizational consequences, workforce displacement, cultural shifts, or structural workforce changes. Those are transformation stories. The litmus test: groundwork helps someone DO the work. Transformation helps someone UNDERSTAND what the work is doing to them and their organization."**

*— Added 2026-03-09, source: user correction after groundwork research returned transformation-category findings*

> **"If I include a thesis, that thesis is the focus of the research and the portrayal of the topics. If the thesis is not fully understood, ask for clarifying questions."**

*— Added 2026-05-14, source: user directive after off-thesis research presentation (research returned findings centered on a secondary pillar of a five-part thesis and treated the user's headline claim as scaffolding)*

> **"I'd love to workshop this with you, but we need a preliminary article first so that I can at least catch up with you to chat about it. That should be how the workshop works."**

*— Added 2026-06-30, source: user directive establishing draft-first workshop entry — see [references/workshop.md](references/workshop.md) § "Draft-First Entry" for the formal branch this authorizes*

> **"Exclude impassable-paywall articles from findings entirely. If a candidate source sits behind a paywall that the Premium Source Pulse authentication and the Playwright paywall-fallback cannot get past — so only a preview, abstract, or opening paragraphs are readable — do not surface it as a finding, build a finding on it, or cite it as supporting context. Drop it at the discovery stage rather than carrying it forward. This does NOT exclude paywalled sources we hold authenticated access to and can therefore read end-to-end (the premium feeds such as Foreign Policy and Trends Journal): a paywall we can pass is not a barrier. The test is full-text access, not the mere presence of a paywall."**

*— Added 2026-06-30, source: user directive "we need to update the research skill to exclude paywall articles," scoped via clarifying question to impassable paywalls only (exclude what we can't fully read; keep premium sources we have authenticated access to)*
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Cited articles should inspire and shape the narrative, NOT the other way around. Article subjects should not be assumed and transmuted just to 'prove a point' or fulfill requirements. The sources guide the story. If the sources don't support the angle, the angle changes or dies. Never bend a source's subject matter to fit a predetermined narrative." -->
CHECKPOINT — Source-Shapes-Angle Gate:
1. Before presenting research findings, enumerate each verified source with a one-sentence summary of what the source is actually ABOUT (primary subject matter).
2. Enumerate each candidate finding's angle in one sentence (the hook the finding proposes).
3. For EACH finding: list which sources would be cited and check whether each source's actual subject directly supports the angle. Mark each source as ALIGNED (actual subject matches angle) or MISALIGNED (source is being reframed, stretched, or used as pretext for a different topic).
4. IF a finding has ≥ 2 MISALIGNED sources → STOP. Do NOT present this finding. Either reshape the angle to match what the sources actually cover, or drop the finding entirely.
5. IF a finding has 1 MISALIGNED source AND ≥ 3 ALIGNED sources → drop the misaligned source; present the finding with only aligned citations.
6. IF a finding has fewer than 3 total ALIGNED sources → STOP. Mark as insufficient per the 3-source gate and do NOT present as article-ready.
7. Apply the "did you set out to prove or to find?" test: IF the angle was chosen before the sources were read AND sources were curated to fit the angle → STOP. Reset: start from what the sources say, not from the intended conclusion.
8. IF all presented findings have alignment-verified sources AND no source is bent to fit a pretext → CONTINUE to presentation.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "All content tracks are non-political and neutral. We observe, describe, and notice patterns. We do not advocate, judge, or take sides." -->
CHECKPOINT — Anthropological Neutrality Gate:
1. Before presenting any finding, scan the finding's framing text (hook, angle, summary) for language patterns.
2. Classify the framing against these FAIL patterns:
   a. Advocacy language: "we should", "we must", "it's time to", "the answer is", "companies need to", "leaders must"
   b. Judgment language: "wrongly", "rightly", "correctly", "misguidedly", "irresponsibly", "ethical", "unethical"
   c. Partisan language: naming political parties, ideologies, or policy positions as good/bad, naming identity groups as aggressor/victim
   d. Prescriptive "lesson" framing: "the lesson here is", "what this teaches us", "the moral of"
3. IF the framing matches any FAIL pattern → STOP. Rewrite using observational verbs (observe, describe, notice, surface, expose, trace) and remove the judgment/prescription.
4. IF the finding takes a stance on a contested political or cultural question rather than describing the phenomenon neutrally → STOP. Reframe around what is HAPPENING, not what SHOULD happen.
5. IF the finding uses neutral observational framing throughout → CONTINUE and present.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "If I include a thesis, that thesis is the focus of the research and the portrayal of the topics. If the thesis is not fully understood, ask for clarifying questions." -->
CHECKPOINT — Thesis Anchor Gate:
1. Parse the invocation arguments. Scan the task description for thesis markers: first-person stance phrases ("I think", "I believe", "I disagree", "my view", "my take", "I have a disagreement", "I'm pushing back on", "I'd argue"), explicit position statements, counter-claims framed against a named position, or a multi-clause argument structure that names both a claim and what it opposes.
2. IF no thesis markers are present → set `thesis_provided = false`. Proceed with the standard research workflow. This CHECKPOINT is a no-op for thesis-free invocations.
3. IF thesis markers are present → set `thesis_provided = true`. Extract the thesis into structured form: (a) the user's central claim (their headline position), (b) the counter-claim being argued against (the discourse / common view they are pushing back on), (c) the supporting reasons the user has stated. Enumerate (a), (b), and (c) explicitly back to the user as a "Thesis read:" block before any search.
4. Thesis Comprehension Check (BLOCKING — fires before any web search):
   a. Identify ambiguous, missing, or internally contradictory elements: missing audience scope, missing counter-claim, multi-part theses where the parts could conflict, terms with multiple plausible meanings in context, supporting reasons that point in incompatible directions.
   b. IF any element is ambiguous OR the structured form has fewer than two of {claim, counter-claim, supporting reasons} populated → STOP. Ask focused clarifying questions in plain-text (NOT AskUserQuestion — questions must persist in scrollback so the user can step away to gather information). Wait for the user's reply before continuing.
   c. IF the thesis is fully understood → CONTINUE to step 5.
5. Search Angle Construction (mandatory when `thesis_provided = true`):
   a. Generate search queries that explicitly target each of: the user's central claim, the counter-claim being argued against, evidence supporting the thesis, evidence contradicting the thesis, and named voices on both sides of the discourse.
   b. Adjacent / topical queries that do not directly bear on the thesis are permitted only AFTER the thesis-anchored queries above have been issued and read.
   c. IF the planned `parallel_search_web` batch does NOT include at least one query for each of: (i) the thesis claim, (ii) the counter-claim, and (iii) contradicting-evidence — STOP. Add the missing queries before executing the batch.
6. Presentation Anchoring (BLOCKING — fires before findings are presented to the user):
   a. The presentation MUST open with a verbatim restatement of the thesis the findings are organized around, so misalignment is visible to the user before they read the findings.
   b. EACH finding must be framed as a specific take on the user's thesis (e.g., "artifact-led version of the thesis", "cost-economics version of the thesis", "contrarian pressure-test of the thesis"), not as a parallel topical article that touches the thesis tangentially.
   c. For EACH finding, write a one-line "Thesis fit:" statement that names which element of the thesis (the central claim, the counter-claim, or a specific supporting reason) the finding leads with.
   d. IF a finding's "Thesis fit:" statement reduces to "this is about the same topic / industry / phenomenon" rather than "this advances [specific element of the thesis]" → STOP. Either reframe the finding to lead with a thesis element, or drop it.
   e. Rank findings by thesis fit (how directly they advance the user's stated claim), not by topical novelty or source quality alone.
7. Pillar-Priority Failure-Mode Lock:
   a. Identify the PRIMARY pillar of the thesis: the headline claim the user opened with, the position they explicitly stated they were pushing back against the discourse to make.
   b. Identify SECONDARY pillars: supporting reasons, contextual evidence, adjacent observations.
   c. IF the LEAD finding centers on a SECONDARY pillar while the PRIMARY pillar is relegated to "scaffolding", "supporting evidence", "context", or appears only in a closing turn → STOP. The user's stated headline is the article's headline. Reorder findings before presenting so the lead finding centers on the PRIMARY pillar.
   d. This is the specific failure mode the directive was added to prevent. The named precedent: a five-part thesis (Claude-vs-OSS economic flip, OSS maintenance reliance, OSS supply-chain attack burden, the historical "code is reviewable" basis for OSS advocacy, AI-built connectors preserving reviewability while improving maintainability) was returned with findings centered exclusively on the OSS supply-chain attack burden, treating the economic flip and reviewability-migration pillars as scaffolding. The user interrupted and redirected. Future runs MUST NOT repeat this pattern.
<!-- END ENFORCEMENT ANNOTATION -->

---

<!-- MODEL-LANE-GATE START — auto-generated by /skill-builder route embed; safe to replace -->
<!-- origin: skill-builder | modifiable: true -->
## Model-Lane Preflight

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: /skill-builder route embed (model-lane gate, slim form per the 2026-06-06 2-Brain Harness directive: gates are slimmed, never stripped — this block is the lane checkpoint that travels with the skill through EVERY entry path, including hand-run invocations, which are always permitted. It goes silent when /route already covered the endeavor. Advisory-only per the 2026-06-06 No-Switch-Prompt directive: the gate CANNOT switch the model and NEVER asks the user to — its entire output is one advisory line, which names the exact remedy informationally per the 2026-06-11 named-command advisory directive. -->
CHECKPOINT — Model-Lane Preflight Gate (slim, advisory-only; fires at the TOP of this skill's workflow, before any generative step):
1. SKIP silently IF ANY of: `/route` dispatched this invocation after running its own lane preflight (a lane advisory OR ask already printed, route otherwise ASSESSED the lane this turn, or it was deliberately suppressed — route's coverage extends to the whole endeavor whether route asked, matched, or the user declined, including skills this one chains); this skill's frontmatter sets `model-lane-gate: off`; the session is headless / non-interactive; this gate is executing inside a subagent (a subagent is already model-pinned via its own frontmatter); OR an advisory for this LANE already printed this endeavor AND the active model is unchanged (advise at most once per (lane, active-model) pair per endeavor).
2. Resolve this skill's lane (own `lane:` frontmatter → the Skill→Lane table in `.claude/skills/skill-builder/references/model-lanes.md` → NO LANE) and the lane's Preferred Model. IF no lane resolves OR the preferred-model cell is empty → silent no-op (correctly absent, not a gap). IF this skill declares per-function lanes AND the invocation's resolved mode has its own row → that function's lane governs; otherwise the skill-level lane covers all modes.
3. Read ACTIVE_MODEL from the session system-context line "The exact model ID is …" (strip `[1m]`/`[200k]`, lowercase — model-lanes.md § Active-Model Detection; never an env var or Bash probe). IF the Preferred Model is malformed or names a clearly superseded family → emit the one-line stale-mapping advisory and proceed; never advise from a stale mapping, never validate against a hardcoded list.
4. Compare. Match → silent no-op. Mismatch → print ONE advisory line and PROCEED: "Lane advisory: this skill declares the `<lane>` lane (preferred `<preferred>`); the active model is `<active>` — to align, run `/model <preferred>` and re-invoke; proceeding as-is." Naming the command is INFORMATIONAL (named-command advisory directive, 2026-06-11): NEVER an AskUserQuestion, never a blocking wait (No-Switch-Prompt directive, 2026-06-06). A skill can NEVER switch the session model and never asks the user to.
5. Primary-lane scope. This gate fires ONCE per invocation, for the resolved PRIMARY lane. Cross-lane mid-workflow steps never re-advise — they delegate via this skill's LANE-AGENT-EMBED Delegation Map when present (see .claude/skills/skill-builder/references/lane-delegation.md). Delegation is never a substitute for THIS gate: analytical primary work runs on the analytical main model — never a creative main session orchestrating analytical-pinned agents to dodge the lane.
<!-- END ENFORCEMENT ANNOTATION -->
<!-- /origin -->
<!-- MODEL-LANE-GATE END -->


## Skill Chaining

**Before presenting findings:**
1. Invoke `/voice` to load Francis's authentic voice
2. Invoke `/writing` to load content protocol and style guidelines

---

## Analytics Integration

Before searching, check `/analytics report` for underperforming categories and content gaps. This helps prioritize topics that fill audience demand.

---

## Premium Source Pulse (Pre-Search)

**Grounding:** [references/premium-feeds.md](references/premium-feeds.md) § "Pulse Procedure" — RSS feed URLs and the lightweight pre-search procedure that runs before web search to surface paywalled content.

---

## Duplicate Topic Detection (Pre-Search Gate)

**Before presenting any findings, scan the neighborhood to prevent duplicate angles.** See [references/duplicate-detection.md](references/duplicate-detection.md) for the full procedure.

---

## Mode-Specific Guidance

See [reference.md](reference.md) § "Mode-Specific Guidance" for purpose, framing, and reference files per mode.

---

## OSINT Analytical Lens (Active)

**Before searching:** Run Steps 1-2 from the OSINT framework — surface your assumptions about the topic and formulate specific, non-generalizing queries including at least one contrarian angle.

**Before presenting:** Run Steps 3-5 — categorize claims (fact/unverified/assertion), interrogate any statistics, and apply deliberate framing to identify missing perspectives.

See [references/osint-framework.md](references/osint-framework.md) for the full checklist.

---

## Search Strategy

Use Jina MCP tools: `search_web`, `parallel_search_web` (3-5 angles), `read_url` (required before citation), `expand_query`. See mode-specific references for queries and source lists.

---

## Paywall Fallback (Playwright)

When `mcp__jina__read_url` returns truncated or paywall-blocked content, use the headless reader script. Known paywalled domains: `foreignpolicy.com`, `trendsjournal.com`. See [references/paywall-auth.md](references/paywall-auth.md) for usage, detection signals, domain config, and adding new sites.

---

## The Filter

Apply the "Odyssey Test" per mode. See [references/filter.md](references/filter.md).

---

## How to Present Findings

Present 5-7 options, ranked by fit. See [references/output-formats.md](references/output-formats.md) for template and [references/voice-guidelines.md](references/voice-guidelines.md) for perspective diversity checks.

---

## Output Hygiene (Workshop and Fieldnotes Modes Only)

`groundwork` and `transformation` modes hand off to `/focus` → `/edit`, which already scrubs invisible-Unicode contamination via the steganographer integration. `workshop` and `fieldnotes` can produce user-facing text directly without that transit. For those two modes, before delivering any prose-length output, pipe it through:

```bash
node .claude/skills/steganographer/scripts/scrub.js --stdin
```

If anything gets reported, the strip itself is the remediation. This catches zero-width characters and narrow no-break spaces that Claude occasionally leaks into generated text and that don't render visually.

---

## Source Verification (Enforced via Agent)

Before presenting, spawn the source-verifier agent ([agents/source-verifier/AGENT.md](agents/source-verifier/AGENT.md)). The source-verifier checks URL accuracy; the OSINT framework (Step 3) checks claim accuracy. Both run before presentation.

## Workshop Agents

See [reference.md](reference.md) § "Workshop Agents" for agent dispatch table. Agents run at natural conversation breaks per [references/workshop.md](references/workshop.md).

## Post-Action Capture

After presenting findings, if research decisions were made (topic rejected, angle shifted, source quality patterns noted), suggest recording in the awareness ledger (DEC or PAT record). Never auto-record — ask the user first.

---


---

<!-- ROUTE-EMBED START — auto-generated by /skill-builder route embed; safe to replace -->
<!-- origin: skill-builder | modifiable: true -->
## Route Consultation

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: /skill-builder route embed. Closes the dispatch-bypass gap: a /route announcement is not a substitute for a Skill tool call, and consulting /route does not license the caller to execute the target skill's procedure manually. -->
CHECKPOINT — Skill Routing Gate:
1. During this skill's workflow, IF a step requires research, web search, lookup, analysis, or any follow-up NOT already covered by an explicit tool or skill name → STOP before improvising.
2. Already-named exception. IF the current workflow step EXPLICITLY names tools or skills (e.g., "use Read", "spawn the X agent", "invoke /[skill]") → execute as written. Do NOT consult `/route` for steps already determined. Skip to your skill's next step.
3. Otherwise → invoke `/route <task description>` via the Skill tool. `/route` reads its index and either returns a target skill or reports "no match."
4. Dispatch Required. IF `/route` returns a target → the IMMEDIATE next tool call MUST be `Skill(skill=<target>, args=<derived>)`. Do NOT execute the target skill's procedure steps yourself with raw Edit / Write / Bash / Task / Agent / Read calls. The target skill's gates (asset backups, agent panels, exit tests, cascade steps, frontend-design reviews, immutable-directive checks) ONLY fire when its SKILL.md is loaded via Skill — running steps manually silently skips every gate.
5. Bypass detection. IF a Skill dispatch was just announced (yours or `/route`'s) and the next tool call is non-Skill work germane to the routed task → STOP. Print verbatim: "Route dispatch announced but Skill call skipped. Invoking Skill tool now." then issue the Skill call.
6. No-match path. IF `/route` returns "no match" → proceed with the most direct, manual approach. Document the gap; the user may want to register a skill.
7. Follow-ups loop back. After the dispatched skill returns, IF further follow-up is needed → consult `/route` again via Skill. Do not freelance the next step.
8. Auto-mode override clause. Auto-mode ("execute immediately", "prefer action over planning") does NOT override clauses 4–5. Auto-mode chooses WHAT to do; once a routing decision is on the table, the only valid next action is Skill invocation.
<!-- END ENFORCEMENT ANNOTATION -->
<!-- /origin -->
<!-- ROUTE-EMBED END -->
