---
name: analytics
description: Site traffic assessment from Google Analytics + Cloudflare, correlated with article releases. Modes: report, article-impact, compare.
allowed-tools: Read, Glob, Grep, Bash, Task
minimum-effort-level: high
strictness: standard
---

# Site Analytics

Pull traffic data from Google Analytics (GA4) and Cloudflare, correlate with article release dates, and evaluate content performance.

## Usage

```
/analytics [mode] [args]
```

### Modes

| Mode | Command | Description |
|------|---------|-------------|
| `report` | `/analytics report [period]` | Full traffic overview from both sources. Default: last 30 days |
| `article-impact` | `/analytics article-impact [slug]` | Traffic impact of a specific article (before/after release) |
| `compare` | `/analytics compare [period1] [period2]` | Period-over-period traffic comparison |
| `list` | `/analytics list` | Show this modes table |

Default mode is `report` if not specified.

---

<!-- origin: user | added: 2026-02-14 | immutable: true -->
## Directives

> **"Compare traffic data with release of articles by date so you can give me an evaluation on how things are going."**

*— Added 2026-02-14, source: user request during skill creation*
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Compare traffic data with release of articles by date so you can give me an evaluation on how things are going." -->
CHECKPOINT — Release-Correlated Evaluation Gate:
1. Before presenting an evaluation, enumerate article release dates within the reporting period from content source (content/focus/*.mdx frontmatter `date` field).
2. For EACH release date, align the traffic series from GA4 and Cloudflare to a ±14-day window around the date.
3. Compute for EACH article: pre-release baseline (mean daily sessions 14 days before), post-release peak (max daily sessions 14 days after), and decay (sessions on day 14 vs peak).
4. IF the report contains traffic numbers without article-release alignment → STOP. Recompute correlating each metric to specific release events.
5. IF an article in the period has no pre/post comparison in the output → STOP. Add the missing comparison before presenting.
6. IF all releases in the period have aligned pre/post/decay figures AND the output names which articles drove which traffic shifts → CONTINUE and present the evaluation.
<!-- END ENFORCEMENT ANNOTATION -->

---

## Workflows

**Grounding:** Before executing any mode, read [references/workflows.md](references/workflows.md) for the full procedure (report, article-impact, compare). Each mode pulls from both Cloudflare (server-side reach) and GA4 (client-side engagement), then correlates with article release dates.

## GA4 Setup Required

**Grounding:** Read [references/setup.md](references/setup.md) for the full GA4 API setup procedure. Until GA4 API access is configured, the skill will operate in **Cloudflare-only mode** and note the gap.

---

## Credential Verification (Precheck, then Agent)

Before any API call, run the deterministic precheck first: test that `.env.local` exists and contains the required key names from [references/credentials.md](references/credentials.md) (e.g., `grep -q '^CLOUDFLARE_API_TOKEN=' .env.local`). IF every required key is present → proceed without spawning an agent. IF the file is absent, a key is missing, or the result is ambiguous → spawn the ID Lookup agent (see [agents/id-lookup/AGENT.md](agents/id-lookup/AGENT.md)) for the full READY/MISSING report. If MISSING for Cloudflare, stop. If GA4 is MISSING, proceed in Cloudflare-only mode.

---

## Grounding

Before making any API call, read credentials from references and state: "I will use [VALUE] for [PURPOSE], found under [SECTION]."

**References:** [credentials.md](references/credentials.md) · [cloudflare-queries.md](references/cloudflare-queries.md) · [ga4-queries.md](references/ga4-queries.md) · [integrations.md](references/integrations.md)

## Post-Action Capture

After completing a report or article-impact analysis that reveals notable patterns (traffic spikes correlated with specific content types, engagement anomalies, sustained vs. flash-in-the-pan articles), suggest recording the finding in the awareness ledger (PAT record) so it persists across sessions. Never auto-record — ask the user first.

