# Cloudflare GraphQL Query Templates

## Daily Traffic (page views + unique visitors)

```bash
curl -s https://api.cloudflare.com/client/v4/graphql \
  -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN" \
  -H "Content-Type: application/json" \
  --data '{
    "query": "{ viewer { zones(filter: { zoneTag: \"'$CLOUDFLARE_ZONE_ID'\" }) { httpRequests1dGroups(filter: { date_gt: \"START_DATE\", date_lt: \"END_DATE\" }, limit: 31, orderBy: [date_ASC]) { sum { requests pageViews bytes } uniq { uniques } dimensions { date } } } } }"
  }'
```

Replace `START_DATE` and `END_DATE` with ISO date strings (e.g., `2026-02-01`).

**Required:** `limit` must be included (e.g., `limit: 31` for 30 days). The API returns an error without it.

## Top Pages by Traffic

```bash
curl -s https://api.cloudflare.com/client/v4/graphql \
  -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN" \
  -H "Content-Type: application/json" \
  --data '{
    "query": "{ viewer { zones(filter: { zoneTag: \"'$CLOUDFLARE_ZONE_ID'\" }) { httpRequestsAdaptiveGroups(filter: { datetime_gt: \"START_DATETIME\", datetime_lt: \"END_DATETIME\" }, limit: 20, orderBy: [count_DESC]) { count dimensions { clientRequestPath } } } } }"
  }'
```

Replace `START_DATETIME` and `END_DATETIME` with ISO datetime strings (e.g., `2026-02-01T00:00:00Z`).

**Max time range: 8 days (691,200s).** For periods longer than 8 days, break into multiple queries and merge results. This applies to all `httpRequestsAdaptiveGroups` queries on this zone tier.

## Traffic for Specific Path

```bash
curl -s https://api.cloudflare.com/client/v4/graphql \
  -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN" \
  -H "Content-Type: application/json" \
  --data '{
    "query": "{ viewer { zones(filter: { zoneTag: \"'$CLOUDFLARE_ZONE_ID'\" }) { httpRequestsAdaptiveGroups(filter: { datetime_gt: \"START_DATETIME\", datetime_lt: \"END_DATETIME\", clientRequestPath: \"/focus/SLUG\" }, orderBy: [date_ASC]) { count sum { edgeResponseBytes } dimensions { date } } } } }"
  }'
```

## Bot vs Human Traffic

```bash
curl -s https://api.cloudflare.com/client/v4/graphql \
  -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN" \
  -H "Content-Type: application/json" \
  --data '{
    "query": "{ viewer { zones(filter: { zoneTag: \"'$CLOUDFLARE_ZONE_ID'\" }) { httpRequestsAdaptiveGroups(filter: { datetime_gt: \"START_DATETIME\", datetime_lt: \"END_DATETIME\" }, limit: 10, orderBy: [count_DESC]) { count dimensions { botManagementDecision } } } } }"
  }'
```
