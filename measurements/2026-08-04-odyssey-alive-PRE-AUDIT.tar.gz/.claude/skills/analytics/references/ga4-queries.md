# GA4 Data API Query Templates

**Requires:** `PyJWT` and `cryptography` Python packages. Install with:
```bash
pip install --user PyJWT cryptography
```

## Authentication

```bash
# Generate access token from service account key
ACCESS_TOKEN=$(python3 -c "
import json, time, jwt, requests
key = json.load(open('$GA4_SERVICE_ACCOUNT_KEY_PATH'))
now = int(time.time())
payload = {'iss': key['client_email'], 'scope': 'https://www.googleapis.com/auth/analytics.readonly', 'aud': 'https://oauth2.googleapis.com/token', 'iat': now, 'exp': now + 3600}
signed = jwt.encode(payload, key['private_key'], algorithm='RS256')
r = requests.post('https://oauth2.googleapis.com/token', data={'grant_type': 'urn:ietf:params:oauth:grant-type:jwt-bearer', 'assertion': signed})
print(r.json()['access_token'])
")
```

**URL note:** The `:runReport` suffix gets mangled by shell variable expansion if written inline. Always assign the URL to a variable first.

## Sessions and Page Views

```bash
GA4_URL="https://analyticsdata.googleapis.com/v1beta/properties/${GA4_PROPERTY_ID}:runReport"
curl -s "$GA4_URL" \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  --data '{
    "dateRanges": [{"startDate": "START_DATE", "endDate": "END_DATE"}],
    "metrics": [
      {"name": "sessions"},
      {"name": "totalUsers"},
      {"name": "screenPageViews"},
      {"name": "engagementRate"},
      {"name": "averageSessionDuration"}
    ],
    "dimensions": [{"name": "date"}],
    "orderBys": [{"dimension": {"dimensionName": "date"}}]
  }'
```

## Top Pages

```bash
GA4_URL="https://analyticsdata.googleapis.com/v1beta/properties/${GA4_PROPERTY_ID}:runReport"
curl -s "$GA4_URL" \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  --data '{
    "dateRanges": [{"startDate": "START_DATE", "endDate": "END_DATE"}],
    "metrics": [
      {"name": "screenPageViews"},
      {"name": "engagementRate"},
      {"name": "averageSessionDuration"}
    ],
    "dimensions": [{"name": "pagePath"}],
    "orderBys": [{"metric": {"metricName": "screenPageViews"}, "desc": true}],
    "limit": 20
  }'
```
