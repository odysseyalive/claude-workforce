# Analytics Workflows

## Report Mode

1. **Pull Cloudflare data** via GraphQL API — page views, unique visitors, top paths, bandwidth for the period
2. **Pull GA4 data** via Data API — sessions, users, page views, engagement rate, top pages for the period
3. **Read article dates** — Glob `content/focus/*.mdx`, extract `date` frontmatter from each
4. **Correlate** — Overlay article release dates onto the traffic timeline
5. **Evaluate** — Produce a plain-language assessment:
   - Overall trend (growing, flat, declining)
   - Traffic spikes correlated with specific articles
   - Top-performing content by both sources
   - Bot vs human traffic ratio (Cloudflare)
   - Engagement quality (GA4 engagement rate, avg session duration)

## Article Impact Mode

1. **Identify article** — Read the MDX frontmatter for the given slug to get the publish date
2. **Define windows** — 7 days before publish, 7 days after publish, and 7 days starting 30 days after (sustained impact)
3. **Pull Cloudflare data** — Page views for `/focus/[slug]` path across all three windows
4. **Pull GA4 data** — Sessions and engagement for the article URL across all three windows
5. **Evaluate** — Report:
   - Immediate impact (before vs after)
   - Sustained traffic (30-day check)
   - Referral sources driving traffic to this article
   - How this article compares to the average article performance

## Compare Mode

1. **Pull data for both periods** from both Cloudflare and GA4
2. **Read article dates** to identify which articles were released in each period
3. **Evaluate** — Side-by-side comparison:
   - Total traffic change (absolute and percentage)
   - New articles published in each period
   - Per-article average performance comparison
   - Audience growth indicators

## Data Source Notes

**Cloudflare GraphQL API** gives server-side metrics: every request hits Cloudflare, so this captures bots, crawlers, and cached responses. Good for total reach and bot traffic analysis.

**GA4 Data API** gives client-side metrics: only fires when JavaScript loads in a real browser. Better for human engagement, session quality, and user behavior.

The two sources tell different stories. Cloudflare shows total visibility (including AI crawlers — which matters for the pro-bot strategy). GA4 shows human engagement quality. Use both.
