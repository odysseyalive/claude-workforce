# API Credentials

All credentials stored in `.env.local`. **Never hardcode tokens.**

## Cloudflare

| Variable | Purpose |
|----------|---------|
| `CLOUDFLARE_API_TOKEN` | Bearer token for API auth |
| `CLOUDFLARE_ZONE_ID` | Zone ID for odysseyalive.com |
| `CLOUDFLARE_ACCOUNT_ID` | Account ID |

**Endpoint:** `https://api.cloudflare.com/client/v4/graphql`
**Auth header:** `Authorization: Bearer $CLOUDFLARE_API_TOKEN`
**Rate limit:** 1,200 requests per 5 minutes

## Google Analytics 4

| Variable | Purpose |
|----------|---------|
| `GA4_PROPERTY_ID` | Numeric property ID (NOT measurement ID) |
| `GA4_SERVICE_ACCOUNT_KEY_PATH` | Path to service account JSON key |

**Measurement ID (site tag):** `G-E1WQ0VGVKT`
**API endpoint:** `https://analyticsdata.googleapis.com/v1beta/properties/{propertyId}:runReport`
**Auth:** OAuth2 via service account JWT
