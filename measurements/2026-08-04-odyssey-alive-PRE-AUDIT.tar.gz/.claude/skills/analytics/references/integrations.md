# Article Dates & Skill Integrations

## Article Date Extraction

Article publish dates live in MDX frontmatter:

```bash
# Pattern: content/focus/*.mdx
# Frontmatter field: date (ISO format, e.g., 2026-01-15)
```

**Extraction method:**
1. Glob `content/focus/*.mdx`
2. Read first 20 lines of each file
3. Extract `date:` and `title:` from frontmatter
4. Sort by date descending

## Integration Points

### /business
The analytics skill feeds into business assessments. When `/business` is invoked for strategic assessment, it can reference `/analytics report` data to ground projections in actual traffic trends rather than assumptions. Key metrics for business: month-over-month growth rate, audience size vs Year 1 target (50+ quality readers), and content-to-traffic conversion.

### /focus
Before planning a new article, `/analytics article-impact` on recent articles shows what topics and formats drive traffic. Informs the editorial calendar with data.

### /promote
The promote skill's `references/analytics.md` already documents API feasibility. The analytics skill is the execution layer for what promote planned. Promote can call analytics data to evaluate which promotion strategies drove the most traffic.

### /research
Research modes (groundwork, transformation) can reference analytics to prioritize topics that have shown audience interest.
