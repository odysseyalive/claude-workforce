# GA4 API Setup

The GA4 measurement ID `G-E1WQ0VGVKT` is installed on the site, but **programmatic API access requires additional setup**:

## 1. Enable the GA4 Data API
- Go to [Google Cloud Console](https://console.cloud.google.com/) and select or create a project
- Navigate to **APIs & Services > Library**
- Search for **"Google Analytics Data API"** (identifier: `analyticsdata.googleapis.com`, NOT the older `analytics.googleapis.com`)
- Click **Enable**

## 2. Create a Service Account + JSON Key
- Go to **IAM & Admin > Service Accounts** ([direct link](https://console.cloud.google.com/iam-admin/serviceaccounts))
- Click **+ CREATE SERVICE ACCOUNT**, name it (e.g., `ga4-reader`), click **CREATE AND CONTINUE**
- Skip the project role step, click **DONE**
- Click the new service account email, go to **KEYS** tab
- Click **ADD KEY > Create new key > JSON > CREATE**
- Save the downloaded `.json` file securely (never commit to repo)
- Note the service account email (e.g., `ga4-reader@your-project.iam.gserviceaccount.com`)

## 3. Grant GA4 Property Access
- Go to [Google Analytics Admin](https://analytics.google.com/) > **Admin** (gear icon)
- Select the correct property, click **Property Access Management**
- Click **+** > **Add users**
- Paste the service account email, uncheck "Notify new users by email"
- Set role to **Viewer**, click **Add**

## 4. Find the Numeric Property ID
- In GA4 Admin, click **Property Details**
- The numeric **Property ID** is at the top right (e.g., `123456789`). This is NOT the measurement ID (`G-...`)

## 5. Add to `.env.local`
```
GA4_PROPERTY_ID=123456789
GA4_SERVICE_ACCOUNT_KEY_PATH=/path/to/service-account-key.json
```
