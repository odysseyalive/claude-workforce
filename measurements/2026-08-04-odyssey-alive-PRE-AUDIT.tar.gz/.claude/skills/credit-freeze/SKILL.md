---
name: credit-freeze
description: "Credit freeze management across all three bureaus. Usage: /credit-freeze"
allowed-tools: Read, WebSearch
minimum-effort-level: medium
strictness: standard
---

# Credit Freeze

Quick reference for freezing and unfreezing credit at all three major bureaus. Free by federal law since 2018.

---

<!-- origin: user | added: 2026-03-05 | immutable: true -->
## Directives

> **"Always direct to all three bureaus -- freezing one leaves the other two open."**

*-- Added 2026-03-05, source: research session*
<!-- /origin -->

---

## Bureau Reference

### Equifax
- **Online:** https://www.equifax.com/personal/credit-report-services/credit-freeze/
- **Phone:** 800-349-9960

### Experian
- **Online:** https://www.experian.com/help/credit-freeze/
- **Phone:** 888-397-3742
- **Mail:** Experian Security Freeze, P.O. Box 9554, Allen, TX 75013

### TransUnion
- **Online:** https://www.transunion.com/credit-freeze
- **Phone:** 888-909-8872

## What You Need
- Social Security number
- Date of birth
- Current and previous addresses
- May need to create an account at each bureau

## Timing
- **Online:** Confirmation within ~1 hour
- **Phone:** Same-day processing
- **Mail:** 3-5 business days after receipt

## Troubleshooting: Online Verification Failure

If a bureau can't verify identity online:
1. Disable VPN and ad blockers, try incognito/different browser
2. Call the bureau's phone line (see numbers above)
3. Last resort: mail with copies (not originals) of government ID + proof of address

## Key Facts
- Free by federal law (no fees at any bureau)
- Does not affect credit score
- Temporary lift available online/phone (processed within 1 hour by law)
- Save PINs/confirmations from each bureau securely

---

## Project Memory

Before recommending changes to files in this skill's domain, check
`.claude/skills/awareness-ledger/ledger/index.md` for relevant records.
If matching records exist, read them and incorporate their warnings,
decisions, and patterns into your plan. Use `/awareness-ledger consult`
for full agent-assisted analysis when high-risk overlap is detected.

After resolving issues that produce institutional knowledge (root causes,
architectural decisions, recurring patterns, user flows), ask the user
if they want to record it with `/awareness-ledger record [type]`.

---

