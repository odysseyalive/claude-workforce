#!/usr/bin/env bash
# Google Contacts (People API) REST integration for the /google-contacts skill.
# Operates on the contacts of the fmeetze@gmail.com account.
# Shares OAuth credentials with /google-calendar (same GOOGLE_* triplet, both scopes).
#
# Usage:
#   gcontacts.sh check
#   gcontacts.sh search --q "name or email"
#   gcontacts.sh list   [--max N]
#   gcontacts.sh add    --name "First Last" [--email "..."] [--phone "..."] [--org "..."] [--notes "..."]
#   gcontacts.sh update --id people/cXXXX [--name "..."] [--email "..."] [--phone "..."] [--org "..."] [--notes "..."]
#   gcontacts.sh delete --id people/cXXXX
#
# Auth: delegates to gcontacts-token.sh (OAuth2 refresh-token flow, cached 55m).
# Output: one JSON document per call (People API responses passed through).
#
# IDs: a contact's id is its People API resourceName, e.g. "people/c123456789".
#      Get it from `search` or `list` (the `.resourceName` field).

set -euo pipefail

BASE="https://people.googleapis.com/v1"
FIELDS="names,emailAddresses,phoneNumbers,organizations,biographies"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

die() { echo "ERROR: $*" >&2; exit 1; }

ACCESS_TOKEN=""
ensure_token() {
  [[ -n "$ACCESS_TOKEN" ]] && return 0
  ACCESS_TOKEN="$("$SCRIPT_DIR/gcontacts-token.sh")" || die "authentication failed — see reference.md § Setup"
  [[ -n "$ACCESS_TOKEN" ]] || die "authentication returned an empty token — see reference.md § Setup"
}

api() {  # api <METHOD> <url> [json-body]  — assumes ensure_token already ran
  local method="$1" url="$2" body="${3:-}"
  if [[ -n "$body" ]]; then
    curl -sS -X "$method" -H "Authorization: Bearer $ACCESS_TOKEN" \
      -H "Content-Type: application/json" --data "$body" "$url"
  else
    curl -sS -X "$method" -H "Authorization: Bearer $ACCESS_TOKEN" "$url"
  fi
}

urlenc() { jq -rn --arg s "$1" '$s|@uri'; }

# Build a Person JSON body from flags. Only non-empty fields are included.
# Echoes, on the SAME call, the comma-list of personFields touched (for updatePersonFields)
# as a second line — caller splits on the newline.
build_person() {
  local name="$1" email="$2" phone="$3" org="$4" notes="$5"
  local given="" family=""
  if [[ -n "$name" ]]; then
    if [[ "$name" == *" "* ]]; then given="${name%% *}"; family="${name#* }"; else given="$name"; fi
  fi
  local fields=()
  [[ -n "$name"  ]] && fields+=("names")
  [[ -n "$email" ]] && fields+=("emailAddresses")
  [[ -n "$phone" ]] && fields+=("phoneNumbers")
  [[ -n "$org"   ]] && fields+=("organizations")
  [[ -n "$notes" ]] && fields+=("biographies")
  local body
  body="$(jq -n --arg g "$given" --arg f "$family" --arg e "$email" \
                --arg p "$phone" --arg o "$org" --arg n "$notes" \
    '{}
     + (if ($g != "" or $f != "") then {names:[{givenName:$g, familyName:$f}]} else {} end)
     + (if $e != "" then {emailAddresses:[{value:$e}]} else {} end)
     + (if $p != "" then {phoneNumbers:[{value:$p}]} else {} end)
     + (if $o != "" then {organizations:[{name:$o}]} else {} end)
     + (if $n != "" then {biographies:[{value:$n, contentType:"TEXT_PLAIN"}]} else {} end)')"
  printf '%s\n' "$body"
  local IFS=,; printf '%s\n' "${fields[*]:-}"
}

# ------- commands -----------------------------------------------------------
cmd_check() {
  ensure_token
  local resp count
  resp="$(api GET "$BASE/people/me/connections?personFields=names&pageSize=1")"
  if printf '%s' "$resp" | jq -e '.error' >/dev/null 2>&1; then
    die "auth/scope check failed: $(printf '%s' "$resp" | jq -r '.error.message')"
  fi
  count="$(printf '%s' "$resp" | jq -r '.totalpeople // .totalItems // 0')"
  jq -n --arg c "$count" '{auth:"ok", api:"people", contactsVisible:($c|tonumber? // 0)}'
}

cmd_search() {
  local q=""
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --q) q="$2"; shift 2 ;;
      *) die "unknown search flag: $1" ;;
    esac
  done
  [[ -n "$q" ]] || die "search requires --q \"text\""
  ensure_token
  api GET "$BASE/people:searchContacts?query=$(urlenc "$q")&readMask=$(urlenc "$FIELDS")"
}

cmd_list() {
  local max=50
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --max) max="$2"; shift 2 ;;
      *) die "unknown list flag: $1" ;;
    esac
  done
  ensure_token
  api GET "$BASE/people/me/connections?personFields=$(urlenc "$FIELDS")&pageSize=${max}&sortOrder=FIRST_NAME_ASCENDING"
}

cmd_add() {
  local name="" email="" phone="" org="" notes=""
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --name)  name="$2";  shift 2 ;;
      --email) email="$2"; shift 2 ;;
      --phone) phone="$2"; shift 2 ;;
      --org)   org="$2";   shift 2 ;;
      --notes) notes="$2"; shift 2 ;;
      *) die "unknown add flag: $1" ;;
    esac
  done
  [[ -n "$name" ]] || die "add requires --name"
  ensure_token
  local out body
  out="$(build_person "$name" "$email" "$phone" "$org" "$notes")"
  body="$(printf '%s' "$out" | sed '$d')"   # all but the last line (the fields list)
  api POST "$BASE/people:createContact" "$body"
}

cmd_update() {
  local id="" name="" email="" phone="" org="" notes=""
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --id)    id="$2";    shift 2 ;;
      --name)  name="$2";  shift 2 ;;
      --email) email="$2"; shift 2 ;;
      --phone) phone="$2"; shift 2 ;;
      --org)   org="$2";   shift 2 ;;
      --notes) notes="$2"; shift 2 ;;
      *) die "unknown update flag: $1" ;;
    esac
  done
  [[ -n "$id" ]] || die "update requires --id (resourceName, e.g. people/c123; get it from search/list)"
  ensure_token
  # People API updateContact requires the current etag for optimistic concurrency.
  local cur etag out body fields
  cur="$(api GET "$BASE/${id}?personFields=$(urlenc "$FIELDS")")"
  etag="$(printf '%s' "$cur" | jq -r '.etag // empty')"
  [[ -n "$etag" ]] || die "could not fetch contact $id (no etag): $(printf '%s' "$cur" | jq -r '.error.message // "not found"')"
  out="$(build_person "$name" "$email" "$phone" "$org" "$notes")"
  body="$(printf '%s' "$out" | sed '$d')"
  fields="$(printf '%s' "$out" | tail -n1)"
  [[ -n "$fields" ]] || die "update requires at least one field to change (--name/--email/--phone/--org/--notes)"
  # Splice the etag into the body.
  body="$(printf '%s' "$body" | jq --arg e "$etag" '. + {etag:$e}')"
  api PATCH "$BASE/${id}:updateContact?updatePersonFields=$(urlenc "$fields")" "$body"
}

cmd_delete() {
  local id=""
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --id) id="$2"; shift 2 ;;
      *) die "unknown delete flag: $1" ;;
    esac
  done
  [[ -n "$id" ]] || die "delete requires --id (resourceName, e.g. people/c123)"
  ensure_token
  local resp
  resp="$(api DELETE "$BASE/${id}:deleteContact")"
  if printf '%s' "$resp" | jq -e '.error' >/dev/null 2>&1; then
    die "delete failed: $(printf '%s' "$resp" | jq -r '.error.message')"
  fi
  jq -n --arg id "$id" '{deleted:true, resourceName:$id}'
}

main() {
  command -v jq >/dev/null 2>&1   || die "jq is required"
  command -v curl >/dev/null 2>&1 || die "curl is required"
  local cmd="${1:-}"; shift || true
  case "$cmd" in
    check)  cmd_check  "$@" ;;
    search) cmd_search "$@" ;;
    list)   cmd_list   "$@" ;;
    add)    cmd_add    "$@" ;;
    update) cmd_update "$@" ;;
    delete) cmd_delete "$@" ;;
    ""|-h|--help)
      sed -n '2,16p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//' ;;
    *) die "unknown command: $cmd (try: check, search, list, add, update, delete)" ;;
  esac
}

main "$@"
