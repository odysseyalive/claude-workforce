#!/usr/bin/env bash
# Google OAuth2 access-token helper for the /google-contacts skill.
# Self-contained but SHARES CREDENTIALS with /google-calendar: it reads the same
# GOOGLE_* triplet from .env.local. The one refresh token must be authorized for
# BOTH the calendar and contacts scopes (see reference.md § Setup).
#
# Usage:
#   TOKEN=$(./scripts/gcontacts-token.sh)
#
# Env (loaded from .env.local in the project root):
#   GOOGLE_CLIENT_ID       required
#   GOOGLE_CLIENT_SECRET   required
#   GOOGLE_REFRESH_TOKEN   required  (scope must include contacts; see reference.md § Setup)
#
# Output: the bare access token on stdout.

set -euo pipefail

TOKEN_URL="https://oauth2.googleapis.com/token"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_DIR="$(dirname "$SCRIPT_DIR")"
CACHE_FILE="$SKILL_DIR/.gcontacts-token-cache"
CACHE_TTL=3300   # 55 minutes (Google access tokens last 3600s)

load_env() {
  local env_file=""
  for candidate in \
    "$PWD/.env.local" \
    "$(git -C "$PWD" rev-parse --show-toplevel 2>/dev/null)/.env.local" \
    "$HOME/lab/odyssey-alive/.env.local"
  do
    [[ -n "$candidate" && -f "$candidate" ]] && { env_file="$candidate"; break; }
  done

  if [[ -z "$env_file" ]]; then
    echo "ERROR: .env.local not found (looked in CWD, repo root, ~/lab/odyssey-alive)" >&2
    exit 2
  fi

  # shellcheck disable=SC1090
  set -a; source "$env_file"; set +a

  local missing=()
  [[ -z "${GOOGLE_CLIENT_ID:-}" ]]     && missing+=("GOOGLE_CLIENT_ID")
  [[ -z "${GOOGLE_CLIENT_SECRET:-}" ]] && missing+=("GOOGLE_CLIENT_SECRET")
  [[ -z "${GOOGLE_REFRESH_TOKEN:-}" ]] && missing+=("GOOGLE_REFRESH_TOKEN")
  if [[ ${#missing[@]} -gt 0 ]]; then
    echo "ERROR: missing in $env_file: ${missing[*]} (see reference.md § Setup)" >&2
    exit 2
  fi
}

cached_token() {
  [[ -f "$CACHE_FILE" ]] || return 1
  local now mtime age
  now="$(date +%s)"
  mtime="$(stat -c %Y "$CACHE_FILE" 2>/dev/null || stat -f %m "$CACHE_FILE" 2>/dev/null || echo 0)"
  age=$(( now - mtime ))
  [[ "$age" -lt "$CACHE_TTL" ]] || return 1
  local tok; tok="$(cat "$CACHE_FILE")"
  [[ -n "$tok" ]] || return 1
  printf '%s' "$tok"
}

refresh_token() {
  local resp access
  resp="$(curl -sS "$TOKEN_URL" \
    -d "client_id=${GOOGLE_CLIENT_ID}" \
    -d "client_secret=${GOOGLE_CLIENT_SECRET}" \
    -d "refresh_token=${GOOGLE_REFRESH_TOKEN}" \
    -d "grant_type=refresh_token")"
  access="$(printf '%s' "$resp" | jq -r '.access_token // empty')"
  if [[ -z "$access" ]]; then
    echo "ERROR: token refresh failed: $(printf '%s' "$resp" | jq -r '.error_description // .error // .' 2>/dev/null || printf '%s' "$resp")" >&2
    exit 1
  fi
  printf '%s' "$access" > "$CACHE_FILE.tmp" && mv "$CACHE_FILE.tmp" "$CACHE_FILE"
  chmod 600 "$CACHE_FILE" 2>/dev/null || true
  printf '%s' "$access"
}

main() {
  if tok="$(cached_token)"; then
    printf '%s' "$tok"
    return 0
  fi
  load_env
  refresh_token
}

main "$@"
