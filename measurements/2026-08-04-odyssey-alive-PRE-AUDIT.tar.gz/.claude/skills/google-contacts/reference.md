# Google Contacts Skill Reference
<!-- Enforcement: LOW — REST integration contract and setup; no hook attached -->

## REST integration

Skill-local, no MCP dependency, over the **People API** (`people.googleapis.com`).
Two scripts:

- `scripts/gcontacts-token.sh` — OAuth2 refresh-token → access-token, cached 55 min in
  `.gcontacts-token-cache`. Reads the SHARED `GOOGLE_*` credentials.
- `scripts/gcontacts.sh` — the operations (`check`, `search`, `list`, `add`, `update`, `delete`).

Both self-locate `.env.local` (CWD → repo root → `~/lab/odyssey-alive`).

| Command | Returns / does |
|---------|----------------|
| `gcontacts.sh check` | `{auth, api, contactsVisible}` — verifies auth + contacts scope |
| `gcontacts.sh search --q "text"` | People API `searchContacts` JSON |
| `gcontacts.sh list [--max N]` | People API `connections.list` JSON (name-sorted) |
| `gcontacts.sh add --name [--email] [--phone] [--org] [--notes]` | Creates a contact; returns the person resource |
| `gcontacts.sh update --id people/cXXXX [--name] [--email] [--phone] [--org] [--notes]` | Fetches the etag, partial-updates (PATCH) |
| `gcontacts.sh delete --id people/cXXXX` | Deletes; returns `{deleted:true, resourceName}` |

A contact's id is its **`resourceName`** (e.g. `people/c123456789`), found in the
`.resourceName` field of `search`/`list` output.

## Account & shared auth

- **Account:** `fmeetze@gmail.com`
- **Credentials:** the SAME `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` /
  `GOOGLE_REFRESH_TOKEN` used by `/google-calendar`. The single refresh token must be
  authorized for BOTH scopes (calendar + contacts). Each skill keeps its own access-token
  cache; the credentials are shared, the scripts are not coupled.

## Setup (one-time, shared with /google-calendar)

If you already set up `/google-calendar`, you only need to make sure the refresh token
includes the **contacts** scope (re-authorize with both scopes if it doesn't).

1. **Google Cloud Console** → same project → enable the **People API**
   (`https://console.cloud.google.com/apis/library/people.googleapis.com`).
   Note: the legacy "Contacts API" is deprecated — this skill uses the People API.
2. Use the same **OAuth client ID** (Desktop app) as the calendar skill.
3. Authorize once with BOTH scopes and exchange for a **refresh token**:
   - `https://www.googleapis.com/auth/calendar`
   - `https://www.googleapis.com/auth/contacts`
4. Put the shared values in `.env.local` at the repo root (same keys the calendar skill reads):

```
GOOGLE_CLIENT_ID=...
GOOGLE_CLIENT_SECRET=...
GOOGLE_REFRESH_TOKEN=...
```

5. Verify: `bash scripts/gcontacts.sh check` should print `{auth:"ok", api:"people", …}`.

> **7-day-expiry gotcha:** while the OAuth consent screen is in **Testing**, refresh tokens
> expire after 7 days, and the expiry is fixed at issuance — publishing to Production
> *afterward* does NOT save a token minted during Testing. **Publish the app to Production
> first, then mint the refresh token** (shared with /google-calendar). A token minted while
> Testing must be re-minted after publishing.

> Setup help is available on request — ask to walk through generating the refresh token
> with both scopes.

## API endpoints used

- Token: `POST https://oauth2.googleapis.com/token` (grant_type=refresh_token)
- People API v1: `https://people.googleapis.com/v1`
  - `GET /people:searchContacts?query=&readMask=…` — search
  - `GET /people/me/connections?personFields=…` — list
  - `POST /people:createContact` — add
  - `GET /{resourceName}?personFields=…` — fetch (for the etag before update)
  - `PATCH /{resourceName}:updateContact?updatePersonFields=…` — update (etag required)
  - `DELETE /{resourceName}:deleteContact` — delete

## Local state (gitignored, never committed)

- `.gcontacts-token-cache` — cached access token (chmod 600)
