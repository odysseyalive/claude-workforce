---
name: google-contacts
description: "Search, add, update, and delete Google Contacts (People API) on fmeetze@gmail.com. Shares OAuth with /google-calendar. Modes: search, list, add, update, delete, check. Usage: /google-contacts [mode] [args]"
allowed-tools: Read, Glob, Grep, Bash
minimum-effort-level: high
---

# Google Contacts

Search and manage Francis's Google Contacts via a skill-local REST integration over
the **People API** (no MCP dependency). Operates on the contacts of `fmeetze@gmail.com`.
Shares OAuth credentials with `/google-calendar` — one refresh token, both scopes.

## Usage

```
/google-contacts [mode] [args]
```

### Modes

| Mode | Command | Description |
|------|---------|-------------|
| `search` | `/google-contacts search --q "name or email"` | Find contacts by name/email/phone |
| `list` | `/google-contacts list [--max N]` | List contacts (default 50, name-sorted) |
| `add` | `/google-contacts add --name "First Last" …` | Add a new contact |
| `update` | `/google-contacts update --id people/cXXXX …` | Update fields on an existing contact |
| `delete` | `/google-contacts delete --id people/cXXXX` | Delete a contact |
| `check` | `/google-contacts check` | Probe auth + contacts scope |

Default mode is `search` if not specified. A contact's `id` is its People API
`resourceName` (e.g. `people/c123456789`) — get it from `search`/`list`.

---

<!-- origin: user | added: 2026-06-26 | immutable: true -->
## Directives

> **"Create a Google Contacts skill on the fmeetze@gmail.com account — search, add, update, and delete contacts. Use the same OAuth token as the Google Calendar skill."**

*— Added 2026-06-26, source: user (skill creation request)*
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Create a Google Contacts skill on the fmeetze@gmail.com account — search, add, update, and delete contacts. Use the same OAuth token as the Google Calendar skill." -->
CHECKPOINT — Shared-Auth & Write-Confirmation Gate:
1. This skill uses the SAME OAuth credentials as `/google-calendar` — the shared `GOOGLE_CLIENT_ID/SECRET/REFRESH_TOKEN` in `.env.local`. The refresh token must be authorized for the contacts scope; if `check` reports a scope error, the token was generated without `https://www.googleapis.com/auth/contacts` — see reference.md § Setup.
2. READ modes (`search`, `list`, `check`) run directly — non-destructive.
3. WRITE modes (`add`, `update`, `delete`) change the real address book. Before invoking them, echo the exact contact fields (or, for delete, the name/email you resolved from the id) back to the user and get explicit confirmation. IF the user has not confirmed THIS specific write → STOP.
4. Never invent contact details. For `update`/`delete`, resolve the target via `search`/`list` first, confirm the `resourceName` is the right person, then write. Do not guess a resourceName.
<!-- END ENFORCEMENT ANNOTATION -->

---

<!-- origin: skill-builder | version: 1.0 | modifiable: true -->
## Workflow

All operations run through `scripts/gcontacts.sh`, which delegates auth to
`scripts/gcontacts-token.sh` (OAuth2 refresh-token flow, cached 55 minutes; reads the
shared `GOOGLE_*` credentials). See [reference.md](reference.md) § Setup.

### Preflight (first run / auth doubt)

Run `bash scripts/gcontacts.sh check`. It verifies the token refreshes and the
contacts scope works (lists one connection). A scope error means the shared refresh
token needs regenerating WITH the contacts scope — route the user to reference.md § Setup.

### search / list — find contacts

```bash
bash scripts/gcontacts.sh search --q "Acme"
bash scripts/gcontacts.sh list --max 50
```

Returns People API JSON. Summarize: display name, email, phone, org — and keep each
contact's `resourceName` for `update`/`delete`.

### add — create a contact

1. Collect: name (required); optional email, phone, org, notes.
2. Per the Write-Confirmation Gate, echo the fields and get explicit confirmation.
3. On confirmation:

```bash
bash scripts/gcontacts.sh add --name "Jane Doe" --email "jane@acme.com" \
  --phone "+1 555 123 4567" --org "Acme Corp" --notes "Met at the AI workshop"
```

Report the created contact's `resourceName`.

### update — change a contact

1. Find the contact with `search`/`list` and confirm its `resourceName`.
2. Collect only the fields to change (the script fetches the etag and patches just those).
3. Per the Write-Confirmation Gate, echo old → new and get explicit confirmation.
4. On confirmation:

```bash
bash scripts/gcontacts.sh update --id "people/c123456789" --phone "+1 555 999 0000"
```

Report the updated contact's `resourceName`.

### delete — remove a contact

1. Find the contact with `search`/`list`; confirm `resourceName` and that it is the right person.
2. Per the Write-Confirmation Gate, echo the name/email and get explicit confirmation.
3. On confirmation:

```bash
bash scripts/gcontacts.sh delete --id "people/c123456789"
```

Returns `{deleted:true, resourceName:…}` on success.

### Error handling

- `.env.local not found` / missing `GOOGLE_*` → reference.md § Setup (shared OAuth client + refresh token).
- `auth/scope check failed` → the shared refresh token lacks the contacts scope; regenerate it including `https://www.googleapis.com/auth/contacts`.
- Any non-2xx People API response is passed through as JSON — read `.error.message` and report it.
<!-- /origin -->

---

<!-- origin: skill-builder | version: 1.0 | modifiable: true -->
## Grounding

Before running any operation, read [reference.md](reference.md) for the shared env
keys, the contacts OAuth scope, and the People API endpoint shapes.

See [reference.md](reference.md) for setup and the REST integration contract.
<!-- /origin -->
