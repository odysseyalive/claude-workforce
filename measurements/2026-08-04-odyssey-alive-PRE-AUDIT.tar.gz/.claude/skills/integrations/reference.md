# Integrations Reference

## Credentials

All credentials are stored in `.env.local`. Never hardcode them in skill files or code.

### Apple SMTP

```bash
SMTP_HOST=smtp.mail.me.com
SMTP_PORT=587
SMTP_USER=francis@odysseyalive.com
SMTP_PASS=gidl-daiv-dzgw-jsep
CONTACT_EMAIL=francis@odysseyalive.com
```

### Apple CalDAV

```bash
CALDAV_USERNAME=francis@odysseyalive.com
CALDAV_PASSWORD=gidl-daiv-dzgw-jsep
```

Both use the same app-specific password.

**To generate a new app-specific password:**
1. Go to [appleid.apple.com](https://appleid.apple.com)
2. Sign in → Sign-In & Security → App-Specific Passwords
3. Click + to generate, name it (e.g., "Odyssey Contact Form")
