---
name: integrations
description: External service configurations for SMTP, CalDAV, social sharing, and llms.txt.
allowed-tools: Read, Glob, Grep
minimum-effort-level: medium
strictness: standard
---

# External Integrations

Configuration details for external services used by the site.

## Apple SMTP Configuration

The contact form uses Apple's SMTP server via nodemailer. Credentials are in `.env.local`.

**Grounding:** Read [reference.md](reference.md) for credentials and password generation instructions.

The server action is at `src/lib/actions/contact.ts`.

## Apple CalDAV Configuration (Calendar Booking)

The booking widget on `/contact` interfaces directly with Apple Calendar via CalDAV. Credentials are in `.env.local` (same app-specific password as SMTP).

**How it works:**
- Queries Apple Calendar for busy times via CalDAV (`https://caldav.icloud.com`)
- Shows available 30-min slots: Mon-Fri, 1-3 PM PST
- Blocks out times with existing calendar events
- Creates events directly in the primary calendar when booked
- Sends confirmation emails to both parties

**Key files:**
- `src/lib/actions/calendar.ts` — CalDAV queries, booking logic, email confirmations
- `src/components/ui/BookingWidget.tsx` — Slot picker UI

**To modify availability hours:** Edit `AVAILABLE_START` and `AVAILABLE_END` constants in `calendar.ts`.

> **Doc-vs-code sync:** The "Mon-Fri, 1-3 PM PST" window above is documentation mirroring the `AVAILABLE_START`/`AVAILABLE_END` constants in `calendar.ts` — it is not enforced by any hook. When you change those constants (or the working days), update this section to match. If the two ever disagree, `calendar.ts` is ground truth.

## Social Sharing

The site has a social sharing system with two distinct patterns:

**ShareButton Component** (`@/components/ui/ShareButton`) — For sharing page content to social networks:
- Use on shareable content pages: focus posts, case studies, about page
- Place after hero/title area AND at end of content (two placements per page)
- Props: `url` (canonical URL), `title`, `description`
- Supports: LinkedIn, X, Facebook, Reddit, WhatsApp, Telegram, Pinterest, Tumblr, GETTR, Email, Copy

**Footer Profile Links** — For linking to Odyssey Alive's social profiles:
- Located only in Footer under "Connect" heading
- These link TO our profiles, not share content FROM pages

**Dynamic OG Images** — Focus posts use `/api/og?title={title}&description={desc}` for branded preview images.

**Share utilities** — `src/lib/share.ts` provides URL generators for all platforms plus `copyToClipboard()` and `webShare()`.

### Social Sharing Protocol

**Trigger phrases:** "Add sharing to this page", "Add share buttons", "Make this shareable"

1. Read the target page and identify page type, metadata, canonical URL
2. Add ShareButton after hero/title section AND at end of main content
3. Verify OG metadata exists for rich previews

**When to use:** Focus posts, case studies, about page, project pages
**When NOT to use:** Contact page, Privacy/Terms pages, navigation-focused pages

## LLM-Friendly Content (llms.txt)

The site provides machine-readable content for LLM discovery following the [llms.txt specification](https://llmstxt.org/).

**Endpoints:**
- `/llms.txt` — Index file with curated links and descriptions
- `/llms-full.txt` — Complete content file with full text

**Implementation:**
- Dynamic routes at `src/app/llms.txt/route.ts` and `src/app/llms-full.txt/route.ts`
- Automatically includes all published focus posts and projects
- Respects scheduled publishing via `isPublishedAndScheduled()`

---

