# Content-Type Constraints

The writing kernel (voice, writing directives, sentence structure) applies to ALL content types. These are the ADDITIONAL constraints per type.

---

## Focus Article

**Source:** `.claude/skills/focus/references/constraints.md`

- Max 600 words body (1200 if `longForm: true` in frontmatter)
- Exactly 2 inline images (2-3 if long-form)
- 3-5 footnote references
- No em-dashes (hook-enforced)
- Cross-article repetition: check neighborhood before editing openings or closings

**Also read when editing:**
- `.claude/skills/focus/references/voice-checklist.md`
- `.claude/skills/focus/references/anti-patterns.md`
- `.claude/skills/focus/references/captions.md` (if editing a caption)

---

## Social Post

**Source:** `.claude/skills/promote/references/post-templates.md`

- LinkedIn Personal: 5-8 sentences, 500-900 characters
- First sentence must land above LinkedIn's "See more" fold (~140 characters)
- No "link in comments" language (hook-enforced)
- No em-dashes (hook-enforced)
- No hedging before critique
- Writing rules: `.claude/skills/promote/references/social-writing.md` (5 mechanical rules)
- Coherence rules: `.claude/skills/promote/references/social-coherence.md` (7 structural rules)

**Social posts are full-scope for edit-validator.** Unlike article edits (where the validator checks only the changed passage), a social post IS the passage. The edit-validator checks the entire post against coherence rules, not just the changed sentence.

---

## Newsletter Teaser

**Source:** `.claude/skills/newsletter/references/specs.md` (if exists)

- 300-400 words total across 3 articles
- Lead article: 2-3 sentences. Others: 1-2 sentences
- No em-dashes
- Subject line: curiosity, don't summarize
- Wit in every teaser hook

---

## Purpose & FAQ (Brief Fields)

**Source:** `.claude/skills/focus/references/llm-meta.md`

- Purpose and FAQ answers are prose. The writing kernel handles all voice decisions.
- Purpose: 2-3 declarative sentences, max 500 chars
- FAQ: 40-60 words per answer, self-contained, citation-ready
- No duplicate information between purpose and FAQ answers

**Also read when editing:**
- `.claude/skills/focus/references/llm-meta.md` (structural constraints)

---

## Presentation Slide

**Source:** `.claude/skills/present/references/slide-content.md` (if exists)

- Action titles (complete sentences)
- Bridges between slides
- No em-dashes (even in headings)
- No text baked into images
- Speaker notes in `<aside class="notes">` only
