# Edit Skill Reference

## Writing Kernel Load Order

When `/edit` is invoked in standalone mode, load these files in this order. Every file is mandatory. No shortcuts.

| Step | File | What It Provides |
|------|------|------------------|
| 1 | `.claude/skills/voice/references/profile.md` | Pronouns (they/them default), identity, humility test |
| 2 | `.claude/skills/voice/references/characteristics.md` | 10 voice characteristics |
| 3 | `.claude/skills/voice/references/vocabulary.md` | Words Francis uses vs. avoids |
| 4 | `.claude/skills/voice/references/sentence-structure.md` | Punctuation, connectors, burstiness, tangents, hedging |
| 5 | `.claude/skills/voice/references/humanity-signals.md` | AI tells to avoid, human tells to cultivate |
| 6 | `.claude/skills/voice/references/satirical-wit.md` | Wit techniques, calibration, anti-patterns |
| 7 | `.claude/skills/writing/references/directives.md` | All enforced writing directives |
| 8 | `.claude/skills/writing/reference.md` | Voice guidelines, client language rules |
| 9 | `.claude/skills/edit/references/content-type-constraints.md` | Per-type constraints for the content being edited |

**When chained from another skill:** The calling skill has already loaded steps 1-8. Skip them. Load only step 9 (content-type constraints).

## Content Type Identifiers

| Content Type | Identifier |
|--------------|------------|
| `focus-article` | Files in `content/focus/*.mdx` |
| `social-post` | Drafted social media posts (LinkedIn, X, Instagram, Facebook) |
| `newsletter-teaser` | Newsletter content for Mailchimp |
| `presentation-slide` | Files in `content/presentations/*.mdx` |
