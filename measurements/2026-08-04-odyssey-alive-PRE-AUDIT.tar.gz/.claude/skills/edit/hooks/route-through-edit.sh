#!/bin/bash
# Hook: Advise routing through /edit for prose changes to content files
# Per CLAUDE.md: "Route all content edits through /edit. When modifying body
# text in any content file or drafted text, invoke /edit to load the writing
# kernel first. Mechanical changes (typo, date, URL) are exempt."
# Scope: project content files only; advisory (exit 0), not blocking.

trap 'echo "{\"systemMessage\":\"route-through-edit.sh crashed (non-fatal)\"}" 2>/dev/null; exit 0' ERR

INPUT=$(cat 2>/dev/null) || exit 0

FILE_PATH=$(echo "$INPUT" | python3 -c 'import json,sys
try:
    d = json.load(sys.stdin)
    print(d.get("tool_input", {}).get("file_path", ""))
except Exception:
    pass' 2>/dev/null)

# Skip skill infrastructure
if echo "$FILE_PATH" | grep -q '\.claude/' 2>/dev/null; then
  exit 0
fi

# Match prose-bearing content paths
if echo "$FILE_PATH" | grep -qE '(content/(focus|presentations)/.*\.mdx$|drafts/.*\.(md|mdx|txt)$|newsletter.*\.(md|mdx)$|social.*\.(md|mdx)$)' 2>/dev/null; then
  echo '{"additionalContext":"REMINDER: /edit gateway. Per CLAUDE.md, prose edits to content files must route through /edit (loads writing kernel: voice, writing rules, content-type constraints, ledger). Exempt: mechanical changes (typos, dates, URLs). If this edit touches prose body text and /edit was not loaded, stop and invoke /edit first."}'
fi

exit 0
