---
name: browser
description: Chrome extension connection troubleshooting for browser automation issues.
allowed-tools: Read, Bash
minimum-effort-level: medium
strictness: standard
---

# Chrome Extension Connection Troubleshooting

If browser automation tools report **"Browser extension is not connected"** even though the extension is installed and Chrome is running, the native host process may be in a zombie state.

## Diagnosis

```bash
# Check if native host process is running
ps aux | grep chrome-native-host

# Check if socket exists (it should if process is healthy)
ls /tmp/claude-mcp-browser-bridge-$USER
```

**Zombie state confirmed if:** Process IS running but socket does NOT exist.

## Workaround

```bash
# 1. Kill the zombie native host process
kill $(pgrep -f chrome-native-host)

# 2. Toggle the Chrome extension to respawn the native host
#    Go to chrome://extensions
#    Find Claude extension → toggle OFF → wait 2 seconds → toggle ON
```

After toggling, browser automation should work immediately.

## Root Cause

The native host process started but never created its Unix socket listener, leaving it unable to communicate with Claude Code's MCP. This is a known bug tracked at: https://github.com/anthropics/claude-code/issues/15463

## Trigger Phrases

- "Chrome not connecting"
- "Browser extension not connected"
- "Fix Chrome connection"

---

