# Deploy Skill Reference

## Modes

| Mode | Command | Description |
|------|---------|-------------|
| **check** (default) | `/deploy` or `/deploy check` | Pre-deploy validation. Catches issues before they reach the server. |
| **push** | `/deploy push` | Commit changes, push to origin, output the server-side commands to run. |
| **verify** | `/deploy verify` | Hit the live site and confirm everything works after deploy. |
| **diagnose** | `/deploy diagnose` | Systematic troubleshooting when something's broken post-deploy. |

## Server-Side Deploy Commands

Output these commands in push mode after `git push`:

```bash
# SSH into server, then run:
cd ~/jstack/sites/odysseyalive.com/odyssey-alive
git pull
sudo rm -rf .next    # Only if Docker previously owned .next
pnpm build
cd ..
docker-compose down
docker-compose up -d

# If IndexNow is configured, submit all URLs:
curl -X GET https://odysseyalive.com/api/indexnow \
  -H "Authorization: Bearer $INDEXNOW_SECRET"
```

## JSON-LD Expected Minimums (Verify mode)

| Page | Min Blocks | Schema Types |
|------|-----------|--------------|
| Homepage | 3 | ProfessionalService, WebSite, FAQPage |
| /about | 5 | ProfessionalService, WebSite, Person, ProfilePage, BreadcrumbList |
| /services | 6+ | ProfessionalService, WebSite, FAQPage, Service, HowTo, BreadcrumbList |
| Focus articles | 5 | ProfessionalService, WebSite, Article, FAQPage, BreadcrumbList |

## Diagnostic Command Templates

### Container status
```bash
docker ps | grep odyssey
```
- Empty: container crashed or wasn't started.
- Present: container running, problem is elsewhere.

### Page response from container
```bash
curl -s -o /dev/null -w "%{http_code}" http://localhost:3002/
```
- 200: Next.js working, problem is NGINX.
- 502/empty: Next.js isn't starting. Check logs.
- Timeout: Container compiling (first request after start takes 30-60s).

### Container logs
```bash
docker logs --tail 50 $(docker ps -q --filter name=odyssey)
```
Look for: EACCES errors, missing modules, env var issues.

### Env var check
```bash
docker exec $(docker ps -q --filter name=odyssey) env | grep -E 'NODE_ENV|INDEXNOW|NEXT_PUBLIC'
```
Missing vars → need `docker-compose down && docker-compose up -d`.

### Static file check
```bash
docker exec $(docker ps -q --filter name=odyssey) ls -la /app/public/*.txt
```
Missing → file wasn't committed or `git pull` wasn't run.

### NGINX config
```bash
cat ~/jstack/nginx/conf.d/odysseyalive.com.conf
```
Verify `proxy_pass` port and `try_files` for static serving.
