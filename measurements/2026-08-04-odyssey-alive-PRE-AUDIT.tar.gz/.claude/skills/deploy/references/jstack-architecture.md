# JStack Architecture Reference
<!-- Enforcement: HIGH -- deploy verification depends on accurate paths -->

## Server Paths

| Path | Purpose |
|------|---------|
| `~/jstack/` | JStack root |
| `~/jstack/sites/odysseyalive.com/` | Site deployment root |
| `~/jstack/sites/odysseyalive.com/docker-compose.yml` | Container orchestration |
| `~/jstack/sites/odysseyalive.com/odyssey-alive/` | Git checkout of odyssey-alive repo |
| `~/jstack/sites/odysseyalive.com/odyssey-alive/.env.local` | Runtime env vars (read by container) |
| `~/jstack/sites/odysseyalive.com/odyssey-alive/public/` | Static files served by Next.js |
| `~/jstack/sites/odysseyalive.com/odyssey-alive/.next/standalone/` | Next.js standalone build output |
| `~/jstack/nginx/conf.d/odysseyalive.com.conf` | NGINX site config |
| `~/jstack/nginx/certbot/conf/` | SSL certificates |

## Docker Compose Configuration

The site's `docker-compose.yml` defines:

```yaml
services:
  odyssey-alive:
    build:
      context: .
      dockerfile: Dockerfile
    restart: unless-stopped
    ports:
      - "3002:3000"      # Host 3002 → Container 3000
    volumes:
      - ./odyssey-alive:/app
      - ./odyssey-alive/public:/app/.next/standalone/public
      - ./odyssey-alive/.next/static:/app/.next/standalone/.next/static
    env_file:
      - ./odyssey-alive/.env.local
    environment:
      - NODE_ENV=production
    networks:
      - jstack_default
```

Key details:
- Container port 3000 exposed as host port 3002
- Source code mounted at `/app` (not copied)
- `public/` and `.next/static/` explicitly mounted into standalone paths
- `env_file` reads from `.env.local` (loaded at container creation, NOT on restart)
- `NODE_ENV=production` hardcoded in environment section

## NGINX Routing

NGINX proxies all requests to the Next.js container:

```nginx
location / {
    proxy_pass http://odyssey-alive:3000;
    proxy_set_header Host $host;
    ...
}
```

Static files in `public/` are served by Next.js directly (not NGINX). This means any file in `public/` at the repo root will be served at the site root URL.

## Deploy Sequence (correct order)

```bash
# On server:
cd ~/jstack/sites/odysseyalive.com/odyssey-alive
git pull                          # Get latest code
sudo rm -rf .next                 # Clear Docker-owned build artifacts
pnpm build                        # Rebuild (generates .next/standalone/)
cd ..
docker-compose down               # Stop and remove container
docker-compose up -d              # Create fresh container with new env
```

**Never use `docker-compose restart`** for deploys that include env var changes or build changes. Restart reuses the existing container (old env vars, old mounts).

## Environment Variable Loading

| Method | When Env Vars Load | Use Case |
|--------|-------------------|----------|
| `docker-compose restart` | Never reloads | Only for crash recovery |
| `docker-compose down && up -d` | At container creation | Env var changes, new code |
| `docker-compose up -d --build` | At image build + creation | Dockerfile changes |

---
*JStack architecture reference for /deploy skill. Updated 2026-03-25.*
