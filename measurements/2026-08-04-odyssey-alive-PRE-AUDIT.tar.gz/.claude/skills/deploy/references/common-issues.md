# Common Deployment Issues
<!-- Enforcement: HIGH -- diagnose workflow references this -->

Known failure patterns encountered during odysseyalive.com deployments, with root causes and fixes.

---

## 1. EACCES: permission denied on .next/standalone/public

**Symptom:** `pnpm build` fails with:
```
Error: EACCES: permission denied, rmdir '.next/standalone/public'
```

**Root cause:** Docker ran as a different user and created `.next/` with Docker-owned permissions. The build process (running as jarvis) can't delete Docker's directories.

**Fix:**
```bash
sudo rm -rf .next
pnpm build
```

**Prevention:** Always `docker-compose down` before rebuilding. The volume mount on `.next/standalone/public` creates a lock while the container is running.

---

## 2. Env vars not loading after deploy

**Symptom:** API endpoints return unexpected errors (401, 403, 500) despite `.env.local` having correct values. `process.env.VARIABLE` is undefined in the running container.

**Root cause:** `docker-compose restart` reuses the existing container with the OLD environment. Only `docker-compose down && up -d` creates a fresh container that reads the current `.env.local`.

**Fix:**
```bash
cd ~/jstack/sites/odysseyalive.com
docker-compose down
docker-compose up -d
```

**Prevention:** Never use `./jstack.sh deploy` or `docker-compose restart` when env vars have changed. Always down+up.

---

## 3. Static file returns JSON 404 instead of file content

**Symptom:** A file exists in `public/` (e.g., IndexNow key `.txt` file) but the live URL returns `{"error":"Not found"}` instead of the file contents.

**Root cause:** Either:
- The file wasn't committed to git and therefore isn't on the server
- An API route is intercepting the request before Next.js serves the static file
- The `public/` directory on the server doesn't have the file (git pull not run)

**Diagnosis:**
1. Check git: `git status public/` and `git check-ignore public/filename`
2. Check server: `ls -la ~/jstack/sites/odysseyalive.com/odyssey-alive/public/filename`
3. Check for interfering routes: grep for route files that might match the URL pattern

**Fix:** Commit the file, push, git pull on server, down+up.

---

## 4. Gateway timeout (502/504) after deploy

**Symptom:** Site returns 502 or 504 for 30-60 seconds after container start.

**Root cause:** Next.js standalone compiles pages on first request. The first hit after a fresh container start triggers compilation, which can take 30-90 seconds depending on page complexity.

**Not a bug.** Wait 60 seconds and try again. If it persists beyond 2 minutes, check container logs:
```bash
docker logs --tail 50 $(docker ps -q --filter name=odyssey)
```

---

## 5. "No containers to restart" on deploy

**Symptom:** `./jstack.sh deploy odysseyalive.com` says "No containers to restart."

**Root cause:** The container was previously stopped with `docker-compose down` and never brought back up.

**Fix:**
```bash
cd ~/jstack/sites/odysseyalive.com
docker-compose up -d
```

---

## 6. Schema present locally but missing on live site

**Symptom:** JSON-LD validates on localhost but evaluators report "no schema" on production.

**Root cause (usually not a real issue):** Most web evaluation tools (Jina Reader, markdown extractors) strip `<script>` tags and cannot see JSON-LD. The schema IS there.

**Verify with curl:**
```bash
curl -s https://odysseyalive.com/services | grep -c 'application/ld+json'
```
Should return a number > 0.

**Verify with validators:**
- Google Rich Results Test: https://search.google.com/test/rich-results
- Schema.org Validator: https://validator.schema.org

These render JavaScript and parse the full DOM, unlike markdown extractors.

---

## 7. Build succeeds locally but fails on server

**Symptom:** `pnpm build` works on your machine but fails on the server.

**Common causes:**
- Different Node.js version (check with `node -v` on both)
- Missing dependencies (run `pnpm install` on server)
- Stale `.next/` cache (run `sudo rm -rf .next`)
- Missing env vars that are needed at build time (`NEXT_PUBLIC_*` vars are baked in during build)

---
*Common deployment issues for /deploy skill. Updated 2026-03-25.*
