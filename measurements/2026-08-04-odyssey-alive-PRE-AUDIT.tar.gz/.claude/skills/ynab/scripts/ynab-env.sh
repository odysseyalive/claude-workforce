#!/usr/bin/env bash
# YNAB credential loader for the /ynab skill.
# Reads the token, budget ID, and account ID from .env.local and exports them
# as TOKEN / BUDGET_ID / ACCOUNT_ID — the variable names the curl examples use.
#
# Designed to be SOURCED at the top of a YNAB Bash command:
#   source .claude/skills/ynab/scripts/ynab-env.sh
#   curl -s "https://api.ynab.com/v1/budgets/$BUDGET_ID/accounts" \
#     -H "Authorization: Bearer $TOKEN" \
#     -H "User-Agent: ClaudeCode-YNAB/1.0 (francis@odysseyalive.com)"
#
# Env (loaded from .env.local in the project root):
#   YNAB_TOKEN        required
#   YNAB_BUDGET_ID    required
#   YNAB_ACCOUNT_ID   optional (only the account-scoped workflows need it)
#
# Self-locates .env.local: CWD → repo root → ~/lab/odyssey-alive.
# On error, prints to stderr and returns non-zero (safe to source).

__ynab_load_env() {
  local env_file=""
  local candidate
  for candidate in \
    "$PWD/.env.local" \
    "$(git -C "$PWD" rev-parse --show-toplevel 2>/dev/null)/.env.local" \
    "$HOME/lab/odyssey-alive/.env.local"
  do
    [[ -n "$candidate" && -f "$candidate" ]] && { env_file="$candidate"; break; }
  done

  if [[ -z "$env_file" ]]; then
    echo "ERROR: .env.local not found (looked in CWD, repo root, ~/lab/odyssey-alive)" >&2
    return 2
  fi

  # shellcheck disable=SC1090
  set -a; source "$env_file"; set +a

  local missing=()
  [[ -z "${YNAB_TOKEN:-}" ]]     && missing+=("YNAB_TOKEN")
  [[ -z "${YNAB_BUDGET_ID:-}" ]] && missing+=("YNAB_BUDGET_ID")
  if [[ ${#missing[@]} -gt 0 ]]; then
    echo "ERROR: missing in $env_file: ${missing[*]} (see references/auth.md § Setup)" >&2
    return 2
  fi

  # Export under the names the auth.md curl snippets expect.
  export TOKEN="$YNAB_TOKEN"
  export BUDGET_ID="$YNAB_BUDGET_ID"
  export ACCOUNT_ID="${YNAB_ACCOUNT_ID:-}"
}

__ynab_load_env
