---
name: ynab
description: YNAB budget management, transaction categorization, payee cleanup, and API integration.
allowed-tools: Read, Glob, Grep, Bash, Task
minimum-effort-level: high
strictness: standard
---

# YNAB Budget Integration

**Trigger phrases:** "Budget", "YNAB", "Check my spending", "How much did I spend", "Import transactions", "Update budget", "Budget check-in", "Let's do YNAB", "Clean up payees", "Merge payees", "Fix payee names", "Reset budget", "Match assigned to spent", "Zero out balances"

Rules for connecting to Francis's YNAB budget via the API.

## Workflows

| Workflow | Command | Description |
|----------|---------|-------------|
| **Uncategorized** | `/ynab` (default) | Categorize transactions, allocate funds |
| **Payee Cleanup** | `/ynab cleanup` | Merge messy bank payee names |
| **Budget Reset** | `/ynab reset` | Set Assigned = Spent for all categories |
| **14-Day Bills** | `/ynab bills` | Fund bill categories for next 14 days |

**Grounding:** Read [references/workflows.md](references/workflows.md) for detailed step-by-step instructions for each workflow.

---

<!-- origin: user | added: 2026-02-03 | immutable: true -->
## Directives

> **Pre-approved operations:** All YNAB API calls (transactions, categories, accounts, budgets) are pre-approved. Do not ask for permission to run these queries.

> **User-Agent header required:** ALL API calls MUST include the header `-H "User-Agent: ClaudeCode-YNAB/1.0 (francis@odysseyalive.com)"`. Without this, Cloudflare may block requests and cause 401 errors.

> **Date confirmation required:** If the user doesn't supply the current date when querying transactions, ask for it. API data may lag behind the UI by several hours, so knowing the actual date helps identify missing recent transactions.
<!-- /origin -->

---

## Grounding (Enforced via Agents)

Before using any category ID, payee mapping, or budget target:

**Option 1: Spawn Specialized Agent (Recommended)**

| Task | Agent | Prompt Template |
|------|-------|-----------------|
| Look up a category ID | ID Lookup | "Look up [category name] in references/categories.md. Return only the ID." |
| Match payee to category | Matcher | "Match payee '[payee name]' to a category using references/categories.md rules." |
| Calculate upcoming bills | Bills Calculator | "Calculate bills due from [start date] through [end date]." |

Use the Task tool with:
```
subagent_type: "general-purpose"
prompt: "Read .claude/skills/ynab/agents/[agent-name]/AGENT.md for instructions,
        then [specific task]. Return structured result."
```

Only proceed if agent returns FOUND/MATCH with a valid result.

**Option 2: Manual Lookup**

1. Read the appropriate file in references/
2. State: "I will use [ID/name] for [purpose], found under [section]"

**Why use agents?** Agents have `context: none`, meaning they cannot use memory or guess. IDs and matches are guaranteed to come from the file, preventing hallucinated values that cause API failures.

See [references/](references/) for all IDs, mappings, schedules, and categorization rules:
- [references/categories.md](references/categories.md) — Category IDs and categorization rules
- [references/payees.md](references/payees.md) — Common payee mappings
- [references/bills.md](references/bills.md) — Recurring bills schedule and budget targets
- [references/auth.md](references/auth.md) — Authentication and API calls

### Available Agents

| Agent | Location | Purpose |
|-------|----------|---------|
| ID Lookup | [agents/id-lookup/AGENT.md](agents/id-lookup/AGENT.md) | Look up category IDs, payee mappings |
| Matcher | [agents/matcher/AGENT.md](agents/matcher/AGENT.md) | Match payees to categories with confidence |
| Bills Calculator | [agents/bills-calculator/AGENT.md](agents/bills-calculator/AGENT.md) | Calculate bills due in date window |

---

## Authentication

**Grounding:** Read [references/auth.md](references/auth.md) for API token, budget ID, account ID, and shell setup instructions.

**API Notes:**
- Amounts in YNAB API are in **milliunits** (multiply dollars by 1000)
- Dates use ISO format: `YYYY-MM-DD`
- Rate limit: 200 requests/hour
- Negative amounts = outflows, positive = inflows
- Always use explicit budget ID, never `/budgets/default`
- Always use explicit month `/months/YYYY-MM-01`, never `/months/current`
- Always include User-Agent header (see Directives)

---

## Post-Action Capture

After resolving budget categorization decisions or recurring transaction mappings, suggest recording the decision in the awareness ledger (DEC record) so it persists across sessions. Never auto-record — ask the user first.

