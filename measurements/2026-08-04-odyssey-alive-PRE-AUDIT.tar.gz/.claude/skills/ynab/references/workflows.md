# Workflow Procedures

## Uncategorized Transactions Workflow

When the user asks to assign available funds, budget, or allocate money:

**Step 1: Confirm Current Date**
Ask for today's date if not provided (API may lag behind UI).

**Step 1b: Check Account Balance**
Always query the main account balance before allocating or rebalancing. Use account ID from [auth.md](auth.md).

**Step 2: Query Uncategorized Transactions**
Query `GET /budgets/$BUDGET/transactions?type=uncategorized` and format as `{id, date, payee_name, amount, type}`.

**Step 3: Categorize Expenses First (Use Matcher Agent)**

For each uncategorized EXPENSE (negative amount):

Spawn the Matcher Agent:
```
Task tool with subagent_type: "general-purpose"
Prompt: "Read .claude/skills/ynab/agents/matcher/AGENT.md for instructions,
        then match these payees to categories:
        [list of payee names]
        Return category and ID for each."
```

Then:
- For HIGH/MEDIUM confidence matches: Apply via API `PATCH /transactions/{id}` with `category_id`
- For UNKNOWN payees: Ask user which category before applying

**Step 4: Categorize Deposits Second**
For each uncategorized DEPOSIT (positive amount):
- All income → Inflow: Ready to Assign (look up ID via agent or [categories.md](categories.md))
- Apply via API: `PATCH /transactions/{id}` with `category_id`

**Step 5: Handle API Sync Gaps**
If user reports transactions visible in UI but not in API:
- List what the user needs to categorize manually in UI
- Provide exact category names for each transaction
- Wait for confirmation before proceeding

**Step 6: Get Ready to Assign Balance**
Query `GET /budgets/$BUDGET` and extract `.data.budget.months[0].to_be_budgeted / 1000`.

**Step 7: Allocate Based on Priority Rules**
1. **Cover all overspent (negative balance) categories first**
2. **Check recurring bills schedule for next 14 days** (see [bills.md](bills.md))
3. **Fund upcoming bills**
4. **Then follow priority order:** Bills → Groceries → Transportation → Everything else
5. **Leave small buffer** ($20-50 in Ready to Assign)

**Step 8: Payee Cleanup (Optional)**
After categorizing, run payee cleanup to merge messy bank names. See Payee Cleanup Workflow below.

**API Note:** Use explicit month format `/months/YYYY-MM-01` instead of `/months/current`.

---

## Payee Cleanup Workflow

**Trigger phrases:** "Clean up payees", "Merge payees", "Fix payee names"

The YNAB API doesn't have a direct "merge payees" endpoint. Achieve merging by:
1. Set `payee_id: null` and `payee_name: "Clean Name"` on the transaction
2. YNAB resolves to an existing payee with that name
3. The `import_payee_name` is preserved for future auto-matching

Use `GET /budgets/$BUDGET/payees` to list payees, then `PUT /budgets/$BUDGET/transactions/$TXN_ID` with `{"transaction":{"payee_id":null,"payee_name":"Clean Name"}}`.

**Rate limit:** Add `sleep 0.3` between calls. YNAB allows 100 requests/minute.

See [payees.md](payees.md) for standard clean names.

---

## Budget Reset Workflow

**Trigger phrases:** "Reset budget", "Match assigned to spent", "Zero out balances", "Start fresh"

Use this workflow to align YNAB with reality by setting Assigned = Spent for all categories. This zeros out all Available balances and leaves remaining funds in Ready to Assign.

**When to use:**
- Budget has drifted from reality (over-assigned relative to actual funds)
- Starting fresh mid-month
- Ready to Assign doesn't match actual available cash

**Step 1: Get All Category Activity**
Query `GET /budgets/$BUDGET/months/YYYY-MM-01` and extract categories with non-zero activity: `name|id|activity|budgeted`.

**Step 2: Set Assigned = |Activity| for Each Category**
For categories with spending (negative activity), set budgeted to the absolute value via `PATCH /months/YYYY-MM-01/categories/$CATEGORY_ID`.

**Step 3: Zero Out Categories with No Activity**
For categories with $0 activity, set budgeted to 0.

**Step 4: Verify Ready to Assign**
After reset, Ready to Assign should approximately match account balance.

**Result:** All category Available balances = $0. Ready to Assign = actual unallocated cash. YNAB now reflects reality.

**Note:** The monthly budget targets remain the *plan*. This workflow aligns YNAB with what's actually been spent and available.

---

## 14-Day Bills Lookahead Workflow

**Trigger phrases:** "Update budget", "Budget check-in", "Let's do YNAB"

This workflow funds bill categories for the next 14 days. All other categories (Groceries, Dining, Shopping, etc.) are left for manual assignment by the user.

**Step 1: Confirm Current Date**
**REQUIRED:** If the current date is not provided, ASK before proceeding. The 14-day window depends on knowing the exact date.

**Step 2: Calculate 14-Day Window**
From the current date, calculate: `today` through `today + 14 days`.

Example: If today is January 23, the window is January 23 through February 6.

**Step 3: Get Current Activity for Bill Categories ONLY**
Bill categories: Rent, Auto loans, Utilities, Insurance, Other subscriptions. Look up IDs via agent or [categories.md](categories.md).

Query current activity for these categories only.

**Step 4: Identify ALL Bills Due in 14-Day Window (Use Bills Calculator Agent)**

Spawn the Bills Calculator Agent:
```
Task tool with subagent_type: "general-purpose"
Prompt: "Read .claude/skills/ynab/agents/bills-calculator/AGENT.md for instructions,
        then calculate bills due from [start date] through [end date].
        Return totals by category with category IDs."
```

The agent handles:
- Month boundary crossings
- Monthly recurring bills (each month is a NEW charge)
- Periodic bills (quarterly, bi-monthly)
- Summing by category

**Step 5: Calculate New Assigned for Each Bill Category**
Using the agent's output, for each bill category:
```
New Assigned = |Current Activity| + Agent's "Total Due" for that category
```

**Step 6: Update Bill Categories via API**
Use `PATCH /budgets/$BUDGET/months/YYYY-MM-01/categories/$CATEGORY_ID` with `{"category":{"budgeted":AMOUNT_IN_MILLIUNITS}}`.

**Step 7: Report Results**
```
## 14-Day Bills Lookahead: [start date] - [end date]

### Upcoming Bills (next 14 days)
| Date | Description | Amount | Category |
|------|-------------|--------|----------|
| [date] | [bill] | $X.XX | [category] |
...

### Bill Categories Updated
| Category | Activity | + Upcoming | = Assigned |
|----------|----------|------------|------------|
| 🗓️ Subscriptions | $X | $X | $X |
| 📄 Insurance | $X | $X | $X |
| ⚡️ Utilities | $X | $X | $X |
...

### Ready to Assign: $X,XXX.XX
→ Available for manual allocation to other categories
```

**Note:** Other categories (Groceries, Dining, Shopping, Hobbies, etc.) are NOT touched by this workflow. The user assigns those manually.

---

## Discovered Issues Log

- **401 on transactions but not accounts** — Turned out to be a fully revoked token, not partial permissions. The earlier "successful" account calls were cached at Cloudflare edge. YNAB Personal Access Tokens are all-or-nothing; there are no granular scopes. If you get 401 on any endpoint, the token is dead. (2026-01-21)
- **jq null iteration errors** — When API returns error JSON instead of expected data structure, `jq '.data.transactions[]'` fails with "Cannot iterate over null". Always check for errors first: `jq 'if .error then . else .data end'` or use `// empty` fallback. (2026-01-21)
- **API sync delay for pending transactions** — Newly imported pending transactions appear in the YNAB UI before they're available via API. The account balances (cleared/uncleared) update in real-time, but the actual transaction records lag behind. If a user reports pending transactions not showing in API results, check the UI — there may be a sync delay of several hours. **This is a hard limitation — you cannot categorize transactions that haven't synced to the API. The user must do these manually in the UI.** (2026-01-21)
- **Rate limit during bulk payee cleanup** — YNAB enforces 100 requests/minute. During payee cleanup of ~50+ payees with multiple transactions each, we hit 429 Too Many Requests. Add `sleep 0.3` between API calls and batch operations. If rate limited, wait 60+ seconds before resuming. (2026-01-21)
- **Payee merge via transaction update** — YNAB API has no direct "merge payees" endpoint, but setting `payee_id: null` and `payee_name: "Clean Name"` on a transaction causes YNAB to resolve to an existing payee with that name. This effectively merges payees. The original bank description is preserved in `import_payee_name` for future auto-matching. (2026-01-21)
- **Phone app Home Page sync lag** — The YNAB phone app's Home Page can show stale uncategorized counts even when transactions are actually categorized. The actual Budget and Accounts views show correct data. Fix: kill app, reopen, pull to refresh. Or log out and back in for a full re-sync. (2026-01-21)
- **Shell escaping breaks jq and curl** — The token contains a hyphen that can break bare `$TOKEN` expansion. Fix: `source .claude/skills/ynab/scripts/ynab-env.sh` (loads from `.env.local` and exports a quoted `$TOKEN`/`$BUDGET_ID`/`$ACCOUNT_ID`), then reference them quoted. Also, jq's `!=` operator gets shell-escaped causing syntax errors. Fix: use `select(.x < 0 or .x > 0)` instead of `select(.x != 0)`. (2026-01-23, loader added 2026-06-27)
- **`/budgets/default` returns 404** — Must use explicit budget ID. The `default` alias doesn't work reliably. (2026-01-23)
- **Token appears revoked after 24 hours** — Likely caused by Cloudflare blocking requests without a proper User-Agent header. After repeated API calls with curl's default `curl/X.X` User-Agent, Cloudflare may flag traffic as automated/suspicious and block the token. Fix: Always include `-H "User-Agent: ClaudeCode-YNAB/1.0 (francis@odysseyalive.com)"` in all curl calls. (2026-01-23)

---

## Known Issues

- **Duplicate imports:** Watch for duplicate transactions when both bank feed and manual import are active. Check for entries with same amount/date but different payee formats (e.g., "Fred Meyer" vs "FRED-MEYER #0377").
- **Spectrum categorization:** All Spectrum charges (internet, mobile) go to ⚡️ Utilities, not TV/Phone/Internet.
- **Apple charges:** All Apple.com/Bill charges go to 🗓️ Other subscriptions, not Music.
- **YouTube Premium:** Goes to 🗓️ Other subscriptions, not TV streaming.
