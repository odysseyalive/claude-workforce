# Common Payee Mappings

| Messy Pattern | Clean Name |
|---------------|------------|
| `AMAZON MKTPL*...`, `AMAZON.COM*...` | Amazon |
| `AMAZON PRIME*...` | Amazon Prime |
| `TST* PELICAN BREWING`, `PELICAN BREWING COMPA` | Pelican Brewing |
| `CENTER MARKET #34`, `CENTER MARKET 27` | Center Market |
| `FRED-MEYER #0377` | Fred Meyer |
| `GOOGLE YOUTUBE...`, `GOOGLE *YOUTUBE` | YouTube Premium |
| `FACEBK *...` | Facebook |
| `SQ *FIVE RIVERS COFFE` | Five Rivers Coffee |
| `SQ *THE ORIGINAL PRON` | Pronto |
| `SQ *BAHAMA MAMA'S BEA` | Bahama Mama's |
| `SQ *OFFSHORE GRILL` | Offshore Grill |
| `SQ *WILD MANZANITA LL` | Wild Manzanita |
| `SQ *THE LONELY CRAB R` | The Lonely Crab Record Shop |
| `SQ *URBAN GERMAN WURS` | Urban German |
| `CHEWY.COM` | Chewy |
| `CLAUDE.AI SUBSCRIPTIO` | Claude AI |
| `TILLAMOOK GROCERY OUT`, `TILLAMOOK GROCERY OUTL` | Tillamook Grocery Outlet |
| `TILLAMOOK SPORTING GO` | Tillamook Sporting Goods |
| `TILLAMOOK PUD 3` | Tillamook PUD |
| `LS FOUR PAWS ON THE B` | Four Paws |
| `NEHALEM ANIMAL HEALIN` | Nehalem Animal Healing |
| `P.SKOOL.COM/CWGVV` | Skool |
| `LINKEDINPRE *...` | LinkedIn |
| `ZOOM.COM 888-799-9666` | Zoom |
| `DONATE.JW.ORG-CCJW` | JW.org |
| `DARRYL DAVIS SEMINARS` | Darryl Davis |
| `ACI*COLUMBIA CREDIT U` | Columbia Credit Union |
| `PREAUTHORIZED ACH CREDIT Square Inc...` | Square |
| `R SANITARY SERVICE` | R Sanitary Service |
| `EL TRIO LOCO 3` | El Trio Loco |
| `CORRAL GRILL & TAPHOU` | The Corral Grill |
| `LS T SPOT INC` | T Spot |
| `ROSENBERG BUILDERS SU` | Rosenberg Builders |
| `VISA AUTHORIZATION REALTOR...` | Realtor Association |
| `SPECTRUM MOBILE` | Spectrum Mobile |
| `FMG*ADDINS#...` | FMG Life Insurance |
| Long `ATM DEBIT POS PURCHASE TERMINAL...` strings | Extract merchant name from middle |
