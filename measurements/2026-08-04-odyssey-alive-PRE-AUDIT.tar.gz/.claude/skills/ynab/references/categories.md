# Category IDs & Categorization Rules

## Category IDs

### Bills
| Category | ID |
|----------|-----|
| 🏠 Rent | 8930fa2f-cf69-4eff-954b-aaea31bf0f8e |
| ⚡️ Utilities | cbe57e95-9a9c-42c4-acd1-9eac90e596a0 |
| 💻 TV, phone and internet | 14835120-b2a3-47ab-a352-ea37eefb4075 |
| 📄 Insurance | f044d79f-a902-415b-93ee-adbe9de839e2 |
| 🎓 Student loans | 00e255c7-2a7a-41b4-a738-c3d2fc0d3dbc |
| 🚗 Auto loans | b21a234f-bfaf-4be0-bedf-954d41cce682 |
| 🗓️ Other subscriptions | e2bb8f89-b786-4d9c-90f8-aca7c2e08a91 |

### Needs
| Category | ID |
|----------|-----|
| 🛒 Groceries | 20df1075-d833-4701-bd36-48af716e3104 |
| 🛞 Transportation | 9e7e259c-bc6d-4915-a6fc-e7f729287f7d |
| 🚗 Car maintenance | 49cad11d-71ea-49a2-a3df-7425c57fa01f |
| 📚 Educational savings | 43d4d6ea-746a-4872-a465-03f004c5c93c |
| 🐾 Pets | 7b2a7b41-0418-4ec2-96e6-096704848894 |
| 🐾️ Vet visits | 4d07c7aa-bb7e-4037-9a30-a7c66080add7 |
| 👖 Clothing | a9f16ee5-e311-4163-8658-d05e393ab002 |
| 💸 Taxes or other fees | 63d5c5bf-86c2-4660-ac72-ae8905106ed4 |
| 😌 Emergency fund | ecbb3383-49c6-4df9-b5e9-563403a67d1b |
| 💰 Retirement or investments | a6319fd6-cada-4a45-a1ca-f59abe3b43c9 |

### Wants
| Category | ID |
|----------|-----|
| 🍽️ Dining out | 8c606c51-11d9-41ca-9d15-cb86b25069ce |
| 🍿 Entertainment | 0e663c98-81a8-44e3-b1c6-c014333d3d59 |
| 🪴 Hobbies | 7ad73aeb-0a0b-41ad-af7d-3967e5f4add2 |
| 💖️ Charity | 0a8dd2a6-49f3-4321-829c-cd6127515e40 |
| 🎁 Gifts | da45a3f2-afd5-4e56-8c0c-346b0a1737ff |
| 🛍️ Shopping | 29a7e811-9664-49bb-b78b-13031bffab85 |
| ✈️ Vacation Fund | b28758e6-6733-48fb-b82e-f382fa1f6efc |
| ❗️ Stuff I forgot to plan for | 7566633c-b6fc-4e12-9d83-bb30a1901634 |

### Internal
| Category | ID |
|----------|-----|
| Inflow: Ready to Assign | 9bc22473-3972-4e59-bc09-7fc7130268ca |
| Uncategorized | 948b119e-6a3c-4609-9760-4389c50d11ed |

---

## Transaction Categorization Rules

### Groceries (🛒)
Fred-Meyer, Center Market, Tillamook Grocery, Natural Grocers, Tillamook Co-op, Safeway, Dollar General, Garibaldi Deli, Tillamook Meat, South Prairie Market, Trader Joe's

### Transportation/Gas (🛞)
Chevron, Shell, Fred M Fuel

### Dining Out (🍽️)
Matt's BBQ, Prost, McMenamins, Pelican Brewing, Fish Peddler, Urban German, Five Rivers Coffee, Pronto, Lonely Crab, Tie Breaker, Corral Grill, Bahama Mama's, Offshore Grill, Wild Manzanita, El Trio Loco, Trio, Taqueria Mendez, Bay City Kitchen, Bunker Grill, Sarasota's

### Subscriptions (🗓️ Other subscriptions)
Claude.AI, Anthropic, Zoom, GitHub, Hetzner, Cloudflare, Squarespace, Zoho, SkySlope, Skool, Google Workspace, Google GSuite, Amazon Prime, Patreon, Nutrafol, HP Instant Ink, Rocket Money, Darryl Davis, McEvoy, Mailchimp, LinkedIn, Realtor Association, Apple.com/Bill (all), YouTube Premium, Readwise, Grammarly, DigiSigner, OpenRouter, Facebook/Meta Ads, useai.substack

### Utilities (⚡️)
Tillamook PUD, R Sanitary Service, City of Rockaway Beach, Spectrum (all variations), Spectrum Mobile

### Insurance (📄)
Artisan & Truck, State Farm, FMG*ADDINS (life insurance)

### Auto Loan (🚗 Auto loans)
Columbia Credit Union, ACI*COLUMBIA CREDIT

### Pets (🐾)
Chewy, Four Paws

### Vet (🐾️ Vet visits)
Nehalem Animal Healing

### Charity (💖️)
Donate.jw.org

### Shopping (🛍️)
Amazon (non-Prime purchases), eBay, PayPal, Goorin Bros

### Hobbies (🪴)
Tillamook Sporting Goods, Rosenberg Builders

### Entertainment (🍿)
OR Liquor Store, Ticket Tomato, Ticketmaster, McMenamins Concerts, Allianz Event Ins

### Educational savings (📚)
Lane Enrollment

### Bank Fees (💸 Taxes or other fees)
Overdraft Fee, Service Charge, Maintenance Fee, EFT Service Charge
