# Recurring Bills & Budget

## Recurring Bills Schedule

**Cash flow warning:** Income averages $5-6k/month, fixed expenses are ~$7.9k. Time bill payments carefully around Square deposits.

### Fixed Monthly Bills

| Payee | Amount | Due Date | Category |
|-------|--------|----------|----------|
| Artisan & Truck Ins | $90.50 | 5th-7th | 📄 Insurance |
| Columbia Credit Union (Auto) | $645.87 | 11th-13th | 🚗 Auto loans |
| Spectrum Mobile | $260-305 | 11th-14th | ⚡️ Utilities |
| Rent (Check) | $2,300 | 10th | 🏠 Rent |
| Tillamook PUD | $175-325 | ~16th | ⚡️ Utilities |
| Spectrum (Internet/TV) | $100 | ~16th | ⚡️ Utilities |

### Periodic Bills

| Payee | Amount | Due Date | Frequency | Category |
|-------|--------|----------|-----------|----------|
| R Sanitary Service | ~$110-130 | ~20th | Every 2 months | ⚡️ Utilities |
| City of Rockaway Beach | ~$105 | ~9th | Every 2 months | ⚡️ Utilities |
| State Farm | $124 | ~5th | Annual (January) | 📄 Insurance |

### Monthly Subscriptions (All → 🗓️ Other subscriptions)

| Payee | Amount | Due Date |
|-------|--------|----------|
| Apple.com/Bill (all) | ~$60-65 | 1st |
| Claude.AI (Anthropic) | $200.00 | 2nd |
| Google Workspace (Odyssey) | $26.40 | 1st-2nd |
| Amazon Prime | $14.99 | 2nd |
| Realtor Association | $150.00 | 2nd |
| Hetzner Online | $35.39 | 6th |
| Rocket Money | $9.00 | 7th |
| GitHub | $5.00 | 8th |
| Zoom | $16.99 | 9th |
| Patreon (various) | ~$37-40 | 10th-11th |
| Squarespace | $33.00 | 14th |
| SkySlope | $15.99 | 14th |
| Skool | $97.00 | 15th |
| Nutrafol | $79.00 | 18th |
| DigiSigner | $20.00 | 20th |
| Cloudflare | $25.00 | 22nd |
| Darryl Davis | $47.00 | 22nd-24th |
| McEvoy Atelier | $14.99 | 23rd |
| HP Instant Ink | $15.99 | 24th |
| YouTube Premium | $22.99 | 26th-27th |
| Google Workspace (secondary) | $9.99 | 27th-29th |
| OpenRouter | ~$10 | Variable |
| Facebook Ads | ~$50-90 | Variable |
| Twilio | ~$50 | Variable |
| Jina.AI | ~$50 | Variable |
| Quo / OpenPhone | ~$33-49 | Variable |
| DocuSign | $35.00 | Variable |
| FS*Enlight | ~$23-36 | Variable |
| Google Cloud (metered) | ~$10-100 | Variable |
| Prime Video (rentals) | ~$4-20 | Variable |
| **Monthly Subscription Total** | **~$1,260** | |

> **Discovered 2026-06-18 (3-mo bank reassessment).** The nine rows above (Twilio → Prime Video) were running through Community Business Checking but were **absent from this index** — added now. Metered/à-la-carte items (Google Cloud, Prime Video rentals, OpenRouter) vary month to month; revised total reflects observed run-rate.
>
> **⏳ Cancellation pending (flagged 2026-06-18)** — NOT added as recurring; appeared as one-time hits in the Mar–Jun window. Do NOT treat as active subscriptions:
> - **Enagic** ($276.40) — ⚠️ **Verify finance status before cancelling.** Likely an installment payment on a financed water ionizer (Enagic MLM), not a discretionary sub — "cancelling" could mean defaulting on a purchase contract. Confirm via Enagic distributor account / Enagic USA (310) 542-7700; if financed, pursue payoff, not cancellation.
> - **TrendsJournal.com** ($149.00) — Likely **annual auto-renew** (Gerald Celente). Action = turn off auto-renew at trendsjournal.com or email support@trendsjournal.com; won't bill again until ~next year.
> - Rocket Money ($9/mo, already subscribed) can action both.
>
> Also watch **foreign-transaction fees** ("SVC CHG INTRNTL TRAN") dribbling out on overseas vendors.

### Annual Subscriptions (→ 🗓️ Other subscriptions)

| Payee | Amount | Due Date |
|-------|--------|----------|
| Readwise | $119.88 | October 6th |
| Grammarly | $144.00 | October 31st |
| Zoho Books | $103.50 | December 15th |

### Quarterly Bills

| Payee | Amount | Due Date | Category |
|-------|--------|----------|----------|
| FMG*ADDINS (Life Insurance) | $67.50 | ~4th | 📄 Insurance |
| LinkedIn Premium Business | $179.97 | ~12th | 🗓️ Other subscriptions |

**Note:** LinkedIn changes to Premium Company Page (~$99.99/month) starting February 11, 2026.

### Periodic Education (→ 📚 Educational savings)

| Payee | Amount | Frequency | Notes |
|-------|--------|-----------|-------|
| Lane Enrollment | ~$697 | Per term (3x/year) | Kids education, NOT monthly |

---

## Monthly Budget Targets (Updated June 2026 — 3-mo bank reassessment)

| Category | Target | Notes |
|----------|--------|-------|
| 🏠 Rent | $2,300 | Check, due 10th. *Mostly paid outside this account — only $155/mo of rent hit business checking in Mar–Jun.* |
| 🚗 Auto loans | $645.87 | Columbia CU ~11th |
| ⚡️ Utilities | $790 | **Raised from $650** — actuals ran ~$791/mo over the quarter (PUD/Spectrum higher than planned) |
| 📄 Insurance | $145 | **Raised from $115** — actuals ~$146/mo; Artisan & Truck ($90.50) + FMG quarterly + American Modern |
| 🗓️ Other subscriptions | $1,260 | **Raised from $1,010** — reflects 9 newly-discovered SaaS line items (see table above) + LinkedIn now at $99.99/mo (switch completed Feb 2026). Excludes Enagic/TrendsJournal pending verification. |
| 🛒 Groceries | $758 | $175/week × 4.33. ⚠️ **Running ~$1,090/mo (84 trips/qtr)** — target is the plan, actuals are 44% over; behavioral, not a stale target |
| 🛞 Transportation | $303 | $70/week × 4.33 |
| 🐾 Pets | $100 | Chewy |
| 🐾️ Vet visits | $95 | Nehalem Animal Healing |
| 🍽️ Dining out | $217 | $50/week × 4.33. ⚠️ **Running ~$629/mo — ~3× over.** Single biggest discretionary leak; target held as the plan, not raised to match |
| 📚 Educational savings | $175 | Lane Enrollment (~$697 per term, 3x/year = ~$175/mo avg) |
| 🛍️ Shopping | $200 | ⚠️ **Running ~$415/mo (mostly Amazon Marketplace)** — ~2× over; target held |
| 🚗 Car maintenance | $85 | |
| 😌 Emergency fund | $85 | |
| 💰 Retirement or investments | $85 | |
| 🎁 Gifts | $80 | |
| ✈️ Vacation Fund | $85 | |
| ❗️ Stuff I forgot to plan for | $80 | |
| **Total** | **~$7,479** | *Raised from ~$7,059 (June 2026): Utilities +$140, Insurance +$30, Subscriptions +$250. Discretionary overages (Dining, Groceries, Shopping) NOT added to plan — those are spending leaks to close, not targets to raise.* |

---

## Income Sources

| Source | Monthly Average | Notes |
|--------|-----------------|-------|
| Square Inc | $4,500-5,500 | Invoice payments, deposited weekly |
| Stripe Transfer | $300-500 | Secondary payment processor |
| **Total Monthly Income** | **~$5,000-6,000** | |

**Target:** $78/hr × 24 hrs/week × 4.33 weeks = **~$8,107/month**

*Note: Square Capital advances (e.g., "SQ Cap") are loans, not income.*
