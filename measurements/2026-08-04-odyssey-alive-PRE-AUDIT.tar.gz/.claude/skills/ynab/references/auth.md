# Authentication & API

## Authentication

Credentials live in **`.env.local`** at the project root (gitignored), never in this file:

```
YNAB_TOKEN        Personal Access Token (all-or-nothing; rotate in YNAB → Developer Settings)
YNAB_BUDGET_ID    Budget ID
YNAB_ACCOUNT_ID   Community Business Checking – 3872
Base URL          https://api.ynab.com/v1
```

### Shell Setup

**Source the loader at the top of every YNAB Bash command.** It self-locates `.env.local`
(CWD → repo root → `~/lab/odyssey-alive`) and exports `TOKEN`, `BUDGET_ID`, and `ACCOUNT_ID`:

```bash
source .claude/skills/ynab/scripts/ynab-env.sh
curl -s "https://api.ynab.com/v1/budgets/$BUDGET_ID/accounts" \
  -H "Authorization: Bearer $TOKEN" \
  -H "User-Agent: ClaudeCode-YNAB/1.0 (francis@odysseyalive.com)"
```

The token's hyphen is safe because the loader exports it quoted; reference it as `"$TOKEN"`.
No `/tmp` token file is needed.

**jq operators:** The `!=` operator gets shell-escaped. Use alternatives:
```bash
# BAD - shell escapes !=
jq 'select(.activity != 0)'

# GOOD - use comparison instead
jq 'select(.activity < 0 or .activity > 0)'
```

**Budget ID:** Always use the explicit `$BUDGET_ID` from the loader. The `/budgets/default` endpoint returns 404.

**Month format:** Always use explicit month `/months/2026-01-01` not `/months/current`.

---

## Common API Calls

### Get account balance
```bash
curl -s -H "Authorization: Bearer $TOKEN" \
  "https://api.ynab.com/v1/budgets/$BUDGET_ID/accounts" | \
  jq '.data.accounts[] | {name, balance: (.balance/1000)}'
```

### Get transactions (since date)
```bash
curl -s -H "Authorization: Bearer $TOKEN" \
  "https://api.ynab.com/v1/budgets/$BUDGET_ID/transactions?since_date=2026-01-01" | \
  jq '.data.transactions'
```

### Get category balances for current month
```bash
curl -s -H "Authorization: Bearer $TOKEN" \
  "https://api.ynab.com/v1/budgets/$BUDGET_ID/months/current" | \
  jq '.data.month.categories[] | {name, budgeted: (.budgeted/1000), activity: (.activity/1000), balance: (.balance/1000)}'
```

### Update budgeted amount for a month
```bash
curl -s -X PATCH "https://api.ynab.com/v1/budgets/$BUDGET_ID/months/2026-01-01/categories/$CATEGORY_ID" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"category":{"budgeted":100000}}'
```
