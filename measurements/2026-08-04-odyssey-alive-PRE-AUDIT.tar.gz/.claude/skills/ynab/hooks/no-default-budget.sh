#!/bin/bash
# Hook: Block /budgets/default in YNAB API calls
# Purpose: Enforce directive: "Always use explicit budget ID"
# The /budgets/default endpoint returns 404 for this account.
#
# Exit codes:
#   0 = Allow
#   2 = Block (uses /budgets/default)

CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR

INPUT=$(cat 2>/dev/null) || exit 0

# Only check commands targeting YNAB API
if ! echo "$INPUT" | grep -q "api.ynab.com" 2>/dev/null; then
  exit 0
fi

# Block /budgets/default
if echo "$INPUT" | grep -q "/budgets/default" 2>/dev/null; then
  echo "BLOCKED: /budgets/default returns 404 for this account." >&2
  echo "Use the explicit budget ID from reference.md instead." >&2
  exit 2
fi

exit 0
