#!/bin/bash
# Hook: Require User-Agent header on YNAB API calls
# Purpose: Enforce directive: "ALL API calls MUST include User-Agent header"
# Without it, Cloudflare blocks requests and tokens appear "revoked"
#
# Exit codes:
#   0 = Allow (not a YNAB call, or User-Agent present)
#   2 = Block (YNAB API call missing User-Agent)

CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR

INPUT=$(cat 2>/dev/null) || exit 0

# Only check commands targeting YNAB API
if ! echo "$INPUT" | grep -q "api.ynab.com" 2>/dev/null; then
  exit 0
fi

# Check for User-Agent header
if echo "$INPUT" | grep -qi "User-Agent:" 2>/dev/null; then
  exit 0
fi

echo "BLOCKED: YNAB API call missing required User-Agent header." >&2
echo "Per directive: ALL API calls MUST include -H \"User-Agent: ClaudeCode-YNAB/1.0 (francis@odysseyalive.com)\"" >&2
echo "Without this, Cloudflare may block requests and cause 401 errors." >&2
exit 2
