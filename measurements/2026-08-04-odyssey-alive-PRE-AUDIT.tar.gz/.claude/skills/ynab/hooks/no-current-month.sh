#!/bin/bash
# Hook: Block /months/current endpoint per /ynab directive
# Must use explicit /months/YYYY-MM-01 format
CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR

INPUT=$(cat 2>/dev/null) || exit 0

if echo "$INPUT" | grep -q '/months/current' 2>/dev/null; then
  echo "BLOCKED: /months/current is forbidden per /ynab directive. Use explicit /months/YYYY-MM-01 format." >&2
  exit 2
fi
exit 0
