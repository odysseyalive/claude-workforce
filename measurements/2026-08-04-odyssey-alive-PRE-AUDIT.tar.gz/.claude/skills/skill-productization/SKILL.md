---
name: skill-productization
description: "Package Claude Code skill-building expertise as a service. Modes: intake, audit, proposal, deliver. Usage: /skill-productization [mode] [client-name]"
allowed-tools: Read, Glob, Grep, Edit, Write, Task, AskUserQuestion
minimum-effort-level: high
hooks:
  PostCompact:
    - hooks:
        - type: command
          command: "echo '{\"additionalContext\": \"REMINDER: /skill-productization is ASYNC-FIRST. Never commit to live calls or real-time sessions. All deliverables are async (Loom videos, written audits, documented skills). Quote conservatively — underpromise, overdeliver.\"}'"
          statusMessage: "Re-injecting async-first directive..."
strictness: standard
---

# Skill Productization Service

Sell your skill-building expertise to other Claude Code users and AI-forward consultants.

## Usage

```
/skill-productization [mode] [client-name]
```

### Modes

| Mode | Command | Description |
|------|---------|-------------|
| `intake` | `/skill-productization intake [client]` | Run discovery questionnaire |
| `audit` | `/skill-productization audit [client]` | Audit client's existing setup |
| `proposal` | `/skill-productization proposal [client]` | Generate service proposal |
| `deliver` | `/skill-productization deliver [client]` | Delivery checklist and handoff |

Default mode is `intake` if not specified.

---

<!-- origin: user | added: 2026-04-17 | immutable: true -->
## Directives

> **"This service is async-first. Never commit to live calls or real-time sessions — all deliverables are async (Loom videos, written audits, documented skills). This fits student schedule constraints."**

*— Added 2026-04-17, source: initial skill creation based on student + business owner constraints*

> **"Underpromise, overdeliver. Quote time and price conservatively. A client who gets more than expected becomes a referral source. A client who gets less becomes a warning to others."**

*— Added 2026-04-17, source: solo entrepreneur best practice*
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Underpromise, overdeliver. Quote time and price conservatively. A client who gets more than expected becomes a referral source. A client who gets less becomes a warning to others." -->
CHECKPOINT — Conservative Quote Gate:
1. Before including any time or price estimate in a proposal or client-facing document, read [references/pricing.md](references/pricing.md) for the baseline tier estimates.
2. Compute the baseline hours estimate for the scope using the pricing reference.
3. Apply the conservative quote rule: the final quoted hours = baseline_hours × 1.5 (50% buffer). The final quoted delivery date = today + quoted_hours / work_rate + 1 week safety margin.
4. IF the proposal quotes hours below baseline OR a delivery date that assumes more than 30 hours of work per week → STOP. Revise upward using the formula.
5. Before committing deliverables to the scope, explicitly name at least one under-the-line deliverable that is NOT quoted but will be delivered (extra Loom, extra documentation, extra validation agent). This is the overdeliver commitment.
6. IF no overdeliver item has been identified → STOP. Add one before proposal goes out.
7. IF the quote passes the buffer check AND includes at least one overdeliver item → CONTINUE to proposal-validator agent spawn.
<!-- END ENFORCEMENT ANNOTATION -->

---

<!-- origin: skill-builder | version: 1.0 | modifiable: true -->
## Workflow: Intake

Run client discovery to understand their needs and qualify the opportunity.

1. **Read intake questions** from [references/intake.md](references/intake.md)
2. **Present questions** via AskUserQuestion or collect answers from client communication
3. **Classify opportunity** by tier (audit only, custom skill, full system)
4. **Capture answers** in a client file: `.claude/skills/skill-productization/clients/[client-name].md`
5. **Recommend next step** — typically `audit` for new clients

---

## Workflow: Audit

Assess client's current Claude Code setup and identify opportunities.

1. **Request access** to client's `.claude/` directory or skill files
2. **Run skill-builder audit** (display mode) on their skills
3. **Document findings** using audit template from [references/audit-template.md](references/audit-template.md)
4. **Identify quick wins** — things fixable in <30 min
5. **Identify major opportunities** — new skills, hooks, agents that would help
6. **Estimate effort** using [references/pricing.md](references/pricing.md) guidelines
7. **Deliver audit** as written report (async)

---

## Workflow: Proposal

Generate a service proposal based on intake and/or audit findings.

1. **Read client file** and audit findings
2. **Select service tier** from [references/pricing.md](references/pricing.md)
3. **Generate proposal** using template from [references/proposal-template.md](references/proposal-template.md)
4. **Include scope, deliverables, timeline, price**
5. **Add payment terms** (50% upfront for custom work)
6. **Validate before sending** — spawn proposal-validator agent (see `agents/proposal-validator/AGENT.md`) to check the draft against async-first and underpromise directives. Resolve all HARD findings before delivery.

---

## Workflow: Deliver

Execute delivery and handoff for accepted proposals.

1. **Create delivery checklist** based on scope
2. **Track progress** using TaskCreate/TaskUpdate
3. **Record Loom walkthrough** for each deliverable
4. **Document in client's repo** (not yours)
5. **Handoff meeting** (async Loom) covering: what was built, how to use it, how to extend it
6. **Collect testimonial** after 2 weeks
7. **Capture evaluation** — spawn capture-recommender agent to assess engagement for ledger-worthy learnings (see agents/capture-recommender/AGENT.md)
<!-- /origin -->

---

<!-- origin: skill-builder | version: 1.0 | modifiable: true -->
## Grounding

Before quoting prices, timelines, or deliverables:
1. Read the relevant file from `references/`
2. State: "I will use [PRICING/TEMPLATE] from references/[file] under [SECTION]"

Reference files:
- [references/pricing.md](references/pricing.md) — Service tiers, pricing, time estimates
- [references/intake.md](references/intake.md) — Discovery questions
- [references/audit-template.md](references/audit-template.md) — Audit report structure
- [references/proposal-template.md](references/proposal-template.md) — Proposal format
- [references/roadmap.md](references/roadmap.md) — Game-changing feature roadmap for scaling
- [references/client-template.md](references/client-template.md) — Client file structure
<!-- /origin -->

---

## Client Files

Store client-specific information in `clients/[client-name].md`. See [references/client-template.md](references/client-template.md) for the file structure.

---

## Marketing Integration

This service plugs into your existing content pipeline:

1. **Lead magnet:** Offer free "Skill Audit Checklist" via SBA workshops
2. **Content:** Write focus articles about skill automation (use `/focus`)
3. **Social proof:** Share anonymized before/after metrics (use `/promote`)
4. **Referrals:** Ask satisfied clients for LinkedIn recommendations

---

