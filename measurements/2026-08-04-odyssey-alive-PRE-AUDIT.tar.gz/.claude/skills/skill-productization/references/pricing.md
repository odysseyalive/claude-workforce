# Service Tiers & Pricing

## Tier 1: Skill Audit

**Price:** $150–300
**Time:** 2–3 hours
**Deliverables:**
- Written audit report (what's working, what's missing)
- Priority recommendations (ranked by impact)
- Quick wins list (fixable in <30 min)
- 10-minute Loom walkthrough

**Best for:** Clients who have tried building skills but aren't sure if they're doing it right.

---

## Tier 2: Custom Skill Creation

**Price:** $500–1,500 per skill
**Time:** 4–10 hours depending on complexity
**Deliverables:**
- Fully documented SKILL.md
- Reference files as needed
- Hooks for enforcement (if applicable)
- Agents for validation (if applicable)
- 15-minute Loom demo + walkthrough
- 30 days of async support (via email)

**Pricing factors:**
| Factor | Low End ($500) | High End ($1,500) |
|--------|----------------|-------------------|
| Complexity | Single workflow | Multi-mode, branching |
| Integrations | None | MCP servers, APIs |
| Enforcement | None | Hooks + agents |
| Reference data | Minimal | Large lookup tables |

**Best for:** Clients who need a specific workflow automated.

---

## Tier 3: Full System Setup

**Price:** $2,500–5,000
**Time:** 20–40 hours
**Deliverables:**
- 3–5 interconnected skills
- Skill chaining (output of one feeds another)
- Awareness ledger setup
- Hook infrastructure
- Agent library (3–5 agents)
- Full documentation
- 60-minute Loom deep-dive
- 60 days of async support

**Best for:** Clients building a Claude Code-powered practice or product.

---

## Add-Ons

| Add-On | Price | Description |
|--------|-------|-------------|
| Additional skill | $400–1,000 | Added to Tier 2 or 3 |
| Awareness ledger | $300 | Standalone ledger setup |
| Hook development | $150–400 | Per enforcement hook |
| Agent creation | $200–500 | Per specialized agent |
| Training session | $200/hr | Live async-recorded training |

---

## Payment Terms

- **Tier 1 (Audit):** Full payment upfront
- **Tier 2 (Custom):** 50% upfront, 50% on delivery
- **Tier 3 (Full System):** 50% upfront, 25% at midpoint, 25% on delivery

---

## Time Estimates

Use these for scoping proposals:

| Task | Time Range |
|------|-----------|
| Intake call/questionnaire | 30 min |
| Audit existing setup | 1–2 hrs |
| Write audit report | 1 hr |
| Simple skill (no hooks) | 2–3 hrs |
| Complex skill (hooks + agents) | 6–10 hrs |
| Reference file extraction | 1–2 hrs |
| Loom recording + editing | 30–60 min |
| Documentation | 1 hr per skill |

---

## Positioning

**You are not selling "Claude Code help."** You are selling:

1. **Time back** — "I built a system that writes my weekly content in 2 hours instead of 8"
2. **Consistency** — "My voice stays the same whether I write it or Claude does"
3. **Operational leverage** — "I productized my expertise into skills that run without me"

Lead with outcomes. Skills are the mechanism, not the product.

---

