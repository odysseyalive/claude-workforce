# Proposal Template

Use this structure for client proposals.

---

```markdown
# Proposal: [Project Title]

**Prepared for:** [Client Name]
**Prepared by:** Francis Meetze, Odyssey Alive
**Date:** YYYY-MM-DD
**Valid until:** YYYY-MM-DD (14 days)

---

## Understanding

[1-2 paragraphs summarizing what you heard in intake/audit. Mirror their language. Show you understand their problem.]

---

## Solution

[1-2 paragraphs describing what you'll build. Focus on outcomes, not features. What will they be able to do that they can't do now?]

---

## Scope & Deliverables

### Included

| Deliverable | Description |
|-------------|-------------|
| [Item] | [What they get] |
| [Item] | [What they get] |
| [Item] | [What they get] |

### Not Included

- [What's explicitly out of scope]
- [What's explicitly out of scope]

*These can be added later as separate engagements.*

---

## Timeline

| Milestone | Target Date | Deliverable |
|-----------|-------------|-------------|
| Kickoff | [Date] | Access granted, questions answered |
| Checkpoint | [Date] | [Partial deliverable for review] |
| Delivery | [Date] | Final deliverables + walkthrough |

Total duration: [X weeks]

---

## Investment

**[Tier Name]:** $[Amount]

Payment schedule:
- [ ] $[Amount] due upon acceptance (50%)
- [ ] $[Amount] due on delivery (50%)

*Payment via [Stripe invoice / PayPal / bank transfer]*

---

## What I Need From You

To deliver this project, I'll need:

1. Access to your `.claude/` directory (read-only is fine)
2. Any existing documentation or SOPs
3. 30-minute async intake (I'll send questions)
4. Feedback on checkpoint delivery within 48 hours

---

## Guarantee

If the delivered system doesn't work as specified, I'll fix it at no additional charge. "Works as specified" means: [specific acceptance criteria from scope].

---

## Next Steps

To proceed:

1. Reply "Approved" to this email
2. I'll send a Stripe invoice for the deposit
3. Upon payment, I'll send the intake questions
4. We begin

Questions? Reply to this email.

---

Francis Meetze
Odyssey Alive
[email]
```

---

## Proposal Writing Guidelines

1. **Mirror their language** — Use words from intake, not your jargon
2. **Lead with understanding** — They should feel heard before seeing solutions
3. **Be specific about scope** — Ambiguity leads to scope creep
4. **Explicit exclusions** — Say what's NOT included
5. **Concrete timeline** — Dates, not "a few weeks"
6. **Simple payment** — Don't overcomplicate
7. **Clear next step** — One action they need to take
8. **Short validity** — 14 days creates urgency

---

## Proposal Checklist

Before sending:

- [ ] Client name spelled correctly
- [ ] Dates are realistic (buffer your estimates)
- [ ] Price matches tier from pricing.md
- [ ] Scope matches what was discussed
- [ ] Exclusions are explicit
- [ ] Payment terms are clear
- [ ] Guarantee is reasonable
- [ ] Next step is one action
- [ ] Proofread for typos

---

