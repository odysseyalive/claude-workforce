# Client File Template

Store client-specific information in `clients/[client-name].md` using the structure below.

```markdown
# [Client Name]

## Contact
- Name:
- Email:
- Company:

## Intake (YYYY-MM-DD)
[Answers from intake questions]

## Audit Findings
[If audit completed]

## Proposals
[Links to sent proposals]

## Delivered
[Completed work]
```
