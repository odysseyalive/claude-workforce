# Skill Audit Report Template

Use this structure for client audit deliverables.

---

```markdown
# Skill System Audit: [Client Name]

**Auditor:** Francis Meetze, Odyssey Alive
**Date:** YYYY-MM-DD
**Scope:** [What was audited — full system, specific skills, etc.]

---

## Executive Summary

[2-3 sentences: overall health, biggest opportunity, recommended action]

---

## Current State

### Skills Inventory

| Skill | Lines | Has Reference? | Has Hooks? | Has Agents? | Status |
|-------|-------|----------------|------------|-------------|--------|
| /skill-1 | XX | Yes/No | Yes/No | Yes/No | [OK/Needs Work] |
| /skill-2 | XX | Yes/No | Yes/No | Yes/No | [OK/Needs Work] |

### Infrastructure

- [ ] Awareness ledger installed
- [ ] Hook infrastructure configured
- [ ] Agent library established
- [ ] Skills interconnected (chaining)

---

## Findings

### What's Working Well

1. **[Finding]** — [Why it's good]
2. **[Finding]** — [Why it's good]

### Quick Wins (< 30 min each)

| Fix | Impact | Effort |
|-----|--------|--------|
| [Description] | [High/Med/Low] | [X min] |
| [Description] | [High/Med/Low] | [X min] |

### Major Opportunities

1. **[Opportunity]**
   - Current state: [What's happening now]
   - Desired state: [What could happen]
   - Estimated value: [Time saved, quality improved, etc.]
   - Estimated effort: [Hours]

2. **[Opportunity]**
   - Current state:
   - Desired state:
   - Estimated value:
   - Estimated effort:

### Issues Found

| Severity | Issue | Recommendation |
|----------|-------|----------------|
| High | [Description] | [Fix] |
| Medium | [Description] | [Fix] |
| Low | [Description] | [Fix] |

---

## Recommendations

### Priority 1: [Title]

[What to do and why — 2-3 sentences]

### Priority 2: [Title]

[What to do and why — 2-3 sentences]

### Priority 3: [Title]

[What to do and why — 2-3 sentences]

---

## Next Steps

Based on this audit, I recommend:

- [ ] **Option A: Quick wins only** — You implement the quick wins yourself. [Free]
- [ ] **Option B: Custom skill** — I build [specific skill]. [$X]
- [ ] **Option C: System upgrade** — I implement priorities 1-3. [$X]

Reply with your choice, or schedule time to discuss.

---

## Appendix: Detailed Notes

[Raw observations, code snippets, specific file references]

```

---

## Audit Process Checklist

When running an audit:

1. [ ] Receive client's `.claude/` directory or skill files
2. [ ] Count skills, lines, structure
3. [ ] Check frontmatter validity
4. [ ] Check for directives (immutable markers)
5. [ ] Check reference file usage
6. [ ] Check hook infrastructure
7. [ ] Check agent infrastructure
8. [ ] Identify chaining opportunities
9. [ ] Run skill-builder audit in display mode
10. [ ] Document findings in template
11. [ ] Record Loom walkthrough
12. [ ] Send report + video link

---

