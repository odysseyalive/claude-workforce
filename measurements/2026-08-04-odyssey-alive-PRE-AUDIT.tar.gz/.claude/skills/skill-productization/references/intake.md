# Client Intake Questions

## Quick Qualification

Ask these first to determine fit:

1. **Are you currently using Claude Code?** (Required: Yes)
2. **Do you have a subscription?** (Required: Pro or Team)
3. **What's your primary use case?** (Determines skill domain)

If they're not using Claude Code yet, redirect to onboarding resources. This service assumes Claude Code proficiency.

---

## Discovery Questions

### Current State

1. **What repetitive tasks do you do in Claude Code today?**
   - Content creation? Code generation? Research? Operations?
   - How often? Daily, weekly, monthly?

2. **Do you have any skills already?**
   - How many?
   - What do they do?
   - Are they working well?

3. **What's your biggest frustration with your current setup?**
   - Inconsistency? Forgetting context? Manual steps?

### Desired State

4. **If Claude Code worked perfectly for you, what would change?**
   - Time saved?
   - Quality improved?
   - New capabilities?

5. **What's the one thing you wish you could automate but haven't figured out?**

### Context

6. **What's your business?**
   - Consulting? SaaS? Content? Services?

7. **Who's your audience?**
   - B2B? B2C? Internal?

8. **Do you have documented processes or SOPs?**
   - These become skill source material

9. **Do you use any external tools Claude should integrate with?**
   - YNAB, Zoho, Notion, Readwise, etc.
   - MCP servers already configured?

### Budget & Timeline

10. **What's your budget range?**
    - Offer tiers: $150–300 (audit), $500–1,500 (custom), $2,500–5,000 (full system)

11. **When do you need this working?**
    - Rush work = premium pricing

12. **What does success look like in 30 days?**
    - Concrete outcome for scoping

---

## Red Flags

Watch for these — may indicate poor fit:

- **"I've never used Claude Code"** — They need onboarding first
- **"I just want you to build me an AI"** — Misunderstanding of service
- **"I need this by tomorrow"** — Unrealistic timeline
- **"Can you just show me quickly?"** — Expecting free consulting
- **"I don't have a budget but..."** — Not ready to pay

---

## Green Flags

These indicate high-value clients:

- Already has 5+ skills (knows the value, wants optimization)
- Clear repetitive workflow they can describe
- Existing documentation or SOPs
- Budget conversation is comfortable
- Specific outcome in mind

---

## Capture Template

After intake, save to `clients/[name].md`:

```markdown
# [Client Name]

## Contact
- Name:
- Email:
- Company:
- Claude subscription: [Pro/Team]

## Intake Date
YYYY-MM-DD

## Current State
- Primary use case:
- Existing skills:
- Pain points:

## Desired State
- Ideal outcome:
- Must-automate task:

## Context
- Business type:
- Audience:
- External tools:

## Budget & Timeline
- Range:
- Deadline:
- Success metric:

## Fit Assessment
- Tier recommendation:
- Red flags:
- Green flags:
- Next step:
```

---

