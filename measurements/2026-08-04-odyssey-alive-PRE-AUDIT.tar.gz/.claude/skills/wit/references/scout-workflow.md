# Workflow: Scout

Scout mode reads source material — URLs, research reports, articles, PDFs — through a satirical lens and extracts the absurdities, contradictions, and humor-worthy observations hiding in the data.

## Step 1: Load Technique Context

Read `.claude/skills/voice/references/satirical-wit.md` — the seven techniques and their shapes. You're looking for raw material that fits these molds, not forcing material into them.

State: "Technique context loaded. Scanning for wit ammunition."

## Step 2: Read Source Material

Read or fetch each URL/file the user provides. For URLs, use WebFetch or WebSearch to retrieve content.

As you read, scan for:

- **Numbers that tell an absurd story** — statistics that, placed in sequence, form a quiet escalation without editorial needed ("$1.3 trillion spent. 70% failed. The consultants got paid either way.")
- **Contradictions between claims and reality** — what companies/industries say vs. what they do (Trojan Observation material)
- **Self-implicating situations** — absurdities the reader (and Francis) are part of, not just observing (Self-Implicating "We" material)
- **Facts so absurd they need zero editorial** — the kind of thing where stating it plainly IS the humor (Understated Absurdity material)
- **Gravity followed by bathos** — serious situations punctured by one mundane detail (Solemn Setup material)
- **Grandiose claims begging for deflation** — industry hype, vendor promises, analyst predictions (Rhetorical Undercut material)
- **Human situations made bearable by framing** — displacement, failure, disruption where compassionate humor opens the door to looking at hard things (Compassionate Absurdist material)

## Step 3: Compile Wit Ammunition

Present findings organized by technique. For each finding:

```
### [Technique Name]

**Source:** [URL or file, with relevant section]
**The raw material:** [The fact, statistic, contradiction, or situation]
**Why it's funny:** [What makes this absurd — stated plainly, not explained]
**Draft angle:** [How this could become a sentence or passage in the article]
```

## Step 4: Prioritize

After listing all findings, rank the top 3-5 by strength:

1. **Strongest:** Facts that are already funny when stated plainly (least effort to deploy)
2. **Strong:** Contradictions that become obvious when placed side by side
3. **Usable:** Situations that need a bit of framing to land

Flag anything that's merely ironic but not actually useful for advancing an argument. Irony without an argument is decoration.

## Step 5: Hand Off

Present the prioritized list. Note which findings pair well with specific article sections if the user has mentioned which article they're working on.

If the user wants to proceed to deployment: "Ready to deploy these into [article]. Run `/wit [file]` and I'll use this ammunition."
