# Sensitivity Flags Reference

Use during the Humor Survey (Phase 1) to classify passages before humor is attempted. Flagging happens upfront — not after generation.

---

## Sensitivity Types

| Type | Description | Default | Rationale |
|------|-------------|---------|-----------|
| `grief` | Loss, death, personal tragedy | **skip** | Humor undermines genuine mourning. The reader needs to sit with the weight. |
| `vulnerability` | Author or subject at their most exposed | **skip** | Humor in vulnerable moments reads as deflection or cowardice. Let the moment breathe. |
| `displacement` | Job loss, economic upheaval affecting real people | **proceed-with-care** | Humor can make the situation bearable enough to look at — but only through Compassionate Absurdist. Mock the system, never the displaced. |
| `cultural` | Cultural practices, traditions, identity | **proceed-with-care** | Self-implication required. If Francis doesn't belong to the culture, humor must come from observing the situation around it, not the culture itself. |
| `political` | Political positions, partisan territory | **proceed-with-care** | Self-implication required. Horatian only — "can you believe this?" not "how dare they?" The reader must never feel recruited. |
| `personal` | Named individuals, specific companies | **reframe** | Mock the situation, process, or outcome — never the person. If the humor only works by targeting the individual, drop it. |

---

## Recommendation Definitions

**skip** — Do not attempt humor on this passage. Mark it in the Humor Survey as a no-go zone. If Francis explicitly overrides during the Workshop, proceed with maximum caution and flag the override for the wit-validator.

**proceed-with-care** — Humor is possible but constrained. The Survey notes the sensitivity type and the constraint (e.g., "Compassionate Absurdist only" or "self-implication required"). During the Workshop, surface the constraint explicitly: "This touches displacement — if we go here, the humor needs to make the situation bearable, not make fun of the people affected."

**reframe** — The current framing won't support humor, but a reframing might. The Survey suggests the reframe direction (e.g., "mock the corporate process that produced the outcome, not the executive who announced it"). The Workshop explores whether the reframe preserves Francis's intended point.

---

## Override Protocol

Francis may override any sensitivity flag during the Workshop. When he does:

1. Note the override in the agent dispatch: "Francis has chosen to proceed with humor on a `[type]`-flagged passage"
2. The satirist agent receives the sensitivity type and constraint alongside the passage
3. The wit-validator receives a flag: "This passage was sensitivity-flagged as `[type]` — Francis chose to proceed. Evaluate whether the humor respects the constraint."
4. A single FAIL from the wit-validator on a sensitivity-overridden passage means drop — no revision attempts

---

## Detection Heuristics

When scanning an article for sensitivity flags, look for:

| Signal | Likely Type |
|--------|-------------|
| Someone lost a job, role, or livelihood | `displacement` |
| Death, illness, or personal loss referenced | `grief` |
| First-person admission of failure, fear, or uncertainty | `vulnerability` |
| Named person criticized or held responsible | `personal` |
| Religious, ethnic, or community practices described | `cultural` |
| Policy position, party affiliation, or voting referenced | `political` |
| "Workers," "employees," "families" affected by systemic change | `displacement` |
| Francis writing about his own struggles or doubts | `vulnerability` |
