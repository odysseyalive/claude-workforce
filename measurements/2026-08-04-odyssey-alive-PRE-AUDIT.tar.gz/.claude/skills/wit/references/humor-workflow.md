# Workflow: Humor

A collaborative workshop for developing literary wit in an article or social post set. Unlike `deploy` (quick retrofitting of 2-4 insertions), `humor` is a deep, conversational process where Francis's comedic instinct drives the work and agents provide craft expertise.

**Core principle:** Agents never generate humor cold. Francis identifies what he finds funny. Agents shape it into Twain-caliber prose.

**Two kinds of humor:** This workflow supports both **passage-level humor** (wit within a single passage) and **connective humor** (wit that bridges separate ideas through dual meanings, callbacks, and bisociative bridges). The Connective Mapping phase finds bridge candidates; the Survey finds passage-level candidates. Both feed into the Workshop.

---

## Phase 1: Connective Mapping

Before surveying individual passages, map the connections between ideas across the entire piece. This is where connective humor — the kind that stitches separate ideas into one thought — gets its raw material.

**Theoretical foundation:** Koestler's bisociation — humor that arises from perceiving a word or concept in two self-consistent but normally incompatible frames simultaneously. Example: "the terms of service are written in Greek" bridges the Trojan Horse frame (literal Greeks) and the tech-incomprehensibility frame (the idiom "it's Greek to me").

### Step 1: Load Voice Context

Read these files before doing anything else:

1. `.claude/skills/voice/references/satirical-wit.md` — the seven techniques, before/after examples, calibration, anti-patterns
2. `.claude/skills/voice/references/characteristics.md` — full voice profile (wit is characteristic #10, but must work alongside the other nine)
3. `.claude/skills/voice/references/calibration.md` — reference texts for voice calibration

State: "Voice context loaded. Beginning connective mapping."

### Step 2: Read the Target Content

Read the file provided by the user. If no file is given, ask which article or post set to work on.

### Step 3: Dispatch the Connector Agent

Launch the Connector agent with `subagent_type: "general-purpose"`:

```
You are a cognitive linguist who finds semantic bridges between ideas.
Read `.claude/skills/wit/agents/connector/AGENT.md` for your full instructions.

Find bisociative bridges in this content:

[Full text of the article or post set]

Return the Connection Map in the specified output format.
```

### Step 4: Present the Connection Map

Present the Connector's output to Francis. Ask:

- "Any of these bridge candidates jump out at you?"
- "Any connections you see that the agent missed?"
- "Which frame pairs feel most promising for humor?"

Francis's selections (plus any connections he adds) carry forward into the Survey and Workshop.

---

## Phase 2: Survey

Map the article's passage-level humor landscape.

### Step 1: Gather Domain Ammunition via Jina

Search for 1-2 technique references relevant to the article's subject matter:

1. Use `mcp__jina__search_web` with queries like:
   - `[article topic] absurd statistics contradiction reality`
   - `[article topic] satire humor criticism`
2. Read the top 2-3 results with `mcp__jina__read_url`
3. Extract raw material only: facts, statistics, contradictions, absurdities
4. Never copy phrasing or comedic framing from sources

### Step 2: Produce the Humor Survey

Read `.claude/skills/wit/references/sensitivity-flags.md` for the sensitivity type definitions and detection heuristics.

Present the survey in this format:

```
## Humor Survey: [Article Title]

### Connective Opportunities

[From the Connection Map — bridge candidates Francis selected or confirmed:]

**Connection [N]:** "[bridge word/phrase]"
- **Frame A:** [meaning in frame A, with the passage it lives in]
- **Frame B:** [meaning in frame B, with the passage it lives in]
- **Bridge quality:** [score from Connector agent]
- **Francis's read:** [what Francis said about this connection, if anything]

### Humor-Ready Passages

[For each individual passage where humor would serve the argument:]

**Passage [N]:** "[exact quote from the article]"
- **Why humor fits:** [what serious point could land harder with wit]
- **Technique candidate:** [which of the seven techniques applies]
- **External ammunition:** [any facts/stats from Jina research that could fuel the humor]

### Sensitivity Flags

[For each passage that touches serious/pungent/offensive territory:]

**Passage:** "[exact quote]"
- **Sensitivity type:** [grief | vulnerability | displacement | cultural | political | personal]
- **Recommendation:** [skip | proceed-with-care | reframe]
- **Why:** [specific reason — what could go wrong if humor is applied carelessly]
- **Constraint:** [if proceed-with-care: what technique/approach is required]

### No-Go Zones

[Passages where humor would actively damage the piece:]

**Passage:** "[exact quote]"
- **Why not:** [what humor would undercut]

### Current Wit Inventory

- **Existing wit beats:** [count]
- **Assessment:** [working well | needs improvement | actively hurting the piece]
- **Gaps:** [where the article could use humor but currently doesn't have it]
```

### Step 3: Present and Ask

Present the Humor Survey to Francis. Ask:

- "Which passages or connections are you most interested in working on?"
- "Anything I flagged as sensitive that you actually want to push into?"
- "Anything I missed — passages that struck you as funny that I didn't catch?"

Francis's response determines which items enter the Workshop.

---

## Phase 3: Workshop

Draw out Francis's comedic instinct through conversation. This is the critical phase — everything that follows depends on what surfaces here.

### Conversational Moves

Work through each passage or connection Francis selected using these moves. Not every move applies to every item — use judgment.

#### Move 1: "What's actually funny here?"

Before generating anything, ask Francis what strikes him as absurd, contradictory, or funny about the passage or topic. His instinct is the raw material. If he says "I don't know, you tell me," push back gently: "What would you say about this if you were telling a friend? What detail would make them laugh?"

#### Move 2: The Twain Test

"If you were telling a friend about this over drinks, what detail would make them laugh?"

The answer is almost always the humor that belongs in the piece. Formal, constructed humor rarely works. The detail Francis would naturally reach for does.

#### Move 3: Technique Matching

Once Francis's instinct is on the table, identify which technique from `satirical-wit.md` best serves it. Present the technique and a before/after example from the reference. Ask: "Does this shape fit what you're going for?"

If the instinct doesn't fit any technique cleanly, say so: "This doesn't map neatly to any of the seven. Let me think about the best delivery." Then identify which Twain mechanic (innocent stringing, slurring the nub, studied-remark-as-aside) would serve it.

#### Move 4: The Opposites Probe

For passages where Francis wants to make a point:

"What's the version of this argument you disagree with? What would someone who's wrong about this say with a straight face?"

This surfaces material for Trojan Observations and the Saunders "opposites method." The reader constructs the real argument when the narrator delivers the wrong one with a straight face.

#### Move 5: The Bridge Workshop (for connective humor)

For selected connections from the Connection Map:

1. Present the bridge candidate and its dual meanings in both frames.
2. Ask: "Does this connection feel real to you, or forced?"
3. If real: "Where would this land? Which paragraph is the setup, which gets the callback?"
4. Ask: "What sentence would carry both meanings at once?"

The goal is to find the sentence where the bridge word activates both frames simultaneously. Francis's instinct for placement and phrasing is essential — the Connector found the word, but only Francis knows how to seat it in the prose.

**Callback rules (from the research):**
- The setup must work on its own — no sign over its head saying "I'm being planted"
- The callback must work at face value for a reader who misses the connection
- The callback must heighten or recontextualize, not merely repeat
- Distance creates surprise — the further apart setup and callback, the bigger the payoff

#### Move 6: Sensitivity Check

If a selected passage has a sensitivity flag, surface the constraint explicitly:

- **displacement:** "This touches people losing their livelihoods. If we go here, the humor needs to make the situation bearable enough to look at, not make fun of the people affected. Compassionate Absurdist is the only safe technique."
- **political:** "This is partisan territory. Self-implication is required — we need to stand inside it, not point at it."
- **personal:** "This names a specific person. We can mock the situation or outcome, but not the individual."

If Francis wants to override a `skip` flag, note it for the validation phase.

### Workshop Exit Conditions

Move to Phase 4 when:
- Francis has expressed his comedic instinct for each selected item (quoted, specific)
- For connective humor: bridge word, placement, and both frames are confirmed
- Technique approaches are agreed upon for each item
- Any sensitivity constraints are acknowledged
- Francis says "go" or equivalent

---

## Phase 4: Generate

Dispatch two agents sequentially. The satirist generates; the editor's table diagnoses structure.

### Step 1: Dispatch the Satirist

Launch the satirist agent with `subagent_type: "general-purpose"`:

**Prompt template (passage-level humor):**

```
You are a veteran literary humorist. Read `.claude/skills/wit/agents/satirist/AGENT.md` for your full instructions.

Generate literary wit for these passages:

[For each passage, include:]

**Passage [N]:** "[exact text from the article]"
**Francis's instinct:** "[quoted from workshop — his exact words about what he finds funny]"
**Agreed technique:** [technique name from satirical-wit.md]
**External ammunition:** [any facts/stats gathered, with sources]
**Sensitivity flag:** [none, or type + constraint]
```

**Prompt template (connective humor):**

```
You are a veteran literary humorist. Read `.claude/skills/wit/agents/satirist/AGENT.md` for your full instructions.

Generate a connective bridge for this connection:

**Connection [N]:**
**Bridge word/phrase:** "[the dual-meaning word]"
**Frame A passage:** "[exact text from the article — the setup frame]"
**Frame A meaning:** [what the bridge word means in this frame]
**Frame B passage:** "[exact text from the article — the callback frame]"
**Frame B meaning:** [what the bridge word means in this frame]
**Francis's instinct:** "[quoted from workshop — his exact words about the connection]"
**Placement:** [which passage gets the bridge sentence — setup, callback, or new]
**Sensitivity flag:** [none, or type + constraint]

Generate 2-3 versions of the bridge sentence. Each must:
- Carry both meanings simultaneously
- Work at face value for a reader who misses the dual meaning
- Reward the reader who catches both frames
```

### Step 2: Dispatch the Editor's Table

Once the satirist returns, launch the editor's table agent with `subagent_type: "general-purpose"`:

**Prompt template:**

```
You are a structural humor editor. Read `.claude/skills/wit/agents/editors-table/AGENT.md` for your full instructions.

Diagnose the structure of these humor versions:

[Include the satirist's complete output for all passages]
```

### Step 3: Synthesize and Present

After the editor's table returns:

1. For each passage, select the strongest version based on the editor's recommendation
2. If the editor reworked a version, prefer the reworked version
3. If the editor flagged all versions for a passage as structurally broken, note it for Francis

Present to Francis:

```
### Passage [N]: [Technique Name]

**Your instinct:** "[quoted from workshop]"

**Best version:** [the selected version, incorporating editor's tweaks]
**Mechanic:** [which Twain mechanic]
**Editor's note:** [one line on why this version lands — from the editor's diagnosis]

**Accept / Reject / Revise / Back to Workshop?**
```

If Francis wants to revise: adjust based on his feedback and re-run the editor's table on the revision only.
If Francis wants to go back to workshop: return to Phase 2 for that specific passage.

---

## Phase 5: Validate

After Francis selects his preferred version for each passage, run the existing wit-validator agent.

Launch with `subagent_type: "general-purpose"`:

```
You are a veteran literary editor. Read `.claude/skills/wit/agents/wit-validator/AGENT.md` for your full instructions.

Validate these accepted wit insertions:

[For each accepted insertion:]

**Original passage:** "[exact text being replaced]"
**Proposed replacement:** "[the accepted version]"
**Claimed technique:** [technique name]
**Rationale:** [why humor fits here — from the Survey]
[If sensitivity-overridden: "This passage was sensitivity-flagged as [type]. Francis chose to proceed. Evaluate whether the humor respects the constraint."]
```

### Handling Failures

If any insertion fails validation:

1. **Minor issues** (rhythm, word choice): Revise based on feedback and re-validate
2. **Fundamental issues** (wrong technique, punches down, undermines argument): Return to Workshop for that passage — ask Francis for a different angle
3. **Sensitivity violation on an overridden passage**: Drop the insertion. One FAIL on a sensitivity-overridden passage means stop — no revision attempts.

Honor the calibration rule: never force humor to hit a quota. If an insertion can't pass validation, drop it.

---

## Phase 6: Apply

For each validated insertion, chain to `/edit` in chained mode (voice and writing context already loaded from Phase 1).

### Step 1: Apply Individually

Use the Edit tool to make each replacement one at a time. After each insertion:
- Read the modified passage plus its surrounding paragraphs
- Check that the insertion flows naturally with the text before and after it
- If the flow is disrupted, flag it: "This insertion reads a bit rough in context. Want me to smooth the transition?"

### Step 2: Final Flow Check

After all insertions are applied, read the full article (or at minimum the sections containing insertions) to verify:
- The humor dosage feels right (not too dense, not too sparse)
- Technique variety — different techniques across the insertions
- The article still reads as serious work that happens to have well-placed humor
- No two insertions compete for the reader's attention in adjacent paragraphs

### Step 3: Offer Follow-Up

"All [N] insertions are in place. Want me to run the content finishing chain (text-eval) on the full article to check for any voice drift the humor may have introduced?"

---

## Jina Reference Sources

These resources teach technique and structure. Agents may read them for craft principles during generation. Never copy phrasing.

| Resource | URL | Use Case |
|----------|-----|----------|
| Twain's "How to Tell a Story" | `https://twain.lib.virginia.edu/onstage/how2tell.html` | Primary source: delivery, nub, pause |
| Project Gutenberg: Twain Essays | `https://www.gutenberg.org/files/3250/3250-h/3250-h.htm` | Extended Twain technique examples |
| Saunders interview (New Yorker) | `https://www.newyorker.com/books/page-turner/george-saunderss-humor` | Satire-compassion, "on the other hand" method |
| Alex Baia "How to Write Satire" | `https://www.alexbaia.com/blog/how-to-write-satire` | Opposites method, premise vs. subtext |
| Post45 "How We Write Funny" | `https://post45.org/2019/01/how-we-write-funny` | Humor as rhetorical strategy |
| Eli Grober on Satire (Lit Hub) | `https://lithub.com/eli-grober-on-the-art-of-satire` | Satire as catharsis, the Camus rule |
| Literary Devices: Bathos | `https://literarydevices.net/bathos` | Anti-climax mechanics |

Agents use these for inspiration and technique reference. Domain-specific searches via `mcp__jina__search_web` provide per-article ammunition (real-world absurdities, contradictions, statistics). All phrasing in output is original.
