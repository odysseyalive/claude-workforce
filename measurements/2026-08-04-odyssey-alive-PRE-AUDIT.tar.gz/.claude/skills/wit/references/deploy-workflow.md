# Workflow: Deploy

## Step 1: Load Voice Context

Read these files before doing anything else:

1. `.claude/skills/voice/references/satirical-wit.md` — the seven techniques, before/after examples, calibration, anti-patterns
2. `.claude/skills/voice/references/characteristics.md` — full voice profile (wit is characteristic #10, but it must work alongside the other nine)
3. `.claude/skills/voice/references/calibration.md` — reference texts, especially "The SaaSpocalypse" for wit calibration

State: "Voice context loaded. Techniques, calibration, and anti-patterns in scope."

## Step 2: Read the Target Article

Read the file provided by the user. If no file is given, ask which article to work on.

Note as you read:
- Where does Francis make serious points that could land softer with humor?
- Where are facts already arranged in a way that could become a deadpan list?
- Where does the article point at "companies" or "the industry" that could become self-implicating?
- Where does a grandiose claim sit without deflation?
- Where does genuine gravity set up a possible puncture?

## Step 3: Identify Insertion Points

Select **2-4 insertion points** (matching the calibration dosage). For each, identify:

1. **The passage** — quote the exact text
2. **The technique** — which of the seven applies (Understated Absurdity, Self-Implicating "We", The Solemn Setup, The Trojan Observation, The Rhetorical Undercut, The Compassionate Absurdist, The Quiet Escalation)
3. **Why here** — what serious point does the humor help land?
4. **The draft** — the proposed replacement or insertion

Apply these filters before proposing:

- **The self-implication test:** Am I standing inside the absurdity or above it? If above, rewrite.
- **The argument test:** Does the humor advance the argument, or is it decoration? If decoration, cut it.
- **The anti-pattern check:** Does the draft announce the humor, punch down, force a callback, or use comedy-writer cadence? If yes, rewrite.
- **The grief check:** Is this a passage about genuine loss, pain, or vulnerability? If yes, skip it.

## Step 4: Validate Insertions

Spawn the wit-validator agent to evaluate each proposed insertion independently:

Launch the agent with subagent_type: "general-purpose"
Prompt: "You are a veteran literary editor with Mark Twain's ear for deadpan — you've spent decades judging whether humor earns its place in serious prose.

Read `.claude/skills/wit/agents/wit-validator/AGENT.md` for your instructions.
Read `.claude/skills/voice/references/satirical-wit.md` for the technique guide and anti-patterns.

Then evaluate these proposed wit insertions:

[Include each insertion with: original passage, technique, rationale, and proposed replacement]

For each insertion, return PASS or FAIL with specific reasoning."

If any insertion fails validation, revise it based on the feedback and re-check against the anti-patterns yourself. If it can't be fixed, drop it and note why.

## Step 5: Present to Francis

Present each validated insertion individually:

```
### Insertion [N]: [Technique Name]

**Why here:** [What serious point this helps land]

**Current:**
> [Exact quoted passage from the article]

**Proposed:**
> [The replacement text]

**Accept / Reject / Revise?**
```

Wait for Francis to decide on each one. Do not batch-apply.

## Step 6: Apply Accepted Insertions

For each accepted insertion, use the Edit tool to make the exact replacement. After all insertions are applied, read the modified passages in context to verify they flow naturally with the surrounding text.

If any insertion disrupts the flow, flag it: "This insertion reads a bit rough in context. Want me to smooth the transition?"
