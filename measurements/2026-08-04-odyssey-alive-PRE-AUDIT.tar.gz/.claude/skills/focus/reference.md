# Focus Skill Reference

## Reference Files Index

Before setting frontmatter or referencing image paths, read the relevant reference file.

| File | Purpose |
|------|---------|
| [references/schema.md](references/schema.md) | Frontmatter schema, date format, categories, lightHero |
| [references/images.md](references/images.md) | Image locations, inline image format |
| [references/captions.md](references/captions.md) | Caption quality standards, four tests, good/dead examples |
| [references/constraints.md](references/constraints.md) | Article constraints (≤600 words, 2 images, 3-5 refs, no em-dashes) |
| [references/schedule.md](references/schedule.md) | Publication schedule and track mapping |
| [references/voice-checklist.md](references/voice-checklist.md) | Voice checklist |
| [references/anti-patterns.md](references/anti-patterns.md) | Anti-patterns |
| [references/architecture.md](references/architecture.md) | Article architecture and fact vs. interpretation guidelines |
| [references/footnotes.md](references/footnotes.md) | Footnotes and references format |
| [references/llm-meta.md](references/llm-meta.md) | LLM meta fields |
| [references/examples.md](references/examples.md) | Reference example |
| [references/validation.md](references/validation.md) | Validator scoping, pre-publication notes |
| [references/capture.md](references/capture.md) | Post-action awareness-ledger capture guidance |
