## Article Architecture

Focus articles require **narrative architecture**, not essay structure.

1. **Open with the reader or a discovery, not a corporate statement.** Ground the reader in something they recognize or something that surprises them. "Think about any skill you're good at" works. "IBM's CEO told Bloomberg" doesn't — it sounds like a briefing. Vary the opening move across articles.
2. **One unifying thread.** A single concept, object, or metaphor that ties everything together.
3. **Ideas emerge from experience.** Don't announce insights; let them surface.
4. **Organize by discovery, not by evidence.** The article's structure should follow how Francis thinks about the material, not the order the sources were read. "Here's what struck me → here's what it made me wonder → here's why it matters" is a discovery arc. "Here's IBM → here's Klarna → here's Gartner → here's Stanford" is a briefing. Evidence serves the narrative — the narrative is never a container for evidence.
5. **Francis's take is the spine.** Every article needs something that isn't in any source — Francis's actual reaction, worry, or insight about what the material means. If the article could be written by anyone with the same sources, it doesn't have a spine yet. The sources inspire the story; Francis's perspective IS the story.
6. **Every observation carries its logic.** Don't just name a pattern — show WHY it exists and WHAT the reader should take from it. Observation → cause → implication. "The bracket sat in a file" → "because the supply chain couldn't absorb generative design" → "understand what your organization can receive before you optimize what it can produce."
7. **Each section builds on the previous.** Momentum, not topic changes.
8. **Close the loop.** Return to the opening thread at the end.
9. **No bullet lists in narrative content.** Restructure as prose.
10. **Spread the devices.** Chiasmus, parallel constructions, triple cascades, aphoristic reversals, and extended metaphors are all valid tools individually. Stacking 3+ in the same passage (2-3 paragraphs) is the AI architecture tell, even when each device is justified on its own. Space them across sections. If a section needs a strong close, thin the rhetorical construction from the middle.
11. **End with a solution gesture.** The final beat should point toward a path forward, grounded in what Odyssey Alive does (building rooms to think in, measured productivity, judgment over horsepower), without becoming a sales pitch. Humor and humility land better than prescriptions.

---

## Fact vs. Interpretation

**Reported fact:** What sources explicitly state, with attribution.
> "GM produced a seat bracket that was 40% lighter and 20% stronger."

**Reasonable inference:** What you conclude, with hedging language.
> "The bracket appears to have remained a proof-of-concept."

**Editorial argument:** Your thesis about what the facts mean.
> "The constraint wasn't capability. It was absorption."

Use hedging language when sources don't explain *why*: "appears to have...", "seems to...", "reportedly"
