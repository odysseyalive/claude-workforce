# Focus Article Workflow Phases

### Phase 0: Model-Lane Preflight (blocking)

Before loading any context or drafting any content, verify the session model matches this skill's lane.

1. Read `references/model-lanes.md` from `.claude/skills/skill-builder/references/model-lanes.md`. Resolve `focus` → its declared lane → the lane's Preferred Model. If `focus` has no declared lane or the preferred model cell is empty, skip silently (unconfigured = no-op).
2. Detect `ACTIVE_MODEL` from the session system-context line ("The exact model ID is ..."), bracket-stripped and lowercased per model-lanes.md § Active-Model Detection.
3. IF `preferred_model != ACTIVE_MODEL` → **STOP. Do not proceed to Phase 1.** Prompt the user in plain text (not AskUserQuestion, so it persists in scrollback):

   > **Model mismatch.** This skill is in the `[lane]` lane, which prefers `[preferred_model]`. The active session model is `[ACTIVE_MODEL]`. Run `/model [preferred_model]` to switch, then say "go." Or reply "skip" to continue on the current model.

   Wait for acknowledgement. If the user switches, re-read the model line once to confirm. If the user says "skip," proceed without switching. Do not loop.
4. IF `preferred_model == ACTIVE_MODEL` → continue silently to Phase 1.

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: model-lane preflight for creative-lane skills. Prevents content generation on the wrong model — the gap that caused INC-2026-06-04-frame-repetition-slipped-tell. Local guard until the upstream claude-enforcer model-lane embed lands. -->
CHECKPOINT — Model-Lane Preflight Gate:
1. This gate fires BEFORE Phase 1. It is the first thing that runs when `/focus` is invoked.
2. Read the model-lanes file. Resolve the skill's lane and preferred model.
3. IF unconfigured (no lane, no preferred model) → CONTINUE silently to Phase 1.
4. IF configured AND `preferred_model == ACTIVE_MODEL` → CONTINUE silently to Phase 1.
5. IF configured AND `preferred_model != ACTIVE_MODEL` → STOP. Prompt the user to `/model`-switch. Do NOT proceed to Phase 1 until the user acknowledges (switch or skip).
6. This gate cannot change the session model itself. It instructs the user.
<!-- END ENFORCEMENT ANNOTATION -->

### Phase 1: Load context (sequential)
1. `/voice` + `/writing` — Load voice and content protocol
2. **Check analytics** — Run `/analytics article-impact` on recent neighborhood articles to see what resonated
3. **Read the neighborhood** — Read at least 3 most recent articles in the same category (by date, whether past or future). Note recurring concepts, metaphors, and phrases. If the new article's central idea duplicates a recent piece, stop and ask the user for a different angle or abandon the topic. Collect word whiskers (repeated phrases across articles) and avoid them in the draft.

### Phase 1b: Scout for wit (mandatory)
Run `/wit scout` on the article's verified sources. This does not replace reading and understanding the sources — it adds a satirical lens on top, surfacing absurdities, contradictions, and escalating facts that the drafter might otherwise miss. Pass the wit ammunition to the drafting step in Phase 2. The only exception is topics requiring gravity without humor (cultural loss, personal grief, vulnerability). When skipping for gravity, state: "Wit skipped: [reason]."

### Phase 1c: Get Francis's spine (mandatory, blocking)

**If a Workshop Handoff Brief is in context** (from `/research workshop`): The spine, angle, discovery arc, and viral hook have already been established through conversation. Skip the spine question — it's already been answered more thoroughly than a single prompt can achieve. Use the handoff brief's spine as the article's spine, the discovery arc as the narrative structure, and the viral hook as a candidate opening or pull quote. Proceed directly to Phase 2.

**Draft-First Branch — if Francis asked for a preliminary draft before workshopping** (see [../../research/references/workshop.md](../../research/references/workshop.md) § "Draft-First Entry"): No Workshop Handoff Brief exists yet, and none is expected before drafting. Do not ask the spine question — Francis has already said, by asking for the draft, that he wants something concrete to react to first. Proceed to Phase 2 using the research-stage working angle (the hypothesis from the `/research` presentation, not yet Francis's own take) as a placeholder spine. Draft the full article normally — real sources, real images, full voice/wit/word-count discipline — EXCEPT the closing section, which stays an explicit bracketed placeholder naming what's missing (e.g., "this closing section is intentionally unfinished — build it around Francis's own take once he's reacted to the draft"). Do not run Phase 3 validation on a draft with an open placeholder; Phase 3 fires only after the placeholder is resolved (see step 5 below). Once Francis has reacted, invoke `/research workshop` against the draft per its Draft-First Entry procedure; when that workshop produces a handoff brief, return here, fill in the placeholder closing using the brief's spine, and proceed through the normal Phase 3 validation gate.

**If no Workshop Handoff Brief is present and no draft-first request was made:** Ask Francis: "What strikes you about this? What worries you? What's the angle only you would see?" His answer becomes the article's spine. Do not begin drafting until Francis has provided his take. If the article could be written by anyone with the same sources, it doesn't have a spine yet. Organize the draft around his discovery arc, not around the evidence.

### Phase 1c-bis: Socratic thesis-surfacing (opt-in via `--socratic`)

**Runs only when `--socratic` was passed AND this is the plain 1c branch** (no Workshop Handoff Brief, no draft-first request). Full procedure: [socratic-thesis.md](socratic-thesis.md). Skip with a stated reason under either other branch — the workshop already surfaced the spine dialectically, and draft-first is react-first (incompatible with talk-first).

This is a **conditional deepening** of the Phase 1c spine question, not a mandatory gauntlet. It draws Francis's thesis out through Socratic dialectic and captures it **in his own words** before drafting. It never drafts — Phase 2 owns that.

1. Ask the normal Phase 1c spine question (above) and capture the answer **verbatim** to the session ledger in the scratchpad (schema in [socratic-thesis.md](socratic-thesis.md) § "Session ledger").
2. Run ONE Thesis-&-Coherence Evaluator pass ([../agents/thesis-coherence-evaluator/AGENT.md](../agents/thesis-coherence-evaluator/AGENT.md), analytical model; pass the **absolute** ledger path). Its questions draw silently on the Phase 1 neighborhood concepts + Phase 1b wit-scout output as a tension inventory — never surfaced to Francis as a lecture on his own sources.
3. IF the evaluator returns `thesis_status: locked` on that first answer → **short-circuit** to the handoff (step 5). The expert nailed it; don't interrogate further.
4. ELSE **escalate into the dialectic:** relate the tension-inventory concepts to Francis's answer, ask viewpoint questions, capture every answer verbatim, and re-run the evaluator every 2–4 exchanges until `locked`. Lock gate = coherence before thesis + the spine check. Surface contradictions as a mirror ("earlier you said X — how does that sit with Y?"), never a verdict. Keep it organic; keep the Trivium stage names internal.
5. **Handoff (never draft here):** on `locked`, the thesis + key phrases become the article's spine and discovery arc, carried into Phase 2 as **protected verbatim spine material** Phase 2 preserves as load-bearing (with traceability to the answer that produced it). Phase 2's kernel renders his voice into publishable prose but must not paraphrase away the original, non-source insight. Proceed to Phase 2.

### Phase 2: Create content (parallel where possible)
4. **Draft the article** — Write the article following voice and writing protocols, organized around Francis's spine from Phase 1c. The structure should follow Francis's discovery arc (what struck him → what nagged → why it matters), not the order sources were read. Incorporate 2-4 well-placed wit beats from the Phase 1b scout output using the techniques identified. The humor must advance the argument, not decorate it. **Write captions during drafting, not after.** Captions are wit beats — apply the four tests (fortune-cookie, summary, specificity, referent) from [captions.md](captions.md). A good caption IS a wit beat and counts toward the 2-4 target.
5. `/image` for watercolor generation (auto-chains to `/image-eval`) — **Run as a parallel Task agent alongside drafting.** Images need the topic and slug, not the full article text. Generate hero + 2 inline images while the draft is being written. Place images into the article after both drafting and image generation complete.

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: finishing-chain enforcement. Prevents presenting an unvalidated draft — the gap that let choppy, fragment-stacked prose reach the user in the "will-ai-stall-itself" session (INC-2026-06-04). -->
CHECKPOINT — Phase 3 Validation Gate (blocking):
1. This gate fires AFTER Phase 2 drafting completes and BEFORE any draft text is presented to the user.
2. Phase 3 validation (finishing chain + preflight + reference verifier + LLM meta) MUST run to completion before the draft is shown.
3. All MUST FIX and SHOULD FIX findings from Phase 3 MUST be resolved before presenting the draft. CONSIDER findings may be presented alongside the draft for the user's judgment.
4. IF Phase 3 has not run → STOP. Do NOT present the draft. Run Phase 3 first.
5. IF Phase 3 ran but MUST FIX or SHOULD FIX findings remain unresolved → STOP. Fix them, then re-run the affected validator to confirm resolution before presenting.
6. Skipping Phase 3 "to move fast" or "to get feedback early" is not permitted. The draft the user sees must have passed validation. An unvalidated draft wastes the user's review time on problems the validators would have caught.
<!-- END ENFORCEMENT ANNOTATION -->

### Phase 3: Validate (parallel where possible)
Run these steps as parallel Task agents after the draft is complete:
6. Run the content finishing chain per `.claude/skills/text-eval/references/finishing-chain.md`. Content type: **focus article**. **All findings at every severity level must be resolved before presenting to the user.** Severity determines fix order, not whether something gets fixed. See the finishing chain for the updated triage protocol.
7. Run preflight validator agent — mechanical constraints (word count, images, references, em-dashes). See [../agents/preflight-validator/AGENT.md](../agents/preflight-validator/AGENT.md).
8. Run reference verifier agent — URL accessibility and content accuracy. See [../agents/reference-verifier/AGENT.md](../agents/reference-verifier/AGENT.md). **REMOVE verdicts are blocking.** If a URL is inaccessible, remove the reference and revise prose before publishing. If content is inaccurate, correct before publishing.
9. **Generate LLM meta fields** — Write a `purpose` paragraph (2-3 declarative sentences, max 500 chars) and 3-5 `faq` items grounded in article content. Add to frontmatter. **Purpose and FAQ answers are prose — the writing kernel loaded in Phase 1 applies in full.** The same voice, sentence structure, vocabulary, and humanity signals that shaped the article body shape both the purpose and the FAQ answers. See [llm-meta.md](llm-meta.md) for quality criteria and voice requirements.

**Validator scoping:** See [validation.md](validation.md) for non-overlapping scope rules. Scope owner's verdict wins on conflicts.

### Phase 4: Revision

When the user requests changes to the draft (before or after initial presentation):
1. Invoke `/edit` in chained mode. Voice and writing context are already loaded.
2. `/edit` applies the change, runs the edit-validator, presents the result.
3. Loop through `/edit` for further changes until the user approves.

### Phase 5: SEO evaluation
10. Run `/seo [slug]` on the new article. AEO/SEO/GEO evaluation as final quality gate. Display mode only (report, no edits). Present scores and any HIGH-priority recommendations to the user.

### Phase 6: Offer promotion
11. Ask: "Do you want me to create promotional content for this article?"
12. If yes, invoke `/promote`
