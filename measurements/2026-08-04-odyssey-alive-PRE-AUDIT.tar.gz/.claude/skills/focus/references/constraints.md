## Article Constraints

### Standard

| Constraint | Requirement |
|------------|-------------|
| Word count | ≤ 600 words (body only) |
| Inline images | Exactly 2 |
| References | 3-5 footnotes |
| Em-dashes | 0 (prohibited) |

### Long-form (`--long` flag)

| Constraint | Requirement |
|------------|-------------|
| Word count | ≤ 1200 words (body only) |
| Inline images | 2-3 |
| References | 3-5 footnotes |
| Em-dashes | 0 (prohibited) |
| Frontmatter | Must include `longForm: true` |

When `/focus create --long` is invoked, add `longForm: true` to the article's frontmatter. The enforcement hooks read this flag to apply long-form limits.

---

## Word Count Reduction Protocol

When a draft exceeds 600 words, **never compress voice to fit.** Do not shorten sentences, remove texture, or tighten phrasing. Francis's voice has rhythm and breathing room that must be preserved.

Instead, reduce word count by removing the least consequential conceptual section entirely:

1. **Identify the article's outline beats.** List the distinct ideas or narrative movements.
2. **Find the least essential beat.** Which section could be removed without breaking the article's core argument or narrative arc?
3. **Remove it whole.** Cut the entire paragraph or section, not pieces of it.
4. **Update transitions.** Ensure the surrounding text flows naturally across the gap. The reader should never sense something was removed.

**The test:** If two sections make the same point (e.g., "the metrics lied" appears in both a dashboard paragraph and an ROI paragraph), the second instance is expendable. Keep the one that's more vivid or lands first.
