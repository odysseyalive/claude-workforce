## Caption Writing

Captions are **wit beats**, not labels. A caption is the article's smallest unit of voice — if the body prose goes through `/voice`, `/writing`, and `/wit`, captions must too. A dead caption under a good image is like a punchline mumbled into the floor.

### What a Caption Does

A caption adds a **new beat** to the argument. It does not summarize the paragraph above it. It does not describe the image. It lands a quiet observation, a juxtaposition, or an ironic aside that the prose didn't have room for. The reader's eye drops to the caption after taking in the image — that's prime real estate for wit.

### The Four Tests

1. **The fortune-cookie test.** Could this caption appear on a motivational poster or a tea bag tag? If yes, it's dead. Kill it. ("Messy doesn't mean broken," "Connection finds its own channel," "Some layers hold. Others fade.")
2. **The summary test.** Does this caption restate what the paragraph above already said? If yes, it's redundant. A caption should add, not echo.
3. **The specificity test.** Does the caption contain a concrete detail — a number, a place, an object, a named thing? Specificity is what separates observation from platitude.
4. **The referent test.** Every noun, pronoun, possessive, and personified entity in the caption points at exactly one thing in the scene or the argument. If you can't answer "whose is the other desk?" or "when did the article meet anyone?", the line is wit-shaped noise — the form of a wit beat without the thought. Beware of copying the structure of a caption that already works in the piece; borrowed form with absent thought is how this failure arrives.

### What Makes Captions Work

**Juxtaposition with concrete details:**
- *$200 billion in commitments. Seventeen new hires.* — two numbers, one contradiction
- *A billion scores. Zero notifications.* — scale vs. silence
- *One product announcement. $285 billion in smoke.* — cause and effect, absurd scale

**Quiet irony grounded in the article's argument:**
- *The algorithm worked. The system around it didn't.* — the article's thesis in miniature
- *The diagnosis is correct. The patient isn't in the building.* — Davos piece in one line
- *Digging for evidence of something that was never in doubt.* — the absurdity of the situation

**Specific, haunting observation:**
- *Somewhere in East Africa, a server that could diagnose tuberculosis is collecting dust.* — a place, an object, a tragedy
- *The chair's still warm. Someone needs to sit there.* — physical detail, implied urgency
- *Fresh rock, born in a decade. Dated in millions.* — the contradiction is in the numbers

**A beat the prose didn't land:**
- *The textbook revises. The mountains don't.* — article's closing thought delivered as caption
- *The product still works. The narrative walked out of the room.* — personification the body text set up
- *The rejection arrived in minutes. The reason never arrived at all.* — rhythm as argument

### What Makes Captions Die

| Dead Pattern | Example | Why It Fails |
|-------------|---------|-------------|
| Fortune cookie | *We find the door that matches how we see.* | Sounds wise, says nothing |
| Abstract metaphor summary | *Every model is a piece of the continent.* | Restates the article's metaphor without adding a beat |
| Vague opposition | *Some layers hold. Others fade.* | No specifics, no stakes |
| Overbuilt profundity | *The future arrived faster than the past prepared us for* | Trying too hard to be profound |
| Image description | *The long windy road to Grand Ronde, Oregon* | That's alt text, not a caption |
| Generic truism | *The real process is rarely the documented one* | True of everything, specific to nothing |
| Paragraph echo | *The context you provide shapes the conversation before it begins.* | Just restating the section's point |
| Unresolvable referent | *One path knew where it led. Mine didn't.* | "Mine" inserts the author into the image's metaphor; neither path belongs to the writer |

### Writing Captions in the Workflow

Captions are written **during Phase 2 drafting**, not bolted on after images are placed. The drafter has wit ammunition from Phase 1b — captions are ideal deployment points for techniques like The Quiet Escalation, Understated Absurdity, and The Rhetorical Undercut.

**Process:**
1. After drafting each section, before moving on, write the caption for that section's image
2. Apply the four tests (fortune-cookie, summary, specificity, referent)
3. If the caption fails any test, rewrite using a concrete detail from the article or a wit technique from Phase 1b
4. Captions count toward the article's 2-4 wit beat target — a good caption IS a wit beat

### Format

```markdown
![Descriptive alt text for accessibility](../../assets/images/focus/inline/article-slug/image-name.jpg)
*Caption text here*
```

Caption immediately follows the image line with no blank line between. See [images.md](images.md) for image path conventions.
