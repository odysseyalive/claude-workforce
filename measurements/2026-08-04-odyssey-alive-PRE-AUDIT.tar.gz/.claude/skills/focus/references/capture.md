# Post-Action Capture

After resolving article decisions (topic direction, angle shifts, reference patterns) or encountering issues (invalid sources, voice drift, validation failures), suggest recording in the awareness ledger (DEC for decisions, PAT for patterns, INC for incidents). Never auto-record — ask the user first.
