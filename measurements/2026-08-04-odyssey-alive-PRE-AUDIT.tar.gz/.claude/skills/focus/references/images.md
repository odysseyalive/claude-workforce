## Image Locations

All source images live in the `assets/` directory. Velite processes them during build.

| Type | Source Location | Path in MDX | Build Output |
|------|-----------------|-------------|--------------|
| Hero | `assets/images/focus/hero/` | `../../assets/images/focus/hero/slug-hero.jpg` | `public/static/` |
| Inline | `assets/images/focus/inline/[slug]/` | `../../assets/images/focus/inline/slug/name.jpg` | `public/static/` |

**Hero images** go in `assets/images/focus/hero/` and are referenced with relative paths in frontmatter:
```yaml
image: ../../assets/images/focus/hero/article-slug-hero.jpg
```

**Inline images** go in `assets/images/focus/inline/[article-slug]/` and are referenced with relative paths in the body:
```markdown
![Alt text](../../assets/images/focus/inline/article-slug/image-name.jpg)
```

Velite processes both hero and inline images, outputting them to `public/static/` with hashed filenames and generating blur data URLs.

**Important:** Save generated images directly to `assets/images/focus/` before running `pnpm dev` or `pnpm build`.

---

## Inline Images with Captions

```markdown
![Descriptive alt text for accessibility](../../assets/images/focus/inline/article-slug/image-name.jpg)
*Caption text in italics on the next line*
```

The caption line immediately follows the image with no blank line between.

**For caption quality standards** (what to write, not just where to put it), see [captions.md](captions.md).
