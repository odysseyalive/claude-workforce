# Validation Pipeline

## Validator Scoping (Non-Overlapping)

- **text-eval** owns prose quality: AI tells, voice alignment, overbuilt prose, rhythm, **caption quality** (fortune-cookie test, summary test, specificity test, referent test per [captions.md](captions.md); referent resolution runs in prose-evaluator Step 1f), **purpose/faq prose quality** (structure-checker agent). Voice characteristics are protected (PAT-2026-02-07).
- **preflight-validator** owns mechanical constraints: word count, image count, reference count, em-dashes, frontmatter completeness.
- **reference-verifier** owns reference integrity: URL accessibility, content accuracy, quote verification, attribution accuracy. If a URL is inaccessible, the reference is removed — no exceptions.
- **image-eval** (Phase 2) owns image quality: AI generation tells, watercolor authenticity.
- When validators flag the same passage, the scope owner's verdict wins. Preflight never overrides text-eval on prose; text-eval never overrides preflight on counts.

## Pre-Publication Note

Preflight validation runs in Phase 3 (parallel with text-eval). Voice is validated once by the text-eval prose-evaluator. No separate voice-validator or final voice check pass.

The [voice-checklist.md](voice-checklist.md) remains available for manual human review but is not part of the automated validation chain.

See [schedule.md § Scheduled Publishing](schedule.md#scheduled-publishing) for date/time scheduling rules.
