## Footnotes and References Format

**Minimum requirement: 3-5 references per article.**

**Footnotes are for external sources only.** Academic papers, reports, third-party URLs. Never use footnotes to reference other focus articles on this site.

**Internal cross-references use inline links.** When referencing another focus article, link naturally to the word or phrase that connects the two pieces. The reader should be able to follow the thread without scrolling to a references section.

```markdown
<!-- CORRECT: inline link to sibling article -->
I wrote about this in [The Toggle](/focus/the-toggle), where the question was simpler.

<!-- CORRECT: link on the concept, not the title -->
The same [briefing room problem](/focus/context-is-the-interface) shows up here.

<!-- WRONG: footnote for an internal article -->
I wrote about this previously.[^3]
[^3]: Meetze, F. (2026). "The Toggle." Odyssey Alive.
```

**In the prose (external sources):**
```markdown
AI works similarly. It's "read" more than any human could in a lifetime.[^1]
```

**At the end of the article:**
```markdown
---

## References

[^1]: Brown, T., et al. (2020). "Language Models are Few-Shot Learners." [arXiv](https://arxiv.org/abs/2005.14165)
```

**Convention:**
- Horizontal rule (`---`) before References section
- `## References` heading
- Each footnote includes author, year, title, and linked source
- **No duplicate citations:** Reuse the same footnote number for the same source
