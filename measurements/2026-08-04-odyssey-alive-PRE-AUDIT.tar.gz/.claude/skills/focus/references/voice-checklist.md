## Voice Checklist

Before publishing, read `/focus/finding-tamanawas` to recalibrate, then verify:

### First-Person Presence
- [ ] Does the article use "I" within the first three paragraphs?
- [ ] Is there at least one moment of "I imagine..." or "I wonder..." or "This got me thinking..."?
- [ ] Does the reader feel like they're alongside someone noticing things?

### Texture and Specificity
- [ ] Does the opening contain at least one concrete sensory detail?
- [ ] Are there named humans, not just organizations?
- [ ] Would a thoughtful reader feel like they're *seeing* something, not being *told* about it?

### Wit and Warmth
- [ ] Is there at least one turn of phrase that surprises or delights?
- [ ] Does it sound like a curious person thinking out loud, or a business article explaining conclusions?
- [ ] Read the opening aloud. Does it invite or lecture?

### Spoken, Not Constructed
- [ ] Read every sentence aloud. Would you restructure any mid-breath?
- [ ] Are there parallel constructions used for rhetorical effect? (Flag them.)
- [ ] Are there sentences with 3+ dependent clauses before the point lands?
- [ ] Does any paragraph feel like it's building a logical staircase instead of talking?

### Neighborhood Moves
- [ ] How do the last 2-3 articles in this category open? Don't repeat the same opening move.
- [ ] How do they close? If they fade out on unresolved observations, this one must close differently.

### Statistics as Seasoning
- [ ] Are there more than two statistics in the article? (If yes, cut some.)
- [ ] Are stats woven into sentences, not presented as a data dump?
- [ ] Could the stat be cut without losing the point? (If yes, cut it.)

### Captions
- [ ] Does each caption add a new beat, or just summarize the paragraph above?
- [ ] Would the caption fail the fortune-cookie test? (Could it appear on a motivational poster?)
- [ ] Does the caption contain at least one concrete detail (number, place, object)?
- [ ] Does the caption sound like Francis noticing something, or like a stock photo label?

### Description Test
- [ ] Does the meta description create a curiosity gap, or explain what you'll learn?
- [ ] **Bad:** "A brilliantly redesigned car part reveals why most AI initiatives fail before they start."
- [ ] **Good:** "What happens when AI designs something your organization can't build?"

### References Check
- [ ] Does the article have 3-5 references?
- [ ] Are statistics and data claims backed by sources?
- [ ] Do references link to primary sources (not just secondary reporting)?
