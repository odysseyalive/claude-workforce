## Anti-Patterns

Watch for these signs that the article has drifted into generic business writing:

| Anti-Pattern | Example | Fix |
|--------------|---------|-----|
| **Thesis-announcing** | "The constraint wasn't capability. It was absorption." (stated cold) | Let the reader arrive there: show the bracket, show the supply chain, let the gap become obvious |
| **Stat dumps** | "42%... 46%... a quarter... 41%..." in consecutive sentences | Pick one stat. Make it count. Cut the rest. |
| **Organization-as-abstraction** | "GM couldn't absorb the change" | "I imagine the engineer who designed it watching it sit in a file, waiting" |
| **Wikipedia voice** | "Apple was experimenting with metalenses, requiring integration across materials science" | "Apple was doing something similar. Different industry, same ambition." |
| **Explaining the point** | "This is important because..." | Trust the reader. If you've shown it well, you don't need to explain why it matters. |
