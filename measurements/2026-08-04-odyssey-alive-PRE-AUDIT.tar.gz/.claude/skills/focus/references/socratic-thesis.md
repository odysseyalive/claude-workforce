# Socratic Thesis-Surfacing (Phase 1c-bis, opt-in via `--socratic`)

<!-- origin: skill-builder | modifiable: true -->
<!-- Ported 2026-07-23 from the essay-helper skill (~/university/.claude/skills/essay-helper), adapted from a
     student-coaching flow to an expert-practitioner content flow. Design pressure-tested by an adaptation-review
     agent; the five must-change calibrations from that review are baked in below. -->

An **optional** deepening of Phase 1c. When `/focus create --socratic` is passed, and only on the **plain** spine branch, the questioner draws Francis's thesis out through Socratic dialectic and captures it **in his own words** before Phase 2 drafts. The point is not to teach Francis his subject — he is the expert — but to surface the one insight that *only he* would bring, the through-line no source contains. ("The Broken Rung" failed precisely because that insight was never asked for; see the Phase 1c directive.)

This phase **never drafts.** It surfaces and captures a thesis, then hands off. Phase 2 owns all drafting (voice/writing kernel, wit, word count, images).

The internal structure borrows the classical **Trivium** — Grammar (the terms), Logic (the dialectic), Rhetoric (expression). Keep those stage names **internal**: never surface "Grammar stage" / "Logic stage" to Francis. He experiences a sharp conversation, not a curriculum.

---

## When this phase runs (branch scope)

Phase 1c-bis fires **only** when ALL of these hold:

1. `--socratic` was passed to `/focus create`.
2. The invocation is on the **plain** Phase 1c branch: **no** Workshop Handoff Brief is in context, **and** no Draft-First request was made.

Explicit no-ops (state the reason, then continue the normal flow):

- **Workshop Handoff Brief present** → SKIP. `/research workshop` already *is* a Socratic thesis-surfacing surface; its brief established the spine, angle, discovery arc, and viral hook through conversation. Running the dialectic again re-interrogates an already-surfaced thesis. Say: "Socratic phase skipped: the workshop brief already surfaced the spine." Use the brief's spine per Phase 1c.
- **Draft-First request** → SKIP. Draft-First exists because Francis signaled, by asking for a draft, that he wants something concrete to react to *before* talking. `--socratic` is talk-first; they are mutually exclusive. Say: "Socratic phase skipped: draft-first was requested (react-first, not talk-first)." Proceed per the Draft-First branch. If both were somehow signaled, ask Francis once which he wants.

---

## Grammar — the silent input (NOT a user-facing beat)

You cannot reason about what isn't named, so the questioner needs the topic's load-bearing concepts and tensions in hand *before* it asks anything. But surfacing them **to Francis** as conversation would tell the expert what his own sources say — patronizing, and duplicative of work `/focus` already did.

So Grammar is a **data dependency, not a teaching surface.** Before the first question, the questioner silently assembles a **tension inventory** from context already gathered:

- **Phase 1 neighborhood reading** — recurring concepts, metaphors, and the word-whiskers already collected.
- **Phase 1b `/wit scout` output** — the absurdities, contradictions, and escalating facts the scout flagged.

These make the questions **specific** ("source X lands on A, and the scout flagged B as absurd — where do you actually stand?") instead of generic. No lexicon agent, no teach-by-definition, no registration-by-use — those are student mechanics. If neither Phase 1 nor Phase 1b ran (they should have), gather the tension inventory directly from the verified sources before questioning.

---

## Logic — the dialectic (the core), gated on need

**This is a conditional escalation, not a mandatory gauntlet.** An expert who nails the spine in one sentence must not be dragged through six rounds of interrogation — that is the exact patronization to avoid.

1. **Ask the normal Phase 1c spine question first:** "What strikes you about this? What worries you? What's the angle only you would see?" Capture the answer **verbatim** in the session ledger (see below).
2. **One evaluator pass on that first answer.** Spawn the Thesis-&-Coherence Evaluator agent (`../agents/thesis-coherence-evaluator/AGENT.md`, analytical model) with the absolute path to the session ledger. It returns `thesis_status` (none | emerging | locked), the candidate thesis quoted verbatim, any contradictions, and the spine check.
3. **Branch on the read:**
   - `thesis_status: locked` on the first answer → **short-circuit.** The spine is already strong; skip the dialectic and go straight to Handoff. (This is the common expert case — protect it.)
   - `thesis_status: none | emerging`, or a contradiction, or a weak spine → **escalate into the Socratic dialectic.** Relate the tension-inventory concepts to Francis's answer, ask viewpoint questions that draw his position out, and capture every answer verbatim. Re-run the evaluator every 2–4 exchanges until it reports `locked`.

**Conduct rules (ported verbatim from essay-helper — these keep the tool from talking down):**

- **Coherence before thesis — this is the lock gate.** A thesis locks only when it is coherent AND free of unresolved self-contradiction. An opinion need not be *correct*, but it must not contradict itself. This coherence check is the actual product of the phase.
- **Surface contradiction as a mirror, not a verdict.** When the evaluator flags incoherence, reflect Francis's two statements back as a question ("earlier you said X — how does that sit with Y?") and let him resolve it. Never lecture.
- **Organic, never pushed by an agenda to "finish."** If Francis wanders somewhere productive, follow. The lock is the destination, never a script read aloud. The completion state lives in the ledger, never in the dialogue.
- **Verbatim is law.** The ledger records Francis's exact words. Never smooth, upgrade, or paraphrase — the whole feature rests on the thesis being *his*.

**The spine check** (the evaluator's, labeled with Francis's own ratified test): *"If the article could be written by anyone with the same sources, it doesn't have a spine yet."* A candidate thesis that merely restates the sources is not `locked`, however coherent — it must carry the insight only Francis brings.

---

## Handoff — protected verbatim spine into Phase 2 (this phase never drafts)

When the evaluator reports `thesis_status: locked`:

1. The locked thesis becomes the article's **spine**, and Francis's captured discovery arc (what struck him → what nagged → why it matters) becomes Phase 2's narrative structure — exactly as the plain Phase 1c feeds Phase 2, only surfaced more deeply.
2. **Carry the thesis and its key phrases across as PROTECTED VERBATIM SPINE MATERIAL** — load-bearing content Phase 2 preserves, not a smoothable "angle." Phase 2's voice/writing kernel renders Francis's voice into publishable prose (that polish is wanted and correct), but it must **not** paraphrase away the original, non-source insight. The rule is not "never paraphrase anything"; it is "never paraphrase away the load-bearing original insight."
3. **Traceability (trimmed):** note which verbatim answer produced the locked thesis, so Phase 2 (and Francis) can see the spine is auditably his. This is the mechanism that lets Phase 2 preserve it.
4. Proceed to Phase 2. Do **not** draft here.

---

## Session ledger (ephemeral working file)

A trimmed capture file — the essay-helper notes schema without the academic frontmatter (no course/week/essay_type/person/word_target). It is the single source of truth the evaluator reads.

- **Location:** the session **scratchpad** directory (see the harness scratchpad path in the system prompt), e.g. `<scratchpad>/socratic-<topic-slug>.md`. It is **ephemeral** — no resume mode, one sitting — and is **cleaned up at the end of the session** per the global temp-file rule. It is never written into `content/` and never committed.
- **Absolute path to the evaluator.** The Thesis-&-Coherence Evaluator is a Task subagent; pass it the **absolute** ledger path.

Minimal structure:

```markdown
# Socratic session — <topic>
stage: logic            # logic | locked  (internal; never read aloud)
thesis_status: none     # none | emerging | locked  (written by the evaluator's return)

## Tension inventory (silent input)
<!-- Load-bearing concepts + contradictions from Phase 1 neighborhood reading and Phase 1b wit scout. -->

## Q&A log (verbatim — never paraphrase)
- Q: ...
  A (verbatim): "..."

## Emerging thesis (in Francis's words)
<!-- The candidate thesis, quoted from the Q&A log. Updated by the evaluator. -->

## Coherence flags
<!-- Open contradictions the evaluator surfaced, and how Francis resolved them. Empty = clean. -->
```

**Rules:** verbatim is law (§ Logic); the frontmatter `stage`/`thesis_status` are written by the evaluator's returns, never read aloud; the locked thesis links back to the verbatim answer that produced it (traceability).

---

## Routing points are sacred

The evaluator agent dispatch is a workflow routing point — preserve it; never inline-replace the coherence evaluation to "save a step." The evaluator supplies the cold, out-of-band read on the analytical model; the warm conversation stays on the creative main loop.
<!-- /origin -->
