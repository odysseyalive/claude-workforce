## Complete Frontmatter Schema

```yaml
---
title: "Article Title"              # Required
slug: "article-slug"                # Required - URL path
description: "Hook that invites"    # Required - shown in cards, meta
date: 2025-01-07T09:00:00-08:00     # Required - publish date/time in PST (see below)
category: "groundwork"              # Required - see options below
tags: ["ai", "research"]            # Optional - for filtering/linking
featured: true                      # Default true - highlights on listings
lightHero: true                     # Default true - adds white backdrop for readability
image: ../../assets/images/focus/hero/slug-hero.jpg  # Optional - hero image
imageAlt: "Description of image"    # Optional - hero image alt text
sideQuest: true                     # Optional - non-tech passion projects
purpose: "2-3 declarative sentences" # Optional - LLM-readable article summary
faq:                                 # Optional - 3-5 citation-ready Q&A pairs
  - question: "What is X?"
    answer: "X is..."
---
```

**Date format:** Use ISO 8601 datetime with PST timezone offset:
- **Full format (preferred):** `2025-01-07T09:00:00-08:00` — publishes at 9:00 AM PST
- **Date only (legacy):** `2025-01-07` — publishes at midnight PST

**Timezone offsets:**
- `-08:00` = Pacific Standard Time (November–March)
- `-07:00` = Pacific Daylight Time (March–November)

**Category options:**
- `groundwork` — Practical AI implementation wisdom (Tuesday)
- `ai-transformation` — Collision stories with specific artifacts (Friday)
- `field-notes` — Anthropological observation (any day)
- `pattern-recognition` — Secondary tag for pattern-focused articles
- `case-studies` — Secondary tag for detailed case studies

**lightHero:** Default `true` for all new articles. Adds a white backdrop behind hero text for readability and uses dark text. Set to `false` only for dark/moody hero images where you want light text without the backdrop.
