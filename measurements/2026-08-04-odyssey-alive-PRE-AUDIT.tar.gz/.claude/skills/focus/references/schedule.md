## Quick Dispatch

Groundwork → next Tuesday, AI Transformation → next Friday, Field Notes → any day. Default 7:00 AM PST.

---

## Publication Schedule & Track Mapping

| Day | Track | Category | Content Type |
|-----|-------|----------|--------------|
| **Tuesday** | Groundwork | `groundwork` | Practical AI implementation wisdom |
| **Friday** | AI Transformation | `ai-transformation` | Collision stories, viral potential |
| **Any** | Field Notes | `field-notes` | Anthropological observation |

**Default publish time:** 7:00 AM PST (`T07:00:00-08:00`)

### Track → Content Mapping

**Groundwork (Tuesday):**
- Context and prompting strategies
- Trust and architecture patterns
- AI tool decisions
- Research and workflow
- Historical tech parallels
- Organizational knowledge preservation
- Content and audience strategy
- Workforce implications

**AI Transformation (Friday):**
- Stories with specific, tangible artifacts
- AI as catalyst for organizational collision
- Human systems under pressure
- Viral potential ("that's exactly what happened to us")

**Field Notes (Any day):**
- Non-business anthropological observation
- Cultural preservation
- Side quests and passion projects

---

## Checking Available Slots

```bash
for f in content/focus/*.mdx; do
  date=$(grep "^date:" "$f" | head -1 | sed 's/date: //')
  title=$(grep "^title:" "$f" | head -1 | sed 's/title: "//' | sed 's/"$//')
  category=$(grep "^category:" "$f" | head -1 | sed 's/category: "//' | sed 's/"$//')
  echo "$date | $category | $title"
done | sort | tail -20
```

Present results as a table showing scheduled and open slots for each track.

---

## Scheduling New Article

1. **Determine track** (see Track → Content Mapping above)
2. **Find next available slot** for that track
3. **Set date and category** in frontmatter: `date: 2026-02-04T07:00:00-08:00` / `category: "groundwork"`
4. **Confirm with user** before creating

---

## Rescheduling Existing Article

1. Read current article for existing date/category
2. Determine new date (same track or changing tracks)
3. Update frontmatter (date and category if changing)
4. Run `pnpm velite` to rebuild

**After any MDX edit:** Always run `pnpm velite` — dev server won't reflect changes until rebuild.

---

## Scheduled Publishing

Articles support future date/time scheduling with `published: true` and future `date`:

- Full datetime (`2025-01-15T09:00:00-08:00`) — appears at exact time
- Date only (`2025-01-15`) — appears at midnight Pacific
- Future-dated articles accessible at direct URL

**Note:** Next.js pre-renders at build time, so scheduled articles appear after site rebuild.
