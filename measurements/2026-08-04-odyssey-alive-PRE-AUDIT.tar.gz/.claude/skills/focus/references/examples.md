## Reference Example

`/focus/finding-tamanawas` demonstrates the architecture:
- Opens with a scene (winding road, squirrel on espresso)
- One thread (the word "tamanawas" weaves through everything)
- Ideas emerge from moments (meeting Joseph, watching Travis carve)
- Sections build (road → museum → conversation → deeper idea → restoration → invitation)
- Closes the loop ("If you're looking for tamanawas, it's here")
