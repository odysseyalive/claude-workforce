## LLM Meta Fields

Generate after article body is finalized. These fields power "The Brief" component (visible on-page for AI web fetch tools) and JSON-LD schema (for search engines).

**Purpose and FAQ answers are prose.** The full writing kernel is already loaded from Phase 1. It governs everything here. Do not reinterpret, override, or supplement the kernel's voice rules. This file defines only the structural constraints specific to Brief fields.

---

### Purpose

- 2-3 declarative sentences explaining what the article covers
- Max 500 characters
- Should answer: "What will a reader learn from this article?"
- Factual and direct, not promotional
- Match the article's point of view. Focus articles are first person; the purpose should be too. Never refer to the author by name in a first-person article's purpose.
- State the core fact and the implication. Don't summarize the article's narrative arc, reference previous articles, or explain how the author arrived at the insight.
- No duplicate information with FAQ answers

### FAQ (3-5 items)

- Questions should match how users naturally query AI ("What is X?", "Why does X matter?", "How does X work?")
- Answers should be 40-60 words, self-contained, and citation-ready
- Every claim must be grounded in article content (no invented facts)
- Include specific numbers or sources from the article when available
- Each answer should make sense if extracted from the page and dropped into an AI response
- No duplicate information between purpose and FAQ answers
- No tagline closers — if every answer ends with a punchy one-liner, that's a template

### Content Structure for Answer Extraction

These are voice-compatible guidance for AEO (Answer Engine Optimization). They complement the writing kernel without overriding it. The voice validators still govern how things sound.

- When a heading naturally phrases as a question, prefer that phrasing. Don't force every heading into question form — that creates a mechanical pattern.
- After each major heading, lead with the insight (1-2 direct sentences) before narrative elaboration. This is information ordering, not a formatting constraint.
- Include specific numbers, percentages, or timeframes when the article's research supports them. AI engines extract and cite concrete data preferentially.
- Each section should work as a standalone extractable chunk. LLMs process content in 200-500 word segments, so each piece needs to make sense if lifted from the page.

### Quality Checklist

- [ ] Purpose under 500 characters
- [ ] Purpose factual, not promotional
- [ ] 3-5 FAQ items present
- [ ] Questions match natural language queries
- [ ] Answers are self-contained (make sense without the article)
- [ ] All claims grounded in article content
- [ ] No duplicate information between purpose and FAQ answers
- [ ] No tagline pattern across closers
- [ ] Headings use question phrasing where natural
- [ ] Sections lead with insight before narrative
