#!/bin/bash
# Hook: Enforce inline image count per /focus directive
# Standard: exactly 2 | Long-form (longForm: true): 2-3
# Scope: Focus article MDX files only
CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR

INPUT=$(cat 2>/dev/null) || exit 0

# Extract file path from Write tool JSON
FILE_PATH=$(echo "$INPUT" | grep -oP '"file_path"\s*:\s*"[^"]*"' | head -1 | sed 's/.*"file_path"\s*:\s*"//;s/"$//')

# Scope check: only focus MDX files
if ! echo "$FILE_PATH" | grep -q 'content/focus/.*\.mdx$'; then
  exit 0
fi

# Count inline images and check longForm flag using python for reliable JSON parsing
RESULT=$(echo "$INPUT" | python3 -c "
import sys, json, re
try:
    data = json.load(sys.stdin)
    content = data.get('tool_input', data).get('content', '')
    # Strip frontmatter (between --- delimiters)
    parts = content.split('---')
    long_form = False
    if len(parts) >= 3:
        frontmatter = parts[1]
        body = '---'.join(parts[2:])
        # Check for longForm: true in frontmatter
        for line in frontmatter.split('\n'):
            stripped = line.strip()
            if stripped in ('longForm: true', 'longForm: True'):
                long_form = True
                break
    else:
        body = content
    # Count ![...](...) patterns in body (inline images only)
    images = re.findall(r'!\[.*?\]\(.*?\)', body)
    print(f'{len(images)} {\"long\" if long_form else \"standard\"}')
except:
    print('0 standard')
" 2>/dev/null)

if [ -z "$RESULT" ]; then
  exit 0
fi

IMAGE_COUNT=$(echo "$RESULT" | awk '{print $1}')
MODE=$(echo "$RESULT" | awk '{print $2}')

if [ "$MODE" = "long" ]; then
  # Long-form: 2-3 inline images
  if [ "$IMAGE_COUNT" -lt 2 ] || [ "$IMAGE_COUNT" -gt 3 ]; then
    echo "BLOCKED: Article has $IMAGE_COUNT inline images (required: 2-3 for long-form) per /focus directive." >&2
    exit 2
  fi
else
  # Standard: exactly 2 inline images
  if [ "$IMAGE_COUNT" -ne 2 ]; then
    echo "BLOCKED: Article has $IMAGE_COUNT inline images (required: exactly 2) per /focus directive." >&2
    exit 2
  fi
fi

exit 0
