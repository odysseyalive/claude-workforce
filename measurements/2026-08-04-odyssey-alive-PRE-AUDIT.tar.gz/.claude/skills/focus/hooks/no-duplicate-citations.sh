#!/bin/bash
# Hook: Block duplicate citation URLs in the References section
# Scope: MDX content files only (skips .claude/ infrastructure)
# Rule: "No duplicate citations: Reuse the same footnote number for the same source"
CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR

INPUT=$(cat 2>/dev/null) || exit 0

# Scope check: skip .claude/ infrastructure files
FILE_PATH=$(echo "$INPUT" | grep -oP '"file_path"\s*:\s*"[^"]*"' | head -1 | sed 's/.*"file_path"\s*:\s*"//;s/"$//')
if echo "$FILE_PATH" | grep -q '\.claude/'; then
  exit 0
fi

# Only check MDX files
if ! echo "$FILE_PATH" | grep -qE '\.mdx$'; then
  exit 0
fi

# Extract the content being written
CONTENT=$(echo "$INPUT" | python3 -c "
import sys, json
data = json.load(sys.stdin)
inp = data.get('tool_input', {})
print(inp.get('content', inp.get('new_string', '')))
" 2>/dev/null)

if [ -z "$CONTENT" ]; then
  exit 0
fi

# Extract URLs from footnote lines: [^N]: ... [text](url) or (url)
URLS=$(echo "$CONTENT" | grep -oP '^\[\^\d+\]:.*\(https?://[^)]+\)' | grep -oP 'https?://[^)]+')

if [ -z "$URLS" ]; then
  exit 0
fi

# Check for duplicate URLs
DUPES=$(echo "$URLS" | sort | uniq -d)
if [ -n "$DUPES" ]; then
  echo "BLOCKED: Duplicate citation URLs in References section. Reuse the same footnote number for the same source." >&2
  echo "Duplicate URLs:" >&2
  echo "$DUPES" >&2
  exit 2
fi

exit 0
