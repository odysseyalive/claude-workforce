#!/bin/bash
# Hook: Rebuild velite content after MDX/MD edits (PostToolUse)
# Skips if dev server is running (velite watch handles it)
CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR

INPUT=$(cat 2>/dev/null) || exit 0

# Only trigger on content file edits
FILE_PATH=$(echo "$INPUT" | grep -oP '"file_path"\s*:\s*"[^"]*"' | head -1 | sed 's/.*"file_path"\s*:\s*"//;s/"$//')
if ! echo "$FILE_PATH" | grep -qE '^(.*/)?content/.*\.(mdx?|txt)$'; then
  exit 0
fi

# Skip if dev server is already running (velite watch mode handles it)
if pgrep -f "next dev" > /dev/null 2>&1; then
  exit 0
fi

# Rebuild velite content
cd "$(git rev-parse --show-toplevel 2>/dev/null || echo '.')"
pnpm run velite 2>&1 | tail -1
exit 0
