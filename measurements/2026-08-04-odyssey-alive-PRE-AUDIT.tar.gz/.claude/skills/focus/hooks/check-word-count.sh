#!/bin/bash
# Hook: Enforce word count per /focus directive
# Standard: ≤600 words | Long-form (longForm: true): ≤1200 words
# Scope: Focus article MDX files only
CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR

INPUT=$(cat 2>/dev/null) || exit 0

# Extract file path from Write tool JSON
FILE_PATH=$(echo "$INPUT" | grep -oP '"file_path"\s*:\s*"[^"]*"' | head -1 | sed 's/.*"file_path"\s*:\s*"//;s/"$//')

# Scope check: only focus MDX files
if ! echo "$FILE_PATH" | grep -q 'content/focus/.*\.mdx$'; then
  exit 0
fi

# Extract content from Write tool JSON
CONTENT=$(echo "$INPUT" | grep -oP '"content"\s*:\s*"' | head -1)
if [ -z "$CONTENT" ]; then
  exit 0
fi

# Extract body and check longForm flag using python for reliable JSON parsing
RESULT=$(echo "$INPUT" | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    content = data.get('tool_input', data).get('content', '')
    # Strip frontmatter (between --- delimiters)
    parts = content.split('---')
    long_form = False
    if len(parts) >= 3:
        frontmatter = parts[1]
        body = '---'.join(parts[2:])
        # Check for longForm: true in frontmatter
        for line in frontmatter.split('\n'):
            stripped = line.strip()
            if stripped in ('longForm: true', 'longForm: True'):
                long_form = True
                break
    else:
        body = content
    # Strip markdown image lines and reference footnotes
    lines = []
    for line in body.split('\n'):
        stripped = line.strip()
        if stripped.startswith('!['):
            continue
        if stripped.startswith('[^'):
            continue
        if stripped.startswith('*') and stripped.endswith('*') and len(stripped) < 100:
            continue
        lines.append(line)
    word_count = len('\n'.join(lines).split())
    limit = 1200 if long_form else 600
    print(f'{word_count} {limit} {\"long\" if long_form else \"standard\"}')
except:
    print('0 600 standard')
" 2>/dev/null)

if [ -z "$RESULT" ]; then
  exit 0
fi

WORD_COUNT=$(echo "$RESULT" | awk '{print $1}')
LIMIT=$(echo "$RESULT" | awk '{print $2}')
MODE=$(echo "$RESULT" | awk '{print $3}')

if [ "$WORD_COUNT" -gt "$LIMIT" ]; then
  echo "WARNING: Article body is $WORD_COUNT words (limit: $LIMIT, mode: $MODE). The preflight validator will flag this. Consider removing the least consequential section. Do not compress voice to fit." >&2
  exit 0
fi

exit 0
