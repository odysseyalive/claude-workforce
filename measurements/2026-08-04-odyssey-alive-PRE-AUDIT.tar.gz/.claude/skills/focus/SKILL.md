---
name: focus
description: Focus article workflow for Odyssey Alive. Chains to /voice, /writing, /image.
allowed-tools: Read, Glob, Grep, Edit, Write, Bash, Task
minimum-effort-level: xhigh
strictness: standard
---

# Focus Article Workflow

**This is a master skill.** When invoked, it orchestrates the full article creation workflow.

## Modes

| Mode | Command | Description |
|------|---------|-------------|
| `create` | `/focus create [topic]` | Full article creation workflow (default) |
| `create --long` | `/focus create --long [topic]` | Long-form article (1200 words, 2-3 images) |
| `create --socratic` | `/focus create --socratic [topic]` | Opt-in Socratic pre-draft: surface the thesis in Francis's own words via dialectic before drafting (Phase 1c-bis). Composes with `--long`. |
| `schedule` | `/focus schedule [date]` | Schedule a focus article for publication |
| `reschedule` | `/focus reschedule [slug] [date]` | Change publication date of existing article |
| `calendar` | `/focus calendar` | Show upcoming publication calendar |

---

<!-- origin: user | added: 2026-02-12 | immutable: true -->
## Directives

> **"Articles must be ≤600 words (body only). Long-form articles (`--long` flag) may be ≤1200 words."**

*— Added 2026-02-12, updated 2026-03-23, source: skill-builder audit + user directive for long-form support*

> **"Articles must have exactly 2 inline images. Long-form articles (`--long` flag) may have 2-3 inline images."**

*— Added 2026-02-12, updated 2026-03-23, source: skill-builder audit + user directive for long-form support*

> **"When `--long` is passed to `/focus create`, add `longForm: true` to the article's frontmatter. This signals the enforcement hooks to use long-form constraints (1200 words, 2-3 images). All other pipeline steps (voice, writing, wit, text-eval, reference verification) run identically."**

*— Added 2026-03-23, source: user directive after standard hooks blocked a long-form article*

> **"Articles must have 3-5 footnote references."**

*— Added 2026-02-12, source: skill-builder audit (extracted from reference.md Article Constraints)*

> **"No em-dashes (prohibited)."**

*— Added 2026-02-12, source: skill-builder audit (extracted from reference.md Article Constraints)*

> **"Read at least 3 most recent articles in the same category before drafting. Note recurring concepts, metaphors, and phrases. If the new article's central idea duplicates a recent piece, stop and ask the user."**

*— Added 2026-02-12, source: skill-builder audit (extracted from Phase 1 neighborhood reading)*

> **"Every reference must link to an accessible, readable URL. If the URL is inaccessible (404, paywall, access denied, timeout), the reference is removed from the article and prose is revised. No exceptions. Content at the URL must also match: quoted text must appear verbatim, statistics must be exact, and named people must hold the titles and affiliations claimed. Secondhand citations are only valid when the footnote attributes the data to the secondary source that was actually read."**

*— Added 2026-03-09, source: user directive after two invalid references shipped in draft*

> **"Do not begin drafting unless at least 3 independent, accessible, on-topic source URLs have been verified. If coming from /research, the source sufficiency count in the findings must show SUFFICIENT. If not, stop and tell the user the topic cannot sustain an article. Never pad references with off-topic sources to meet the 3-reference minimum. If on-topic sources fall below 3 during drafting, stop and inform the user rather than adding unrelated citations. A killed article is better than a dishonest one."**

*— Added 2026-03-09, source: user directive after single-source topic wasted a full drafting cycle with padded off-topic references*

> **"Every observation must include WHY it matters. Don't just describe a pattern — explain the underlying cause and the practical implication. The pattern is: observation → cause → implication. 'AI scheduling worked perfectly' is incomplete. 'AI scheduling worked perfectly → it exposed how decisions had actually been made for decades → map your informal processes before optimizing them' is a complete thought. If an article only names a pattern without explaining why it exists or what the reader should do about it, it's a cram sheet, not insight."**

*— Added 2026-02-16, source: functional logic principle from study-prep skill*

> **"Cited articles should inspire and shape the narrative, NOT the other way around. Article subjects should not be assumed and transmuted just to 'prove a point' or fulfill requirements. The sources guide the story. If the sources don't support the angle, the angle changes or dies. Never bend a source's subject matter to fit a predetermined narrative."**

*— Added 2026-03-09, source: user directive after article drafted around a forced narrative with off-topic sources bent to fit*

> **"When an article draft is complete and validated, start the dev server (`pnpm dev`) if it isn't already running and provide the article link (http://localhost:3030/focus/[slug]) for review. When changes are requested to an existing article, check if the dev server is running. If not, start it. If it is already running, run `pnpm velite` to rebuild the content so the changes are visible."**

*— Added 2026-03-09, source: user directive for immediate article preview during review*

> **"Wit scout and deploy are mandatory for every focus article. Run `/wit scout` on verified sources during Phase 1b, and incorporate wit ammunition during drafting. The only exception is topics requiring gravity without humor (cultural loss, personal grief, vulnerability), and when skipping for gravity, state: 'Wit skipped: [reason].' Never skip wit because of context loss, time pressure, or because sources were 'already loaded.'"**

*— Added 2026-03-09, source: user directive after wit was skipped during "The Broken Rung" pipeline due to context boundary*

> **"Before drafting, ask Francis: 'What strikes you about this? What worries you? What's the angle only you would see?' His answer is the article's spine. Do not begin drafting until Francis has provided his take. If the article could be written by anyone with the same sources, it doesn't have a spine yet. Sources inspire the story; Francis's perspective IS the story. Organize the draft around his discovery arc, not around the evidence. Evidence serves the narrative."**

*— Added 2026-03-09, source: "The Broken Rung" was drafted as a research briefing because Francis's actual take was never asked for. His insight (expertise ages out, removing juniors eventually kills the whole pipeline) wasn't in any source and transformed the article when added.*
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Do not begin drafting unless at least 3 independent, accessible, on-topic source URLs have been verified. If coming from /research, the source sufficiency count in the findings must show SUFFICIENT. If not, stop and tell the user the topic cannot sustain an article. Never pad references with off-topic sources to meet the 3-reference minimum. If on-topic sources fall below 3 during drafting, stop and inform the user rather than adding unrelated citations. A killed article is better than a dishonest one." -->
CHECKPOINT — Source Verification Gate:
1. Collect all candidate source URLs (from /research findings if chained, or from the topic-scoping phase).
2. IF input includes a /research findings block → read its source sufficiency count field. IF count shows SUFFICIENT → set verified_count = 3+ and proceed to step 5. IF count shows INSUFFICIENT → STOP. Report to user: "Topic cannot sustain an article (research flagged INSUFFICIENT sources)." Do not proceed.
3. For EACH candidate URL: fetch the page, confirm HTTP 200, confirm content is on-topic by reading at least the first 3 paragraphs and matching the topic keywords.
4. Count URLs that pass all three checks (loads, accessible, on-topic). Record as verified_count.
5. IF verified_count < 3 → STOP. Report to user: "[verified_count] of 3 required on-topic sources verified. Missing: [which URLs failed and why]. Topic cannot sustain an article without padding." Do not proceed to drafting.
6. IF verified_count ≥ 3 → log verified sources and continue to Phase 1b.
7. During drafting, IF an on-topic source is removed or fails re-verification AND the remaining on-topic count drops below 3 → STOP drafting. Report: "On-topic source count fell below 3 during drafting. [which source fell out and why]." Do not substitute with off-topic citations.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Every observation must include WHY it matters. Don't just describe a pattern — explain the underlying cause and the practical implication. The pattern is: observation → cause → implication. 'AI scheduling worked perfectly' is incomplete. 'AI scheduling worked perfectly → it exposed how decisions had actually been made for decades → map your informal processes before optimizing them' is a complete thought. If an article only names a pattern without explaining why it exists or what the reader should do about it, it's a cram sheet, not insight." -->
CHECKPOINT — Observation-Cause-Implication Gate:
1. After draft completion, enumerate every paragraph or observation block that names a pattern, trend, or finding.
2. For EACH such block, check for three elements: (a) the observation (what was seen), (b) the cause (why it exists / what produced it), (c) the implication (what the reader should do with this, or why it matters practically).
3. IF a block contains only (a) without (b) and (c) → STOP. Mark the block as incomplete and rewrite to add cause and implication before presenting the draft.
4. IF a block contains (a) and (b) but no (c) → STOP. Rewrite to add the practical implication.
5. IF a block contains (a) and (c) but no (b) → STOP. Rewrite to add the underlying cause.
6. IF every observation block contains all three elements → CONTINUE and proceed to validation phase.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Cited articles should inspire and shape the narrative, NOT the other way around. Article subjects should not be assumed and transmuted just to 'prove a point' or fulfill requirements. The sources guide the story. If the sources don't support the angle, the angle changes or dies. Never bend a source's subject matter to fit a predetermined narrative." -->
CHECKPOINT — Source-Narrative Direction Gate:
1. After the angle/spine is defined in Phase 1c and before drafting starts in Phase 2, enumerate each verified source with one-sentence summary of what the source is actually ABOUT (not what claim it is being used to support).
2. For EACH source: compare the source's actual subject against the intended angle. Mark as ALIGNED (source's subject directly supports the angle) or MISALIGNED (source is being stretched or reframed to support the angle).
3. Count MISALIGNED sources. IF MISALIGNED count ≥ 2 → STOP. Report: "[N] sources appear to be bent to fit the narrative: [list]. The angle must change to match what the sources actually support, or the article must be abandoned." Wait for user decision before drafting.
4. IF only 1 source is MISALIGNED AND the remaining ALIGNED count is ≥ 3 → drop the misaligned source from the reference list and continue.
5. IF all sources are ALIGNED → CONTINUE to drafting.
6. During drafting, IF a source is cited in a way that makes a claim the source does not actually make → STOP. Either revise the draft to accurately reflect the source OR remove the citation and revise prose.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Read at least 3 most recent articles in the same category before drafting. Note recurring concepts, metaphors, and phrases. If the new article's central idea duplicates a recent piece, stop and ask the user." -->
CHECKPOINT — Neighborhood Reading Gate:
1. Before Phase 2 drafting begins, resolve the article's category from frontmatter (ai-transformation, pattern-recognition, case-studies, field-notes).
2. Glob content/focus/*.mdx and filter to the same category. Sort by date descending.
3. Select the 3 most recent articles in that category (by frontmatter `date`).
4. For EACH selected article: read the full body (not just frontmatter). Extract recurring concepts (3+ mentions), core metaphors (single dominant image per article), and signature phrases (2-4 word collocations that appear verbatim or near-verbatim).
5. Compile the neighborhood list: all concepts + metaphors + phrases across the 3 articles. Save in the drafting context as "word whiskers to avoid" and "neighborhood concepts to check against."
6. Compare the proposed article's central idea (from spine/angle in Phase 1c) to each neighborhood article's central idea. IF the new idea is a paraphrase, extension-only, or direct overlap with any neighborhood article → STOP. Report to user: "This article's central idea overlaps with [article-slug]: [how]. Proposed alternatives: [1-2 distinct angles]." Wait for user decision.
7. During drafting, IF a word whisker from the neighborhood appears → replace with a different phrasing grounded in the current article's specifics.
8. IF neighborhood reading completed AND no duplicate central idea → CONTINUE to drafting.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- origin: skill-builder | modifiable: true -->
<!-- Source: Socratic thesis-surfacing ported from the essay-helper skill 2026-07-23 as an OPT-IN pre-draft phase (Phase 1c-bis). This governing text is skill-builder-origin and modifiable; it is NOT a user-ratified directive and deliberately lives OUTSIDE the immutable Directives block. Only the `--socratic` flag's existence was user-ratified (architecture choice). Procedure: references/socratic-thesis.md. -->
CHECKPOINT — Socratic Thesis-Surfacing Gate (fires only when `--socratic` is passed to `/focus create`):
1. Default is OFF. IF `--socratic` was NOT passed → this gate is a silent no-op; run the normal flow.
2. Branch scope. Phase 1c-bis runs ONLY on the PLAIN Phase 1c branch. IF a Workshop Handoff Brief is in context → SKIP (the workshop already surfaced the spine dialectically); state the skip reason and use the brief's spine. IF a Draft-First request was made → SKIP (draft-first is react-first, incompatible with talk-first); state the skip reason and proceed per the Draft-First branch. IF both `--socratic` and one of these branches are signaled → the branch wins; do not run the dialectic.
3. Conditional escalation, never a mandatory gauntlet. Ask the normal Phase 1c spine question first and capture the answer VERBATIM to the session ledger. Run ONE Thesis-&-Coherence Evaluator pass (agents/thesis-coherence-evaluator, analytical model; pass the ABSOLUTE ledger path). IF it returns `thesis_status: locked` on the first answer → short-circuit straight to Handoff (protect the expert who nails it in one sentence). ELSE escalate into the Socratic dialectic, re-running the evaluator every 2–4 exchanges until `locked`.
4. Lock gate = coherence before thesis. A thesis locks only when coherent, free of unresolved self-contradiction, AND it passes the spine check ("if the article could be written by anyone with the same sources, it doesn't have a spine yet"). Surface any contradiction as a mirror, not a verdict. Keep the conversation organic; keep the Trivium stage names internal (never read "Grammar/Logic stage" aloud). Verbatim is law — never paraphrase Francis's captured words.
5. This phase NEVER drafts. On `locked`, the thesis + key phrases hand off to Phase 2 as PROTECTED VERBATIM SPINE material Phase 2 preserves as load-bearing (with traceability to the answer that produced it); Phase 2 owns all drafting. Do not inline-replace the evaluator dispatch — it is a sacred routing point.
<!-- END ENFORCEMENT ANNOTATION -->

---


<!-- MODEL-LANE-GATE START — auto-generated by /skill-builder route embed; safe to replace -->
<!-- origin: skill-builder | modifiable: true -->
## Model-Lane Preflight

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: /skill-builder route embed (model-lane gate, slim form per the 2026-06-06 2-Brain Harness directive: gates are slimmed, never stripped — this block is the lane checkpoint that travels with the skill through EVERY entry path, including hand-run invocations, which are always permitted. It goes silent when /route already covered the endeavor. Advisory-only per the 2026-06-06 No-Switch-Prompt directive: the gate CANNOT switch the model and NEVER asks the user to — its entire output is one advisory line, which names the exact remedy informationally per the 2026-06-11 named-command advisory directive. -->
CHECKPOINT — Model-Lane Preflight Gate (slim, advisory-only; fires at the TOP of this skill's workflow, before any generative step):
1. SKIP silently IF ANY of: `/route` dispatched this invocation after running its own lane preflight (a lane advisory OR ask already printed, route otherwise ASSESSED the lane this turn, or it was deliberately suppressed — route's coverage extends to the whole endeavor whether route asked, matched, or the user declined, including skills this one chains); this skill's frontmatter sets `model-lane-gate: off`; the session is headless / non-interactive; this gate is executing inside a subagent (a subagent is already model-pinned via its own frontmatter); OR an advisory for this LANE already printed this endeavor AND the active model is unchanged (advise at most once per (lane, active-model) pair per endeavor).
2. Resolve this skill's lane (own `lane:` frontmatter → the Skill→Lane table in `.claude/skills/skill-builder/references/model-lanes.md` → NO LANE) and the lane's Preferred Model. IF no lane resolves OR the preferred-model cell is empty → silent no-op (correctly absent, not a gap). IF this skill declares per-function lanes AND the invocation's resolved mode has its own row → that function's lane governs; otherwise the skill-level lane covers all modes.
3. Read ACTIVE_MODEL from the session system-context line "The exact model ID is …" (strip `[1m]`/`[200k]`, lowercase — model-lanes.md § Active-Model Detection; never an env var or Bash probe). IF the Preferred Model is malformed or names a clearly superseded family → emit the one-line stale-mapping advisory and proceed; never advise from a stale mapping, never validate against a hardcoded list.
4. Compare. Match → silent no-op. Mismatch → print ONE advisory line and PROCEED: "Lane advisory: this skill declares the `<lane>` lane (preferred `<preferred>`); the active model is `<active>` — to align, run `/model <preferred>` and re-invoke; proceeding as-is." Naming the command is INFORMATIONAL (named-command advisory directive, 2026-06-11): NEVER an AskUserQuestion, never a blocking wait (No-Switch-Prompt directive, 2026-06-06). A skill can NEVER switch the session model and never asks the user to.
5. Primary-lane scope. This gate fires ONCE per invocation, for the resolved PRIMARY lane. Cross-lane mid-workflow steps never re-advise — they delegate via this skill's LANE-AGENT-EMBED Delegation Map when present (see .claude/skills/skill-builder/references/lane-delegation.md). Delegation is never a substitute for THIS gate: analytical primary work runs on the analytical main model — never a creative main session orchestrating analytical-pinned agents to dodge the lane.
<!-- END ENFORCEMENT ANNOTATION -->
<!-- /origin -->
<!-- MODEL-LANE-GATE END -->


## Skill Chaining

**Grounding:** [references/workflow.md](references/workflow.md) — full phase-by-phase procedure:

- **Phase 1** Load context (voice/writing, analytics, neighborhood reading)
- **Phase 1b** Scout for wit (mandatory; gravity exception)
- **Phase 1c** Get Francis's spine (mandatory, blocking)
- **Phase 1c-bis** Socratic thesis-surfacing (opt-in via `--socratic`; plain-branch only) — see [references/socratic-thesis.md](references/socratic-thesis.md)
- **Phase 2** Create content (drafting + parallel `/image`)
- **Phase 3** Validate (finishing chain, preflight, reference verifier, LLM meta)
- **Phase 4** Revision (via `/edit`)
- **Phase 5** SEO evaluation
- **Phase 6** Offer promotion

---

## Grounding

**Before setting frontmatter or referencing image paths, read [reference.md](reference.md) § "Reference Files Index" and load the relevant files.**

- Scheduling: [references/schedule.md](references/schedule.md) — tracks, quick dispatch, default publish time
- Socratic pre-draft (`--socratic`): [references/socratic-thesis.md](references/socratic-thesis.md) — Phase 1c-bis dialectic, branch scope, evaluator handoff
- Post-action capture: [references/capture.md](references/capture.md) — awareness-ledger guidance


---

<!-- ROUTE-EMBED START — auto-generated by /skill-builder route embed; safe to replace -->
<!-- origin: skill-builder | modifiable: true -->
## Route Consultation

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: /skill-builder route embed. Closes the dispatch-bypass gap: a /route announcement is not a substitute for a Skill tool call, and consulting /route does not license the caller to execute the target skill's procedure manually. -->
CHECKPOINT — Skill Routing Gate:
1. During this skill's workflow, IF a step requires research, web search, lookup, analysis, or any follow-up NOT already covered by an explicit tool or skill name → STOP before improvising.
2. Already-named exception. IF the current workflow step EXPLICITLY names tools or skills (e.g., "use Read", "spawn the X agent", "invoke /[skill]") → execute as written. Do NOT consult `/route` for steps already determined. Skip to your skill's next step.
3. Otherwise → invoke `/route <task description>` via the Skill tool. `/route` reads its index and either returns a target skill or reports "no match."
4. Dispatch Required. IF `/route` returns a target → the IMMEDIATE next tool call MUST be `Skill(skill=<target>, args=<derived>)`. Do NOT execute the target skill's procedure steps yourself with raw Edit / Write / Bash / Task / Agent / Read calls. The target skill's gates (asset backups, agent panels, exit tests, cascade steps, frontend-design reviews, immutable-directive checks) ONLY fire when its SKILL.md is loaded via Skill — running steps manually silently skips every gate.
5. Bypass detection. IF a Skill dispatch was just announced (yours or `/route`'s) and the next tool call is non-Skill work germane to the routed task → STOP. Print verbatim: "Route dispatch announced but Skill call skipped. Invoking Skill tool now." then issue the Skill call.
6. No-match path. IF `/route` returns "no match" → proceed with the most direct, manual approach. Document the gap; the user may want to register a skill.
7. Follow-ups loop back. After the dispatched skill returns, IF further follow-up is needed → consult `/route` again via Skill. Do not freelance the next step.
8. Auto-mode override clause. Auto-mode ("execute immediately", "prefer action over planning") does NOT override clauses 4–5. Auto-mode chooses WHAT to do; once a routing decision is on the table, the only valid next action is Skill invocation.
<!-- END ENFORCEMENT ANNOTATION -->
<!-- /origin -->
<!-- ROUTE-EMBED END -->
