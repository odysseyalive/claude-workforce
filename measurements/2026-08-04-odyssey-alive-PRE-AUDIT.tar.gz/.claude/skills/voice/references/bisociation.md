# Bisociation Reference

Theoretical foundation for connective humor. Source: Arthur Koestler, *The Act of Creation* (1964).

---

## Core Concept

**Bisociation** is the simultaneous perception of a situation or idea in two self-consistent but normally incompatible frames of reference. Every connective joke requires a **Common Aspect** — a word, phrase, or concept that has valid but different meanings in both frames.

Example: "The terms of service are written in Greek."
- **Frame 1** (Trojan Horse): Greek = the civilization that built the horse
- **Frame 2** (tech incomprehensibility): Greek = "it's Greek to me" (the idiom)
- **Bridge**: the word "Greek" vibrates on both wavelengths simultaneously

## Quality Measure

The previous independence of the two frames is the measure of quality. The more unrelated the frames were before the bridge, the harder the humor lands.

## Distinction from Association

- **Association**: thinking within a single pre-existing frame ("routine skills of thinking on a single plane")
- **Bisociation**: connecting two autonomous, independent frames through a common element

This distinction explains why AI humor engines that work passage-by-passage produce flat results — they associate within a single frame instead of bisociating across frames.

## The Decomposable Process

Finding bridges is a two-phase search:
1. **Divergent**: exhaustively enumerate the semantic fields of each theme (idioms, slang, technical terms, cultural references, homophones, connotations)
2. **Convergent**: systematically compare the fields for overlap, scoring candidates by the independence of the two matrices they bridge

The Connector agent (`.claude/skills/wit/agents/connector/AGENT.md`) implements this process.

---

*Added 2026-03-27. Source: three-agent research synthesis (comedy craft, AI humor failure, lateral thinking/cognitive science). Based on Koestler's bisociation theory, Kao/Levy/Goodman's ambiguity+distinctiveness model (Stanford 2015), Mednick's Remote Associates Test, and De Bono's lateral thinking toolkit.*
