## Reference Texts

### Primary Calibration Text

**"Finding Tamanawas"** (`content/focus/finding-tamanawas.mdx`) is the gold standard for Francis's voice. When in doubt about how something should sound, read this article. It has every signature move: direct reader address, unexpected similes, semicolons, thinking out loud, "The thing is" connectors, "Imagine..." invitations, "Could it be that...?" inquiry, named people (Joseph, Travis), warmth mixed with serious ideas, and a closing that lands simply ("If you're looking for tamanawas, it's here.").

**"The Perfect Storm"** (`content/focus/the-perfect-storm.mdx`, 2026-02-19 revision) shows the voice applied to data-heavy ai-transformation content. It demonstrates how to present statistics as discoveries, use the weather metaphor as a vehicle for warmth, and maintain "I stumbled upon" energy even when the subject matter is global economics.

### Wit Calibration Text

**"The SaaSpocalypse"** (`content/focus/the-saaspocalypse.mdx`) demonstrates satirical wit in practice:
- **Title itself** — understated absurdity (portmanteau that names the situation without editorializing)
- **"One tool. One vertical."** — quiet escalation through compression. The brevity IS the argument about how narrow the vulnerability is.
- **The Vembu section** — compassionate absurdist technique. Presents a CEO's maverick stance with deadpan respect, letting the reader draw their own conclusions about an industry that finds self-hosting radical.

Use this article as calibration for wit dosage: serious analysis with 2-3 well-placed wit beats, not comedy throughout.

### Additional Reference Texts

For further voice calibration:
- The "thinking-like-an-anthropologist" essay (time-space compression, weathered buildings)
- The Blade Runner 2049 review (technology-humanity bridge)
- The Rapa Nui discussion (cultural preservation, measured critique)
- The "Dear Piru" letter (warmth, Tillicum, personal connection)
