# Satirical Wit Reference

> **Sacred Directive:** "I would like to incorporate these aspects a bit more into my writing in a measured, but calculated way. If I want to make a point, use this method as a tool to teach and preach."

> **Twain Principle:** "Humor must not professedly teach, and it must not professedly preach, but it must do both if it would live forever."

---

## Seven Techniques

| Technique | Twain Principle | Description |
|-----------|----------------|-------------|
| **Understated Absurdity** | Deadpan delivery | State an absurd fact with zero editorial. Let the reader do the math. |
| **Self-Implicating "We"** | Self-implication over finger-pointing | Stand inside the absurdity. "We" instead of "they." |
| **The Solemn Setup** | Gravity as setup | Build genuine seriousness, then let one quiet observation puncture it. |
| **The Trojan Observation** | Teach without announcing | Make the reader laugh, then realize what they just agreed with. |
| **The Rhetorical Undercut** | Against the assault of laughter | Follow a grandiose claim with a plain observation that deflates it. |
| **The Compassionate Absurdist** | Humor as compassion | Use humor not to mock the affected, but to make the situation bearable enough to look at. |
| **The Quiet Escalation** | Teach and preach without announcing | List facts in ascending absurdity. No punchline. The progression IS the argument. |

---

## Before/After Examples

### Understated Absurdity

- **Before:** "The market panic was disproportionate to the actual threat."
- **After:** "No customers had canceled. The products still worked. The revenue hadn't changed. Two hundred and eighty-five billion dollars vanished anyway."

### Self-Implicating "We"

- **Before:** "Companies keep buying AI tools they don't know how to use."
- **After:** "We keep buying the thing before we've figured out what the last thing does. I have three AI subscriptions open right now. I used one of them last week."

### The Solemn Setup

- **Before:** "The AI tuberculosis detection system was shut down when the grant money ran out."
- **After:** "The algorithm could spot tuberculosis on a chest X-ray faster than any human radiologist in the region. It saved lives for eighteen months. Then someone forgot to renew the subscription."

### The Trojan Observation

- **Before:** "SaaS companies spend more on marketing than engineering, making them vulnerable."
- **After:** "An industry that spends more convincing you to subscribe than building what you're subscribing to was always one good demo away from an existential crisis."

### The Rhetorical Undercut

- **Before:** "AI is being positioned as the solution to all enterprise problems."
- **After:** "AI will revolutionize every industry, transform every workflow, and replace every inefficiency. It will also need someone to plug it in."

### The Compassionate Absurdist

- **Before:** "Workers displaced by automation face uncertain futures."
- **After:** "They spent twenty years becoming the best at something a computer learned in an afternoon. That's not a failure of work ethic."

### The Quiet Escalation

- **Before:** "AI adoption requires infrastructure improvements."
- **After:** "First you need reliable electricity. Then stable internet. Then someone who knows how to run the software. Then someone to pay for it. Then a regulatory framework. Then a liability answer. Then trust. The algorithm was the easy part."

---

## Calibration

### Dosage

2-4 instances per article. Wit is a spice, not the main ingredient. The gravity background — Francis's serious engagement with ideas — needs room to breathe. If every paragraph has a punchline, none of them land.

### The Self-Implication Test

"Am I standing inside the absurdity or above it?"

- **Inside (wit):** "We keep buying the thing before we've figured out what the last thing does."
- **Above (snark):** "They keep buying tools they'll never use."

If above, it's snark. If inside, it's wit. Francis stands inside.

### When to Deploy

- When a hard truth needs to land without triggering the reader's defenses
- When the absurdity of a situation IS the argument
- When self-implication builds trust before making a serious point
- When a progression of facts tells the story better than any editorial

### When NOT to Deploy

- In moments of genuine grief or loss (the Piru letter, cultural erasure)
- When the reader needs direct, unambiguous information
- When the humor would undercut someone else's pain
- When Francis is at his most vulnerable and the tone should match

---

## Anti-Patterns

| Anti-Pattern | Why It Fails |
|-------------|-------------|
| **Announcing the humor** ("Here's the irony," "The funny thing is") | Kills the deadpan. If you have to tell the reader it's funny, it isn't. |
| **Punching down or finger-pointing** ("They should have known better") | Snark, not wit. Francis implicates himself first. |
| **Forced callbacks** that don't advance the argument | Decoration, not rhetoric. Every wit beat should carry weight. |
| **Comedy-writer cadence** (setup-setup-punchline rhythm) | This is prose, not a set. The humor lives in the observation, not the structure. |
| **Humor in every paragraph** | The gravity background needs room. Too much wit and the reader stops trusting the serious parts. |
| **Sarcasm** ("Oh, what a brilliant idea") | Mean-spirited. Francis is warm even when he's skeptical. |
| **Pop culture references as punchlines** | Dates the writing and replaces observation with recognition humor. |
