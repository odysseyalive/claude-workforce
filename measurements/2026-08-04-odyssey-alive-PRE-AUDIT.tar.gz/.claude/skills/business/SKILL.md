---
name: business
description: Odyssey Alive business plan 2025-2030 reference for strategic planning and assessments.
allowed-tools: Read, Glob, Grep
minimum-effort-level: high
strictness: standard
---

# Odyssey Alive Business Plan 2025-2030

**Trigger phrases:** "Business plan", "Strategic assessment", "Revenue goals", "Product roadmap", "Financial projections", "Growth strategy", "Company vision", "Business assessment"

Reference document for strategic planning, assessments, and alignment with company vision.

**Grounding:** Read the relevant reference file before answering any business plan question.

See individual reference files for:
- [references/timeline.md](references/timeline.md) — Strategic timeline, year-by-year objectives and status
- [references/products.md](references/products.md) — Product portfolio and competitive advantages
- [references/revenue.md](references/revenue.md) — Active revenue streams and revenue path
- [references/financials.md](references/financials.md) — Financial projections, expenses, inflation hedge strategy
- [references/strategy.md](references/strategy.md) — Growth strategy, content strategy, distribution channels
- [references/metrics.md](references/metrics.md) — Success metrics, key dates, source document

## Analytics Integration

Before strategic assessments, run `/analytics report` to ground projections in actual traffic data rather than assumptions.

## Strategic Assessment Agent

**Precheck (before spawning):** confirm actual analytics data is in hand — either an `/analytics report` summary from this session or equivalent traffic data supplied by the user. IF no data is available → run `/analytics report` first (per § Analytics Integration) or ask Francis for the data; do NOT spawn the assessor with an empty "Analytics data:" slot, because it will assess projections against nothing.

For deep assessments, spawn the strategic-assessor agent:

```
Task tool with subagent_type: "general-purpose"
prompt: "Read .claude/skills/business/agents/strategic-assessor/AGENT.md for instructions,
        then assess [specific question or area]. Analytics data: [paste summary]."
```

See [agents/strategic-assessor/AGENT.md](agents/strategic-assessor/AGENT.md) for details.

---

## Quick Reference

- **Mission:** Safeguard the human element in AI-powered communication
- **Tagline:** Where human intuition meets digital precision
- **Year 1 revenue target:** $157,000+
- **Year 5 revenue target:** $750,000+ ARR
- **Core products:** Communication Intelligence Platform, Ethical Data Stewardship Suite, Cultural Communication Compass
- **Revenue anchor:** $72K/year ticketing agency modernization

---

