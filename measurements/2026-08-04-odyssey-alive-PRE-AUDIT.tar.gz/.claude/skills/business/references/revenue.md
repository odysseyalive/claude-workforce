# Active Revenue Streams

| Stream | Type | Revenue | Status |
|--------|------|---------|--------|
| Ticketing Agency Modernization | Retainer | $6,000/month ($72K/year) | Stable anchor |
| Cabo Calendar Project | Project fee | $4,000-8,000 total | In progress — first calendar delivered |
| SBA AI Consulting (Tillamook County) | Hourly + project | $65/hr + project fees | New — teaching classes, advisory |
| Content/Thought Leadership | Lead generation | Indirect | 22 articles, growing traffic |

## Revenue Path

**Near-term (2026):** Consulting + retainer income while SaaS is in R&D
**Mid-term (2027):** SaaS subscriptions begin supplementing consulting
**Long-term (2028+):** SaaS becomes primary revenue, consulting shifts to premium/strategic
