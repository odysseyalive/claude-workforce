---
name: present
description: Create browser-based presentations for conferences using reveal.js. Generates MDX content, slide graphics via Nano Banana, and validates output.
allowed-tools: Read, Glob, Grep, Bash, Edit, Write, ToolSearch, Skill, Task
minimum-effort-level: xhigh
strictness: standard
---

# Presentation Workflow

Browser-based slides built on reveal.js. Content authored as MDX, processed by Velite, split into slides by `---` separators.

---

<!-- origin: user | added: 2026-02-14 | immutable: true -->
## Directives

> **"Use Playwright instead of the Chrome browser plugin to visually view and debug sites, every time. At the end of every debug session, no temporary files, images, etc. should be left over after the debugging has been completed."**

*— Added 2026-04-11, source: user directive*

> **"Slide images use flat illustration style, NOT watercolor. High contrast for projector readability."**

*— Added 2026-02-14, source: initial skill creation*

> **"No text baked into generated images. Text belongs in the slide markup, not the graphic."**

*— Added 2026-02-14, source: initial skill creation*

> **"Speaker notes go in `<aside class="notes">` blocks. They're private to the presenter (S key in reveal.js)."**

*— Added 2026-02-14, source: initial skill creation*

> **"Each slide should serve dual purpose: informative for the audience AND a guide for the presenter."**

*— Added 2026-02-14, source: Feb 17 AI conference design*

> **"Slide content is written for the audience, not the presenter. Identify the audience before generating any content — ask if not provided. Speaker notes are the only place for presenter-specific guidance (what to click, what to say, time cues). If it wouldn't make sense to someone sitting in the third row, it doesn't belong on the slide."**

*— Added 2026-02-14, source: post-conference review of context-is-the-interface*

> **"Before outlining slides, research the topic and the audience. Find the intersection — what this specific audience needs to understand about these topics — and build the presentation around that. Don't write slides around what the presenter already knows; write them around what the audience needs to hear."**

*— Added 2026-02-14, source: post-conference review of context-is-the-interface*

> **"Do not display Odyssey Alive branding, company info, URLs, or contact details on slides unless explicitly asked. Francis is a paid presenter — showing company info is a conflict of interest in most contexts."**

*— Added 2026-02-14, source: user instruction*

> **"Once the audience is known, do a full research pass on the region or community being addressed — their values, culture, local economy, and business makeup. This analysis must be completed before writing any content. You can't speak to people you haven't bothered to understand."**

*— Added 2026-02-14, source: user instruction*

> **"Every slide must be visually distinct from the slides around it. A deck where every slide looks the same is confusing — the audience can't tell a section opener from a key insight from a closing thought. Use the slide type system (title, divider, statement, content, visual, quote, closing) and evaluate each slide's design individually using `/frontend-design`, not just a uniform template."**

*— Added 2026-02-14, source: user instruction, post-conference review*

> **"Every slide must bridge from the previous one. The audience should feel each idea follows from the last, not that the topic changed. Use the previous slide's conclusion as the launch point for the next slide's action title. Speaker notes must include the transition phrase that connects the two. 'Great, now let's talk about X' is not a bridge."**

*— Added 2026-02-16, source: concept bridging pattern from study-prep skill*

> **"Images and text must be large enough to see and read from the back of a room and take up most of the slide. Text uses absolute pixel sizes (32px+ body, 48px+ headings) — not em units, which compound to unreadable sizes in reveal.js. Images must override the default slide-type CSS constraints (especially the visual type's `p { max-width: 30em }` which shrinks images wrapped in MDX paragraph tags). When writing custom slide CSS, always include `p:has(img) { max-width: 100% }` to prevent paragraph constraints from shrinking images."**

*— Added 2026-03-16, source: user instruction (inline)*

*Postscript 2026-04-11: the `p:has(img) { max-width: 100% !important }` rule and larger image max-heights (visual 460px, closing 440px, statement 360px, content 320px, default 380px) are now baked into `src/app/globals.css`. New decks inherit them automatically. Don't duplicate the override per slide-type rule. The auto-classifier in `SlideViewer.tsx` also routes image+prose slides under 400 textOnly chars to the `visual` type.*
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Each slide should serve dual purpose: informative for the audience AND a guide for the presenter." -->
CHECKPOINT — Dual-Purpose Slide Gate:
1. After each slide is drafted (main slide body + speaker notes), enumerate the slide's two channels: (a) visible slide content, (b) speaker notes (`<aside class="notes">` block).
2. Check channel (a) — visible slide content — against the audience test: Does the slide's headline + body text communicate the idea to a viewer who hears no audio? A viewer in row 3 with the sound off should still grasp the slide's point.
3. IF the slide headline is a topic label rather than a claim ("AI Tools", "Results", "Context") → STOP. Rewrite as an action title that makes a complete statement ("AI tools multiply judgment, not replace it").
4. IF the slide body has no concrete content beyond the headline AND the slide is not a title/divider type → STOP. Add at least one anchoring element (a phrase, a figure, an image with clear subject) that stands alone.
5. Check channel (b) — speaker notes — against the presenter test: Do the notes give the presenter a cue to deliver (transition phrase, timing note, what to emphasize, what to click, what question to pose)?
6. IF speaker notes are empty OR merely repeat the slide body verbatim → STOP. Add presenter-specific cues: the transition phrase from the previous slide, any stage directions, the key beat to emphasize.
7. IF speaker notes contain content that should be on the slide (critical audience information hidden in notes) → STOP. Move to slide body.
8. IF both channels pass (slide works silently for audience AND notes guide the presenter distinctly) → CONTINUE to next slide.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Every slide must bridge from the previous one. The audience should feel each idea follows from the last, not that the topic changed. Use the previous slide's conclusion as the launch point for the next slide's action title. Speaker notes must include the transition phrase that connects the two. 'Great, now let's talk about X' is not a bridge." -->
CHECKPOINT — Slide Bridge Gate:
1. After all slides are drafted, enumerate each slide in sequence (slide N → slide N+1).
2. For EACH pair (slide N, slide N+1), check two elements:
   a. Slide N+1's action title launches from a specific claim or conclusion in slide N (i.e., it continues the reasoning, not restarts it).
   b. Slide N+1's speaker notes include a transition phrase that names the prior claim from slide N (e.g., "Given [claim from N], the next move is…").
3. IF the transition phrase is generic ("Let's talk about X", "Now on to Y", "Next, we'll cover Z") → STOP. Rewrite the transition to name the specific prior claim being built on.
4. IF slide N+1's action title does not reference or extend slide N's conclusion → STOP. Rewrite the action title to launch from slide N's conclusion.
5. IF any pair fails either check → mark the deck as incomplete and fix before running slide-evaluator.
6. IF every pair passes → CONTINUE to slide-evaluator agent spawn.
<!-- END ENFORCEMENT ANNOTATION -->

---

## Modes

| Command | Purpose |
|---------|---------|
| `/present create` | Create a new presentation from topic/outline |
| `/present edit [slug]` | Edit an existing presentation |
| `/present graphics [slug]` | Generate/regenerate slide graphics only |

---

## Workflow: `/present create`

<!-- MODEL-LANE-GATE START — auto-generated by /skill-builder route embed; safe to replace -->
<!-- origin: skill-builder | modifiable: true -->
## Model-Lane Preflight

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: /skill-builder route embed (model-lane gate, slim form per the 2026-06-06 2-Brain Harness directive: gates are slimmed, never stripped — this block is the lane checkpoint that travels with the skill through EVERY entry path, including hand-run invocations, which are always permitted. It goes silent when /route already covered the endeavor. Advisory-only per the 2026-06-06 No-Switch-Prompt directive: the gate CANNOT switch the model and NEVER asks the user to — its entire output is one advisory line, which names the exact remedy informationally per the 2026-06-11 named-command advisory directive. -->
CHECKPOINT — Model-Lane Preflight Gate (slim, advisory-only; fires at the TOP of this skill's workflow, before any generative step):
1. SKIP silently IF ANY of: `/route` dispatched this invocation after running its own lane preflight (a lane advisory OR ask already printed, route otherwise ASSESSED the lane this turn, or it was deliberately suppressed — route's coverage extends to the whole endeavor whether route asked, matched, or the user declined, including skills this one chains); this skill's frontmatter sets `model-lane-gate: off`; the session is headless / non-interactive; this gate is executing inside a subagent (a subagent is already model-pinned via its own frontmatter); OR an advisory for this LANE already printed this endeavor AND the active model is unchanged (advise at most once per (lane, active-model) pair per endeavor).
2. Resolve this skill's lane (own `lane:` frontmatter → the Skill→Lane table in `.claude/skills/skill-builder/references/model-lanes.md` → NO LANE) and the lane's Preferred Model. IF no lane resolves OR the preferred-model cell is empty → silent no-op (correctly absent, not a gap). IF this skill declares per-function lanes AND the invocation's resolved mode has its own row → that function's lane governs; otherwise the skill-level lane covers all modes.
3. Read ACTIVE_MODEL from the session system-context line "The exact model ID is …" (strip `[1m]`/`[200k]`, lowercase — model-lanes.md § Active-Model Detection; never an env var or Bash probe). IF the Preferred Model is malformed or names a clearly superseded family → emit the one-line stale-mapping advisory and proceed; never advise from a stale mapping, never validate against a hardcoded list.
4. Compare. Match → silent no-op. Mismatch → print ONE advisory line and PROCEED: "Lane advisory: this skill declares the `<lane>` lane (preferred `<preferred>`); the active model is `<active>` — to align, run `/model <preferred>` and re-invoke; proceeding as-is." Naming the command is INFORMATIONAL (named-command advisory directive, 2026-06-11): NEVER an AskUserQuestion, never a blocking wait (No-Switch-Prompt directive, 2026-06-06). A skill can NEVER switch the session model and never asks the user to.
5. Primary-lane scope. This gate fires ONCE per invocation, for the resolved PRIMARY lane. Cross-lane mid-workflow steps never re-advise — they delegate via this skill's LANE-AGENT-EMBED Delegation Map when present (see .claude/skills/skill-builder/references/lane-delegation.md). Delegation is never a substitute for THIS gate: analytical primary work runs on the analytical main model — never a creative main session orchestrating analytical-pinned agents to dodge the lane.
<!-- END ENFORCEMENT ANNOTATION -->
<!-- /origin -->
<!-- MODEL-LANE-GATE END -->



**Grounding:** [references/workflow.md](references/workflow.md) — full phase-by-phase procedure:

- **Phase 1** Input (topic, event, audience, duration, source material, slide count — audience is mandatory)
- **Phase 1.5** Research (community + topic landscape + intersection)
- **Phase 2** Outline (action titles, bridges, structure arc)
- **Phase 3** Content (MDX authoring, slide-evaluator + voice-validator, finishing chain)
- **Phase 4** Graphics (Nano Banana flat illustration + hero, image-eval)
- **Phase 5** Verify (`pnpm build`, render check, keyboard nav)

---

## Grounding

Read the relevant reference file before using its content:
- [references/design-principles.md](references/design-principles.md) — Research-backed presentation principles
- [references/slide-content.md](references/slide-content.md) — Audience-first content, density, MDX format examples
- [references/slide-types.md](references/slide-types.md) — 7-type taxonomy, visual rhythm, typography scale, /frontend-design evaluation
- [references/image-generation.md](references/image-generation.md) — Flat illustration templates, style rules, image eval adaptation
- [references/reveal-js.md](references/reveal-js.md) — Keyboard shortcuts, speaker notes, layout rules
- [references/schema.md](references/schema.md) — Frontmatter schema, file organization, hero images, issues log

---

## Post-Action Capture

After delivering a presentation, if audience feedback or slide review patterns emerge, suggest recording in the awareness ledger (PAT or DEC record). Never auto-record — ask the user first.


---

<!-- ROUTE-EMBED START — auto-generated by /skill-builder route embed; safe to replace -->
<!-- origin: skill-builder | modifiable: true -->
## Route Consultation

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: /skill-builder route embed. Closes the dispatch-bypass gap: a /route announcement is not a substitute for a Skill tool call, and consulting /route does not license the caller to execute the target skill's procedure manually. -->
CHECKPOINT — Skill Routing Gate:
1. During this skill's workflow, IF a step requires research, web search, lookup, analysis, or any follow-up NOT already covered by an explicit tool or skill name → STOP before improvising.
2. Already-named exception. IF the current workflow step EXPLICITLY names tools or skills (e.g., "use Read", "spawn the X agent", "invoke /[skill]") → execute as written. Do NOT consult `/route` for steps already determined. Skip to your skill's next step.
3. Otherwise → invoke `/route <task description>` via the Skill tool. `/route` reads its index and either returns a target skill or reports "no match."
4. Dispatch Required. IF `/route` returns a target → the IMMEDIATE next tool call MUST be `Skill(skill=<target>, args=<derived>)`. Do NOT execute the target skill's procedure steps yourself with raw Edit / Write / Bash / Task / Agent / Read calls. The target skill's gates (asset backups, agent panels, exit tests, cascade steps, frontend-design reviews, immutable-directive checks) ONLY fire when its SKILL.md is loaded via Skill — running steps manually silently skips every gate.
5. Bypass detection. IF a Skill dispatch was just announced (yours or `/route`'s) and the next tool call is non-Skill work germane to the routed task → STOP. Print verbatim: "Route dispatch announced but Skill call skipped. Invoking Skill tool now." then issue the Skill call.
6. No-match path. IF `/route` returns "no match" → proceed with the most direct, manual approach. Document the gap; the user may want to register a skill.
7. Follow-ups loop back. After the dispatched skill returns, IF further follow-up is needed → consult `/route` again via Skill. Do not freelance the next step.
8. Auto-mode override clause. Auto-mode ("execute immediately", "prefer action over planning") does NOT override clauses 4–5. Auto-mode chooses WHAT to do; once a routing decision is on the table, the only valid next action is Skill invocation.
<!-- END ENFORCEMENT ANNOTATION -->
<!-- /origin -->
<!-- ROUTE-EMBED END -->
