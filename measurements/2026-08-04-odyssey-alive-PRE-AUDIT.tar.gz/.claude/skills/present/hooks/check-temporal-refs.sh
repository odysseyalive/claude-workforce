#!/bin/bash
# Hook: Flag unresolved relative date phrases in presentation content
# These phrases become stale once presented at events. Require absolute dates instead.
# Scope: Presentation MDX files only (content/presentations/)

CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR

INPUT=$(cat 2>/dev/null) || exit 0

# Extract file path from tool JSON
FILE_PATH=$(echo "$INPUT" | grep -oP '"file_path"\s*:\s*"[^"]*"' | head -1 | sed 's/.*"file_path"\s*:\s*"//;s/"$//')

# Scope check: only presentation MDX files
if ! echo "$FILE_PATH" | grep -q 'content/presentations/.*\.mdx$' 2>/dev/null; then
  exit 0
fi

# Scope check: skip infrastructure files
if echo "$FILE_PATH" | grep -q '\.claude/' 2>/dev/null; then
  exit 0
fi

# Get content from Write or Edit tool
CONTENT=$(echo "$INPUT" | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    inp = data.get('tool_input', data)
    print(inp.get('content', inp.get('new_string', '')))
except:
    pass
" 2>/dev/null)

if [ -z "$CONTENT" ]; then
  exit 0
fi

# Strip speaker notes (aside blocks) — temporal refs in notes are acceptable
CONTENT=$(echo "$CONTENT" | python3 -c "
import sys, re
text = sys.stdin.read()
text = re.sub(r'<aside[^>]*class=[\"'\'']notes[\"'\''][^>]*>.*?</aside>', '', text, flags=re.DOTALL)
print(text)
" 2>/dev/null)

# Check for relative temporal phrases that become stale in published presentations
PHRASES=$(echo "$CONTENT" | grep -inP '\b(this week|this month|this year|today|yesterday|tomorrow|last week|last month|next week|next month|this quarter|next quarter|last quarter)\b' | head -5)

if [ -n "$PHRASES" ]; then
  echo "BLOCKED: Relative date phrases found in presentation content. Presentations are delivered at specific events — replace with absolute dates (e.g., 'March 2026' instead of 'this quarter'). CLAUDE.md rule: temporal references are literal." >&2
  echo "$PHRASES" >&2
  exit 2
fi

exit 0
