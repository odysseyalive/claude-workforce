#!/bin/bash
# Hook: Block Odyssey Alive branding in presentation slides per /present directive
# "Do not display Odyssey Alive branding, company info, URLs, or contact details
# on slides unless explicitly asked."
# Scope: content/presentations/ files only
CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR

INPUT=$(cat 2>/dev/null) || exit 0

# Scope check: only apply to presentation MDX files
FILE_PATH=$(echo "$INPUT" | grep -oP '"file_path"\s*:\s*"[^"]*"' | head -1 | sed 's/.*"file_path"\s*:\s*"//;s/"$//')
if ! echo "$FILE_PATH" | grep -q 'content/presentations/'; then
  exit 0
fi

# Check for branding patterns in the content being written
CONTENT=$(echo "$INPUT" | grep -oP '"content"\s*:\s*"[^"]*"' | head -1 || echo "$INPUT")
# Also check new_string for Edit tool
NEW_STRING=$(echo "$INPUT" | grep -oP '"new_string"\s*:\s*"[^"]*"' | head -1 || true)

CHECK_TEXT="$CONTENT $NEW_STRING"

if echo "$CHECK_TEXT" | grep -qi 'odysseyalive\.com\|odyssey alive\|francis@odysseyalive\|odysseyalive'; then
  # Allow in speaker notes (aside blocks)
  if echo "$CHECK_TEXT" | grep -qi '<aside[^>]*class=.notes'; then
    exit 0
  fi
  echo "BLOCKED: Odyssey Alive branding detected in presentation slide content. Per /present directive: do not display company info unless explicitly asked. Move to speaker notes if needed for presenter reference." >&2
  exit 2
fi
exit 0
