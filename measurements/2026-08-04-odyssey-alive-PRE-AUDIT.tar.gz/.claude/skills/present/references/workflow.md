# Presentation Workflow: `/present create`

### Phase 1: Input

Gather from user:
- **Topic** and working title
- **Event** name, date, and format (lecture, demo, workshop)
- **Audience** — Who is in the room? What's their background, expertise level, and what do they care about? **This is mandatory. If the user doesn't provide audience info, ask before proceeding.**
- **Duration** target
- **Source material** (article, outline, notes)
- **Slide count** target

### Phase 1.5: Research

Research three fronts before outlining: **the community**, **the topic landscape**, **the intersection**. Summarize for user before proceeding. See [slide-content.md](slide-content.md) for checklists.

### Phase 2: Outline

Structure arc: Opening hook → oscillate "what is" / "what could be" → close on "the new bliss." Generate slides with **action titles** (complete sentences) and **bridges** (connection to previous). Test: titles alone should tell the story. Present outline to user before content.

### Phase 3: Content

1. Load `/voice` and `/writing` for Francis's voice
2. Write MDX to `content/presentations/[slug].mdx` with `---` separators and `<aside class="notes">` blocks
3. Run slide-evaluator agent ([../agents/slide-evaluator/AGENT.md](../agents/slide-evaluator/AGENT.md)) and voice-validator agent ([../agents/voice-validator/AGENT.md](../agents/voice-validator/AGENT.md)). Fix violations.
4. Run the content finishing chain per `.claude/skills/text-eval/references/finishing-chain.md`. Content type: **presentation slides**.

**Frontmatter:** See [schema.md](schema.md).

### Phase 4: Graphics

1. Create directory: `assets/images/presentations/inline/[slug]/`
2. Generate slide images via Nano Banana using **flat illustration style** (see [image-generation.md](image-generation.md))
3. Generate a **hero image** for the `/presentations` directory page. Save to `assets/images/presentations/hero/[slug]-hero.png`. Add `image` and `imageAlt` to frontmatter. Style should match the presentation's visual theme (watercolor for watercolor decks, flat for flat decks).
4. Run `/image-eval` with adapted criteria (projector readability, no text in images)
5. Regenerate any that fail evaluation

### Phase 5: Verify

1. Run `pnpm build` to process through Velite
2. Check `/slides/[slug]` renders correctly
3. Test keyboard navigation (arrows, Esc for overview, S for speaker notes)
