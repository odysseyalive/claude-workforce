# Slide Content Principles

### Audience-First Slides

Slide content is written for the people in the room, not the person on stage. Every slide should make sense to someone sitting in the third row who has no backstory.

**Slide content** (what the audience sees):
- Explains the concept in terms the audience relates to
- Uses their language, their pain points, their context
- Answers "why should I care?" before "how does it work?"

**Speaker notes** (what the presenter sees, via S key):
- Demo steps, prompts to type, time cues
- Transition cues, engagement prompts
- What to click or show next

**The test:** Read the slide without the speaker notes. Does it teach the audience something? Or does it only make sense if you're the one presenting? If it's the latter, the teaching content needs to move from notes onto the slide, and the presenter cues need to move into notes.

### Content Density

Target ~20 words per slide. Prefer visual evidence over bullet lists.

- **Title slides**: Action title + subtitle only
- **Content slides**: One idea, 3 bullets max (prefer a chart, diagram, or image instead)
- **Image slides**: Image + action title (the title carries the message, the image is evidence)
- **Demo marker slides**: Action title + 3 bullet checklist of what to cover

### Slide-to-Slide Bridging

Every slide must connect to the previous one. The audience should feel each idea follows naturally from the last.

**The bridge pattern:**
1. The previous slide's conclusion raises a question or creates a gap
2. The next slide's action title answers that question or fills that gap
3. The speaker notes include the spoken transition phrase

**Example bridge:**

Slide 3 ends with: "Your Consultant Is Brilliant — But the Room Is Empty"
Speaker notes for Slide 4 include: "So the room is empty. What would it look like if it were full? What does a well-briefed AI actually look like?"
Slide 4 title: "Projects Give Your AI a Memory That Lasts"

**What makes a bad bridge:**
- "Moving on to our next topic..." (mechanical, no connection)
- No transition phrase in speaker notes (audience feels the jump)
- Slide titles that don't follow logically when read in sequence

### Speaker Notes

Private notes in `<aside class="notes">` blocks:
- **Transition phrase** connecting this slide to the previous one (first line)
- Specific prompts to type (for live demos)
- Time cues ("~5 min here, then move on")
- Transition cues ("Switch to browser now")
- Engagement prompts ("Ask: has anyone tried this?")
- What to click/show next

### MDX Slide Format

```mdx
# Your Consultant Is Brilliant — But the Room Is Empty

![Flat illustration of an empty office with a single desk](../../assets/images/presentations/inline/slug/slide-01-empty-room.jpg)

The smartest advisor in the world can't help you without context.

<aside class="notes">
Pause after the image lands. Let the audience read the title.
"Most people approach AI like a search bar. That's maybe ten percent of the capability."
~2 min, then transition to the solution.
</aside>

---

# Projects Give Your AI a Memory That Lasts

- Business description persists across conversations
- Customer profiles stay loaded — no re-explaining
- Last quarter's data is always in the room

<aside class="notes">
DEMO: Open Claude.ai → Projects → show the sidebar.
"Think of this as briefing your consultant before the meeting starts."
~5 min with demo.
</aside>
```

## Pre-Outline Research Checklist

Before outlining any presentation, research on three fronts. Use a Task agent with web search.

### 1. The Community

Research the region or group being addressed:
- Local/regional economy — major industries, employers, economic trends
- Business makeup — what kinds of businesses are in the room? Size, sector, maturity
- Culture and values — what does this community care about? What's their identity?
- Pain points — what challenges are specific to this area or group right now?

### 2. The Topic Landscape

What's the current conversation around these topics?
- Common misconceptions
- Recent developments
- Hot-button issues

### 3. The Intersection

Where do the community's reality and the topic meet?
- What specific angle will resonate with *these* people, not a generic audience?
- What examples, analogies, or references will land because they connect to their world?
