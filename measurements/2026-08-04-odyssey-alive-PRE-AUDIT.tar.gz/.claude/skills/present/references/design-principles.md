# Presentation Design Principles

Research-backed principles from MBB consulting (McKinsey, Bain, BCG), presentation design authorities (Duarte, Garr Reynolds, Michael Alley), cognitive science, and Fortune 500 boardroom practice.

### Action Titles

The single most validated principle across all sources: **every slide title must state a conclusion as a complete sentence, not name a topic.**

- **Amateur:** "Market Overview"
- **Professional:** "German market growing 12% annually, outpacing US by 3x"

A reader should be able to read only the slide titles, in sequence, and understand the entire argument. McKinsey calls these "action titles." Penn State research found statistically significant improvements in comprehension and retention when slides used assertion headlines versus topic-and-bullets format. Lower cognitive load, stronger delayed recall.

**The rule:** Action title contains a verb, stays under 15 words, never exceeds two lines, and passes the "so what" test.

### One Message Per Slide

Every slide communicates exactly one insight. Two points = two slides. The moment a slide serves two masters, the audience serves neither.

### Cognitive Load Limits

Research across 17 lectures found optimal medians:
- **~20 words per slide** (hard ceiling: 30)
- **~5 lines per slide**
- **28pt minimum font** (sans-serif)
- **3 visual elements maximum**

When confronted with a single bullet point, study participants "engaged comprehensively, typically reading every word." The fewer words on the slide, the more get absorbed.

### The Redundancy Effect

When a presenter reads text simultaneously displayed on screen, comprehension drops. The audience splits attention between reading and listening. **If you'll say it, the slide shows the evidence, not the words.**

### Narrative Frameworks

**SCQA (Consulting standard — for structured arguments):**
- **Situation:** Facts the audience already agrees with
- **Complication:** What changed, what threatens, what creates urgency
- **Question:** The implied question the audience now has
- **Answer:** Your recommendation, stated first

Present conclusions first, evidence second. Think bottom-up, present top-down.

**Duarte Sparkline (Conference standard — for persuasive talks):**
Oscillate between "what is" (current reality) and "what could be" (transformed future). The rhythm creates tension and resolution. The audience is the hero, the presenter is the mentor. End at "the new bliss" — the state the audience reaches when they adopt your idea.

### The Executive Bar

What billion-dollar company audiences expect:

| Expectation | Why |
|-------------|-----|
| Conclusions on slide 1-2, not slide 47 | Executives filter through "how does this help us win?" |
| 10 min of speaking, 20 min of dialogue | The presentation catalyzes conversation, not replaces it |
| Pre-reads for data-heavy material | Slides stay minimal; detailed analysis sent in advance |
| Every number framed comparatively | Raw numbers without benchmark/competitor/prior context signal amateur |
| Transparency over curation | Presenting only good news destroys credibility |
| Sourced, dated data | Unsourced numbers are treated as opinions |

### Signal-to-Noise Ratio

For every element on the slide, ask: "If I remove this, does my message lose effectiveness?" If no, remove it.

- **Restrain:** Stop adding — the hardest discipline is editing yourself
- **Reduce:** Strip to essentials — footers, logos, decorative items are noise
- **Emphasize:** Make the signal unmistakable through contrast, size, and position

Whitespace is not wasted space. A crammed slide signals anxiety about whether the content is sufficient.

### Amateur Signals to Avoid

- Topic titles instead of action titles
- Wall-of-text slides (40+ words)
- Unsourced data
- No "so what" — data without interpretation
- Generic stock photography
- Decorative clutter (logos on every slide, gradients, borders)
- Burying the conclusion at the end
- One-size-fits-all decks not tailored to the audience

### Modern Practice (2024-2026)

- **Typography as visual element** — massive bold titles taking 50% of screen, replacing decorative graphics
- **Data storytelling** — one critical insight per chart, full dataset in appendix
- **Custom visuals over stock** — audiences have stock-photo blindness
- **Shorter, bolder, more visual** — text-heavy 50-slide decks are a relic
