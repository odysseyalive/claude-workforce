# Image Generation

## Templates

### Base Template (Flat Illustration)

```
A clean, minimal illustration of [SCENE]. [DETAILS].
Flat design style with bold shapes and limited color palette.
Colors: warm cream (#F7EDE2), coral (#FFA07A), amber (#FFE0A8),
deep brown (#4A3828). High contrast for projector readability.
Simple composition, no fine detail. Aspect ratio 16:9.
```

### Scene Templates

**Consultant/Meeting:**
```
A clean, minimal illustration of a consultant's desk with organized documents
and a glowing laptop screen. Flat design style with bold shapes and limited
color palette. Colors: warm cream (#F7EDE2), coral (#FFA07A), amber (#FFE0A8),
deep brown (#4A3828). High contrast for projector readability. Simple
composition, no fine detail. Aspect ratio 16:9.
```

**Technology/AI:**
```
A clean, minimal illustration of connected nodes forming a network pattern,
with one highlighted node radiating warmth. Flat design style with bold shapes
and limited color palette. Colors: warm cream (#F7EDE2), coral (#FFA07A),
amber (#FFE0A8), deep brown (#4A3828). High contrast for projector readability.
Simple composition, no fine detail. Aspect ratio 16:9.
```

**Growth/Progress:**
```
A clean, minimal illustration of ascending steps or building blocks, each
layer adding height. Flat design style with bold shapes and limited color
palette. Colors: warm cream (#F7EDE2), coral (#FFA07A), amber (#FFE0A8),
deep brown (#4A3828). High contrast for projector readability. Simple
composition, no fine detail. Aspect ratio 16:9.
```

---

## Style Rules

| Rule | Reason |
|------|--------|
| Flat illustration, not watercolor | Watercolor looks muddy on projectors |
| Brand palette only | Visual consistency with Odyssey Alive |
| High contrast | Must read in a lit conference room |
| No text in images | Text renders differently at various scales |
| One concept per image | Audience gets 3-5 seconds to process |
| 16:9 aspect ratio | Matches standard projector/screen ratio |
| No fine detail | Detail is lost at projector resolution |
| Bold shapes | Visible from the back of the room |

---

## Image Evaluation Adaptation

When running `/image-eval` for presentation graphics, adapt these criteria:

**Check for:**
- Projector readability (sufficient contrast between elements)
- Brand color compliance (cream, coral, amber, brown only)
- No text baked into images
- Simple composition (one focal point)
- Signatures or watermarks (reject)
- AI symmetry tells (reject)
- Overly complex or detailed rendering (reject)

**Skip:**
- Watercolor technique checks
- Paper texture checks
- Edge fade/border checks

---

## Session Consistency

When generating multiple slide images for a presentation:

1. Use the same `conversation_id` across all generations (e.g., `"presentation-slides"`)
2. Set `use_image_history: true` on the 2nd+ images
3. This tells Nano Banana to maintain style consistency across the set
4. Convert all PNGs to JPG: `magick input.png -background '#FDF8F0' -flatten output.jpg`
