# Reveal.js Reference

## Keyboard Shortcuts (for presenter)

| Key | Action |
|-----|--------|
| Arrow keys | Navigate slides |
| Space | Next slide |
| Esc | Slide overview |
| S | Speaker notes window |
| F | Fullscreen |
| B | Black screen (pause) |

## Speaker Notes Setup

Press `S` to open the speaker notes window. This shows:
- Current slide
- Next slide preview
- Speaker notes for current slide
- Elapsed time

Works best with two screens (projector + laptop).

---

## Slide Layout Rules

Content must be centered in the viewport with text left-aligned for readability.

| Element | Alignment |
|---------|-----------|
| Title slide (h1, h2, h3) | Centered text, centered block |
| Body text (p, li) | Left-aligned text, centered block |
| Headings on content slides | Left-aligned |
| Images | Within centered content block |

**Implementation:** `.slide-inner` uses `max-width: 960px; margin: 0 auto` to create a centered content column. All text is `text-align: left` except title slides which use `text-align: center`.
