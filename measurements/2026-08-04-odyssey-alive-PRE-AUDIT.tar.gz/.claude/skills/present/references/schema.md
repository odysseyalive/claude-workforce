# Presentation Schema & File Organization

## Frontmatter Schema

```yaml
title: string (max 99 chars)
slug: string (URL-safe)
description: string (max 300 chars, typically "Event — Date")
date: ISO date (YYYY-MM-DD)
event: string (optional, full event name)
published: boolean (required, default true)
image: relative path (optional, hero image for directory card)
imageAlt: string (optional, describes the hero image)
```

**Note:** `published` controls visibility. Date does NOT — presentations should show before the event.

**Frontmatter template for new presentations:**
```yaml
title: "Presentation Title"
slug: "presentation-slug"
description: "Event name — Date"
date: YYYY-MM-DD
event: "Full Event Name"
published: true
image: ../../assets/images/presentations/hero/[slug]-hero.jpg
imageAlt: "Description of hero image"
```

---

## Hero Image for /presentations Page

The directory page (`/presentations`) has its own hero image — distinct from individual presentation card images.

| Property | Value |
|----------|-------|
| Style | **Watercolor** (matches site aesthetic, NOT flat illustration) |
| Location | `assets/images/pages/presentations-hero.jpg` |
| Integration | CSS `background-image` on hero section with semi-transparent dark overlay |
| Aspect ratio | 21:9 (full-width banner) |
| Pipeline | Copied by `copy-assets.js` to `public/images/` |

Individual presentation **card images** (frontmatter `image` field) use watercolor style too — they appear on the site's marketing page, not on the projector.

Only **slide graphics** (inline images within slides) use flat illustration style for projector readability.

---

## File Organization

```
content/presentations/
  [slug].mdx                          # Slide content

assets/images/presentations/
  hero/[slug]-hero.jpg                 # Directory listing card image (optional)
  inline/[slug]/                       # Slide graphics
    slide-01-[description].jpg
    slide-02-[description].jpg
    ...
```

| Asset | Path |
|-------|------|
| MDX content | `content/presentations/[slug].mdx` |
| Slide images | `assets/images/presentations/inline/[slug]/` |
| Hero image (optional) | `assets/images/presentations/hero/[slug]-hero.jpg` |

---

## Discovered Issues Log

- **Velite adds inline width/height to images** — Must override with `width: auto !important; height: auto !important` in slide CSS, or images ignore `max-height` constraints. (2026-02-14)
- **MDX outputs `class` not `className` in `<aside>`** — Speaker notes use `<aside class="notes">`. CSS must use attribute selector `aside[class="notes"]` not `.notes`. React warns but it works. (2026-02-14)
- **Date timezone shift** — Velite outputs full ISO timestamps (e.g., `2026-02-17T00:00:00.000Z`). Display code must use `.slice(0, 10) + "T12:00:00"` to avoid UTC midnight shifting the date back one day in US timezones. (2026-02-14)
- **Don't filter presentations by date** — Unlike focus posts, presentations should be visible BEFORE the event. Filter by `p.published` only, not `isPublishedAndScheduled`. (2026-02-14)
- **Content centering** — Use `max-width: 960px; margin: 0 auto` on `.slide-inner` to center content. `align-items: center` and `margin: auto` on children don't work reliably against reveal.js internals. (2026-02-14)
- **Use `conversation_id` for image consistency** — When generating multiple slide images, pass the same `conversation_id` to Nano Banana and set `use_image_history: true` on subsequent images. This maintains style consistency across the set. (2026-02-14)
- **`p:has(img)` global override is now baked in** — `globals.css` (around line 469) carries `.brand-slides .slides p:has(img) { max-width: 100% !important }` so MDX paragraph wrappers stop clamping images to text width. Don't duplicate this per slide-type rule. (2026-04-11)
- **Auto-classifier visual threshold is 400 chars** — `SlideViewer.tsx` `classifySlide()` routes image+prose slides under 400 textOnly chars to `visual` (was 200, which left bold-prose decks misclassified as `statement` with tight image caps). When designing image slides, expect anything under ~400 chars of body text to render with the visual treatment. (2026-04-11)
- **Turbopack stale CSS cache** — Editing `globals.css` while `next dev` is running sometimes serves stale CSS even after a touch/save. Symptom: source has new value, served `_next/static/chunks/.../*.css` still has old value. Fix: kill the dev server, `rm -rf .next`, and restart. Touching the file alone is not enough. (2026-04-11)
- **Default image max-heights baked into globals.css** — visual 460px / 90% width, closing 440px / 88%, statement 360px / 80%, content 320px / 75%, default fallback 380px / 80%. These supersede the em-based sizes documented in `slide-types.md`. (2026-04-11)
