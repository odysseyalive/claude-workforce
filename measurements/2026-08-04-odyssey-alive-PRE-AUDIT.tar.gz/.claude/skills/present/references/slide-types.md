# Slide Type Taxonomy

A professional deck uses visually distinct slide types. The auto-classifier in `SlideViewer.tsx` detects type from content via `data-type` attributes. Each type has its own CSS treatment.

### The 7 Slide Types

| Type | Purpose | Visual Signature | Detection |
|------|---------|-----------------|-----------|
| **title** | Opens the deck, sets tone | Dark gradient bg, oversized centered type, coral accent line | First slide (index 0) |
| **divider** | Signals topic transition | Dark bg, large single heading, no body text — a visual "breath" | Heading-only, <80 chars total |
| **statement** | One punchy takeaway | Cream bg, left accent bar, larger body text (1.3em) | No lists, ≤4 paragraphs, <300 chars |
| **content** | Delivers structured info | Cream bg, top accent bar, standard text hierarchy | Has lists or longer text |
| **visual** | Storytelling through imagery | Large image (300px+), minimal text, image as focal point | Image-dominant, <200 chars text |
| **quote** | Highlights an expert voice | Tinted warm bg, large italic text, decorative accent | Contains `<blockquote>` |
| **closing** | Ends the deck, stays on screen | Dark bg (mirrors title), centered, quiet design | Last slide |

### Visual Rhythm Rules

A deck where every slide looks the same is a deck where no slide matters. Visual rhythm is how the audience knows "this is important" vs. "this is supporting detail."

**The rules:**
1. **Never stack 3+ same-type slides.** After 2 content slides, insert a statement, visual, or divider.
2. **Dark slides bracket and divide.** Title, dividers, and closing use dark backgrounds. They create structural punctuation.
3. **Alternate dense and sparse.** Content slide (bullets) → statement slide (one sentence) → visual slide (image). This gives the audience breathing room.
4. **Color shift signals transition.** Moving from light to dark background is an unmistakable "we're changing topics" signal.

**The 3-tier color system:**
- **Dark mode** (dark gradient bg, light text): title, divider, closing
- **Light mode** (cream bg, dark text): content, statement
- **Tinted mode** (warm-washed bg): quote, special emphasis

### Typography Scale by Slide Type

Type size should be consistent within each type but vary between types. This is how the audience unconsciously recognizes "this is a different kind of slide."

| Element | Title | Divider | Statement | Content | Visual | Quote | Closing |
|---------|-------|---------|-----------|---------|--------|-------|---------|
| h1 | 3.2em | 3em | 2.8em | 2.2em | 2.4em | — | 2.6em |
| Body/p | — | — | 1.3em | 1.15em | 1.1em | 1.4em italic | 1.2em |
| Text color | cream | cream | brand-black | brand-black (80%) | brand-black | brand-black | cream |
| Max body width | — | — | 36em | 48em | 30em | 38em | — |

### Layout Patterns

Each slide type maps to a specific layout grid:

- **Title / Closing**: Centered content, centered text, full-width
- **Divider**: Centered content, centered text, no body
- **Statement**: Left-aligned text, centered block (960px), left accent bar
- **Content**: Left-aligned text, centered block (960px), top accent bar
- **Visual**: Image fills more space (300px+ height), text below or beside
- **Quote**: Centered block, large italic text, warm tinted background

### Evaluating Slide Design with /frontend-design

After writing CSS for any slide type, use `/frontend-design` to evaluate the visual treatment individually. Each slide type should be assessed on its own merits — not as part of a template, but as a distinct design problem:

- Does this type look visually distinct from adjacent slide types?
- Does the color/typography/layout signal what kind of content this is?
- Would someone flipping through the deck instantly recognize "this is a section break" or "this is the key takeaway"?
- Is the design polished enough for a Fortune 500 audience?
