---
name: seo
description: "AEO + SEO + GEO evaluation. Modes: evaluate [page], --all, --calibrate [--since date]. Supersedes /geo."
allowed-tools: Read, Glob, Grep, Edit, Write, WebFetch, WebSearch, Task, Agent
minimum-effort-level: high
strictness: standard
---

# AEO + SEO + GEO Evaluation

Evaluate pages for Answer Engine Optimization (AEO), Search Engine Optimization (SEO), and Generative Engine Optimization (GEO). Runs three specialized agents in parallel, each scoring against their framework.

## Usage

```
/seo [page-path]              # Evaluate a single page
/seo --all                    # Evaluate every page on the site
/seo --calibrate [--since YYYY-MM-DD]  # Research current industry standards
```

### Modes

| Mode | Command | Description |
|------|---------|-------------|
| **evaluate** (default) | `/seo [page-path]` | Evaluate a single page. Accepts a route path (`/services`) or file path. |
| **all** | `/seo --all` | Evaluate every page on the site. Aggregates results into a site-wide report. |
| **calibrate** | `/seo --calibrate [--since YYYY-MM-DD]` | Research agents check current industry standards for changes since the given date. Defaults to 90 days ago. |

---

<!-- origin: user | added: 2026-03-25 | immutable: true -->
## Directives

> **"Every time a new page gets generated, this skill must evaluate it last for AEO, SEO, and GEO."**

*-- Added 2026-03-25, source: user directive during AEO/GEO implementation planning*

> **"Voice survives optimization. If it reads like keyword-stuffing, start over."**

*-- Carried from /geo skill, source: user directive*
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Voice survives optimization. If it reads like keyword-stuffing, start over." -->
CHECKPOINT — Voice Survival Gate:
1. For each proposed content change (body text, meta description, FAQ answer, purpose paragraph), extract the before and after passage.
2. Count target keywords or brand terms in the after passage. Compute keyword density as (keyword occurrences / total word count × 100).
3. IF keyword density in the after passage > 3% for any single keyword OR > 6% for all keywords combined → STOP. Mark as keyword-stuffing and reject the proposed change.
4. Read the after passage aloud-in-head. IF it contains phrases no human Francis-voice would say because they only exist to cram a keyword ("leading AI automation consulting services", "top-rated strategic AI partner", "comprehensive solutions provider") → STOP. Reject the change.
5. Spawn the voice-validator agent on the after passage. IF voice-validator returns violations → STOP. Reject the change.
6. IF keyword density is within thresholds AND no keyword-cram phrases are present AND voice-validator passes → CONTINUE and include the change in the report.
<!-- END ENFORCEMENT ANNOTATION -->

---

## Workflow: Evaluate (single page)

1. **Resolve the page.** Map the route or file path to the source file(s):
   - Marketing pages: `src/app/(marketing)/[route]/page.tsx` or their content components
   - Editorial pages: `src/app/(editorial)/[route]/page.tsx` or their content components
   - Focus articles: `content/focus/[slug].mdx` + `src/app/(editorial)/focus/[slug]/page.tsx`
   - Homepage: `src/app/page.tsx` + `src/components/marketing/HomeContent.tsx`

2. **Read the target page** and `src/lib/schema.ts` (shared schema utilities).

3. **Spawn three evaluation agents in parallel** (`context: none`):
   - **AEO Evaluator** -- Schema markup, featured snippet readiness, direct-answer blocks, FAQ structure
   - **SEO Evaluator** -- Meta tags, heading hierarchy, internal linking, canonical URLs, OG tags
   - **GEO Evaluator** -- Citability, authority signals, outbound citations, entity coverage

4. **Each agent reads its framework** from `references/` and scores against criteria (0-100).

5. **Synthesize results** into a unified report:
   - Per-discipline score (0-100)
   - Combined score (average)
   - Prioritized action items (HIGH / MEDIUM / LOW)

6. **If content changes are proposed**, spawn the **voice-validator** agent to ensure they don't compromise Francis's voice.

7. **Present report.** Display mode only. No edits unless the user requests them.

---

## Workflow: All Pages (`--all`)

1. Glob for all page files:
   - `src/app/**/page.tsx` (exclude slides, privacy, terms)
   - `content/focus/*.mdx`
1b. **Change-scope precheck (optional):** accept `--changed-since <date|git-ref>`. When provided, check each page's git history and SKIP pages with no commits since that point — list the skipped pages in the report so the scope is explicit. Default (no flag) remains the full sweep. This gates only the 3-agent spawn per unchanged page; the single-page directive ("every new page gets evaluated") is unaffected.
2. For each page, run the single-page evaluate workflow.
3. Aggregate into site-wide report:
   - Page-by-page scores
   - Site-wide averages per discipline
   - Top 5 highest-impact fixes across the site
   - Pages that need no action

---

## Workflow: Calibrate (`--calibrate`)

1. Accept `--since YYYY-MM-DD` flag (defaults to 90 days ago if omitted).
2. Read `references/calibration-queries.md` for search queries.
3. Spawn three **research agents** in parallel:
   - **AEO Research** -- Schema.org updates, featured snippet changes, answer engine behavior
   - **SEO Research** -- Google algorithm updates, Core Web Vitals changes, ranking factors
   - **GEO Research** -- How ChatGPT/Claude/Perplexity/Gemini cite sources, new citation patterns
4. Each agent uses WebSearch + WebFetch, filtering by the date parameter.
5. Synthesize findings:
   - What changed since [date]
   - Which framework files need updating
   - Recommended updates to `references/*.md`
6. Present report. User decides whether to apply framework updates.

---

## Known Limitation

Markdown extractors cannot see JSON-LD. See [references/known-limitations.md](references/known-limitations.md) for details and workarounds.

---

## Grounding

Before evaluating any page:
1. Read the relevant framework file(s) from `references/`
2. State: "I will evaluate against [FRAMEWORK] from references/[file]"

Reference files:
- [references/aeo-framework.md](references/aeo-framework.md) -- AEO evaluation criteria
- [references/seo-framework.md](references/seo-framework.md) -- SEO evaluation criteria
- [references/geo-framework.md](references/geo-framework.md) -- GEO evaluation criteria
- [references/calibration-queries.md](references/calibration-queries.md) -- Research mode search queries

---

## Voice Validation (Enforced via Agent)

After proposing any content changes, spawn the voice-validator agent to verify the content still sounds like Francis. If violations found, fix before presenting.

See [agents/voice-validator/AGENT.md](agents/voice-validator/AGENT.md) for details.

---


---

<!-- ROUTE-EMBED START — auto-generated by /skill-builder route embed; safe to replace -->
<!-- origin: skill-builder | modifiable: true -->
## Route Consultation

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: /skill-builder route embed. Closes the dispatch-bypass gap: a /route announcement is not a substitute for a Skill tool call, and consulting /route does not license the caller to execute the target skill's procedure manually. -->
CHECKPOINT — Skill Routing Gate:
1. During this skill's workflow, IF a step requires research, web search, lookup, analysis, or any follow-up NOT already covered by an explicit tool or skill name → STOP before improvising.
2. Already-named exception. IF the current workflow step EXPLICITLY names tools or skills (e.g., "use Read", "spawn the X agent", "invoke /[skill]") → execute as written. Do NOT consult `/route` for steps already determined. Skip to your skill's next step.
3. Otherwise → invoke `/route <task description>` via the Skill tool. `/route` reads its index and either returns a target skill or reports "no match."
4. Dispatch Required. IF `/route` returns a target → the IMMEDIATE next tool call MUST be `Skill(skill=<target>, args=<derived>)`. Do NOT execute the target skill's procedure steps yourself with raw Edit / Write / Bash / Task / Agent / Read calls. The target skill's gates (asset backups, agent panels, exit tests, cascade steps, frontend-design reviews, immutable-directive checks) ONLY fire when its SKILL.md is loaded via Skill — running steps manually silently skips every gate.
5. Bypass detection. IF a Skill dispatch was just announced (yours or `/route`'s) and the next tool call is non-Skill work germane to the routed task → STOP. Print verbatim: "Route dispatch announced but Skill call skipped. Invoking Skill tool now." then issue the Skill call.
6. No-match path. IF `/route` returns "no match" → proceed with the most direct, manual approach. Document the gap; the user may want to register a skill.
7. Follow-ups loop back. After the dispatched skill returns, IF further follow-up is needed → consult `/route` again via Skill. Do not freelance the next step.
8. Auto-mode override clause. Auto-mode ("execute immediately", "prefer action over planning") does NOT override clauses 4–5. Auto-mode chooses WHAT to do; once a routing decision is on the table, the only valid next action is Skill invocation.
<!-- END ENFORCEMENT ANNOTATION -->
<!-- /origin -->
<!-- ROUTE-EMBED END -->
