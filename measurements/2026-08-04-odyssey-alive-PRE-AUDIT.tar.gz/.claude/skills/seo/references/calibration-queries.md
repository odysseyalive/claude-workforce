# Calibration Search Queries

Templated queries for the `--calibrate` mode. Replace `[YEAR]` and `[MONTH]` with the current values. Filter results by the `--since` date parameter.

---

## AEO Queries

- `schema.org changes [YEAR]`
- `featured snippet requirements update [YEAR]`
- `answer engine optimization best practices [YEAR]`
- `Google rich results changes [YEAR]`
- `FAQ schema markup updates [YEAR]`
- `JSON-LD structured data new types [YEAR]`
- `zero-click search optimization [YEAR]`

## SEO Queries

- `Google algorithm update [MONTH] [YEAR]`
- `Google core update [YEAR]`
- `Core Web Vitals changes [YEAR]`
- `SEO ranking factors [YEAR]`
- `Next.js SEO best practices [YEAR]`
- `meta description best practices [YEAR]`
- `E-E-A-T signals update [YEAR]`

## GEO Queries

- `how ChatGPT cites web sources [YEAR]`
- `how Perplexity selects sources [YEAR]`
- `AI search citation patterns [YEAR]`
- `generative engine optimization [YEAR]`
- `AI overview optimization Google [YEAR]`
- `Claude web search citation behavior [YEAR]`
- `LLM source selection criteria [YEAR]`

---

## Filtering by Date

When using `--since YYYY-MM-DD`:
1. Include the date in search queries where supported (e.g., `after:YYYY-MM-DD`)
2. When reading results, discard any content published before the since date
3. Focus on changes, updates, and new findings. Ignore restatements of established practices.

---
*Calibration queries for /seo skill. Last calibrated: 2026-03-25.*
