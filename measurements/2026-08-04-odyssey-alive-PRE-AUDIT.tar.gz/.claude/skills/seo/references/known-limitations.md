# Known Limitations

## Markdown Extractors Cannot See JSON-LD

Web fetch tools (Jina Reader, WebFetch, similar markdown extractors) strip `<script>` tags from HTML and return only body text. This means they **cannot detect JSON-LD structured data** on a live page. This was discovered 2026-03-25 when an external evaluation reported "no JSON-LD anywhere" despite 8 schema blocks being present in the server-rendered HTML.

**For evaluation:** Always evaluate against source files (`src/lib/schema.ts`, page components), not by fetching the live URL. The evaluate workflow already does this.

**For verification:** Direct users to Google Rich Results Test (search.google.com/test/rich-results) or Schema.org Validator (validator.schema.org) to verify deployed schema. These tools render JavaScript and parse the full DOM. Alternatively, `curl` the page and grep for `application/ld+json`.

**For calibrate mode:** WebSearch results about competitor schema implementations may describe what exists but fetching competitor pages won't reveal their JSON-LD. Note this limitation in calibration reports.
