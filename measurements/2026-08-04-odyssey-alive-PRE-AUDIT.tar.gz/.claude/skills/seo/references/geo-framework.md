# GEO Evaluation Framework
<!-- Enforcement: HIGH -- agent evaluation -->

Score each criterion 0-10. Total /100. Weight by impact.

## Citability (30 points)

| Criterion | Points | What to Check |
|-----------|--------|---------------|
| Quotable passages | 10 | Clear, self-contained statements an LLM could extract and cite |
| Statistics with sources | 10 | Named sources, specific numbers, verifiable claims |
| Named entities | 10 | People, organizations, tools mentioned by name (not just generic references) |

## Authority Signals (25 points)

| Criterion | Points | What to Check |
|-----------|--------|---------------|
| Author identity | 10 | Schema connects content to a real person with credentials |
| Outbound citations | 10 | Links to credible external sources (research, reports, official sites) |
| Source trustworthiness | 5 | Consistent identity across schema, visible content, and social profiles |

## AI-Readable Formatting (25 points)

| Criterion | Points | What to Check |
|-----------|--------|---------------|
| Extractable structure | 10 | Clear headings, answer capsules, semantic HTML |
| Entity coverage depth | 10 | Page goes deep on its topic rather than surface-level across many |
| Content freshness | 5 | Dates present, content appears maintained |

## Query Matching (20 points)

| Criterion | Points | What to Check |
|-----------|--------|---------------|
| Natural language queries | 10 | Content answers questions users would ask an AI system (23+ word queries) |
| Topic completeness | 10 | Page covers the topic thoroughly enough that an LLM wouldn't need to combine it with other sources |

---

## GEO Principles (from /geo skill)

- **Answer first, context second.** Lead with the answer, not background.
- **Match AI query patterns.** 23-word natural language questions.
- **Make content extractable.** Statistics, quotes, clear structure.
- **Schema as direct signal.** Label Q&A pairs explicitly for citation boost.
- **Consistency.** Schema must match visible content exactly.
- **Depth over breadth.** AI cites nested pages (82.5%), not homepages.
- **Voice survives optimization.** If it reads like keyword-stuffing, start over.

---
*GEO framework for /seo skill. Last calibrated: 2026-03-25.*
