# AEO Evaluation Framework
<!-- Enforcement: HIGH -- agent evaluation -->

Score each criterion 0-10. Total /100. Weight by impact.

## Schema Markup (30 points)

| Criterion | Points | What to Check |
|-----------|--------|---------------|
| JSON-LD present | 10 | At least one JSON-LD block on the page |
| Schema type appropriate | 5 | Correct @type for the page (Article, FAQPage, ProfessionalService, etc.) |
| Schema data complete | 10 | All required fields populated with accurate data. ProfessionalService must include: telephone, image, logo, priceRange, sameAs, address. Person must include: image, sameAs, knowsAbout. Article must include: author with sameAs, datePublished, image. ContactPoint must include: telephone, email. |
| Schema validates | 5 | No errors in Google Rich Results Test (search.google.com/test/rich-results) or Schema.org Validator (validator.schema.org). Common misses: missing `telephone`, missing `image` on organization schemas. |

**Check against:** `src/lib/schema.ts` for shared utilities. Verify rendered schema matches page content.

## Featured Snippet Readiness (25 points)

| Criterion | Points | What to Check |
|-----------|--------|---------------|
| Direct-answer block | 10 | Clear, bounded answer to a question within the first screen of content |
| Question-format heading | 5 | At least one H2/H3 phrased as a question users would ask |
| Answer capsule format | 5 | Answer immediately follows the question heading (no preamble) |
| List/table extractability | 5 | Processes or comparisons use semantic HTML (ol, ul, table) |

## FAQ/Q&A Structure (20 points)

| Criterion | Points | What to Check |
|-----------|--------|---------------|
| FAQ content present | 5 | Page has Q&A content (visible or schema) |
| FAQPage schema | 10 | JSON-LD FAQPage wrapping the Q&A pairs |
| Schema matches visible | 5 | Schema Q&A text exactly matches what the user sees |

## Meta & Authorship (25 points)

| Criterion | Points | What to Check |
|-----------|--------|---------------|
| Unique meta description | 5 | Not falling back to root layout default |
| Meta description answers a query | 5 | Description could serve as a direct answer |
| Author attribution | 5 | Visible byline with `rel="author"` link |
| Author schema | 5 | Person schema with sameAs (LinkedIn, etc.) |
| BreadcrumbList schema | 5 | Navigation context for answer engines |

---

## Page-Type Expectations

| Page Type | Required Schema | Required Content |
|-----------|----------------|------------------|
| Homepage | ProfessionalService, FAQPage | Business definition, service overview |
| /about | Person, ProfilePage | Author bio, credentials, sameAs links |
| /services | FAQPage, Service, HowTo | Direct-answer blocks, process list, pricing |
| Focus article | Article, optional FAQPage | Byline with rel="author", breadcrumbs |
| Collection page | CollectionPage | Listing with ItemList |
| /contact | ContactPoint | Contact methods |

---
*AEO framework for /seo skill. Last calibrated: 2026-03-25.*
