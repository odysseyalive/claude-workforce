# SEO Evaluation Framework
<!-- Enforcement: HIGH -- agent evaluation -->

Score each criterion 0-10. Total /100. Weight by impact.

## Meta Tags (25 points)

| Criterion | Points | What to Check |
|-----------|--------|---------------|
| Title tag | 5 | Present, under 60 chars, includes primary topic |
| Meta description | 5 | Present, unique per page, 150-160 chars, answers a query |
| Open Graph tags | 5 | og:title, og:description, og:type, og:image all set |
| Twitter card | 5 | twitter:card, twitter:title, twitter:description set |
| Canonical URL | 5 | Correct, not duplicated, matches the page |

## Heading Structure (20 points)

| Criterion | Points | What to Check |
|-----------|--------|---------------|
| Single H1 | 5 | Exactly one H1 per page |
| Logical hierarchy | 10 | H2s under H1, H3s under H2s. No skipped levels. |
| Keywords in headings | 5 | Primary topic appears in H1 and at least one H2 |

## Content Quality (20 points)

| Criterion | Points | What to Check |
|-----------|--------|---------------|
| Keyword presence | 5 | Primary keywords appear naturally in body text |
| Internal linking | 10 | Links to other pages on the site where relevant |
| Image alt text | 5 | All images have descriptive alt attributes |

## Technical (20 points)

| Criterion | Points | What to Check |
|-----------|--------|---------------|
| Server-rendered | 10 | Page content available without JS (SSR or SSG) |
| Mobile structure | 5 | Responsive layout, no horizontal scroll |
| No duplicate content | 5 | No identical content blocks across pages |

## Authority Signals (15 points)

| Criterion | Points | What to Check |
|-----------|--------|---------------|
| Author info | 5 | Named author with link to bio page |
| Consistent entity data | 5 | sameAs URLs match across schema objects |
| External mentions | 5 | Linked from or mentioned by external sites (hard to check programmatically, note as recommendation) |

---
*SEO framework for /seo skill. Last calibrated: 2026-03-25.*
