#!/bin/bash
# Hook: Validate temporal references against date anchors in SEO evaluation output
# Catches mismatches between claimed durations and actual date gaps
# Scope: Content MDX files only
CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR

INPUT=$(cat 2>/dev/null) || exit 0

# Extract file path
FILE_PATH=$(echo "$INPUT" | grep -oP '"file_path"\s*:\s*"[^"]*"' | head -1 | sed 's/.*"file_path"\s*:\s*"//;s/"$//')

# Scope check: only content MDX files
if ! echo "$FILE_PATH" | grep -q 'content/.*\.mdx$'; then
  exit 0
fi

# Run temporal validation in Python (INPUT passed via env to keep heredoc as script source)
INPUT="$INPUT" python3 << 'PYTHON_SCRIPT'
import os
import json
import re
import sys
from datetime import datetime

def main():
    try:
        data = json.loads(os.environ.get('INPUT', '{}'))
    except:
        return 0

    tool_input = data.get('tool_input', data)
    file_path = tool_input.get('file_path', '')

    # Scope check (redundant with bash, but safe)
    if not re.search(r'content/.*\.mdx$', file_path):
        return 0

    # Get content: Write tool has 'content', Edit tool needs file + substitution
    content = tool_input.get('content', '')
    edit_mode = False
    new_string = ''

    if not content:
        old_string = tool_input.get('old_string', '')
        new_string = tool_input.get('new_string', '')
        if not (file_path and old_string):
            return 0
        try:
            with open(file_path) as f:
                content = f.read()
            content = content.replace(old_string, new_string, 1)
            edit_mode = True
        except:
            return 0

    if not content:
        return 0

    # Extract article date from frontmatter for year inference
    article_year = None
    article_month = None
    fm_match = re.search(r'^date:\s*(\d{4})-(\d{2})', content, re.MULTILINE)
    if fm_match:
        article_year = int(fm_match.group(1))
        article_month = int(fm_match.group(2))

    if not article_year:
        return 0  # Can't validate without article date

    MONTHS = {
        'january': 1, 'february': 2, 'march': 3, 'april': 4,
        'may': 5, 'june': 6, 'july': 7, 'august': 8,
        'september': 9, 'october': 10, 'november': 11, 'december': 12
    }

    # Temporal phrases: (regex, min_days, max_days, label)
    PHRASES = [
        (r'a\s+few\s+days\s+(?:later|after|before|earlier)', 2, 10, 'a few days'),
        (r'several\s+days\s+(?:later|after|before|earlier)', 3, 14, 'several days'),
        (r'a\s+(?:few|couple(?:\s+of)?)\s+weeks\s+(?:later|after|before|earlier)', 10, 35, 'a few weeks'),
        (r'several\s+weeks\s+(?:later|after|before|earlier)', 21, 63, 'several weeks'),
        (r'a\s+(?:few|couple(?:\s+of)?)\s+months\s+(?:later|after|before|earlier)', 45, 150, 'a few months'),
        (r'several\s+months\s+(?:later|after|before|earlier)', 90, 300, 'several months'),
        (r'(?:a|one)\s+week\s+(?:later|after|before|earlier)', 5, 10, 'one week'),
        (r'two\s+weeks?\s+(?:later|after|before|earlier)', 10, 21, 'two weeks'),
        (r'three\s+weeks?\s+(?:later|after|before|earlier)', 18, 28, 'three weeks'),
        (r'(?:a|one)\s+month\s+(?:later|after|before|earlier)', 25, 45, 'one month'),
        (r'two\s+months?\s+(?:later|after|before|earlier)', 50, 75, 'two months'),
        (r'three\s+months?\s+(?:later|after|before|earlier)', 75, 110, 'three months'),
        (r'four\s+months?\s+(?:later|after|before|earlier)', 105, 145, 'four months'),
        (r'five\s+months?\s+(?:later|after|before|earlier)', 135, 175, 'five months'),
        (r'six\s+months?\s+(?:later|after|before|earlier)', 160, 210, 'six months'),
        (r'(?:a|one)\s+year\s+(?:later|after|before|earlier)', 330, 400, 'one year'),
        (r'two\s+years?\s+(?:later|after|before|earlier)', 660, 780, 'two years'),
        (r'\bweeks\s+(?:later|after|before|earlier)', 14, 63, 'weeks'),
        (r'\bmonths\s+(?:later|after|before|earlier)', 30, 365, 'months'),
    ]

    # Strip frontmatter
    parts = content.split('---')
    if len(parts) >= 3:
        body = '---'.join(parts[2:])
    else:
        body = content

    # Strip references section
    ref_idx = body.rfind('## References')
    if ref_idx >= 0:
        body = body[:ref_idx]

    # Strip image lines and captions
    clean_lines = []
    for line in body.split('\n'):
        stripped = line.strip()
        if stripped.startswith('!['):
            continue
        if stripped.startswith('*') and stripped.endswith('*') and len(stripped) < 200:
            continue
        clean_lines.append(line)
    body = '\n'.join(clean_lines)
    body_lower = body.lower()

    # Find all month mentions with positions
    month_positions = []
    for month_name, month_num in MONTHS.items():
        for m in re.finditer(r'\b' + month_name + r'\b', body_lower):
            after = body[m.end():m.end() + 10].strip()
            year_match = re.match(r'(\d{4})', after)
            if year_match:
                year = int(year_match.group(1))
            else:
                if month_num > article_month:
                    year = article_year - 1
                else:
                    year = article_year
            month_positions.append({
                'month': month_num,
                'year': year,
                'pos': m.start(),
                'name': month_name
            })

    # Deduplicate overlapping matches
    month_positions.sort(key=lambda x: (x['pos'], -len(x['name'])))
    deduped = []
    last_end = -1
    for mp in month_positions:
        if mp['pos'] >= last_end:
            deduped.append(mp)
            last_end = mp['pos'] + len(mp['name'])
    month_positions = deduped

    if len(month_positions) < 2:
        return 0

    errors = []

    for pattern, min_days, max_days, label in PHRASES:
        for match in re.finditer(pattern, body_lower):
            match_pos = match.start()
            phrase_text = match.group(0)

            if edit_mode and new_string:
                new_lower = new_string.lower()
                if not re.search(pattern, new_lower):
                    continue

            nearby = [mp for mp in month_positions
                      if match_pos - 500 <= mp['pos'] <= match_pos + 500]

            if len(nearby) < 2:
                continue

            nearby.sort(key=lambda mp: abs(mp['pos'] - match_pos))
            m1 = nearby[0]
            m2 = None
            for mp in nearby[1:]:
                if mp['month'] != m1['month'] or mp['year'] != m1['year']:
                    m2 = mp
                    break

            if m2 is None:
                continue

            try:
                d1 = datetime(m1['year'], m1['month'], 15)
                d2 = datetime(m2['year'], m2['month'], 15)
                delta_days = abs((d2 - d1).days)
            except:
                continue

            if delta_days < min_days or delta_days > max_days:
                m1_label = f"{m1['name'].capitalize()} {m1['year']}"
                m2_label = f"{m2['name'].capitalize()} {m2['year']}"
                approx_months = round(delta_days / 30.44, 1)
                errors.append(
                    f'"{phrase_text}" used between {m1_label} and {m2_label} '
                    f'(actual gap: ~{delta_days} days / ~{approx_months} months). '
                    f'Expected range for "{label}": {min_days}-{max_days} days.'
                )

    if errors:
        for e in errors:
            print(f'BLOCKED: Temporal mismatch: {e}', file=sys.stderr)
        return 2

    return 0

sys.exit(main())
PYTHON_SCRIPT

exit $?
