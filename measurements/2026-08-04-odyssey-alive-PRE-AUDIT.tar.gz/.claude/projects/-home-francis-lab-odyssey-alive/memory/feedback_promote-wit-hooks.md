---
name: Promote hooks must use satirical wit, not earnest confession
description: Hooks defaulted to personal vulnerability instead of humor despite satirical-wit.md being loaded. Skill now requires Hook Workshop step.
type: feedback
---

Earnest confession is not wit. "I spent years complaining about opaque systems" is a LinkedIn vulnerability post, not a Twain-style hook. The satirical-wit techniques must be operationalized, not just passively loaded.

**Why:** The Trojan Combine promotion (2026-03-27) produced hooks that were sincere and self-implicating but not funny. Francis's article was full of wit beats (understated absurdity, quiet escalation, Trojan observations) and the promote skill ignored all of them in favor of personal confession. The skill improvements to voice/wit only prevented overbuilt prose but didn't force wit into the hook construction.

**How to apply:** The promote skill now has a mandatory Hook Workshop step. Mine the article for its own wit beats first. Generate 3-5 candidate hooks using different techniques. Present candidates to Francis before drafting posts. Never default to earnest personal experience as the hook. The article's humor is the primary source material.
