---
name: Wit skill connective humor gap
description: The /wit humor workflow was structurally incapable of connective humor (jokes bridging separate ideas) because it worked passage-by-passage. Fixed 2026-03-27 with Connector agent using Koestler's bisociation framework.
type: feedback
---

The /wit humor workshop produced flat, unfunny results when asked to add humor to social posts for "The Trojan Combine." None of the generated options were funny. Francis's own humor ("Probably because the terms of service are written in Greek") worked because it connected TWO separate paragraph themes through a dual-meaning word.

**Why:** "Greek" = literal Greeks from the Trojan Horse AND the idiom "it's Greek to me." The AI treated each paragraph as isolated and could only generate humor WITHIN single passages. It never searched for bridges between them.

**Root cause:** Every phase of the humor workflow was passage-centric. The survey mapped "humor-ready passages," the satirist received individual passages, the editor checked single insertions. There was no step that mapped relationships between passages. The satirist was even instructed "one premise per passage."

**How to apply:** The fix adds a Connector agent that extracts semantic fields per theme and runs collision detection to find polysemous words, shared idioms, and structural analogies across frames. The humor workshop now has Phase 1 (Connective Mapping) before the existing Survey. The satirist accepts connective premises alongside passage-level ones. The editor and validator have new checks for bisociative quality. The /promote skill now offers the humor workshop after Stage 1 validation passes.

**Key insight from research:** The cognitive process of finding bridges is decomposable. An agent can enumerate semantic fields more thoroughly than a human (larger vocabulary, more idioms). The convergent search (comparing fields for overlap) is essentially set intersection. The human's advantage is in construction — building the sentence where both meanings activate with the right timing. So the Connector finds candidates, Francis picks winners, and the satirist builds delivery.
