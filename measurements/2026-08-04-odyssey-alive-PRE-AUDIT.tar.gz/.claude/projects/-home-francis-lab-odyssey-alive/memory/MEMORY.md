# Memory

## Feedback
- [feedback_story_first.md](feedback_story_first.md) — When differentiating social posts across platforms, always lead with a person/story, never abstract data
- [feedback_gender_pronouns.md](feedback_gender_pronouns.md) — Use they/them for all named individuals unless pronouns are publicly stated
- [feedback_wit-connective-humor.md](feedback_wit-connective-humor.md) — /wit humor was passage-centric, couldn't find cross-paragraph bridges. Fixed with Connector agent (bisociation)
- [feedback_promote-wit-hooks.md](feedback_promote-wit-hooks.md) — Earnest confession is not wit; promote hooks must mine article's own humor, not default to vulnerability
