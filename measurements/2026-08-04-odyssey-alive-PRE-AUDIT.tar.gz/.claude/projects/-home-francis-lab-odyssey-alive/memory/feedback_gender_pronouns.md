---
name: Gender-neutral pronouns for named individuals
description: Use they/them for all named individuals in content unless pronouns are publicly stated by the person
type: feedback
---

When referencing individuals by name in any content (articles, social posts, newsletters), use they/them pronouns. A gendered name or gendered language in a source article is not sufficient basis to assume pronouns. Use first name for clarity when needed.

**Why:** Francis corrected she/her pronouns for Erin Kistler in a social post. Even when source material uses gendered pronouns, we can't assume gender identity. This applies to both the focus (article) and promote (social) workflows.

**How to apply:** This is now codified in voice/SKILL.md under "Referring to People." Since all content skills chain through voice, it applies everywhere. Default to they/them unless the person has publicly and explicitly stated their pronouns.
