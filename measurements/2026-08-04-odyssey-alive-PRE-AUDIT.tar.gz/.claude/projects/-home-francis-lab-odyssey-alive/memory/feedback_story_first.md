---
name: Story first when differentiating
description: When fixing cross-platform duplication in social posts, always lead with a person/story, never swap to abstract data
type: feedback
---

When differentiating social posts across platforms to avoid duplication, always ground each post in a specific person or story. Never replace storytelling with abstract stats or data to create differentiation. Find a different human angle instead.

**Why:** Francis's ethos is "telling the story first." The first Facebook revision for "The Invisible Interview" was flagged as "super vague" because it led with liability percentages instead of a person. The fix was switching from Mobley's story to Kistler's story, not from story to abstraction.

**How to apply:** When the structure checker flags cross-platform duplication, differentiate by finding a different character, quote, or human moment from the article. Each platform gets a different person or angle, but every platform gets a person.
