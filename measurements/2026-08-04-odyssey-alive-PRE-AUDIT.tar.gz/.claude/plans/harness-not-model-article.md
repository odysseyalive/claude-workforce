# Plan: Complete "The Harness, Not the Model" Article

## Status: Ready for Image Generation

### What's Done
- [x] Article MDX created at `content/focus/harness-not-model.mdx`
- [x] Frontmatter complete (title, slug, description, date Jan 23 9AM PST, category, tags)
- [x] ~520 words, narrative architecture, Francis's voice

### What's Needed

**1. Generate 3 images via Nano Banana**

| Image | Aspect | Palette | Filename |
|-------|--------|---------|----------|
| Hero | 16:9 | Warm Earth | `harness-not-model-hero.jpg` |
| Inline 1 | 4:3 | Cool Industrial | `server-room.jpg` |
| Inline 2 | 4:3 | Night/Moody | `monitoring-station.jpg` |

**2. Save images to asset locations**
```
assets/images/focus/hero/harness-not-model-hero.jpg
assets/images/focus/inline/harness-not-model/server-room.jpg
assets/images/focus/inline/harness-not-model/monitoring-station.jpg
```

**3. Update MDX with image paths and inline images**

**4. Run image set evaluation** (per `image-evaluation.md`)

**5. Preview with `pnpm dev`**

---

## Image Prompts

### Hero (16:9) — Warm Earth
```
A watercolor painting of a vintage auto mechanic's garage. A car with hood open in center, mechanic standing outside looking in, organized tools on a wooden workbench to the side. Morning light streaming through a large window. Wet-on-wet technique with diffused edges and seamless color blending. Transparent layered washes. Medium-rough cold-press paper texture. Painting fades softly into white paper at the edges, unfinished border with visible raw paper showing through. Warm sienna, ochre, and burnt orange with cool blue-grey tones in shadows. Dreamy, luminous, gentle atmosphere. Aspect ratio 16:9.
```
*Caption: Observation requires distance.*

### Inline 1 (4:3) — Cool Industrial
```
A watercolor painting of a server room corridor, rows of black server racks with blinking status lights receding into shadow. No people visible. Cables bundled neatly but complexity evident. Wet-on-wet technique with diffused edges and seamless color blending. Transparent layered washes. Medium-rough cold-press paper texture. Painting fades softly into white paper at the edges, unfinished border. Steel blues, slate greys, and cool teals - rich and vibrant, not pale or faded. Warm amber accents from overhead lights. Atmospheric. Aspect ratio 4:3.
```
*Caption: Black boxes all the way down.*

### Inline 2 (4:3) — Night/Moody
```
A watercolor painting of a monitoring station at night, a single desk with multiple screens showing dashboard graphs and scrolling logs. An empty chair pulled back slightly. Coffee cup beside keyboard. Wet-on-wet technique with diffused edges and seamless color blending. Transparent layered washes. Medium-rough cold-press paper texture. Painting fades softly into white paper at the edges, unfinished border. Deep indigo and midnight blue - rich color, not pale or faded. Warm orange-amber glow from the screens. Intimate, atmospheric. Aspect ratio 4:3.
```
*Caption: Where you can see it.*

---

## Invocation

When ready, say:

> "Complete the harness-not-model article using the plan in .claude/plans/"

Or more specifically:

> "Generate the 3 images for harness-not-model using Nano Banana, save to assets, update the MDX with inline images, run image evaluation, and preview."

---

## After Images Are Generated

Update MDX frontmatter:
```yaml
image: ../../assets/images/focus/hero/harness-not-model-hero.jpg
imageAlt: "Watercolor of a mechanic observing a car engine from outside the garage"
```

Add inline images after relevant paragraphs in the MDX body:
```markdown
![Server room corridor with rows of black server racks](../../assets/images/focus/inline/harness-not-model/server-room.jpg)
*Black boxes all the way down.*

![Monitoring station at night with glowing screens](../../assets/images/focus/inline/harness-not-model/monitoring-station.jpg)
*Where you can see it.*
```
