# Skill System Optimization Plan

**Created:** 2026-01-22
**Completed:** 2026-01-22
**Goal:** Reduce skill file sizes by extracting reference material, preserve all directives verbatim, add enforcement hooks where possible.

## Execution Summary

| Skill | Before | After (SKILL.md) | reference.md | Savings |
|-------|--------|------------------|--------------|---------|
| /ynab | 550 | 184 | 269 | 366 lines in SKILL.md |
| /timesheet | 315 | 183 | 119 | 132 lines in SKILL.md |
| /zoho | 262 | 180 | 86 | 82 lines in SKILL.md |
| /focus | 347 | 225 | 101 | 122 lines in SKILL.md |
| CLAUDE.md | 225 | 198 | - | 27 lines |

**Total SKILL.md reduction:** 729 lines
**Enforcement hook created:** `/zoho` no-uncategorized hook

---

## Optimization Principles

1. **MOVE, don't rewrite** — Tables and IDs copied verbatim to reference.md
2. **Directives are sacred** — User rules stay in SKILL.md, word-for-word
3. **Workflows unchanged** — Same steps, same order, same logic
4. **Add grounding** — Each skill gets a grounding statement requiring explicit ID citation

---

## Phase 1: Critical Extractions (Largest Impact)

### 1.1 `/ynab` — 550 → ~180 lines

**Current state:** 550 lines with 12 tables of IDs, mappings, and schedules mixed with workflow.

**Extract to `reference.md`:**
- [ ] Category IDs (Bills, Needs, Wants, Internal) — 4 tables
- [ ] Common Payee Mappings table
- [ ] Recurring Bills Schedule — 4 tables (Fixed Monthly, Periodic, Subscriptions, Quarterly)
- [ ] Monthly Budget Targets table
- [ ] Income Sources table
- [ ] Transaction Categorization Rules (payee lists)

**Keep in `SKILL.md`:**
- [ ] Directive: "Pre-approved operations" (verbatim)
- [ ] Directive: "Date confirmation required" (verbatim)
- [ ] Uncategorized transactions workflow (Steps 1-8)
- [ ] Payee Cleanup Workflow (process, not mappings)
- [ ] Authentication section (token, base URL)
- [ ] IDs section (Budget ID, Account ID only)
- [ ] Common API Calls (templates)
- [ ] Allocation Priority Rules (prose)
- [ ] Known Issues / Discovered Issues Log
- [ ] Grounding statement: "Before using any category or payee, state: 'I will use [ID/name] for [purpose], found in reference.md under [section]'"

**Expected result:** SKILL.md ~180 lines, reference.md ~370 lines

---

### 1.2 `/timesheet` — 315 → ~180 lines

**Current state:** 315 lines with large project mapping table and API examples.

**Extract to `reference.md`:**
- [ ] Project Mapping table (25 rows of org file → Zoho Project ID)
- [ ] Francis's Zoho Entry Patterns table
- [ ] API endpoint examples (Create Task, Create Time Entry, List endpoints)

**Keep in `SKILL.md`:**
- [ ] Directive: "Pre-approved operations" (verbatim)
- [ ] Org Files Location
- [ ] Org-mode Clock Format explanation
- [ ] Time Calculation Rules
- [ ] Hierarchy explanation
- [ ] Mockup Output Format
- [ ] Workflow steps (1-6)
- [ ] Notes section
- [ ] Grounding statement: "Before using any project ID, state: 'I will use [ID] for [project], found in reference.md under Project Mapping'"

**Expected result:** SKILL.md ~180 lines, reference.md ~135 lines

---

### 1.3 `/focus` — 347 → ~220 lines

**Current state:** 347 lines with frontmatter schema, image tables, and anti-patterns mixed with narrative guidance.

**Extract to `reference.md`:**
- [ ] Complete Frontmatter Schema (YAML block)
- [ ] Image Locations table
- [ ] Anti-Patterns table
- [ ] Category options list

**Keep in `SKILL.md`:**
- [ ] Skill Chaining section
- [ ] Publication Schedule (workflow, not just table)
- [ ] Scheduled Publishing explanation
- [ ] Inline Images with Captions
- [ ] Footnotes and References rules
- [ ] Fact vs. Interpretation section
- [ ] Article Architecture section (core narrative guidance)
- [ ] Pre-Publication Verification (Required)
- [ ] Voice Checklist
- [ ] Grounding statement: "Before setting frontmatter, verify against reference.md schema"

**Expected result:** SKILL.md ~220 lines, reference.md ~130 lines

---

### 1.4 `/zoho` — 262 → ~140 lines

**Current state:** 262 lines with bank account IDs, expense category IDs, and rate limits.

**Extract to `reference.md`:**
- [ ] Bank Accounts table (8 rows)
- [ ] Expense Categories table (23 rows)
- [ ] Rate Limits tables (Per-Minute, Daily, Concurrent)

**Keep in `SKILL.md`:**
- [ ] Directive: "CRITICAL: Never Use Generic or Uncategorized Accounts" (verbatim, full section)
- [ ] Authentication section
- [ ] Common API Calls (templates with placeholders)
- [ ] Notes section
- [ ] Grounding statement: "Before using any account or category ID, state: 'I will use [ID] for [purpose], found in reference.md under [section]'"

**Expected result:** SKILL.md ~140 lines, reference.md ~120 lines

---

## Phase 2: Borderline Skills (Optional)

### 2.1 `/image-eval` — 277 lines (borderline)

**Assessment:** Most content is evaluation criteria and technique tables. These are core to the skill's function, not reference data. Tables describe *what to look for*, not IDs/mappings.

**Recommendation:** Keep as-is. The tables are operational guidance, not externalizable reference.

---

### 2.2 `/business` — 229 lines

**Assessment:** Pure reference material (business plan). Only loaded when explicitly invoked for strategic questions.

**Recommendation:** Keep as-is. This isn't a workflow skill — it's documentation that happens to be loadable. No workflow to separate from reference.

---

### 2.3 `/image` — 214 lines

**Assessment:** Contains aspect ratio table and palette variants. These are operational (needed during generation), not just reference.

**Optional extraction to `reference.md`:**
- [ ] Supported Aspect Ratios table
- [ ] Palette Variants table (keep summary in SKILL.md)

**Recommendation:** Low priority. Current size is acceptable.

---

## Phase 3: Enforcement Hooks

### 3.1 `/zoho` — No Uncategorized Hook

**Purpose:** Block any API call that would assign to Uncategorized (ID: 1117916000000035005) or Other Expenses (ID: 1117916000000000460).

**Implementation:**
```bash
# .claude/skills/zoho/hooks/no-uncategorized.sh
#!/bin/bash
INPUT=$(cat)
if echo "$INPUT" | grep -qE "1117916000000035005|1117916000000000460"; then
  echo "BLOCKED: Uncategorized/Other Expenses accounts are forbidden per user directive" >&2
  exit 2
fi
exit 0
```

**Hook registration:** Add to `.claude/settings.json` under PreToolUse for Bash.

---

### 3.2 `/focus` — Em-Dash Check Hook (Optional)

**Purpose:** Warn (not block) when writing MDX files that contain em-dashes.

**Complexity:** Medium — would need to parse Write tool output for `.mdx` files and grep for `—`.

**Recommendation:** Defer. The `/text-eval` skill already catches this during evaluation.

---

## Phase 4: CLAUDE.md Optimization

**Current:** 225 lines (target: <150)

**Extraction candidates:**
- [ ] Self-Improvement Protocol (lines 184-225) — Replace with: "See individual skill files for issue documentation patterns"
- [ ] Skills Reference tables — Already necessary, keep

**Realistic target:** ~180 lines (can't go much lower without losing essential project context)

---

## Execution Order

| Step | Skill | Action | Est. Time |
|------|-------|--------|-----------|
| 1 | /ynab | Extract to reference.md | 15 min |
| 2 | /timesheet | Extract to reference.md | 10 min |
| 3 | /zoho | Extract to reference.md | 10 min |
| 4 | /focus | Extract to reference.md | 10 min |
| 5 | /zoho | Create enforcement hook | 5 min |
| 6 | CLAUDE.md | Trim Self-Improvement section | 5 min |
| 7 | Verify | Read each optimized skill, confirm behavior unchanged | 10 min |

**Total estimated:** ~65 minutes

---

## Success Criteria

After optimization:

| Metric | Before | After | Target |
|--------|--------|-------|--------|
| /ynab lines | 550 | ~180 | <200 |
| /timesheet lines | 315 | ~180 | <200 |
| /focus lines | 347 | ~220 | <250 |
| /zoho lines | 262 | ~140 | <150 |
| CLAUDE.md lines | 225 | ~180 | <200 |
| Enforcement hooks | 0 | 1 | 1+ |
| reference.md files | 0 | 4 | 4 |

---

## Verification Checklist

For each optimized skill:

- [ ] All directives preserved verbatim
- [ ] All workflow steps unchanged
- [ ] All tables moved intact (no rewriting)
- [ ] Grounding statement added
- [ ] Link to reference.md added
- [ ] Skill still triggers on same phrases
- [ ] Test invocation produces same behavior

---

## Notes

- **Do not rewrite content** — This is restructuring, not editing
- **Preserve discovered issues logs** — These are valuable institutional knowledge
- **Test after each extraction** — Don't batch all changes before testing
