# CLAUDE.md

> This project targets Opus 4.7+. All instructions are written for literal execution. If an instruction is ambiguous, ask — do not infer.

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

**Status: skill layer built, SignMe discovery done, app not yet scaffolded (updated 2026-07-28).**
The `.claude/` layer is complete — `/odyssey-apps` and its 16 companion skills are installed (17
including `/odyssey-apps` itself, matching the Skills Reference table below), and
the foundational decisions are made and recorded. **No application code exists yet**; `pnpm`,
`src/`, `convex/` and the rest arrive when `/odyssey-apps build` runs. This file will be rewritten
again once it does.

**This directory is NOT a git repository.** Everything here — skills, references, the ledger — is
loose files with no commit history to fall back on. Treat edits accordingly.

**Start here:** `/odyssey-apps` is the front door for all site work. Its `references/` carry the
decided state — `port-inventory.md` (what to copy and strip), `schema.md` (the database plan),
`modules.json` (the site thesis, both modules, positioning), `beta-access.md`, and `palette.md`.
**Per-module grounding files are mandatory reading before touching a module:**
`meridian-workflow-notes.md` (Meridian's interview record — her words, and nothing gets built that
cannot be traced to a line in it), `meridian-interview-queue.md` (the standing queue of questions not
yet put to her — read it before proposing any Meridian research or county-records work), and
`sign-me-build-plan.md` (SignMe's discovery record and phased build plan). Institutional memory is in
`.claude/skills/awareness-ledger/ledger/` — **17 decision records and 3 patterns**; start at
`ledger/index.md`, which opens with per-module "read these first" blocks.

**Session of 2026-07-27 — what changed.** A discovery pass on SignMe, ending with a hands-on review
of a live DocuSign account (authorized by the account holder; upload → place fields → send → sign →
complete → download, plus the Certificate of Completion retrieved and read in full). Results:

- **`research-log.md` grew §§ 7–12** — DocuSign's legal surface, what an e-signature system must BE
  under ESIGN/UETA/URPERA/RON, three primary case-law opinions on repudiated signatures, sending
  documents to a model, and the hands-on review. This is the SignMe evidence base.
- **`sign-me-build-plan.md` is new** — the consolidated plan: settled/proposed/open, the v1 slice,
  a `sign*` data-model sketch, a 9-phase plan, and what could invalidate the module.
- **Three ledger decisions** — SignMe stands alone (accepted), mechanical-first field detection
  (accepted, + an amendment putting the verification sweep on the Anthropic API directly), and
  erase-the-document-keep-the-hash (**still proposed**, amended once the real certificate showed the
  retained row carries signer name, email, and IP).
- **`playwright-mcp` gained real session binding** — a captured login now authenticates the
  interactive `browser_*` tools, not just `web_fetch`, and `session_attach` switches actors. That
  repo is committed and in sync with origin. SignMe's test suite depends on it (two-actor pattern in
  `procedures/test-suite.md`).

**Session of 2026-07-28 — what changed.** A feasibility probe of county property records for
Meridian, run against Tillamook County's Property Search Online and then Clatsop County's. Full
extraction works on Tillamook (owner, situs + mailing address, assessment, tax history, sales chain,
lender of record); Clatsop is unrelated software whose query grammar was not cracked. Results:

- **`DEC-2026-07-28-county-adapter-registry`** (accepted) — one adapter per county behind a shared
  output contract. The cheaper vendor-platform shortcut was tested and refuted. **Architecture only:
  it does not authorize building the feature.**
- **`PAT-2026-07-28-county-record-extraction-traps`** (active) — nine ways these sites return
  plausible-but-wrong data without erroring (a `$0` trust transfer sitting above the real sale,
  truncated owner lists, personal-property account collisions, AV≠market value, an incomplete TLS
  chain that breaks Node `fetch`).
- **`meridian-interview-queue.md` is new** — the standing queue of questions for the practitioner,
  carried across sessions. County records remain **Francis's untested hypothesis**; the notes
  (line 675) raise the live possibility that MLS already covers the task. Nothing was built.

## Project goal

**apps.odysseyalive.com** — a site hosting **AI productivity tools**, structured as self-contained
modules within one shared project. It is a **private, proprietary project (not open-source)**.

"Module" means a self-contained unit that lives in this repo, shares the site's accounts, theme,
entitlements, and backend, and is added alongside its siblings rather than split into a separate
project. Here a module is a **first-party Next.js route tree** under
`src/app/(app)/modules/<slug>/app`, entitlement-gated on `moduleAccess`.

**The first two modules** (decided 2026-07-22; scopes still OPEN):

| Slug | Title | What it is |
|---|---|---|
| `meridian` | **Meridian** | A workspace for the solo real-estate agent — speeds up work that takes hours and tracks where everything stands. The catalog's HUB; other modules connect into it |
| `sign-me` | **SignMe** | E-signature for real estate. A SPOKE on Meridian, not a sibling |

**The catalog is NOT real-estate-specific.** More modules are coming and most will not be real
estate; the first two happen to be. Consequence that binds now: the home page — copy AND imagery
— stays vertical-neutral, and nothing in the shared schema, admin, or entitlement layer may assume
real estate. Details in `odyssey-apps/references/modules.json` `$site_thesis`.

## Origin: copied from nsayka-wawa / odyssey-skul

This project is a **direct copy of the website half of `/home/francis/lab/nsayka-wawa`** (the
"odyssey-skul" site that serves skul.odysseyalive.com), retargeted to host AI productivity tools
instead of interactive-fiction game modules.

**Everything Inform 7 and Chinuk Wawa is dropped.** No `.inform`/`.materials` bundles, no Glulx,
no gargoyle/glulxe-term, no CW corpus, no Pimsleur pedagogy, no `library/` translation sources.
Skills carrying that baggage (`nsayka-wawa`, `nsayka-wawa-canon`, `if-craft`, `cw-*`,
`elders-speak`, `english-to-cw`, `study-prep`, `pimsleur-pedagogy`, `pnw-forest-beings`,
`inform-precheck`) do not come across.

The `/odyssey-skul` skill came across as a **template** for this project's own site skill.
**Done 2026-07-22:** it was ported and retargeted as **`/odyssey-apps`** (see § Skills Reference).
The port decisions are recorded in that skill's `references/port-inventory.md`; the ratified
choices were: port the app from nsayka-wawa's site half rather than re-deriving from
odyssey-alive, slugs `meridian` + `sign-me`, a professional blue/white/gold palette, and
photographic imagery in place of the watercolor illustration aesthetic.

Related projects for reference:
- `/home/francis/lab/nsayka-wawa` — the source being copied (odyssey-skul site + IF game).
- `/home/francis/lab/odyssey-alive` — odysseyalive.com, the parent marketing site; the deploy
  template both sites descend from.
- `/home/francis/lab/jstack` — the Docker hosting stack this deploys through.

## Stack

Carried over from odyssey-skul in full, minus Inform 7:

- **Next.js 16** + **React 19**, TypeScript
- **Tailwind CSS 4** (+ `@tailwindcss/typography`), PostCSS
- **Velite** for MDX content
- **Convex** (self-hosted) for the backend: accounts/auth (`@convex-dev/auth`, `@auth/core`),
  per-account state, support desk
- **pnpm** as the package manager (never npm or yarn)
- **Playwright** for tests
- **ESLint** (`eslint-config-next`)
- Email via `resend` / `nodemailer`; `@marsidev/react-turnstile` for bot protection;
  `framer-motion`, `sharp`, `zod`, `clsx`, `tailwind-merge`
- Deploy via **jstack** (Docker Compose + nginx + certbot), as `jstack/sites/apps.odysseyalive.com`

## Build / run / test

Ports are allocated per project so they can run side by side: odyssey-alive 3030,
odyssey-skul 3040, **this project 3050**.

Expected scripts, mirroring odyssey-skul's `package.json` (adapt as the scaffold lands):

```
pnpm install
pnpm dev            # copy-assets + velite + next dev --port 3050
pnpm build          # next build (prebuild runs copy-assets + velite)
pnpm start          # next start --port 3050
pnpm lint           # eslint
pnpm verify         # bash scripts/verify.sh
pnpm serve / stop   # bash scripts/serve.sh [stop]
```

Convex:

```
pnpm migrate:new / migrate:verify / migrate:run
pnpm db:bootstrap
pnpm db:deploy      # migrate:verify -> convex deploy -> migrate:run -> db:bootstrap
```

Runtime verification goes through the project's Playwright test suite (`/test-suite`), not
one-off scripts.

## Layout (expected, once copied)

```
src/            Next.js app source
content/        Velite MDX content
convex/         Convex backend (schema, functions, migrations)
public/         static assets served as-is
assets/         source assets, copied into public/ by scripts/copy-assets.js
scripts/        serve.sh, verify.sh, copy-assets.js, migration helpers
tests/          Playwright suites
deploy/         jstack deploy config
.claude/        skills, agents, hooks, settings
```

## Environment

`.env.local` (symlinked as `.env`) carries the secrets, with `.env.example` as the committed
template. Values are pulled over from nsayka-wawa, including the **nanobanana** (Gemini image
MCP) credentials used by the `/image` skills. Never commit `.env.local`.

## Skills to import

From `/home/francis/lab/nsayka-wawa/.claude/skills/`:

- **Site/infra:** `odyssey-skul` (as a retargeting template), `frontend-design`, `serve`,
  `test-suite`, `route`, `model-switch`, `self-heal`
- **Authoring/voice:** `my-voice`, `writing`, `edit`, `text-eval`, `wit`, `copy-truth`
- **Image:** `image`, `image-eval` (nanobanana-backed)
- **Infrastructure:** `awareness-ledger`, `code-evaluator`, `analytics`, `skill-builder`

**Imported 2026-07-22.** Skills are **snapshots** — diverge them freely. `/serve` was deliberately
NOT imported: nsayka-wawa's `/serve` recompiles Inform 7 and serves Parchment on :8765; this
site's server lifecycle belongs to `/odyssey-apps serve`.

**Retargeting completed 2026-07-22.** All three chores are done:

- **`/image`** rethemed to the drawn graphic system. Two of its immutable directives conflicted
  with this project and were **superseded by dated amendment, never edited**: the watercolour
  base style, and "each image in a set uses a different palette variant" — the latter is
  *inverted* here, because a system is recognisable precisely when its colours and measurements
  repeat. Scope reduced to textural fields (line-work is authored SVG). CW-label references
  removed.
- **`/image-eval`** retargeted: `references/graphic-system.md` replaces watercolour-technique
  authenticity, and the palette check is inverted to flag drift rather than sameness. Its two
  game-era directives (partial figures, labels over faces) are **inert here and preserved
  verbatim** — this project generates no people and has no label pipeline.
- **`/my-voice`** calibration paths resolved. The directive gives relative paths into
  `content/focus/`, which does not exist in this repo; a path note points them at
  `/home/francis/lab/odyssey-alive/content/focus/` (both files verified present, read-only).

**Two skills were removed rather than retargeted** — both are Inform 7 game tooling that the
import list mislabeled as site infra:

- **`/serve`** recompiles Inform 7 and serves Parchment on :8765. The site's lifecycle is
  `/odyssey-apps serve`.
- **`/test-suite`** is the game's transcript-test harness (`tools/run.py`, tests for
  parser/mechanics/navigation/save). The site's Playwright suite is `/odyssey-apps test`. Its one
  genuinely general rule — the **Regression-Guard Discrimination Gate** — was carried into
  `odyssey-apps/references/procedures/test-suite.md`, and the references that pointed at it were
  repointed.

## Skills Reference

All 17 skills installed and retargeted as of 2026-07-22. The site's Playwright suite is `/odyssey-apps test`, not a separate skill.

| Skill | Use it for | Lane |
|-------|-----------|------|
| `/odyssey-apps` | **The site's front door.** Build, theme, populate, maintain, and deploy apps.odysseyalive.com. 20 modes incl. `build`, `scaffold`, `serve`, `verify`, `module-app`, `beta`, `admin`, `deploy` | per-mode |
| `/route` | Dispatcher — pass any task description and it invokes the right skill | — |
| `/skill-builder` | Create, audit, optimize skills; hooks, agents, ledger, backups | — |
| `/awareness-ledger` | `record` / `consult` / `review` institutional memory | — |
| `/self-heal` | Ambient friction detection; surgical skill correction at task resolution | — |
| `/model-switch` | Lane gate — creative work on the creative model, everything else on the analytical one | — |
| **Authoring** | | |
| `/my-voice` | Load Francis's voice profile. Required for all site copy | creative |
| `/writing` | Content and communication protocol | creative |
| `/edit` | Revision gateway — routes any change to shipped copy through the writing kernel | creative |
| `/wit` | Satirical wit — `deploy`, `scout`, `humor` | creative |
| `/text-eval` | AI tells and voice loss. **Unconditional on every shipped string** (2026-07-22 directive) | creative |
| `/copy-truth` | Does the copy claim a capability the interface actually gives this reader? | creative |
| **Design + media** | | |
| `/frontend-design` | Distinctive, production-grade UI. Named in an immutable directive | creative |
| `/image` | Generate the textural layer via Nano Banana (graphic system; line-work is authored SVG) | creative |
| `/image-eval` | AI-generation tells + graphic-system integrity (drift, register, meaning) | creative |
| **Engineering** | | |
| `/code-evaluator` | `review` a diff / `sweep` the tree for dead code, duplication, complexity | coding |
| `/analytics` | Cloudflare RUM traffic assessment correlated with releases | coding |

Model lanes are configured: creative → `claude-opus-4-6`, everything else → `claude-opus-4-8`.

## Conventions and hard constraints

- **Playwright only. Never use `mcp__claude-in-chrome__*` tools in this project** — not for
  screenshots, not for review, not for debugging. All browser-driven verification goes through
  Playwright. The Chrome MCP extension is installed system-wide but is not acceptable here.
- **Skill-first proposals.** Express every multi-step plan, continuation prompt, or agent brief as
  slash-command invocations of this project's skills, not as freeform imperative prose — skills
  carry the directives, write-gates, model selection, and bookkeeping that prose bypasses. If no
  skill covers a step, surface the gap explicitly rather than doing it ad hoc (`/skill-builder new
  <name>`, or extend an existing skill). Narrow read-only follow-ups are exempt.
- **Private and proprietary.** Not open-source. Deploys via jstack. **pnpm only.**
- **Awareness ledger.** Institutional memory lives at
  `.claude/skills/awareness-ledger/ledger/`. Check `ledger/index.md` before recommending
  non-trivial changes and factor in matching records; use `/awareness-ledger consult` when
  high-risk overlap shows up. After resolving something worth remembering (recurring bugs,
  architectural choices, trade-offs), finish the work first, then ask the user whether to record
  it via `/awareness-ledger record [type]`.

## Next steps

**Done 2026-07-22:** `/odyssey-apps` authored and retargeted; all companion skills imported; the
foundational decisions made and recorded in the awareness ledger; this file refreshed.

**Done 2026-07-27:** SignMe's discovery pass — see the status block at the top of this file for
what it produced and where it lives. Nothing was built; the app is still unscaffolded.

**Before `/odyssey-apps build`:**

1. **`.env.local`** — Turnstile + SMTP from nsayka-wawa, the three Mailchimp keys from
   **odyssey-alive** (same newsletter, same audience), and **freshly generated** Convex auth keys
   via `scripts/generateKeys.mjs`. Never reuse nsayka-wawa's signing key.
2. Docker running, for self-hosted Convex.

**Then:** run `/odyssey-apps build` in a fresh session. It creates one task per phase so the long
run survives compaction, and it is resumable.

**Open decisions it will surface rather than guess** (also tracked in the skill's references):

- **The paperwork interview for SignMe — the biggest open item.** The Meridian interview
  (`meridian-workflow-notes.md`) never touched contracts, offers, disclosures, or closing documents,
  so every SignMe feature named so far is an *invention*, not testimony. This blocks SignMe's UI
  scope, though not its engine work. Questions and rationale: `sign-me-build-plan.md` § 2. The
  productive framing is *"what did you do and resent,"* never *"what features do you want."*
- **Which county the practitioner actually lists in — blocks the county-records line.** Her MLS
  association subdomain is `CLT` (probably Clatsop); the property examined on 2026-07-28 is
  Tillamook, and the two counties run entirely unrelated record systems with no shared work between
  them. If the answer is "both," two adapters are needed on day one. Architecture is settled in
  `DEC-2026-07-28-county-adapter-registry` (accepted, **architecture only — not authorization to
  build**); the traps a county adapter must survive are in
  `PAT-2026-07-28-county-record-extraction-traps`. The gating questions are staged as Batch A of
  `meridian-interview-queue.md`, and question A3 can end the whole line.
- Trademark / domain availability for the name **Meridian** — not verified, and it is a common
  business name. Check before it ships in a URL.
- **Whether the SignMe attestation row survives a signer's erasure request** — a legal question, not
  a technical one, and it blocks the `signEvents` table design.
  `DEC-2026-07-27-erase-document-keep-hash` § Amendment states it against the real field list.
- **Anthropic's DPA / processor terms** — unread, and now operative: the field-detection sweep calls
  the Anthropic API directly, which makes it a subprocessor carrying the agent's clients' documents.
- The beta re-request rate limit after a denial (proposed: 1 per user per module per 30 days).
- The `supportTickets.purpose` enum is settled but user-visible; changing it later is a migration.

**Resolved since this list was written — do not re-raise:** whether SignMe stands alone (yes,
`DEC-2026-07-27-signme-stands-alone`); which provider runs the detection sweep (Anthropic direct);
whether brokerage form mandates block the build (no — they bound the *advertising*, see
`modules.json` `sign-me.copy_constraints`); and Meridian's core scope, which the 2026-07-22
interview confirmed.

**Also outstanding, outside this project:** the `skill-builder` agent-directive conflict — its
immutable "AGENTS ARE MANDATORY" directive collides with sessions that forbid spawning agents.
It will fire again on any `/skill-builder audit`.
