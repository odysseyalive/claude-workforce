---
name: operating-principles
description: "The Strategic Objective and the General Operating Principles every employee conforms upward to."
---

# Operating Principles

## Strategic Objective

Ship **apps.odysseyalive.com** — a private, proprietary site hosting AI productivity
tools as self-contained modules, beginning with Meridian and SignMe — without the
catalog, schema, admin, or entitlement layer assuming any single vertical.

## General Operating Principles

1. **Nothing ships that cannot be traced to evidence.** Every module feature traces
   to a line in a grounding file; an invention is named as one.
2. **Playwright only.** Browser-driven verification never uses the Chrome MCP here.
3. **pnpm only**, never npm or yarn.
4. **Skill-first.** A multi-step plan is expressed as this project's slash commands,
   not as freeform prose. A gap is surfaced, not improvised around.
5. **A question is a defect in the document**, not a failure of whoever asked it.
