# PAT-2026-07-28-county-record-extraction-traps

**Status:** active
**Tags:** odyssey-apps, meridian, public-records, scraping, playwright, data-quality, tillamook
**Related:** DEC-2026-07-28-county-adapter-registry, DEC-2026-07-22-mls-data-access

## Pattern

**County property-record sites fail by returning plausible-but-wrong data, not by erroring.** Every
trap found on 2026-07-28 produces a value that passes a type check, renders cleanly in a UI, and is
false. None of them throws. A scraper written to the happy path will look like it works and will
quietly report the wrong owner, the wrong sale price, or a missing co-owner.

The corollary: **normalization belongs above the adapter layer**, applied once to the shared contract,
because each trap is a data-shape problem rather than a site-specific parsing problem. Only the
mechanism is per-county.

## Evidence

All observed 2026-07-28 against Tillamook County PSO (`query.co.tillamook.or.us/PSO/`) unless noted.

1. **The most recent sale can be `$0`.** Account 74779 (972 S Breaker Ave, Rockaway Beach) shows a
   30-Dec-2025 bargain-and-sale at **$0** — a transfer into the owners' trust — above an 18-Jul-2024
   warranty deed at **$480,000**. A naive "last sale price" returns $0. *Fix: filter on doc type
   (`WD` vs `B&S`) and non-zero price for comps; surface the trust transfer separately, because it is
   signal in its own right.*
2. **Owner lists truncate silently.** The same account displays two owners plus a "View all 3 Names"
   control; the third (JOAN M NORTH) appears only after expanding. *Fix: always expand; treat a
   "View all N" control as a hard requirement, not an enhancement.* The expanded modal then
   **intercepts pointer events on every other tab** until explicitly closed — a Playwright click on
   another tab times out rather than failing usefully.
3. **"Smallest account number" can select the wrong property class.** A search on `Wilson River Loop`
   returned **Account 3904 — KR SALON, Personal Property**, with no situs address at all.
   Personal-property accounts number in the thousands; real-property accounts in the hundred-thousands.
   A naive `min()` picks a business's equipment account over the house. *Fix: filter to Real Property
   before taking the minimum.*
4. **One assessment account fans out to several tax accounts.** Account 146210 carries tax accounts
   146210 (code area 0912) and 416537 (code area 0908). "The tax amount" is a sum across rows, not a
   field. *Fix: model tax as an array keyed by tax-account ID.*
5. **Assessed value is not market value.** AV $148,300 against a $480,000 arm's-length sale, per
   Oregon's Measure 50 MAV compression. *Fix: never label AV as market value; if the UI shows a
   value at all, label the basis.*
6. **Street-suffix matching is literal, not fuzzy.** `201 Laurel Avenue` → "No results found";
   `201 Laurel Ave` → one result; `201 Laurel` → one result. Dropping the suffix is more robust than
   abbreviating it, and the county's own instructions endorse minimal input. *Clatsop is stricter
   still: three formats of its own placeholder address were all rejected.*
7. **The search surface is a Blazor Server SignalR circuit.** A plain HTTP GET to
   `/PSO/search?searchOption=Address&searchValue=…` returns a 3.6 KB shell with zero data. Search
   requires a real browser; `fetch` + a DOM parser returns empty silently.
8. **But the reports are plain HTTP, keyed on account ID** — no circuit needed once the ID is known:
   `download/?report=TaxSummaryAll&accountId=<id>&RollType=Real`, plus `TaxStatementAll`,
   `AssessmentSummary&year=`, `Legal`, `TaxStatementHistory`. The `TaxSummaryAll` PDF carried mailing
   address, situs, 13+ years of tax, and a populated **Lender Name** field. *Browser for the search,
   cheap HTTP for the payload.*
9. **The TLS chain is incomplete.** `query.co.tillamook.or.us` serves only the leaf certificate, no
   GoDaddy G2 intermediate. Chromium recovers via AIA fetching; `curl` and Node `fetch` fail with
   `unable to get local issuer certificate`. *Fix: bundle the intermediate in any server-side
   fetcher.* No `robots.txt` exists (404), so there are no crawl directives either way.

## Counter-Evidence

1. **This is one county, thoroughly probed, plus one barely probed.** Tillamook was exercised end to
   end; Clatsop was characterized (bespoke PHP/jQuery, POST search) but its query grammar was not
   cracked in three attempts. Traps 1–5 are data-shape problems and should generalize; traps 6–9 are
   Tillamook-specific mechanism and should not be assumed elsewhere. — 2026-07-28
2. **Trap 3's severity depends on search breadth.** It surfaced on a street-wide search
   (`Wilson River Loop`), not on a full address-line-1 search, which returned only same-situs
   accounts. Narrow searches may never hit it — which makes it *more* dangerous, not less, since it
   will pass testing and fire in production on a sloppy input.
3. **Trap 1 was found on a single record.** A $0 trust transfer sitting atop a real sale is common in
   Oregon but the sample here is one property. The fix is cheap and the failure is expensive, so it
   is worth applying regardless.

> **"Yeah, that's a good question."**

*— Captured 2026-07-28, source: Francis, on which county the practitioner actually lists in — the
question these traps are downstream of, since none of this is worth hardening until the county is
known.*

## Applicability

- **When to use:** writing or reviewing any county property-record adapter; reviewing the shared
  normalization layer; writing contract tests for an adapter.
- **When NOT to use:** as a substitute for probing a new county. Traps 6–9 are Tillamook's mechanism.
  Each new county needs its own discovery session — that cost is the whole point of
  DEC-2026-07-28-county-adapter-registry.
- **Do not treat this list as complete.** It is what one afternoon against two properties surfaced.
  Assume more exist.

## Confidence

**MEDIUM** — HIGH for the traps themselves (each directly observed, none inferred), MEDIUM for
generalization beyond Tillamook, which rests on one partially-probed second county. Upgrade to HIGH
if traps 1–5 reproduce on the Clatsop adapter; downgrade the data-shape claims if they do not.
