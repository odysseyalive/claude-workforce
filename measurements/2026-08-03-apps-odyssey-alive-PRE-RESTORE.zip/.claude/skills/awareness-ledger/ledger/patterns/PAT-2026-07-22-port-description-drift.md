# PAT-2026-07-22-port-description-drift

**Status:** active
**Tags:** odyssey-apps, port, nsayka-wawa, skills, refactoring, verification
**Related:** DEC-2026-07-22-port-from-nsayka-wawa, DEC-2026-07-22-private-tickets-only

## Pattern

**In this port, a component's DESCRIPTION and its ACTUAL USAGE diverge in both directions. Verify
by grepping real usage, never by reading the name, the frontmatter, or the prose.**

The failure runs both ways, which is what makes it dangerous:

- **Looks like site infra, is game tooling** — import it and it silently does nothing useful.
- **Looks like game/forum tooling, is load-bearing site code** — strip it and something quietly
  stops working with no error.

Neither direction announces itself. Both were caught only by grepping actual call sites.

## Evidence

1. **`/serve`** — listed under "Site/infra" in the import list; the skill actually recompiles
   Inform 7 and serves Parchment on :8765. The site's lifecycle is `/odyssey-apps serve`.
   Removed. — 2026-07-22
2. **`/test-suite`** — frontmatter says *"Curated Playwright-test library"*; the corpus is
   `tools/run.py` plus transcript tests for parser, mechanics, navigation, and save. It is the
   game's harness. Removed, after extracting its one general rule (the Regression-Guard
   Discrimination Gate) into `odyssey-apps/references/procedures/test-suite.md`. — 2026-07-22
3. **`convex/profanity.ts`** — the INVERSE case, and the more dangerous one. Marked for stripping
   as forum-only when the public forum was removed. Grepping showed `containsBadWord` guards
   USERNAMES at signup and account edit (`loginCode.ts:212`, `authCodes.ts:134`,
   `account.ts:106`). Stripping it would have silently disabled username validation — no error,
   no failing test. Kept. — 2026-07-22
4. **odyssey-skul's own prose had drifted from its own `schema.ts`** in three places, including a
   `betaEnabled` field the docs did not mention and an `accessRequests` table further along than
   documented. — 2026-07-22
5. **The beta-request flow was documented as UNBUILT and is in fact IMPLEMENTED.** odyssey-skul's
   prose states `accessRequests` is "schema-ready… Do NOT build the self-service UI yet."
   `convex/access.ts` contains `requestBetaAccess`, `myAccessRequests`, `hasPendingBetaRequest`,
   and `listAccessRequests`, plus a `BetaIntentClaimer` client component handling the post-signup
   auth race. **The most expensive instance of this pattern so far**: the stale doc caused a
   working feature to be re-specified from scratch as new work. — 2026-07-22
6. **`convex/recovery.ts`** is named for recovery and contains GAME-SAVE recovery (DEC-037),
   operating on tables that are stripped. It was briefly mis-listed as account-lifecycle code on
   the port's copy list. — 2026-07-22
7. **`bootstrap` defaults `accessible: false`** — taking the seeder unchanged would have shipped a
   Request-beta button that rejected every click, with no error anywhere. — 2026-07-22

## Counter-Evidence

1. **The port is still the right call.** These are findable, one-time costs; re-deriving the auth
   and entitlement stack from scratch would have re-paid for bugs already fixed in production.
   The pattern argues for verification during the port, not against porting.
   — DEC-2026-07-22-port-from-nsayka-wawa
2. **Most of the port is exactly what it says.** Auth, entitlements, admin, tickets, and the
   migration system all transferred cleanly. The drift is concentrated where the game and site
   halves of a monorepo touched — which is a predictable place to look, not a random one.

## Applicability

- **When to use:** any decision to import, keep, or strip a component from nsayka-wawa. Grep the
  call sites first. Cost: seconds. Cost of skipping: a silent hole.
- **When to use (extended):** whenever documentation and code could disagree — prefer the code.
  schema.md was derived from `schema.ts` for exactly this reason.
- **When NOT to use:** not a reason to distrust the port wholesale or re-derive from scratch.
  The mechanisms are sound; it is the LABELS that are unreliable.

## Confidence

**HIGH** — seven independent instances in one session, in both directions. Three would have failed
silently rather than loudly; one (the beta flow) caused real duplicated design work rather than a
runtime fault, which is the pattern's other cost and the easier one to miss.

**Sharpened rule after instance 5:** when a doc says a feature is deferred, unbuilt, or "not yet",
**grep for its function names before believing it**. Absence of a feature is exactly as unreliable
a claim as presence, and it is more expensive — a missing thing gets rebuilt, quietly and at full
cost, by someone who trusted the prose.
