# PAT-2026-07-22-machine-narrows-human-judges

**Status:** active
**Tags:** odyssey-apps, meridian, ai, product-scope, openrouter, ux
**Related:** DEC-2026-07-22-meridian-scope-dormant-contacts, DEC-2026-07-22-no-guilt-scoring,
DEC-2026-07-22-openrouter-provider

## Pattern

**The machine narrows by topic; the human judges relationship, intent, and worth.** When a
practitioner can state a rule for a classification, automate it. When she cannot — and says so —
that judgment is hers, and the software's job is to shrink the set she has to judge, not to make
the call for her.

The dividing line is empirical and cheap to find: ask her the rule. If she answers with criteria,
it is mechanisable. If she answers "it depends", "trial and error", or "I'm not sure", it is not,
and any model built on it is inventing a rule its own source denies having.

## Evidence

1. **She could not state a rule for seriousness** — "It's always a trial and error situation with
   people… there are just some that just slip through the cracks because I'm not sure." — interview
   2026-07-22.
2. **Nor for keep-or-drop** — the contacts she was glad to lose failed on location or on *her own
   capacity at the time* ("what was going on with me at that time that they decided to list"), a
   variable no lead-scoring model carries.
3. **Nor for personal fit** — the ones she regrets are those where "we got on with each other",
   knowable in the moment and not reconstructible afterward.
4. **But she named a mechanical filter herself, unprompted** — "single out the ones who I have
   definitely talked to about real estate goals." Topic, not relationship. Close to binary, and it
   requires none of the judgments above.
5. **She stayed the judge willingly.** Handed the sorted-down list, she knew immediately what to do
   with it; the friction was never the judging, it was the volume of material to judge over.

## Counter-Evidence

1. **Two of her ranking signals ARE mechanical** — response speed is computable from message
   timestamps, and distance from an address. So "relationship judgments are never mechanisable" is
   too strong; the pattern is about which *classifications* to automate, not which *inputs* to
   compute. Computing an input that informs her judgment is fine and useful.
2. **The topic filter will still be wrong sometimes.** Friends talk to her about real estate too,
   so a topic-narrowed list is not a clean prospect list — it is a smaller pile she still sorts.
   The pattern reduces her work; it does not eliminate the sorting step.
3. **She asked for exactly the thing the pattern forbids** — "Is there any way to kind of filter
   those out?", meaning friends from prospects. A user requesting automation of a judgment is not
   evidence that it can be automated; it is evidence that the work is annoying.

> **"That's hard to tell, because I've saved a lot of people on my phone who I've only met once or
> twice, talking about non-real-estate issues. So there would have to be a way to filter out those
> people and just single out the ones who I have definitely talked to about real estate goals."**

*— Captured 2026-07-22, source: interview relayed by Francis. This answer corrected an assistant
proposal that names and dates alone would suffice, and supplied the better filter in the same
breath.*

## Applicability

- **When to use:** any Meridian or catalogue feature that would sort, rank, score, or prioritise
  people. Ask for the rule first. Automate the topical/mechanical narrowing, hand back the
  judgment.
- **When to use:** deciding what an AI call is *for* — extraction and filtering against a stated
  question, not inference about intent or worth.
- **When NOT to use:** as an excuse to hand the user everything unsorted. The whole value here is
  that the pile gets smaller. A tool that narrows nothing has not applied this pattern, it has
  skipped the work.
- **When NOT to use:** where the practitioner *can* state the rule. Then automate it and stop
  asking.

## Confidence

**MEDIUM-HIGH.** Five independent supporting observations from a single practitioner in a single
session, with three genuine limits recorded. The core claim — do not model judgments the
practitioner says have no rule — is well supported. The specific split for Meridian (topic
narrows, she sorts) is untested in use and should be revisited after she sees a real list.
