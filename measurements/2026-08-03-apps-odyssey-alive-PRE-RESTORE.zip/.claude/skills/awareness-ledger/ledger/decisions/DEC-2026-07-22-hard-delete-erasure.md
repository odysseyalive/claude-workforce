# DEC-2026-07-22-hard-delete-erasure

**Status:** accepted
**Tags:** odyssey-apps, gdpr, privacy, convex, schema, admin, erasure
**Related:** DEC-2026-07-22-private-tickets-only, DEC-2026-07-22-manual-grant-vs-subscription

## Context

The port's `deleteAccount` deletes most user rows outright but **anonymizes support content in
place**: owned tickets keep their row with the subject replaced by "Post from a deleted account"
and `ownerDeleted: true`; authored messages keep their row with the body replaced by a GDPR
removal notice and `authorDeleted: true` (verified in `nsayka-wawa/convex/account.ts`). The source
comment states the rule: content displayed to other people keeps an anonymized husk; everything
else is removed outright.

That behavior exists because support there was a PUBLIC FORUM — hard-deleting one participant's
posts would tear holes in a conversation others were reading.

## Decision Drivers

- The public-forum justification does not survive DEC-2026-07-22-private-tickets-only. A ticket
  here is a private thread between one user and staff; there is no third-party reader.
- Francis's plain expectation of what erasure means.
- Keeping `ownerDeleted` / `authorDeleted` after hard deletion would leave permanently unreachable
  states in schema and UI — a trap for whoever reads the code next.

## Options Considered

### Option A: Hard-delete every row referencing the user, tickets included

- Good, because it matches the plain meaning of erasure.
- Good, because it removes the anonymization machinery entirely (simpler code, fewer states).
- Bad, because staff lose the support history when a user erases.

### Option B: Keep anonymize-in-place as ported

- Good, because staff keep a coherent support record, and it is already built and working.
- Bad, because the reason it exists no longer applies, so it would be cargo-culted.

## Decision

Chosen option: **Option A**.

> **"you can completely delete an account and it deletes all data in reference to that account.
> That's in the database, the Convex database. That's how GDPR works. You have to be able to scrub
> people if they request being scrubbed from the website."**

> **"since these are private tickets, they should just get scrubbed along with the user data."**

*— Captured 2026-07-22, source: Francis Meetze, session "site-development"*

## Consequences

- `supportTickets.ownerDeleted` and `ticketMessages.authorDeleted` are dropped from the schema,
  along with `DELETED_TICKET_SUBJECT`, the removal-notice body, and the `DELETED` author rendering.
- **An admin entry point is required and is genuinely new** — the port has self-service erasure
  only. Most erasure requests arrive as an email to a human, not a click. `adminEraseAccount` and
  `deleteAccount` MUST share one internal engine; two paths will drift, and the one that drifts is
  the one that quietly stops deleting a table added later.
- **The registration trap:** the engine iterates a declared table list. A user-data table added
  without being registered is silently never erased — tests pass, the UI looks right, the data
  persists. Adding a table and registering it for erasure is ONE change.
- Support metrics cannot be derived by reading old tickets later. If aggregate reporting is ever
  wanted, it must be captured as non-personal aggregates as it happens.
- Audit records must NOT retain the erased identifiers; a deletion log full of the emails just
  deleted defeats the deletion.

## Confirmation Criteria

Right if an erasure leaves no row anywhere referencing the user and the username/email become
re-registrable. Reconsider when payment lands: financial records may carry a retention obligation
that outlives an erasure request, so the engine should support "retained with justification" as a
per-table state rather than being rewritten under time pressure.
