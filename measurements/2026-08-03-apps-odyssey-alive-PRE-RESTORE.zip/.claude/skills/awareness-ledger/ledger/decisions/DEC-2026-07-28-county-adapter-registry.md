# DEC-2026-07-28-county-adapter-registry

**Status:** accepted — ARCHITECTURE ONLY. Does not authorize building the feature; see Consequences.
**Tags:** odyssey-apps, meridian, architecture, data-sources, public-records, scraping, playwright, schema
**Related:** DEC-2026-07-22-mls-data-access, DEC-2026-07-22-meridian-scope-dormant-contacts, DEC-2026-07-22-in-house-by-default, PAT-2026-07-28-county-record-extraction-traps

## Context

Francis's county-records proposal (`meridian-workflow-notes.md` § "Francis's proposal — 2026-07-22")
proposed "per-county tooling so a user says 'I'm in this county' and AI scours county sources." The
notes flagged it as untested and warned: "County record systems differ site by site; each is its own
integration and its own breakage."

On 2026-07-28 that warning was tested empirically rather than argued. A full extraction procedure was
run end to end against **Tillamook County's Property Search Online**
(`https://query.co.tillamook.or.us/PSO/`) — address search → account selection → owner, mailing
address, assessment, tax history, sales chain. It works. Two properties were pulled successfully,
including a live multi-account address and Francis's own home.

The open architectural question was the *unit of integration*: is it the county, or something
coarser that would cover many counties at once?

## Decision Drivers

- **The hope was that the unit could be the vendor platform, not the county.** Tillamook runs Helion
  Software's PSO product. If a handful of vendors covered Oregon, one adapter per vendor plus a
  config row per county would collapse the long tail the interview notes warn about.
- **That hope was tested against Clatsop County and failed.** The two counties most likely to matter
  to the practitioner run entirely unrelated systems:

  | | Tillamook | Clatsop |
  |---|---|---|
  | Platform | Helion PSO (vendor) | Bespoke, in-house (`version: 2023_11_5`) |
  | Stack | Blazor Server over SignalR | PHP + jQuery 3.4 + Bootstrap 4 (public CDNs) |
  | Search | GET, URL-addressable | **POST** to `/property/search/`, 302 on failure |
  | Params | `searchOption` + `searchValue` | `street` / `taxid` |
  | Reports | Plain-HTTP PDF endpoints keyed on account ID | Unknown |
  | Address grammar | Substring; street suffix optional | **Strict — three formats rejected** |

  Nothing is shared below the data contract. `800 Exchange St` (Clatsop's own placeholder text),
  `800 EXCHANGE`, and `EXCHANGE` all returned "an address that cannot be found."
- **The variation is not cosmetic.** It is not different HTML around the same idea — it is different
  transport (SignalR circuit vs form POST), different addressability, different query grammar, and
  different available fields.
- **County is a property attribute, not a user attribute.** Rockaway Beach is Tillamook; Astoria is
  Clatsop. A coastal agent may list in both, so the county cannot be a per-account setting.
- **Capability varies by county, not just mechanism.** Tillamook exposes lender of record
  (`CLG - NATIONSTAR MTG LLC DBA MR. COOPER` on a real record) and a sales chain to 1987. Whether
  Clatsop exposes either is unknown.
- County public records remain the legally safe source under DEC-2026-07-22-mls-data-access —
  unaffected by the MLS feed question, which is precisely why this line stayed live at all.

## Options Considered

### Option A: One generic scraper with per-county selectors in config

- Good, because it looks cheapest and keeps all logic in one place.
- Bad, because it is refuted by the evidence: Tillamook needs a live browser driving a SignalR
  circuit, Clatsop needs a form POST. There is no selector-level abstraction over that difference.
- Bad, because a config-driven scraper fails silently when a site changes shape rather than failing
  loudly at a type boundary.

### Option B: One adapter per vendor platform, counties as config rows

- Good, because it would genuinely collapse the tail if vendors were concentrated.
- Bad, because **it was tested and the premise does not hold** for the two counties in play. Clatsop
  is in-house software with no vendor to share.
- Note: not permanently dead. If a later county turns out to run Helion PSO, its adapter should be
  parameterized from Tillamook's rather than written fresh.

### Option C: One adapter per county behind a shared, rigid output contract

- Good, because it matches the observed reality instead of an assumed one.
- Good, because it isolates breakage: when a county redeploys, exactly one adapter fails and its
  contract tests say so.
- Good, because it lets capability differ per county explicitly, as declared flags rather than as
  undefined fields at runtime.
- Bad, because the cost is linear in counties and each adapter is a discovery session plus ongoing
  maintenance.

### Option D: Buy a commercial aggregator (ATTOM, CoreLogic, Regrid, PropMix)

- Good, because someone else owns the long tail and the breakage.
- Good, because coverage is national on day one.
- Bad, because DEC-2026-07-22-in-house-by-default puts the burden of proof on any third party and
  ranks "subscribe" as the last rung of the ladder.
- Bad, because per-record or per-seat pricing on an unvalidated feature spends money before the
  hypothesis is tested at all.
- **Kept as the explicit pressure-release valve:** if the county count ever exceeds what one person
  can maintain, this is the option to revisit rather than grinding out adapter number nine.

## Decision

Chosen option: **Option C — county-scoped adapters behind a shared output contract**, because the
vendor-consolidation premise of Option B was tested against the two counties that actually matter and
did not survive contact.

The county is stored on the **property record**. The county selects the adapter. The adapter is free
to work however that county's site demands — headless browser, form POST, PDF endpoint — and is
obliged only to return the shared contract or fail loudly.

> **"what we need is a setting where when users are working with certain properties that we choose a
> county that the property is in and that county will drive processes like this one to scrape
> information because all counties are gonna be different the websites are gonna be different and
> we're going to have to work on providing processes that are unique to each county."**

*— Captured 2026-07-28, source: Francis, in session, after reviewing the Tillamook extraction.*

## The contract (first draft — every field observed, none invented)

```
identity   county, accountId, rollType, mapTaxlot, legalDescription
addresses  situs, mailing                    ← must stay distinct; see Consequences
parties    owners[] (entity + natural persons), ownershipForm
value      rmv, mav, av, assessmentYear      ← AV is not market value
tax        byTaxAccount[]: {id, codeArea, year, original, due}, lender
sales      [{date, docType, price, grantor, grantee}]
structure  yearBuilt, livableSize, propertyClass, acreage
meta       fetchedAt, sourceUrl, adapterVersion, capabilities[], confidence
```

Drawn from a Tillamook sample. It is a sample of one county and should be expected to move when the
second adapter lands — that movement is the confirmation test below, not a failure.

## Consequences

- **Normalization lives above the adapter, not inside it.** Adapters emit raw county strings; one
  shared layer applies the corrections in PAT-2026-07-28-county-record-extraction-traps. Otherwise
  every adapter re-implements the same traps and gets them wrong in different ways.
- **Capability flags are mandatory.** Each adapter declares what it can supply. The UI degrades per
  county. This makes the feature a `/copy-truth` surface: "owner and lender for any property" becomes
  a false claim the moment a county that lacks lender data is added.
- **`situs` and `mailing` must never be collapsed into one address field.** The gap between them is
  the absentee-owner signal, and it is the one output here that plausibly connects to her stated
  friction (the dormant-contact pool) rather than to an invented one.
- **Each adapter needs contract tests against a known-stable account**, run on a schedule. County
  sites redeploy without notice and will fail silently otherwise. This is `/odyssey-apps test`
  territory and inherits the Regression-Guard Discrimination Gate.
- **A server-side fetcher cannot use bare Node `fetch` for Tillamook.** See the pattern record: the
  TLS chain is incomplete.
- **This record does NOT authorize building the feature.** County tooling remains Francis's
  hypothesis, never put to the practitioner. `meridian-workflow-notes.md` line 675 raises the live
  possibility that MLS already covers the walk-in research task and that county records are redundant
  *for that task*. The gating step is a conversation, staged at
  `odyssey-apps/references/meridian-interview-queue.md`.
- **Build order is blocked on one unanswered question:** which county does she actually list in? Her
  MLS association subdomain is `CLT` (probably Clatsop, per
  DEC-2026-07-22-mls-data-access § Amendment); the property examined is Tillamook. If the answer is
  "both," two adapters are needed on day one and the long-tail risk arrives immediately rather than
  later.

## Confirmation Criteria

Validated when a **second** county adapter (Clatsop is the natural candidate) is written and the
shared contract survives it without structural change — additive capability flags are fine, reshaped
fields are not. If the contract has to be redrawn for county #2, it was over-fitted to a sample of
one and should be re-derived from both counties together.

Reconsider Option D if the maintained county count passes what one person can keep green, or if
adapter breakage becomes a recurring incident rather than an occasional one.

Reconsider the whole line — including this record — if the practitioner's answers establish that MLS
already covers the research task. In that case the correct outcome is to drop the feature, not to
build the adapters more cheaply.
