# DEC-2026-07-22-usage-metering

**Status:** accepted
**Tags:** odyssey-apps, metering, ai, cost, admin, convex, schema, gdpr, pricing
**Related:** DEC-2026-07-22-openrouter-provider, DEC-2026-07-22-hard-delete-erasure, DEC-2026-07-22-manual-grant-vs-subscription

## Context

The modules are AI-backed, so cost scales per call rather than per seat. Before pricing can be set
— and before a subscription tier means anything — Francis needs to know what it actually costs to
serve one user, one module, for one month. Nothing in the ported codebase meters anything; the
source project had no per-call spend at all.

## Decision Drivers

- Pricing intelligence is the whole purpose: *"that way I can adjust the price accordingly,
  especially if the numbers get real high."*
- Development-stage numbers are unknown and will move, so the system must observe rather than
  constrain.
- Usage data is personal data, and this project hard-deletes on erasure
  (DEC-2026-07-22-hard-delete-erasure) — which would destroy the cost history it depends on.

## Options Considered

### Option A: Meter everything through one chokepoint; report, do not enforce

- Good, because a single helper makes metering structural rather than a convention someone forgets.
- Good, because it defers commercial questions (caps, tiers) to when there is data.
- Bad, because it adds a required step to every AI feature forever.

### Option B: Meter and enforce per-user caps now

- Good, because it bounds spend automatically.
- Bad, because the numbers are unknown, so any cap would be a guess that either does nothing or
  breaks a legitimate user.
- Bad, because Francis considers limits a commercial term, not an engineering control.

### Option C: Retrofit metering after the first AI features ship

- Bad, because the first months have no data precisely when pricing is most uncertain.

## Decision

Chosen option: **Option A** — collect, store, display; no caps.

> **"any scripts that we use that interface with AI we have to have the ability for it to track
> tokens and inject that into the database so that I can log into the admin and see that the
> average user is using X amount of tokens a month and that way I can adjust the price
> accordingly especially if the numbers get real high"**

> **"No, I wasn't planning on doing a user cap or anything like that. I mean that would have to be
> part of their agreement if they purchased a slot on the server."**

*— Captured 2026-07-22, source: Francis Meetze, session "site-development"*

## Consequences

- **The chokepoint is enforced, not documented** (AI Metering Chokepoint Gate in
  enforcement-checkpoints.md). A direct provider call is unmetered BY CONSTRUCTION — it does not
  fail, it silently does not count, and the discovery mechanism is a bill.
- **No cap is safe only because grants are manual.** The beta gate IS the spend control: exposure
  is bounded by a number Francis chose by hand. That protection ends when access becomes automatic
  on payment, so metering must be revisited in the same change as the subscription directive
  amendment (DEC-2026-07-22-manual-grant-vs-subscription).
- **Daily rollup grain, not monthly** — because the dashboard has adjustable timeframes and
  monthly buckets cannot answer "last 7 days." Cheap to decide now, a migration later.
- **`usageDailyAnon` exists solely to survive erasure.** Per-user usage rows are deleted on
  erasure, which would retroactively destroy cost history including for months already reviewed.
  The anonymous per-module aggregate carries no `userId`, is therefore not personal data, and is
  written AT CALL TIME because it cannot be reconstructed afterward. It is deliberately exempt
  from the erasure engine and must be commented as such, or a later audit will "fix" it.
- **The dashboard shows distribution, not just the average.** A mean hides the whale: if one power
  user is 60% of spend, the average looks healthy until it isn't. Median, p90, and max ship
  alongside it.
- **Metering is what makes AI features testable.** Generated content cannot be asserted on without
  flake; "a usage row of the right shape was written" is deterministic. The model helper stubs to
  a canned response under `SITE_ENV=development` — the same pattern the port already uses to skip
  SMTP for login codes — so `verify` never burns tokens, and the stub still writes usage rows.

## Confirmation Criteria

Right when Francis can open the admin, pick a module and a window, and read what that module costs
to serve. Reconsider when access stops being granted by hand — at that point the no-cap position
needs re-deciding, not re-confirming. Open: raw-row retention (rollups make `aiUsage` redundant
for reporting after some age).
