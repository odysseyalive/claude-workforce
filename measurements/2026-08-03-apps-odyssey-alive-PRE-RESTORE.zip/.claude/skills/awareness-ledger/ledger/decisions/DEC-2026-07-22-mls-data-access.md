# DEC-2026-07-22-mls-data-access

**Status:** proposed — BLOCKS any feature that reads listing data
**Tags:** odyssey-apps, meridian, legal, compliance, playwright, data-sources, risk
**Related:** DEC-2026-07-22-meridian-scope-dormant-contacts, DEC-2026-07-22-in-house-by-default

## Context

The practitioner's property search runs through her local MLS, daily, as a standing watch — "I just
keep on looking week after week." When listings seem to be missing she asks her principal broker to
check *her* MLS. Francis proposed driving that with Playwright MCP: "we can use Playwright MCP to
log in and create a session, log in, where we can go and get information from that site."

Technically straightforward. The problem is not technical.

## Decision Drivers

- Automated login to an MLS and extraction of its listing data is normally prohibited by the MLS
  participation agreement and the terms the **agent** signs — not by any general law about
  scraping. The restriction is contractual.
- **The exposure lands on her licence and on the boutique brokerage, not on the software.** Loss of
  MLS access would end her ability to work. She is the source of truth for this module and Francis's
  wife; the downside is not an abstract compliance risk.
- She has independently made reputation an absolute — "I don't play with my reputation." A tool
  that put her MLS access at risk would violate the stated value of the person it is built for.
- A sanctioned route exists and is dull: most MLSs grant an authorised data feed (RESO Web API,
  historically RETS) to a brokerage or an approved vendor. It is an application and a signature.
- County public records are a separate and safe source, unaffected by this.

## Options Considered

### Option A: Playwright-driven MLS login and extraction

- Good, because it works immediately and needs no permission from anyone.
- Bad, because it likely breaches the agreement she signed, and she carries the penalty.
- Bad, because it cannot be productised — it is unshippable to any other agent for the same reason.

### Option B: Sanctioned MLS data feed, applied for through the brokerage

- Good, because it is durable, shippable, and puts nobody's licence at risk.
- Good, because approval is paperwork rather than engineering.
- Bad, because it takes time and may be refused to a two-person brokerage or an unapproved vendor.

### Option C: County public records only; no MLS data

- Good, because it is unambiguously safe and needs no permission.
- Bad, because the search criteria she named (location, price, type, beds, baths, view) are MLS
  search fields — county records may not serve this task at all.

## Decision

Chosen option: **Option B, with Option C as the safe fallback. Option A is refused.**

No Meridian feature reads MLS listing data until it is established which MLS she is on and whether
her brokerage can be approved for a feed. County public records remain usable meanwhile.
Playwright-driven access stays fine for sources that permit it; the constraint is specific to the
MLS.

> **"But I know some of them cut corners and take risks that I'm not willing to take, because my
> reputation is on the line. And I don't play with my reputation."**

*— Captured 2026-07-22, source: interview relayed by Francis. Said about competing agents, and it
applies with equal force to software built in her name.*

## Consequences

- Two facts must be gathered before any listing-data work: **which MLS**, and **whether the
  brokerage can obtain a feed**. Both are questions for her, not research tasks.
- The standing-watch feature — carrying six sets of buyer criteria and re-running them against new
  inventory — is blocked on this, and it is the one feature with a clear mechanical payoff.
- The scope in DEC-2026-07-22-meridian-scope-dormant-contacts is deliberately unaffected: the
  dormant-contact list needs no listing data at all, which is a further argument for shipping it
  first.
- Applies to any future real-estate module, SignMe included.

## Amendment — 2026-07-22, the MLS is identified

**`CLT.FLEXMLS.COM`** — a **flexmls** instance, the MLS platform operated by **FBS**. The `CLT`
subdomain is the local association's; given the Pacific Northwest coastal context and her mention
of ocean-view searches, Clatsop County (Oregon) is the likely referent — **confirm with her, do not
assume.**

**VERIFIED 2026-07-22 by web search** (search-result level, not a direct page fetch — the local
browser profile was held by a live instance, so `web_fetch` could not run; re-confirm by reading the
pages directly when convenient):

- **Spark Platform is real and is FBS's developer platform for flexmls.** Documentation lives at
  `https://sparkplatform.com/docs/`.
- **It is the sanctioned route, and it is explicitly member-gated:** "The Spark API allows
  authorized MLS members to request…" — which is exactly the Option B shape, and confirms access is
  granted rather than taken.
- **RESO alignment is a stated objective** — "One of the core objectives for the Spark Platform is
  to help MLS organizations implement the Real Estate Standards Organization (RESO) data
  dictionary." Both a RESO Web API and the older RETS interface are documented, with guidance on
  which to choose.
- **There is a developer on-ramp:** registration at `sparkplatform.com/register/developers` and
  support at `api-support@sparkplatform.com`.
- **flexmls also documents Spark API administration from the MLS side**
  (`flexmls.com/flexmls-academy/…/spark/api-documentation/`), meaning the local association is a
  participant in granting access — consistent with approval being association-level.

**So the route exists and is well documented. What remains is not technical:** establish what the
`CLT` association grants a member brokerage, and whether a two-person firm qualifies. That is a
question for her association, not a research task.

Sources: [Spark API overview](https://sparkplatform.com/docs/overview/api) ·
[API overview / read first](https://sparkplatform.com/docs/api_services/read_first) ·
[RETS overview](https://sparkplatform.com/docs/rets/overview) ·
[flexmls API documentation](https://flexmls.com/flexmls-academy/category/mls-administrators/spark/api-documentation/)

Nothing changes about Option A: browser-driven login to `CLT.FLEXMLS.COM` remains refused.

**Scope correction from the same session:** she clarified that the MLS "is not a communication tool
— unless you're sending listings or CMAs to possible clients." So this record does **not** block
Meridian's first build (the dormant-contact list, which lives entirely in her SMS). It gates the
standing-watch and CMA features only.

## Confirmation Criteria

Resolved when her MLS is named and a feed is either approved or refused. If refused, the
standing-watch feature needs a different mechanism or must be dropped — not quietly implemented
via login automation. Any future session proposing browser-driven MLS access should be sent here
first.
