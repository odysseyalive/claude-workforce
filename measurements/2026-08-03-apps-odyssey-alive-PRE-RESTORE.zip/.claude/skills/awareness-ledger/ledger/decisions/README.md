# decisions

Records of this type live here. Created by `/awareness-ledger record`.
