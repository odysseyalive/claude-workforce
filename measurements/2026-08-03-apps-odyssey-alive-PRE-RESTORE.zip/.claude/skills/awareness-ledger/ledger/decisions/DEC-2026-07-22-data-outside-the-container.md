# DEC-2026-07-22-data-outside-the-container

**Status:** accepted — infrastructure invariant, binds site and every module
**Tags:** odyssey-apps, infrastructure, docker, convex, jstack, backups, permissions, deploy
**Related:** DEC-2026-07-22-one-backup-surface, DEC-2026-07-22-in-house-by-default, DEC-2026-07-22-port-from-nsayka-wawa

## Context

Self-hosted Convex runs as a container behind jstack. The question of where its data physically
lives is not a deployment detail — it determines whether the data survives an ordinary deploy,
whether it can be backed up at all, and whether the backup job can read it.

## Decision Drivers

- A container is **disposable by design**: destroyed and recreated on every image update and config
  change. Data inside it is lost during a ROUTINE SUCCESSFUL DEPLOY — nothing appears to go wrong.
- Backups are only possible if the data is reachable as plain files.
- Modules will store both tables and binaries; they must not each invent their own location.

## Options Considered

### Option A: Host bind mount to an explicit path

- Good, because the path is inspectable, directly copyable, and inside the directory jstack's site
  backup already covers.
- Good, because it survives `docker compose down -v` — bind mounts are not removed by `-v`.
- Bad, because host permissions must be set correctly and are easy to get wrong.

### Option B: Named docker volume

- Good, because it survives container recreation.
- Bad, because it lives in Docker's internal storage: opaque, awkward to back up, invisible to
  jstack's site backup, and **destroyed by `docker compose down -v`**.

### Option C: Container filesystem

- Catastrophic. Data lost on the next image update. Listed only because it is the default if nobody
  decides otherwise.

## Decision

Chosen option: **Option A**, as an invariant covering every service that ever holds data.

> **"The database itself needs to be set up so that it is on the server and not inside the box.
> That way, if something happens to that box, that data is still there and it can also be backed
> up. It also needs the appropriate permissions… we really need to stick to this infrastructure
> where actual data that's being served is outside the box. Regardless of whether it's convex or a
> web server or what."**

*— Captured 2026-07-22, source: Francis Meetze, session "site-development"*

## Consequences

- **The ported compose already does this correctly** — verified 2026-07-22:
  `./data/convex:/convex/data`, and **no named volumes declared at all**. Keep it that way.
- Live resolves to `jstack/sites/apps.odysseyalive.com/data/convex`; dev resolves inside this repo
  (gitignored). Never point both at the same directory.
- **Permissions are part of the change, not a follow-up.** jstack's convention is ownership
  `user:docker-group`, mode `770` (`scripts/core/fix_workspace_permissions.sh`). Wrong ownership
  fails in two confusing ways: the container cannot write, OR the files are root-owned and **the
  backup job silently cannot read them** — a backup that appears to run and captures nothing.
- **One host path holds everything**, because module tables AND stored binaries both live in Convex
  (DEC-2026-07-22-one-backup-surface). One backup, one permissions fix, one restore.
- **CORRECTED A DOCUMENTED ERROR.** The skill inherited the claim that `docker compose down -v`
  wipes the data. It does not: `-v` removes named volumes and there are none, so the bind-mounted
  host directory survives. Wrong in the dangerous direction — someone believing test data was wiped
  when it was not. Fixed in SKILL.md and scaffold-theme.md; wiping means stopping the stack and
  deleting the host directory.
- Extends to any future persistence — caches, queues, search indexes. "It's only a cache" is not an
  exception: a cache you cannot inspect or back up is a cache you cannot debug.

## Confirmation Criteria

Right when the stack can be torn down and recreated with `--force-recreate` and every account,
ticket, and stored document is still present — and when the backup job, running as its own user,
can read the data directory without elevation. Reconsider only on a move to Postgres, where the
principle is unchanged and only the engine differs.
