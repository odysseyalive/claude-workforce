# DEC-2026-07-22-meridian-scope-dormant-contacts

**Status:** proposed — core hypothesis CONFIRMED 2026-07-22; see § Amendment
**Tags:** odyssey-apps, meridian, product-scope, modules.json, privacy, convex, schema
**Related:** DEC-2026-07-22-no-guilt-scoring, DEC-2026-07-22-mls-data-access,
PAT-2026-07-22-machine-narrows-human-judges, DEC-2026-07-22-in-house-by-default

## Context

`modules.json` has carried `meridian.product_scope: OPEN` since the module was named, with an
explicit instruction that `/odyssey-apps module-app meridian` must not invent a product surface.
On 2026-07-22 Francis interviewed his wife — a working solo agent, and the module's designated
source of truth per `meridian.positioning.source_of_truth` — across ~25 questions, one at a time.
The full transcript and observations are in
`odyssey-apps/references/meridian-workflow-notes.md`, which is the evidence base for this record.

The interview produced three confirmed frictions and, more usefully, a large set of **negative**
findings that eliminate most of the obvious builds.

## Decision Drivers

- **Her active pipeline is seven people** — six buyers, one possible seller. Seven fits in a head
  and on paper. No dashboard, database, or CRM earns its place against a notebook at that volume.
- **Her dormant pile is "at least a dozen" and uncountable** — "that number is undetermined,
  because of how far back they are in my text messages or emails that have gone off the radar."
  She cannot enumerate the population she describes as her main loss.
- **Paper is not broken.** Capture is fast, retrieval is "fairly easy", and her filing scheme
  (three notebooks indexed by where she was when she wrote) works. It fails only for dormant
  contacts, where recall needs both the notes and a message scroll she will not perform.
- **She has the data and lacks the follow-through** — "even though I write down their information,
  I have emails from them." The loss happens downstream of capture.
- **Given the list, she knows exactly what to do.** Asked what she would do with it, she answered
  instantly and concretely: call them, ask whether their goals were met and what prevented it.
  No script requested, no hesitation.
- **No enrichment is possible** — "I can't know anything new about them unless I actually talk to
  them in a new conversation."
- **A concrete loss with a date in it:** she did a free market analysis, was told "not going to be
  selling until next summer", and the listing went to another brokerage. A known future
  re-engagement point, said out loud, held by nothing.

## Options Considered

### Option A: Ship the list-reconstruction surface and stop there

- Good, because every element traces to a verbatim answer; nothing is invented.
- Good, because it does the one thing she demonstrably cannot do herself. The work is not hard, it
  is merely unbearable — the best possible profile for a hand-off.
- Good, because it is small, and small is testable inside a beta she has said is how she would
  decide whether to trust it.
- Bad, because it requires reading her correspondence, on which she has given a soft no pending a
  narrower proposal.

### Option B: Build the research/analysis tool (Francis's county-records proposal)

- Good, because the walk-in question genuinely waits "a week or two" and the delay has a real
  commercial cost.
- Bad, because she has never described the research mechanics; three attempts produced intake
  criteria, not lookup steps. Building it would be inventing a surface.
- Bad, because the criteria she named (location, price, type, beds, baths, view) are MLS search
  fields, so county records may be redundant for this task.
- Bad, because it deepens the *expensive* mode of outreach, which she gates behind a judgment she
  has said she cannot make.

### Option C: Build outreach drafting / a drip campaign

- Bad, because she drafted a warm, specific outreach message cold, in one pass, unprompted.
  Writing is not her bottleneck.
- Bad, because the message she wrote contains no property, no market data, and no call to action.
  A listing drip is the opposite artifact.
- Bad, because "I don't play with my reputation" makes anything recognisably machine-generated a
  threat to the one thing she refuses to risk.

### Option D: Build a CRM

- Bad, because she priced one out and declined it on volume and cost, correctly, for seven people.

## Decision

Chosen option: **Option A — reconstruct the dormant-contact list, and stop there.**

The minimal surface, specified end to end from her answers with nothing invented:

1. Read her messages for conversations that touched **real-estate goals** — topic, not
   relationship (see PAT-2026-07-22-machine-narrows-human-judges).
2. Present each as a name, a last-contact date, and **enough of the exchange for her to recognise
   the person**. A content-free version is ruled out: asked whether a name alone would do, she
   said "the conversation, to be sure."
3. She sorts: prospect / friend / ignore.
4. What remains is the list she cannot build herself. She takes it from there.

> **"I need a system where I can make sure that I'm keeping these people thinking about me. And
> it's really sad that I haven't figured that out yet."**

*— Captured 2026-07-22, source: interview relayed by Francis. Her only explicit request in ~25
questions; everything else was description.*

## Consequences

- `meridian.product_scope` moves from OPEN to this scope, with the untested hypothesis named.
- The module's Convex tables (`mer*`) can now be designed: contacts, last-contact date, her
  classification, and provenance. Nothing more — no enrichment fields, no lead scores.
- **Do not build:** capture, note digitisation, notebook search, contact research, background
  enrichment, lead scoring, drip campaigns, bulk sends, or a CRM. Each is separately contradicted
  by her testimony; see the notes file for which answer kills which.
- Reading her correspondence becomes a first-order design question. Work and personal are "all
  mixed together" on one private phone, across SMS, email, and WhatsApp — and some threads are
  "ancient and really hard to search for", so part of the backlog may be unrecoverable.
- Francis's Quo proposal is recorded in the notes file. It addresses the *next* dozen, not this
  one — Quo only sees what passes through Quo — and it is a subscription, which is her stated
  barrier to tools generally.

## Amendment — 2026-07-22, same session

She returned to the one open question and answered it:

> **"Not really — because they're glad I kept in touch. But I think it's been too long for them, and
> they decided to make other plans, to go with another broker."**

**The decoupling hypothesis is confirmed.** Presence outreach does not drag research along; the
cheap mode stays cheap. The decision's foundation holds.

**But the same sentence re-prices the deliverable.** Late outreach earns goodwill, not listings.
Reconstructing the existing dozen will therefore produce warm conversations and few deals — it is a
starting position, not a payday. What the losses have in common is not that she never called; it is
that she called after the decision was made.

**Consequence: the backlog reconstruction is a one-time onboarding pass, not the product.** The
product is what stops the *next* twelve — catching a stated date like "not until next summer"
before it passes. Ship the reconstruction first, because it is what makes the list exist at all,
and do not let it define the module.

This partially rehabilitates Francis's Quo proposal, discounted above for addressing the next dozen
rather than this one. On this answer the next dozen is where the money is, so the two are
complementary rather than ranked. The subscription and behaviour-change objections stand
unchanged.

## Amendment 2 — 2026-07-22, consent granted and scoped

Asked for a *specific* read with a stated purpose rather than open-ended access, she agreed:

> **"I would just do the text messages and maybe email. The others — I've talked to friends and
> other people about real estate, but they're not possible clients."**

**Scope of the permission: SMS yes. Email conditional ("maybe") — confirm before touching it.
WhatsApp excluded.** Her reason for the exclusion is relevance rather than privacy: friends who
discuss real estate but are not prospects.

This removes the blocker in the Confirmation Criteria below, and it vindicates the narrowing: the
earlier "I just don't know how I feel about that" was a response to unbounded access, not to this.
**Build for SMS first.**

One inconsistency is logged in the notes file and must not be resolved by inference: she earlier
described WhatsApp as where the "more intense" exchanges and long videos go, which sounds like
engaged clients rather than friends. If real prospects live there, excluding it drops exactly the
people the list exists to recover. Raise it with her later; the exclusion stands until she changes
it.

## Confirmation Criteria

Right if: shown a reconstructed list, she recognises people she had forgotten, sorts them without
difficulty, and contacts some. Wrong if: the list is mostly noise, she cannot recognise people
from the excerpts, or she recognises them and still does not call — which would mean the blocker
was never the missing list.

Reconsider if she declines the narrowed read of her messages. The scope survives; the mechanism
does not, and would need a route to the list that does not read her correspondence.
