# DEC-2026-07-22-openrouter-provider

**Status:** accepted — implementation details PRELIMINARY (search-derived, unverified)
**Tags:** odyssey-apps, ai, openrouter, metering, architecture, convex, privacy
**Related:** DEC-2026-07-22-usage-metering, DEC-2026-07-22-port-from-nsayka-wawa

## Context

AI features are first-party code running in Convex actions, with no external orchestration
platform (no n8n). The remaining question was which provider interface the code calls, and what
usage shape those calls take.

## Decision Drivers

- One integration reaching many models beats one integration per provider.
- Metering needs authoritative cost, not an estimate maintained in-repo.
- Francis's stated usage shape: scripts performing defined jobs, not a chatbot.

## Options Considered

### Option A: OpenRouter as the single gateway

- Good, because it reports token counts AND actual cost with every response — so this repo
  maintains no price table and metering records an authoritative number.
- Good, because model choice becomes a config decision rather than an integration project.
- Bad, because it adds a dependency in the request path and its own margin on cost.

### Option B: Direct provider SDKs

- Good, because no intermediary.
- Bad, because cost must be computed from a price table maintained here, which drifts silently.
- Bad, because each additional model is another integration.

## Decision

Chosen option: **Option A**, with the usage shape explicitly bounded.

> **"This will most likely be done through open router. So we need to keep in mind that we'll be
> using open router to process any AI results. And so we'll need to capture the data that we get
> from open router as far as, you know, if we reached out and got this information, then we also
> need to collect, okay, how much does this cost us and save it to the database."**

> **"I don't plan on using open router for any chatbot activity. Open router will only be used
> within the scripts that perform whatever function that I give those scripts to do."**

*— Captured 2026-07-22, source: Francis Meetze, session "site-development"*

## Consequences

- **No price table in this repo.** Cost is recorded as reported. The row carries `costSource`
  (`openrouter` / `openrouter-async` / `estimated`) so an unreliable number is visible in a report
  rather than invisible.
- **THE ROUTING TRAP — the highest-value finding here.** With fallback routing, the model that
  ANSWERS may not be the one requested; the response's `model` and `provider` name what actually
  served it. Recording the requested model would misattribute cost silently, producing a per-model
  report that looks entirely plausible and is wrong. Record the response's values; keep
  `modelRequested` alongside, since a growing gap between them signals a flaky primary.
- **Streaming hole exists but does not bite today.** Usage arrives in the final SSE message, so an
  abandoned stream leaves real cost unrecorded — but calls are server-side scripts with complete
  responses. The guard is retained for the day a streaming surface appears.
- **Jobs, not turns.** One user action may fan out into several calls, so every call carries a
  shared `runId`. This makes cost per UNIT OF WORK answerable, and yields the decomposition
  `cost/user/month = cost per run x runs per user per month` — two numbers with completely
  different levers (engineering vs pricing) that an average collapses together.
- **No conversation history is stored.** A deliberate privacy position, not an incidental fact:
  model inputs derive from data the user already gave the module, not an open-ended log. A feature
  wanting history is a new schema decision with its own erasure consequences.
- **`OPENROUTER_API_KEY` lives on the Convex backend environment, never `NEXT_PUBLIC_`.** A
  provider key in client-side JS is a key someone else spends.
- OpenRouter being a gateway does NOT soften the first-party rule: the calls are still our code in
  our repo through our metered helper. It routes to models; it does not orchestrate.

## Confirmation Criteria

**These findings are search-derived and were NOT read from the live docs** (the local browser
profile was locked), so every implementation detail is a lead to confirm, not a fact to build on.
Verify before writing the client: the exact usage/cost response shape, whether OpenRouter's margin
is included in reported cost, whether their Analytics API is a better source for parts of the
dashboard, and BYOK's effect on reported figures. Reconsider the whole choice if the margin proves
material at volume, or if a needed model is unavailable through the gateway.
