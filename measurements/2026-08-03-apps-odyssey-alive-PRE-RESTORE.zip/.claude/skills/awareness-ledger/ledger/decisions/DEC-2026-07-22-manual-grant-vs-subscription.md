# DEC-2026-07-22-manual-grant-vs-subscription

**Status:** accepted — WITH A KNOWN FUTURE CONFLICT
**Tags:** odyssey-apps, entitlements, beta, payment, square, directives, moduleAccess
**Related:** DEC-2026-07-22-hard-delete-erasure, DEC-2026-07-22-port-from-nsayka-wawa

## Context

Module access is admin-granted. Both launch modules carry a public "Request beta access" button
that writes an `accessRequests` row; an admin approves it, and the approval calls `grantAccess`.
The request itself never grants. This is enforced by an immutable directive and by a CHECKPOINT in
`odyssey-apps/references/enforcement-checkpoints.md`.

Separately, the roadmap includes a subscription area where customers pay monthly for a bundle of
modules — and payment will likely be offloaded to Square-hosted checkout.

## Decision Drivers

- Francis's directive that access is conferred manually, full stop.
- The port already ships `accessRequests` declared but deliberately unwired ("Do NOT build the
  self-service UI yet"); this project activates it.
- A paid subscription grants access **automatically on payment**. That is a direct contradiction of
  the manual-grant directive, not a gap to interpret around.

## Options Considered

### Option A: Enforce manual-only now; require a dated directive amendment before any automated grant

- Good, because the directive is honored literally and the conflict is visible rather than latent.
- Good, because a future session cannot quietly "work around" it.
- Bad, because it means subscription work cannot begin without a decision from Francis first.

### Option B: Pre-emptively allow a payment grant path

- Bad, because it contradicts a standing directive on the basis of a feature nobody has specified.

## Decision

Chosen option: **Option A**.

> **"Both these new modules will have a beta button where people can ask to join, but access will
> have to be given manually."**

> **"eventually, I'll have a subscription area where people will be paying a monthly subscription
> for the services that they want, which will be a string of modules"**

*— Captured 2026-07-22, source: Francis Meetze, session "site-development"*

## Consequences

- **NOTHING may write `moduleAccess`** except `grantAccess` / `grantAccessByEmail` invoked by an
  admin, or `decideAccessRequest` on an explicit admin approval. Not a signup, not a seeder, not a
  webhook.
- When subscriptions arrive they need a NEW dated directive amendment naming payment as a second
  sanctioned grant path, and answering: what happens on failed payment, on cancellation, on
  refund, and whether an admin grant outranks a lapsed subscription. **Until that amendment
  exists, a webhook-driven grant is a directive violation.**
- Square-specific finding that will shape the link table: Square's subscription checkout matches
  customers **by phone number**, and site accounts are username + email with no phone. The Square
  customer therefore cannot be correlated to a site account by contact details — `billingLinks`
  must be populated from the checkout/webhook flow with an explicit correlation token.
- Square does **not** support metered/usage-based pricing. Since the modules are AI-backed and AI
  cost scales per call, the supported shape is flat pricing plus internal usage caps. Pricing shape
  and processor are therefore ONE decision, not two.

## Confirmation Criteria

Right if beta access works end to end with every grant traceable to a human. The trigger to revisit
is the first subscription work: if anyone proposes a webhook that grants access, this record and
the directive amendment requirement are the gate it must pass first.
