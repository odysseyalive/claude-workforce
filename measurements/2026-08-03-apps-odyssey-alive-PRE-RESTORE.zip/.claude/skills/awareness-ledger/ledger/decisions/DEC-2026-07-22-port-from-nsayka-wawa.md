# DEC-2026-07-22-port-from-nsayka-wawa

**Status:** accepted
**Tags:** odyssey-apps, scaffold, convex, auth, architecture, port
**Related:** DEC-2026-07-22-private-tickets-only, DEC-2026-07-22-hard-delete-erasure

## Context

apps.odysseyalive.com needed a Next.js + Convex site with accounts, per-user module
entitlements, an admin desk, and a support desk. Two sources existed: `odyssey-alive` (the parent
marketing site, the original design system) and `nsayka-wawa` (the odyssey-skul site, a descendant
of odyssey-alive that had already built accounts, passwordless auth, entitlements, and the admin
desk, and runs them in production).

## Decision Drivers

- Francis's stated requirement that this project share the source's exact layout, login schema,
  and module-access model.
- The auth and entitlement code in nsayka-wawa is debugged in production; re-deriving it would
  re-pay for bugs already fixed (Turbopack content globs, Convex behind nginx, enumeration
  resistance, code-attempt lockout).
- The source is a monorepo whose other half is an Inform 7 game with no analogue here.

## Options Considered

### Option A: Port the site half of nsayka-wawa, strip the game half

- Good, because the login schema, entitlements, admin desk, and support desk arrive working.
- Good, because it matches the stated requirement literally.
- Bad, because it inherits game-shaped assumptions that must be found and removed deliberately.

### Option B: Re-derive from odyssey-alive templates

- Good, because it starts clean with no game baggage.
- Bad, because every backend mechanism would be rebuilt from prose descriptions of it.
- Bad, because it re-treads solved problems.

### Option C: Hybrid — copy the backend, rebuild the frontend

- Good, because the palette break is large (cream/navy to white/blue/gold).
- Bad, because the frontend also carries the debugged auth and admin UI.

## Decision

Chosen option: **Option A**, because the requirement was explicitly that the mechanisms be
identical, and the source's are proven.

> **"This project has the same exact layout as that project, including the login schema how
> modules get applied to users that are created, etc.. The only difference is is that we aren't
> using the gaming code."**

*— Captured 2026-07-22, source: Francis Meetze, session "site-development" (ratified via
AskUserQuestion: "Copy from nsayka-wawa, strip game")*

## Consequences

- The strip list is load-bearing and enumerated in `odyssey-apps/references/port-inventory.md` § B.
  A half-stripped table fails `convex deploy` loudly, which is the intended signal.
- The default posture toward ported code is **"this is solved, prove it works here"** — NOT "this
  is a fresh build." Flagging inherited mechanisms as risk is a category error; the genuinely new
  surfaces are the beta flow, the module apps, and AI cost.
- Two source documents had DRIFTED from the source code and cannot be trusted over the files:
  odyssey-skul's prose described a schema that differed from its own `schema.ts` in three places.
  Always derive from the source FILE.

## Confirmation Criteria

Right if `pnpm verify` goes green on the ported tree with auth, admin, and support working without
being rebuilt. Reconsider if the strip turns out to touch more of the shared spine than expected —
if removing the game requires rewriting auth or the admin desk, the hybrid option was correct.
