# DEC-2026-07-22-in-house-by-default

**Status:** accepted — binding on the site AND every module
**Tags:** odyssey-apps, architecture, self-hosting, dependencies, cost, observability, gdpr
**Related:** DEC-2026-07-22-openrouter-provider, DEC-2026-07-22-one-backup-surface, DEC-2026-07-22-usage-metering

## Context

Designing observability surfaced the question directly: an external error service (Sentry) is the
conventional answer, and it is a subscription plus a data processor. That forced the general
question the project had been answering ad hoc — when is a third-party service acceptable at all?

## Decision Drivers

- Maintenance burden falls entirely on one person.
- Subscription costs compound and are hard to predict as the catalog grows.
- A third party can change terms, raise prices, or break — and take the site with them.
- Anything holding user data is a processor: privacy-policy entry, likely a DPA, and beyond the
  reach of an erasure system that otherwise works properly.

## Options Considered

### Option A: In-house by default, with a burden of proof on any third party

- Good, because costs stay predictable and the dependency surface stays small.
- Good, because user data stays inside the erasure and backup boundaries that already work.
- Bad, because some capability is genuinely unavailable in-house, so it cannot be absolute.

### Option B: Best-tool-for-the-job, accept subscriptions

- Good, because it is faster to build and the tools are usually better.
- Bad, because it compounds cost and fragility across a growing catalog, and each service holding
  user data adds permanent administrative weight.

## Decision

Chosen option: **Option A** — a DEFAULT WITH A BURDEN OF PROOF, not an absolute ban.

> **"I would much rather keep everything in-house as much as possible because it's easier to
> maintain and it also keeps costs relatively stable as opposed to adding in a bunch of
> third-party services that I'm going to have to pay subscriptions for and worry if someone's
> gonna break it. So make sure that's part of the directive throughout all of the module building
> and the website."**

*— Captured 2026-07-22, source: Francis Meetze, session "site-development"*

## Consequences

- **A preference LADDER, in order: don't need it → build it into what we already run → self-host a
  service → subscribe.** Self-hosting is THIRD, not first. This is the non-obvious part: running
  another container moves cost from a subscription to patching, backups, restore drills, and being
  woken at 2am. "Run our own X" is less in-house than "don't need X."
- **Three questions any new dependency must answer:** is it structurally unavailable in-house? what
  breaks if it disappears or reprices? does it hold user data? Enforced by the In-House Default
  Gate in enforcement-checkpoints.md.
- **If a third party still wins, isolate it behind an interface we control**, so replacing it later
  is a swap rather than a rewrite.
- **First application — observability.** Sentry cloud rejected as a subscription and a processor.
  A self-hosted GlitchTip ALSO rejected, because both stated reasons (maintenance, stable cost)
  argue against another container too. What ships: the Convex `errorLog` plus invariant checks —
  built into what already runs. The honest residual gap is that nothing inside a dead box can
  report it died, covered by a cheap external heartbeat against `/api/health`.
- **The directive is written with its own counter-pressure**, deliberately: self-hosting does not
  remove cost, it moves it. A directive that pretends otherwise gets violated the first time it is
  inconvenient.
- **Audited baseline of existing third parties, each with its stated reason:** OpenRouter (model
  inference cannot be in-house; a gateway REDUCES lock-in by keeping models swappable behind one
  integration), Cloudflare Turnstile (free, and named in an inherited directive), SMTP (Francis's
  own infrastructure), Mailchimp (the one genuine subscription — flagged as the most plausible
  candidate to bring in-house later, since the SMTP path already exists), Square (card processing
  is PCI-bound), GitHub (the git remote IS the code backup).

## Confirmation Criteria

Right if the monthly service bill stays roughly flat as modules are added, and no outage is ever
caused by a vendor the project does not control. Reconsider a SPECIFIC case — never the directive
— when an in-house gap demonstrably costs more in time than the subscription would in money. That
is a data-driven exception, and it should be recorded as one.
