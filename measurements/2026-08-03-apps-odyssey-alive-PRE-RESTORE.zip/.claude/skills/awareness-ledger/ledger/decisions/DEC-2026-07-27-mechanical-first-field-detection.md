# DEC-2026-07-27-mechanical-first-field-detection

**Status:** accepted
**Tags:** odyssey-apps, sign-me, ai, privacy, architecture, product-scope, evidence
**Related:** DEC-2026-07-27-erase-document-keep-hash, DEC-2026-07-27-signme-stands-alone, DEC-2026-07-22-openrouter-provider, DEC-2026-07-22-in-house-by-default, PAT-2026-07-22-machine-narrows-human-judges

## Context

`sign-me` had no product thesis. `product_scope` read "a DocuSign clone is a large surface and the
beta ships one slice of it," with the slice undecided, and research had established that the
vertical alone is not a differentiator — DocuSign already sells Rooms into real estate
(research-log.md § 7.6).

On 2026-07-27 Francis supplied the thesis, then immediately refined its architecture. Both
statements are recorded because the refinement is the load-bearing part.

**The thesis:**

> **"I'm going to use AI to scan the documents and automatically create the check boxes and
> signature bucket so all the agent has to do is upload their document and AI will prepare it for
> signature."**

**The refinement, the same session, after the assistant raised the privacy and evidence
consequences:**

> **"In all honesty, though I think that we could create a script with AI that can be smart enough
> to build those boxes mechanically than using a cheap model to do a sweep of the document as the
> last step just to make sure everything looks right and filling in the gaps."**

*— Captured 2026-07-27, source: Francis Meetze, session "docusign-clone"*

## Decision Drivers

- Field placement is plausibly the tedious part of preparing an envelope — a differentiator that
  is about work rather than price.
- Sending client documents to a model provider creates a subprocessor relationship reaching data
  we hold as processor for the agent (research-log.md § 7.4).
- **Attribution under UETA § 9 turns on explaining how a signature came to be placed on a
  document** (research-log.md § 9). A model in that chain is a non-replayable step.
- `PAT-2026-07-22-machine-narrows-human-judges` already governs: automate the classification a rule
  can be stated for; never the judgment.
- Cost per run, under `usage-metering.md`'s cost-per-run framing.

## Options Considered

### Option A: Model-first — send the document, let it place the fields

- Good, because it is the least code and handles novel layouts immediately.
- Bad, because every document leaves our infrastructure, including scanned ones.
- Bad, because placement becomes non-deterministic and unreplayable — directly weakening the
  "could only have happened this way" narrative that Ruiz and Espejo require.
- Bad, because per-run cost scales with document length forever.

### Option B: Mechanical-first, cheap model as a final verification sweep

- Good, because the deterministic pass is **replayable** — same bytes, same field map — which is
  an attestable property in the Ruiz/Espejo sense.
- Good, because far less content leaves, and for cached forms possibly none.
- Good, because per-run cost collapses and decays further as the template cache fills.
- Bad, because it is materially more code: PDF parsing, anchor matching, geometry, a fingerprint
  cache, and a separate OCR path for scanned documents.
- Bad, because novel layouts degrade to whatever the sweep catches.

### Option C: Mechanical only, no model

- Good, because nothing leaves at all.
- Bad, because novel and scanned layouts fail with no recovery, and "upload and it's ready" is the
  entire promise.

## Decision

Chosen option: **Option B.**

The three advantages are on independent axes — cost, privacy, and evidence — and **the evidentiary
one is decisive**. A deterministic placement pass can be re-run and attested to; a model cannot
promise that. The cheap design and the defensible design turn out to be the same design, which is
rare and should not be traded away later for a simpler pipeline or a one-click demo.

## Consequences

- **The model may PROPOSE and FLAG. It may never silently move or delete what the mechanical pass
  produced** — that would place a non-deterministic edit beneath the deterministic layer and
  forfeit the evidentiary advantage. Its output is a diff the agent accepts.
- **NEVER AUTO-SEND.** The agent confirms placement, always. This is
  `PAT-2026-07-22-machine-narrows-human-judges` applied exactly, and it is the rule that keeps the
  whole feature defensible. Do not trade it for a smoother demo.
- **Preparation is an audit event**: what the mechanical pass found, what the sweep proposed, and
  what the agent reviewed, changed, and approved. This converts the AI step from a liability into
  another attested link in the chain — see `DEC-2026-07-27-erase-document-keep-hash` and
  research-log.md § 9.6.
- **The provider path is decided in the Amendment below** (2026-07-27) — direct Anthropic API
  rather than OpenRouter, for this feature. The zero-retention and subprocessor consequences live
  there.
- **The subprocessor is disclosed regardless of which provider is used.** Zero-retention reduces
  exposure; it does not remove the subprocessor. Privacy page names it; the DPA lists it.
- **The model call goes through the ONE metered helper** (`usage-metering.md`, enforced not
  advisory), from a Convex action on the Node runtime per `$architecture.ai_approach`. That helper
  is the provider seam — which is also what `DEC-2026-07-22-in-house-by-default` means by
  "isolate behind an interface we control." No plugin, no second runtime.
- **A template fingerprint cache is part of the design, not an optimization.** Real-estate forms
  repeat, so cache field maps keyed to an exact layout fingerprint. Model usage decays toward zero
  as the catalog fills. Two hard constraints: the key must be an exact layout fingerprint (a
  revised form with shifted fields is a different document, and a stale map is now an evidentiary
  error), and the cache stores **field geometry only, never document content**.
- **Scanned PDFs are a second path from day one**, not a later patch — OCR (Tesseract, in-house per
  `DEC-2026-07-22-in-house-by-default`) introduces positional error that lands directly on field
  placement.
- **Copy describes what it DOES, never what it guarantees.** "Prepares your document for signature,
  ready for your review." See `modules.json` `sign-me.copy_constraints`.

## Confirmation Criteria

Right if: the mechanical pass handles the majority of real forms unaided; re-running it on the same
document yields an identical field map (this should be a test, not an assumption); and the cache
hit rate climbs as usage grows.

**The open question this decision does NOT settle, and it is the important one:** whether field
placement is the friction the working agent actually experiences. It is a reasonable inference, not
testimony, and `meridian.positioning.source_of_truth` distinguishes those sharply — Meridian's
scope was narrowed hard by exactly this check. Ask her what preparing a document for signature
actually costs her today; the answer may be the placement, the chasing, or something neither
Francis nor the assistant has guessed. Reconsider the whole thesis if it is not the placement.

Reconsider the architecture if novel-layout quality proves unacceptable without a model-first pass,
or if OCR error rates on real scanned documents make the mechanical path unreliable for them.

---

## Amendment — 2026-07-27: the verification sweep calls the Anthropic API directly

Recorded the same day as the parent decision, after Francis raised it:

> **"if Heiku 4.5 is adequate enough to do that, I could easily just build a plugin for that model
> that would interface my Claude account."**

*— Captured 2026-07-27, source: Francis Meetze, session "docusign-clone"*

**Decision: the sweep calls the Anthropic API directly (`claude-haiku-4-5`), NOT OpenRouter.** This
is scoped to `sign-me`'s field-detection sweep; `DEC-2026-07-22-openrouter-provider` still governs
everywhere else, and this record does not supersede it.

### One clarification that had to be made first

"Interface my Claude account" resolves two ways, and only one works:

- **The Anthropic API** (API key, pay-per-token) — the correct path for a commercial product. This
  is what was decided.
- **A Claude.ai Pro/Max subscription** — a personal subscription for using Claude through the
  Claude interface, not a backend for a product we sell. Not viable, and noted here so it is not
  revisited as a cost-saving idea later.

### Why direct wins here specifically

1. **It removes a subprocessor** — the decisive reason. The path would otherwise be
   agent → us → OpenRouter → model provider. Going direct cuts one party out of a chain carrying
   the agent's CLIENTS' documents. Under research-log.md § 7.4 we are the processor and the agent
   is the controller, so every added party is a privacy-page entry, a DPA line, and a place GDPR
   erasure cannot reach. `DEC-2026-07-22-in-house-by-default` question 3 asks exactly this.
2. **Org-level zero-retention configuration** is a stronger guarantee than per-request routing
   flags — it is a property of the account rather than something a forgotten parameter can bypass.
   Contrast research-log.md § 10.1, where OpenRouter's per-request `zdr` is additive-only precisely
   because request-level controls are easy to miss.
3. **Lock-in barely applies to this task.** A mechanical verification sweep is narrow and
   well-specified; any competent small model does it. Model swappability matters for open-ended
   generation, not for "look at this and flag what is missing" — and the metered helper keeps the
   provider swappable anyway.

### The honest cost of going direct

`DEC-2026-07-22-openrouter-provider` chose OpenRouter partly because it **reports actual cost with
every response, so this repo maintains no price table**. Direct means `usage-metering.md` now needs
a maintained price entry — `claude-haiku-4-5` is **$1.00 / $5.00 per million tokens** (in/out),
200K context, 64K max output, as of 2026-07-27. Small, but it is a number that goes stale silently,
so it belongs in one place with a checked date rather than scattered through the metering code.

### An enforcement win worth recording

**Haiku 4.5 supports strict structured outputs.** The sweep can therefore be constrained to a JSON
schema at the API level — it *must* return a machine-readable diff of proposed field additions and
cannot return prose. That turns the parent decision's "the model may PROPOSE and FLAG, never
silently edit" from a prompt instruction we hope holds into a request-level constraint. Build it
that way.

### Consequences specific to this amendment

- Metering records the model **and** its price basis; `DEC-2026-07-22-openrouter-provider`'s
  "record the model that ANSWERED" is satisfied trivially here (one provider, one model), but the
  recorded value must still identify the pinned model rather than a category.
- Confirm the org's data-retention configuration before the first document is sent, and re-confirm
  it as a launch checklist item — it is account state, not code, so nothing in the repo will catch
  a change to it.
- The privacy page and DPA name **Anthropic** as the subprocessor for this feature.
- If the sweep ever expands beyond field detection into open-ended generation, revisit — the
  lock-in argument in (3) above stops applying the moment model choice starts mattering.
