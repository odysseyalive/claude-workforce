# DEC-2026-07-22-private-tickets-only

**Status:** accepted
**Tags:** odyssey-apps, support, forum, privacy, convex, schema
**Related:** DEC-2026-07-22-port-from-nsayka-wawa, DEC-2026-07-22-hard-delete-erasure

## Context

The ported support system is a **public-reading forum**: anyone may read `/support/<slug>`
threads, active users may post, and a versioned forum-rules document forces re-agreement whenever
it changes. That model suited a family-oriented game community. This site's users are licensed
real-estate professionals.

## Decision Drivers

- A support thread about a problem is routinely a thread about a **live transaction with a real
  client in it**.
- Agents have professional confidentiality obligations; an affordance that invites public posting
  works against them regardless of what the rules copy says.
- The forum carries substantial machinery: `forumRules`, `forumRuleAcceptances`, the
  `forumEnabled` flag and gate, forum components, a `/forum-rules` route, and a whole skill mode.

## Options Considered

### Option A: Private tickets only

- Good, because it removes an affordance that invites professional self-harm.
- Good, because it deletes a large amount of ported code and one skill mode.
- Bad, because it forgoes community-building around the tools.

### Option B: Keep the public forum as ported

- Good, because the code already works and community has value.
- Bad, because it invites users to disclose client details in public.

### Option C: Keep the forum, private by default with public opt-in

- Bad, because it is the most code and the most ways to get visibility wrong.

## Decision

Chosen option: **Option A**, ratified via AskUserQuestion.

> **"Private tickets only."**

*— Captured 2026-07-22, source: Francis Meetze, session "site-development"*

## Consequences

- Stripped: `convex/forumRules.ts`, the forum tables, `forumEnabled` + `moduleForumEnabled`,
  `src/components/forum/`, `/forum-rules`, `tests/forum-rules`, and the `/odyssey-apps
  forum-rules` mode.
- **NOT stripped, despite looking forum-shaped:** `convex/profanity.ts` and `src/lib/censor.ts`.
  `containsBadWord` guards USERNAMES at signup and account edit (`loginCode.ts:212`,
  `authCodes.ts:134`, `account.ts:106`). Removing it would have silently disabled username
  validation with nothing failing. This was caught only by grepping actual usage.
- This decision **cascaded** into erasure: the reason the port anonymizes tickets instead of
  deleting them was to protect a public conversation. See DEC-2026-07-22-hard-delete-erasure.
- Privacy is now enforced in the query layer and must be TESTED, not assumed: a second signed-in
  user and a logged-out visitor must both be denied on someone else's ticket.

## Confirmation Criteria

Right if support volume is manageable and no user ever posts client details somewhere public.
Reconsider if a genuine community forms and asks for a shared space — at which point it should be
a deliberate new surface, not a revival of the game's forum.
