# DEC-2026-07-27-erase-document-keep-hash

**Status:** proposed
**Tags:** odyssey-apps, sign-me, gdpr, privacy, convex, schema, erasure, e-signature
**Related:** DEC-2026-07-22-hard-delete-erasure, DEC-2026-07-22-one-backup-surface, DEC-2026-07-22-data-outside-the-container, DEC-2026-07-27-signme-stands-alone

## Context

Two accepted decisions collide on `sign-me`, and the collision was flagged but not resolved when
each was recorded:

- **DEC-2026-07-22-hard-delete-erasure** commits the site to hard-deleting every row referencing a
  user on erasure, explicitly rejecting the port's anonymize-in-place behavior. Its own
  Confirmation Criteria anticipated this exact problem: *"Reconsider when payment lands: financial
  records may carry a retention obligation that outlives an erasure request, so the engine should
  support 'retained with justification' as a per-table state."*
- **DEC-2026-07-22-one-backup-surface** puts every binary in Convex file storage, which means
  erasure reaches uploaded documents automatically — recorded at the time as a benefit, with the
  note that *"for sign-me this collides with evidentiary retention."*

`modules.json` `sign-me.convex._note` states the requirement plainly: a signed agreement that must
outlive its uploader's erasure request needs a *"retained with justification"* state in the erasure
engine **before this module ships**. Nobody had proposed what that state actually contains.

On 2026-07-27 Francis directed a discovery read of DocuSign's own legal documents:

> **"I am interested in understanding the legal processes but focused on the actual presentation
> retention of documents and specific legal illegalities of providing the service."**

*— Captured 2026-07-27, source: Francis Meetze, session "docusign-clone"*

The full teardown, with citations, is `odyssey-apps/references/research-log.md` § 7. This record
captures the one architectural idea that came out of it.

## Decision Drivers

- The erasure engine cannot ship with an unresolved exception; a per-table "retained" flag with no
  defined contents is a hole, not a design.
- An e-signature product with no durable evidence of what was signed has no product.
- An e-signature product that cannot honor erasure is not GDPR-compliant, which the site's
  inherited directives require.
- **The market leader has already solved this**, and its solution is visible in its own terms —
  cheaper to read than to derive.

## Options Considered

### Option A: Erase the document, keep a hashed attestation

DocuSign separates two artifacts. The **eDocument** is content the customer purges at will. The
**audit trail / Transaction Data** is defined in its eSignature Service Schedule as transaction
history, sender and recipient names and emails, signature IDs, method and time of envelope
deletion — and an **image hash value**. On purge, DocuSign optionally retains the audit log:

> **"we provide an option to retain the audit log data (which includes the Certificate of
> Completion and history) to support our ability to attest to the details of a transaction.
> Customers view this behavior as a valuable feature that allows Docusign to be a neutral
> record."**

*— Docusign, "Data management and privacy practices," last updated 2026-04-14, fetched 2026-07-27*

Applied here: the signed PDF lives in Convex file storage and is fully reachable by hard-delete
erasure. The audit trail retains a hash of the signed artifact plus event metadata — enough to
attest **that** a document was signed, by whom, when, and that a given file is or is not the one
signed. No document content is retained.

- Good, because the retained thing is an *attestation*, not a *record* — a fingerprint of
  something that no longer exists.
- Good, because it gives the "retained with justification" state a concrete, testable shape.
- Good, because the hash is what makes the attestation worth anything: it proves integrity without
  storing content.
- Bad, because **signer names and emails also live in the audit trail**, and the hash does nothing
  for those. This is the unresolved part.

### Option B: Retain signed documents outright, exempt from erasure

- Good, because it is the strongest evidentiary position.
- Bad, because it directly contradicts DEC-2026-07-22-hard-delete-erasure and makes the site's
  erasure promise conditional in a way the privacy page would have to disclose.

### Option C: Erase everything, retain nothing

- Good, because it is the simplest and the most defensible on privacy grounds.
- Bad, because an e-signature tool that erases its own evidence on request is arguably not fit for
  purpose — the evidence's whole value is that a party cannot make it disappear.

## Decision

Chosen option: **Option A**, at status `proposed`.

Proposed rather than accepted deliberately: this is an assistant-derived reading of DocuSign's
architecture, not a verified legal conclusion, and neither Francis nor a lawyer has ruled on it.
It resolves the *storage* half of the collision cleanly and leaves the *identity* half open.

## Consequences

- **Two artifacts, not one, from the first schema line.** The document (Convex file storage,
  erasable) and the attestation (a row, retained) are separate tables with separate lifecycles.
  Designing them as one record and splitting later is the expensive path.
- **The hash is a first-class field**, computed at signing time, not derivable afterward — once
  the document is erased there is nothing left to hash.
- **The erasure engine gains a real "retained with justification" state**, which
  DEC-2026-07-22-hard-delete-erasure's Confirmation Criteria already predicted it would need.
  Note the trap that record names: the engine iterates a declared table list, so the attestation
  table must be registered as *retained* rather than simply omitted — an unregistered table is
  indistinguishable from a forgotten one.
- **The privacy page must disclose it.** An erasure that leaves an attestation behind is not the
  plain meaning of erasure, and the page cannot imply otherwise.
- **This makes Odyssey Alive a data CONTROLLER for the attestation slice.** For documents, the
  agent is controller and we are processor (research-log.md § 7.4). But retaining an attestation
  for our own evidentiary purposes is our decision, not the agent's instruction — which is
  precisely the dual role DocuSign discloses for its own transactional data.
- **Do not carry this to other modules.** Meridian and future modules have no evidentiary claim;
  hard-delete remains unqualified everywhere else.

## Confirmation Criteria

This becomes `accepted` when **both** of the following resolve:

1. **Legal review** of whether an attestation row naming a signer survives that signer's erasure
   request — and if not, whether the row can be reduced to a hash of the identity alongside the
   hash of the document, or whether the attestation must go too. This is the question the hash
   does not answer and must not be allowed to look like it does.
2. **ESIGN/UETA primary text** read on what an electronic record must contain and for how long —
   currently unread, and listed as such in research-log.md § 7. DocuSign explicitly disclaims
   determining retention periods (Service Schedule § 2(d)), so its behavior is evidence of
   industry practice and nothing more.

Reconsider immediately if legal review says the attestation cannot name a signer at all — that
would not merely amend this record, it would reopen whether `sign-me` can offer a durable
evidentiary guarantee, which is a product question rather than a schema one.

---

## Amendment — 2026-07-27: the hash was the easy part

Recorded the same day as the parent decision, after the discovery moved from **reading** DocuSign's
legal documents to **operating** a live DocuSign account end to end — upload, place fields, send,
sign, complete — and retrieving an actual **Certificate of Completion**.

The parent record was derived entirely from prose: the eSignature Service Schedule and the data
management page, which describe the audit trail in the abstract as "transaction history … and an
image hash value." That description is accurate and it is not sufficient. The certificate itself is
now in hand, and its contents change what the open question is.

### What the artifact actually contains

Field-by-field teardown in `odyssey-apps/references/research-log.md` § 12.3; the sender surface is
§ 11 and the signing side is § 12. The parts that bear on this record, per signer:

> `Signer Events` · name · email · `Security Level` · ID-check method · `Signature Adoption: <method>`
> · `Using IP Address: <addr>` · `Sent:` / `Viewed:` / `Signed:` timestamps
> `Electronic Record and Signature Disclosure: Accepted: <timestamp> · ID: <uuid>`

*— Certificate of Completion, retrieved 2026-07-27 from a live account with the account holder's
permission. Structure only; no party data recorded here or in the research log.*

Plus, for the originator: name, email, and IP address. Plus the envelope's configuration recorded
as attested fact, and the full recipient-role taxonomy printed even where empty.

### Why this sharpens rather than answers

**The hash was the easy part.** Retaining an image hash raises no meaningful privacy question — a
fingerprint of erased content is not personal data in any troublesome sense, and the parent record
was right that it gives the attestation its integrity value.

The parent record also posed the real question correctly, but abstractly: *"signer names and emails
also live in the audit trail, and the hash does nothing for those."* That is now concrete, and worse
than stated. The attestation row does not merely **name** a signer — it **locates** them. Name,
email, and IP address are three items of personal data under GDPR, and the IP address is the most
sensitive of the three.

**The tension, stated plainly: the fields that give the row its evidentiary value are exactly the
fields that make it personal data.** IP address is not incidental metadata that could be dropped for
tidiness — it is the UETA § 9 attribution evidence, the recorded "efficacy of the security procedure
applied," and `research-log.md` § 9's case law turns on precisely this class of evidence. Strip it
to satisfy erasure and the row may no longer attest to the thing that made it worth retaining.

This raises the stakes rather than lowering them. The lawyer question can no longer be deferred by
imagining the retained row is substantially anonymous. It is not.

### Status — unchanged

**Still `proposed`.** The amendment makes the open question sharper, not answered. Nothing here
ratifies Option A; it establishes what Option A would actually be retaining.

### Confirmation Criteria — revised

These **supersede the parent record's two criteria, newest-wins.** The parent's text stands
unedited above as the record of what was asked before the artifact was in hand.

This becomes `accepted` when **all three** resolve:

1. **Legal review** of whether an attestation row containing signer **name, email, and IP address**
   survives that signer's erasure request. If it does not, the review must also establish *which
   subset may be retained* — and whether what remains still attests to anything useful, rather than
   becoming a row that satisfies the auditor and convinces nobody.
2. **Whether a pseudonymised variant preserves enough attribution value to be worth retaining at
   all** — hash of email rather than email; truncated or dropped IP. This is not a free mitigation:
   § 9's case law turns on exactly the evidence being pseudonymised, so the honest answer may be
   that a pseudonymised attestation is not worth the storage.
3. **ESIGN § 7001(d) and UETA § 12 primary text** on what a retained record must *contain* — which
   bounds how much can be stripped before the thing stops being a record at all. This replaces the
   parent's broader "read ESIGN/UETA" criterion with the two specific provisions that govern
   retention rather than validity.

The parent record's reopening clause still stands and is now more likely to fire: if legal review
says the attestation cannot name a signer at all, that reopens whether `sign-me` can offer a durable
evidentiary guarantee — a product question, not a schema one.

### Consequences already written elsewhere

Recorded so they are not re-derived, and so a change here propagates to known places:

- `odyssey-apps/references/schema.md` § F — the retention open question, rewritten with this
  sharpened version; and § E.6, which now flags that the `sign*` table decisions are **legal, not
  technical**.
- `odyssey-apps/references/sign-me-build-plan.md` § 4 (proposed-not-settled) and § 7 — the
  `signEvents` design note: *do not design its erasure behaviour without the legal answer*.
- `odyssey-apps/references/modules.json` → `sign-me.legal_surface` finding (7).
- `odyssey-apps/references/research-log.md` § 12.3 — the field-by-field source for all of it.
