# DEC-2026-07-27-signme-stands-alone

**Status:** accepted
**Tags:** odyssey-apps, sign-me, product-scope, positioning, pricing
**Related:** DEC-2026-07-22-manual-grant-vs-subscription, DEC-2026-07-27-erase-document-keep-hash

## Context

`modules.json` has carried an open question on `sign-me` since 2026-07-22, recorded verbatim as:
*"OPEN — must sign-me stand alone for someone who never buys Meridian? Affects both the pricing
story and how much of its own state it needs to own."*

It blocked more than it looked like it did. Until it was answered, `sign-me` could not be given a
tagline, an intro page, a pricing position, or a schema — because each of those changes shape
depending on whether the reader is assumed to already own Meridian. The registry's own
`role_in_the_catalog` states that `sign-me` is *"a SPOKE on meridian, not a sibling"*, which reads
as an answer but is not one: being a spoke describes how the modules relate, not whether one can
be bought without the other.

The question surfaced again while scoping the module on 2026-07-27 and was put to Francis directly.

## Decision Drivers

- **It gates the intro page.** A page written for someone who owns Meridian and a page written for
  a stranger are different pages, and `/copy-truth` cannot evaluate either until we know which.
- **It gates the schema.** Whether `sign-me` owns its own parties/recipients or reads Meridian's
  contacts is a table-level decision that is expensive to reverse after data exists.
- **It gates the beta audience.** A Meridian-dependent module can only be granted to people who
  already have Meridian access — a materially smaller and slower beta.
- **The catalog thesis pushes toward standalone.** `$site_thesis.future_direction` describes a
  future plan picker where customers "pay monthly for the string of modules they want." A module
  that cannot be picked alone is not really a line item in that picker.
- **Counter-pressure, recorded honestly:** standalone means duplicating some of what the hub
  already holds, and duplication between a hub and its spoke is the classic source of two
  divergent sources of truth.

## Options Considered

### Option A: Standalone — sells on its own

- Good, because the beta audience is everyone, not a subset of Meridian's beta.
- Good, because it fits the future plan picker without special-casing.
- Good, because it de-risks Meridian: if Meridian's scope keeps moving (its own scope record is
  still `proposed`), `sign-me` is not held hostage to it.
- Bad, because `sign-me` must own parties/recipients that partly duplicate Meridian's contacts.
- Bad, because it eventually forces a reconciliation between the two when the integration lands.

### Option B: Meridian-bound spoke

- Good, because it is the cheapest to build — borrow parties and deals from the hub, own only
  signing state.
- Good, because there is exactly one source of truth for a contact.
- Bad, because the beta ships to a smaller audience and the intro page must say "you also need
  Meridian," which is a conversion tax on an unproven product.
- Bad, because it couples two modules whose scopes are both still open.

### Option C: Standalone now, hub-aware later

- Effectively Option A with the reconciliation named up front rather than discovered.

## Decision

Chosen option: **Option A — standalone**, with Option C's honesty about the debt.

> **"Yes — sells on its own"**

*— Captured 2026-07-27, source: Francis Meetze, session "docusign-clone". Recorded precisely:
this was a selection from options presented by the assistant, not Francis's own prose. The
consequences below were drafted by the assistant from that selection and are the part most worth
re-confirming.*

## Consequences

- **`sign-me` owns its own parties/recipients and its own document grouping.** It may not read
  Meridian's tables. Its tables stay `sign*`-prefixed per the registry's existing rule.
- **Duplication with the hub is accepted deliberately**, not treated as a defect to be designed
  away. Anyone who later "fixes" it by pointing `sign-me` at Meridian's contacts is reversing this
  decision, not tidying.
- **It needs its own pricing story** and an intro page whose argument never assumes the reader has
  heard of Meridian.
- **The Meridian integration becomes a SEAM, not a dependency.** A signature request may originate
  from a Meridian deal; it must also originate from nothing at all. `role_in_the_catalog` still
  stands — `sign-me` is a spoke that also stands up alone.
- **The parties/contacts reconciliation is accepted debt. Do not pre-build it.** Building the
  bridge before either module's scope is closed guarantees building the wrong bridge.
- **The copy bar rises.** A wider beta means the intro page is read cold by strangers with no
  context and no charity — the condition the 2026-07-22 directive amendment already warned about
  for public launch.
- **The signing surface is reachable without a `moduleAccess` grant** — see
  DEC-2026-07-27-erase-document-keep-hash and research-log.md § 7.3. The signer is the agent's
  client, not a subscriber. This is a consequence of the product, not of standalone-ness, but it
  lands here because standalone widens who encounters it first.

## Confirmation Criteria

Right if `sign-me` can be granted, opened, and used end-to-end by an account with no Meridian
access, and if its intro page reads coherently to someone who has never seen the hub.

Reconsider if the working-agent interview (still not conducted for `sign-me` — see
`modules.json` `sign-me.product_scope`) shows that signing work is inseparable from deal work in
practice, such that a standalone signing tool has no job to do on its own. That finding would not
reopen hub/spoke positioning; it would reopen whether standalone is *sellable*, which is a
different question from whether it is *buildable*.
