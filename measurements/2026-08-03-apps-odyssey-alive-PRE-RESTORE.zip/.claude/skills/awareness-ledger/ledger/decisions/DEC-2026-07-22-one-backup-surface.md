# DEC-2026-07-22-one-backup-surface

**Status:** accepted
**Tags:** odyssey-apps, backups, convex, storage, architecture, gdpr, sign-me, deploy
**Related:** DEC-2026-07-22-hard-delete-erasure, DEC-2026-07-22-usage-metering, DEC-2026-07-22-port-from-nsayka-wawa

## Context

Self-hosted Convex bind-mounts its data to the host. The site will accumulate data that cannot be
rebuilt — accounts, tickets, beta requests, usage/cost history — and modules will accumulate
user-supplied binaries, `sign-me` most obviously (uploaded and signed documents). The question was
where those binaries live, and what a single backup has to cover.

jstack already provides backup tooling, but its site backup is a file-level `tar` of a directory
whose database is running.

## Decision Drivers

- A backup must cover *everything*, in one operation, with one restore path.
- Usage/cost history is unreconstructable; documents are irreplaceable to the user.
- Francis is a solo operator — two backup systems means one of them rots.

## Options Considered

### Option A: All binaries in Convex file storage; one logical export, zipped daily, rotated

- Good, because one backup surface covers rows and files together.
- Good, because GDPR erasure reaches the files automatically instead of orphaning them on disk.
- Good, because the repo stays code-only — no committed binaries, no Git LFS.
- Bad, because backups grow with document volume; retention becomes a disk budget.

### Option B: Files on the host filesystem, backed up separately

- Good, because backups of rows stay small.
- Bad, because it fails ASYMMETRICALLY: the database restores cleanly, the documents do not, and
  the gap is discovered when someone asks for a signed agreement.
- Bad, because erasure must reach a second system, which it will eventually fail to do.

### Option C: Files committed to the repo

- Bad on every axis. Rejected without discussion; contradicts deploy.md § No large binaries.

## Decision

Chosen option: **Option A**.

> **"We want to save the documents that are uploaded to the convex database itself so that when we
> back up the database we're backing up everything and we're not in loss of anything. We're not
> having to back up files or commit files to your repository."**

> **"I would like some kind of a cron job backup process where there is a zip file created each day
> that backs up the complete convex database. And then it needs to be rotated so that I don't run
> out of memory."**

*— Captured 2026-07-22, source: Francis Meetze, session "site-development"*

## Consequences

- **Binds every module, not just sign-me.** Recorded in `modules.json` `$architecture.binary_storage`
  so a future module cannot quietly write to disk.
- **Convex FILE STORAGE, not a `v.bytes()` document field.** Documents have a size ceiling; a
  multi-megabyte PDF in a field fails at upload, in front of a user.
- **Deleting a row that references a stored file must delete the file.** Otherwise bytes survive
  with nothing pointing at them — a compliance hole and an invisible disk leak.
- **jstack's file-level site tar is NOT the database backup.** It copies a live database mid-write
  and fails silently at restore. The daily job takes a logical export and writes it INTO the site
  directory, so jstack's existing tar, cron, remote copy, and GPG encryption carry it for free.
  Cron order: export first, then tar.
- **THE HIGHEST-RISK UNKNOWN: does the Convex export include file storage by default, or does it
  need a flag?** If it needs one and the job omits it, the backup runs green nightly, the zip has a
  plausible size, and every document is missing — discovered only at restore. Verify against the
  installed version before scheduling anything.
- **Retention is now a disk budget**, since each full snapshot re-copies every document. Seven
  dailies is seven copies of every PDF. Escape hatch if it bites: shorter daily retention, or a
  deduplicating snapshot tool (restic/borg store identical blobs once across snapshots).
- **Rotation runs AFTER a successful export, never before** — otherwise a failing export silently
  reduces recovery depth by one every night.
- **Sharpens rather than solves the sign-me retention question.** Erasure now reaches signed
  documents, which is correct for GDPR and possibly wrong for evidentiary retention. The erasure
  engine needs a "retained with justification" per-table state before that module ships.

## Confirmation Criteria

Right when a restore into a scratch environment produces a working site WITH its documents intact,
and the recovery time is recorded. Reconsider when document volume makes full daily snapshots
expensive — that is a scale trigger for changing the snapshot mechanism, never for splitting the
storage surface.
