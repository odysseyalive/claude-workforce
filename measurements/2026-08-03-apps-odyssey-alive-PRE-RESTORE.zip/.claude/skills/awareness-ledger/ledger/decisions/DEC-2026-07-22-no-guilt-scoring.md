# DEC-2026-07-22-no-guilt-scoring

**Status:** accepted
**Tags:** odyssey-apps, meridian, ux, copy, frontend-design, product-scope
**Related:** DEC-2026-07-22-meridian-scope-dormant-contacts, PAT-2026-07-22-machine-narrows-human-judges

## Context

Meridian's scope (DEC-2026-07-22-meridian-scope-dormant-contacts) centres on contacts that went
quiet. The obvious interface for that is the one every follow-up tool ships: overdue counters, red
badges, days-since-contact, a compliance streak. The practitioner's own words rule it out.

Across the interview she described the same failure in three registers — "it's really sad", "I'm
in a funk", "I know it's a failure on my part", "none of my contacts know that I have left them on
the side of the road to die", "asking them if they still remembered me". She already supplies the
guilt in full measure.

## Decision Drivers

- She stated the constraint herself, unprompted, before being asked anything about it.
- A surface that opens with how many people she has neglected would describe her worst feeling
  about herself back to her every morning. She would stop opening it.
- Her capacity genuinely fluctuates — "whatever lands on my plate during the day", "I don't want to
  get too overwhelmed", "my life is so full". A tool that only works on a good week fails on
  precisely the weeks that produced every loss she described.

## Options Considered

### Option A: Standard follow-up UX — overdue counts, staleness badges, compliance metrics

- Good, because it is conventional, cheap, and users recognise it.
- Bad, because the source of truth has explicitly refused it.
- Bad, because it measures the wrong party: her compliance rather than the contact's experience.

### Option B: Accountability measured on the CONTACT's side, never hers

- Good, because it is what she actually asked for.
- Good, because it keeps the surface usable on a bad week, which is when it matters.
- Bad, because "how many did you miss" is a much easier number to compute and display, so the
  temptation to add it will recur in every future design session. Hence this record.

## Decision

Chosen option: **Option B.** Meridian never displays a count, badge, streak, or score of missed,
overdue, or neglected follow-ups. It makes the next action easy without keeping score of the ones
that did not happen.

> **"I know I need more accountability, but I don't want to be made to feel like I'm not doing
> enough, because my life is so full. I just need a system that's going to work for what I want to
> do. And to make sure that none of my contacts know that I have left them on the side of the road
> to die."**

*— Captured 2026-07-22, source: interview relayed by Francis, volunteered before the question was
asked.*

Note the resolution of the apparent contradiction, which is hers and not an interpretation: the
accountability she wants is **to the contact** — nobody feels dropped — not to a scoreboard.
Success is measured on the recipient's side.

## Consequences

- No overdue counters, no red badges, no "you haven't contacted X in N days" as a headline, no
  streaks, no completion percentages, no weekly digest of failures.
- Last-contact dates may still be *shown as facts* on a contact — she needs them to recognise
  people — but never aggregated into a judgment or coloured as a warning.
- The zero state and the bad-week state are first-class design cases, not afterthoughts.
- Binds `/frontend-design`, `/copy-truth`, and any `/odyssey-apps module-app meridian` work.
- Generalises beyond Meridian: this is a catalogue-wide stance on tools for solo operators, whose
  defining condition is that nobody else is coming to help.

## Confirmation Criteria

Right if she opens it on a bad week. Wrong if she stops opening it — which is the exact failure
this record exists to prevent, and which will look like disengagement rather than a design fault
unless someone remembers why the constraint was set. Reconsider only if she asks for a metric by
name, in her own words, unprompted.
