# DEC-2026-07-22-graphic-system-imagery

**Status:** accepted (supersedes the kickoff imagery directive)
**Tags:** odyssey-apps, design, imagery, brand, art, palette
**Related:** DEC-2026-07-22-port-from-nsayka-wawa

## Context

The kickoff directive specified photographic imagery, breaking from the watercolour illustration
used by odyssey-alive and odyssey-skul. Three things then changed the calculus: all imagery must be
AI-generated; site-level imagery must be vertical-neutral because the catalog will grow past real
estate; and the site's own pitch became "AI you can trust."

## Decision Drivers

- On a site arguing its AI is trustworthy, a visibly broken generated image is **evidence against
  the argument**. Faces, hands, and architecture are where generation fails.
- The audience looks at properties professionally and will notice impossible interiors that a
  general audience would miss.
- Vertical-neutral photography of "work" is the most clichéd genre in stock imagery — every
  competitor has the laptop-and-coffee shot.
- A drawn system accommodates a future legal or medical module; a photo library does not.

## Options Considered

### Option A: Graphic system from the surveying vocabulary

- Good, because there is nothing for a model to render wrong — no uncanny valley.
- Good, because it is distinctive rather than stock, and vertical-neutral by nature.
- Good, because the naming already supplies the language (Meridian, plat, bearing, benchmark).
- Bad, because it demands a coherent system rather than a set of assets.

### Option B: Photorealistic (the original direction)

- Good, because it reads serious and grounded.
- Bad, because vertical-neutral office photography is undifferentiable and carries generation risk.

### Option C: Typographic, no pictorial imagery

- Good, because zero generation risk and fastest to build.
- Bad, because it rests entirely on typography being superb, and there is no product to screenshot.

### Option D: Hybrid — graphic at site level, photographic on module pages

- Bad, because two visual languages on one site is a real design problem, not a detail.

## Decision

Chosen option: **Option A**.

> **"I'm trying to decide whether we should have real images or if we should do some kind of
> art."** … *(selecting the graphic system)*

*— Captured 2026-07-22, source: Francis Meetze, session "site-development". Supersedes the same
day's kickoff directive "Instead of the artistic images, create real-life images."*

## Consequences

- **SVG first, generation second.** Generated line-work DRIFTS between assets — stroke weights and
  tick spacing differ every run — and a system is recognisable because its measurements repeat.
  SVG also recolours from palette tokens, so a hex change restyles everything with no regeneration.
- The `/image` retheme (a build prerequisite) is now to this system, not photography, and its scope
  shrinks to textural fields only.
- Motion becomes available in a way photography never allowed: a route drawing itself, a mark
  settling into position. Framer Motion is already in the stack.
- Each module earns a mark in one glyph family — an identity system that scales with the catalog.
- New test target: gold hairlines actually rendering at mobile width. A 1px gold line on white can
  vanish on a low-DPI screen — fine in review, broken in production.

## Confirmation Criteria

Right if the site looks like one designed system rather than a folder of assets, and no visitor
can point at an image and say "that was AI-generated." Reconsider once modules exist: product
screenshots should displace decorative imagery on module pages, so do not over-invest in a
decorative library a screenshot will retire.
