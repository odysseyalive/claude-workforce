# Awareness Ledger Index

*Auto-generated. Last updated: 2026-07-28*

Consult with `/awareness-ledger consult [topic]`; record with `/awareness-ledger record [type]`.

> **Read first if you are new to this project — four records carry most of the load:**
> `DEC-2026-07-22-in-house-by-default` (work the dependency ladder before proposing anything),
> `DEC-2026-07-22-data-outside-the-container` (where persisted data may and may not live),
> `PAT-2026-07-22-port-description-drift` (grep call sites; never trust a ported label), and
> `DEC-2026-07-22-manual-grant-vs-subscription` (a live directive conflict awaiting an amendment).
>
> **Building Meridian? Read these four first:** `DEC-2026-07-22-meridian-scope-dormant-contacts`
> (what the module is, derived from the working agent's own testimony — and the long list of things
> her answers rule out), `DEC-2026-07-22-no-guilt-scoring` (never show her a count of what she
> missed), `PAT-2026-07-22-machine-narrows-human-judges` (automate the topic filter, never the
> judgment), and `DEC-2026-07-22-mls-data-access` (no listing data until the feed question is
> answered). The evidence base for all four is
> `odyssey-apps/references/meridian-workflow-notes.md`.
>
> **Touching county records / property research?** Add
> `DEC-2026-07-28-county-adapter-registry` (one adapter per county behind a shared contract — the
> vendor-consolidation shortcut was tested against Clatsop and failed) and
> `PAT-2026-07-28-county-record-extraction-traps` (nine ways these sites return plausible-but-wrong
> data without erroring). **Read the decision's Consequences before writing any code: it is
> architecture only and does NOT authorize building the feature.** The gating questions are staged at
> `odyssey-apps/references/meridian-interview-queue.md` — Batch A, and A3 in particular, can end this
> line entirely.
>
> **Building SignMe? Read these three first:** `DEC-2026-07-27-mechanical-first-field-detection`
> (the product thesis — a deterministic script places the fields and a cheap model only sweeps;
> read it for WHY replayability is an evidentiary property and not merely a cheaper one),
> `DEC-2026-07-27-signme-stands-alone` (it sells on its own, so it owns its own state and its own
> pricing story — and the duplication with Meridian is deliberate, not a defect to design away),
> and `DEC-2026-07-27-erase-document-keep-hash` (how a signed agreement's evidentiary weight
> coexists with hard-delete erasure — still `proposed`, and **read its 2026-07-27 Amendment before
> its original Confirmation Criteria**: retrieving a real Certificate of Completion showed the
> retained attestation carries signer name, email, AND IP address, so the fields that give the row
> its evidentiary value are exactly the fields that make it personal data).
>
> The evidence base is `odyssey-apps/references/research-log.md` §§ 7–12: DocuSign's own legal
> surface, what an e-signature system must BE under ESIGN/UETA, the three primary case-law opinions
> on repudiated signatures (§ 9 is the most directly buildable research in the file), the
> zero-retention posture and provider choice, and — §§ 11–12 — a hands-on review of a live DocuSign
> account: the sender surface, the signing side, and the Certificate of Completion field by field.
> **Start instead at `odyssey-apps/references/sign-me-build-plan.md`**, which consolidates all of it
> into settled/proposed/open, a v1 slice, a `sign*` data-model sketch, and a phased plan whose
> Phase 3 is an explicit go/no-go on the module's premise.
>
> **`sign-me` still has no workflow grounding** — the Meridian interview never touched paperwork, so
> every feature named so far is an inference, not testimony. The build plan's Phase 1 exists to fix
> that, and it blocks UI scope (though not the engine work).

## By Tag

### odyssey-apps
- DEC-2026-07-22-data-outside-the-container — Data lives on the HOST via explicit bind mount, never inside the container or a named volume; permissions are part of the change (accepted)
- DEC-2026-07-22-graphic-system-imagery — Imagery is a drawn graphic system from surveying vocabulary, SVG-first — superseding the photographic direction (accepted)
- DEC-2026-07-22-hard-delete-erasure — GDPR erasure hard-deletes every row incl. tickets, diverging from the port's anonymize-in-place; admin entry point required (accepted)
- DEC-2026-07-22-in-house-by-default — In-house by default with a burden of proof on any third party; ladder = don't need it > build into what we run > self-host > subscribe (accepted)
- DEC-2026-07-22-manual-grant-vs-subscription — moduleAccess is written only by an admin grant; a future subscription needs a directive amendment before any automated grant (accepted)
- DEC-2026-07-22-one-backup-surface — Every binary lives in Convex file storage; one daily logical export, zipped and rotated — never a file-level tar of a live DB (accepted)
- DEC-2026-07-22-openrouter-provider — OpenRouter is the AI gateway, used by server-side scripts (never a chatbot); record the model that ANSWERED, not the one requested (accepted)
- DEC-2026-07-22-port-from-nsayka-wawa — Port the site half of nsayka-wawa and strip the game half, rather than re-deriving from odyssey-alive (accepted)
- DEC-2026-07-22-private-tickets-only — Support is private tickets only; the ported public forum and its rules/re-agreement machinery are stripped (accepted)
- DEC-2026-07-22-usage-metering — Token/cost metering through one enforced chokepoint; report only, no caps; daily rollups + a GDPR-safe anonymous aggregate (accepted)
- PAT-2026-07-22-port-description-drift — A ported component's description and its actual usage diverge in BOTH directions — verify by grepping call sites, never by reading the label (active)
- DEC-2026-07-22-meridian-scope-dormant-contacts — Meridian reconstructs the dormant-contact list she cannot build herself, and stops there; capture/research/drafting/CRM all ruled out by her testimony (proposed)
- DEC-2026-07-22-no-guilt-scoring — Never display a count, badge, or streak of missed follow-ups; accountability is to the contact, not to a scoreboard (accepted)
- DEC-2026-07-22-mls-data-access — No MLS listing data until a sanctioned feed is established; Playwright-driven MLS login is refused because her licence carries the penalty (proposed)
- PAT-2026-07-22-machine-narrows-human-judges — Automate the classification she can state a rule for (topic); never the ones she says have no rule (seriousness, fit, worth) (active)
- DEC-2026-07-27-signme-stands-alone — SignMe sells on its own to someone who never buys Meridian; it owns its own parties/documents and the hub duplication is accepted debt (accepted)
- DEC-2026-07-27-erase-document-keep-hash — Erase the signed document, retain a hashed attestation; gives the "retained with justification" erasure state a concrete shape. Amended 2026-07-27: the attestation's real field list is now known (proposed)
- DEC-2026-07-27-mechanical-first-field-detection — SignMe's product thesis: mechanical field placement with a cheap-model verification sweep; replayability is an evidentiary property (accepted)
- DEC-2026-07-28-county-adapter-registry — One adapter per county behind a shared output contract; the vendor-platform shortcut was tested against Clatsop and refuted. Architecture only — does not authorize the build (accepted)
- PAT-2026-07-28-county-record-extraction-traps — County record sites return plausible-but-wrong data rather than erroring; normalize above the adapter layer (active)

### sign-me
- DEC-2026-07-27-signme-stands-alone — SignMe sells on its own; own parties/documents, own pricing story, Meridian integration is a seam not a dependency (accepted)
- DEC-2026-07-27-erase-document-keep-hash — Erase the document, keep a hash + event metadata; the hash was the easy part — the attestation names AND locates the signer (name, email, IP), which is the unresolved half (proposed)
- DEC-2026-07-27-mechanical-first-field-detection — Deterministic script places the signature/checkbox fields; a cheap ZDR model only sweeps and proposes. Never auto-send (accepted)

### meridian
- DEC-2026-07-22-meridian-scope-dormant-contacts — Meridian reconstructs the dormant-contact list she cannot build herself, and stops there; capture/research/drafting/CRM all ruled out by her testimony (proposed)
- DEC-2026-07-22-no-guilt-scoring — Never display a count, badge, or streak of missed follow-ups; accountability is to the contact, not to a scoreboard (accepted)
- DEC-2026-07-22-mls-data-access — No MLS listing data until a sanctioned feed is established; Playwright-driven MLS login is refused because her licence carries the penalty (proposed)
- PAT-2026-07-22-machine-narrows-human-judges — Automate the classification she can state a rule for (topic); never the ones she says have no rule (seriousness, fit, worth) (active)
- DEC-2026-07-28-county-adapter-registry — County is a property attribute and selects the extraction adapter; blocked on which county she actually lists in (accepted)
- PAT-2026-07-28-county-record-extraction-traps — $0 trust transfers, truncated owner lists, personal-property account collisions, AV≠market — all silent failures (active)

### public-records
- DEC-2026-07-28-county-adapter-registry — One adapter per county, shared rigid output contract, capability flags per county; commercial aggregators kept as the pressure-release valve (accepted)
- PAT-2026-07-28-county-record-extraction-traps — Nine observed traps against Tillamook PSO; traps 1–5 are data-shape and generalize, 6–9 are mechanism and do not (active)
- DEC-2026-07-22-mls-data-access — County public records are the SAFE source; the contractual restriction is specific to MLS listing data (proposed)

### playwright
- DEC-2026-07-22-mls-data-access — Playwright-driven MLS login is refused; Playwright stays fine for sources that permit it (proposed)
- DEC-2026-07-28-county-adapter-registry — Tillamook's search is a Blazor SignalR circuit, so the adapter needs a real browser; its PDF reports do not (accepted)
- PAT-2026-07-28-county-record-extraction-traps — An expanded "View all N Names" modal intercepts pointer events on every other tab until closed (active)

### product-scope
- DEC-2026-07-22-meridian-scope-dormant-contacts — Meridian reconstructs the dormant-contact list she cannot build herself, and stops there (proposed)
- DEC-2026-07-22-no-guilt-scoring — Never display a count, badge, or streak of missed follow-ups (accepted)
- PAT-2026-07-22-machine-narrows-human-judges — Automate the topic filter; hand back the judgment (active)
- DEC-2026-07-27-signme-stands-alone — SignMe sells on its own; standalone closes the open standalone_question from 2026-07-22 (accepted)

### convex
- DEC-2026-07-22-data-outside-the-container — Data lives on the HOST via explicit bind mount, never inside the container or a named volume; permissions are part of the change (accepted)
- DEC-2026-07-22-hard-delete-erasure — GDPR erasure hard-deletes every row incl. tickets, diverging from the port's anonymize-in-place; admin entry point required (accepted)
- DEC-2026-07-22-one-backup-surface — Every binary lives in Convex file storage; one daily logical export, zipped and rotated — never a file-level tar of a live DB (accepted)
- DEC-2026-07-22-openrouter-provider — OpenRouter is the AI gateway, used by server-side scripts (never a chatbot); record the model that ANSWERED, not the one requested (accepted)
- DEC-2026-07-22-port-from-nsayka-wawa — Port the site half of nsayka-wawa and strip the game half, rather than re-deriving from odyssey-alive (accepted)
- DEC-2026-07-22-private-tickets-only — Support is private tickets only; the ported public forum and its rules/re-agreement machinery are stripped (accepted)
- DEC-2026-07-22-usage-metering — Token/cost metering through one enforced chokepoint; report only, no caps; daily rollups + a GDPR-safe anonymous aggregate (accepted)
- DEC-2026-07-27-erase-document-keep-hash — Document and attestation are SEPARATE tables with separate lifecycles; the hash is computed at signing time, not derivable later (proposed)

### architecture
- DEC-2026-07-22-in-house-by-default — In-house by default with a burden of proof on any third party; ladder = don't need it > build into what we run > self-host > subscribe (accepted)
- DEC-2026-07-22-one-backup-surface — Every binary lives in Convex file storage; one daily logical export, zipped and rotated — never a file-level tar of a live DB (accepted)
- DEC-2026-07-22-openrouter-provider — OpenRouter is the AI gateway, used by server-side scripts (never a chatbot); record the model that ANSWERED, not the one requested (accepted)
- DEC-2026-07-22-port-from-nsayka-wawa — Port the site half of nsayka-wawa and strip the game half, rather than re-deriving from odyssey-alive (accepted)
- DEC-2026-07-28-county-adapter-registry — Per-county adapters behind one contract; normalization lives above the adapter, not inside it (accepted)

### gdpr
- DEC-2026-07-22-hard-delete-erasure — GDPR erasure hard-deletes every row incl. tickets, diverging from the port's anonymize-in-place; admin entry point required (accepted)
- DEC-2026-07-22-in-house-by-default — In-house by default with a burden of proof on any third party; ladder = don't need it > build into what we run > self-host > subscribe (accepted)
- DEC-2026-07-22-one-backup-surface — Every binary lives in Convex file storage; one daily logical export, zipped and rotated — never a file-level tar of a live DB (accepted)
- DEC-2026-07-22-usage-metering — Token/cost metering through one enforced chokepoint; report only, no caps; daily rollups + a GDPR-safe anonymous aggregate (accepted)
- DEC-2026-07-27-erase-document-keep-hash — Erasure reaches the signed document; a hashed attestation is retained, which the privacy page must disclose — and it contains personal data, not just a hash (proposed)

### privacy
- DEC-2026-07-22-hard-delete-erasure — GDPR erasure hard-deletes every row incl. tickets, diverging from the port's anonymize-in-place; admin entry point required (accepted)
- DEC-2026-07-22-openrouter-provider — OpenRouter is the AI gateway, used by server-side scripts (never a chatbot); record the model that ANSWERED, not the one requested (accepted)
- DEC-2026-07-22-private-tickets-only — Support is private tickets only; the ported public forum and its rules/re-agreement machinery are stripped (accepted)
- DEC-2026-07-27-erase-document-keep-hash — Odyssey Alive is PROCESSOR for documents (the agent is controller) but CONTROLLER for the retained attestation (proposed)

### schema
- DEC-2026-07-22-hard-delete-erasure — GDPR erasure hard-deletes every row incl. tickets, diverging from the port's anonymize-in-place; admin entry point required (accepted)
- DEC-2026-07-22-private-tickets-only — Support is private tickets only; the ported public forum and its rules/re-agreement machinery are stripped (accepted)
- DEC-2026-07-22-usage-metering — Token/cost metering through one enforced chokepoint; report only, no caps; daily rollups + a GDPR-safe anonymous aggregate (accepted)
- DEC-2026-07-27-erase-document-keep-hash — The attestation table registers as RETAINED in the erasure engine's declared table list, never simply omitted; do not design `signEvents` erasure behaviour before the legal answer (proposed)
- DEC-2026-07-28-county-adapter-registry — County lives on the PROPERTY record, never on the user account; `situs` and `mailing` must never collapse into one address field (accepted)

### admin
- DEC-2026-07-22-hard-delete-erasure — GDPR erasure hard-deletes every row incl. tickets, diverging from the port's anonymize-in-place; admin entry point required (accepted)
- DEC-2026-07-22-usage-metering — Token/cost metering through one enforced chokepoint; report only, no caps; daily rollups + a GDPR-safe anonymous aggregate (accepted)

### ai
- DEC-2026-07-22-openrouter-provider — OpenRouter is the AI gateway, used by server-side scripts (never a chatbot); record the model that ANSWERED, not the one requested (accepted)
- DEC-2026-07-22-usage-metering — Token/cost metering through one enforced chokepoint; report only, no caps; daily rollups + a GDPR-safe anonymous aggregate (accepted)
- PAT-2026-07-22-machine-narrows-human-judges — Automate the classification she can state a rule for (topic); never the ones she says have no rule (seriousness, fit, worth) (active)
- DEC-2026-07-27-mechanical-first-field-detection — The model proposes and flags; it never silently edits what the deterministic pass produced, and the agent always confirms (accepted)

### backups
- DEC-2026-07-22-data-outside-the-container — Data lives on the HOST via explicit bind mount, never inside the container or a named volume; permissions are part of the change (accepted)
- DEC-2026-07-22-one-backup-surface — Every binary lives in Convex file storage; one daily logical export, zipped and rotated — never a file-level tar of a live DB (accepted)

### cost
- DEC-2026-07-22-in-house-by-default — In-house by default with a burden of proof on any third party; ladder = don't need it > build into what we run > self-host > subscribe (accepted)
- DEC-2026-07-22-usage-metering — Token/cost metering through one enforced chokepoint; report only, no caps; daily rollups + a GDPR-safe anonymous aggregate (accepted)

### deploy
- DEC-2026-07-22-data-outside-the-container — Data lives on the HOST via explicit bind mount, never inside the container or a named volume; permissions are part of the change (accepted)
- DEC-2026-07-22-one-backup-surface — Every binary lives in Convex file storage; one daily logical export, zipped and rotated — never a file-level tar of a live DB (accepted)

### metering
- DEC-2026-07-22-openrouter-provider — OpenRouter is the AI gateway, used by server-side scripts (never a chatbot); record the model that ANSWERED, not the one requested (accepted)
- DEC-2026-07-22-usage-metering — Token/cost metering through one enforced chokepoint; report only, no caps; daily rollups + a GDPR-safe anonymous aggregate (accepted)

### port
- DEC-2026-07-22-port-from-nsayka-wawa — Port the site half of nsayka-wawa and strip the game half, rather than re-deriving from odyssey-alive (accepted)
- PAT-2026-07-22-port-description-drift — A ported component's description and its actual usage diverge in BOTH directions — verify by grepping call sites, never by reading the label (active)

*Single-record tags omitted from the grouped view; every tag is still searchable in the record files.*

## By Status

### Active

- DEC-2026-07-22-data-outside-the-container — Data lives on the HOST via explicit bind mount, never inside the container or a named volume; permissions are part of the change [odyssey-apps, infrastructure, docker, convex]
- DEC-2026-07-22-graphic-system-imagery — Imagery is a drawn graphic system from surveying vocabulary, SVG-first — superseding the photographic direction [odyssey-apps, design, imagery, brand]
- DEC-2026-07-22-hard-delete-erasure — GDPR erasure hard-deletes every row incl. tickets, diverging from the port's anonymize-in-place; admin entry point required [odyssey-apps, gdpr, privacy, convex]
- DEC-2026-07-22-in-house-by-default — In-house by default with a burden of proof on any third party; ladder = don't need it > build into what we run > self-host > subscribe [odyssey-apps, architecture, self-hosting, dependencies]
- DEC-2026-07-22-manual-grant-vs-subscription — moduleAccess is written only by an admin grant; a future subscription needs a directive amendment before any automated grant [odyssey-apps, entitlements, beta, payment]
- DEC-2026-07-22-one-backup-surface — Every binary lives in Convex file storage; one daily logical export, zipped and rotated — never a file-level tar of a live DB [odyssey-apps, backups, convex, storage]
- DEC-2026-07-22-openrouter-provider — OpenRouter is the AI gateway, used by server-side scripts (never a chatbot); record the model that ANSWERED, not the one requested [odyssey-apps, ai, openrouter, metering]
- DEC-2026-07-22-port-from-nsayka-wawa — Port the site half of nsayka-wawa and strip the game half, rather than re-deriving from odyssey-alive [odyssey-apps, scaffold, convex, auth]
- DEC-2026-07-22-private-tickets-only — Support is private tickets only; the ported public forum and its rules/re-agreement machinery are stripped [odyssey-apps, support, forum, privacy]
- DEC-2026-07-22-usage-metering — Token/cost metering through one enforced chokepoint; report only, no caps; daily rollups + a GDPR-safe anonymous aggregate [odyssey-apps, metering, ai, cost]
- PAT-2026-07-22-port-description-drift — A ported component's description and its actual usage diverge in BOTH directions — verify by grepping call sites, never by reading the label [odyssey-apps, port, nsayka-wawa, skills]
- DEC-2026-07-22-no-guilt-scoring — Never display a count, badge, or streak of missed follow-ups; accountability is to the contact, not to a scoreboard [odyssey-apps, meridian, ux, copy]
- PAT-2026-07-22-machine-narrows-human-judges — Automate the classification she can state a rule for (topic); never the ones she says have no rule (seriousness, fit, worth) [odyssey-apps, meridian, ai, product-scope]
- DEC-2026-07-27-signme-stands-alone — SignMe sells on its own to someone who never buys Meridian; it owns its own parties/documents and the hub duplication is accepted debt [odyssey-apps, sign-me, product-scope, positioning, pricing]
- DEC-2026-07-27-mechanical-first-field-detection — Mechanical field placement primary, cheap ZDR model as verification sweep only; never auto-send, preparation is an audit event [odyssey-apps, sign-me, ai, privacy, architecture, evidence]
- DEC-2026-07-28-county-adapter-registry — One adapter per county behind a shared output contract; vendor-platform consolidation tested against Clatsop and refuted. ARCHITECTURE ONLY — does not authorize the build [odyssey-apps, meridian, architecture, data-sources, public-records, scraping, playwright, schema]
- PAT-2026-07-28-county-record-extraction-traps — County record sites fail by returning plausible-but-wrong data, not by erroring; nine observed traps, normalization belongs above the adapter [odyssey-apps, meridian, public-records, scraping, playwright, data-quality, tillamook]

### Proposed

- DEC-2026-07-22-meridian-scope-dormant-contacts — Meridian reconstructs the dormant-contact list she cannot build herself, and stops there; one hypothesis still untested [odyssey-apps, meridian, product-scope, privacy]
- DEC-2026-07-22-mls-data-access — No MLS listing data until a sanctioned feed is established; Playwright-driven MLS login refused because her licence carries the penalty [odyssey-apps, meridian, legal, risk]
- DEC-2026-07-27-erase-document-keep-hash — Erase the signed document, retain a hashed attestation; AMENDED 2026-07-27 after reading a real Certificate of Completion — the retained row carries signer name, email and IP, so the open half is now sharply posed, not merely named [odyssey-apps, sign-me, gdpr, privacy, convex, schema, erasure, e-signature]

### Resolved

*(none)*

### Under Review

*(none)*

## Relationship Map

- DEC-2026-07-22-data-outside-the-container → related to DEC-2026-07-22-one-backup-surface, DEC-2026-07-22-in-house-by-default, DEC-2026-07-22-port-from-nsayka-wawa
- DEC-2026-07-22-graphic-system-imagery → related to DEC-2026-07-22-port-from-nsayka-wawa
- DEC-2026-07-22-hard-delete-erasure → related to DEC-2026-07-22-private-tickets-only, DEC-2026-07-22-manual-grant-vs-subscription
- DEC-2026-07-22-in-house-by-default → related to DEC-2026-07-22-openrouter-provider, DEC-2026-07-22-one-backup-surface, DEC-2026-07-22-usage-metering
- DEC-2026-07-22-manual-grant-vs-subscription → related to DEC-2026-07-22-hard-delete-erasure, DEC-2026-07-22-port-from-nsayka-wawa
- DEC-2026-07-22-one-backup-surface → related to DEC-2026-07-22-hard-delete-erasure, DEC-2026-07-22-usage-metering, DEC-2026-07-22-port-from-nsayka-wawa
- DEC-2026-07-22-openrouter-provider → related to DEC-2026-07-22-usage-metering, DEC-2026-07-22-port-from-nsayka-wawa
- DEC-2026-07-22-port-from-nsayka-wawa → related to DEC-2026-07-22-private-tickets-only, DEC-2026-07-22-hard-delete-erasure
- DEC-2026-07-22-private-tickets-only → related to DEC-2026-07-22-port-from-nsayka-wawa, DEC-2026-07-22-hard-delete-erasure
- DEC-2026-07-22-usage-metering → related to DEC-2026-07-22-openrouter-provider, DEC-2026-07-22-hard-delete-erasure, DEC-2026-07-22-manual-grant-vs-subscription
- PAT-2026-07-22-port-description-drift → related to DEC-2026-07-22-port-from-nsayka-wawa, DEC-2026-07-22-private-tickets-only
- DEC-2026-07-22-meridian-scope-dormant-contacts → related to DEC-2026-07-22-no-guilt-scoring, DEC-2026-07-22-mls-data-access, PAT-2026-07-22-machine-narrows-human-judges, DEC-2026-07-22-in-house-by-default
- DEC-2026-07-22-no-guilt-scoring → related to DEC-2026-07-22-meridian-scope-dormant-contacts, PAT-2026-07-22-machine-narrows-human-judges
- DEC-2026-07-22-mls-data-access → related to DEC-2026-07-22-meridian-scope-dormant-contacts, DEC-2026-07-22-in-house-by-default
- PAT-2026-07-22-machine-narrows-human-judges → related to DEC-2026-07-22-meridian-scope-dormant-contacts, DEC-2026-07-22-no-guilt-scoring, DEC-2026-07-22-openrouter-provider
- DEC-2026-07-27-signme-stands-alone → related to DEC-2026-07-22-manual-grant-vs-subscription, DEC-2026-07-27-erase-document-keep-hash
- DEC-2026-07-27-erase-document-keep-hash → related to DEC-2026-07-22-hard-delete-erasure, DEC-2026-07-22-one-backup-surface, DEC-2026-07-22-data-outside-the-container, DEC-2026-07-27-signme-stands-alone
- DEC-2026-07-27-mechanical-first-field-detection → related to DEC-2026-07-27-erase-document-keep-hash, DEC-2026-07-22-openrouter-provider, DEC-2026-07-22-in-house-by-default, PAT-2026-07-22-machine-narrows-human-judges
- DEC-2026-07-28-county-adapter-registry → related to DEC-2026-07-22-mls-data-access, DEC-2026-07-22-meridian-scope-dormant-contacts, DEC-2026-07-22-in-house-by-default, PAT-2026-07-28-county-record-extraction-traps
- PAT-2026-07-28-county-record-extraction-traps → related to DEC-2026-07-28-county-adapter-registry, DEC-2026-07-22-mls-data-access

> **Supersession note.** DEC-2026-07-22-graphic-system-imagery supersedes the kickoff imagery
> directive ("create real-life images"); the original remains verbatim in odyssey-apps/SKILL.md with
> a dated amendment beneath it. No record supersedes another.

## Statistics

| Type | Total | Active | Proposed | Resolved | Deprecated |
|------|-------|--------|----------|----------|------------|
| Incidents | 0 | 0 | 0 | 0 | 0 |
| Decisions | 17 | 14 | 3 | 0 | 0 |
| Patterns | 3 | 3 | 0 | 0 | 0 |
| Flows | 0 | 0 | 0 | 0 | 0 |

*The three `proposed` decisions are Meridian's scope, MLS data access, and SignMe's
erase-the-document-keep-the-hash split. The first two rest on questions only the working agent can
answer; the third rests on a legal review and on reading ESIGN § 7001(d) / UETA § 12 primary text. Its
criteria were REVISED by a 2026-07-27 amendment and now number three, not two — read the amendment,
not the original criteria. See each record's Confirmation Criteria.*
