# Consultation Protocol

How the ledger is queried, how agents are spawned, and how their findings are synthesized. Read this before running `consult`.

---

## Triage (run in order)

1. Read `ledger/index.md`. **Zero records → STOP.** Report "No ledger records match the current context. Proceeding without historical consultation." An empty ledger has zero consultation overhead.
2. Collect the current context: file paths, directory names, component/function names, and the topic argument.
3. Match that context against record tags in the index. **No tag overlap → STOP** with the same no-records report.
4. Read the full record files for every match (records are short — read them, do not skim the index summary).
5. Only after steps 1–4 decide whether agents are needed, per the table below.

## Proportional overhead rules

| Match Scope | Agents Spawned | Rationale |
|-------------|----------------|-----------|
| No records match | None | Zero overhead until records exist |
| Only incidents/flows match | `regression-hunter` only | Single relevant perspective |
| Only decisions/patterns match | `skeptic` only | Single relevant perspective |
| Risk/failure language detected | `premortem-analyst` only | Targeted premortem |
| Multiple record types match | All three (full panel) | Cross-referencing needed |

Agents are spawned with `context: none` — each reads the ledger itself rather than inheriting the conversation, so its finding is an independent read, not an echo of the current plan.

## Synthesis rules

- **Agents agree → HIGH confidence.** Report as a Warning with the record reference.
- **Agents disagree → the disagreement IS the signal.** Never average it away and never pick a winner silently. Report each position under its agent's name as a Consideration, and say plainly that the disagreement is what needs investigating.
- **A record that is relevant but carries no warning** is reported as Context, not escalated.

## Consultation Briefing Format

```markdown
## Ledger Consultation

### Warnings (HIGH confidence — agents agree)

- **[Warning]** — [INC/DEC/PAT/FLW reference] — [one-line explanation]

### Considerations (agents disagree — investigate the disagreement)

- **[Topic]**
  - Regression Hunter: [finding]
  - Skeptic: [finding]
  - Premortem Analyst: [finding]

### Context (relevant records, no warnings)

- [ID] — [why it's relevant but not a warning]

### No Records

No ledger records match the current context. Proceeding without historical consultation.

### Capture Opportunity

The current conversation contains knowledge not yet in the ledger:
- **Suggested type:** [INC/DEC/PAT/FLW]
- **Suggested ID:** [auto-generated from context]
- **Source material:** [quote from conversation]

Confirm to record, or skip.
```

## When consultation runs

During **research and planning** — before a plan, recommendation, or code-change proposal is presented. Not at edit time: by then the plan is already approved, and the ledger's value is in shaping the plan itself.

Skip consultation for changes to `.claude/` infrastructure files, trivial edits (typos, formatting, comments), and areas with no tag overlap.
