---
name: awareness-ledger
description: "Institutional memory for your project. Commands: record, consult, review. Usage: /awareness-ledger [command] [args]"
allowed-tools: Read, Glob, Grep, Write, Edit, Task, TaskCreate, TaskUpdate, TaskList, TaskGet
minimum-effort-level: high
strictness: standard
---

# Awareness Ledger

<!-- origin: skill-builder | version: 1.0 | modifiable: true -->
## Quick Commands

| Command | Action |
|---------|--------|
| `/awareness-ledger record [type]` | Create a record (`incident` / `decision` / `pattern` / `flow`) |
| `/awareness-ledger consult [topic]` | Query the ledger for relevant history before acting |
| `/awareness-ledger review` | Health check: stale entries, missing links, tag drift, statistics |
<!-- /origin -->

---

## Directives

<!-- User directives go here, wrapped in `<!-- origin: user | immutable: true -->` markers.
     Nothing in this section is generated or rewritten by skill-builder. -->

<!-- origin: skill-builder | version: 1.0 | modifiable: true -->
### Auto-Consultation (READ)

During research and planning — before formulating any plan, recommendation, or
code change proposal — automatically consult the ledger:

1. **Index scan** — Read `ledger/index.md` and match tags against the files,
   directories, and components under discussion. This is free — the index is
   small. Do this as part of your initial research, alongside reading source
   files.
2. **Record review** — If matching records exist, read the full record files.
   Incorporate warnings, known failure modes, and relevant decisions into your
   thinking before presenting any plan to the user. This is cheap — records
   are short.
3. **Agent escalation** — If high-risk overlap is detected (matching INC records
   with active status, or multiple record types matching the same change area),
   spawn consultation agents proportionally per the agent table in
   `references/consultation-protocol.md` § "Proportional overhead rules." Present
   agent findings as part of your recommendation. This is expensive — only when
   warranted.

The consultation must happen during planning, not at edit time. By the time
code is being written, the plan has already been presented and approved. The
ledger's value is in shaping the plan itself — surfacing past failures,
challenging assumptions, and providing historical context that changes what
you recommend.

Skip auto-consultation for:
- Changes to `.claude/` infrastructure files
- Trivial edits (typos, formatting, comments)
- Areas with no tag overlap in the index

### Auto-Capture Suggestion (WRITE)

When the current conversation produces institutional knowledge, suggest recording it **after** resolving the immediate issue. Never interrupt active problem-solving to suggest capture.

Automatically suggest capture when you encounter:
- **Bug investigation** with timeline, root cause analysis, or contributing factors → INC record
- **Architectural decisions** with trade-offs discussed and option chosen → DEC record
- **Recurring patterns** observed across multiple instances or confirmed by evidence → PAT record
- **User/system flows** traced step-by-step with code paths identified → FLW record

Capture suggestions are always user-confirmed. Present the suggestion with:
- Suggested record type and ID
- Key content to capture (quoted from conversation)
- One-line confirmation prompt: "Record this in the awareness ledger? (confirm/skip)"
<!-- /origin -->

---

<!-- origin: skill-builder | version: 1.0 | modifiable: true -->
## Command: `record [type]`

**Grounding — read before writing any record:** [references/templates.md](references/templates.md) § the matching record type.

1. Resolve `type` to one of `incident` (INC), `decision` (DEC), `pattern` (PAT), `flow` (FLW). If the argument is absent or unrecognized, ask which type via AskUserQuestion listing the four types — do not guess.
2. **Ownership check (before anything is written).** Read [references/templates.md](references/templates.md) § "Ownership Boundary". IF the fact is per-user-per-machine ergonomics (writing preferences, notation, humor calibration, tool aliases, transient session state) → route it to Claude Code auto memory and STOP. Do not open a ledger record.
3. Generate the ID as `<TYPE>-YYYY-MM-DD-slug`, where the date is today's actual date and `slug` is a kebab-case summary of 2–5 words.
4. Fill the record template from `references/templates.md` verbatim in structure. Every `> "verbatim quote"` field carries the source's own words — never paraphrase a user's wording into a record.
5. Write the file to the matching directory: `ledger/incidents/`, `ledger/decisions/`, `ledger/patterns/`, `ledger/flows/`.
6. Regenerate `ledger/index.md` per [references/templates.md](references/templates.md) § "Index Generation Rules" — tags, status groupings, relationship map, statistics.
7. Report the created path and ID.

**Capture is always user-confirmed. Directives are sacred — never auto-record.**

## Command: `consult [topic]`

**Grounding — read before spawning anything:** [references/consultation-protocol.md](references/consultation-protocol.md).

1. Read `ledger/index.md`. IF the ledger has zero records → report "No ledger records match the current context. Proceeding without historical consultation." and STOP. Zero overhead until records exist.
2. Match `topic` (plus the files/components under discussion) against record tags.
3. Spawn agents **proportionally** per the § "Proportional overhead rules" table — no match → none; incidents/flows only → `regression-hunter`; decisions/patterns only → `skeptic`; risk/failure language → `premortem-analyst`; multiple types → all three.
4. Synthesize findings into the § "Consultation Briefing Format": agreement = HIGH-confidence warning; disagreement is itself the signal and is reported as a Consideration with each agent's position named.
5. Close with a Capture Opportunity block if the conversation contains uncaptured knowledge.

## Command: `review`

1. **Stale entries** — records with `status: active` whose last modification is older than 180 days → list for re-confirmation (`under-review`).
2. **Missing links** — any `Related:` reference whose target record file does not exist → list as a broken link with both IDs.
3. **Tag drift** — tags appearing exactly once across the whole ledger → list as candidates for merging into an established tag.
4. **Index freshness** — recompute the index from the record files and diff against `ledger/index.md`; report any divergence.
5. **Statistics** — emit the § "Index Generation Rules" statistics table.

Review is read-only: it reports, it never rewrites a record.
<!-- /origin -->

---

<!-- origin: skill-builder | version: 1.0 | modifiable: true -->
## Grounding

- [references/templates.md](references/templates.md) — record type templates (INC/DEC/PAT/FLW), status lifecycle, index generation rules, ownership boundary
- [references/consultation-protocol.md](references/consultation-protocol.md) — triage, proportional agent spawning, synthesis rules, briefing format
- [references/capture-triggers.md](references/capture-triggers.md) — conversation signals that suggest a record, and the memory-vs-ledger bail-out rule
- `agents/` — `regression-hunter`, `skeptic`, `premortem-analyst` (each `context: none`)
- `hooks/capture-reminder.sh` — trigger-pattern reminder (host-local; wire it yourself via `/skill-builder hooks awareness-ledger --execute`)
<!-- /origin -->
