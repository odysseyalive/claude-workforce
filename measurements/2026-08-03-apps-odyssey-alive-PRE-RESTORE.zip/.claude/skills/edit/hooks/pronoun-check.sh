#!/bin/bash
# Hook: Pronoun check — enforce they/them default per voice/profile.md
# Scope: Content files only (skips .claude/ infrastructure and quoted scripture)
# Fires on: Edit, Write

# Crash logging
CRASH_LOG="/tmp/edit-pronoun-check-crash.log"
trap 'echo "pronoun-check.sh crashed at line $LINENO" > "$CRASH_LOG" 2>/dev/null; exit 0' ERR

INPUT=$(cat 2>/dev/null) || exit 0

# Scope check: skip .claude/ infrastructure files
FILE_PATH=$(echo "$INPUT" | grep -oP '"file_path"\s*:\s*"[^"]*"' 2>/dev/null | head -1 | sed 's/.*"file_path"\s*:\s*"//;s/"$//' 2>/dev/null) || exit 0
if echo "$FILE_PATH" | grep -q '\.claude/' 2>/dev/null; then
  exit 0
fi

# Extract the content being written/edited
# For Edit: check new_string only
# For Write: check content
CONTENT=$(echo "$INPUT" | grep -oP '"new_string"\s*:\s*"[^"]*"' 2>/dev/null | head -1 | sed 's/.*"new_string"\s*:\s*"//;s/"$//' 2>/dev/null) || true
if [ -z "$CONTENT" ]; then
  CONTENT=$(echo "$INPUT" | grep -oP '"content"\s*:\s*"[^"]*"' 2>/dev/null | head -1 | sed 's/.*"content"\s*:\s*"//;s/"$//' 2>/dev/null) || exit 0
fi

[ -z "$CONTENT" ] && exit 0

# Check for gendered pronouns referring to Francis (common AI default)
# Only flag "he/him/his" or "she/her/hers" when used as subject pronouns
# that likely refer to Francis (not quoted speech or scripture)
if echo "$CONTENT" | grep -qiP '\b(Francis\s+(he|she|him|her|his|hers)\b|(?:^|\.\s+)(He|She)\s+(is|was|has|had|does|did|would|could|should|will|can|writes|wrote|says|said|thinks|thought|believes|felt|feels|notes|noted))\b' 2>/dev/null; then
  echo "NOTICE: Possible gendered pronoun detected — Francis uses they/them pronouns (per voice/profile.md). Check that gendered pronouns aren't referring to Francis. Names over pronouns when the person matters." >&2
  exit 2
fi

exit 0
