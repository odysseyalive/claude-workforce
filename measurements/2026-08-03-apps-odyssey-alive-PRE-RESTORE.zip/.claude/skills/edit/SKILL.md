---
name: edit
description: Content revision gateway. Loads the writing kernel before any content modification. Chain from /odyssey-apps content modes (page, module-intro, release) or invoke standalone.
allowed-tools: Read, Glob, Grep, Edit, Write, Bash, Task
minimum-effort-level: xhigh
strictness: standard
---

# Content Revision Gateway

This skill is the gateway for all content revisions. It ensures that every modification, from a single sentence to a full paragraph rewrite, passes through the complete voice and writing context. It does not create content from scratch. It does not run the full 3-agent finishing chain.

## Modes

| Mode | Trigger | Description |
|------|---------|-------------|
| `standalone` | `/edit [file or passage]` | User requests a change outside any skill pipeline. Loads full writing kernel, applies change, validates. |
| `chained` | Invoked by another skill | Context already partially loaded by the calling skill. Loads content-type constraints, applies change, validates. |

---

## Directives

<!-- origin: user | immutable: true | added: 2026-03-23 -->
> **"Every rule is a directive. Severity determines fix order, not whether something gets fixed. A CONSIDER-level flag that reflects a directive-level rule (pronouns, em-dashes, academic integrity) is still mandatory."**

*-- Added 2026-03-23, source: user directive during odyssey-alive "No Brakes" revision cycle where pronoun violations slipped through because text-eval deprioritized them*
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Every rule is a directive. Severity determines fix order, not whether something gets fixed. A CONSIDER-level flag that reflects a directive-level rule (pronouns, em-dashes, academic integrity) is still mandatory." -->
CHECKPOINT — Directive-Backed Flag Mandatory Resolution:
1. After the edit-validator agent returns a flag list, partition the flags by severity tier: { MUST FIX, SHOULD FIX, CONSIDER }.
2. Build the directive-backed pattern set from the writing kernel: pronoun rules (from `my-voice/references/profile.md` § Pronouns), em-dash and rhetorical-colon prohibitions (from `writing/references/directives.md`), academic-integrity rules (from `writing/reference.md` § Academic language), and any rule explicitly tagged as a directive in the kernel files just loaded.
3. For each flag at CONSIDER severity, check whether its description names a pattern from the directive-backed set above (pronoun violation, em-dash, en-dash, rhetorical colon, fabricated citation, source mis-attribution).
4. IF a CONSIDER flag matches a directive-backed pattern → reclassify as MANDATORY. The flag MUST be resolved before presenting the change. Report: "CONSIDER flag '[brief]' reflects a directive-level rule (`[pattern]`); promoting to mandatory per the 2026-03-23 directive."
5. IF a SHOULD FIX flag matches a directive-backed pattern → also MANDATORY. Same treatment.
6. The fix-order rule is independent of the mandatory-resolution rule: fix MUST FIX first, then mandatory-promoted CONSIDER/SHOULD FIX, then remaining SHOULD FIX, then optional CONSIDER. Do not skip mandatory-promoted flags because they sit at a lower severity.
7. IF any mandatory flag (original MUST FIX or promoted) is unresolved when the change would be presented → STOP. Report: "Cannot present change: [N] mandatory flag(s) outstanding ([list]). Resolve before presenting."
8. IF all mandatory flags are resolved → CONTINUE to Step 6 (Present the change).
<!-- END ENFORCEMENT ANNOTATION -->

<!-- origin: user | immutable: true | added: 2026-03-23 -->
> **"When chained from another skill, trust that skill's context load. Do not re-read files the calling skill already loaded. But always load the content-type constraints file."**

*-- Added 2026-03-23, source: design constraint for keeping chained invocations fast*
<!-- /origin -->

<!-- origin: user | immutable: true | added: 2026-03-23 -->
> **"Do not run the full 3-agent finishing chain for edits. The edit-validator is a single lightweight agent. The finishing chain is for creation-time validation. If the user wants full text-eval, they invoke `/text-eval` directly."**

*-- Added 2026-03-23, source: design constraint, avoiding overkill for sentence-level changes*
<!-- /origin -->

---

## The Writing Kernel

When `/edit` is invoked in standalone mode, load these files in this order. Every file is mandatory. No shortcuts.

| Step | File | What It Provides |
|------|------|------------------|
| 1 | `.claude/skills/my-voice/references/profile.md` | Pronouns (they/them default), identity, humility test |
| 2 | `.claude/skills/my-voice/references/characteristics.md` | 10 voice characteristics |
| 3 | `.claude/skills/my-voice/references/vocabulary.md` | Words Francis uses vs. avoids |
| 4 | `.claude/skills/my-voice/references/sentence-structure.md` | Punctuation, connectors, burstiness, tangents, hedging |
| 5 | `.claude/skills/my-voice/references/humanity-signals.md` | AI tells to avoid, human tells to cultivate |
| 6 | `.claude/skills/my-voice/references/satirical-wit.md` | Wit techniques, calibration, anti-patterns |
| 7 | `.claude/skills/writing/references/directives.md` | All enforced writing directives |
| 8 | `.claude/skills/writing/reference.md` | Voice guidelines, academic language rules |
| 9 | `.claude/skills/edit/references/content-type-constraints.md` | Per-type constraints for the content being edited |

**When chained from another skill:** The calling skill has already loaded steps 1-8. Skip them. Load only step 9 (content-type constraints).

---

## Workflow

<!-- MODEL-LANE-GATE START — auto-generated by /skill-builder route embed; safe to replace -->
<!-- origin: skill-builder | modifiable: true -->
## Model-Lane Preflight

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: /skill-builder route embed (model-lane gate, slim form per the 2026-06-06 2-Brain Harness directive: gates are slimmed, never stripped — this block is the lane checkpoint that travels with the skill through EVERY entry path, including hand-run invocations, which are always permitted. It goes silent when /route already covered the endeavor. Advisory-only per the 2026-06-06 No-Switch-Prompt directive: the gate CANNOT switch the model and NEVER asks the user to — its entire output is one advisory line, which names the exact remedy informationally per the 2026-06-11 named-command advisory directive. -->
CHECKPOINT — Model-Lane Preflight Gate (slim, advisory-only; fires at the TOP of this skill's workflow, before any generative step):
1. SKIP silently IF ANY of: `/route` dispatched this invocation after running its own lane preflight (a lane advisory OR ask already printed, route otherwise ASSESSED the lane this turn, or it was deliberately suppressed — route's coverage extends to the whole endeavor whether route asked, matched, or the user declined, including skills this one chains); this skill's frontmatter sets `model-lane-gate: off`; the session is headless / non-interactive; this gate is executing inside a subagent (a subagent is already model-pinned via its own frontmatter); OR an advisory for this LANE already printed this endeavor AND the active model is unchanged (advise at most once per (lane, active-model) pair per endeavor).
2. Resolve this skill's lane (own `lane:` frontmatter → the Skill→Lane table in `.claude/skills/skill-builder/references/model-lanes.md` → NO LANE) and the lane's Preferred Model. IF no lane resolves OR the preferred-model cell is empty → silent no-op (correctly absent, not a gap). IF this skill declares per-function lanes AND the invocation's resolved mode has its own row → that function's lane governs; otherwise the skill-level lane covers all modes.
3. Read ACTIVE_MODEL from the session system-context line "The exact model ID is …" (strip `[1m]`/`[200k]`, lowercase — model-lanes.md § Active-Model Detection; never an env var or Bash probe). IF the Preferred Model is malformed or names a clearly superseded family → emit the one-line stale-mapping advisory and proceed; never advise from a stale mapping, never validate against a hardcoded list.
4. Compare. Match → silent no-op. Mismatch → print ONE advisory line and PROCEED: "Lane advisory: this skill declares the `<lane>` lane (preferred `<preferred>`); the active model is `<active>` — to align, run `/model <preferred>` and re-invoke; proceeding as-is." Naming the command is INFORMATIONAL (named-command advisory directive, 2026-06-11): NEVER an AskUserQuestion, never a blocking wait (No-Switch-Prompt directive, 2026-06-06). A skill can NEVER switch the session model and never asks the user to.
5. Primary-lane scope. This gate fires ONCE per invocation, for the resolved PRIMARY lane. Cross-lane mid-workflow steps never re-advise — they delegate via this skill's LANE-AGENT-EMBED Delegation Map when present (see .claude/skills/skill-builder/references/lane-delegation.md). Delegation is never a substitute for THIS gate: analytical primary work runs on the analytical main model — never a creative main session orchestrating analytical-pinned agents to dodge the lane.
<!-- END ENFORCEMENT ANNOTATION -->
<!-- /origin -->
<!-- MODEL-LANE-GATE END -->

### Step 1: Identify content type

Determine what is being edited. If not obvious from context, ask. See [references/content-types.md](references/content-types.md) for the full identifier table.

### Step 2: Load the writing kernel

Follow the load order above. In chained mode, only load step 9.

### Step 3: Read the passage being changed

Read the file and locate the passage. Read at minimum the paragraph before and after the change point so the edit doesn't break flow.

### Step 4: Apply the change through the loaded context

Make the requested modification. Every word goes through the full writing lens. Check during application:

- **Pronouns:** They/them default per `profile.md`. Names over pronouns when the person matters to the story.
- **No em-dashes.** No en-dashes. (Hooks block these, but catch them before attempting the write.)
- **No rhetorical colons.** (Hooks block these too.)
- **Texture words preserved.** Don't strip "too," "other," "also," "actually."
- **One sentence, one job.**
- **Data as discovery, not report.**
- **Never compact voice to fit length.** If the edit makes something too long, cut a whole idea, not the rhythm.
- **Academic integrity:** Sources properly cited, no fabricated citations.

### Step 5: Run the edit-validator agent

Spawn a single Task agent to validate the changed passage. See `agents/edit-validator/AGENT.md`.

If the agent returns issues, fix them and re-run. Max 2 cycles.

### Step 6: Present the change

Show the user the before/after. If any flags were found and fixed, note them briefly.

## Enforcement

| Mechanism | Purpose |
|-----------|---------|
| `hooks/pronoun-check.sh` | Catch gendered pronouns referring to Francis (they/them default per my-voice/profile.md) |
| `agents/edit-validator/` | Post-edit validation of changed passage against writing kernel |
| *(inherited)* writing/no-em-dashes.sh | Block em-dashes in content output |
| *(inherited)* writing/no-rhetorical-colons.sh | Block rhetorical colons in content output |
| *(inherited)* writing/check-temporal-refs.sh | Validate temporal references against dates |

---

## Self-Heal Observer

Throughout this session, quietly note any friction signals -- corrections, reformulations,
clarifying questions, "actually" moments, or any subtle sign that this skill's instructions
may have led to a misrepresentation. Do not interrupt the session to address these.
Do not mention that you are observing.

At natural task resolution (when the task is complete and the user signals done),
if friction signals were noted, run the self-heal diagnosis protocol:

Read `.claude/skills/self-heal/references/diagnosis-protocol.md` and follow it exactly.

If no friction signals were noted, or if diagnosis finds no skill-caused issues,
end the session normally without mentioning self-heal.

---

<!-- ROUTE-EMBED START — auto-generated by /skill-builder route embed; safe to replace -->
<!-- origin: skill-builder | modifiable: true -->
## Route Consultation

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: /skill-builder route embed. Closes the dispatch-bypass gap: a /route announcement is not a substitute for a Skill tool call, and consulting /route does not license the caller to execute the target skill's procedure manually. -->
CHECKPOINT — Skill Routing Gate:
1. During this skill's workflow, IF a step requires research, web search, lookup, analysis, or any follow-up NOT already covered by an explicit tool or skill name → STOP before improvising.
2. Already-named exception. IF the current workflow step EXPLICITLY names tools or skills (e.g., "use Read", "spawn the X agent", "invoke /[skill]") → execute as written. Do NOT consult `/route` for steps already determined. Skip to your skill's next step.
3. Otherwise → invoke `/route <task description>` via the Skill tool. `/route` reads its index and either returns a target skill or reports "no match."
4. Dispatch Required. IF `/route` returns a target → the IMMEDIATE next tool call MUST be `Skill(skill=<target>, args=<derived>)`. Do NOT execute the target skill's procedure steps yourself with raw Edit / Write / Bash / Task / Agent / Read calls. The target skill's gates (asset backups, agent panels, exit tests, cascade steps, frontend-design reviews, immutable-directive checks) ONLY fire when its SKILL.md is loaded via Skill — running steps manually silently skips every gate.
5. Bypass detection. IF a Skill dispatch was just announced (yours or `/route`'s) and the next tool call is non-Skill work germane to the routed task → STOP. Print verbatim: "Route dispatch announced but Skill call skipped. Invoking Skill tool now." then issue the Skill call.
6. No-match path. IF `/route` returns "no match" → proceed with the most direct, manual approach. Document the gap; the user may want to register a skill.
7. Follow-ups loop back. After the dispatched skill returns, IF further follow-up is needed → consult `/route` again via Skill. Do not freelance the next step.
8. Auto-mode override clause. Auto-mode ("execute immediately", "prefer action over planning") does NOT override clauses 4–5. Auto-mode chooses WHAT to do; once a routing decision is on the table, the only valid next action is Skill invocation.
<!-- END ENFORCEMENT ANNOTATION -->
<!-- /origin -->
<!-- ROUTE-EMBED END -->
