# Content Type Identifiers

> **PROJECT NOTE (Odyssey Apps, 2026-07-22).** This file is a snapshot from the source project and
> describes content types belonging to skills that are NOT installed here (`/study-notes`,
> `/study-prep`, `/bible-study`). Those rows are inert — nothing in this project produces them.
> The content types that DO apply here are the site's own: MDX pages, module intros, beta blurbs,
> release notes, transactional email bodies, and component-embedded UI strings. All of them also
> pass `/text-eval` unconditionally (2026-07-22 directive), with no per-type exemption.

Lookup table for /edit workflow Step 1 — used to identify what is being edited so the correct content-type constraints load.

| Content Type | Identifier |
|--------------|------------|
| `study-notes` | Study notes from /study-notes or /study-prep auto/review modes |
| `bible-study-notes` | Notes from /bible-study review mode |
| `research-report` | Research output from /bible-study research mode |
| `talk-manuscript` | Manuscript from /bible-study talk mode |
| `discussion-post` | Academic discussion board responses |
| `academic-paper` | Term papers, essays, formal assignments |

For per-type constraints (what each content type requires), see [content-type-constraints.md](content-type-constraints.md).
