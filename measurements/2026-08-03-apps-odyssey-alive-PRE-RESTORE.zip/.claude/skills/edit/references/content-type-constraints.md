# Content-Type Constraints

> **PROJECT NOTE (Odyssey Apps, 2026-07-22).** This file is a snapshot from the source project and
> describes content types belonging to skills that are NOT installed here (`/study-notes`,
> `/study-prep`, `/bible-study`). Those rows are inert — nothing in this project produces them.
> The content types that DO apply here are the site's own: MDX pages, module intros, beta blurbs,
> release notes, transactional email bodies, and component-embedded UI strings. All of them also
> pass `/text-eval` unconditionally (2026-07-22 directive), with no per-type exemption.

The writing kernel (voice, writing directives, sentence structure) applies to ALL content types. These are the ADDITIONAL constraints per type.

---

## Study Notes

**Source:** `.claude/skills/study-notes/references/content-quality.md`

- Coverage-first: every named species, every bolded term, every defined concept from the source
- Voice: sounds like the user talking to themselves, not a textbook
- WHY lines follow comparison tables (trait, selective pressure, consequence)
- Ends with drill recommendation
- No em-dashes (hook-enforced)

**Also read when editing:**
- `.claude/skills/study-notes/references/format-content-directives.md`
- `.claude/skills/study-notes/references/content-quality.md`

---

## Bible Study Notes

**Source:** `.claude/skills/bible-study/references/skill-integration.md`

- Scripture citations must use New World Translation (NWT)
- Cross-reference JW publications for interpretive accuracy
- Voice: knowledgeable study partner, not academic lecture
- No em-dashes (hook-enforced)

**Also read when editing:**
- `.claude/skills/bible-study/references/skill-integration.md`

---

## Research Report

**Source:** `.claude/skills/bible-study/references/procedures/research.md`

- Clear investigative question framed at the top
- Evidence quality: scripture chains, not isolated proof-texts
- Publication cross-references for all interpretive claims
- Reflection section should have personal voice and wit (per skill integration)
- No em-dashes (hook-enforced)

**Also read when editing:**
- `.claude/skills/bible-study/agents/research-analyst/AGENT.md` (constraints)

---

## Talk Manuscript

**Source:** `.claude/skills/bible-study/references/procedures/talk.md`

- Follows outline structure from assignment
- Applies theocratic ministry principles (th lessons)
- Fits word budget per assignment requirements
- Scripture readings marked with `[READ]`
- No em-dashes (hook-enforced)

**Also read when editing:**
- `.claude/skills/bible-study/agents/talk-evaluator/AGENT.md` (constraints)

---

## Discussion Post

**Source:** Standalone academic content

- Full-scope for edit-validator (the post IS the passage)
- Must answer the discussion prompt directly
- Evidence-based claims with specific citations (page numbers, chapter references)
- Francis's voice, not academic boilerplate
- APA citation format (per university CLAUDE.md)
- Word count per assignment requirements
- No em-dashes (hook-enforced)

**Discussion posts are full-scope for edit-validator.** Unlike other edits (where the validator checks only the changed passage), a discussion post IS the passage. The edit-validator checks the entire post, not just the changed sentence.

---

## Academic Paper

**Source:** Standalone academic content

- Proper citation format per assignment (default APA)
- Section structure follows assignment rubric
- Third person for formal papers (per university CLAUDE.md)
- No em-dashes (hook-enforced)
- Voice applied at paragraph level but respects academic conventions
- Sources must be read before citing (per writing directive: "Never cite what you can't read")
