---
name: analytics
description: Odyssey Apps site traffic assessment from Cloudflare Web Analytics (RUM), correlated with roadmap version releases and module launches. Cloudflare-only. Modes: report, release-impact, compare.
allowed-tools: Read, Glob, Grep, Bash, Task
minimum-effort-level: high
strictness: standard
---

# Site Analytics

Pull traffic data from **Cloudflare Web Analytics** (the RUM beacon product), correlate it with the Odyssey Apps site's own release events (roadmap versions, and module launches once they happen), and evaluate how the site is doing.

This skill was imported and adapted from the odyssey-alive `analytics` skill (2026-05-29). The upstream version pulled from both Google Analytics 4 and Cloudflare zone-level HTTP analytics. **This project has no Google Analytics and no Cloudflare zone for `apps.odysseyalive.com`** (the site deploys via jstack + nginx, not behind an orange-cloud proxy). The only telemetry is the standalone Cloudflare Web Analytics beacon. Everything here is Cloudflare-RUM-only.

## Usage

```
/analytics [mode] [args]
```

### Modes

| Mode | Command | Description |
|------|---------|-------------|
| `report` | `/analytics report [period]` | Full traffic overview from Cloudflare Web Analytics. Default: last 30 days |
| `release-impact` | `/analytics release-impact [version]` | Traffic impact of a roadmap version release (before/after its ship date) |
| `compare` | `/analytics compare [period1] [period2]` | Period-over-period traffic comparison |
| `list` | `/analytics list` | Show this modes table |

Default mode is `report` if not specified.

> **`module-impact` is reserved** for when a module flips `status: coming-soon → live` and acquires a launch date. The site is pre-launch today (both modules are `coming-soon`), so the active impact mode is `release-impact`, anchored on roadmap versions. When the first module launches, `module-impact` becomes the natural sibling using the same windowing on the module's own paths.

---

<!-- origin: user | added: 2026-02-14 | immutable: true | imported-from: odyssey-alive/analytics 2026-05-29 -->
## Directives

> **"Compare traffic data with release of articles by date so you can give me an evaluation on how things are going."**

*— Added 2026-02-14, source: user request during the odyssey-alive analytics skill's creation. Imported verbatim into this project's skill 2026-05-29. On the Odyssey Apps site, "release of articles" maps to the site's own release events — roadmap version releases, and module launches once they occur — since this site has no dated articles of its own (Field Notes point out to odysseyalive.com).*
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Compare traffic data with release of articles by date so you can give me an evaluation on how things are going." -->
<!-- Re-anchored 2026-05-29: GA4 removed (Cloudflare-only); "release of articles" → roadmap version releases + module launches. -->
CHECKPOINT — Release-Correlated Evaluation Gate:
1. Before presenting an evaluation, enumerate the site's release events within the reporting period. The release source is the roadmap version list in `src/lib/roadmaps.ts` → `RoadmapVersion[]` (source of truth `.claude/skills/odyssey-apps/references/(module roadmap source — see odyssey-apps/references/modules.json)` § Versions), plus any module that launched in the period (`content/modules/*.mdx` whose status flipped to live). For the date of each release, see § "Release-date sourcing" below.
2. For EACH release date, align the Cloudflare Web Analytics traffic series to a ±14-day window around the date.
3. Compute for EACH release: pre-release baseline (mean daily visits 14 days before), post-release peak (max daily visits 14 days after), and decay (visits on day 14 vs peak).
4. IF the report contains traffic numbers without release-event alignment → STOP. Recompute correlating each metric to specific release events.
5. IF a release in the period has no pre/post comparison in the output → STOP. Add the missing comparison before presenting.
6. IF the reporting period contains NO release events (the realistic pre-launch case) → say so explicitly and present the traffic trend on its own, noting there is nothing to correlate yet. Do NOT invent a release to correlate against.
7. IF all releases in the period have aligned pre/post/decay figures AND the output names which releases drove which traffic shifts → CONTINUE and present the evaluation.
<!-- END ENFORCEMENT ANNOTATION -->

---

## Credentials Gate (stub-vs-live)

This skill operates in one of two modes depending on whether Cloudflare API access is configured:

- **Live mode** — runs real queries when `CLOUDFLARE_API_TOKEN`, `CLOUDFLARE_ACCOUNT_ID`, and `CLOUDFLARE_WEB_ANALYTICS_SITE_TAG` are all present AND the token has **Account → Account Analytics: Read** permission.
- **Stub mode** — when any are missing or the token lacks scope, the skill does NOT fabricate numbers. It prints the exact gap (which env vars to add, how to scope the token, how to find the site tag — see [references/setup.md](references/setup.md)) and stops.

**Current state (2026-05-29):** `CLOUDFLARE_API_TOKEN` and `CLOUDFLARE_ACCOUNT_ID` are carried over from odyssey-alive (same Cloudflare account). The token is active but **scoped to the odysseyalive.com zone, not account-level Web Analytics** — an account-RUM query returns `authz: not authorized for that account`. `CLOUDFLARE_WEB_ANALYTICS_SITE_TAG` is not yet set. Until the token is re-scoped and the site tag is added, the skill runs in **stub mode**. See [references/setup.md](references/setup.md).

**CHECKPOINT — Credentials preflight (fires before any mode):**
1. **Deterministic precheck first (no agent).** Grep `.env.local` for all three vars: `CLOUDFLARE_API_TOKEN`, `CLOUDFLARE_ACCOUNT_ID`, `CLOUDFLARE_WEB_ANALYTICS_SITE_TAG` (presence only — never read or print the values). IF any one is absent → enter stub mode immediately, report the gap from [references/setup.md](references/setup.md), and STOP **without spawning the agent**. The agent's job is scope-probing, which is meaningless when a var is plainly missing.
2. **Agent scope-probe (only when all three are present).** Spawn the ID Lookup agent (see [agents/id-lookup/AGENT.md](agents/id-lookup/AGENT.md)) to verify the token is active AND authorized for account-level RUM. Never print credential values.
3. IF the agent returns NOT-AUTHORIZED (or MISSING) → enter stub mode: report the gap from [references/setup.md](references/setup.md) and STOP. Do not run queries, do not estimate numbers.
4. IF the agent returns READY → proceed to the requested mode in live mode.

---

## Release-date sourcing

`RoadmapVersion` in `src/lib/roadmaps.ts` currently carries `version` / `title` / `summary` but **no date field**. To correlate a version release against traffic you need its ship date. Two sources, in preference order:

1. **Preferred (durable):** an explicit `date` (ISO `YYYY-MM-DD`) on each `RoadmapVersion`, stamped by `/odyssey-apps release` when the entry is added. If that field exists, use it. Adding it is a one-line schema change routed through `/odyssey-apps release` — propose it via `/route`, do not hand-edit the site source from this skill.
2. **Interim fallback (approximate):** derive the date from git history of the roadmap source file — the commit that first introduced the version's heading:
   ```bash
   git log -S "v0.1.0" --diff-filter=A --format=%aI -- .claude/skills/odyssey-apps/references/(module roadmap source — see odyssey-apps/references/modules.json) | tail -1
   ```
   Flag this as approximate (it tracks when the entry was written, not necessarily when it shipped) and note it breaks if the file is reformatted.

If neither a `date` field nor a git-derived date is available for a version, treat that release as undated and exclude it from correlation, noting the gap.

---

## Workflows

**Grounding:** Before executing any mode, read [references/workflows.md](references/workflows.md) for the full procedure (report, release-impact, compare). Every mode pulls from Cloudflare Web Analytics RUM only, then correlates with the site's release events.

---

## Grounding

Before making any API call, read credentials from references and state: "I will use [VALUE] for [PURPOSE], found under [SECTION]." Never echo the secret value itself.

**References:** [credentials.md](references/credentials.md) · [setup.md](references/setup.md) · [cloudflare-queries.md](references/cloudflare-queries.md) · [workflows.md](references/workflows.md) · [integrations.md](references/integrations.md)

## Post-Action Capture

After completing a report or release-impact analysis that reveals a notable pattern (a roadmap release that moved traffic, a sustained vs. flash-in-the-pan bump, a bot/human anomaly), suggest recording the finding in the awareness ledger (PAT record) so it persists across sessions. Never auto-record — ask the user first.
