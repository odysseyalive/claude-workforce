#!/bin/bash
# Hook: Validate date parameters in Cloudflare Web Analytics API commands
# Catches: start > end, dates far in future, invalid formats
# Scope: Bash commands containing Cloudflare GraphQL analytics API calls
# NOTE: This is a HOST-LOCAL hook. It is not distributed/auto-wired. To activate
#       it, wire a PreToolUse(Bash) entry in .claude/settings.local.json on this host
#       (see /skill-builder hooks analytics).
CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR

INPUT=$(cat 2>/dev/null) || exit 0

COMMAND=$(echo "$INPUT" | grep -oP '"command"\s*:\s*"[^"]*"' | head -1 | sed 's/.*"command"\s*:\s*"//;s/"$//')

# Only check commands that hit the Cloudflare analytics GraphQL API
if ! echo "$COMMAND" | grep -qi 'cloudflare.*graphql\|graphql.*cloudflare\|rumPageloadEvents\|rumPerformanceEvents\|httpRequests'; then
  exit 0
fi

# Extract date parameters (YYYY-MM-DD, from either bare dates or ISO datetimes)
DATES=$(echo "$COMMAND" | grep -oP '\d{4}-\d{2}-\d{2}' | sort -u)

if [ -z "$DATES" ]; then
  exit 0
fi

# Validate each date
while IFS= read -r d; do
  if ! date -d "$d" +%s >/dev/null 2>&1; then
    echo "BLOCKED: Invalid date format in Cloudflare analytics API call: $d" >&2
    exit 2
  fi

  D_EPOCH=$(date -d "$d" +%s 2>/dev/null)
  FUTURE_LIMIT=$(date -d "+30 days" +%s 2>/dev/null)
  if [ "$D_EPOCH" -gt "$FUTURE_LIMIT" ] 2>/dev/null; then
    echo "BLOCKED: Analytics date $d is more than 30 days in the future. Analytics data is historical." >&2
    exit 2
  fi
done <<< "$DATES"

# If there are exactly 2 dates, check start < end
DATE_COUNT=$(echo "$DATES" | wc -l)
if [ "$DATE_COUNT" -eq 2 ]; then
  START=$(echo "$DATES" | head -1)
  END=$(echo "$DATES" | tail -1)
  START_EPOCH=$(date -d "$START" +%s 2>/dev/null)
  END_EPOCH=$(date -d "$END" +%s 2>/dev/null)
  if [ "$START_EPOCH" -gt "$END_EPOCH" ] 2>/dev/null; then
    echo "BLOCKED: Analytics date range is inverted: start=$START > end=$END" >&2
    exit 2
  fi
fi

exit 0
