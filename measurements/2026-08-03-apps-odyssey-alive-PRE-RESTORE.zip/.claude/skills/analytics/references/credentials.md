# API Credentials

All credentials live in `.env.local`. **Never hardcode tokens. Never print their values.**

## Cloudflare Web Analytics (RUM)

| Variable | Purpose | Status (2026-05-29) |
|----------|---------|---------------------|
| `CLOUDFLARE_API_TOKEN` | Bearer token for the GraphQL Analytics API. **Must include Account → Account Analytics: Read.** | Present (same account as odyssey-alive) and **account-scoped** — account-level RUM queries return `data` (verified 2026-05-29). |
| `CLOUDFLARE_ACCOUNT_ID` | The `accountTag` for the `viewer.accounts(filter:)` node. | Present (same account). |
| `CLOUDFLARE_WEB_ANALYTICS_SITE_TAG` | The RUM **site tag** — the Web Analytics dataset id bound to the beacon. Used as the `siteTag` filter. Distinct from the public beacon token. | Set to the **SHARED** tag `d0ea0dad…` (one beacon, two hosts: `apps.odysseyalive.com` + `odysseyalive.com`). **Not** a dedicated skul tag, so every query also filters `requestHost:"apps.odysseyalive.com"` — see below. The dedicated skul-only tag `d3b02e896…` exists but has no beacon and returns zero data. |
| `NEXT_PUBLIC_CF_BEACON_TOKEN` | The *public* beacon-injection token (client-side, shipped to browsers). **Cannot authenticate the API** — informational only. | Present. |

**Endpoint:** `https://api.cloudflare.com/client/v4/graphql`
**Auth header:** `Authorization: Bearer $CLOUDFLARE_API_TOKEN`
**Scope semantics:** Web Analytics RUM datasets are **account-scoped** (`viewer.accounts`, filtered by `accountTag` + `siteTag`). There is **no zone** for `apps.odysseyalive.com`, so the zone datasets (`httpRequests1dGroups`, `httpRequestsAdaptiveGroups`) and `CLOUDFLARE_ZONE_ID` do **not** apply here and are intentionally absent.
**Shared-tag host filter (mandatory):** because the site tag is shared across `apps.odysseyalive.com` and `odysseyalive.com`, every skul query MUST add `requestHost:"apps.odysseyalive.com"` to isolate skul traffic. `siteTag` alone is insufficient. See [cloudflare-queries.md](cloudflare-queries.md) § MANDATORY host filter.
**Rate limit:** 300 GraphQL queries per 5 minutes per user.

## Not used in this project

- **Google Analytics 4** — no GA4. Removed when this skill was imported. Do not add GA4 vars, queries, or setup steps.
- **`CLOUDFLARE_ZONE_ID`** — odyssey-alive used it for zone HTTP analytics on its own domain. `apps.odysseyalive.com` is not a Cloudflare zone (jstack/nginx TLS), so it is not needed.
