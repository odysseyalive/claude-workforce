# Cloudflare Web Analytics (RUM) GraphQL Query Templates

All queries are **account-scoped** RUM datasets — `viewer.accounts(filter: {accountTag})` → `rumPageloadEventsAdaptiveGroups`, filtered by the Web Analytics `siteTag`. There is no Cloudflare zone for this site, so none of the zone datasets apply.

> **MANDATORY host filter — the site tag is SHARED.** `CLOUDFLARE_WEB_ANALYTICS_SITE_TAG` (`d0ea0dad…`) is a single RUM dataset bound to a beacon that fires on **both** `apps.odysseyalive.com` **and** `odysseyalive.com`. Filtering by `siteTag` alone therefore blends the two sites and over-reports skul. **Every skul query below MUST also filter `requestHost:"apps.odysseyalive.com"`** — it is not optional. The only exception is the "Enumerate site tags" discovery query at the bottom, which intentionally spans all tags/hosts.

**Conventions:**
- Datetime filters use `datetime_geq` / `datetime_leq` (ISO 8601, e.g. `2026-05-01T00:00:00Z`) — the RUM convention, NOT the zone `date_gt`/`date_lt`.
- `limit` is required; the API errors without it.
- RUM datasets are **beta and adaptively sampled** — treat `count` (pageloads) and `sum.visits` as estimates. Validate exact metric/dimension names against the live schema on first run; beta fields drift.

## Daily traffic (pageloads + visits)

```bash
curl -s https://api.cloudflare.com/client/v4/graphql \
  -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN" \
  -H "Content-Type: application/json" \
  --data '{"query":"{ viewer { accounts(filter:{accountTag:\"'"$CLOUDFLARE_ACCOUNT_ID"'\"}) { rumPageloadEventsAdaptiveGroups(filter:{ siteTag:\"'"$CLOUDFLARE_WEB_ANALYTICS_SITE_TAG"'\", datetime_geq:\"START_DATETIME\", datetime_leq:\"END_DATETIME\", requestHost:\"apps.odysseyalive.com\" }, limit:1000, orderBy:[date_ASC]) { count sum { visits } dimensions { date } } } } }"}'
```

## Top pages by traffic

```bash
curl -s https://api.cloudflare.com/client/v4/graphql \
  -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN" \
  -H "Content-Type: application/json" \
  --data '{"query":"{ viewer { accounts(filter:{accountTag:\"'"$CLOUDFLARE_ACCOUNT_ID"'\"}) { rumPageloadEventsAdaptiveGroups(filter:{ siteTag:\"'"$CLOUDFLARE_WEB_ANALYTICS_SITE_TAG"'\", datetime_geq:\"START_DATETIME\", datetime_leq:\"END_DATETIME\", requestHost:\"apps.odysseyalive.com\" }, limit:25, orderBy:[count_DESC]) { count sum { visits } dimensions { requestPath } } } } }"}'
```

## Traffic for a specific path (used by `release-impact`)

```bash
curl -s https://api.cloudflare.com/client/v4/graphql \
  -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN" \
  -H "Content-Type: application/json" \
  --data '{"query":"{ viewer { accounts(filter:{accountTag:\"'"$CLOUDFLARE_ACCOUNT_ID"'\"}) { rumPageloadEventsAdaptiveGroups(filter:{ siteTag:\"'"$CLOUDFLARE_WEB_ANALYTICS_SITE_TAG"'\", datetime_geq:\"START_DATETIME\", datetime_leq:\"END_DATETIME\", requestHost:\"apps.odysseyalive.com\", requestPath:\"/modules/nsayka-wawa\" }, limit:1000, orderBy:[date_ASC]) { count sum { visits } dimensions { date } } } } }"}'
```

Relevant site paths to correlate against releases: `/`, `/modules`, `/modules/nsayka-wawa`, `/modules/nsayka-wawa/roadmap`.

## Referrer breakdown

```bash
... rumPageloadEventsAdaptiveGroups(filter:{ siteTag:"$SITE_TAG", requestHost:"apps.odysseyalive.com", datetime_geq:"START", datetime_leq:"END" }, limit:25, orderBy:[count_DESC]) { count dimensions { refererHost } }
```

## Core Web Vitals (optional perf secondary, not traffic)

```bash
... rumPerformanceEventsAdaptiveGroups(filter:{ siteTag:"$SITE_TAG", requestHost:"apps.odysseyalive.com", datetime_geq:"START", datetime_leq:"END" }, limit:1000) { count dimensions { date } }
```

## Enumerate site tags (find which siteTag is skul)

Once the token has Account Analytics: Read, group by `siteTag` to list datasets and pick the one with skul's traffic (cross-check `requestHost` if exposed):

```bash
... rumPageloadEventsAdaptiveGroups(filter:{ datetime_geq:"START", datetime_leq:"END" }, limit:50, orderBy:[count_DESC]) { count dimensions { siteTag } }
```
