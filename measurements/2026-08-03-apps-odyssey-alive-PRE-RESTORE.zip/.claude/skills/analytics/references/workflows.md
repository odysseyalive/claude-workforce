# Analytics Workflows

All data comes from **Cloudflare Web Analytics (RUM)** — there is no GA4 and no Cloudflare zone analytics for this site. Every mode runs the Credentials Gate first (see SKILL.md); if creds/scope are missing it reports the gap and stops (stub mode) rather than fabricating numbers.

## Report Mode

1. **Credentials preflight** — spawn the ID Lookup agent. If NOT READY, enter stub mode and stop.
2. **Pull Cloudflare RUM data** via the GraphQL queries in [cloudflare-queries.md](cloudflare-queries.md) — daily pageloads + visits, top pages, referrer breakdown for the period. **Every query MUST filter `requestHost:"apps.odysseyalive.com"`** — the site tag is shared with `odysseyalive.com`, so an unfiltered query blends both sites (see cloudflare-queries.md § MANDATORY host filter). For periods longer than the API's per-query window, split and merge. (The window cap is ~13 weeks; a wider range errors with `code: quota`.)
3. **Read release events** — enumerate roadmap version releases from `src/lib/roadmaps.ts` → `RoadmapVersion[]`, and any module launches in the period. Resolve each release's date per SKILL.md § "Release-date sourcing".
4. **Correlate** — overlay release dates onto the traffic timeline.
5. **Evaluate** — produce a plain-language assessment:
   - Overall trend (growing, flat, declining)
   - Traffic shifts correlated with specific releases (per the Release-Correlated Evaluation Gate)
   - Top-performing pages
   - Referrer mix (where visitors come from)
   - If the period contains no releases (pre-launch case), say so and present the trend on its own.

## Release-Impact Mode

1. **Credentials preflight** — as above.
2. **Identify the release** — given a version (e.g. `v0.1.0`), resolve its ship date per § "Release-date sourcing". If undated, report the gap and stop.
3. **Define windows** — 7 days before the release date, 7 days after, and 7 days starting 30 days after (sustained impact).
4. **Pull Cloudflare RUM data** — pageloads + visits for the relevant site paths (`/`, `/modules/nsayka-wawa`, `/modules/nsayka-wawa/roadmap`) across all three windows. **Every query MUST filter `requestHost:"apps.odysseyalive.com"`** (the tag is shared with `odysseyalive.com`).
5. **Evaluate** — report immediate impact (before vs after), sustained traffic (30-day check), referrer sources during the window, and how this release compares to the average release.

> When a module actually launches (`status: coming-soon → live`), `module-impact` runs this same procedure anchored on the module's launch date and its own paths.

## Compare Mode

1. **Credentials preflight** — as above.
2. **Pull Cloudflare RUM data for both periods.** **Every query MUST filter `requestHost:"apps.odysseyalive.com"`** (the tag is shared with `odysseyalive.com`).
3. **Read release events** to identify which releases shipped in each period.
4. **Evaluate** — side-by-side: total traffic change (absolute + %), releases shipped in each period, per-release average performance, audience-growth indicators (new vs returning if exposed by RUM).

## Data Source Notes

**Cloudflare Web Analytics (RUM)** is client-side: the beacon fires when the page loads in a real browser (and only in the `live` env — `isLive && NEXT_PUBLIC_CF_BEACON_TOKEN`). It measures human pageloads and visits, not raw edge requests (there is no proxied zone here, so no server-side request counts or bot-management dimensions). It is beta and adaptively sampled — report figures as estimates.

**Shared site tag.** The configured `CLOUDFLARE_WEB_ANALYTICS_SITE_TAG` (`d0ea0dad…`) is bound to one beacon that fires on **both** `apps.odysseyalive.com` and `odysseyalive.com`. There is no dedicated skul-only dataset wired to a beacon (a separate tag `d3b02e896…` exists but receives zero traffic). Consequently **skul figures are only correct when isolated by `requestHost:"apps.odysseyalive.com"`** on every query.

**Pre-launch reality:** both modules are `coming-soon` and the beacon only fires in production, so there may be little or no RUM data yet. A correct report for an empty/sparse period says exactly that — it does not invent traffic or releases.
