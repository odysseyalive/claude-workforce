# Release Dates & Skill Integrations

## Release-event extraction

This site has no dated articles of its own. Release events come from two site-owned sources:

### Roadmap version releases (primary)
- Source of truth: `.claude/skills/odyssey-apps/references/nsayka-wawa-roadmap.md` § Versions, transcribed into `src/lib/roadmaps.ts` → `RoadmapVersion[]`.
- Each version has `version` / `title` / `summary`. **Date sourcing** is described in SKILL.md § "Release-date sourcing" (preferred: an explicit `date` field stamped by `/odyssey-apps release`; interim: git history of the roadmap source file).

### Module launches (future)
- `content/modules/*.mdx` frontmatter (`slug`, `status`, `order`, `published`). Both modules are `coming-soon` today. When one flips to live, its launch date becomes a release event for `module-impact`.

### Field Notes — NOT a release source
- `src/data/field-notes.ts` points OUT to `odysseyalive.com/focus`. Those are external articles served by a different property. **Do not** correlate this site's traffic against them.

## Integration Points

### /odyssey-apps
The analytics skill is the read-only traffic layer for the Odyssey Apps site that `/odyssey-apps` builds and deploys. It depends on `/odyssey-apps` for the release source of truth:
- `/odyssey-apps roadmap` / `release` maintain the roadmap versions this skill correlates against. If a `date` field is needed on `RoadmapVersion`, propose it through `/odyssey-apps release` via `/route` — do not hand-edit the site source from this skill.
- `/odyssey-apps module` / `module-intro` define the modules whose launches become `module-impact` anchors.

### awareness-ledger
Notable traffic patterns (a release that moved traffic, sustained vs. flash bumps) can be recorded as PAT records via `/awareness-ledger record` so they persist across sessions. Always ask the user first.

### route
Any follow-up this skill cannot complete itself (schema changes to the site, content edits, new pages) should be dispatched through `/route` to the owning skill rather than performed directly here.
