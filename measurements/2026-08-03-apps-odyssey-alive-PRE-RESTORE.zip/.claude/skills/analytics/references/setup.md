# Cloudflare Web Analytics API Setup

The site already emits Cloudflare Web Analytics via the beacon (`NEXT_PUBLIC_CF_BEACON_TOKEN`, injected client-side in production). But **reading** that data programmatically through the GraphQL Analytics API needs an account-scoped token and the site tag. Until both exist, the skill runs in **stub mode**.

## Current state (resolved 2026-05-29)

Live mode is enabled. Both prerequisites below are now satisfied:

- `CLOUDFLARE_API_TOKEN` is **account-scoped** — an account-level RUM query returns `data` (Account Analytics: Read confirmed working), no longer `authz: not authorized`.
- `CLOUDFLARE_WEB_ANALYTICS_SITE_TAG` is **set to the SHARED tag `d0ea0dad…`**, which is bound to a beacon firing on **both** `apps.odysseyalive.com` and `odysseyalive.com`. It is **not** a dedicated skul tag, so all skul queries isolate by `requestHost:"apps.odysseyalive.com"` (see cloudflare-queries.md § MANDATORY host filter). A separate skul-only tag `d3b02e896…` exists in the account but has **no beacon wired to it and returns zero data**, so it is not used.

The two steps below are retained as reference for how the account was scoped and how to locate a site tag (e.g. if a dedicated skul beacon is wired up later):

## 1. Give the token Account Analytics: Read

In the Cloudflare dashboard → **My Profile → API Tokens** (or **Manage Account → API Tokens** for an account-owned token):

- Either **edit the existing token** to add a permission, or **create a new token**.
- Add permission: **Account → Account Analytics → Read** (this is what unlocks the RUM `viewer.accounts(...)` datasets — distinct from the zone-level Zone Analytics: Read the current token has).
- Scope it to the correct account (same `CLOUDFLARE_ACCOUNT_ID` already in `.env.local`).
- If you create a *new* token, replace `CLOUDFLARE_API_TOKEN` in `.env.local` with it. If you edit the existing one, no `.env.local` change is needed.

Verify:
```bash
set -a; . ./.env.local; set +a
curl -s https://api.cloudflare.com/client/v4/user/tokens/verify \
  -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("success"))'
```

## 2. Find and set the Web Analytics site tag

The site tag is the RUM dataset id bound to the beacon — distinct from the public beacon token. Once the token has Account Analytics: Read, enumerate the account's Web Analytics sites and pick skul's:

```bash
set -a; . ./.env.local; set +a
# REST (needs Account Web Analytics read):
curl -s "https://api.cloudflare.com/client/v4/accounts/$CLOUDFLARE_ACCOUNT_ID/rum/site_info/list" \
  -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN"
# or via GraphQL, group by siteTag (see cloudflare-queries.md § "Enumerate site tags")
```

Identify the entry whose host is `apps.odysseyalive.com`, copy its `site_tag`, and add to `.env.local`:
```
CLOUDFLARE_WEB_ANALYTICS_SITE_TAG=<the site tag for apps.odysseyalive.com>
```

## Not applicable

- **No GA4 setup.** This project has no Google Analytics. (Removed when the skill was imported from odyssey-alive.)
- **No zone setup.** `apps.odysseyalive.com` is not a Cloudflare zone (jstack/nginx TLS), so there is no `CLOUDFLARE_ZONE_ID` and no zone HTTP analytics to configure.
