## Watercolor Technique Authenticity — NOT USED IN THIS PROJECT

**Superseded 2026-07-22.** This project's imagery is a drawn graphic system, not watercolour
(SKILL.md § Directive amendment; ledger DEC-2026-07-22-graphic-system-imagery).

The equivalent checks live in **[graphic-system.md](graphic-system.md)** — system drift, wrong
register, and meaning — which ask "is this the same system as its siblings?" in place of "could a
watercolourist have painted this?"

The original watercolour-physics table is preserved in the source project
(`nsayka-wawa/.claude/skills/image-eval/references/watercolor.md`) and remains correct there. It is
kept as this stub rather than deleted so that a reference to it resolves to an explanation instead
of a missing file.
