## Graphic-System Integrity

**Replaces `watercolor.md` for this project** (SKILL.md § Directive amendment, 2026-07-22). The
old file asked whether a real watercolourist could have painted the image. The equivalent question
here is: **is this the same system as its siblings, and is it free of what a technical drawing
should not contain?**

### Fail conditions — system drift

A system is recognisable because its measurements repeat. Any of these breaks it:

| Defect | What to look for | Why it fails |
|---|---|---|
| **Stroke-weight variation** | Lines noticeably heavier or lighter than sibling assets, or varying within one asset without a reason | The single strongest signal that assets are not one system |
| **Palette drift** | A hue that is not `#123A6B` navy, `#C9A227` gold, or the white/`#F4F7FA` grounds | Colour is a constant here, not a variable |
| **Gold misuse** | Gold as a fill, as body text, or anywhere on white where it must be read (~2.9:1, below AA) | Gold is a hairline, a tick, an accent mark |
| **Mark-language drift** | Station marks or glyphs drawn in a different idiom between assets | The catalog's identity depends on one glyph family |
| **Tick/spacing inconsistency** | Grid or tick intervals that differ between assets without intent | Measurement repetition IS the system |

### Fail conditions — wrong register

| Defect | Why it fails |
|---|---|
| **Text or numerals of any kind** | The model renders both badly, and neither belongs in this system |
| **Gradients, glow, or drop shadows** | The register is flat and engraved, not rendered |
| **3D or isometric projection** | This is a plan-view drawing language |
| **Hand-drawn or sketchy strokes** | The claim is precision; wobble contradicts it |
| **Blueprint inversion** (white on blue) | This is navy on white; the inversion reads as a different brand |
| **Photographic or watercolour elements** | Both are explicitly superseded for this project |

### Fail conditions — meaning

- **The piece says nothing.** State in one sentence what it communicates. If the sentence is "it
  looks nice here," it is filler and should be cut rather than fixed.
- **It reads as noise.** Density without structure is texture, not a field. There should be a
  discernible organising logic — a route, a contour, a grid, a fan.
- **It needs a legend.** The system borrows surveying's *vocabulary*, not its literalism. If a
  viewer would need a key, it has become a diagram.

### The monotony this project CAN still have

The original palette-variety rule guarded against AI sameness, and that risk has not vanished —
it has moved. Here, flag a set where every asset is **the same field type at the same density and
crop**. Variety belongs in composition: field type, density, crop, scale. Never in palette or
stroke weight.

### Quick test

Ask: **"Could these have been drawn by one hand, with one instrument, in one sitting?"**

If two assets look like they came from different tools — different line quality, different
colour, different mark vocabulary — the set fails regardless of how good each one looks alone.
