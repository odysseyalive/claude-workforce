# Image-Eval Invocation Guide

## Single Image Evaluation

After generating a single image, launch the image-validator agent:

```
Task tool with subagent_type: "general-purpose"
Prompt: "Evaluate this image for AI generation tells: [image path].
Read .claude/skills/image-eval/agents/image-validator/AGENT.md for instructions.
Return findings in the specified output format."
```

## Article Image Set Evaluation

After generating all images for an article, evaluate the set together:

```
Task tool with subagent_type: "general-purpose"
Prompt: "Evaluate this article's image set for AI tells and palette variation:
- Hero: [path]
- Inline 1: [path]
- Inline 2: [path]
Read .claude/skills/image-eval/agents/image-validator/AGENT.md for instructions.
Return findings using the article image set format."
```

The agent runs with `context: none`, providing unbiased evaluation independent of the creation conversation.

## Required Verification Steps

**Before subjective evaluation, perform these checks.** Do not skip. Do not assume images are clean.

### Signature/Watermark Check

Examine all four corners and edges for AI signatures, watermarks, or artist attributions.

**Output format:** See [output-formats.md](output-formats.md)

### Symmetry Assessment

Evaluate bilateral symmetry. Natural asymmetry is expected even in drawn work; perfect mirroring is an AI tell. (Deliberate geometric symmetry in a grid or reticle is intentional and is NOT a defect — judge by whether the symmetry is doing work.)

**Output format:** See [output-formats.md](output-formats.md)

### Palette Identification (For Article Sets)

When evaluating hero + inline images together, identify the dominant palette for each image independently.

**Output format:** See [output-formats.md](output-formats.md)

If two or more images share the same dominant palette, flag as "insufficient variation."

## Style Consistency

For this project's drawn graphic system (navy line-work on white, gold accents — see graphic-system.md; the watercolour checklist below is inert here and is retained only for reference):

- [ ] Matches wet-on-wet technique with diffused edges?
- [ ] Transparent layered washes visible?
- [ ] Medium-rough cold-press paper texture present?
- [ ] Fades softly to white paper at edges?
- [ ] Appropriate palette variant for scene mood?
- [ ] Rich and vibrant colors, not pale or washed out?
- [ ] Unfinished border with raw paper showing?
