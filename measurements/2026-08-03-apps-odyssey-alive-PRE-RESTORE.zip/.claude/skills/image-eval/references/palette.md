## Palette Consistency (INVERTED for this project)

**RETARGETED 2026-07-22.** The source file flagged a set sharing one palette as AI monotony, and
required a different palette variant per image. **That is inverted here.**

### The rule now: ONE palette, every asset

Odyssey Apps imagery is a drawn SYSTEM, not a set of independent illustrations. A system is
recognisable precisely because its colours repeat. Palette variation between assets is the
**defect**, not the goal.

| Scenario | Verdict |
|----------|---------|
| Every asset: navy line-work on white, sparing gold accents | **Good** — one system |
| One asset shifts to teal, or introduces a second accent hue | **Flag** — system drift |
| One asset uses heavier strokes than its siblings | **Flag** — drift; weight is as load-bearing as colour |
| Every asset identical in field type, density, and crop | **Flag** — the monotony this project CAN still have |
| Same palette, varied field type / density / crop / scale | **Good** — distinction where it belongs |

### The palette

| Role | Hex |
|---|---|
| Ground | `#FFFFFF` |
| Ink / structure | `#123A6B` |
| Secondary field | `#F4F7FA` |
| Accent metal | `#C9A227` |
| Dark field | `#0C2340` |
| On dark | `#F2F6FA` text, `#E8C766` gold |

**The gold rule.** `#C9A227` on white is ~2.9:1, below AA. Gold is a hairline, a tick, or a small
badge fill with dark text on it — never body text, never a link, never a button label on white.
Gold on the navy field clears AA and is the one place it may carry type. **Flag any gold that a
reader must read on white.**

Authoritative source: `.claude/skills/odyssey-apps/references/palette.md`.
