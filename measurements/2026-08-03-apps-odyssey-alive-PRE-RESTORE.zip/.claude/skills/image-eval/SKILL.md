---
name: image-eval
description: Evaluate images for AI generation tells and graphic-system integrity (Odyssey Apps: line-work consistency, palette discipline, no text artifacts). Run as Task agent for unbiased assessment.
allowed-tools: Read, Glob, Grep, Task
minimum-effort-level: high
strictness: standard
---

# Image Evaluation Protocol

**IMPORTANT:** Run this evaluation as a **Task agent** to ensure context isolation. The agent evaluates without being influenced by the conversation that created the content.

---

## Directives

<!-- origin: user | added: 2026-04-28 | immutable: true -->
> **The current room graphic for Town Square has a half a woman in the background. that's ok, only if that graphic finds it's edge at the bottom of the photo. We need to prevent this type of malformation.**

*— Added 2026-04-28, source: user instruction (inline)*
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "The current room graphic for Town Square has a half a woman in the background. that's ok, only if that graphic finds it's edge at the bottom of the photo. We need to prevent this type of malformation." -->
CHECKPOINT — Partial-Figure Canvas-Edge Anchoring (anti-floating-figure):
1. Walk every human (or anthropomorphic) figure visible in the watercolor base. For each figure, record its bounding box (x_min, y_min, x_max, y_max) within the canvas (canvas dims per nsayka-wawa-canon: 540×520 for room illustrations).
2. Classify each figure: COMPLETE (all four sides of the figure's silhouette are inside the painted canvas — head, both arm tips/sides, full torso/legs visible OR cleanly framed by canvas) vs. PARTIAL (the figure is cropped — at least one side of the silhouette is missing OR the figure ends mid-body).
3. For each PARTIAL figure: check whether the cropped edge coincides with a canvas edge (typically y_max ≈ canvas_height for a bottom-clipped figure, x_min ≈ 0 for left-clipped, etc., within a 4px tolerance for watercolor edge-bleed).
4. IF the partial figure's cropped edge does NOT touch a canvas edge → MALFORMATION. The figure is "floating" — bisected mid-canvas, neither complete nor anchored to a canvas boundary. STOP. Report: "Floating partial-figure malformation at bbox=(x0,y0,x1,y1): figure is bisected mid-canvas (cropped edge at [side]=[value]; canvas edge at [side]=[canvas-value]; gap=[delta]px). Per 2026-04-28 directive, partial figures are acceptable only when the cropped edge meets the canvas edge. Flag for image regeneration."
5. IF the partial figure's cropped edge touches a canvas edge → ACCEPTABLE per the directive. Continue to other evaluation criteria.
6. IF the figure is COMPLETE → ACCEPTABLE; not a malformation case.
7. Record findings in the evaluation report under "Partial-Figure Anchoring", listing each figure's classification and any malformation flags. The image-validator agent uses this CHECKPOINT before subjective evaluation.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- origin: user | added: 2026-04-29 | immutable: true -->
> **Don't put labels over people's faces.** Image-eval MUST flag any composited CW label whose anchor box overlaps a human (or anthropomorphic) face in the underlying watercolor. Faces are the highest-attention pixels in the frame; covering one with a cream callout reads as defacement, breaks immersion, and degrades the foreground figure's role in the scene. When evaluating any labeled room/map illustration, walk every label's bounding box, identify the watercolor content underneath, and FAIL the asset if a label intersects a face. Recovery: nudge the label's anchor outside the face's bounding box, or move the label to an alternate referent that's not face-occluding.

*— Added 2026-04-29, source: user instruction (mid-task: "I'd like to add a directive not to put labels over people's faces. that should be an image-eval thing").*
<!-- /origin -->

<!-- origin: user | added: 2026-07-22 | immutable: true | scope: this project's snapshot only -->
## Directive amendment — Odyssey Apps evaluates a graphic system (2026-07-22)

This snapshot lives in the apps.odysseyalive.com repo, whose imagery is a **drawn graphic
system** — navy line-work on white with gold accents, from surveying vocabulary — **not
watercolour and not photography** (ledger: DEC-2026-07-22-graphic-system-imagery; spec:
`odyssey-apps/references/procedures/art.md`).

**Both directives above are INERT here, and are preserved verbatim rather than deleted.** The
2026-04-28 partial-figure rule and the 2026-04-29 label-over-faces rule govern watercolour room
illustrations with human figures and composited Chinuk Wawa labels. This project generates neither:
there are no people in the imagery and no label-overlay pipeline. If either ever becomes relevant
again, the rules apply unchanged.

**What replaces watercolour-technique authenticity** is *system integrity* — see
[references/graphic-system.md](references/graphic-system.md). The question is no longer "could a
watercolourist have painted this?" but **"is this the same system as its siblings, and is it
free of the things a drawing shouldn't contain?"**

**The palette check is INVERTED.** The source flags a set that shares one palette as AI monotony.
Here, sharing one palette is REQUIRED, and palette variation between assets is the defect. See
[references/palette.md](references/palette.md).

**Unchanged and still governing:** the AI-tell catalogue in `ai-patterns.md` (text artifacts,
symmetry obsession, floating elements, and symbolic abstraction all still apply), and the visual
clarity test — a texture that reads as noise has still failed.
<!-- /origin -->

<!-- origin: user | added: 2026-04-30 | immutable: true -->
> **Labels CAN cover parts of painted objects (that is what labels are for) but MUST NEVER cover people.** The 2026-04-29 face-coverage rule extends to the whole human figure, not just the face: when a foreground waist-up figure is depicted in one of the bottom corners (per nsayka-wawa-canon), no label may overlap the figure's bounding box. Labels overlapping painted objects (door frames, stones, baskets, building walls, animals, plants) is expected, that is how the label points at the object it teaches. Image-eval distinguishes: object-overlap = OK; figure-overlap = FAIL.

*— Added 2026-04-30, source: user instruction (mid-task: "the labels might need to cover parts of objects... they should never cover people up.").*
<!-- /origin -->

<!-- origin: user | added: 2026-04-30 | immutable: true -->
> **Within-room label uniqueness; every CW label on a room image must appear at most once.** No room may have two items labeled with the same CW form (e.g., river-dock cannot label both `rope` and `fishing-line` as `lup`). When two physically-similar items appear on the painted scene, the labels must differentiate them via Tier-2 compounds (e.g. `lup` for rope, `ikʰik-lup` for fishing-line / hook-line). Image-eval MUST scan the labels.json and flag any duplicate `text` values within a single room asset.

*— Added 2026-04-30, source: user instruction (mid-task: "all rooms need to have unique labels. No one label can be reused in each room").*
<!-- /origin -->

<!-- origin: user | added: 2026-04-30 | renegotiated: 2026-05-02 -->
> **Cross-room CW-label uniqueness — DROPPED 2026-05-02.** The original 2026-04-30 directive required every items[*].cw value to appear in exactly one room. That sub-rule was renegotiated 2026-05-02 (see SKILL.md `nsayka-wawa` § Per-Room Word-Index Counts CHECKPOINT and `awareness-ledger DEC-017`): the same CW form MAY now appear in any number of rooms — `lapot` (door), `lishesh` (chair / bench), `tʼwax̣-lapot` (window), `tsəqw` (water), `paya` (fire) and other everyday items repeat naturally. Pimsleur graduated repetition benefits from seeing the same word in multiple contexts. The within-room uniqueness rule (above) STAYS enforced — no two labels in a single labels.json may share the same `text` value. Image-eval MUST NOT flag cross-room reuse as a violation; it MAY surface cross-room reuse as informational output so the user knows the spread.

*— Added 2026-04-30; renegotiated 2026-05-02 (cross-room reuse permitted; within-room uniqueness retained). Original source: user instruction "lapot should only be used by itself. It can be used in compound words, but those compound variations can only be used once". Renegotiation source: user directive 2026-05-02 (in-place audit kept surfacing "violations" the user immediately waived).*
<!-- /origin -->

<!-- origin: user | added: 2026-04-30 | immutable: true -->
> **Label font size 18pt; readable but compact.** The overlay tool's DEFAULT_FONT_SIZE is 18 (was 28). Smaller font lets more labels coexist on a 540x520 canvas, which matters for label-rich rooms (general-store, diner, cultural-center). Image-eval MUST flag labels rendered larger than 22pt (visual-density loss) or smaller than 14pt (legibility risk) when measured against the canvas dimensions.

*— Added 2026-04-30, source: user instruction (mid-task: "the labels are too big. In some cases, the labels are cover other labels and peoples faces. If the labels were smaller, we could fit more in a room").*
<!-- /origin -->

---


<!-- MODEL-LANE-GATE START — auto-generated by /skill-builder route embed; safe to replace -->
<!-- origin: skill-builder | modifiable: true -->
## Model-Lane Preflight

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: /skill-builder route embed (model-lane gate, slim form per the 2026-06-06 2-Brain Harness directive: gates are slimmed, never stripped — this block is the lane checkpoint that travels with the skill through EVERY entry path, including hand-run invocations, which are always permitted. It goes silent when /route already covered the endeavor. Advisory-only per the 2026-06-06 No-Switch-Prompt directive: the gate CANNOT switch the model and NEVER asks the user to — its entire output is one advisory line, which names the exact remedy informationally per the 2026-06-11 named-command advisory directive. -->
CHECKPOINT — Model-Lane Preflight Gate (slim, advisory-only; fires at the TOP of this skill's workflow, before any generative step):
1. SKIP silently IF ANY of: `/route` dispatched this invocation after running its own lane preflight (a lane advisory OR ask already printed, route otherwise ASSESSED the lane this turn, or it was deliberately suppressed — route's coverage extends to the whole endeavor whether route asked, matched, or the user declined, including skills this one chains); this skill's frontmatter sets `model-lane-gate: off`; the session is headless / non-interactive; this gate is executing inside a subagent (a subagent is already model-pinned via its own frontmatter); OR an advisory for this LANE already printed this endeavor AND the active model is unchanged (advise at most once per (lane, active-model) pair per endeavor).
2. Resolve this skill's lane (own `lane:` frontmatter → the Skill→Lane table in `.claude/skills/skill-builder/references/model-lanes.md` → NO LANE) and the lane's Preferred Model. IF no lane resolves OR the preferred-model cell is empty → silent no-op (correctly absent, not a gap). IF this skill declares per-function lanes AND the invocation's resolved mode has its own row → that function's lane governs; otherwise the skill-level lane covers all modes.
3. Read ACTIVE_MODEL from the session system-context line "The exact model ID is …" (strip `[1m]`/`[200k]`, lowercase — model-lanes.md § Active-Model Detection; never an env var or Bash probe). IF the Preferred Model is malformed or names a clearly superseded family → emit the one-line stale-mapping advisory and proceed; never advise from a stale mapping, never validate against a hardcoded list.
4. Compare. Match → silent no-op. Mismatch → print ONE advisory line and PROCEED: "Lane advisory: this skill declares the `<lane>` lane (preferred `<preferred>`); the active model is `<active>` — to align, run `/model <preferred>` and re-invoke; proceeding as-is." Naming the command is INFORMATIONAL (named-command advisory directive, 2026-06-11): NEVER an AskUserQuestion, never a blocking wait (No-Switch-Prompt directive, 2026-06-06). A skill can NEVER switch the session model and never asks the user to.
5. Primary-lane scope. This gate fires ONCE per invocation, for the resolved PRIMARY lane. Cross-lane mid-workflow steps never re-advise — they delegate via this skill's LANE-AGENT-EMBED Delegation Map when present (see .claude/skills/skill-builder/references/lane-delegation.md). Delegation is never a substitute for THIS gate: analytical primary work runs on the analytical main model — never a creative main session orchestrating analytical-pinned agents to dodge the lane.
<!-- END ENFORCEMENT ANNOTATION -->
<!-- /origin -->
<!-- MODEL-LANE-GATE END -->

## How to Invoke

Launch the image-validator agent via Task tool with `context: none`. See [references/invocation.md](references/invocation.md) for single-image and article-set templates, and [agents/image-validator/AGENT.md](agents/image-validator/AGENT.md) for evaluation criteria.

---

## When to Run

Execute this evaluation after:
- Generating images via Nano Banana
- Creating hero images for articles
- Producing inline images for content
- Any visual content creation

---

## Required Verification Steps

**Before subjective evaluation, perform these checks.** Do not skip. Do not assume images are clean. See [references/invocation.md](references/invocation.md) for signature/watermark, symmetry, and palette checks.

---

## Evaluation Criteria

See references for detailed criteria:
- **[Visual Clarity](references/visual-clarity.md)** — Immediate comprehension, concrete subjects, grounded imagery
- **[Common AI Image Patterns](references/ai-patterns.md)** — Symbolic abstraction, impossible lighting, uncanny artifacts
- **[Graphic-System Integrity](references/graphic-system.md)** — system drift, wrong register, meaning (replaces watercolour authenticity for this project)
- **[Style Consistency](references/invocation.md#style-consistency)** — line-work consistency checklist
- **[Output Templates](references/templates.md)** — Single image and article set evaluation formats

Cross-reference `/image` skill for full visual clarity guidelines.

---

## Important Notes

- **Required checks come first.** Always perform signature, symmetry, and palette checks before subjective evaluation. Report findings explicitly. Do not assume or skip.
- **Advisory, not prescriptive.** Flags prompt human judgment, not automatic regeneration.
- **View in context.** An image that looks off in isolation might work perfectly with the article.
- **Specificity matters.** "Looks AI-generated" is useless. "The lighting on the left contradicts the window placement on the right" is actionable.
- **Preserve what works.** Note strengths so regeneration prompts retain successful elements.
- **One pass, then stop.** Present evaluation once. Human decides whether to regenerate.
- **Be selective.** 3-5 substantive flags maximum. Don't nitpick every detail.

---

