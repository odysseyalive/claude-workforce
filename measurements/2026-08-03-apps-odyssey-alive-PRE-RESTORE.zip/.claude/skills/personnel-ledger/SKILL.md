---
name: personnel-ledger
description: "Holds this org's personnel records — EMP, PERF, DEF, AMD, RFI, ORG. Read and written through, never around."
---

# Personnel Ledger

Records live at `.claude/workforce/personnel/`. Formats: `workforce/references/personnel-templates.md`.

## Schema
One file per record, `<TYPE>-<subject>.md`. Types: EMP (one per employee, living),
PERF (incident), DEF (procedure defect), AMD (amendment), RFI (improvement), ORG (structural).

## Invariants
> **Degraded state may cause more work. It may never authorize a write.**

- Every `EMP` names a roster row that exists — `mechanical`
- Every `PERF` carries an `Attribution` — `mechanical`
- A record is append-only once written — `mechanical` (needs a stored digest)
- A `DEF` closes only by an amendment or a declared decline — `contextual`

## Degradation
absent → the org has no history and `review` says so, never "clean" · empty → same ·
stale → the index is rebuilt from the filesystem · corrupt → **stop, never rewrite**.

## Owner
HR. Exactly one Records Owner; its Lead is the second key.

## Git policy
This project is **not a git repository**. Recovery is `.claude-backups/` alone.

## Seed
An empty `.claude/workforce/personnel/` and an index stating zero records.

## Maintainers
*(none yet)* — `check-personnel-index.sh` is the mechanical invariant's maintainer
and is not written. Until it exists this row is honestly empty.
