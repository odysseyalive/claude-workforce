<!-- creative-scrub-ref-version: 2 -->
<!-- origin: skill-builder | modifiable: true -->
# Finishing Chain — the bounded text scrub loop

Executed by `/text-eval scrub`. Every step marked ◆ is a non-negotiable: removing one turns
a bounded, reversible loop into an unbounded rewrite that drifts away from the author's
voice. Follow this file literally.

---

## ◆ Step 0 — Entry provenance guard (BLOCKING)

Establish the target's provenance before touching anything:

- **AI-drafted, in this session** → the loop may auto-fix, per Step 3's severity policy.
- **Human-authored, unknown, or mixed** → **evaluate and report ONLY.** No edit, regardless
  of what the caller asked for. Say plainly that provenance downgraded the run.
- **Never** run against calibration/reference texts, style samples, or non-prose files.

If provenance cannot be established, treat it as unknown. Report-only is the safe default.

## Step 1 — Snapshot (best-so-far baseline)

Record the input verbatim as `best-so-far`, along with its baseline scores:

- `blocking_count` — number of MUST FIX + hard-directive flags
- `human_presence` — the human-presence marker density from text-tells.md § Human-presence markers

These two numbers govern Steps 6 and 7. Compute them before any edit exists.

## Step 2 — Evaluate (context-isolated)

1. Spawn `glyph-counter` (mechanical, FIRST, every cycle). ◆ **An evaluation whose output
   lacks the Verification Preamble is invalid — discard and re-invoke.**
2. Spawn `voiceprint-examiner` (fresh context) for Tier 2 + Tier 3.
3. Never run the reasoning evaluator alone; never evaluate inline in the drafting
   conversation (principle 6 — the context that wrote the prose cannot judge it).

## ◆ Step 3 — Severity policy (what may be touched)

| Class | Action |
|---|---|
| MUST FIX (cluster density 3+) | auto-fix |
| Hard-directive flags and `[hard]` catalog rows | auto-fix — never demoted by clustering, voice protection, or human presence |
| SHOULD FIX | advisory — present, do not apply |
| CONSIDER | advisory — present, do not apply (cap advisories at 3–5) |

Voice-dependent judgments are advisory-only when the project has no documented voice
profile. This project has none at scaffold time, so treat every voice-dependent flag as
advisory until a profile exists.

## ◆ Step 4 — ONE atomic fix pass

Plan every approved fix together, then apply them in a **single edit**. Serial fixes
compound drift: each edit changes the context the next one is judged against. If a planned
fix cannot be expressed in the same pass, drop it to advisory rather than opening a second
pass.

## ◆ Step 5 — Whole-document echo re-scan

Fixes introduce new tells. After the fix pass, grep the **whole document** — not just the
edited spans — for what the fixes just introduced:

- tokens or phrases the rewrites repeated (new detail latches)
- caption/heading collisions the rewrites created
- newly uniform sentence lengths where an em-dash split used to vary the rhythm
- connectives ("Furthermore," "Additionally") introduced while dissolving dashes

Then re-validate: the changed passages plus the document-level echo findings. The unchanged
bulk does not need re-reading.

## ◆ Step 6 — Best-so-far + divergence abort

Score the new version exactly as in Step 1. Compare against `best-so-far`:

- **Fewer blocking flags AND human presence not lower** → the new version becomes
  `best-so-far`. Continue.
- **More blocking flags OR lower human presence** → **revert to `best-so-far` and STOP.**
  Report the divergence and which cycle produced the kept version.

Never "last output wins." Quality oscillates between cycles; the keeper is explicit.

## ◆ Step 7 — Humanity floor

Never ship a version whose human-presence density is below the input's baseline. A reduced
tell count never justifies lost voice markers. If the only way to clear a flag is to strip a
human marker, the flag stays and becomes an advisory.

*(Advisory-only note: this project has no documented voice profile at scaffold time, so the
floor is enforced against the input's own baseline markers rather than against a profile.)*

## ◆ Step 8 — Cycle cap: 2

At most **2 fix cycles** (a cycle = evaluate → fix → re-evaluate), so at most 3 evaluations
total. On reaching the cap, stop and present — never a third cycle, never "one more pass."

## Step 9 — Present

Report, in this order:

1. Before/after of each changed passage
2. Fixes applied, with the mechanism each one addressed
3. Advisories remaining (capped 3–5, with the count suppressed)
4. Cycle history: score per cycle, which cycle is `best-so-far`, and any abort with its reason
5. Provenance verdict from Step 0, if it downgraded the run

## ◆ Never

Never optimize toward an AI-detector score. Detector-guided revision measurably degrades
quality; the loop's target is the human craft rubric. And never fabricate imperfections to
simulate humanity — that is itself a tell.
<!-- /origin -->
