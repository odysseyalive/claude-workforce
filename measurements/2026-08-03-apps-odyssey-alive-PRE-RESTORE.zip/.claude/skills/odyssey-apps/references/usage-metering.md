# Usage Metering — tokens, cost, and the admin dashboard

**Requirement (Francis, 2026-07-22):** *"any scripts that we use that interface with AI we have to
have the ability for it to track tokens and inject that into the database so that I can log into
the admin and see that the average user is using X amount of tokens a month, and that way I can
adjust the price accordingly."*

The purpose is **pricing intelligence**: what does it actually cost to serve one user one module
for one month? Everything below serves that question.

Read before building any AI feature (`module-app`) or the admin dashboard (`admin`).

---

## A. Scope — deliberately narrow at first

**IN scope now:** collect the data, store it correctly, display it graphically.

**OUT of scope, decided 2026-07-22:**

- **No per-user caps or hard limits.** Francis: *"I wasn't planning on doing a user cap … that
  would have to be part of their agreement if they purchased a slot on the server."* Limits become
  a commercial term at subscription time, not an engineering control now.
- **No enforcement, throttling, or degradation.** Nothing in this system may block a call.
- **No pricing decisions encoded anywhere.** The system reports; Francis decides.

**Why no cap is safe right now — and when that stops being true.** Module access is granted
manually, one user at a time (DEC-2026-07-22-manual-grant-vs-subscription). **The beta gate IS the
spend control**: exposure is bounded by a number Francis personally chose. That protection
disappears the moment access becomes automatic on payment. **When the subscription directive
amendment is written, revisit this file in the same change** — an automated grant path with no
cap and no alert is an unbounded liability.

---

## A-bis. The usage shape — scripted functions, NOT a chatbot

**Clarified 2026-07-22 (Francis):** *"I don't plan on using OpenRouter for any chatbot activity.
OpenRouter will only be used within the scripts that perform whatever function that I give those
scripts to do."*

Every model call is a **server-side script performing a defined job** — never a conversational
turn streamed to a user's browser. That is not a detail; it changes four things:

1. **A job may make SEVERAL model calls.** "Generate the summary" might be three calls: extract,
   draft, check. So the pricing question is not only cost-per-call — it is **cost per RUN**. See
   `runId` in § C, and § G for why it is the more useful number.
2. **Streaming is out of scope**, and with it the abandoned-stream hole. Non-streaming responses
   carry usage in the complete body. The guard in § B is retained but downgraded — if a streaming
   surface is ever added, re-read it before building.
3. **No conversation history is stored.** No transcripts, no message threads, no rolling context
   in the database. That is a meaningful privacy simplification: model *inputs* here are derived
   from data the user already gave the module, not an open-ended chat log accumulating whatever
   someone typed. Keep it that way — if a feature ever needs history, that is a new schema
   decision with its own erasure consequences, not an incremental addition.
4. **Convex action execution limits apply.** A multi-call job can outrun a single action's
   runtime. Long jobs are chunked or scheduled rather than run inline, and each chunk still meters
   its own calls (the chokepoint does not care how the work is divided).

**The decomposition this gives you** — and it is the useful one for pricing:

```
cost per user per month  =  cost per run  ×  runs per user per month
```

Those two numbers are actionable in completely different ways. **Cost per run is an engineering
number** — better prompts, cheaper models for the easy steps, caching. **Runs per user per month
is a product and pricing number** — it tells you what a subscription tier should include. An
average that collapses them together tells you something is expensive without telling you which
lever to pull.

---

## B. The chokepoint — the one rule that makes the rest work

**Every model call goes through ONE internal helper, which makes the call and writes the usage row
in the same operation. No module ever touches a provider SDK directly.**

If a module can call a provider directly, metering is optional — and optional metering is missing
precisely when a surprise bill arrives. This is not a convention; it is enforced
(enforcement-checkpoints.md § AI Metering Chokepoint Gate).

The helper lives with the AI code in `convex/` and runs in an **action** (Node runtime — model
calls are third-party network I/O). It:

1. Resolves the caller (`requireUserId`) and re-checks `hasAccess` for the module.
2. Makes the model call.
3. Reads token counts and **cost as reported by OpenRouter** (§ C) — we do not compute it.
4. Writes the raw usage row AND increments the daily rollups (§ D) — in one mutation, so a
   recorded call can never lack its rollup.
5. Returns the model result.

**Streaming — not applicable today, guard retained.** Calls are scripted and server-side
(§ A-bis), so responses are complete and usage arrives in the body. IF a streaming surface is ever
added, this hole opens: usage arrives in the final SSE message, and an abandoned stream (user
navigates away, connection drops) never delivers it, leaving real cost unrecorded. The remedy then
is to reconcile via the generation id or write the row with `costSource: "estimated"` and flag it.
Silently dropping the row is never acceptable.

**Failures still cost money.** A call that errors after the provider processed tokens, or times
out mid-stream, still bills. Record it with `status: "error"` and whatever token counts came back.
A metering system that only counts successes under-reports exactly when things go wrong.

---

## C. What to record

### `aiUsage` — the raw row, one per call

| Field | Why |
|---|---|
| `userId`, `moduleSlug` | Who and which module — the two axes every report uses |
| `feature` | The script/job name within the module (e.g. `draft-summary`). Without it, a module's cost is one undifferentiated number and you cannot tell which job is expensive |
| `runId` | **Groups every call belonging to ONE job.** A single user action may fan out into several model calls; without this you can report cost per call and cost per user, but not cost per unit of work — which is the number pricing actually needs |
| `step` | Optional position within the run (`extract`, `draft`, `check`). Turns an expensive job into a diagnosable one |
| `model` | The model that **actually answered** — from the response, never the request. With fallback routing these differ, and recording the request silently misattributes cost |
| `modelRequested` | What we asked for. Optional but cheap, and the gap between the two is itself a signal (frequent fallbacks mean a flaky primary) |
| `provider` | Which upstream provider served it, per the response |
| `generationId` | OpenRouter's id for the call — the join key for async reconciliation and for auditing against OpenRouter's records |
| `inputTokens`, `outputTokens` | The raw counts |
| `cachedTokens`, `cacheWriteTokens` | Reported by OpenRouter. Cache reads are materially cheaper and cache writes carry their own price on some models; omitting them distorts cost |
| `costMicros` | **The cost reported by OpenRouter at call time**, in millionths of a currency unit (integers — never floats for money) |
| `costSource` | `openrouter` \| `openrouter-async` \| `estimated`. Makes an unreliable number visible in a report instead of invisible |
| `durationMs` | Compute time. Convex execution is a real if secondary cost axis |
| `status` | `ok` \| `error` |
| `createdAt` | Timestamp |

Indexes: `by_user`, `by_module`, `by_user_module`, `by_created`.

### The provider is OpenRouter, and it reports cost directly

**Decided 2026-07-22 (Francis): AI calls go through OpenRouter.** That changes this section for
the better — OpenRouter reports actual cost, so **no price table is maintained in this repo**.

**Source-quality caveat:** the findings below are search-derived from OpenRouter's own docs, not
fetched and read directly (the local browser profile was locked). Confirm each against the live
docs before implementing — this API changes, and a metering system built on a stale assumption
under-reports silently. Links in § J.

What OpenRouter gives us:

- **Usage accounting is automatic.** Token counts and cost come back with every response — no
  extra call, no opt-in parameter. Reported per the model's **native tokenizer**, plus
  `cached_tokens` (read from cache) and `cache_write_tokens` (models with explicit cache-write
  pricing). For streaming responses it arrives in the **final SSE message**, which is a real
  implementation detail: a stream abandoned early may never deliver it.
- **An async path exists** — usage can be retrieved later via the generation id, which is the
  reconciliation route if the inline value is missing or a stream was cut short.

**So `costMicros` is RECORDED FROM OPENROUTER, not computed by us.** The original rule stands with
its reason intact — store cost at call time, never derive it later from a price table — but the
value is now authoritative rather than estimated. The row therefore carries a **`costSource`**
field rather than a price-table version: `openrouter` (reported inline), `openrouter-async`
(reconciled via generation id), or `estimated` (a fallback we should rarely see and must be able
to spot in a report).

### The routing trap — record the model that ANSWERED, not the one requested

OpenRouter supports model fallbacks and auto-routing: you may pass a priority list, and if the
first model errors it tries the next. **The response's `model` and `provider` fields name what
actually served the request.**

**Record those, never the requested model.** Recording the request would misattribute cost to a
model that never ran — and it would do so silently, producing a per-model cost report that looks
plausible and is wrong. Store both if useful (`modelRequested` and `model`), but the one every
report keys on is the model that answered.

Also store OpenRouter's **generation id** on the row. It is the join key for async reconciliation
and the only way to audit a specific call against OpenRouter's own records later.

## D. Rollups — daily grain, and why

**Daily, not monthly.** Francis wants *adjustable* timeframes. Monthly buckets cannot answer "last
7 days" or "last 90 days"; daily buckets sum into any window. This is cheap now and a migration
later.

### `usageDaily` — per user, per module, per day

`userId`, `moduleSlug`, `day` (`YYYY-MM-DD`, UTC), `calls`, **`runs`**, `inputTokens`, `outputTokens`,
`costMicros`, `updatedAt`. Indexes: `by_user_day`, `by_module_day`, `by_user_module_day`.

Written by increment in the same mutation as the raw row. Contention is low: concurrent writes
would have to be the same user, same module, same day.

### `usageDailyAnon` — per module, per day, NO user

`moduleSlug`, `day`, `calls`, **`runs`**, `inputTokens`, `outputTokens`, `costMicros`, `activeUsers`.
Index: `by_module_day`.

**This table exists because of GDPR erasure, and it is not optional.** See § F.

---

## E. Timezone — decide once, state it everywhere

Bucket on **UTC days**. Not because UTC is friendlier, but because a bucket boundary that moves
with daylight saving produces two 23/25-hour days a year that quietly distort any average
computed across them. The dashboard states "UTC" next to the date range rather than silently
converting.

---

## F. GDPR — the collision, and the only thing that resolves it

`aiUsage` and `usageDaily` are keyed by `userId`, so they are personal data. Erasure
(schema.md § H) **deletes them outright**, like every other row.

**That destroys the history the pricing analysis depends on.** A user erases and their cost
contribution vanishes retroactively — including from months already reviewed.

**`usageDailyAnon` is the resolution.** It carries no `userId` and is therefore not personal data,
so it survives erasure untouched. Increment it **in the same mutation** as the per-user rollup, at
call time. It cannot be reconstructed afterward — that is the entire point. Deriving it later from
per-user rows would mean the data disappears exactly when someone erases.

**Consequences:**

- Both `aiUsage` and `usageDaily` are registered in the erasure engine's table list
  (schema.md § H — the registration trap applies: a table added without registering it is silently
  never erased).
- `usageDailyAnon` is **NOT** registered, and that is deliberate. Add a comment saying so, or a
  future audit will "fix" the omission and destroy the aggregates.
- `activeUsers` on the anon table is a **count**, never a list. A list of user ids is personal data
  wearing a different name.

---

## G. The admin dashboard

Lives in the ported admin desk (`support-admin.md`) as a **Usage** panel. Admin-only, never
Support — cost data is business information, not support tooling.

### What Francis asked for

- **A line graph of usage over time.**
- **Average usage over time**, with an **adjustable timeframe**.
- **Split by module** — *"so that we can see, okay, this is how much the module is costing me to
  provide to people."* Cost-to-serve per module is the primary number; everything else is context.

### What to show alongside the average — and why the average alone will mislead

An average hides distribution. **If one power user is 60% of spend, the mean says everything is
fine right up until it isn't.** Pricing against the mean is how a per-seat product goes underwater
on its heaviest users. So show, for the selected window and module:

| Metric | What it answers |
|---|---|
| Total cost | What the module cost to run |
| **Cost per run** | What one unit of work costs. The engineering lever — prompts, model choice, caching |
| **Runs per active user** | How often people use it. The product and pricing lever |
| Cost per active user (mean) | The headline number Francis asked for — and the product of the two rows above |
| **Median** | What a *typical* subscriber costs — usually well below the mean |
| **p90 and max** | The worst case, and whether the tail is a problem |
| Active users | The denominator; a mean without it is unreadable |
| Tokens in / out | Where the cost sits — output tokens usually dominate |

Median and p90 need per-user rows for the window (`usageDaily`), so they are only available while
those users still exist; totals come from the anon table and are always available.

**Show cost per run beside cost per user, always.** They answer different questions and the pair
tells you which lever to pull: an expensive module might be an expensive job run rarely, or a cheap
job run constantly. Those need opposite responses, and the per-user average alone cannot tell them
apart.

### Charting

Route chart work through the **`/dataviz` skill** — it governs chart form, color, and layout.

**One palette constraint it must respect:** gold `#C9A227` is ~2.9:1 on white and **cannot be a
series color** on a light chart — a line a reader must trace is text-equivalent. Series colors come
from the blue family with value variation; gold is reserved for a single highlight (a threshold
line, the selected series). Same rule as everywhere else (palette.md § The gold rule).

Also: label the currency and the timezone, and never plot cost and tokens on one unlabeled axis.

---

## H. Testing (test-suite.md)

**Metering is what makes AI features testable.** Generated content is non-deterministic and cannot
be asserted on without flake — but *"a usage row was written with the right shape"* is a fully
deterministic assertion about a non-deterministic operation.

- **Dev-mode stub.** The model-call helper returns a canned deterministic response when
  `SITE_ENV=development`, exactly as `requestLoginCode` already skips SMTP and returns the code in
  plaintext for headless tests. Same proven pattern, same env var. Without it, every `verify` run
  burns real tokens — perverse in a system built to control spend.
- **The stub still writes usage rows**, with synthetic token counts. Otherwise the metering path
  is the one path tests never exercise.
- Required cases: a call writes a raw row + both rollups; an errored call is still recorded; the
  anon rollup increments without a `userId`; erasure removes `aiUsage` and `usageDaily` but leaves
  `usageDailyAnon` intact; a non-admin cannot read the Usage panel or its queries.

---

## I. Open decisions

- **Raw-row retention.** `aiUsage` grows without bound. Rollups make the raw rows redundant for
  reporting after a while — prune at 90 days? 180? Rollups are never pruned. Not urgent while
  volume is small, but decide before it is not.
- **Whether CPU/compute cost is ever surfaced separately** or stays a recorded-but-unreported
  field. Tokens will dominate; `durationMs` is recorded either way.
- **Alerting**, if any, once access stops being manually granted (§ A).

---

## J. OpenRouter references (search-derived 2026-07-22 — verify before implementing)

- [Usage Accounting — track token usage](https://openrouter.ai/docs/cookbook/administration/usage-accounting)
- [Control costs with the Analytics API](https://openrouter.ai/docs/cookbook/administration/analytics-cost-control)
- [Model fallbacks — automatic failover](https://openrouter.ai/docs/guides/routing/model-fallbacks)
- [How model routing works: providers, fallbacks, auto router](https://openrouter.ai/blog/insights/model-routing/)
- [Provider failover vs model fallbacks](https://openrouter.ai/blog/insights/reliability-failover/)
- [Pricing](https://openrouter.ai/pricing)

**Open questions to resolve against the live docs:** how OpenRouter's own margin appears in the
reported cost; whether the Analytics API is a better source for the admin dashboard's aggregates
than our own rollups (it may already answer "cost per model over time," though NOT "cost per our
user per module" — that join only exists here); and how BYOK, if ever used, changes the reported
figures.
