# Enforcement CHECKPOINTs

Auto-generated CHECKPOINT blocks for the Odyssey Apps skill directives.
Read this file on invocation for any mode that touches the site.

---

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "All site copy is authored in Francis's voice via /my-voice and /wit." (The Chinuk Wawa accuracy clause of the source directive is NOT carried — there is no second language on this site.) -->
CHECKPOINT — Content Provenance Gate (fires before writing any user-facing copy: MDX pages, module blurbs, hero text, emails, AND component-embedded UI strings — subtitles, hints, empty-states, button/link/aria labels authored in `.tsx`. Net-new component strings written during an engineering refactor are in scope even when no one set out to "edit copy"):
1. Before drafting, load Francis's voice: invoke `/my-voice`, and for marketing/persuasive copy also `/wit`.
2. Draft the copy.
3. Scan the draft for capability claims about a module. Both modules launch as gated betas, so any sentence implying the reader can DO something today must be true for the reader it is shown to. IF a claim outruns what the gate allows, STOP and correct it before the copy is written to a shipped file.
4. Run `/copy-truth check` on each user-facing functional claim in the draft against the component/flow it will render in. IF a claim asserts a capability the interface does not back up for the reader it is shown to (a claim-vs-behavior MUST FIX), STOP and correct it before the copy is written to a shipped file. This is the English-copy analog of step 3's CW gate: the interface's behavior is ground truth the way the dictionary is for CW.
5. Before presenting the draft, run the text-eval agent pair (see references/procedures/content.md).
6. IF voice load or the copy-truth gate was skipped, STOP. Report: "Copy drafted without voice load or copy-truth gate. Re-run through /my-voice + /copy-truth before shipping."
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: /model-switch skill (Integration Points). Caller-side enforcer for the creative-copy paths. /edit and /image carry their own gate in STANDALONE mode, but when this skill chains /edit it runs in CHAINED mode and /edit defers the gate to its caller (this skill). odyssey-apps has no opus-4-6-pinned authoring subagents, so without this block the creative copy paths author text with no model gate at all. Added 2026-05-28. -->
CHECKPOINT — Model Switch Gate (fires in the creative-copy modes — page, module-intro, the module-card blurb in `module`, and the "latest updates" prose in `release` — i.e., any mode whose primary work is authoring user-facing marketing/MDX copy):
1. Pre-gate. Before drafting any such copy, read the active model from the session environment block. IF it is NOT `claude-opus-4-6` → STOP and output:
   "This is creative work (site copy). Switch to the creative model: `/model opus-4-6` — then re-run the command. I'll wait."
   Do not draft until the user confirms the switch. IF already on `claude-opus-4-6` → skip silently.
2. This gate composes with the Content Provenance Gate above and fires BEFORE it (be on the creative model before loading /my-voice + /wit and drafting).
3. Post-gate. After the copy is presented, output (informational, non-blocking):
   "Creative work complete. Switch back to the code model: `/model opus-4-8`"
   The switch back MUST complete before any `test` / `verify` / `build` / `deploy` / `convex` work begins — testing and infra are always `claude-opus-4-8`.
4. This gate does NOT fire for scaffold, serve, test, verify, debug, convex, auth, module-app, beta, support, admin, roadmap, release, or deploy — those are programming/infra modes that stay on the analytical lane.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "All browser automation and visual verification use Playwright only. Never use claude-in-chrome." -->
CHECKPOINT — Playwright-Only Gate (fires before any browser-driven verification):
1. The only permitted browser-automation tool is Playwright (invoked from `test` mode scripts).
2. IF a step proposes `mcp__claude-in-chrome__*` for any purpose (playtest, screenshot, visual review) → STOP. Refuse and route through Playwright instead.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION (auto-generated for Opus 4.7+ literal execution) -->
<!-- Source directive: "The site runs in a live or development environment, set in .env via NEXT_PUBLIC_SITE_ENV..." -->
CHECKPOINT: Environment Resolution Gate (fires in serve, test, debug, deploy):
1. Read NEXT_PUBLIC_SITE_ENV. State the active environment before acting.
2. Resolve the site base URL, Convex URL/origins, and the module app URL from references/environments.md for that environment. Do not hardcode.
3. IF a live build or deploy would use a temporary/dev URL (localhost, or the dev-apps mirror) -> STOP. Use the live values.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION (auto-generated for Opus 4.7+ literal execution) -->
<!-- Source directive: "A user cannot access a module's app unless an admin has granted that user permission for that module." + "Both new modules have a beta button where people can ask to join, but access has to be given manually." -->
CHECKPOINT: Module Access Gate (fires when wiring or rendering a module's play route):
1. The /modules/<slug>/app route MUST check hasAccess(userId, moduleSlug) AND moduleAppEnabled(slug) before rendering the app, in the route layout so every nested route inherits it.
1b. Every Convex query and mutation belonging to a module MUST re-check hasAccess server-side. A route guard alone is not an entitlement — the API is directly callable.
1c. NOTHING may write moduleAccess except an explicit admin grant (grantAccess / grantAccessByEmail) or decideAccessRequest on an admin approval. IF a proposed change would let a beta request, a signup, a seeder, or any automated path confer access → STOP. That inverts the directive's core: access is given manually.
2. IF the user is not granted -> render a request-access state, never the playable app. The intro page /modules/<slug> stays public.
3. Grant and revoke happen only through the admin user-management interface (support-admin.md).
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION (auto-generated for Opus 4.7+ literal execution) -->
<!-- Source directive: "Every creation and debugging step must ... generate or update a curated Playwright test that visually views, operates, and verifies the affected part of the site, run it headless, and confirm it passes. No shortcuts." -->
CHECKPOINT: Test-Suite Verification Gate (fires at the end of EVERY mode that creates or changes the site, before presenting):
1. Identify the surface changed (route, component, flow, backend function, asset).
2. Find a test in tests/ tagged for that surface. IF none exists, AUTHOR one via `test discover`: navigate headless, screenshot for visual review, operate the real flow, assert the result (references/procedures/test-suite.md). The authored/updated test MUST be observed to FAIL before the fix and PASS after — the Regression-Guard Discrimination Gate (rule body: references/procedures/test-suite.md § The Regression-Guard Discrimination Gate). A test green on the unpatched build does not count: rebuild without the fix (or point at the pre-fix asset/bundle), confirm FAIL, restore the fix, confirm PASS. Net-new surfaces with no prior behavior use the documented one-line "no fail-before possible" exception instead.
3. Run the covering test(s) headless.
4. IF any fail, OR no real browser run occurred, OR the screenshot was not visually reviewed -> STOP. Do not present. Fix and re-run.
5. Present only after the covering test passes. Never assert imagined behavior; never skip the browser run; never use claude-in-chrome.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION (auto-generated for Opus 4.7+ literal execution) -->
<!-- Source directive: "Site UI is built with /frontend-design, using the odyssey-alive project as the visual touchstone for layout, components, and polish. Do not ship generic AI-looking UI." -->
CHECKPOINT: Frontend-Design Gate (fires in any mode that creates or edits a user-facing UI surface: build, scaffold, theme, auth, page, module, module-intro, progress, support, admin, and the debug theme/content routes):
1. Before writing or finalizing any UI markup, component, layout, or visual treatment, the /frontend-design skill MUST be loaded (invoked via the Skill tool) and used, with the odyssey-alive project as the visual touchstone.
2. Run /frontend-design's Generic-Aesthetic Detection scan on the result: no bare unstyled forms; intentional layout, hierarchy, and spacing; brand tokens from globals.css; no generic-AI look.
3. IF UI was authored or changed WITHOUT loading /frontend-design -> STOP. Report: "UI changed without the /frontend-design pass. Re-run through /frontend-design before presenting." Then do the pass before continuing.
4. This gate composes with the Test-Suite Verification Gate above; the Playwright visual review there is still required and is where the design pass is confirmed on the rendered page. Authoring copy via /my-voice does NOT satisfy this gate; layout and visual polish are a separate, mandatory pass.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION (auto-generated for Opus 4.7+ literal execution) -->
<!-- Source: 2026-05-26 migration-system enforcement (convex/schema.ts migrations ledger + convex/migrate.ts + convex/migrations/ + convex/bootstrap.ts + scripts/new-migration.mjs). Workflow-gate layer; complements the deterministic harness PostToolUse hook (.claude/settings.json + .claude/hooks/convex-migration-reminder.sh) and an awareness-ledger DEC. -->
CHECKPOINT: Data-Migration Decision Gate (fires at the end of ANY mode that edited convex/schema.ts or a top-level convex/*.ts backend function file, before presenting):
1. Determine whether this mode changed convex/schema.ts or any top-level convex/*.ts function file. Exclude convex/_generated/** (codegen) and convex/migrations/** (the migration files themselves). IF nothing under that set changed -> this gate is a no-op; continue.
2. IF such a file changed, resolve a migration decision BEFORE presenting:
   (a) DATA work (the change backfills, transforms, or drops existing rows) -> author a migration: `pnpm migrate:new <slug>`, fill its up() body, then `pnpm migrate:run`; OR
   (b) STRUCTURE-ONLY (a new table, index, or optional field that `convex deploy` reconciles with no data work) -> explicitly record in the result: "structure-only -- declarative, no data migration needed."
3. Run `pnpm migrate:verify` and confirm it passes (manifest <-> files integrity).
4. Migrations are IMMUTABLE once applied: never edit a migration that has run on any backend; create a NEW one instead.
5. IF a convex/schema.ts or convex/*.ts function change was made AND neither (a) nor (b) was resolved, OR `pnpm migrate:verify` did not pass -> STOP. Do not present. Report: "DB change made without a migration decision. Resolve (a) or (b) and pass migrate:verify before presenting." See backend.md "migrate (data migrations) + bootstrap + db:deploy".
6. This gate is the workflow layer; it composes with the deterministic PostToolUse hook (which injects the same reminder on every convex/*.ts edit) and with the Test-Suite Verification Gate above. All applicable gates must pass before presenting.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: /skill-builder route embed. Closes the dispatch-bypass gap: a /route announcement is not a substitute for a Skill tool call, and consulting /route does not license the caller to execute the target skill's procedure manually. -->
CHECKPOINT — Skill Routing Gate:
1. During this skill's workflow, IF a step requires research, web search, lookup, analysis, or any follow-up NOT already covered by an explicit tool or skill name → STOP before improvising.
2. Already-named exception. IF the current workflow step EXPLICITLY names tools or skills (e.g., "use Read", "spawn the X agent", "invoke /[skill]") → execute as written. Do NOT consult `/route` for steps already determined. Skip to your skill's next step.
3. Otherwise → invoke `/route <task description>` via the Skill tool. `/route` reads its index and either returns a target skill or reports "no match."
4. Dispatch Required. IF `/route` returns a target → the IMMEDIATE next tool call MUST be `Skill(skill=<target>, args=<derived>)`. Do NOT execute the target skill's procedure steps yourself with raw Edit / Write / Bash / Task / Agent / Read calls. The target skill's gates (asset backups, agent panels, exit tests, cascade steps, frontend-design reviews, immutable-directive checks) ONLY fire when its SKILL.md is loaded via Skill — running steps manually silently skips every gate.
5. Bypass detection. IF a Skill dispatch was just announced (yours or `/route`'s) and the next tool call is non-Skill work germane to the routed task → STOP. Print verbatim: "Route dispatch announced but Skill call skipped. Invoking Skill tool now." then issue the Skill call.
6. No-match path. IF `/route` returns "no match" → proceed with the most direct, manual approach. Document the gap; the user may want to register a skill.
7. Follow-ups loop back. After the dispatched skill returns, IF further follow-up is needed → consult `/route` again via Skill. Do not freelance the next step.
8. Auto-mode override clause. Auto-mode ("execute immediately", "prefer action over planning") does NOT override clauses 4–5. Auto-mode chooses WHAT to do; once a routing decision is on the table, the only valid next action is Skill invocation.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal execution -->
<!-- Source directive: "any scripts that we use that interface with AI we have to have the ability for it to track tokens and inject that into the database so that I can log into the admin and see that the average user is using X amount of tokens a month" (Francis, 2026-07-22) -->
CHECKPOINT — AI Metering Chokepoint Gate (fires whenever code is written that calls a model provider):
1. There is exactly ONE metered helper through which every model call passes (usage-metering.md § B). It makes the call AND writes the usage row plus both daily rollups in the same operation.
2. BEFORE writing any code that calls a provider SDK, HTTP endpoint, or third-party AI service directly from a module, a route handler, a script, or a component → STOP. Route it through the metered helper instead. A direct call is unmetered by construction, and unmetered spend is invisible precisely when it matters.
3. IF a new call path genuinely cannot use the helper (e.g. a different provider shape) → the helper is EXTENDED, never bypassed. A second unmetered path is not an acceptable outcome; a second metered path is.
4. Every recorded call stores `costMicros` COMPUTED AT CALL TIME with a `priceVersion` stamp — never tokens alone. Deriving cost later from a current price table silently rewrites historical reports whenever a provider changes prices.
5. Errored and timed-out calls are recorded too (`status: "error"`). They still consume tokens; a metering system that counts only successes under-reports exactly when things go wrong.
6. The per-module anonymous rollup (`usageDailyAnon`, no `userId`) is incremented in the SAME mutation as the per-user rollup. It cannot be reconstructed after a GDPR erasure — that is its whole purpose (usage-metering.md § F).
7. IF a model call is added without a usage row, or a usage row without its rollups → STOP. Report: "Unmetered AI call path. Route through the metered helper before proceeding."
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal execution -->
<!-- Source: playwright-mcp suite_methodology § 4, folded in 2026-07-22. Guards the autonomous build loop, which is rewarded for turning red green and would otherwise weaken assertions to advance. -->
CHECKPOINT — Test-Failure Adjudication Gate (fires on EVERY failing test, in every mode, and especially inside the autonomous `build` loop):
1. Before editing ANYTHING in response to a failure, assign exactly one verdict, from ARTIFACTS (failure screenshots, page snapshots, attachments, server-side state, clean-condition reproduction) — NEVER from the error message string. Two unrelated bugs routinely render the same user-facing error.
2. TEST-DEFECT (software right, test wrong: stale selector, wrong fixture data, timing budget, session-shape violation, mis-declared expectation, environment not established) → fix the SCRIPT, re-run to green.
3. PRODUCT-BUG (the software violates its own contract while the test's expectation matches intended behavior, reproduced under a correct freshly-verified setup) → the spec stays BYTE-FOR-BYTE UNTOUCHED. Fixing the product is a separate deliberate change with its own review. STOP the phase and report.
4. AMBIGUOUS (evidence supports both) → STOP. Present BOTH readings to Francis. NEVER default toward the side you are allowed to edit.
5. FORBIDDEN in every case, and each one ends the phase and escalates instead: deleting a failing test; marking it `.skip` / `.fixme`; loosening an assertion to match observed behavior; adding a wait to mask a race; narrowing a selector until it stops catching the defect.
6. An empty log next to a user-visible error means the failing branch has no logging — not that nothing failed. Do not read silence as evidence of correctness.
7. IF a fix was applied to a spec without a recorded verdict → STOP. Report: "Test edited without adjudication. Classify the failure before changing the spec."
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal execution -->
<!-- Source directive: "Keep everything in-house as much as possible. It's easier to maintain, it keeps costs relatively stable, and it avoids adding a bunch of third-party services with subscriptions to pay and the worry of someone else breaking it. This applies throughout all of the module building and the website." (Francis, 2026-07-22) -->
CHECKPOINT — In-House Default Gate (fires whenever a third-party service, hosted API, SaaS dependency, or paid subscription is about to be proposed, added, or assumed — in the site OR in any module):
1. STOP before naming the service as the solution. Work the preference ladder IN ORDER and state which rung the answer lands on: (a) do we not need it at all? (b) can it be built into something we already run — Convex, Next.js, jstack, nginx, cron? (c) does it warrant self-hosting a new service? (d) only then, subscribe.
2. Clause (c) is NOT the default in-house answer. Self-hosting moves cost from a subscription to patching, backups, restore drills, and being woken at 2am. "Run our own X" is less in-house than "don't need X."
3. Answer the three questions explicitly, in the proposal: is it structurally unavailable in-house? what breaks if it disappears, changes terms, or raises prices? does it hold user data (making it a processor — privacy-policy entry, likely a DPA, and beyond GDPR erasure's reach)?
4. IF it clears all three and is still the right answer → isolate it behind an interface WE control, so replacing it later is a swap and not a rewrite. Record it in modules.json `$architecture.self_hosting` alongside the audited baseline.
5. IF a proposal reaches for a subscription without working the ladder → STOP. Report: "Third-party dependency proposed without the in-house ladder. State rungs (a) and (b) before proposing (d)."
6. This gate governs NEW additions. The audited baseline (OpenRouter, Turnstile, SMTP, Mailchimp, Square, GitHub) is permitted as recorded in SKILL.md § Directive amendment; each carries its stated reason, and Mailchimp is explicitly flagged as the most plausible candidate to bring in-house later.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal execution -->
<!-- Source directive: "The database itself needs to be set up so that it is on the server and not inside the box. That way, if something happens to that box, that data is still there and it can also be backed up. It also needs the appropriate permissions... we really need to stick to this infrastructure where actual data that's being served is outside the box. Regardless of whether it's convex or a web server or what." (Francis, 2026-07-22) -->
CHECKPOINT — Data-Outside-The-Container Gate (fires on ANY change to docker-compose, a Dockerfile, a deploy artifact, or any code that writes a file at runtime — in the site OR any module):
1. Enumerate every path the change causes to be WRITTEN at runtime. For each, answer: does it resolve to a HOST BIND MOUNT, or does it land inside the container?
2. Inside the container → STOP. Containers are destroyed and recreated on every image update and config change; data written there is lost during a ROUTINE SUCCESSFUL DEPLOY, with nothing appearing to go wrong. Move it to a host path under the site directory.
3. A NAMED or ANONYMOUS docker volume is also not acceptable here. It survives recreation but is opaque to inspection, awkward to back up, invisible to jstack's site backup, and destroyed by `docker compose down -v`. Use an explicit host bind mount. The verified compose declares NO named volumes; keep it that way.
4. Applies to every persistence, not just the database — caches, queues, search indexes, generated files. "It's only a cache" is not an exception: a cache you cannot inspect or back up is a cache you cannot debug.
5. Uploaded and generated BINARIES go into Convex file storage (backups.md § A-bis), which lands in the same bind-mounted host path. Never write user files to the container filesystem, and never to a path outside the site directory.
6. PERMISSIONS are part of the change, not a follow-up. The host directory must be writable by the container's uid, following jstack's convention (ownership `user:docker-group`, mode `770`). Verify by writing a row and reading the file back AS THE BACKUP USER — wrong ownership fails in two confusing ways: the container cannot write, or the backup silently cannot read.
7. NEVER state that `docker compose down -v` wipes this data. It does not — `-v` removes named volumes, and the data is a host bind mount. Wiping means stopping the stack and deleting the host directory.
<!-- END ENFORCEMENT ANNOTATION -->
