# odyssey-alive Templates Inventory (secondary reference)

**Read [port-inventory.md](port-inventory.md) first.** `scaffold` ports the working site from
nsayka-wawa; that file is the primary source list. This file is the **fallback**: odyssey-alive
is where the design system originated, and it stays the **visual touchstone** for layout,
components, motion, and polish. Reach for it when the port lacks something, when you need to see
the original intent behind a ported component, or when running `debug og-parity`.

All paths are under `/home/francis/lab/odyssey-alive`. Read-only — never write into it.

## Stack (the shared ancestor)

Next.js 16 (App Router), pnpm, TypeScript strict, Tailwind v4 (`@tailwindcss/postcss`),
Velite 0.3 for MDX, Framer Motion, Sharp, Resend + Nodemailer, `@marsidev/react-turnstile`.
`next.config.ts` uses `output: "standalone"` (required for the Docker build). This is the same
stack the port carries, one generation on.

## Build config

- `next.config.ts` (standalone output, Velite plugin, redirects)
- `velite.config.ts` (collections: posts/projects/presentations — the port's `modules`
  collection descends from `presentations`)
- `tsconfig.json` (path aliases `@/*` → src, `#site/content` → .velite)
- `package.json` (dev on 3030; this site uses **3050**)

## Theme

- `src/app/globals.css` — the CSS-variable palette + `@theme`. The `theme` mode rewrites these
  per [palette.md](palette.md): white surface, blue accent, and a **new gold family**
  odyssey-alive does not have.

## Layout + UI components (the touchstone)

- `src/components/layout/Header.tsx` (nav + pulse dot), `Footer.tsx` (newsletter + 4-col grid +
  socials), `HeaderContext.tsx`, `TransparentHeader.tsx`
- `src/components/ui/Button.tsx` (variants; primary uses the accent token)
- `src/components/ui/JsonLd.tsx`, `Breadcrumbs.tsx`, `CookieConsent.tsx`
- `src/lib/schema.ts` (JSON-LD generators), `src/lib/utils.ts` (`cn`, date helpers)

## Pages worth reading for intent

- `src/components/marketing/HomeContent.tsx` — the home shape (hero, featured, services, preview,
  newsletter CTA). This site's home is authored fresh (`page home`), but the section rhythm and
  motion are the reference.
- `src/components/presentations/PresentationsContent.tsx` +
  `src/app/(marketing)/presentations/page.tsx` — the ancestor of the `/modules` 2-col card grid.
- `src/app/(marketing)/contact/page.tsx` + `ContactContent.tsx` — contact info is reused verbatim:
  `francis@odysseyalive.com`, (971) 257-5489, linkedin.com/in/francismeetze.
- `src/app/(marketing)/privacy/page.tsx`, `terms/page.tsx` — the basis for this site's legal
  pages, adapted for its data (content.md § Legal pages).
- `src/app/(editorial)/focus/[slug]/page.tsx:35-83` — the `generateMetadata` pattern the module
  detail page mirrors (parity-with-odyssey-alive.md, `debug og-parity` step 3).

## Server actions (security)

- `src/lib/actions/newsletter.ts` — honeypot + 3s cookie timing + Mailchimp `status:"pending"`.
  This site adds Turnstile (odyssey-alive's newsletter lacks it) and posts to **odyssey-alive's
  audience** — the same list, so preserve the upsert-on-existing behavior rather than
  reimplementing it, or a person who subscribed on the parent site will collide here.
- `src/lib/actions/contact.ts` — Turnstile verify (`verifyTurnstile`), SMTP send.
- The registration and **beta-request** actions follow the same `verifyTurnstile` pattern. All
  four public forms (signup, contact, newsletter, beta request) gate on Turnstile.

## Env keys (names only)

Reused **verbatim from odyssey-alive, audience included**: `MAILCHIMP_API_KEY`,
`MAILCHIMP_SERVER`, `MAILCHIMP_AUDIENCE_ID` (same newsletter, one list),
`NEXT_PUBLIC_TURNSTILE_SITE_KEY`, `TURNSTILE_SECRET_KEY`, `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`,
`SMTP_PASS`, `CONTACT_EMAIL`.

AI (new for this site, 2026-07-22): `OPENROUTER_API_KEY` — set on the **Convex backend**
environment (`npx convex env set`), not the Next build, since model calls run in Convex actions.
Never `NEXT_PUBLIC_`: a provider key in client-side JS is a key someone else spends.

Backend (from the port + research-log.md): `NEXT_PUBLIC_CONVEX_URL`, `CONVEX_SELF_HOSTED_URL`,
`CONVEX_SELF_HOSTED_ADMIN_KEY`, `CONVEX_CLOUD_ORIGIN`, `CONVEX_SITE_ORIGIN`, `JWT_PRIVATE_KEY`,
`JWKS`, `SITE_URL`, `SITE_ENV`, `ADMIN_USER`, `ADMIN_USERNAME`, plus `NEXT_PUBLIC_SITE_ENV`.

Document all in `.env.example`; real secrets stay in `.env.local` (gitignored). **Generate this
site's own Convex auth keys** — never reuse nsayka-wawa's signing key.

## Fonts

Inter (body) + Playfair Display (serif headings). Gentium Plus is **not** carried — it existed
for Chinuk Wawa.
