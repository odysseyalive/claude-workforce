# Module Connectors (single repo, first-party modules)

Everything lives in **one repo**: the website and both module apps. A module here is not a
foreign artifact embedded in a page — it is a **first-party Next.js route tree** that shares the
site's accounts, theme, entitlements, and Convex backend. That is the structural difference from
odyssey-skul, where a module was a compiled Glulx game loaded into an interpreter.

Consequences of that difference, all of which simplify things:

- No same-origin constraint to protect (there is no interpreter to intercept).
- No opaque save blob — module state is normal, typed, per-account Convex tables.
- No asset staging of foreign build artifacts, no Git LFS, no `stageModuleGame()`.
- The entitlement gate is unchanged: a route-level check on `moduleAccess`, server-side.

## The registry

[modules.json](modules.json) maps each slug to its routes, content, Convex state, assets,
serving URLs, and access model. Read it at the start of any mode that reaches a module:
`module`, `module-intro`, `roadmap`, `release`, `module-app`, `beta`, and `image` when the
target belongs to a module.

State which entry and field you are using, e.g. "I will scaffold into
`modules.sign-me.routes.app` = `src/app/(app)/modules/sign-me/app/`."

## How each mode uses the registry

- **module:** adds the registry entry + the Velite MDX file + the `/modules` listing card.
- **module-intro:** authors `/modules/<slug>` from the entry's tagline and product scope, and
  places the Request-beta block ([beta-access.md](beta-access.md)).
- **module-app:** scaffolds or extends `routes.app`, wires `convex.state`, and enforces the
  entitlement gate. **Refuses to invent product scope** when `product_scope` is still OPEN.
- **roadmap / release:** site-owned content, grounded by inspecting the module's own source in
  this repo — percentages are read from the code, never guessed.
- **beta:** reads `access.beta_request` to know which modules render the button.
- **image:** resolves output paths from `assets.images`.

## Product scope is a gate, not a detail

Both modules currently carry `product_scope: OPEN`. Francis named *what they are* ("real estate
AI", "a DocuSign clone for real estate") but not *what the beta ships*. `module-app` must
workshop that with him and write the outcome into modules.json before building. Surfacing the
gap is correct behavior; guessing a feature set and building it is not.

For `sign-me` specifically, the registry flags a hard constraint: an e-signature product carries
evidentiary requirements (append-only audit trail, immutable stored documents, signer identity
and consent records). Research that on the coding lane and design the schema around it from the
start — retrofitting an audit trail onto a table that was not built for one is a rewrite.

## Cross-project references

- `/home/francis/lab/nsayka-wawa` — the **port source** (site half). Read-only. See
  [port-inventory.md](port-inventory.md).
- `/home/francis/lab/odyssey-alive` — the parent marketing site and the **visual touchstone**
  for layout, components, motion, and polish. Read-only. See
  [templates-inventory.md](templates-inventory.md).
- `/home/francis/lab/jstack` — the Docker hosting stack this deploys through
  ([procedures/deploy.md](procedures/deploy.md)).

Never write into a sibling repo, and never symlink across repos — jstack clones only this one.

## Not carried over from odyssey-skul

- **Field Notes.** odyssey-skul's home page pulled an anthropology feed from odysseyalive.com's
  `/focus`. This site has no equivalent rail and the consumer script is dropped
  (port-inventory.md § B). If a "from the blog" rail is wanted later, the producer/consumer feed
  contract already exists upstream and can be revived deliberately.
- **The progress emission channel.** There is no in-app turn loop to read state from; each
  module owns its own state directly.
