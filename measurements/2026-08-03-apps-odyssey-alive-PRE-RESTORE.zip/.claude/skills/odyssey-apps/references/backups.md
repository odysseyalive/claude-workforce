# Backups and Recovery

**The scenario this exists for: the VPS is gone.** Not a bad deploy — the box. What survives, and
how long does it take to be serving again?

Read before `deploy`, and before any change to what the site stores.

---

## A. What is actually at risk

| Data | Where | If lost |
|---|---|---|
| Accounts, profiles, module grants | Convex | Users cannot log in and have no access. Recoverable only by re-registering everyone and re-granting by hand |
| Support tickets and messages | Convex | Conversation history gone; open issues lost silently |
| Beta requests (`accessRequests`) | Convex | The waitlist — the thing the site exists to collect before the product does |
| **Usage / cost history** (`aiUsage`, `usageDaily`, `usageDailyAnon`) | Convex | **UNRECONSTRUCTABLE.** It records calls that already happened. There is no re-running them, and it is the entire basis for pricing (usage-metering.md) |
| Secrets (`.env.local`) | Host filesystem | Convex admin key, `JWT_PRIVATE_KEY`, SMTP, Turnstile, OpenRouter, Mailchimp |
| Site code | Git remote | Already backed up — that is what the remote is |
| Generated assets, `node_modules`, `.next` | Host | Rebuildable. Do not back these up |

**The asymmetry worth internalising:** everything above has a painful-but-possible recovery path
except usage history. Back that up as though it were accounting data, because functionally it is.

**One mercy:** losing `JWT_PRIVATE_KEY` invalidates every session but locks nobody out — auth is
passwordless, so users simply request a new code. There is no password-reset cascade. Regenerate,
redeploy, move on.

---

## A-ante. The precondition: data is on the SERVER, not in the container

None of this works if the data is inside a container. A container is destroyed and recreated on
every image update — **data written inside it is lost during a routine, successful deploy**, and
there is nothing to back up in the first place.

The invariant, in full, is backend.md § Database persistence: an explicit **host bind mount**
(`./data/convex:/convex/data`), never a named volume, never the container's writable layer,
resolving on the VPS to `jstack/sites/apps.odysseyalive.com/data/convex` — inside the directory
jstack's site backup already covers, with jstack's own ownership convention applied.

**Two consequences for this file.** Bind-mounted data is *directly* copyable, which is what makes
the § C export practical at all. And it survives `docker compose down -v` — that command removes
named volumes, of which there are none, so it is NOT a wipe. Deliberately wiping means deleting the
host directory.

---

## A-bis. ONE backup surface — every binary lives in Convex

**Rule (Francis, 2026-07-22):** *"We want to save the documents that are uploaded to the Convex
database itself so that when we back up the database we're backing up everything and we're not in
loss of anything. We're not having to back up files or commit files to your repository."*

**Every user-supplied or generated binary — uploaded documents, signed PDFs, exports, attachments —
is stored in Convex, never on the host filesystem and never committed to the repo.** This binds
every module, present and future. SignMe is the obvious case; it is not the only one.

**Why this is worth a rule rather than a preference:** a second storage location is a second thing
to back up, on a second schedule, with a second failure mode — and it fails asymmetrically. The
database restores cleanly, the documents don't, and you discover it when someone asks for a signed
agreement. One surface means one backup, one restore, one thing to verify, and one place where
GDPR erasure has to reach.

**Use Convex FILE STORAGE, not a bytes field on a document.** Documents carry a per-document size
ceiling; a stored file is referenced by its storage id from a normal row. Putting a multi-megabyte
PDF into a document field works right up until it doesn't, and the failure lands at upload time in
front of a user.

**The consequences to accept knowingly:**

- **Backups get much bigger, and rotation becomes a disk budget.** A full daily snapshot of a
  document-heavy database copies every document again. Seven dailies means seven copies of every
  PDF ever uploaded. Options if that bites: shorten daily retention, or move to a
  deduplicating snapshot tool (restic/borg store identical blobs once across snapshots, which suits
  this shape almost perfectly). Start with plain daily zips per § C; revisit when size, not
  principle, forces it.
- **Erasure reaches the files automatically** — a real benefit. Files referenced by an erased
  user's rows are deleted with them, rather than orphaned on a disk nobody audits.
- **BUT for `sign-me` this collides with evidentiary retention.** A signed agreement may need to
  outlive its uploader's erasure request. That tension is already flagged
  (`modules.json` → `sign-me.privacy_flag`) and is a question for Francis and a lawyer, not a
  default to pick silently. The erasure engine should support "retained with justification" as a
  per-table state before that module ships (schema.md § H).
- **The repo stays code-only.** No committed binaries, no Git LFS — consistent with
  deploy.md § No large binaries.

---

## B. jstack covers infrastructure; it does NOT safely cover the database

`/home/francis/lab/jstack` ships `./jstack.sh --backup` (full and per-site), documented cron,
`scp`/S3 remote copy, and GPG encryption. Use it — do not build a parallel system for the parts it
already does.

**But its site backup is `tar czf … -C "$SITE_DIR" .`** — a file-level copy of the site directory
**while services are running**. For static files and config that is fine. For a live database it is
not: a tar taken mid-write yields a torn, possibly unrestorable snapshot, and it does so
**silently**. The tar succeeds. The archive looks right. It fails at restore, which is the one
moment you cannot afford it.

**So: never rely on the file-level tar as the database backup.** Take a logical export instead.

**Also verify before relying on restore:** jstack's restore path extracts with `tar xzf "$FILE" -C /`,
while a *site* backup is created with paths relative to `$SITE_DIR`. Those two conventions do not
obviously agree, and a mismatched restore would scatter files rather than land them. Test a
restore into a scratch directory before trusting it with the real one. (Observation from reading
the script, 2026-07-22 — not a conclusion. jstack is a sibling project; verify there, and never
edit it from this repo.)

---

## C. The daily job — one zip, rotated

**Requirement (Francis, 2026-07-22):** *"a cron job backup process where there is a zip file
created each day that backs up the complete Convex database, and then it needs to be rotated so
that I don't run out of memory."*

**A logical export, not a file copy.** The job takes a consistent snapshot the database itself
produces — never bytes copied from underneath a running process (§ B).

### The job

1. **Export Convex** — the whole deployment, tables **and file storage** (§ A-bis: the documents
   are the point).
2. **Zip it**, date-stamped: `convex-YYYY-MM-DD.zip`.
3. **Write it into the site directory** (`sites/apps.odysseyalive.com/backups/`) so jstack's
   existing site tar, cron, remote copy, and GPG encryption carry it for free.
4. **Rotate** — delete snapshots older than the retention window, by count not guesswork, so disk
   use has a hard ceiling instead of a slow leak.
5. **Log the outcome, including size.** A silently shrinking backup is the signal that something
   stopped being included.

Ordering in cron matters: **export first, then jstack's tar.** A tar that captures yesterday's
export loses a day for no reason.

### VERIFY BEFORE SCHEDULING — file storage is the trap

**Confirm the exact export command against the installed Convex version** (`npx convex export
--help`, plus the self-hosted docs), and specifically confirm **whether file storage is included
by default or requires a flag.**

This is the single highest-risk detail in this file. If file storage needs an opt-in and the job
omits it, the backup runs green every night, the zip has a plausible size, and **every uploaded
document is missing** — discovered only at restore. A backup that silently excludes the most
valuable content is worse than no backup, because it stops anyone from looking for one.

Record the verified command in `deploy/` and the finding in research-log.md.

### Rotation and disk

Retention is a **disk budget**, not a policy preference, precisely because documents live in the
database (§ A-bis). Before fixing the window, estimate: average document size x expected uploads x
retention depth. Then:

- **Alarm on free space, not just on job failure.** The failure mode is the disk filling and the
  *next* backup failing — so the first thing you lose is the backup, silently, while the site keeps
  running normally.
- Rotation deletes by count and by age, and runs **after** a successful export, never before. A
  rotation that runs first, then fails to export, quietly reduces your recovery depth by one every
  single night.

## D. Offsite, encrypted, rotated

- **Offsite is not optional.** A backup on the same VPS protects against a bad deploy, not against
  the scenario in the first line of this file.
- **Encrypt before it leaves the box.** These archives contain names, emails, support
  conversations, and — if `.env.local` is inside the site dir — every secret the site holds. jstack
  documents the GPG path; use it. An unencrypted backup in object storage is a breach waiting for
  a misconfigured bucket.
- **Rotation:** 7 daily, 4 weekly, 3 monthly is a reasonable starting default — but see § C, where documents-in-the-database make this a disk-budget decision rather than a free choice. Long enough to
  survive a corruption you notice late; short enough to bound the GDPR exposure in § E.
- **Store the encryption passphrase somewhere that is NOT the VPS and NOT this repo.** A backup you
  cannot decrypt is not a backup. This is the single most common way a working backup system still
  fails.

---

## E. GDPR — erasure versus backups

Backups contain personal data, including of people who have since been erased. Immediately
rewriting historical archives on every erasure request is neither expected nor practical. The
accepted position, which must be **written into the privacy policy rather than merely assumed**:

1. Backups are retained on a **bounded, documented rotation** (§ D). An erased person's data ages
   out of the backup set within that window.
2. Backups are used for **disaster recovery only** — never mined, never queried, never restored
   selectively to retrieve one person's data.
3. **A restore MUST re-apply every erasure that happened after the snapshot.** This is the clause
   people miss: restoring a backup silently resurrects erased accounts, turning a completed
   erasure into an ongoing violation with no one aware of it.

**Clause 3 has an operational requirement:** keep an **erasure log** — user id and timestamp only,
never the erased identifiers (schema.md § H). Without it there is no way to know who to
re-erase after a restore. That log is small, non-personal, and it is the only thing that makes
clause 3 executable rather than aspirational.

---

## F. An untested backup is not a backup

**Run a restore drill before launch, and periodically after.** Into a scratch environment, never
over the live one:

1. Take a backup by the normal automated path — not a special hand-run one.
2. Restore into a scratch directory / disposable stack.
3. Bring up Convex against the restored data.
4. **Verify substance, not file presence:** a known user exists, their module grants are intact, a
   support ticket reads correctly, and usage rows are present for a known date.
5. Record the wall-clock time it took. That number is your actual recovery time, and it is usually
   several times what anyone estimates.

A drill that only confirms the archive extracts has verified tar, not the backup.

---

## G. What "recovered" means — write the runbook

Document the full path in `deploy/`, because it will be needed on the worst day, possibly by
someone tired:

1. Provision a box; install Docker, git, git-lfs is NOT needed (deploy.md § No large binaries).
2. Clone the repo from the git remote — **the code is not in the backup and does not need to be**.
3. Restore secrets (`.env.local`) from wherever they are kept — **not from the same place as the
   backups**, or one compromise takes both.
4. Restore the Convex export; bring the stack up; `pnpm db:deploy`.
5. **Re-apply post-snapshot erasures** (§ E clause 3).
6. Re-point DNS; reissue TLS via jstack/certbot.
7. Run `/odyssey-apps verify` against the restored site before calling it done.

---

## H. Open decisions

- **Retention depth vs disk**, once document volume is real (§ A-bis, § C). Whether to stay on
  plain daily zips or move to a deduplicating snapshot tool.
- **Backup frequency.** Daily, per the 2026-07-22 requirement. Usage and tickets accumulate
  continuously; a day's loss is survivable but not free.
- **Where offsite lives** — another box, S3-compatible object storage, or both.
- **Whether `.env.local` is inside the backed-up site directory.** Convenient for recovery,
  and it makes encryption strictly mandatory rather than merely advisable.
- **Retention window** — must match whatever the privacy policy ends up stating (§ E).
