# Palette: professional blue + white + gold (PROPOSED; finalized at site-build)

Per Francis: **a professional blue, white and gold.** White is the ground, blue is the structural
accent, gold is the signature metal. The exact hexes below are a starting point; every graphic,
the logo, the favicon, and all site imagery get reviewed with Playwright on the rendered site
during creation and adjusted then (see "Build-time graphics review").

This is the deliberate break from odyssey-skul, which kept odyssey-alive's warm cream surface.
Here the surface is **white** — a cleaner, more corporate ground appropriate to business software.

## Token map (relative to odyssey-alive `src/app/globals.css` @theme)

| Token | odyssey-alive | Odyssey Apps | Role |
|-------|---------------|--------------|------|
| `--brand-bg` | `#FDF8F0` (warm cream) | `#FFFFFF` (white) | main surface |
| `--brand-cream` | `#F7EDE2` | `#F4F7FA` (cool off-white) → rename `--brand-surface` | secondary surface, section bands, cards |
| `--brand-accent-primary` | `#FFA07A` (coral) | `#123A6B` (deep professional blue) | headings, links, primary CTAs, the nav dot |
| `--brand-accent-hover` | coral lighten | `#1D5A9E` (brighter blue) | hover/active |
| `--brand-accent-soft` | `#FFE0A8` | `#E3ECF5` (pale blue) | soft fills, badges, quiet backgrounds |
| `--brand-gold` | *(none)* | `#C9A227` (muted brass) | **the signature metal**: rules, icon strokes, focus rings, "beta" badges, accent underlines |
| `--brand-gold-hover` | *(none)* | `#E0B93C` | gold hover / active |
| `--brand-gold-soft` | *(none)* | `#F6EDD2` | gold-tinted fills |
| `--brand-ink` | `#4A3828` (warm brown) | `#16202B` (near-black slate) | body copy on white |
| `--brand-muted` | — | `#5A6B7C` | secondary text, captions |
| `--brand-border` | — | `#DCE3EA` | hairlines, card borders, table rules |
| `--brand-footer` | `#3B2F25` | `#0C2340` (deep navy) | footer / dark hero background |
| `--brand-on-dark` | — | `#F2F6FA` body, `#E8C766` gold-on-navy accent | text on the navy footer/hero |

Keep the type stack **Inter (body) + Playfair Display (serif headings)**. Gentium Plus is dropped
— it existed for Chinuk Wawa and has no role here.

## The gold rule (non-negotiable, contrast)

**Gold is a metal, not a text color on white.** `#C9A227` on `#FFFFFF` is roughly 2.9:1 — below
WCAG AA for body and large text alike. So:

- Gold IS for: rules and dividers, icon strokes, focus rings, small badge fills (with dark text
  on them), underline accents, chart/stat marks, borders on hover.
- Gold is NOT for: body copy on white, links on white, button labels on white, or any run of
  text a user must read.
- Gold-on-navy IS legible: `#E8C766` on `#0C2340` clears AA comfortably. Gold text is permitted
  there and in the footer/dark hero only.
- Every gold usage gets checked in the `theme` sweep and again at the Playwright visual review.

Blue `#123A6B` on white clears AAA for body text, so blue carries every text role gold cannot.

## Image guidance (for `/odyssey-apps image`) — A DRAWN GRAPHIC SYSTEM

Ratified 2026-07-22, **superseding** both odyssey-alive's watercolour and this project's own
earlier "real-life images" direction. Full specification: [procedures/art.md](procedures/art.md).

The system is built from surveying vocabulary — the line that indexes many points, station marks,
bearings, contour fields, instrument geometry. It is the platform metaphor drawn rather than
described, and it is vertical-neutral by nature, which matters because the catalog will grow past
real estate.

How the palette lands in it:

- **White is the ground.** Line-work needs air; a crowded field kills the precision that is the
  whole point.
- **Navy is the ink and the field.** Structure lines, filled bands, dark hero panels.
- **Gold is the hairline, the tick, and the accent mark** — never a fill and never body text on
  white (§ The gold rule). Sparse gold is what makes the system read as engraved rather than as a
  diagram; generous gold makes it look like a chart.
- **Stroke weight is a token, not a per-asset choice.** A system is recognisable because its
  measurements repeat. Fix the weights and the tick spacing once, reuse everywhere.
- **Authored as SVG wherever it is line-work** — recolours from these tokens directly, so a
  palette change restyles the whole system without regenerating anything (art.md § SVG first).
- Brand marks stay flat graphic in the same language: navy with a gold accent, legible at 16px,
  transparent where they sit on the navy footer.

## Build-time graphics review (deferred, mandatory)

Hexes and graphics are not finalized on paper. When the site is built, EVERY graphic (the logo, the
favicon, hero and section graphics, OG images) is reviewed with Playwright on the actual
rendered page and adjusted during creation: hairline weights against the white surface, gold
contrast on both white and navy, legibility of blue on white, and transparency where a mark must
float on the navy footer. This pairs with the Test-Suite Verification gate and the visual
self-review discipline.

## Apply sweep (theme mode)

1. Replace odyssey-alive's warm cream `@theme` surface tokens with the white/off-white pair, and
   ADD the three gold tokens (odyssey-alive has no gold family — this is new, not a swap).
2. Grep components for `brand-coral` and coral hexes; repoint to `--brand-accent-primary`
   (blue). Known touch points: HomeContent CTAs, Header nav underline + pulse dot, Footer links,
   Button primary. Because the port comes from nsayka-wawa, also grep for its navy/cream tokens
   (`#1E3A5F`, `#2C5F8A`, `#FDF8F0`, `#F7EDE2`, `#142233`) — those are what actually ship in the
   copied source.
3. Place gold deliberately, not by find-and-replace: it is the accent that appears a few times
   per page, not a third body color. Audit every insertion against § The gold rule.
4. Run `test` and verify with Playwright that blue renders as the accent, gold appears only in
   permitted roles, and contrast holds at both viewports.
