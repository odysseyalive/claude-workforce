# Meridian — Interview Queue

**Purpose:** questions staged for the practitioner, carried across sessions until asked and answered.
**Created:** 2026-07-28 · **Status:** all pending, nothing asked yet.

This file is the standing queue. `meridian-workflow-notes.md` is the *record* — answers go there,
verbatim, and the question here is marked `answered` with a pointer. Never paraphrase her answers into
this file; this file holds questions, the notes hold testimony.

## How to use this file

- **Read it before any session that touches Meridian's county-records or research surface.** The
  questions below gate `DEC-2026-07-28-county-adapter-registry`; Q1 gates the build order outright.
- **Ask in batches, in the order given within a batch.** Batch A is ordered deliberately: the
  decisive question is last so the earlier ones do not prime it.
- **Update in place.** Change a question's `Status:` line to `asked YYYY-MM-DD` or
  `answered YYYY-MM-DD → notes.md § <section>`. Do not delete answered questions — a question that
  turned out to be the wrong question is itself worth keeping.

## Framing rules — these are not optional

Per CLAUDE.md and `modules.json → meridian.positioning.source_of_truth`:

1. **"What did you do and resent," never "what features do you want."** She is not being asked to
   design software. She is being asked what happened.
2. **Past tense, specific instance, not general description.** She has twice stayed abstract about
   research ("get to work on what they're wanting to know"). The fix is to ask about *the last time*,
   not about *usually*.
3. **Do not demo the Tillamook extraction before Batch A is complete.** Showing her a working tool
   converts every subsequent answer into politeness about the tool. If she asks what prompted the
   questions, "I was poking at county records and want to know if they're even useful" is honest and
   non-leading.
4. **A "no" is a result, not a failure.** If the answers establish that MLS already covers this, the
   correct outcome is to drop the county feature. `meridian-workflow-notes.md` line 675 already
   raises that possibility explicitly.

---

## Batch A — gates the county-records line entirely

### A1. Which counties?
**Status:** pending · **Unblocks:** build order for DEC-2026-07-28-county-adapter-registry

> "Over the last year, the properties you've shown or listed — which counties were they in? Is it
> always the same one, or does it move around?"

**Why it matters:** her MLS association subdomain is `CLT` — probably Clatsop
(`DEC-2026-07-22-mls-data-access` § Amendment) — but the property we examined is in Tillamook. If the
answer is "both," two adapters are needed on day one and the long-tail risk arrives immediately.
Tillamook and Clatsop run entirely unrelated systems; there is no shared work between them.

**Follow-up if she names more than one:** "Roughly how does it split? Is one of them most of it?"

---

### A2. The last walk-in, step by step
**Status:** pending · **Unblocks:** whether a research surface exists at all

> "Think of the last person who walked in and asked you about a specific property. Between them
> asking and you giving them an answer — what did you actually do? Walk me through it."

**Why it matters:** `meridian-workflow-notes.md` line 323 — "She has never described the research
mechanics… Building a research tool without that is inventing a surface." This is the question that
closes that gap, and it is the single most important one in this file.

**Follow-ups, only if she stays general:**
- "What did you look at first?"
- "How long did the whole thing take — minutes, or did it wait until the next day?"
- "Was any part of it annoying enough that you remember it?"
- "Did you have to wait on anybody else?"

---

### A3. Where the MLS runs out
**Status:** pending · **Unblocks:** the redundancy question — ask LAST in this batch

> "In the last few months, was there anything about a property you needed and couldn't get out of
> the MLS? Where did you end up going for it?"

**Why it matters:** this is the decisive one. Line 675 of the notes: "if the walk-in research is an
MLS search on these criteria, county records may be redundant *for this task*." Her stated search
criteria — location, price, type, beds, baths, ocean view — are all MLS fields. If the honest answer
is "the MLS has everything," the county adapter work stops here.

**Do not** prompt with examples. If she draws a blank, that blank is the answer.

---

## Batch B — the three things county records have that MLS does not

Ask only after Batch A. Each is a past-tense probe, not a pitch. If A3 came back "MLS has
everything," these become tests of whether that answer holds up against specific cases — and if they
also come back empty, the feature is dead and that is a good outcome cheaply reached.

### B1. Reaching an owner who isn't selling
**Status:** pending · **Unblocks:** the absentee-owner signal (mailing ≠ situs)

> "Have you ever needed to find out who owns a place that isn't on the market, or how to get hold of
> them? What did you do?"

**Why it matters:** county records give the *mailing* address, which is often not the property. On
the record we pulled, the owners get their mail in a different town. That gap is an absentee-owner
signal, and it is the one output here that plausibly connects to her stated friction — the
dormant-contact pool ("I have made a lot of contacts of people and they have gone nowhere") — rather
than to an invented one.

---

### B2. Who holds the mortgage
**Status:** pending · **Unblocks:** whether the `lender` contract field earns its place

> "Has it ever mattered to you, in a deal, who the lender on a property was? Did you have a way to
> find out?"

**Why it matters:** Tillamook's tax PDF carries a populated lender-of-record field. It is not in the
MLS. If she has never needed it, drop the field — do not ship it because it was easy to get.

---

### B3. Trusts and LLCs
**Status:** pending · **Unblocks:** `ownershipForm` in the contract; also feeds SignMe

> "Have you dealt with a property owned by a trust, or an LLC? What changed for you when that came
> up?"

**Why it matters:** ownership form changes who signs, which makes this a SignMe question as much as a
Meridian one. See `sign-me-build-plan.md` § 2 — the paperwork interview is tracked there and should
not be duplicated here, but this question straddles both and can be asked once for both.

---

## Batch C — deferred, ask when the above have landed

### C1. Working several properties at once
**Status:** pending · **Unblocks:** the spreadsheet assumption in Francis's proposal

> "When you're looking into more than one place at a time, what does that look like right now?"

**Why it matters:** the proposal assumes "she plugs in a spreadsheet of properties." The notes push
back (line 331): she keeps notes on paper, has no CRM, and has never mentioned working from a list.
Ask what she does; do not offer the spreadsheet as an option.

---

### C2. The size of the dead-contact pool
**Status:** pending · **Unblocks:** sizing for the first build (dormant contacts)

> "Roughly how many people are in that group you mentioned — the contacts that went nowhere? Ballpark
> is fine."

**Why it matters:** notes line 671 — "its size is worth establishing — a number, roughly, when she
has one." This one is unrelated to county records and belongs to the *shipping* module, so it is
worth asking whenever there is an opening, independent of the rest of this file.

---

## Not in this file

- **SignMe's paperwork interview** — tracked in `sign-me-build-plan.md` § 2. It is the larger open
  interview and has its own framing. B3 above is the one question that serves both; everything else
  about contracts, offers, disclosures and closing documents belongs there.
- **The MLS feed question** ("which MLS, and can the brokerage be approved for a feed") — tracked in
  `DEC-2026-07-22-mls-data-access` § Confirmation Criteria. The MLS is now identified as
  `CLT.FLEXMLS.COM`; what remains is an association question, not an interview question.

## Related records

- `DEC-2026-07-28-county-adapter-registry` — the architecture these questions gate
- `PAT-2026-07-28-county-record-extraction-traps` — what a county adapter has to survive
- `DEC-2026-07-22-meridian-scope-dormant-contacts` — the scope her testimony *does* support
- `DEC-2026-07-22-mls-data-access` — why county records are the safe source in the first place
