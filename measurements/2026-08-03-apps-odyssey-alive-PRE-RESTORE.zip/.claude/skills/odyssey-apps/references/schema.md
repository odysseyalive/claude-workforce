# Target Database Schema

The authoritative table-by-table plan for `convex/schema.ts`. Derived **from the source file**
(`/home/francis/lab/nsayka-wawa/convex/schema.ts`, 447 lines, read 2026-07-22), not from
odyssey-skul's prose description of it — the two had drifted.

Read this before `convex`, `module-app`, or `beta`. The strip list it implies is
[port-inventory.md](port-inventory.md) § B; this file is the field-level detail.

---

## A. Carried unchanged

| Table | Fields | Why |
|---|---|---|
| `...authTables` | `users`, `authSessions`, `authAccounts`, `authRefreshTokens`, `authVerificationCodes`, `authVerifiers`, `authRateLimits` | Convex Auth's own identity + session tables. Never hand-edit; the library owns them |
| `loginCodes` | email, codeHash, expiresAt, attempts, kind, pendingUsername, pendingUsernameLower, devPlain | Passwordless auth, entire mechanism. `devPlain` is the dev-only plaintext for headless tests, gated on `SITE_ENV=development`. **`pendingBirthdate` and `pendingLocation` are dropped** with their target fields (§ C) |
| `modules` | slug, title, tagline | DB mirror of modules.json for server-side joins |
| `moduleAccess` | userId, moduleSlug, granted, grantedBy, grantedAt, revokedAt | **The entitlement core.** Unchanged in every respect |
| `supportAssignments` | userId, moduleSlug, assignedBy, assignedAt | Which modules a Support user covers |
| `ticketSubscriptions` | ticketId, userId, subscribed | Per-thread notification opt-out |
| `releases` | moduleSlug, version, notes, publishedAt | Version list under a module roadmap |
| `migrations` | name, checksum, status, appliedAt, durationMs, error | The checksum-guarded migration ledger. Infrastructure — carry as-is |

---

## B. Strip entirely

| Table | Why it goes |
|---|---|
| `gameSaves` | Opaque Glulx save blobs. Module state here is typed relational data |
| `playerProgress` | kəmtəks score, in-game day, checkpoint, flags, leaderboard opt-in |
| `missionProgress` | Mission/checkpoint model with CW surfaces and hint counts |
| `vocabProgress` | Chinuk Wawa vocabulary mastery |
| `forumRules` | Versioned public-forum rules |
| `forumRuleAcceptances` | The forced re-agreement ledger |

Also strip the **fields** `moduleSettings.playEnabled` (renamed, § D),
`moduleSettings.leaderboardEnabled`, and `moduleSettings.forumEnabled`.

Stripping a table means its indexes, its seeders in `admin.ts` / `bootstrap.ts`, its migrations,
and its tests go too. A half-stripped table fails `convex deploy` loudly — that is the signal
working, not a problem.

---

## C. Carried with changes — read each, these are the real decisions

### `profiles` — three fields lose their reason to exist

Carried: `userId`, `username`, `usernameLower`, `displayName`, `role`, `prefs`, `lockedOut`,
`lockedOutAt`, `lockedOutBy`, `lastLockWarningAt`. The lockout quartet is load-bearing and stays.

Two fields are **DROPPED (ratified by Francis, 2026-07-22)**:

- **`birthdate` — DROPPED.** It existed as audit evidence for the source site's 16+ age gate on a
  family-oriented game. This is business software sold to licensed professionals; there is no age
  gate to evidence, and storing a date of birth with no use for it is a data-minimization problem
  under GDPR rather than a harmless carry-over. Removing it also removes
  `loginCodes.pendingBirthdate` and the signup age-gate UI.
- **`location` — DROPPED.** A free-text PUBLIC location shown on the `/explorer` profile;
  Explorer is stripped, so it had no surface left. Removing it also removes
  `loginCodes.pendingLocation` and the location branch of the language guard. **It is NOT the
  billing address** raised the same day: `location` is free-text and public, a billing address is
  structured and private, and reusing the field would carry a public-display assumption into PII.
  See § G — no address is stored here at all.

**The username language guard SURVIVES both.** `convex/profanity.ts` `containsBadWord` runs on
usernames at signup (`loginCode.ts:212`, `authCodes.ts:134`) and on account edit
(`account.ts:106`) — it was never forum-only. Keep it, and keep `src/lib/censor.ts` in sync with
it (port-inventory.md § A).

- **`avatarId` / `avatarUrl` — recommend keep `avatarId`, unchanged.** The curated no-upload
  avatar set is a good fit here too: it sidesteps user-uploaded-image moderation and storage
  entirely, and the initials-in-a-circle default is appropriate for business software. The
  *artwork* needs replacing (the source set is PNW animals), but the mechanism is sound.

### `moduleSettings` — flags in, flags out

| Field | Disposition |
|---|---|
| `slug`, `updatedAt`, `updatedBy` | Keep |
| `published`, `status` (`live` \| `coming-soon`) | Keep — content defaults, admin-overridable |
| `accessible` | Keep — the module is grantable |
| `betaEnabled` | **Keep — it ALREADY EXISTS in the source schema.** Do not add it as a new field, and do not put it only in Velite frontmatter. The runtime flag is the authority; content supplies the default |
| `playEnabled` | **Rename → `appEnabled`**, with `modulePlayEnabled` → `moduleAppEnabled` |
| `forumEnabled` | Strip (no public forum) |
| `leaderboardEnabled` | Strip |

### `accessRequests` — the beta table, activated

The source declares it and never wires it. It carries `userId`, `moduleSlug`, `status`
(pending/approved/denied), `email`, `requestedAt`, `decidedAt`, `decidedBy` and all four indexes
already. **Add** per [beta-access.md](beta-access.md): `withdrawn` to the status union, `note`
(the requester's optional "what would you use it for", capped and language-guarded), and
`denyReason` (admin-internal, never rendered or emailed).

### `supportTickets` — the purpose enum is game vocabulary

| Field | Disposition |
|---|---|
| `userId`, `subject`, `status` (open/pending/closed), `createdAt`, `updatedAt` | Keep. **Drop `ownerDeleted`** — erasure hard-deletes the row now (§ H), so the flag can never be set |
| `moduleSlug` | Keep — optional, so a ticket can be about the site rather than a module |
| `hash` | Keep — backs the stable `/support/.../ticket/<hash>` permalink, still wanted for a private ticket |
| `isPrivate` | **Drop.** With private-tickets-only every row would be `true`; a boolean that is always true is a trap that reads like a real choice. Privacy is enforced in the query layer instead |
| `purpose` | **RETARGETED (ratified 2026-07-22).** The source's `translation_fix` and `historical_inaccuracy` are game concerns and go. The enum is now exactly: `bug`, `feature_request`, `account`, `billing`, `data_question`, `other`. `billing` anticipates the subscription; `data_question` anticipates the client-document questions SignMe raises. This is user-visible and changing it later is a migration — treat the list as settled, not a starting point |

### `ticketMessages` — unchanged fields, changed visibility

Fields carry as-is: `ticketId`, `userId`, `authorRole` (user/support/admin), `body`, `createdAt`.
**Drop `authorDeleted`** — erasure hard-deletes messages now (§ H), so the flag is unreachable.
What else changes is **who can read them**, and that lives in the query layer, not the schema
(§ E).

---

## D. What goes in the database on day one

`bootstrap:ensure` (idempotent, convergent — run by `pnpm db:bootstrap` and `db:deploy`) seeds:

1. **The admin account** — from `ADMIN_USER` + `ADMIN_USERNAME` via `seedAdmin`. Passwordless;
   the env allowlist is the irrevocable bootstrap admin, and `profiles.role = "admin"` can grant
   revocable peers from the UI afterward.
2. **Two `modules` rows** — `meridian` / "Meridian" and `sign-me` / "SignMe", mirroring
   modules.json.
3. **Two `moduleSettings` rows** — and the flag combination here is the one to get right:

   | Flag | Value at launch | Why |
   |---|---|---|
   | `published` | `true` | The module appears on `/modules` and has a public intro page |
   | `status` | `coming-soon` | Honest: neither module runs yet |
   | `accessible` | **`true`** | **Load-bearing.** `requestAccess` rejects a non-accessible module, so beta requests silently fail if this is false |
   | `betaEnabled` | `true` | Renders the Request-beta button |
   | `appEnabled` | `false` | The app route is not live; a granted user sees the honest "not switched on yet" state |

   **`accessible: true` + `appEnabled: false` is the launch state** — grantable and collecting a
   waitlist, but nothing to run yet. The source site's baseline defaults `accessible` to false,
   so taking its seeder unchanged would ship a beta button that rejects every request. Assert this
   combination in the `beta` exit tests rather than trusting the seed.

4. **The migration baseline** — a `migrations` row marking the schema's starting point so the
   ledger has an origin.

Nothing else. No sample users, no fixture tickets, no placeholder requests in a live database —
the dev seeders (`seedSampleUsers`) stay development-only, gated on `SITE_ENV`.

---

## E. Invariants that outlive any one table

1. **Every app row is scoped by `userId`** and resolved through `lib.ts requireUserId`. Never
   trust a client-supplied user id.
2. **Entitlement is checked server-side in every module function**, not only at the route. The
   route guard is convenience; the function check is the control.
3. **Private means private in the query layer.** A ticket is readable by its owner, an assigned
   Support user for that module, and an admin. There is no public read path — and that is a
   *tested* assertion, not a convention (test-suite.md § Coverage targets).
4. **Erasure is part of adding a table, not a follow-up.** Any new table holding user data is
   wired into the erasure paths — `deleteAccount` and `adminEraseAccount` (§ H), and per-module
   state into `deleteModuleData` — in the SAME change. `accessRequests` rows are deleted outright;
   unlike tickets, nobody else's conversation depends on them, so there is no tombstone.
5. **Schema changes go through the migration system.** `pnpm migrate:new`, then `db:deploy`
   (verify → deploy → run → bootstrap). The Data-Migration Decision Gate fires on every
   `convex/schema.ts` edit.
6. **Module tables are namespaced and never shared** — `mer*` for Meridian, `sign*` for SignMe.
   Two modules sharing a table is how a bundle becomes impossible to unbundle later.
   **The `sign*` tables have a design sketch** — `sign-me-build-plan.md` § 7, derived from the
   competitor teardown and the Certificate of Completion field list. It is a sketch, not schema:
   two of its decisions (whether `signDocuments.storageId` nulls on erasure while the row survives,
   and how `signEvents` behaves under an erasure request when it holds signer name, email, and IP)
   are **unresolved and legal, not technical**. Do not design them from memory of DocuSign, and do
   not resolve them silently — see § F.

---

## F. Open decisions in this file

Surface these; do not resolve them silently:

- Whether SignMe's document tables need a separate retention policy from the rest of the site
  (they hold the user's clients' agreements — modules.json `privacy_flag`). **Sharpened 2026-07-27
  by reading a real Certificate of Completion** (`research-log.md` § 12.3): the audit trail that
  would survive a document purge contains signer **name, email, and IP address**. So the question is
  not "keep a hash?" — that part is easy — but whether an attestation row that names and locates a
  signer survives that signer's erasure request. `DEC-2026-07-27-erase-document-keep-hash` is
  **proposed, not accepted**, and this is why. Answer it before `signEvents` is designed.
- The GDPR-erasure vs financial-retention tension, once payment exists (§ G)
- Whether Square fits recurring SaaS subscription billing (§ G, coding-lane research)

**Resolved 2026-07-22** — do not reopen without a reason: drop `birthdate`, drop `location`,
and the `supportTickets.purpose` enum above.

---

## G. Payment, billing, and why there is no address in this schema

**Direction (2026-07-22, PROVISIONAL — Francis said "maybe," so this is a proposal, not a
ratified decision): offload payment to Square. Checkout happens on Square, not on this site.**

The requirement that raised it: a subscription eventually needs a full billing address. The
resolution: if Square owns checkout, **Square collects and stores the address, and this database
never holds one.** No address fields, no card data, no billing tables — and PCI scope stays
essentially nil because card details never touch this stack.

**So the schema does not change today.** Do not add address, tax, or payment tables
speculatively. Collecting a billing address during a free closed beta would be PII gathered with
no present purpose to justify it — the same data-minimization argument that drops `birthdate`.

### What WILL be needed when payment lands (design sketch, do not build)

A small link between a site account and its Square-side records. Roughly:

- `billingLinks` — `userId`, the Square customer id, the subscription id, plan identifier,
  status, `currentPeriodEnd`, `updatedAt`; indexed `by_user` and by the Square customer id for
  webhook lookups.
- **Its own table, never fields on `profiles`.** `profiles` is read on ordinary surfaces
  (rendering a username, an avatar); billing state should not ride along on every one of those
  reads, and a separate table is far easier to scope-guard and to erase.
- Webhook handling for subscription lifecycle events, in a Convex action.
- Deleted with the account in `deleteAccount` — with a caveat: financial records may have a
  retention obligation that outlives an erasure request. That is a real tension between GDPR
  erasure and tax/accounting retention, and it needs an actual answer rather than a default.

### The directive conflict this creates — flag it, do not quietly resolve it

The current immutable directive (2026-07-22) says: **"access has to be given manually,"** and the
enforcement checkpoint states that NOTHING may write `moduleAccess` except an explicit admin
grant or an admin approval of a beta request.

A paid subscription grants access **automatically on payment**. That is a direct conflict with
the directive as written — not a loophole to interpret around. When subscriptions arrive, it
needs a **new dated directive amendment** naming payment as a second sanctioned grant path, with
its own rules (what happens on failed payment, on cancellation, on refund, and whether an admin
grant outranks a lapsed subscription). Until that amendment exists, manual granting is the only
path and an automated grant is a directive violation.

### Open questions for the coding lane, before any of this is designed

- **Is Square the right fit for recurring SaaS subscriptions?** Square's strength is in-person and
  retail commerce; subscription billing for software is a different profile. If Francis already
  runs the business on Square, consolidation has real value that may outweigh a better-fitting
  processor — but that is a decision to make knowingly. Research current capabilities and write
  the findings into research-log.md; do not assume from memory.
- Sales-tax handling for software subscriptions varies by US state. Whoever processes payment
  should also be determining tax, or you inherit a compliance job.
- Whether module bundling maps onto the processor's plan model, or needs its own layer here.

---

## H. Admin-initiated GDPR erasure (required — Francis, 2026-07-22)

> **"We need to have a GDPR option in admin that can completely wipe an account."**

The port ships **self-service** erasure only: a user deletes their own account from
`/account`. That is not sufficient. In practice most erasure requests arrive as an *email to a
human* — the person cannot log in, has forgotten which address they used, or simply asks rather
than clicking. Under GDPR the controller must be able to honor that request regardless of how it
arrives, so the admin needs to perform it on the user's behalf.

### Build it as ONE erasure engine, invoked two ways

`adminEraseAccount({ userId })` and the user's own `deleteAccount()` **must call the same internal
implementation.** Two parallel erasure code paths will drift, and the one that drifts is the one
that quietly stops deleting a table somebody added six months later. One engine, two entry points,
one place to register every new table.

### Requirements

- **Admin-only**, through the existing `isAdmin()` check (env allowlist OR `profiles.role`).
  Support-role users must NOT have it — erasure is irreversible and staff scope is per-module.
- **Irreversible, and the UI must say so** before it fires. This is the destructive action on the
  whole admin desk; it deserves a stronger confirmation than a ticket close.
- **Same coverage as self-service erasure:** auth identity, sessions, accounts, refresh tokens,
  profile, `moduleAccess`, `accessRequests`, `ticketSubscriptions`, `supportAssignments`, and
  every module's per-account state. Frees the username and email for reuse.
- **An audit record that is not itself a privacy problem.** Log that an erasure occurred — when,
  and which admin did it — but **do not retain the erased person's email or username in the log**.
  A deletion log full of the identifiers you just deleted defeats the deletion. Store the former
  user id and a timestamp; if a stronger paper trail is needed, store a salted hash, never
  plaintext.
- **This log is also what makes backup restores lawful.** Restoring a snapshot silently resurrects
  accounts erased after it was taken — turning a completed erasure into an ongoing violation that
  nobody notices. The erasure log is the only way to know who to re-erase after a restore
  (backups.md § E clause 3). It is small, non-personal, and load-bearing for a reason that is not
  obvious from the erasure feature alone.

### Full erasure means FULL — including tickets (decided 2026-07-22)

> Francis: *"you can completely delete an account and it deletes all data in reference to that
> account. That's how GDPR works. You have to be able to scrub people if they request being
> scrubbed."*

**On this site, erasure hard-deletes every row referencing the user, with no exceptions —
including `supportTickets` and `ticketMessages`.**

This is a deliberate DIVERGENCE from the port, and the reason matters. The source site
anonymizes tickets in place: it patches the subject to a placeholder, replaces the message body
with a removal notice, sets `ownerDeleted` / `authorDeleted`, and keeps the rows (verified in
`nsayka-wawa/convex/account.ts` `deleteAccount`, 2026-07-22). It does that because support there
was a **PUBLIC FORUM** — hard-deleting one participant's posts would tear holes in a conversation
other people were reading and had contributed to.

**That justification does not survive the private-tickets decision.** A ticket here is a private
thread between one user and staff. No third party is reading it, and there is no shared
conversation to keep coherent. So the anonymize-in-place machinery — `ownerDeleted`,
`authorDeleted`, `DELETED_TICKET_SUBJECT`, the removal-notice body, and the `DELETED` author
rendering — is **stripped along with the forum**, and the rows are deleted like everything else.

Simpler code, fewer unreachable states in the UI, and it matches what erasure is normally
understood to mean.

### Every table, no survivors

The erasure engine deletes, for the target user: `profiles`, `moduleAccess`, `accessRequests`,
`ticketSubscriptions`, `supportAssignments`, `supportTickets`, `ticketMessages`, **`aiUsage`,
`usageDaily`**, every module's per-account state (`mer*`, `sign*`, and whatever comes later),
`authSessions`, `authRefreshTokens`, `authAccounts`, and the `users` row.

**One table is deliberately NOT erased: `usageDailyAnon`.** It carries no `userId`, so it is not
personal data, and it is the only thing that preserves cost history across an erasure
(usage-metering.md § F). Mark it in code as intentionally exempt — otherwise a future audit will
"fix" the omission and destroy the pricing record. Username and email are freed for reuse
— no PII tombstone.

**Stored files are part of erasure too.** Deleting a row that references a stored file must also
delete the file — otherwise the bytes survive in file storage with nothing pointing at them, which
is both a compliance hole and an invisible disk leak.

**Registration is the failure mode to guard.** The engine iterates a declared table list. A table
added without being added to that list is silently NOT erased, and nothing fails — tests pass, the
UI looks right, and the data quietly persists. So adding a user-data table and registering it in
the erasure engine are ONE change, and the erasure test asserts against the full declared table
list rather than a sample.

### Interaction with the future payment work

Once subscriptions exist, financial records may carry a **retention obligation that outlives an
erasure request** (§ G). At that point erasure becomes "delete everything except what the law
requires be kept, and keep that minimally." Build the engine so a table can be registered as
retained-with-justification rather than deleted — otherwise adding billing later means rewriting
erasure under time pressure.

### Exit tests (mandatory)

An admin erasure removes rows from every registered table; the username and email become
re-registrable; the audit record exists and contains no erased identifiers; a Support-role user is
refused; and the erased user's session no longer authenticates.
