# SignMe — discovery record and build plan

**Status: discovery substantially done, product scope NOT grounded, nothing built.** Written
2026-07-27 after a document-research pass and a hands-on review of a live DocuSign account.

This is SignMe's counterpart to `meridian-workflow-notes.md`, with one critical difference:
Meridian's file is an *interview record* and its scope traces to a working agent's own words.
**SignMe has no such interview.** Everything below traces to competitor teardown, statute, and case
law — good evidence about what the thing must BE, no evidence about what this agent actually needs.
That asymmetry is the single most important fact in this document and § 2 is about it.

---

## 1. Where the evidence lives

Nothing here restates the evidence; it points at it. Read the source before acting on a summary.

| Evidence | Location |
|---|---|
| DocuSign's legal surface — privacy notice, terms, eSignature service schedule | `research-log.md` § 7 |
| What an e-signature system must BE — ESIGN, UETA, URPERA, RON, PAdES | `research-log.md` § 8 |
| Case law on repudiated e-signatures — three primary CA opinions | `research-log.md` § 9 |
| Sending documents to a model — ZDR, provider choice, the architecture | `research-log.md` § 10 |
| DocuSign's sender surface, operated — send flow, templates, settings | `research-log.md` § 11 |
| The signing side and the artifacts — adoption, consent, the certificate | `research-log.md` § 12 |
| Decided scope, positioning, copy limits, legal surface | `modules.json` → `modules["sign-me"]` |
| SignMe stands alone | `ledger/decisions/DEC-2026-07-27-signme-stands-alone.md` (accepted) |
| Mechanical-first field detection | `ledger/decisions/DEC-2026-07-27-mechanical-first-field-detection.md` (accepted) |
| Erase the document, keep the hash | `ledger/decisions/DEC-2026-07-27-erase-document-keep-hash.md` (**proposed**) |

**Data discipline, binding on every file in this skill:** no counterparties, addresses, property
details, or document titles from the live account are recorded anywhere. Structure only.

---

## 2. The grounding gap — read this before planning any feature

`modules.json → sign-me.product_scope` records it and it has not changed: **the ~25-question
interview behind Meridian never touched paperwork or signing.** There is no material on contracts,
offers, disclosures, or closing documents from the person whose workflow is the source of truth.

So every SignMe feature named today — including the v1 slice in § 5 — is an *invention*.
`meridian.positioning.source_of_truth` and `PAT-2026-07-22-machine-narrows-human-judges` exist
precisely to prevent that. The competitor review narrowed the field honestly; it cannot substitute
for the agent's own account of what she resents doing.

**This is a blocker on scope, not on preparation.** The work in Phases 1–3 below (§ 6) is
either evidence-gathering or engine work whose correctness is defined by statute and by real state
forms, not by preference — none of it depends on the interview. The UI work does. Do not build a
sender surface before the interview happens.

**Questions the interview needs to answer** — the productive framing is what she *did and
resented*, never what features she wants:

1. Walk me through the last document you sent for signature. Every step, including the parts that
   happened outside the computer.
2. What did you have to do twice? What did you have to chase?
3. Which platform were you required to use, and by whom — brokerage, association, or your choice?
4. When a signing goes wrong, how do you find out? What does going wrong look like?
5. What do you do with the signed document afterward, and who else asks you for a copy?
6. How often is the signer someone who has never used e-signature before?

Q3 matters most for scope: `product_scope` records the brokerage-mandate question as **resolved as
a build blocker** (Francis, 2026-07-27 — it does not block building) but **live as a copy
constraint**. The interview should establish the actual situation so the copy can be true rather
than cautious.

---

## 3. The product thesis, and the one thing that carries it

**Upload a document; the app prepares it for signature; the agent reviews and sends.** The bet is
that field preparation — not signing, not delivery, not storage — is the labor worth removing.

The hands-on review supports the bet on its own terms (`research-log.md` § 11.1):

- **DocuSign's default is fully manual.** On an arbitrary PDF it places nothing. The sender drags
  every tab by hand. So this is not a commodity feature being re-implemented behind a competitor.
- **Their AI-prep container exists and renders empty on this plan** — they are building the same
  idea, gated to higher tiers. The differentiation window is finite. Plan accordingly.
- **Templates are not the alternative lever** (§ 11.2). One working agent, three years, exactly one
  template, `[Untitled]`, abandoned one second after creation. Templates front-load the work; the
  agent with a document to send tonight never has that setup session. If templates ship at all they
  are a byproduct offered *after* a successful send — never a prerequisite.

**Everything else in an e-signature product is table stakes that must simply be correct.** Consent,
audit trail, certificate, retention, erasure — none of it wins a user, all of it loses the product
if wrong. Budget accordingly: the interesting engineering is in § 6 Phase 3; the careful
engineering is everywhere else.

**Architecture (decided, `research-log.md` § 10 + the mechanical-first ledger record):** a
deterministic pass does the work — PDF AcroForm fields where they exist, then layout heuristics
(signature/date/initial line detection, label proximity, ruled boxes) — and a cheap model does a
final verification sweep to catch what the mechanics missed and flag what looks wrong. Direct
Anthropic API, `claude-haiku-4-5`, structured outputs, org-level zero retention confirmed before
the first client document. Every model call goes through the single metered helper in
`usage-metering.md` — enforced, not advisory.

---

## 4. What is settled, what is proposed, what is open

**Settled — do not reopen without a reason:**

- SignMe sells on its own; it owns its own parties and document grouping, and the Meridian
  integration is a seam, not a dependency.
- Mechanical-first detection with a cheap-model verification sweep; direct Anthropic, not
  OpenRouter, for this feature.
- Brokerage mandates do not block the build; they bound the advertising.
- The signer is the agent's client, not a subscriber — **the signing surface must work without an
  account and without a `moduleAccess` grant.** This is structural and it constrains routing and
  auth (`legal_surface` finding 3).
- The agent is the data controller; Odyssey Alive is the processor. The agent is also the ESIGN
  *discloser* — we supply the mechanism, they hold the § 7001(c) obligation (§ 12.2).
- Consent is keyed `(signer, sending account)`, not per envelope, with a stable ID and a timestamp,
  both of which appear on the certificate.

**Proposed — needs a decision before the code depends on it:**

- Erase the document, keep the attestation row. The certificate teardown showed that row contains
  signer **name, email, and IP address** (§ 12.3), so the hash was the easy part. Whether an
  attestation row that names and locates a signer survives that signer's erasure request is a
  lawyer question, now posed against a concrete field list.
- The v1 slice in § 5. Derived from the competitor surface, not from the agent.

**Open — surface, do not guess:**

- The paperwork interview (§ 2). Blocks all UI scope.
- Anthropic's DPA / processor terms — a subprocessor needs one and it has not been read.
- Whether SignMe's document tables need a retention policy distinct from the rest of the site
  (`schema.md` § F, `modules.json` `privacy_flag`).
- Pricing, since the module now needs its own story rather than inheriting Meridian's.
- Trademark and domain availability for **Meridian** — unrelated to SignMe but still unchecked and
  still shipping in a URL.

---

## 5. Scope: the v1 slice

Proposed against the observed surface (`research-log.md` § 12.4). **Provisional until § 2 happens.**

**Carry:** upload · AI field detection · recipients with real-estate role names · review and adjust
fields · send · remind · signer view (ungated) · adopt signature (CHOOSE + DRAW) · sign · certificate
· download · void.

**Drop for v1:** templates as a front-loaded feature · Stamps · Identity Wallet / ID verification ·
payment tabs · bulk send · in-person signing · PowerForms · Connected Apps · the REALTOR®-logo
checkbox · every recipient role except signer and carbon-copy · UPLOAD as a signature-adoption
method (least used, most support burden, and the one path where a signer can supply an image of
someone else's signature).

**Dropped with a flag, not permanently:** witness and notary. Some real-estate instruments require
notarization, RON is a real market, and ESIGN § 7001(g) exempts notarization from the general rule
(§ 8). Their absence bounds which documents SignMe can honestly claim to handle, and that bound
belongs in the copy — not discovered by a user mid-transaction.

**The field vocabulary is the detection pass's output enum, not an aspiration:** Signature, Initial,
Date Signed, Name, Email, Company, Title, Text, Checkbox, Radio, Dropdown, Attachment. A detection
result that cannot name a tag in this list has produced something the signing UI cannot render.

---

## 6. Build plan

**Prerequisite: none of this starts before `/odyssey-apps build` has run.** SignMe depends on
accounts, entitlements, the admin desk, the beta flow, and the erasure engine — all site-level, all
delivered by the main build. There is no application code in this repo yet.

Phases are ordered by *what would invalidate the module soonest*. The deliberate choice is that
**the detection engine is validated offline, before any UI exists** — if the differentiator does not
work, that must be known before a signing stack is built around it.

### Phase 1 — Ground the scope
`/odyssey-apps debug module` to stage the interview; record the result as
`references/sign-me-workflow-notes.md`, in her words first, matching `meridian-workflow-notes.md`.

**Exit:** a workflow-notes file exists and every § 5 feature either traces to a line in it or is
explicitly marked as an invention that survived review.

### Phase 2 — Build the evaluation set
Obtain **blank published state forms** and tag them by hand; that hand-tagging is the ground truth.
Do **not** source fixtures from the live account: reading a client envelope adds audit events to a
real legal transaction and the data-discipline rule bars recording most of what it contains
(`modules.json` `evaluation_plan`).

**Exit:** ≥5 blank forms, hand-tagged, with a scoring script that reports precision and recall per
field type. The two-actor requirement in `evaluation_plan` applies — the person who writes the
detector does not define the ground truth alone.

### Phase 3 — The detection engine, offline
`/odyssey-apps module-app sign-me` (engine only, no routes). Deterministic pass first — AcroForm
extraction, then layout heuristics — scored against Phase 2. Then the cheap-model verification
sweep, scored again, so the model's marginal contribution is *measured* rather than assumed. Every
call through the `usage-metering.md` chokepoint.

**Exit:** measured precision/recall for the mechanical pass alone and mechanics+sweep, with a
per-document cost figure. **This is the go/no-go gate for the module's premise.** A sweep that adds
nothing measurable is a sweep that should not ship, and a mechanical pass that cannot find
signature lines on a real state form is a product that does not work.

### Phase 4 — Data model
`/odyssey-apps convex` — the `sign*` tables (§ 7), migration, erasure wiring. Table design goes
through the migration system; the Data-Migration Decision Gate fires on every `convex/schema.ts`
edit.

**Exit:** schema deployed, erasure exit-tests in `schema.md` § H extended to cover every new table,
and the retention question in `schema.md` § F answered rather than deferred again.

### Phase 5 — Sender surface
`/odyssey-apps module-app sign-me` — upload → detect → **review and adjust** → recipients → send.
The review step is not optional polish: detection will be wrong sometimes, and the product's honesty
depends on the agent seeing and correcting it before a client does.

**Exit:** `/odyssey-apps test` covers upload-through-send at both viewports.

### Phase 6 — Signer surface
`/odyssey-apps module-app sign-me` — the ungated signing route, ERSD presentation and acceptance,
signature adoption (choose + draw), signing, decline, and **consent withdrawal as a real state
transition** including the in-session decline-then-withdraw path (§ 12.2).

**Exit:** a two-actor Playwright flow — sender composes and sends, signer receives and signs —
using the `session_attach` actor-switch pattern (`procedures/test-suite.md`). No account required
on the signer side, verified by test, not by inspection.

### Phase 7 — The record
Certificate of Completion as a separately downloadable artifact with the ERSD text embedded, the
audit trail behind it, and document download. Field list in `research-log.md` § 12.3 — treat it as
the specification.

**Exit:** a completed envelope produces a certificate containing all of: envelope config as attested
fact, per-signer Sent/Viewed/Signed timestamps, IP for originator and signer, adoption method,
consent ID and timestamp, the empty role taxonomy, and the full ERSD text.

### Phase 8 — Copy, intro page, beta
`/odyssey-apps module-intro sign-me` and `/odyssey-apps beta`. All copy through `/my-voice`,
`/text-eval` unconditionally, and `/copy-truth` against the three live constraints: no
enforceability claim, no ESIGN-compliance claim, no claim about documents v1 cannot handle
(witness/notary).

**Exit:** `/copy-truth` clean, `/text-eval` clean, beta request → manual grant verified end to end.

### Phase 9 — Deploy
`/odyssey-apps deploy`, then `/odyssey-apps verify`. The Anthropic org retention setting is
**account state that no test can catch** — confirm it before the first client document and again at
launch (`research-log.md` § 10.9).

---

## 7. Data model sketch — `sign*` tables

**Design sketch, not a schema. Do not build from this without Phase 4.** Namespaced `sign*` per
`schema.md` § E.6; two modules sharing a table is how a bundle becomes impossible to unbundle.

| Table | Holds | Notes |
|---|---|---|
| `signEnvelopes` | ownerId, title, status, createdAt, sentAt, completedAt, voidedAt | Status is the lifecycle: draft → sent → completed / voided / declined |
| `signDocuments` | envelopeId, storageId, pageCount, sha256 | The PDF in Convex file storage. **`storageId` is nullable — erasure clears it and keeps the row and the hash** (proposed decision) |
| `signRecipients` | envelopeId, name, email, role, routingOrder, status | Role uses real-estate vocabulary, not "Signer 1". Statuses mirror the certificate's Sent/Viewed/Signed |
| `signFields` | documentId, recipientId, type, page, x, y, w, h, required, value, source | `type` is the § 5 enum. **`source` records `mechanical` \| `model` \| `human`** — needed to measure the engine in production, not just in Phase 3 |
| `signSignatures` | userId, name, initials, adoptionMethod, sigStorageId, initialsStorageId | The **user-level** signature library (§ 11.3), not per-envelope. Signature + initials pair under one row |
| `signConsents` | signerEmail, sendingAccountId, acceptedAt, consentId, withdrawnAt | **Keyed to the sending account, not the envelope** (§ 12.2). `withdrawnAt` makes withdrawal a real transition |
| `signEvents` | envelopeId, recipientId, type, at, ip, meta | The audit trail. Append-only. Backs the certificate |

**Design notes that fall out of the discovery:**

- **`signEvents` is the erasure problem.** It holds name, email, and IP — personal data — and it is
  the thing whose survival justifies keeping any record at all after a document is erased. Do not
  design its erasure behaviour without the § 4 legal answer.
- **`signFields.source` is cheap now and impossible to backfill.** Record where each field came from
  from the first line of code, or the production accuracy question is permanently unanswerable.
- **Nothing here reads Meridian's tables.** The standalone decision means SignMe owns its parties and
  document grouping; the duplication is deliberate and the future reconciliation is accepted debt
  that must not be pre-built.

---

## 8. What could invalidate this module

Kept explicit so it is re-checked rather than assumed away.

1. **Detection does not work well enough on real scanned forms.** The most likely failure, and
   Phase 3 exists to surface it before anything is built on top. Scanned-document OCR accuracy is
   listed as unresearched in `research-log.md` § 10 and remains so.
2. **The agent does not actually resent field placement.** Phase 1 answers this. If the resented
   work is chasing signatures rather than preparing documents, the product's centre of gravity moves
   to reminders and status — a different module.
3. **DocuSign ships its AI prep to the tiers a solo agent buys.** The container is already in their
   markup (§ 11.1). This shortens the window; it does not close it, since the vertical framing and
   price are separate axes from the feature.
4. **The erasure answer comes back as "the attestation row cannot survive."** Then the retention
   story needs rebuilding and § 7's `signEvents` design changes materially.
5. **A mandated platform turns out to be universal in her market.** Ruled out as a build blocker,
   but Phase 1 Q3 should establish the real picture so the copy is true.

---

## Grounding

- `research-log.md` §§ 7–12 — the full evidence base with citations
- `modules.json` → `modules["sign-me"]` — decided scope, positioning, copy limits, legal surface
- `schema.md` — site-level tables, erasure engine (§ H), and the retention open question (§ F)
- `usage-metering.md` — the single metered chokepoint every model call goes through
- `procedures/test-suite.md` — the two-actor `session_attach` pattern Phase 6 depends on
- `meridian-workflow-notes.md` — the format Phase 1's output must match
