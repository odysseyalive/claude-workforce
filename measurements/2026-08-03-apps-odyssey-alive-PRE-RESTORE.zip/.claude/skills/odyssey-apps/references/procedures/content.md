# Procedure: page, module, module-intro, roadmap, release

All copy is authored in Francis's voice and gated for copy-truth (claims must match what the UI
actually does) — see the SKILL.md Content Provenance directive. The Chinuk Wawa accuracy gate
that governed odyssey-skul does NOT apply here; there is no second language on this site.
Grounding: read [../connectors.md](../connectors.md) for any mode that reaches a module's source.

## Voice + evaluation (applies to every content mode)

1. Load voice: invoke `/my-voice`; for marketing/persuasive copy also `/wit`.
2. **Editing existing site copy?** Route the change through `/edit` (Francis's standing
   directive, 2026-05-25: "use /edit whenever you edit text on odyssey apps"). `/edit` loads the
   writing kernel and runs the single lightweight edit-validator on the changed passage. Use it
   for any revision to shipped MDX/page/component copy, hero text, blurbs, or emails. Authoring a
   page from scratch still uses the full draft + text-eval flow below.
3. Draft (or apply the `/edit` change).
4. Copy-truth gate: run `/copy-truth check` on each user-facing functional claim against the
   component/flow it renders in. A claim-vs-behavior MUST FIX (copy asserting a capability the
   UI doesn't back up for the reader it's shown to) blocks the write — correct it first. Scope
   includes component-embedded `.tsx` strings (subtitles, hints, empty-states, button/aria
   labels), not just MDX.

   **This gate matters more here than it did on the source site.** This is business software sold
   to real-estate professionals, and both modules launch as gated betas — so copy is structurally
   tempted to describe capability that is not switched on for the reader yet. A beta page may
   promise what the product WILL do; it may not imply the reader can do it today when the gate
   says otherwise.
5. **Text evaluation — UNCONDITIONAL (directive, 2026-07-22).** Before presenting, run
   `/text-eval` on the draft. **Every string that lands in a shipped file**, with no exemptions:
   MDX pages, module intros, beta blurbs, transactional email bodies, button labels, empty states,
   error messages, and component-embedded `.tsx` copy — not just long-form prose.

   The old `/edit` carve-out is GONE. `/edit` still runs for revisions to shipped copy; it no
   longer stands in for the eval. Both run.

   Why it is stricter here than on the source site: this is business software for a professional
   audience, sold from a page strangers read cold. Copy that reads as machine-generated does not
   just land flat — it undercuts the one thing the product claims, which is that a person built
   something thoughtful enough to save you time.

## page <slug>

Author a marketing/MDX page (home, contact, about). Reuse the ported component for the page type
where one exists; odyssey-alive remains the visual touchstone (templates-inventory.md).

**The home page is authored fresh.** The port's home is built around a language-learning pitch
and a Field Notes rail pulled from odysseyalive.com — neither transfers.

**Read `modules.json` `$site_thesis` first** — `home_page_proposition`, `home_page_spine`,
`home_page_cautions`, and `home_page_blocked_on`. That is the decided argument, worked out with
Francis on 2026-07-22, and this procedure defers to it.

The proposition in one line: **"this lets you compete with companies that are already using AI,"**
with "put a team to work for you" as the hook. Do not dilute it into a feature list.

**Vertical-neutral, in copy AND imagery.** More modules are coming and most will not be real
estate (modules.json `$site_thesis.catalog_scope`). The home page therefore avoids real-estate
vocabulary and real-estate pictures entirely; the vertical belongs on the module pages. This does
NOT license generic copy — see `specificity_resolution`: the home page is specific about the
PROBLEM SHAPE, the module pages are specific about the WORK.

**One CTA, and it is not a conversion.** The home page's job is to route a visitor to the right
module page. The beta ask lives on `/modules/<slug>` and nowhere else (Francis, 2026-07-22:
"each module [has] its own CTA page"). Competing calls to action — newsletter, two module betas,
and a general signup all on one screen — is how a page ends up with none. The newsletter is
secondary and belongs in the footer, where the port already puts it.

Both modules are **pre-release**. The home page says so plainly rather than implying either is
generally available — the beta framing is the honest position and also the one `/copy-truth` will
hold you to.

Build the page UI with `/frontend-design`, using odyssey-alive as the visual touchstone; avoid
generic AI-looking UI.

## Legal pages (/privacy, /terms)

The site is GDPR-compliant and needs `/privacy` and `/terms`. Author them with `page`, based on
odyssey-alive's `src/app/(marketing)/privacy/page.tsx` and `terms/page.tsx`
(templates-inventory.md), adapted for what THIS site collects: accounts (username + email),
per-module application state, **beta-access requests**, and support tickets. State the GDPR
rights and point to the account-page controls for data reset and erasure (backend.md § Data
deletion).

**Revisit these pages when a module ships state.** `sign-me` in particular will process
documents that are not the site's own data — signed agreements belonging to the user's clients.
That changes the privacy posture (retention, processor role, who can access what) and is a
question for Francis and, plausibly, a lawyer. Surface it; do not quietly write policy text that
sounds like it was reviewed. Carry over odyssey-alive's CookieConsent; the footer links to both pages.

## module <slug>

Add a module to the `/modules` listing.

1. Read `modules.json` for the slug (title, tagline, status, product scope).
2. Create the Velite `modules` content entry — frontmatter: title, tagline, slug, cover, order,
   plus `betaEnabled` and optional `betaBlurb` (port-inventory.md § D) — and ensure the card
   renders in the `/modules` grid (presentations-card format) with its **Beta** chip.
3. Generate/assign a cover image via `image` mode if none exists. Photographic, per art.md.
4. Register the runtime flags: a new module is NOT `accessible` or `appEnabled` until an admin
   turns it on (backend.md § moduleSettings). Shipping the card is not shipping the product.

## module-intro <slug>

Author the deep `/modules/<slug>` page — the module's public marketing surface and the home of
its beta button.

1. Read `modules.json` for the slug: tagline, product scope, access model.
2. **If `product_scope` is still OPEN, write what is genuinely known and no more.** Both modules
   are described by intent ("real estate AI", "a DocuSign clone for real estate") but their beta
   surfaces are not yet decided. An intro page that invents features to fill a layout is exactly
   what `/copy-truth` exists to stop. A short, honest page beats a padded one, and a beta
   audience is the least forgiving one to oversell to.
3. Write the introduction: what the module does, who it is for, what problem it removes. For
   `sign-me`, name the real-estate context specifically — a general e-signature pitch is weaker
   and less true than the one Francis actually described.
4. Place the **Request beta access** block (beta-access.md § The button). It is the page's
   primary CTA and it renders in one of five states depending on auth and entitlement.
5. Link to the module roadmap when one exists.
6. Apply the voice + copy-truth + eval steps above.

## roadmap <slug>

The roadmap is **site-owned** content and **public** (viewable without an account). It lists the
major areas grouped (shipped vs coming-next) with a percent-complete bar per area, linked from
`/modules/<slug>`.

1. Read the module's roadmap source from `modules.json`. If the module has no roadmap source
   yet, create one alongside the first roadmap rather than inventing numbers inline.
2. Render each area + its percent, ordered by the build sequence.
3. **Grounding the percentages:** inspect the module's own source in this repo (routes,
   functions, tables present/absent) and update the source file. Do not guess or inflate. A
   roadmap on a beta product is read as a commitment — an inflated bar is a broken promise with
   a date on it.
4. Say what is NOT planned when it is likely to be assumed. For `sign-me`, a DocuSign comparison
   invites assumptions about the full DocuSign feature set; the roadmap is the honest place to
   bound that.

## release <slug>

Maintains the **version list** shown below the roadmap. This is the mode that updates the page
when new functionality ships.

1. Generate/confirm the new version number (semver; the line starts at v0.1.0).
2. Prepend a version entry (newest first) describing what shipped, in user-facing language.
3. Update any roadmap percentages the release changed (grounded by inspecting the source).
4. Render the version list newest-first below the roadmap.
