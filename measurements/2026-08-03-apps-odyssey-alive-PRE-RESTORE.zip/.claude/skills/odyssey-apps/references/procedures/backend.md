# Procedure: convex, auth, module-app

Grounding: read [../research-log.md](../research-log.md) §§ 2, 3, 1 before acting. The recipes
there are citation-checked; the items flagged "empirical test required" must be run, not
assumed (project rule: no trusting doc-review verdicts without a real run).

---

## convex [action]

Scaffold and manage the self-hosted, open-source Convex backend.

### Local dev setup

1. `npm install convex@latest`. Create `convex/` with `schema.ts` and function files.
2. Bring up the backend + dashboard via the SAME self-hosted compose used in production
   (`ghcr.io/get-convex/convex-backend` on :3220/:3221, `ghcr.io/get-convex/convex-dashboard`
   on :6792). **Bind-mount** the data dir (see Database persistence below), not a named volume.
   Pin image tags, do not track `:latest`. In dev this runs behind the dev-apps mirror
   (environments.md); it is the same compose as live, differing only by data path and origins.
3. Generate the admin key: `docker compose exec backend ./generate_admin_key.sh`. Put it +
   the URL in `.env.local`:
   `CONVEX_SELF_HOSTED_URL='http://127.0.0.1:3220'`,
   `CONVEX_SELF_HOSTED_ADMIN_KEY='<key>'`. These replace the cloud `CONVEX_DEPLOY_KEY`.
4. `npx convex dev` to push schema + functions and watch.
5. Set `NEXT_PUBLIC_CONVEX_URL` to the browser-reachable backend origin (see the gotcha in
   research-log.md §2).

### Database persistence — DATA LIVES ON THE SERVER, NEVER INSIDE THE CONTAINER

**Directive (Francis, 2026-07-22):** *"The database itself needs to be set up so that it is on the
server and not inside the box. That way, if something happens to that box, that data is still there
and it can also be backed up. It also needs the appropriate permissions… we really need to stick to
this infrastructure where actual data that's being served is outside the box. Regardless of whether
it's Convex or a web server or what."*

**This is an infrastructure invariant, not a Convex detail.** It binds the website, the Convex
database, and every module that stores anything — present and future.

A container is disposable by design. It gets destroyed and recreated on every image update, every
config change, every `docker compose up --force-recreate`. **Anything written inside it dies with
it, and it dies during a routine, successful deploy — not during a disaster.** That is what makes
this failure mode so easy to hit: nothing goes wrong, and the data is gone anyway.

So: **a HOST BIND MOUNT to an explicit path.** Not a named volume, not an anonymous volume, and
never the container's writable layer.

```yaml
services:
  convex-backend:
    image: ghcr.io/get-convex/convex-backend:<pinned-tag>
    volumes:
      - ./data/convex:/convex/data        # host path, outside the container
```

**Why a bind mount rather than a named volume**, since named volumes also survive recreation:

| | Bind mount (what we use) | Named volume |
|---|---|---|
| Location | An explicit path you chose and can `ls` | Docker's internal storage area |
| Backup | Copy the directory; it is just files | Requires `docker run --volumes-from` gymnastics |
| Survives `docker compose down -v` | **Yes** — `-v` does not touch bind mounts | **No** — destroyed |
| Visible to jstack's site backup | Yes, it is inside the site dir | No |

The verified compose (nsayka-wawa, read 2026-07-22) declares **no named volumes at all** — one
bind mount, `./data/convex:/convex/data`. Keep it that way.

**Where the host path resolves:**

- **Dev:** `./data/convex` inside this repo (gitignored). The local test database, separate from live.
- **Live:** compose runs from the jstack site dir, so it resolves to
  `jstack/sites/apps.odysseyalive.com/data/convex` on the server — outside the container, inside
  the directory jstack's site backup already covers.

**Permissions — the thing that actually goes wrong.** The host directory must be writable by the
uid the backend container runs as. Get this wrong and you get one of two failures, both confusing:
the container cannot write (the backend appears to start, then errors on first write), or the files
end up owned by root and **your backup job silently cannot read them**. Follow jstack's own
convention (`scripts/core/fix_workspace_permissions.sh`): ownership `user:docker-group`, mode `770`
on data directories. Set it once after the first `up`, and verify by writing a row and reading the
file back as the backup user — not by assuming.

**This is where module data lives too.** Every module's tables AND every stored binary — uploaded
documents, signed PDFs (backups.md § A-bis) — land in Convex, which means they land in this one
host directory. That is the whole point: one path on the server holds everything, so one backup
covers everything and one permissions fix covers everything.

**The same rule for anything else that ever holds data.** If a future service needs persistence —
a cache, a queue, a search index — its data goes to a host path under the site directory by the
same reasoning. No exceptions for "it's only a cache": a cache you cannot inspect or back up is a
cache you cannot debug.

**Consequence for wiping data:** because the mount is a host directory, `docker compose down -v`
does **NOT** delete it — `-v` removes named volumes, and there are none. To genuinely wipe, stop
the stack and delete the host directory. Anyone who believes `-v` wiped their test data is wrong in
the more dangerous direction.

**dev ↔ live data:** plain files outside the container, so seeding dev from a live snapshot is a
directory copy taken **while the backend is stopped** (a live copy is torn — backups.md § B). Never
point dev and live at the same directory.

**Scale alternative:** for a larger deployment, repoint Convex at Postgres via `POSTGRES_URL`
(research-log.md §2) and bind-mount Postgres's data instead. The principle is unchanged — only the
engine differs.

Same in dev and live; only the resolved host path and the public origins differ (environments.md).

### Debugging (dev vs live)

- The **dashboard** (:6792) is the inspection surface for both: data, logs, function runs.
- **Dev (local testing):** `npx convex dev` hot-pushes `convex/` changes to the local backend
  and watches; the dashboard is local.
- **Live (live debugging):** `npx convex deploy` pushes committed functions/schema to the VPS
  backend (part of the deploy flow). Debug live by pointing the CLI/dashboard at the live backend
  with the live admin key. **Firewall or proxy the live dashboard behind auth** (it has full
  admin over the data).
- `debug convex` resolves which backend (dev vs live) from `NEXT_PUBLIC_SITE_ENV`
  (environments.md) and states the active environment before acting.

### Schema (`convex/schema.ts`) - target tables

**Authoritative plan: [../schema.md](../schema.md)** — derived from the source `schema.ts` itself,
table by table, with the day-one seed contents and the open field-level decisions. Read it first;
the summary below is orientation, and where the two disagree, schema.md wins.

Author with `defineSchema`/`defineTable`/`v.*`:
- `users` (auth-owned identity; `tokenIdentifier`, indexed `by_token`)
- `profiles` (display name, avatar, prefs; `userId`)
- `modules` (slug, title, tagline; mirrors modules.json for DB-side joins)
- `moduleAccess` (per `userId`+`moduleSlug`: `granted`, `grantedBy`, `grantedAt`, `revokedAt`;
  indexed by user and by module) - a user cannot enter a module's app unless `granted`; the
  admin grants and revokes (entitlements)
- `accessRequests` (per `userId`+`moduleSlug`: `status` pending/approved/denied, `requestedAt`)
  - DEFERRED: schema-ready for self-service requests; closed beta does not use it yet
- `accessRequests` (`userId`+`moduleSlug`, `status` pending|approved|denied|withdrawn,
  `requestedAt`, `decidedAt?`, `decidedBy?`, `note?`, `denyReason?`; indexed `by_user`,
  `by_module`, `by_user_module`, `by_status`) - the **beta-request** records. odyssey-skul
  declared this table and left it unwired; here it is live. Full contract:
  [../beta-access.md](../beta-access.md). **A row never grants access** - only an admin
  approval, which calls `grantAccess`, does.
- **Per-module state** - each module owns its own typed tables, namespaced by module
  (`mer*` for meridian, `sign*` for sign-me) and scoped by `userId`. Declared in
  modules.json `convex.state` and built by `module-app`. This REPLACES the game's opaque
  save blob: module state here is normal relational data, not a `v.bytes()` blob, so it is
  queryable, migratable, and erasable field by field.
- `supportTickets` (`userId`, `moduleSlug`, `purpose` enum, `subject`, `status`, `createdAt`,
  `updatedAt`). **2026-05-26 (support forum revision, see support-admin.md):** `status` is
  `open|pending|closed` (was `completed`); `purpose` uses `historical_inaccuracy` (was
  `lore_correction`); add `isPrivate: v.boolean()`, `hash: v.string()` (`by_hash` index) for the
  `/support/<slug>/ticket/<hash>` permalink, and a `by_module` index. **GDPR (decision 18):** add
  `ownerDeleted: v.optional(v.boolean())`, set when the owner erased their account (the `subject`
  is scrubbed, the ticket is kept in place, and the display shows `DELETED`).
- `ticketMessages` (`ticketId`, `authorRole` **user|support|admin**, `body`, `createdAt`,
  **`userId`** author identity with a `by_user` index — added 2026-05-26 for the public forum).
  **GDPR (decision 18):** add `authorDeleted: v.optional(v.boolean())`, set when the author erased
  their account (the `body` is replaced by the removal notice, the display shows `DELETED`).
- `ticketSubscriptions` (`ticketId`, `userId`, `subscribed`; indexes `by_ticket`, `by_ticket_user`,
  `by_user`) — per-thread Save&Send opt-out; no row = subscribed. **NEW 2026-05-26.**
- `supportAssignments` (`userId`, `moduleSlug`, `assignedBy`, `assignedAt`; indexes `by_user`,
  `by_module`, `by_user_module`) — which modules an assigned **Support** user covers. **NEW
  2026-05-26.** `profiles` also gains `role` (`"support"`; admin stays env-based) and uses `prefs`
  for `supportPageSize` (10|25|50, default 10).
- `moduleSettings` (`slug`, optional `published`, `status`, `accessible`, `appEnabled`,
  `updatedAt`, `updatedBy`; `by_slug` index). Runtime-editable module flags the
  admin sets in **Account -> Admin -> Modules**, OVERRIDING the static MDX-frontmatter defaults
  so a module's state changes without a content rebuild. Every flag is optional: an absent field
  (or row) falls back to the content default via `src/lib/modules.ts` `effectiveModuleFlags`.
  `accessible` (grantable + has a support forum) and `appEnabled` (the module app runs at
  `/modules/<slug>/app`) are operational gates with no content equivalent, so they default
  **false** until an admin turns them on; `published`/`status` fall back to content. That keeps a
  not-yet-ready module out of grants and support without hardcoding slugs.

  Functions in `convex/modules.ts`: `moduleFlags` (PUBLIC query, the override rows for the
  whole-site merge), `setModuleFlags` (admin-only partial upsert), and the server gates
  `moduleAccessible` / `moduleAppEnabled` (read the row, default false) used as defense-in-depth
  by `grantAccess` / `grantAccessByEmail` (access gate), `createTicket` (a ticket must name a
  real, accessible module), and `requestAccess` (the beta gate — beta-access.md § Module gating).

  **`forumEnabled` is NOT carried** (2026-07-22 directive amendment): there is no public forum on
  this site, so the flag, its `moduleForumEnabled` gate, and its baseline backfill are stripped
  with the rest of the forum machinery (port-inventory.md § B).

  Client components read `moduleFlags` via `useQuery`; the already-dynamic marketing pages
  (`/modules`, `/modules/<slug>`) read it server-side via `fetchModuleFlagRows` in
  `src/lib/modules.server.ts` (`convex/nextjs` `fetchQuery`). Dev seeder:
  `admin.seedModuleSettings`, called from the `seedSampleUsers` reseed path.

  **Ported, not redesigned.** `playEnabled` is renamed `appEnabled` (port-inventory.md § D);
  `leaderboardEnabled` and `forumEnabled` are stripped along with the features they gated.
  Everything else about this mechanism is unchanged from odyssey-skul, where it is already proven.
- `releases` (`moduleSlug`, `version`, `notes`, `publishedAt`) - optional DB mirror of
  CHANGELOG once that source exists

### Functions

`query`/`mutation`/`action` from `./_generated/server`, called via the generated `api`.
Scope every row to the caller: `const identity = await ctx.auth.getUserIdentity()` then filter
by `userId`. Tickets: `createTicket`, `listMyTickets`, `addMessage`; admin:
`listAllTickets` (sortable by status), `replyToTicket` (mutation that also triggers the email
action), `setTicketStatus`. Access + users (admin): `grantAccess` / `revokeAccess` (mutations
on `moduleAccess`), `hasAccess` (query used to gate the module-app route), `listUsers` (query
returning each user with their module access, their activity summary, and their open-ticket
count); `grantAccessByEmail(email, moduleSlug)` to grant before/without the user being in view.
Beta requests: `requestAccess`, `myAccessRequests`, `withdrawRequest`, `pendingAccessRequests`,
`decideAccessRequest` — see [../beta-access.md](../beta-access.md) § Functions. Per-module
state functions are owned by each module and namespaced by it (`module-app`).

### action

Convex `action`s (Node runtime) for side effects: sending ticket-reply emails and any other
transactional email, plus third-party calls. **All outgoing email uses Francis's SMTP
credentials, the same ones odyssey-alive uses** (`SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`,
`SMTP_PASS`, sender `CONTACT_EMAIL`); reuse odyssey-alive's Nodemailer send path. Provide those
keys to the Convex backend environment so the action can send. Actions cannot touch `ctx.db`
directly; they call queries/mutations via `ctx.runQuery`/`ctx.runMutation`.

### seed-admin (admin bootstrap)

`/odyssey-apps convex seed-admin` -> `npx convex run admin:seedAdmin`. PASSWORDLESS:
idempotently ensures the admin account from `ADMIN_USER` (an email) and `ADMIN_USERNAME`
(optional, defaults to the email local-part), set on the backend via `npx convex env set`.
There is no `ADMIN_PASS`. `admin/seedAdmin` is an **internalAction** (not in the public
`api`, so only the admin-keyed CLI runs it) that reconciles any legacy admin email (the
2026-05-25 `admin@`->`francis@` rename), then, if no user exists, creates a passwordless
account via `createAccount` (`@convex-dev/auth/server`, provider `email-code`, no secret) and
ensures a profile username. The admin then signs in through the usual `/login` 6-letter-code
flow; it is admin because `lib.ts` `adminEmails()` includes `ADMIN_USER` alongside
`ADMIN_EMAILS`. Idempotent (`created:false` when present), never auto-runs on app boot,
explicit invocation only. This is the live first-admin bootstrap AND the deterministic admin
for tests/debugging (the `signInAsAdmin` helper, test-suite.md): the test setup runs
`seedAdmin()` then signs in via the dev deterministic-code path (no password to type).

### migrate (data migrations) + bootstrap + db:deploy

The single front door for updating the live database is `pnpm db:deploy`. It runs
four idempotent phases, so "first run" is never special-cased: `migrate:verify`
(integrity gate) -> `npx convex deploy` (STRUCTURE: schema.ts + functions) ->
`migrate:runPending` (one-time DATA migrations) -> `bootstrap:ensure` (convergent
baseline). In dev, `serve.sh` runs the last two on bring-up (functions are
hot-pushed by `npx convex dev`).

**Key Convex reframing:** the schema is declarative. Adding a table, index, or
field happens automatically on `convex deploy` from `convex/schema.ts`. There is
NO `CREATE TABLE` migration. Migration files cover DATA-only work that deploy
cannot do: backfills, transforms, data drops, one-off cleanups. Decide migration
vs. bootstrap by: "if I wiped the DB and redeployed, should this run again?" Yes
-> bootstrap (convergent, insert-if-absent). Only-relative-to-existing-rows ->
migration (one-time, tracked).

Pieces (all plain deterministic code; AI only writes a migration's `up` body):
- `convex/schema.ts` `migrations` table - per-backend ledger (name, checksum,
  status, appliedAt, durationMs, error; `by_name`). Dev and live each keep their
  own; both converge because they run the same committed, ordered, checksummed
  files. Git is the sync channel.
- `convex/migrations/` - one file per migration, `m<YYYYMMDDHHMMSS>_<slug>.ts`
  (the `m` prefix keeps the module name a valid Convex identifier), each exporting
  an `up` internalMutation. Plus `manifest.ts` (GENERATED; the integrity ALLOWLIST
  the runner iterates - a file not listed will not run).
- `convex/migrate.ts` - the runner. `runPending` (internalAction) walks the
  manifest in order, transactionally CLAIMS each migration (the insert is the
  concurrency lock), runs `up`, records the ledger row. Idempotent (skips
  applied). Immutable: if an applied migration's source checksum changes it ABORTS
  (ConvexError, so `db:deploy` halts and the reason reaches the log) rather than
  silently re-running. `listLedger` (status); `resetLedger` (DEV-ONLY teardown /
  local re-apply, guarded by SITE_ENV=development).
- `convex/bootstrap.ts` - `ensure` (internalAction): converges the production-real
  baseline. `ensureModuleBaseline` upserts `moduleSettings` INSERT-IF-ABSENT (never
  clobbers a later admin `setModuleFlags` change), then seeds the admin via
  `internal.admin.seedAdmin` when `ADMIN_USER` is set. Production-safe sibling of
  admin.ts's dev-only sample seeders.
- `scripts/new-migration.mjs` - deterministic scaffolder. `new <slug>` stamps a
  file + regenerates the manifest with a fresh sha256; `verify` recomputes hashes
  and fails on drift (pre-deploy / CI gate); `regen` rebuilds the manifest.

pnpm scripts: `migrate:new`, `migrate:verify`, `migrate:run`, `db:bootstrap`,
`db:deploy`. Integrity is layered: (1) deploy boundary - only deployed functions
run on live, so a file dropped on the VPS does nothing; (2) manifest allowlist -
only listed migrations run; (3) checksum - author-time hash in the manifest,
verified pre-deploy AND re-checked at runtime against the ledger (catches a
manifest re-gen too). See INSTALL.md for the live-box flow.

**Migration decision (mandatory):** any mode that edits `convex/schema.ts` or a
top-level `convex/*.ts` backend function MUST, before presenting its result,
resolve the migration decision: EITHER author + run a migration (`pnpm migrate:new
<slug>` -> fill up() -> `pnpm migrate:run`) for data work (backfill / transform /
drop), OR explicitly record "structure-only -- declarative, no data migration
needed" for a new table / index / optional field that `convex deploy` reconciles
on its own. `pnpm migrate:verify` must pass. Migrations are immutable once
applied. This is enforced deterministically by the PostToolUse hook
(.claude/settings.json + .claude/hooks/convex-migration-reminder.sh) and as a
workflow gate by the Data-Migration Decision Gate in enforcement-checkpoints.md.

### Data deletion (GDPR)

The site is GDPR-compliant. **Three** mutations, sharing ONE internal erasure engine (schema.md
§ H — an admin path and a user path that drift is how a table silently stops being deleted):

- `adminEraseAccount({ userId })` — **admin-only** (never Support), irreversible, invoked when an
  erasure request arrives by email rather than through the UI, which is how most of them arrive.
  Writes an audit record that does NOT retain the erased identifiers.

Two user-owned mutations back the account-page controls:
- `deleteModuleData(moduleSlug)` - deletes the caller's per-module state rows for ONE module, so
  they can start that module over. Keeps the account and the access grant. Behind a clear
  warning. **Every module that adds state must extend this mutation in the same change** — a
  module whose tables are not enumerated here silently survives a user's reset.
- `deleteAccount()` - right to erasure. Deletes the user and their PRIVATE rows across every table
  (per-module state, moduleAccess, **accessRequests**, profile, auth identity + sessions + accounts,
  plus the user's `ticketSubscriptions` and `supportAssignments`), which frees the username +
  email with no PII tombstone. It does NOT delete support/forum content: tickets and messages are
  ANONYMIZED IN PLACE so the public conversation still reads (support-admin.md decision 18,
  2026-05-26). Owned tickets keep their row with `subject` scrubbed to `"Post from a deleted
  account"` + `ownerDeleted` set; authored messages (own tickets and replies on other threads)
  keep their row with `body` replaced by the GDPR removal notice + `authorDeleted` set; the display
  shows a plain `DELETED` author. Irreversible; behind a strong confirmation.

Both are scoped to the authenticated caller only.

---

## auth (Convex Auth, passwordless email-code — DECIDED 2026-05-25)

**Decision (2026-05-25, supersedes the 2026-05-24 password lock): Convex Auth (`@convex-dev/auth`),
self-hosted, PASSWORDLESS via the `ConvexCredentials` provider + an app-owned `loginCodes` table.**
No third-party SaaS, no passwords. The manual self-hosted key setup is unchanged: run
`generateKeys.mjs`, set `JWT_PRIVATE_KEY`, `JWKS`, `SITE_URL` on the backend; `auth.config.ts` uses
`{ domain: process.env.CONVEX_SITE_URL, applicationID: "convex" }`. Beta; accept the maturing
Next.js helpers. Full grounded API recipe + "why not the built-in Email/OTP provider" in
**research-log.md §3** — read it before editing auth code.

**Deliverability is part of auth, not adjacent to it** — [../email.md](../email.md). On this site
the email IS the password: a code that does not arrive is an account with no fallback, because there
is no password to reset. That file covers sender identity (send from `@odysseyalive.com`, NOT the
apps subdomain — SPF/DKIM do not inherit), the send log, and the iCloud sending ceiling.

### The flow

- **Sign-up:** unique **username** + unique **email** (both unique among *active* accounts;
  account deletion frees them — no PII tombstone, clean GDPR erasure).
- **Login:** username OR email identifier → a **6-uppercase-letter (A–Z)** code is emailed to the
  account address, valid **10 minutes**, **one-time use**.
- **Reuse, don't resend:** while an unexpired code exists for an email, repeat requests reuse it
  and send NO second email (this is why the built-in Email provider, which regenerates+overwrites
  per `signIn`, can't be used).
- **Enumeration resistance:** taken **username** → explicit "already taken" error. Taken **email**
  → never disclosed; signup with an existing email silently sends a *login* code to that address
  and advances to the identical code screen. The login email warns "if you didn't request this,
  contact support." The code-entry screen tells the user to check spam.

### Implementation (see research-log.md §3 for API specifics)

- `convex/schema.ts`: spread `authTables`, then **override `users`** with `username` +
  `usernameLower` (+ `by_username` index, + keep `by_email` lookups). Add `loginCodes`
  (`email` lowercased, `codeHash`, `expiresAt`, `attempts`, `pendingUsername?`, `kind`
  login|signup; indexed `by_email`).
- `convex/auth.ts`: `ConvexCredentials({ id: "email-code", authorize })`. `authorize({email,code})`
  → internal mutation `consumeCode` (hash-compare, expiry, attempt-lock, delete-on-success,
  return `pendingUsername`); existing user by email → `{ userId }`; else `createAccount(ctx,
  { provider: "email-code", account: { id: email }, profile: { email, username, usernameLower }})`
  (no secret) → its `user._id`. Re-check username uniqueness atomically at create.
- **Issuance** = a separate public `"use node"` action `requestLoginCode({ identifier, flow,
  username?, turnstileToken })`: resolve identifier→email, run username/email enumeration logic,
  call internal `issueCode` (mint-or-reuse), email via the existing Nodemailer/SMTP path
  (email.ts). Turnstile-gated. In `development` env it also returns the plaintext code (for the
  headless test); in live it returns `{ sent: true }`.
- `checkUsernameAvailable(username)` query backs the signup form's inline pre-check.
- Header: a `login` link → user-icon/menu once authenticated. Gate `/admin` to an admin role.
  Scope per-user data via `getAuthUserId(ctx)` (the `lib.ts requireUserId` pattern).

### SITE_ENV gate (deploy safety)

The dev affordances are gated on the **Convex backend** env var `SITE_ENV`:
`SITE_ENV=development` makes `requestLoginCode` skip SMTP and return the plaintext `devCode`,
makes `consumeCode` NOT consume on success (parallel-safe tests), and enables `authCodes.peekCode`
/ `admin.purgeTestUser*`. **Live must NOT set `SITE_ENV=development`** (leave it unset or set it to
`production`), or it would suppress real emails, disable one-time-use, and expose codes. This is a
separate var from the Next.js build's `NEXT_PUBLIC_SITE_ENV`; set it on the backend via
`npx convex env set SITE_ENV development` in dev only.

### Admin bootstrap (passwordless)

`seedAdmin` no longer uses `ADMIN_PASS`. It ensures the admin account from `ADMIN_USER` (email) +
`ADMIN_USERNAME` (default derived from the email local-part) via `createAccount` with no secret;
`lib.ts adminEmails()` already grants admin to `ADMIN_USER`. The `signInAsAdmin` test helper signs
in by issuing+consuming a code for `ADMIN_USER` through the dev deterministic-code path. **2026-05-25:**
`ADMIN_USER` is now `francis@odysseyalive.com` (the `admin@` mailbox doesn't exist); an idempotent
reconcile renames any legacy `admin@odysseyalive.com` user row + its `authAccounts`
providerAccountId to the current `ADMIN_USER`.

### Access model and access-request flow

**Now:**
- **Account registration is open and self-service:** anyone can create an account at
  apps.odysseyalive.com (passwordless: unique username + email, 6-letter email code). No invite
  needed.
- **Signup is protected by Cloudflare Turnstile** (captcha), reusing odyssey-alive's
  `verifyTurnstile` pattern and the `NEXT_PUBLIC_TURNSTILE_SITE_KEY` / `TURNSTILE_SECRET_KEY`
  keys. The contact form and newsletter signup use Turnstile too (the newsletter keeps its
  honeypot + timing as defense-in-depth). The newsletter is open to anyone.
- **The module intro page `/modules/<slug>` is public** to everyone, logged in or not. Browsing
  it requires nothing.
- **Module access is admin-granted, manually.** A newly registered user shows up in the admin
  user-management list (support-admin.md) with no module access; the admin grants a module via
  `grantAccess`. To grant before/without the user being in view, also provide
  `grantAccessByEmail(email, moduleSlug)`. **The manual grant is the only way access is ever
  conferred** (Francis, 2026-07-22: "access has to be given manually").
- **The app gate** (`/modules/<slug>/app`): not logged in -> prompt to create an account or log
  in; logged in but not granted -> the beta state; granted -> the app. The module's own Convex
  queries and mutations also check `hasAccess` server-side, so a user cannot reach module data
  without permission even by calling the API directly.

**The beta-request flow (LIVE here, unlike odyssey-skul).** odyssey-skul declared
`accessRequests` and deliberately left it unwired — "closed beta does not use it yet … Do NOT
build the self-service UI yet." This site activates it, per Francis's directive that both modules
carry a beta button. A logged-in user on a public intro page presses **Request beta access**;
that writes an `accessRequests` row with `status: "pending"` and notifies the admin. The admin
approves from the queue, and the approval mutation calls `grantAccess` in the same transaction.

**The request never grants.** Nothing in that flow may write `moduleAccess` except an explicit
admin approval. The full contract — schema, functions, the five UI states, emails, abuse
controls, and the seven exit tests — is [../beta-access.md](../beta-access.md), and the runbook
is [beta.md](beta.md).

### Account lifecycle

self-service register -> browse `/modules/<slug>` (public) -> **request beta access** -> admin
approves, which grants the module -> use the module app. Plus profile edit and the account-page
data-deletion controls (§ Data deletion).

---

## AI features (first-party, in-repo)

**Decision (2026-07-22, Francis): every AI capability is code we build in this repo, proprietary
and locked in.** No n8n, no Zapier, no external orchestration service, no third-party AI-workflow
SaaS in the request path. Convex is the database AND the place the AI work runs.

Grounding: modules.json `$architecture`. Read it before designing any AI surface.

**The provider is OpenRouter** (decided 2026-07-22). One integration, many models, and it reports
token counts AND actual cost with every response — so this repo maintains no price table. Two
traps worth knowing before writing the client: with fallback routing the model that ANSWERS may
differ from the one requested, so metering records the response's `model`/`provider`, never the
request; and streamed responses deliver usage only in the final SSE message. **The second does not
bite today** — OpenRouter is used by server-side SCRIPTS performing defined jobs, never a chatbot
streaming to a browser (usage-metering.md § A-bis) — but the guard is retained for the day a
streaming surface appears.

**Jobs, not turns.** One user action may fan out into several model calls (extract, draft, check).
Every call carries a shared `runId` so cost per UNIT OF WORK is answerable, not just cost per call.
No conversation history is stored — a real privacy simplification, and one to preserve
deliberately. Multi-call jobs that outrun a Convex action's execution limit are chunked or
scheduled; each chunk still meters its own calls.

`OPENROUTER_API_KEY` is set on the **Convex backend** environment, never `NEXT_PUBLIC_`.

**Where the code goes.** Model calls are side effects and third-party network I/O, so they belong
in Convex **actions** (the Node runtime) — the same place the ported email sends live. Actions
cannot touch `ctx.db` directly; they read and write through `ctx.runQuery` / `ctx.runMutation`.
A query or mutation that tries to call a model API is in the wrong function type.

**In-house default applies here too.** Before reaching for a hosted API to solve a sub-problem
inside an AI feature (vector search, OCR, PDF generation, transcription), work the preference
ladder in SKILL.md § Directive amendment. Convex and the Node runtime already cover more of this
than a first instinct suggests, and every added service is another processor, another bill, and
another thing that can be down.

**An AI feature is not a special case.** Because it is first-party code on the site's own stack,
it carries the same obligations as any other module surface, and skipping one because "it's just
the AI part" is how the gaps appear:

1. Schema for whatever it persists (prompts, runs, outputs, caches), scoped by `userId`.
2. A migration, if the schema changed (Data-Migration Decision Gate).
3. The module's `hasAccess` re-check server-side — an AI action is directly callable, and it
   costs real money per call, so an unguarded one is both a data leak and a billing hole.
4. Registration in `deleteModuleData` and `deleteAccount` — model inputs and outputs are user
   data (§ Data deletion).
5. A headless-Playwright exit test.

**Non-determinism vs. the test gate.** The suite must still pass reliably, and asserting on
generated prose will flake. Test the *contract*, not the *content*: the action was called, it was
entitlement-gated, it persisted a row of the right shape, failures surface to the user, and the
route renders the result. Where output quality itself matters, that is a judgment question for
Francis, not a Playwright assertion.

**Things to research before designing, not during** (coding lane, per the research-precedence
directive; write findings into research-log.md): which Convex capabilities this actually uses,
how model credentials reach the self-hosted backend's environment, timeout and retry behavior for
long calls, and cost controls. Do not design against remembered capability sets — they move fast.

**Cost is a product constraint, not an ops detail — and it is METERED, not capped.**
Every model call goes through the one metered helper that records tokens and computed cost
([../usage-metering.md](../usage-metering.md) § B; enforced by the AI Metering Chokepoint Gate).
There are deliberately NO per-user caps right now: module access is granted by hand, so **the beta
gate is the spend control**. That protection ends the moment access becomes automatic on payment —
revisit metering in the same change as the subscription directive amendment.

---

## module-app <slug>

Scaffold or extend a module's own application: a **first-party Next.js route tree in this repo**
at `/modules/<slug>/app`, entitlement-gated on `moduleAccess`, with its per-account state in
Convex. This replaces odyssey-skul's `game-bridge`, and it is structurally simpler: there is no
foreign interpreter, no opaque save blob, no same-origin constraint, and nothing to embed.

**Scope gate (first, before any code).** Read `modules.json` for this slug. IF `product_scope` is
still OPEN → **STOP and workshop the scope with Francis.** Record the agreed first beta surface
in the registry, then build. Do not infer a feature set from the module's name. Building a gated
shell — the route, the guard, the empty-state — is always in scope; inventing the product is not.

**Access gate (always, and server-side).** The `/modules/<slug>/app` route tree is entitlement-
gated. Before rendering, check `hasAccess(userId, moduleSlug)` **and** `moduleAppEnabled(slug)`:

- Not logged in → prompt to create an account or log in, carrying `?next=`.
- Logged in, not granted → the beta state: "request access" if they have no open request, or
  "you're on the beta list" if they do (beta-access.md § The button). Never the app.
- Granted but `appEnabled` false → an honest "not switched on yet" state, not a broken page.
- Granted and enabled → the app.

The gate lives in the route layout so it covers **every** nested route at once. And it is not
only a route guard: **every query and mutation in the module's own Convex functions re-checks
`hasAccess` server-side**, exactly as the ported save/load endpoints did. A UI gate alone is not
an entitlement — someone will call the API directly.

**State.** Declare the module's tables in `convex/`, namespaced by module (`mer*`, `sign*`),
every row scoped by `userId` via the ported `lib.ts requireUserId` pattern. Then, in the SAME
change: register them in `modules.json` `convex.state`, wire them into `deleteModuleData`, and
wire them into `deleteAccount` (§ Data deletion). A module that adds state without touching both
erasure paths is a GDPR bug that will not be visible for months.

**Binaries go in Convex file storage.** Any file a module accepts or produces is stored in Convex
and referenced by storage id — never written to the host filesystem and never committed. That keeps
ONE backup surface (backups.md § A-bis) and makes erasure reach the bytes. Deleting the referencing
row must delete the stored file too, or the bytes outlive their row invisibly.

**Schema changes go through migrations.** Any change to `convex/schema.ts` triggers the
Data-Migration Decision Gate (enforcement-checkpoints.md) — same as every other backend change.

**`sign-me` carries an extra constraint.** An e-signature product has evidentiary requirements
the rest of this site does not: an append-only audit trail, immutable storage of the signed
artifact, and recorded signer identity + consent. Research that on the coding lane and design the
schema around it from the first line — an audit trail retrofitted onto tables that were not built
for one is a rewrite, not a patch. Surface the legal-review question to Francis rather than
implying the implementation is compliant.

**Exit verification (mandatory):** before presenting any backend mode's result, author/run the
headless-Playwright exit-test that operates the real flow (convex round-trip, login, the module
entitlement gate from BOTH the route and the API, the beta request -> approval -> access path),
confirm it passes, and clean up test data and files after the run (test-suite.md; SKILL.md Test-Suite Verification gate). No shortcuts. When the
mode also changed `convex/schema.ts` or a `convex/*.ts` function, the Migration decision
(mandatory) above is a SEPARATE required exit gate (Data-Migration Decision Gate in
enforcement-checkpoints.md); both must pass before presenting.
