# Procedure: scaffold, theme, serve, test, debug

Grounding: read [../port-inventory.md](../port-inventory.md) and
[../palette.md](../palette.md) before scaffold/theme; [../templates-inventory.md](../templates-inventory.md)
is the secondary reference for anything the port lacks. Browser verification is Playwright only.

Design quality: build UI with `/frontend-design`, using the odyssey-alive project
(`/home/francis/lab/odyssey-alive`) as the visual touchstone for layout, components, motion, and
polish. Match what odyssey-alive does; do not ship generic AI-looking UI.

---

## scaffold

Creates the app in the repo root by **porting the site half of nsayka-wawa** and stripping the
Inform 7 game half. The skill lives at `.claude/skills/odyssey-apps/`; the app lives at the repo
top level alongside it.

**Read [../port-inventory.md](../port-inventory.md) in full before the first copy.** It is the
authoritative list of what comes, what is stripped, and what is renamed. Do not improvise the
selection.

1. Confirm the app does not already exist (`package.json` absent at repo root). If present,
   stop and suggest `serve` or a targeted `page`/`module` mode.
2. Confirm `$SRC` = `/home/francis/lab/nsayka-wawa` resolves and is readable. It is a live
   sibling project: **the port is a one-way copy — never write into `$SRC`.**
3. **Copy** per port-inventory.md § A: `convex/`, `src/`, build config, `scripts/`, `tests/`,
   `deploy/`, `docker-compose.yml`, `Dockerfile`. Use pnpm. Preserve `output: "standalone"` in
   `next.config.ts`.
4. **Strip** per port-inventory.md § B, in one pass, before anything is run: the Inform 7 and
   Glulx trees, the save bridge, the progress model, the leaderboard, the explorer, every
   Chinuk Wawa surface, Field Notes, and the Git-LFS provisioning. Deleting a table means
   deleting its indexes, seeders, and tests too — a half-stripped table fails `convex deploy`
   loudly, which is the intended signal.
5. **Rename** per port-inventory.md § D: naming, domain, port 3050, route group `(play)` → `(app)`
   and leaf `/play` → `/app`, `playEnabled` → `appEnabled`, "player" → "user", "game" → "module
   app", the Convex instance name. Apply mechanically, then **read the prose for damage** — several
   renames land mid-sentence.
6. **Route tree after the port** (App Router):
   - `/` home (authored fresh via `page home`)
   - `/modules` listing, `/modules/[slug]` intro page (public; carries the Request-beta block)
   - `/modules/[slug]/roadmap`
   - `/contact`, `/support`, `/support/[slug]`, `/support/[slug]/ticket`, `/forum-rules`
   - `/admin` (user management + module grants + ticket triage + the beta queue)
   - `/login`, `/account`, `/privacy`, `/terms`
   - `/modules/[slug]/app` — the module's own app, **entitlement-gated** on `moduleAccess`
     (`module-app` mode builds it)
   - `/api/og` and route handlers as needed
7. **Velite:** the `modules` collection ports as-is; add `betaEnabled` + `betaBlurb`, remove
   `scoreLabel` (port-inventory.md § D).
8. Carry **two** fonts: Inter (body), Playfair Display (headings). Gentium Plus is dropped.
9. Write `.env.example` from the ported key names (templates-inventory.md § Env keys +
   research-log.md). Real secrets go in `.env.local` (gitignored). **Generate this site's own
   Convex auth keys** with `scripts/generateKeys.mjs` — never reuse nsayka-wawa's signing key.
   The Mailchimp audience ID is an open decision (port-inventory.md § C.4) — surface it, do not
   copy skul's.
10. `pnpm install`. Do NOT commit secrets.
11. Immediately run `theme` (below), then `test` to confirm a clean build, then `verify`.

Defer Convex backend work to `convex` mode, the module apps to `module-app`, and the beta flow
to `beta`.

## .gitignore (build or edit)

**Delivery method:** jstack clones THIS repo into `jstack/sites/apps.odysseyalive.com`. Unlike
nsayka-wawa, this repo is **not** a monorepo carrying a compiled game — there is no large binary
to deliver, no Git LFS, and nothing under `public/modules/<slug>/` that must be committed as a
build artifact.

If a root `.gitignore` already exists, read it first and add only the missing entries
idempotently, preserving existing lines and ordering. Otherwise create it.

Ensure these entries are present:

- dependencies: `/node_modules`, `.pnp*`, `.yarn/*`
- Next.js: `/.next/`, `/out/`, `/build`, `next-env.d.ts`
- Velite: `/.velite/`
- env: `.env`, `.env.local`, `.env*.local` (real secrets are never committed)
- self-hosted Convex data: `/data/` (the bind-mounted DB lives on the host, outside git; see
  backend.md § Database persistence)
- Convex generated: `.convex/`
- test artifacts: `/test-results/`, `/playwright-report/`, `/playwright/.cache/`
- OS/editor: `.DS_Store`, `.idea/`, `.vscode/*` (keep `!.vscode/extensions.json`)
- backups: `.claude-backups/` (skill-builder snapshots)

Generated public assets staged by `scripts/copy-assets.js` follow the port's existing convention;
do not ignore committed source assets under `assets/`.

## theme

Apply palette.md (blue surface-white-gold). Full sweep and the contrast rule live there —
this is the short form:

1. Rewrite the `@theme` / CSS-variable tokens in `src/app/globals.css` per the token map:
   white surface, cool off-white secondary, blue accent family, and the **new gold family**
   (`--brand-gold`, `--brand-gold-hover`, `--brand-gold-soft`) that neither ancestor has.
   Hexes are PROPOSED — confirm with Francis at the rendered-page review, not on paper.
2. Grep components for the port's shipped tokens and hexes — nsayka-wawa's navy/cream
   (`#1E3A5F`, `#2C5F8A`, `#FDF8F0`, `#F7EDE2`, `#142233`) and any surviving `brand-coral` from
   the odyssey-alive ancestry. Known touch points: HomeContent, Header (nav underline + pulse
   dot), Footer, Button.
3. **Place gold by hand, never by find-and-replace.** It is an accent that appears a few times
   per page. Every insertion is checked against palette.md § The gold rule — gold is not a text
   color on white (2.9:1), only on navy.
4. Drop the Gentium Plus font face and its `--font-cw` token; the CW type role no longer exists.
5. Run `test` and verify with Playwright at both viewports: blue renders as the accent, gold
   appears only in permitted roles, contrast holds.

## serve

**One command brings up the whole site: `pnpm serve`** (the skill mode `/odyssey-apps serve`
runs this). It is an orchestrator (`scripts/serve.sh`) because "the site" is more than the Next
server, and several non-obvious facts (learned the hard way) are baked in:

1. **State the environment first** (Environment Resolution gate): read `NEXT_PUBLIC_SITE_ENV`
   from `.env.local` and print it.
2. **Self-hosted Convex must be up** or the auth/account/support/admin/module-app routes error. The
   script runs `docker compose up -d` (plain `up` excludes the `prod`-profile `next-app`, so only
   Convex backend + dashboard start) and waits for `http://127.0.0.1:3220/version` to answer.
3. **Seed the admin** (idempotent, best-effort): `npx convex run admin:seedAdmin` (backend.md
   § seed-admin). A no-op if the admin already exists; never blocks startup.
4. **Start the Next server.** Default `pnpm serve` runs `pnpm dev` (hot reload). `pnpm serve prod`
   runs `next build` then `next start`.
   - **The dev server uses Turbopack** (`next dev`, the Next.js 16 default), matching
     odyssey-alive. Keep the `source(none)` + scoped `@source "../../src"` / `"../../content"`
     lines the port carries in `globals.css`. They were added in nsayka-wawa to stop Tailwind v4
     auto-detecting the monorepo's Inform game extensions into a malformed content glob; this
     repo has no such files, so the scoping is no longer load-bearing — but it is still correct,
     cheap, and it keeps the content scan tight. Do not delete it as "dead config."
   - **Do NOT use `next dev --webpack` here.** Next 16's webpack dev server silently drops Tailwind
     v4 arbitrary-value utilities (`aspect-[4/3]`, `h-[..vh]`), so aspect-ratio'd image containers
     collapse to height 0 — backgrounds load (HTTP 200) yet render invisible. Turbopack dev and
     `next build` both generate them correctly. The `tests/art` collapse guard asserts painted
     height > 0 at desktop **and** mobile widths to catch this regression.
5. **Report the URLs:** site `http://localhost:3050`, Convex dashboard `http://localhost:6792`,
   Convex backend `http://127.0.0.1:3220`.

Dev port is 3050 (distinct from odyssey-alive's 3030). This is local dev only; production serving
is jstack (deploy mode). The dev-apps.odysseyalive.com TLS mirror (environments.md) remains the
faithful-rehearsal option for Convex WSS / TLS-behind-proxy testing; `pnpm serve` is the fast path.

**Stopping the stack: `/odyssey-apps serve stop`** (`pnpm serve stop` or `pnpm stop`; handled by
`scripts/serve.sh stop`). It reverses the bring-up:

1. Stops the Next server by finding whatever listens on port 3050 (`next start`/`next dev`),
   including a backgrounded or detached serve, then TERM then KILL for stragglers.
2. Stops any stray host-level `convex-local-backend --instance-name odyssey-apps` left by a
   non-docker dev run (scoped to the instance name, so sibling projects are never touched).
3. `docker compose stop` for the self-hosted Convex backend + dashboard. **`stop`, never `down`**,
   so the Convex data survives: accounts, module state, beta requests, and support tickets must persist
   across a stop/serve cycle. **Note the data is a HOST BIND MOUNT (`./data/convex`), not a named
   volume** — so `docker compose down -v` does NOT wipe it. Deliberately wiping means stopping the
   stack and deleting that host directory (backend.md § Database persistence).
4. Verifies port 3050 is free.

The stop path is idempotent: re-running it when the stack is already down reports the clean state
and exits 0. It is the teardown counterpart to the serve bring-up and lives in the same orchestrator
so the lifecycle stays in one place.

## test

The `test` mode is the curated headless-Playwright test-suite. Its full procedure lives in
[test-suite.md](test-suite.md): discover/run/list, env-aware base URL, screenshots, the
exit-test rule every other mode obeys, the after-every-run cleanup, **delegation to the
playwright-mcp suite tooling**, the **TEST-DEFECT vs PRODUCT-BUG adjudication rubric**, and the
session-isolation rule (fresh session per test by default — the erasure spec deletes its account). `next build` (type/lint
clean) is the first gate; the Playwright drive is the real verification. Playwright only, never
claude-in-chrome.

## debug <route>

Surgical router; pick the narrowest route. Each isolates one surface:
`build` (compile/type errors), `deploy` (Docker/compose/nginx artifacts), `theme` (token
sweep + the gold-contrast rule), `newsletter` (Mailchimp action + gating), `convex` (backend
connectivity, schema push), `auth` (session/login flow), `module` (the entitlement gate and the
module app route tree), `beta` (request → queue → grant, beta.md), `support` (ticket CRUD),
`observability` (error capture, invariant checks, alerting — observability.md),
`email` (deliverability, SPF/DKIM, send logging, the dev bypass — email.md),
`content` (MDX/Velite collection issues), `og-parity` (SEO/OG/social-cards parity
with odyssey-alive — see below). Reproduce, fix, then author/run the matching
headless-Playwright exit-test (test-suite.md) and confirm it passes before presenting. No
shortcuts. Routes that need an admin (`auth`, `support`, `module`, `beta`, `convex`) first run
`/odyssey-apps convex seed-admin` and sign in as `ADMIN_USER` (the `signInAsAdmin` helper),
so the admin path is deterministic rather than re-created ad hoc (backend.md § seed-admin).

### debug og-parity

Audits SEO + OG + social-card + sitemap/robots parity against odyssey-alive (the reference
template project) and applies the missing invariants. Reuse the design system; do not invent
a new pattern. Read [../parity-with-odyssey-alive.md](../parity-with-odyssey-alive.md) for the
canonical invariants and the curated diff list (what must match, what is intentionally
diverged).

Procedure (in order; skip any step whose invariant already passes):

1. **Root metadata** (`src/app/layout.tsx`). Required exports on the `metadata` constant:
   `metadataBase: new URL(SITE_URL)`, full `openGraph` block (type, locale, url, siteName,
   title, description, images[1200x630]), full `twitter` block (`summary_large_image`, site +
   creator handles), `robots` (index/follow + googleBot tuning), `alternates.canonical`. Use
   `SITE_URL` from `@/lib/schema`, never a hardcoded URL.
2. **Dynamic OG endpoint** (`src/app/api/og/route.tsx`). Edge runtime, `next/og` `ImageResponse`
   (Next 16 built-in — no `@vercel/og` dependency). Reads `?title=`, `?description=`,
   `?eyebrow=` query params with safe length truncation. **Regrade to this site's palette:** a
   navy field (`#0C2340` → `#123A6B` gradient), title in `#F2F6FA`, and the gold accent
   `#E8C766` for the eyebrow/rule — gold on navy is the one place gold carries text
   (palette.md § The gold rule). Output 1200x630.
3. **Per-module metadata** (`src/app/(marketing)/modules/[slug]/page.tsx`). The
   `generateMetadata` export must return the full Metadata shape, never just
   `{title, description}`. Image fallback chain: `mod.socialImage` (author override) → dynamic
   `/api/og?title=…&description=…&eyebrow=…`. Set `alternates.canonical` to
   `${SITE_URL}/modules/${slug}`. Mirror odyssey-alive's focus page pattern at
   `src/app/(editorial)/focus/[slug]/page.tsx:35-83`.
4. **Velite schema** (`velite.config.ts`). The `modules` collection must expose an optional
   `socialImage: s.string().optional()` field so content authors can override the per-module
   OG image with a static asset path (relative to `/public`). The dynamic /api/og fallback
   covers modules that don't.
5. **Sitemap + robots** (`src/app/sitemap.ts`, `src/app/robots.ts`). Intentional divergence
   from odyssey-alive: robots disallows `/account/`, `/admin/`, `/login/` in addition to
   `/api/` and `/_next/`. Sitemap is static + published-module entries (no blog/tag pages).
   Confirm those invariants; do NOT re-import odyssey-alive's article-crawling sitemap.
6. **Newsletter** parity is handled by the `newsletter` debug route; only flag it here if a
   diff is detected.
7. After applying changes, write/run the matching Playwright test (test-suite.md) that fetches
   `/api/og?title=Smoke` and asserts a 200 + PNG content-type, and that the module detail page
   serves the expected `og:image` meta. Stop on first failure.
