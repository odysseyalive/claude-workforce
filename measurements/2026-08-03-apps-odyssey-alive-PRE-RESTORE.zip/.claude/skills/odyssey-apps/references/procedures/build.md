# Procedure: build (full-project orchestration)

`/odyssey-apps build` is the single command that builds the complete Odyssey Apps site end to
end. Run it in a fresh, clean session. It executes every phase in dependency order, gates each on
its headless-Playwright exit-test (cleaning up test data after each run), self-corrects routine
breakage before advancing, pauses only at genuine decisions, and is resumable.

## Before running

Read SKILL.md (directives + enforcement gates), then port-inventory.md, palette.md,
beta-access.md, connectors.md, environments.md, research-log.md, and modules.json. Confirm
prerequisites and state which are missing:

- `.env.local` holds Turnstile + SMTP from nsayka-wawa, the three **Mailchimp keys from
  odyssey-alive** (same newsletter, same audience — port-inventory.md § C.4), and this site's OWN
  Convex keys (generated, not copied from nsayka-wawa).
- pnpm + Node; Docker (for self-hosted Convex); the `dev-apps.odysseyalive.com` hosts-file entry
  + local TLS for the mirror (environments.md).
- `/home/francis/lab/nsayka-wawa` readable — it is the port source.
- The repo's `/image` skill has been rethemed to the graphic system (art.md), NOT photography. Phase 6 blocks on this.

Stop if a hard prerequisite (pnpm, Docker, the port source) is absent; otherwise proceed.

## Task list (resumable)

TaskCreate one task per phase below, in order, so the long build survives context compaction. On
re-run, detect completed phases (is the app scaffolded? do the module pages render? is Convex
up?) and resume from the first incomplete one. Mark each task in_progress, then completed.

## Phases (run the mode, then its exit-test, then proceed)

1. **Port + strip.** `scaffold` (copies nsayka-wawa's site half, strips the game half, applies
   the global renames, writes `.env.example`, `pnpm install`). **Then lay the e2e foundation:**
   run playwright-mcp `suite_scaffold` (test-suite.md § Delegate the plumbing) so the environment
   guard, page-integrity gate, and error capture exist BEFORE the first exit test is authored —
   retrofitting them across a written suite is far more work than starting with them.
   Exit gate: `pnpm build` clean and `convex deploy` accepts the stripped schema. **Do not proceed with a half-stripped tree** —
   every later phase inherits its breakage.
2. **Theme.** `theme` (white surface, blue accent, the new gold family; drop Gentium Plus).
   Decision to surface: confirm the palette hexes on the rendered page (palette.md — they are
   PROPOSED, not locked).
3. **Backend.** `convex` (self-hosted, bind-mounted data outside the image), `auth` (passwordless
   email-code + Turnstile), `support`, `admin`. Empirical gates (must really pass, no faking):
   exactly one Convex backend reachable behind the proxy; a real login code round-trip; the
   ticket loop fires the email action. Auth and admin come across from the port already working —
   the gate here is proving that in THIS repo, not rebuilding them.
4. **Modules.** `module meridian`, `module sign-me`, then `module-intro` for each. Then
   `beta wire` — **mostly a PORT, not a build**: `requestBetaAccess`, `myAccessRequests`,
   `hasPendingBetaRequest`, `listAccessRequests` and the `BetaIntentClaimer` handoff already exist
   in the source and come across working. Add only `note`, `withdrawn`, `denyReason`, the decision
   mutation, the five UI states, and the approval/denial emails (beta-access.md). Empirical gate: a
   request creates a `pending` row, an admin approval grants access, and an ungranted user is
   still refused at `/modules/<slug>/app`.

   **`module-app` is NOT in this phase.** Both modules carry `product_scope: OPEN` in
   modules.json; their app surfaces are workshopped with Francis and built after the site stands.
   Building a gated shell is in scope; inventing a product is not.

   **Sequencing decision (Francis, 2026-07-22): build the SITE first, the modules separately
   afterward.** So this phase ships each module's intro page **thin and honest** — the name, one
   line on what it is, and the Request-beta button — and stops there. A short page is the
   CORRECT page for a product that does not exist yet; it is not a placeholder to apologize for,
   and `/copy-truth` will pass it precisely because it claims nothing. The upside is real: the
   beta waitlist starts collecting the day the site goes live, before either module is built.

   Do NOT pad these pages to fill a layout. If the design looks empty with honest copy, fix the
   design for the thin case — that is the case that ships first and stays longest. `module-intro`
   fills the page out properly once `product_scope` closes.
5. **Content + the account area.** `page home`, `page contact`, `page privacy`, `page terms`, and
   the account surfaces per [../account-area.md](../account-area.md) — Overview reshaped to its four
   states, Progress stripped, and the **My Tickets** tab added (private tickets removed the public
   list that was previously a user's only route to their own threads). Design the ZERO-state first:
   with open signup and manual grants, an account with no access is what nearly every visitor sees. Footer carries the
   quiet-parent credit — "from Odyssey Alive" — and the newsletter posts to **odyssey-alive's own
   audience** (port-inventory.md § C.4), so the signup copy says Odyssey Alive rather than naming
   a site-specific list. All copy through
   `/my-voice` + `/wit` + `/text-eval` + `/copy-truth`. The home page is authored fresh — the
   port's home is a language-learning pitch and does not transfer.
6. **Imagery — the graphic system.** Establish the system BEFORE producing assets: fix stroke
   weights, tick spacing, and the mark family as tokens, then build the line/point/contour
   components as **SVG** (art.md § SVG first — line-work is authored, not generated, because
   generated line-work drifts between assets and cannot be recoloured from tokens). Retheme
   `/image` to this system for the textural pieces only. Then the logo and favicon. Everything
   reviewed with Playwright on the rendered page at both viewports (palette.md § Build-time
   graphics review) — hairlines especially, since a 1px gold line can disappear on a low-DPI
   screen. Decisions to surface: the mark's blue/gold treatment and its transparency over the navy
   footer.
7. **Deploy.** `deploy` (Next.js standalone Dockerfile, docker-compose with the Convex
   bind-mount, site.config, the nginx proxy template, `.env.example`). No Git LFS and no baked
   game assets — this repo ships no large binary. **Plus backups** (backups.md): a scheduled
   Convex logical export into the site dir, offsite and encrypted, and a restore drill actually
   performed. **Plus observability** (observability.md): in-house error capture (`errorLog` + invariant
   checks — no third-party service, per the self-hosting directive), source maps retained with
   tagged releases, `/api/health`, and an external heartbeat for the case where the box itself is
   gone. Empirical gates: `docker compose config` validates; the proxy resolves the domain to
   the Next port and forwards WS; **and a backup has been restored into a scratch environment
   with its recovery time recorded** — an untested backup is not a backup, and usage history is
   the one thing here that cannot be reconstructed.

## Per-phase loop (apply, refresh service, verify, compensate, advance)

Each phase runs as a self-correcting loop, so an autonomous goal-driven run fixes routine breakage
on its own and escalates only genuine unknowns:

1. **Apply.** Run the phase's mode(s).
2. **Refresh the service** so the test sees the CURRENT build, never a stale one: stop the running
   dev server, then rebuild/restart it (`next build`, or restart `next dev` via `serve`); run
   `npx convex deploy` if Convex schema/functions changed; restart containers if the compose
   changed. Never run a phase's test against an old build.
3. **Verify.** Run the phase's headless-Playwright exit-test (author it via `test discover` if none
   exists). It must drive the rendered site and read console/network, not assume.
4. **Compensate if broken — but ADJUDICATE FIRST.** This is the step where an autonomous loop
   goes wrong, so it is gated.

   Before touching anything, classify the failure. Evidence first — artifacts, page snapshots,
   server state — **never the error message string**, because two unrelated bugs routinely render
   the same user-facing error:

   - **TEST-DEFECT** — the software is right and the test is wrong: stale selector, wrong fixture
     data, timing budget, session-shape violation, mis-declared expectation, environment not
     established. → Fix the SCRIPT. Re-run to green.
   - **PRODUCT-BUG** — the software violates its own contract while the test's expectation matches
     intended behavior, reproduced under a correct, freshly-verified setup. → **The spec stays
     BYTE-FOR-BYTE UNTOUCHED.** Fix the product as a deliberate change, never as a side effect of
     making tests pass.
   - **AMBIGUOUS** — the evidence supports both readings. → STOP and present both to Francis.
     **Never default toward the side you are allowed to edit.**

   Then fix, refresh the service (step 2), and re-run. Use `/odyssey-apps debug <route>` for the
   matching surface. Iterate up to **3 attempts** per phase.

   **Why this gate exists.** This loop runs autonomously and is rewarded for turning red green. An
   unadjudicated loop will eventually weaken an assertion to pass a phase — and a weakened
   assertion is indistinguishable from success in the closing report. Rubric source:
   playwright-mcp `suite_methodology` § 4; the same rubric backs `suite_audit`.

   **Forbidden compensations, in every case:** deleting or skipping a failing test; loosening an
   assertion to accommodate observed behavior; adding a wait to mask a race; marking a spec
   `.skip`/`.fixme` to advance. Any of these ends the phase and escalates instead.
5. **Escalate, do not thrash.** STOP and report (with run output + screenshot) if: still failing
   after 3 attempts; OR the verdict is PRODUCT-BUG or AMBIGUOUS (step 4); OR the failure is a
   flagged empirical unknown (Convex behind nginx, TLS on the dev mirror), a missing prerequisite,
   or a genuine design/decision question.
   Never fake a pass or skip a broken phase to keep moving.
6. **Clean up + advance.** Remove test data + run artifacts (test-suite.md § Cleanup), mark the
   task completed, move to the next phase. On resume, re-verify the last completed phase before
   continuing.

This is what makes `build` safe to drive autonomously: it self-heals what it can prove and fix,
and surfaces what it genuinely cannot.

## Rules (inherited, non-negotiable)

- Every phase runs its headless-Playwright exit-test before the next, and cleans up test data +
  files after each run. No shortcuts; never present an unverified phase (SKILL.md Test-Suite
  Verification gate).
- Playwright only; never claude-in-chrome.
- Proceed with the ratified decisions without re-asking: private + proprietary; port from
  nsayka-wawa and strip the game half; passwordless Convex Auth; blue/white/gold palette;
  a drawn graphic system for imagery (never photography or watercolour); slugs `meridian` and `sign-me`; admin-granted module access with a
  beta-request button that never grants; open registration + Turnstile on all public forms; all
  outgoing email via Francis's SMTP; GDPR (/privacy, /terms, account data deletion); site copy via
  my-voice/wit. PAUSE only at the genuinely open decisions — the palette hexes on the rendered
  page, the logo/favicon treatment, the beta re-request rate limit, and both modules' product
  scope — surfacing them rather than silently guessing.
- Failure handling follows the Per-phase loop above: compensate routine breakage (bounded to 3
  retries), escalate empirical unknowns / missing prerequisites / decisions. Never fake a pass or
  skip a broken phase.

## Close

Run `/odyssey-apps verify` — the full gate, not just `test --all`: one authoritative Convex
backend, `pnpm build`, and the complete Playwright suite at BOTH viewports. Drive the whole site
once (every route, signup -> login-code -> account, a beta request -> admin approval -> module
app, the newsletter, support, admin). Report status per phase plus deferred items
(transactional-email specifics, rate limiting, backups, both modules' product scope, and the
empirical infra checks that need the real VPS).
