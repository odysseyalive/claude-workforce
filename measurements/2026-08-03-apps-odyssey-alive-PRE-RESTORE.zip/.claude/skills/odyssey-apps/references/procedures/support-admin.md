# Procedure: support, admin

<!-- RETARGETED 2026-07-22 — read this banner before the body -->
> **PRIVATE TICKETS ONLY (2026-07-22 directive amendment).** This file was ported from
> odyssey-skul, where support was a **public-reading forum** with versioned rules and a forced
> re-agreement gate. That model is **stripped** here. Wherever the body below describes public
> reading, forum threads, rules versions, re-agreement, profanity filtering, or the
> `forumEnabled` flag, it is describing the SOURCE site and does not apply.
>
> What this site has instead: a ticket is visible to **its owner, an assigned Support user, and
> the admin** — nobody else, ever, signed in or not. There is no public `/support/<slug>` thread
> list, no `/forum-rules` page, and no `forum-rules` skill mode.
>
> **Why:** the users are real-estate agents, and a support thread about a problem is routinely a
> thread about a live transaction with a real client in it. A public forum invites people to
> disclose what they are professionally obliged to keep confidential, and rules copy does not fix
> an affordance.
>
> **ADDED 2026-07-22:** the admin desk also carries a **GDPR erasure** action — an admin can
> completely wipe a user account on that user's behalf. It is the most destructive control on the
> desk, it is admin-only (never Support), and it shares one erasure engine with the user's own
> self-service deletion. Full requirements: [../schema.md](../schema.md) § H.
>
> **ADDED 2026-07-22 (2):** the admin desk carries a **Usage** panel — token and cost metering per
> module over an adjustable timeframe, the input to Francis's pricing decisions. Admin-only, never
> Support: cost data is business information, not support tooling. Chart work routes through
> `/dataviz`, and gold cannot be a series color on a light chart (~2.9:1). Spec:
> [../usage-metering.md](../usage-metering.md) § G.
>
> **CONSEQUENCE (2026-07-22):** removing the public thread list also removed how a user found
> THEIR OWN tickets. The account area gains a **My Tickets** tab to restore that
> (../account-area.md § D). Nothing errors without it — the tickets exist, replies arrive, and the
> user simply has nowhere to read them.
>
> Everything else in this file — the ticket lifecycle, statuses, purpose enum, assignment, the
> Support role, admin triage, reply-with-email, sorting, page size, and the GDPR anonymization
> rules — carries over unchanged and is still authoritative. The strip list is
> port-inventory.md § B.


All ticket state lives in Convex (backend.md schema). Grounding: read [backend.md](backend.md)
for the schema and functions.

> **MAJOR REVISION — 2026-05-26 (Francis, this session).** Support was a tab inside the account
> area; it is now a **standalone, public, searchable forum** at `/support`. This file is the
> authoritative spec for that revision. The old "Support tab + owner-only private tickets +
> auto-email on every reply" model is superseded. Where this file and older notes disagree, this
> file wins. Decisions captured below under **Locked decisions**.

---

## Locked decisions (2026-05-26)

1. **`/support` is its own page**, not an account tab. Remove the `/support` -> `/account?tab=support`
   redirect; remove the **Support** tab from `AccountShell`. The account area keeps Overview /
   Data & Privacy / (Admin).
2. **Public forum, signed-in-visible.** Any signed-in user can browse any module's forum and see
   everyone's **public** tickets (so the same issue is not re-filed). Logged-out users do not see
   the forum (auth-gated). Rationale: reduce duplicate tickets.
3. **Community replies.** Any signed-in user who can view a ticket may reply to it. Replies carry
   the author's identity (username), not just a role.
4. **Module-access gate on creation.** A user may only **open** a ticket for a module they have a
   granted `moduleAccess` row for. With **zero** granted modules, `/support` shows an explainer:
   they must be using a module before they can open a ticket for it. (Viewing is not gated;
   creating is.)
5. **Per-module stat cards on `/support`.** One card per module the user is registered with
   (granted access). Each card shows: **total tickets** (visible to the viewer), **tickets the
   user created or replied to**, **private tickets** (the viewer's own private ones; for
   admin/assigned-Support, all private in that module). Card links to `/support/<slug>`.
6. **Private tickets.** A creator may mark a ticket **private** at creation. Private tickets are
   visible only to the **owner**, **admin**, and **assigned Support for that module**. They never
   appear in the public list for anyone else, and are excluded from non-privileged stats/search.
7. **No automatic email, ever.** Creating a ticket emails nobody. A community reply emails nobody.
   This is deliberate anti-spam. (Auth login-code emails are unrelated and stay.)
8. **Manual staff notify (Save vs Save & Send).** When **Admin or assigned Support** reply, the
   reply UI offers two actions: **Save** (silent) and **Save & Send** (an email icon). Save & Send
   sends ONE stock email — "Support has replied to your support ticket" + a link to the ticket —
   to every **subscribed participant** on that thread. Community members' reply box has no send
   option; it only saves.
9. **Per-ticket subscription.** Each ticket thread has a **Subscribed / Unsubscribed** dropdown for
   the current user. Default **Subscribed**. Unsubscribed users are excluded from Save & Send sends.
   "Participants" = the owner + everyone who has replied.
10. **Ticket permalinks via a unique hash.** Route `/support/<slug>/ticket/<hash>`. The stock email
    links here; the hash is a stable public id (not the Convex `_id`).
11. **Status rename `completed` -> `closed`.** Statuses are `open | pending | closed`. **Any reply
    to a `closed` ticket reopens it to `open`** (community or staff). Admin AND assigned Support can
    set status.
12. **Purpose rename `lore_correction` -> `historical_inaccuracy`** (label "Historical Inaccuracy").
    The platform is about real history/language/culture, so "historical inaccuracy" (a real-world
    factual error) replaces "lore correction" (invented-world fix). Migrate existing rows + seeds.
13. **New "Support" role.** A third user type. Admin **designates** a user as Support, then
    **attaches** them to specific modules (two steps). Assigned Support, **for their modules only**,
    can: see private tickets, reply with Save / Save & Send, and set status. They do **not** get
    user-management or access-granting (Admin-only). UI lives in **Admin tab -> Users & Access**.
    Admin stays an env allowlist (`lib.ts`); Support is DB-stored.
14. **"Already searched" checkbox** on the new-ticket form: a required checkbox affirming the user
    searched first, with a link to the module search (`/support/<slug>`). Submit is disabled until
    it is checked.
15. **Search the forum.** A search box on `/support/<slug>` filters the tickets the viewer is
    allowed to see (subject + body), client-side, scoped to that module. Convex `searchIndex` is a
    later scale upgrade, not now.
16. **Pagination selector.** The forum list offers **10 / 25 / 50** per page, **default 10**. The
    choice is **remembered per-user in the DB** (`profiles.prefs.supportPageSize`).
17. **Hero art, per-surface (revised 2026-05-27, Francis).** The support area uses TWO heroes,
    not one shared image. The `SupportHero` component is parameterized (`image` + `imageAlt`
    props; canoes is the default).
    - **`/support` hub:** a **Pacific Northwest city park** community scene, two people shaking
      hands in the foreground, children playing behind, a couple picnicking on a blanket (civic
      gathering place / mutual aid). Asset `/images/support-hub-hero.webp`.
    - **`/support/<slug>` module forum AND the `/ticket/<hash>` permalink:** the original
      **two cedar canoes meeting at dawn on calm water**, asset `/images/support-hero.webp`. The
      canoes are now RESERVED for the per-module surfaces only (originally they were the `/support`
      hub hero; Francis reassigned them 2026-05-27 and asked for the new park hero on the hub).

    Both are dark-blue PNW palette, source in `assets/images/pages/` then staged to
    `public/images/` by `copy-assets` (site-images rule).
18. **GDPR erasure ANONYMIZES forum content in place, it does not delete it** (Francis, 2026-05-26).
    When a user erases their account (Data & Privacy), their support/forum threads STAY in the
    forum so the surrounding conversation still reads. The scrub: every ticket they OWN keeps its
    row but the `subject` is overwritten with `"Post from a deleted account"` and `ownerDeleted`
    is set; every message they AUTHORED (their own tickets AND replies on other people's threads)
    keeps its row but the `body` is overwritten with the GDPR removal notice and `authorDeleted`
    is set. Every surface that names the author shows a plain **`DELETED`** (no `@`, no
    `(support)` suffix, the username is gone): the public forum AND the **admin triage view**
    (`AdminTickets`, which previously fell back to the now-null owner email / `"unknown"`).
    Subject scrubbing and private-ticket handling are BOTH on (a private
    ticket the deleted owner created is anonymized in place too, staying visible to admin/Support
    only). Rows that carry no displayable content (the user's `ticketSubscriptions` and any
    `supportAssignments`, `accessRequests`) are deleted outright. Everything else (per-module state,
    moduleAccess, accessRequests, profile, auth identity) is still deleted, which frees the
    username + email, leaving no PII tombstone. `userId` on the anonymized rows is left as a
    dangling id (Convex ids are never reused, it resolves to nothing and is never surfaced for a
    deleted author). Implementation: `convex/account.ts` `deleteAccount`; flags in
    `supportTickets.ownerDeleted` / `ticketMessages.authorDeleted`; display in `convex/tickets.ts`
    (`listModuleTickets`, `getTicketByHash`) + `TicketThread` / `ModuleForum`, and in
    `AdminTickets` off the `listAllTickets` payload (no query change, the flags ride `...t` and the
    raw messages). The notice + subject strings are voice-gated via `/edit`. Two support-spec
    cases cover it: "GDPR erasure anonymizes the forum in place" (a member opens their own public
    ticket and replies on a third party's thread, erases their account, then the third party
    confirms both forum surfaces show `DELETED` + the notice, never the original words, while the
    threads survive) and "admin Tickets view shows DELETED for a GDPR-erased account" (the admin
    triage card + expanded thread show `DELETED`, not the old `"unknown"` email fallback). Cleanup
    of the anonymized husk a deleted account leaves behind uses the dev-only
    `admin.purgeTicketByHash` (the husk is unreachable by `purgeTestUser` once the email is freed).

19. **Forum reading is PUBLIC (2026-05-27, Francis).** Supersedes decision 2's
    "logged-out users do not see the forum." Anyone, signed in or not, may READ a
    module's forum and any non-private ticket: `/support` (hub),
    `/support/<slug>` (forum list + search), and `/support/<slug>/ticket/<hash>`
    (thread). Private tickets stay owner/admin/assigned-Support only. The three
    read queries (`listModuleTickets`, `getTicketByHash`, `forumModuleStats`) use
    nullable `getAuthUserId`, not `requireUserId`; a null caller sees public rows
    only, with every mine/following/staff/subscription signal false (subscription
    lookups are skipped for a null user). The components drop the
    `<Authenticated>`/`<Unauthenticated>` wall and render the forum for everyone;
    a guest sees a "log in to post" prompt where the new-ticket form / reply box
    would be (`forum-signin-to-post`, `thread-signin-to-reply`,
    `support-signin-hint`).
20. **Posting (open OR reply) requires login + module access (2026-05-27,
    Francis).** Tightens decision 3 ("any signed-in user who can view a ticket may
    reply"): replying is now "posting" and carries the same gate as opening a
    ticket. An ordinary member must be signed in AND hold a granted `moduleAccess`
    row ("active in the module"); admin and assigned Support are staff and may post
    without a grant. Enforced SERVER-SIDE in both `createTicket` and `postReply`
    (the non-staff branch requires `hasGrantedAccess` + `moduleForumEnabled`), not
    just in the UI. A signed-in member without access sees `forum-no-access` (can
    read, can't open) and `thread-no-access-reply` (can read, can't reply).
21. **Per-module "Activate Forum" switch (2026-05-27, Francis).** A NEW
    `moduleSettings.forumEnabled` flag, INDEPENDENT of `accessible`, in Admin ->
    Modules (`AdminModules`, pill `module-flag-<slug>-forumEnabled`). It alone
    gates whether a module's forum exists: when off, the forum (hub row, list, and
    every thread) is hidden from EVERYONE (members and guests alike, including an
    admin browsing the forum surface), and posting is refused server-side.
    `accessible` keeps meaning only grantability (the grant mutations still gate on
    `moduleAccessible`). Default false (operational gate, no content default);
    seeded per module via dev
    `admin.seedModuleSettings` + the convergent `bootstrap.ensureModuleBaseline`,
    which BACKFILLS `forumEnabled` when absent on a pre-existing row and never
    clobbers an admin's explicit toggle. Server gate: `modules.moduleForumEnabled`.
    The hub query `forumModuleStats` (renamed from `myModuleSupportStats`) now
    lists every forum-activated module to everyone, not the caller's granted
    modules.
22. **Captcha on every forum POST; never on the admin Tickets area (2026-05-27,
    Francis).** Every post under `/support/<slug>` (open a ticket in
    `NewTicketForm`; any reply in `TicketThread`, community AND staff) passes a
    Cloudflare Turnstile check via the existing `verifyTurnstileToken` server
    action BEFORE the Convex mutation, exactly as the login form does (widget not
    rendered + verify bypassed in development, so headless tests stay
    deterministic). The `/account` Admin Tickets area (`AdminTickets`) calls the
    SAME `postReply` mutation directly with NO widget and NO verify, so admin
    replies carry no captcha. The captcha is a UI-layer gate on the forum surfaces
    only; `postReply` is shared and stays captcha-free at the mutation layer, which
    is exactly what keeps the admin area exempt.

---

## Routes

- **`/support`** (auth-gated hub). Hero (canonical pattern, `support-hero.webp`). Per-module stat
  cards for granted modules; zero-modules explainer otherwise. Each card -> `/support/<slug>`.
- **`/support/[slug]`** (forum). Search box + paginated ticket list (10/25/50) + **new-ticket form**
  (only when the user has access to `slug`; else the access explainer). Form fields: subject,
  purpose, details, **private** checkbox, **already-searched** required checkbox (links to the
  search above). No module dropdown — the module is the route.
- **`/support/[slug]/ticket/[hash]`** (permalink). Full thread with author usernames, the reply box
  (community = Save only; staff = Save / Save & Send), the Subscribed/Unsubscribed dropdown, and —
  for staff — the status control. Reopen-on-reply enforced server-side.

## Visibility + posting rules (enforce server-side in every query/mutation)

- **Reading is public (decision 19).** A ticket is visible to the caller iff: it is **not
  private**, OR caller is the **owner**, OR caller is **admin**, OR caller is **assigned Support
  for the ticket's module**. The caller may be **null** (logged out): a null caller sees public
  tickets only. Read queries use `getAuthUserId`, never `requireUserId`.
- **Posting requires login + module access (decision 20).** Both **creating** and **replying**
  require: forum activated (`moduleForumEnabled`) AND a granted `moduleAccess` row, UNLESS the
  caller is staff (`canStaffModule` = admin OR assigned Support), who may post without a grant and
  regardless of `forumEnabled`. Status-set + Save&Send require staff. Subscription toggle requires
  visibility + a signed-in caller.
- **Forum existence (decision 21).** When `forumEnabled` is off, the forum (hub row, list, threads)
  is hidden from everyone and posting is refused server-side.

---

## Schema deltas (convex/schema.ts) — see backend.md for the full table

- `supportTickets`: `status` enum `completed` -> **`closed`**; `purpose` enum `lore_correction` ->
  **`historical_inaccuracy`**; add **`isPrivate: v.boolean()`**; add **`hash: v.string()`** with a
  **`by_hash`** index; add **`by_module`** index (`moduleSlug`) for forum listing. `moduleSlug` is
  effectively required now (set from the route) but stays `v.optional` so legacy rows validate.
- `ticketMessages`: add **`userId: v.id("users")`** (author identity, for username display + the
  "replied to" stat; add a `by_user` index); extend `authorRole` to **`user | support | admin`**.
- NEW **`ticketSubscriptions`**: `ticketId`, `userId`, `subscribed: v.boolean()`; indexes
  `by_ticket`, `by_ticket_user`, `by_user`. No row = subscribed (default); a row with
  `subscribed:false` = opted out.
- NEW **`supportAssignments`**: `userId`, `moduleSlug`, `assignedBy`, `assignedAt`; indexes
  `by_user`, `by_module`, `by_user_module`.
- `profiles`: add **`role: v.optional(v.union(v.literal("support")))`** (admin stays env-based);
  use existing `prefs` for **`supportPageSize`** (10 | 25 | 50).

## Functions (convex/tickets.ts + a roles module; see backend.md)

- `createTicket(moduleSlug, purpose, subject, body, isPrivate)` — posting gate (decision 20):
  non-staff need `hasGrantedAccess` + `moduleForumEnabled`; staff bypass. Generate `hash`; insert
  ticket + first message (with `userId`, role derived); subscribe the author.
- `listModuleTickets(moduleSlug)` — PUBLIC (nullable caller); visibility-filtered list with message
  counts, last-reply time, participant/own-reply flags, and per-ticket private flag. Backs the
  forum list, search, and stats.
- `getTicketByHash(moduleSlug, hash)` — PUBLIC (nullable caller); single ticket + full thread
  (resolve author usernames); enforce visibility; include the caller's subscription state (default
  for a guest) and whether caller is staff here.
- `postReply(ticketId, body, sendEmail?)` — caller must have visibility; **posting gate (decision
  20): non-staff need `hasGrantedAccess` + `moduleForumEnabled`; staff bypass.** Role derived
  (admin/support/user); `sendEmail` is ignored unless caller is staff for the module; insert
  message; subscribe the author if no row; **reopen if `closed`**; if `sendEmail` && staff ->
  schedule the stock-notification action to subscribed participants. No email otherwise.
- `setTicketStatus(ticketId, status)` — admin OR assigned Support for the module.
- `setSubscription(ticketId, subscribed)` — caller toggles own subscription (visibility + signed-in
  required).
- `forumModuleStats()` (PUBLIC, nullable caller; renamed from `myModuleSupportStats`) — per
  FORUM-ACTIVATED module (`forumEnabled`, not the caller's grants): `{ total, open,
  mineCreatedOrReplied, private, lastPost }` scoped to the viewer's visibility (zero "mine" for a
  guest). Backs the public hub rows.
- `setSupportPageSize(size)` — persists `profiles.prefs.supportPageSize` (validate 10|25|50).
- Roles (admin-only, in `access.ts` or a new `roles.ts`): `setSupportRole(userId, isSupport)`,
  `assignSupportModule(userId, moduleSlug)`, `unassignSupportModule(userId, moduleSlug)`. Fold
  Support role + assignments into `listUsers` so Users & Access can render them.
- Helpers in `lib.ts`: `isSupportFor(ctx, userId, moduleSlug)`, `canStaffModule(ctx, moduleSlug)`
  ( = admin OR assigned Support ), `requireStaffForModule`.
- `email.ts`: drop the auto-`sendTicketReply` from the reply path; add `sendTicketNotification`
  (stock subject/body + permalink) used only by `postReply`'s Save & Send.

## DB wipe + reseed (no migration — decided 2026-05-26)

Francis chose to **wipe the development database and reseed**, rather than migrate prior rows.
There are no production tickets to preserve, and a clean DB removes any stale `lore_correction` /
`completed` rows. So:
- The schema goes **straight to the final enum values** (`closed`, `historical_inaccuracy`) — no
  widen/migrate/narrow sequence.
- Wipe: `/odyssey-apps serve stop`, delete the bind-mounted `./data/convex`, bring the stack back
  up, `npx convex dev` to push the fresh schema + functions.
- Reseed (the dev-guarded internal seeders in `admin.ts`): `seedAdmin`, `seedSampleUsers` (creates
  the sample roster + grants + experience + tickets). **Update `admin.ts` `SAMPLE_TICKETS`** to use
  the new enum values and add **private** + **multi-replier** + a **Support-assigned** sample so the
  forum, stats, private-visibility, and Support-role paths all have seed coverage. **No migration
  mutation is written.**

---

## admin (admin-only) — unchanged surface + Support-role management

Gated to the admin role (`lib.ts`). The admin still:
- **Triages tickets** (now also reachable through the public forum thread with staff controls):
  reply (Save / Save & Send), set status, see private tickets everywhere.
- **Users & Access** (`listUsers`): per user, see module access (grant/revoke), experience
  summary, open-ticket count + quick links. **NEW:** toggle a user's **Support** role and, when
  Support, **attach/detach modules** (`setSupportRole` / `assignSupportModule` /
  `unassignSupportModule`). Components: `src/components/admin/AdminUsers.tsx`. The grant + attach
  module lists are filtered to **accessible** modules (see Modules below), so a placeholder module
  is never offered (an already-granted/assigned module stays listed so it can be revoked/detached).
- **Admin role (DB-grantable) — NEW 2026-05-28 (Francis).** Admin used to be ONLY the env
  allowlist (`ADMIN_USER` / `ADMIN_EMAILS`); now it is also a DB role (`profiles.role === "admin"`)
  so admins can be made/removed from the UI. `isAdmin()` = env allowlist OR the DB role. **Flat
  model:** any admin (env or DB) can grant/remove admin AND support; support staff get NO
  user-management surface (Francis explicitly scoped this down: support only handle tickets).
  Function: `roles.setAdminRole(userId, isAdmin)`. **Guardrails:** env-admins are irrevocable
  (their status is not a DB row; the UI shows an **Owner (environment)** badge with no toggle, and
  the mutation refuses them); you cannot change your own admin status (no self-demote); the **last
  admin** can never be removed (env-admin always present). `role` is single-valued, so "admin"
  supersedes "support" (a promoted support user becomes "admin"); `setSupportRole` /
  `assignSupportModule` refuse to touch an "admin" row so they cannot bypass the admin guardrails.
  `listUsers` returns `isAdmin` (either path) + `isEnvAdmin` (env-only) to drive the control.

### admin -> Modules (runtime module-flag editor) — NEW 2026-05-26

A fourth admin section (`AdminModules.tsx`, registered in `AdminPanel.tsx` alongside Usage /
Tickets / Users & Access) lets the admin edit a module's mutable flags at runtime instead of
hand-editing MDX frontmatter. Flags live in Convex `moduleSettings` and OVERRIDE the content
defaults; the whole site reads the merged value (`src/lib/modules.ts` `effectiveModuleFlags`;
server pages via `src/lib/modules.server.ts`). Five flags, "everything the admin needs":
- **Listed** (`published`) — module card on `/modules`.
- **Status** (`live | coming-soon`) — card/intro badge + the Play-now vs roadmap CTA.
- **Accessible** — grantable to users. Gates the admin grant/attach lists and is enforced
  server-side in `grantAccess`/`grantAccessByEmail`. **Independent of the forum since 2026-05-27**
  (it no longer means "has a support forum"; that is `forumEnabled`).
- **App-gate** (`appEnabled`) — the module app runs at `/modules/<slug>/app` (else the
  PlayGate shows a "not playable yet" state), independent of card status.
- **Activate Forum** (`forumEnabled`) — NEW 2026-05-27. The module's support forum exists: when on,
  anyone (signed in or not) can READ `/support/<slug>` and active users can POST; when off, the
  forum (hub row, list, threads) is hidden from everyone (`forum-not-open`) and posting is refused.
  Gates the support hub list, the `/support/<slug>` page, and is enforced server-side in
  `createTicket` + `postReply` via `moduleForumEnabled`. Independent of `accessible`. **This is the
  flag that opens/closes a module's forum.**

`accessible`/`playEnabled`/`forumEnabled` have no content default and so default **false** (a
module is not grantable/runnable/forum-open until an admin enables it); `published`/`status` fall
back to content. The dev reseed (`seedModuleSettings`) and the convergent
`bootstrap.ensureModuleBaseline` sets each module's baseline (both modules start NOT accessible and NOT app-enabled) and
the-hanseatic-league none (the baseline BACKFILLS `forumEnabled` if absent on a pre-existing row).
Module-agnostic: the editor lists whatever modules exist in content. Backend: `convex/modules.ts`
(`moduleFlags`, `setModuleFlags`, `moduleAccessible`, `modulePlayEnabled`, `moduleForumEnabled`);
schema in backend.md.

## Frontend inventory

- Delete the `/support` redirect page; build `src/app/(marketing)/support/page.tsx` (hub),
  `src/app/(marketing)/support/[slug]/page.tsx` (forum), and
  `src/app/(marketing)/support/[slug]/ticket/[hash]/page.tsx` (thread).
- New `src/components/support/`: `SupportHub` (stat cards), `ForumList` (search + pagination
  selector + list), `NewTicketForm` (private + already-searched checkboxes, no module dropdown),
  `TicketThread` (author names, subscribe dropdown, staff Save/Save&Send + status).
- Remove the Support tab from `src/components/account/AccountShell.tsx`; retire
  `src/components/account/SupportPanel.tsx` (or strip to nothing). Fix any OverviewPanel link that
  pointed at the support tab; point it at `/support`.
- `src/lib/support.ts`: `PURPOSES` (historical_inaccuracy), `STATUSES` (closed), labels, badges,
  page-size options.
- Add a **`/support`** link to the site nav/header.
- Hero generated via `/odyssey-apps image` (dark-blue PNW, canoes-at-dawn), then `/image-eval`.

## Tests (route through `/odyssey-apps test`, headless Playwright, mandatory exit-test)

Rewrite `tests/support/support.spec.ts` (it drives the old `/account?tab=support` flow and
`admin-set-completed`/`completed` — both gone). Cover: forum visibility (signed-in user sees
another user's public ticket); community reply; private ticket hidden from a non-staff third party
but visible to its owner; assigned Support sees private + replies + sets status, scoped to their
module only (not other modules); **no email on create / community reply**; **Save & Send** notifies
subscribed participants and **not** an unsubscribed one; **reply reopens a closed ticket**; stat
cards; search filter; create-gate (no access -> explainer, no form); already-searched checkbox
gates submit; pagination 10/25/50 persists across reloads (DB-backed); hero renders. Verify the
migration left no `completed`/`lore_correction` values. **Drive it visually too** (project rule:
visual drive after UI/overlay changes). Clean up test data after the run.
