# Procedure: image — the graphic system

The site's imagery is a **drawn graphic system**, not photography and not watercolour. Ratified
2026-07-22, superseding the kickoff directive's "real-life images" — see SKILL.md § Directive
amendment for the three reasons (AI-generation risk on a trust pitch, vertical-neutrality at site
level, and a catalog that will outgrow real estate).

Grounding: [../palette.md](../palette.md) and `modules.json` `$site_thesis.catalog_scope`.

---

## The visual language

It comes from the same surveying vocabulary that produced the name **Meridian** — the language of
orientation, reference, and things connected along a single route:

- **The line.** One continuous path indexing many points. This is the platform metaphor drawn
  rather than described: Meridian is the line, each module a point on it. It is the site's single
  strongest image and should recur as a structural motif, not a one-off illustration.
- **Points and marks.** Benchmarks, station markers, plotted positions. Each module earns its own
  mark — a small distinct glyph in the same family, so the catalog reads as a set even as it grows.
- **Bearings and vectors.** Direction, heading, angle. Useful for anything about progress,
  routing, or "what happens next."
- **Contours, grids, and plats.** Fields of fine parallel or concentric line-work. This is the
  texture register — section backgrounds, card fills, hero underlays.
- **Instrument geometry.** Reticles, scales, tick marks, alignment marks. Precision as an
  aesthetic, which is exactly the claim the product makes.

**Palette** (palette.md): white ground, navy fields, **gold reserved for hairlines, ticks, and the
accent mark**. Gold is what makes it read as engraved rather than diagrammatic — and it is never
body text on white.

### What it is NOT

- **Not watercolour.** That is odyssey-alive's and odyssey-skul's language. This site is a quiet
  sibling, not a copy.
- **Not photorealistic.** No generated faces, hands, interiors, or properties anywhere.
- **Not corporate-Memphis blob people.** Flat pastel figures with oversized limbs are the most
  dated look in B2B software.
- **Not a technical diagram.** It borrows surveying's *vocabulary*, not its literalism. Nothing
  should look like an engineering drawing or need a legend.
- **Not decorative-abstract filler.** Every piece means something — the line connects, the mark
  locates, the contour describes a field. If a piece could be swapped for any other without loss,
  it is filler; cut it.

---

## SVG first, generation second

**Most of this system should be authored as SVG in the repo, not generated as raster.** For
line-work that is not a stylistic preference, it is a quality and maintenance decision:

| | SVG (preferred) | Generated raster |
|---|---|---|
| Crispness | Perfect at any size and DPI | Softens; hairlines fur at small sizes |
| Palette | Recolours via CSS variables — one token change restyles everything | Baked in; a palette tweak means regenerating every asset |
| Consistency | Identical stroke weight across every asset by construction | **Drifts between generations** — the core failure mode of a generated system |
| Weight | A few KB | Hundreds of KB |
| Motion | Animatable (draw-on, trace along the line) | Static |

So: **lines, marks, grids, reticles, contours, and module glyphs are SVG.** Reach for `/image`
generation only for richer textural pieces where hand-authoring is impractical — a weathered chart
field, a complex organic contour map, an atmospheric hero underlay — and even then treat the output
as a texture layer *beneath* SVG structure rather than as the whole image.

**Consequence for the `/image` retheme** (still a blocking prerequisite, port-inventory.md § C.2):
it is rethemed to *this* system, not to photography. Its job shrinks — textures and fields, not
scenes.

---

## image \<target\>

1. **Decide the altitude.**
   - **Site level** (home, section bands, OG): vertical-neutral. The line, the marks, the fields.
     No real-estate references of any kind — the catalog is not real-estate-specific
     (`$site_thesis.catalog_scope`).
   - **Module level** (`/modules/<slug>`): the same system, expressed with that module's own mark
     and a composition suited to its job. The vertical may inform the *composition* — SignMe's mark
     can suggest a signature line, Meridian's a route through points — but it stays in the drawn
     language. No photographs of houses.

2. **Determine the output path.**
   - Structural SVG: `src/components/graphics/` if it is a component, `assets/graphics/` if it is a
     static asset staged into `public/` by `copy-assets`.
   - Generated textures: `assets/images/pages/` → served at `/images/<name>`. Never hand-populate
     `public/static/` (Velite's gitignored hashed output — a file placed there is untracked and
     will not deploy).
   - Module assets: resolve from `modules.json` → `assets.images`.

3. **Author or generate**, per § SVG first. Hold stroke weights, tick spacing, and corner treatment
   to a shared scale — a system is recognisable because its *measurements* repeat, not because its
   subjects do.

4. **Apply the meaning test.** State in one sentence what the piece says. If the sentence is "it
   looks nice here," it is filler.

5. **Run `/image-eval`** on any generated raster for AI tells. Deterministic post-edits first; if a
   generative re-edit is needed, use a single "Replace X with Y" edit. Never a second generative
   cleanup pass to fix the first pass's side effects — surface it instead.

6. **Optimise and place.** Real `alt` text describing what the graphic communicates, not
   "decorative line illustration." A purely decorative SVG gets `aria-hidden`.

---

## Brand marks

The logo and favicon are **flat graphic** in this same language — navy with a gold accent, readable
at 16px, transparent where they must sit on the navy footer. They should look drawn from the same
instrument as everything else. Reviewed on the rendered page at both viewports before shipping
(palette.md § Build-time graphics review).

---

## Motion (a real opportunity, used sparingly)

A line system animates in a way photography cannot: a route drawing itself, a mark settling onto
its position, a contour field parallaxing behind a section. Framer Motion is already in the stack.
Two rules: respect `prefers-reduced-motion`, and never delay content — the page must be legible
with animation removed. Restraint is the whole aesthetic; a system this precise looks cheap the
moment it bounces.

---

## The target this stands in for

For a productivity product the strongest imagery is eventually **the product itself** — a real
screen showing real state. The graphic system carries the site until then, and should keep carrying
the *platform* story afterwards, but module pages should shift toward product imagery once there is
a product. Do not build a large decorative library that a screenshot will retire.

---

## Exit verification (mandatory)

After placing any graphic, author/run the headless-Playwright exit-test that it renders at BOTH
viewports, confirm it passes, and clean up test data and files (test-suite.md; SKILL.md Test-Suite
Verification gate). The ported `tests/art` suite asserts watercolour-era invariants and is
**re-authored** for this system — but keep its aspect-ratio collapse guard, which catches the
Turbopack arbitrary-value regression that renders a container at height 0.
