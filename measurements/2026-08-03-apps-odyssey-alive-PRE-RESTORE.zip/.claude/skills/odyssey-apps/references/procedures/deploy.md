# Procedure: deploy

Author and refresh the jstack deploy artifacts. The site eventually lives at
`jstack/sites/apps.odysseyalive.com`, cloned from this GitHub repo. Grounding: read
[../research-log.md](../research-log.md) §4. jstack contract reference:
`/home/francis/lab/jstack` (`site-templates/`, `scripts/core/register_sites_nginx.sh`).

jstack's existing `node-mdx-tailwind` template is a generic Express app (`npm start`), NOT a
Next.js standalone build, and its nginx registration emits a static `root` block. So this site
provides its OWN Next.js-standalone Dockerfile + a proxy nginx template.

## Artifacts to author in the repo

1. **`Dockerfile`** - multi-stage, from the canonical `vercel/next.js/examples/with-docker`
   pattern (deps -> builder -> runner). Copy `.next/standalone`, then `.next/static` into
   `./.next/static` and `public` into `./public` (the standalone server does not copy them).
   Run as `node` user; `ENV PORT=3000`, `ENV HOSTNAME="0.0.0.0"`; `CMD ["node","server.js"]`.
   In the builder stage, copy the module serving assets into `public/modules/<slug>/`
   resolved from `modules.json` (images and static assets only — no compiled binaries).
2. **`docker-compose.yml`** - three services on one VPS:
   - `next-app` (build: ., publishes the Next port; env from `.env`)
   - `convex-backend` (`ghcr.io/get-convex/convex-backend`, pinned tag; **bind-mount**
     `./data/convex:/convex/data` so the DB files live on the host under the site dir, outside
     the image, per backend.md § Database persistence; `CONVEX_CLOUD_ORIGIN` /
     `CONVEX_SITE_ORIGIN` set to the public HTTPS URLs, not localhost)
   - `convex-dashboard` (pinned tag; firewalled / proxied behind auth)
3. **`site.config`** - `DOMAIN=apps.odysseyalive.com`, a unique `PORT`, `MODE=production`, and
   `NGINX_TEMPLATE=` pointing at a **proxy** template (see #4).
4. **nginx proxy (jstack ALREADY supports this; no jstack change for the main site).** Confirmed
   by reading `jstack/scripts/core/setup_service_subdomains_ssl.sh`: `bash jstack.sh --install-site`
   reads the site's `.env` (`DOMAIN`, `PORT`, optional `CONTAINER`) and generates a reverse-proxy
   vhost (`generate_site_nginx_config` then `upgrade_site_to_https`) with `proxy_pass`,
   `proxy_http_version 1.1`, `Upgrade`/`Connection "upgrade"` (WebSocket), and `X-Forwarded-*`,
   plus the ACME location and HTTP->HTTPS upgrade. So the Next.js site needs NO jstack edit.
   (The static `register_sites_nginx.sh` is a separate legacy path that `--install-site` does not
   use; ignore it.) Provide `sites/apps.odysseyalive.com/.env` with `DOMAIN=apps.odysseyalive.com`
   and `PORT`. Simplest: publish the Next port to the host (`127.0.0.1:<PORT>:3000` in compose),
   omit `CONTAINER` (nginx proxies to `127.0.0.1:PORT`). Alternative: set `CONTAINER`=the next-app
   container and join jstack's docker network (nginx proxies to the container name).
   **Convex public origin:** the browser-facing `NEXT_PUBLIC_CONVEX_URL` needs its own HTTPS+WS
   origin. Register Convex as a SECOND jstack domain (`appshook.odysseyalive.com`) with its own
   `.env` (`PORT=3210`, `CONTAINER`=the convex-backend container) so jstack proxies it the same
   way. The one thing to verify on the box: `--install-site` runs `docker-compose up -d` only if
   the site dir has a compose, then does nginx+SSL; confirm it registers the vhost for a domain
   whose container is already up from the main compose, and if not, give that thin second-site dir
   a minimal/stub compose. That is the only possible jstack-side addition.
   Post-`up` steps jstack does NOT perform (run after `--install-site`): generate the Convex admin
   key (`docker compose exec convex-backend ./generate_admin_key.sh`), `npx convex deploy` to push
   schema/functions, provision secrets in the VPS `.env`, ensure `./data/convex` persists.
5. **`.env.example`** - all keys from templates-inventory.md (Mailchimp/Turnstile/SMTP reused,
   audience `b7792f6c03`) + the `CONVEX_*` keys + `NEXT_PUBLIC_SITE_ENV` (`live` on the VPS,
   `development` on the dev mirror). Secrets live in the VPS `.env`, never committed.

## No large binaries (the LFS section is intentionally gone)

odyssey-skul shipped a ~52MB compiled game via Git LFS, with a Dockerfile guard against pointer
stubs and a GitHub LFS quota to watch. **None of that applies here.** This repo's modules are
first-party route trees; there is no compiled artifact to deliver. Do not reintroduce Git LFS,
`.gitattributes` filters, or the builder-stage binary guard — if a future module needs a large
asset, that is a new decision to make deliberately, not a pattern to inherit.

## Deploy flow (documented, not auto-run)

1. Push this repo to its **private** GitHub remote and clone into
   `jstack/sites/apps.odysseyalive.com/`. A plain clone is sufficient — no git-lfs, no smudge
   step, no large-binary guard (§ No large binaries).
2. On the VPS: bring up Convex, generate the admin key, set `.env`, `npx convex deploy` to push
   schema/functions into the running backend.
3. `jstack` install of the site wires nginx + Let's Encrypt for `apps.odysseyalive.com`.

## Backups (deploy is not done without them)

Full spec: [../backups.md](../backups.md). The three things `deploy` must establish:

1. **A scheduled Convex logical export** written into the site directory, so jstack's existing
   site tar, cron, remote copy, and GPG encryption carry it for free. **Never rely on jstack's
   file-level tar as the database backup** — it copies a live database mid-write and fails
   silently at restore time, which is the worst possible moment to discover it.
   Order matters in cron: export first, then tar.
2. **Offsite and encrypted**, with the passphrase stored somewhere that is neither the VPS nor this
   repo. A backup you cannot decrypt is not a backup.
3. **A restore drill before launch** (backups.md § F), verifying substance — a known user, their
   grants, a ticket, and usage rows for a known date — not merely that the archive extracts.

## Observability (also not optional before a public launch)

Full spec: [../observability.md](../observability.md). Three things `deploy` must establish:

1. **In-house error capture** — the Convex `errorLog` plus the invariant checks. **No third-party
   service and no new container** (self-hosting directive; observability.md § H). The one thing
   that must live outside the box is a **cheap external heartbeat** against `/api/health`, because
   nothing inside a dead machine can report that it died.
2. **Source maps retained and releases tagged** in the Docker build (server-side, never served
   publicly), or every client stack trace arrives minified and unreadable — which looks like
   information and is not.
3. **The invariant checks** (observability.md § C). This app's worst failures are SILENT — an
   unsent login code produces no error and no complaint, just a user who never returns.

## Empirical checks before declaring done

- `docker compose config` validates.
- **Real mail reaches real inboxes.** Send a login code to Gmail, Outlook, and one other provider;
  confirm each arrives in the INBOX (not spam) and that SPF, DKIM, and DMARC all pass in the
  receiving provider's "show original". This is the only way to learn what a stranger experiences.
- **`SITE_ENV` is NOT `development` on the live backend.** If it is, no real email sends,
  one-time-use is disabled, and login codes are exposed — silently and totally (email.md § G).
- A deliberately triggered error lands in `errorLog` with its correlation id, a readable
  (de-minified) stack, and the correct release tag. An untested reporter fails exactly like an
  untested backup.
- `/api/health` responds, and the external heartbeat has been observed to fire on a simulated
  outage — not merely configured.
- A backup has been taken by the AUTOMATED path and restored into a scratch environment, with the
  wall-clock recovery time recorded (backups.md § F). Until that has happened once, the backup
  system is untested and should not be described as working.
- The nginx proxy template resolves the domain to the Next port and forwards WS.
- `DO_NOT_REQUIRE_SSL` + `CONVEX_SITE_ORIGIN` "/http" routing behind nginx works on a real run
  (flagged in research-log.md §2 as needing a live test).

**Exit verification (mandatory):** after refreshing deploy artifacts, author/run the
headless-Playwright exit-test against the dev-apps mirror (the proxy resolves, the site loads,
Convex connects over the proxy), confirm it passes, and clean up test data and files after the
run (test-suite.md; SKILL.md Test-Suite Verification gate). No shortcuts.
