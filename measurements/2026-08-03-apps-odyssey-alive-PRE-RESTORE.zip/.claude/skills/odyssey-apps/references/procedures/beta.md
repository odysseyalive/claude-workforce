# Procedure: beta

Wire and maintain the beta-access request flow. Full specification — schema, functions, UI
states, emails, admin queue, abuse controls, exit tests — lives in
[../beta-access.md](../beta-access.md). **Read it before acting; this file is the runbook, that
file is the contract.**

Grounding order: `../beta-access.md` → `../research-log.md` (Convex + auth recipes) →
`../modules.json` (which modules carry `access.beta_request`).

## beta wire

The build-out, in dependency order. Each step ends with its Playwright exit-test green before
the next begins (SKILL.md Test-Suite Verification gate).

1. **Schema.** Extend `accessRequests` in `convex/schema.ts` per beta-access.md § Schema, then
   `pnpm db:deploy`. The port ships the table already declared but unused — extend it, do not
   redeclare it.
2. **Server functions.** `requestAccess`, `myAccessRequests`, `withdrawRequest`,
   `pendingAccessRequests`, `decideAccessRequest` in `convex/access.ts`. Turnstile on the
   request; module-flag re-check server-side; approval calls the existing `grantAccess` inside
   the same mutation.
3. **Erasure.** Wire `accessRequests` deletion into the ported account-erasure path in
   `convex/account.ts` in the SAME step as the schema, not later. A table added without touching
   erasure is a GDPR bug, and it will not be obvious months from now.
4. **Emails.** Three templates in `convex/email.ts` (admin-on-request, requester-on-approval,
   requester-on-denial), authored via `/my-voice`. Never emit `denyReason`.
5. **Public UI.** The Request-beta block on `/modules/<slug>`, all five states, built with
   `/frontend-design`. Plus the "Beta" chip on the `/modules` listing card.
6. **Admin queue.** The Beta requests panel in `/admin`, extending the ported desk's existing
   patterns — Francis's directive is that the admin interface is fine as it is, so add a panel,
   do not restyle the desk.
7. **Tests.** The seven cases in beta-access.md § Exit tests, in `tests/beta/`, at both
   viewports, with cleanup.
8. **Verify.** `/odyssey-apps verify`. Only a green full run may be called verified.

## beta status

Read-only report, safe to run any time:

- Pending / approved / denied / withdrawn counts, per module.
- Requests older than 7 days still `pending` (the queue is being ignored).
- Users with `moduleAccess.granted` but no `approved` row (granted directly by the admin — this
  is legitimate, not an error; report it as context, not a defect).
- Users with an `approved` row but no live grant (access was revoked after approval — also
  legitimate; flag only so the admin is not surprised).
- Modules where `betaEnabled` is true but `accessible` is false (the button will not render — a
  real misconfiguration worth reporting).

State the active environment first (environments.md); these counts differ between dev and live
and a dev number reported as live is worse than no number.

## Public launch — mostly inherited, one genuinely new surface (2026-07-22)

The site launches **publicly with open signup**. This is **not new territory**: open self-service
registration is already built, shipped, and running in production on skul.odysseyalive.com, and
this project mimics that technology exactly. Do not re-derive it, re-harden it, or treat it as
risk. Specifically, all of this arrives PROVEN in the port:

- Open registration with unique username + email, passwordless 6-letter codes.
- Turnstile on every public form.
- `convex/lockout.ts` — a lockout table with `isLockedOutByEmail` / `isLockedOutByUserId` /
  `setLockout`, wired into `auth.ts`, `users.ts`, `loginCode.ts`, and `admin.ts`.
- `MAX_ATTEMPTS` throttling in `authCodes.ts` — a code locks after repeated failures.
- Enumeration resistance (a taken email is never disclosed).
- The SMTP send path, exercised daily by a live site.

**What IS new: `requestAccess`.** It is a brand-new public endpoint, and none of the machinery
above covers it — `lockout.ts` guards *authentication*, not arbitrary public mutations. So the
one real task is extending the EXISTING lockout pattern to the request endpoint. Reuse it; do not
invent a second rate-limiting mechanism alongside it.

**Worth a one-time check, not a project:** confirm SPF/DKIM cover mail sent from this site's
domain the way they already do for the source site. Same infrastructure, different sender
identity — a five-minute verification, and a login code in a spam folder is an account that never
opens.

**Copy accuracy is the real day-one difference.** Strangers arriving with no context read every
claim literally. That is a `/copy-truth` concern on the beta pages, not an infrastructure one.

## Decisions to confirm with Francis, not to assume

Surface these rather than silently choosing:

- The re-request rate limit after a denial (proposed: 1 per user per module per 30 days).
- Whether the requester gets a confirmation email at request time (proposed: no — the on-page
  pending state is the receipt).
- Whether a denial is ever visible to the user as anything beyond the neutral state
  (proposed: no).

## Hard invariants

- **A request never grants.** Nothing in this flow may write `moduleAccess` except
  `decideAccessRequest` on an explicit admin approval.
- **`denyReason` is internal.** It must not appear in any served HTML, API response to a
  non-admin, or email.
- **Turnstile on the public mutation**, per the inherited directive covering every public form.
- **Playwright only** for verification. Never `claude-in-chrome`.
