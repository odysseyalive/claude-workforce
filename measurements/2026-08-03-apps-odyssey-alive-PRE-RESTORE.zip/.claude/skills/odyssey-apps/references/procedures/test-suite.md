# Procedure: test (the curated headless-Playwright test-suite)

The verification spine of this skill. Modeled on nsayka-wawa's `/test-suite`: tests live in
`tests/`, are authored once via discovery, and are reused as **exit-tests** by every other mode.
Every creation and debugging step double-checks itself here before anything is presented.

## No shortcuts (non-negotiable)

- Verification is **headless Playwright that actually drives the running site**: it navigates,
  takes a screenshot for visual review, operates the real flow (clicks, fills, submits), and
  asserts the result. Headless, but it genuinely renders and exercises the page.
- **Never** assert imagined behavior, hand-wave "this should work", or present work without a
  real browser run. Tests assert what you imagine; a visual Playwright drive catches what you
  missed. Both are required.
- **Reproduce the REAL user flow, not a convenient proxy.** A test must exercise the path the
  user actually takes (navigate between pages, full remount on a fresh load, real form submits),
  not a shortcut that only happens to touch the same component (e.g. an in-page "back" button
  standing in for "leave the page and come back"). A proxy that passes while the real path fails
  is worse than no test. This rule exists because a reuse-code test once used the in-component
  "back" button instead of a navigate-away-and-return, and missed the actual bug (2026-05-27).
- **Never** use claude-in-chrome (SKILL.md Playwright-Only gate). Playwright only.
- If a test cannot be made to pass, the work is not done. Report the failure with the run
  output and the screenshot; do not present it as finished.

<!-- ENFORCEMENT ANNOTATION — Model Gate for Testing (added 2026-05-27) -->
<!-- Source: /model-switch SKILL.md — testing is always opus-4-8. -->
CHECKPOINT — Test Model Gate:
1. Before running ANY Playwright test (discover, run, exit-test), check the active model.
2. IF the active model is NOT claude-opus-4-8 → STOP. Output:
   "Testing requires the code model. Switch to: `/model opus-4-8` — then re-run."
   Do not execute any test until the user confirms the switch.
3. IF already on claude-opus-4-8 → skip silently.
4. This gate fires even when tests follow immediately after creative work on opus-4-6. The /model-switch post-gate ("creative work complete, switch back") is a reminder; this gate is the enforcer.
<!-- END ENFORCEMENT ANNOTATION -->

## Always test mobile (non-negotiable)

The site must work on phones, so the suite **always verifies the mobile viewport too**, not
just desktop. The mechanism is built into `playwright.config.ts`: there are **two projects**,
`desktop` ("Desktop Chrome") and `mobile` (Chromium "Pixel 5", 393x851, touch, mobile UA), both
defined from the single source of truth in `tests/_helpers/viewports.ts`. Because the projects
carry the viewport, **every spec runs at both widths automatically** and new tests inherit
mobile coverage with zero per-test code. A full run shows each test twice, tagged `[desktop]`
and `[mobile]`.

Rules for authoring and running:
- **Do NOT hardcode a viewport** in a spec (no `setViewportSize` for the desktop/mobile split).
  Let the project supply it so the test runs at both. Use `isMobile(page)` from the helper only
  when an assertion is genuinely viewport-conditional (e.g. the header nav is `hidden md:flex`
  on desktop and behind a hamburger on mobile).
- **Reaching header nav on mobile:** call `openMobileNav(page)` (helper) before clicking header
  links/menus; it clicks the "Toggle menu" hamburger on mobile and is a no-op on desktop.
- **Layout/visual specs must hold at both widths.** The canonical example is the `tests/art`
  collapse guard, which asserts painted height > 0 for background images at whatever viewport
  the project supplies (this is the regression from INC-010, where aspect-ratio'd containers
  collapsed; it now fails on either project if it recurs).
- **`test run` runs both projects.** Do not pass `--project desktop` to skip mobile except for a
  deliberate, stated quick check; the default and the exit-test gate run both.
- **Prefer the prod build for full runs.** The `webServer` boots `pnpm start`; a full
  parallel run against a Turbopack **dev** server can flake on first-hit route compilation
  (e.g. the login form submitting before hydration). Run the whole suite against the built site.

## Sub-actions

- `test discover [--surface <name>] [--complaint "<what to prove>"]` - author a NEW test for a
  surface not yet covered. Drive the site, capture a screenshot, operate the flow, assert.
  Persist it under `tests/<surface>/` with a tag for the owning mode/surface so debug routes
  can re-run it.
  - **One suite, one home.** Unlike the source project — a monorepo whose game had its own
    separate suite — this repo has exactly one test home: the repo-root `tests/`, verified at
    :3050. Module apps are first-party route trees, so their tests live here too, under
    `tests/modules/<slug>/`. There is no second suite to route a fix to.
  - **Regression-Guard Discrimination (Gate: see the section at the end of this file):** the authored test MUST
    be observed to FAIL before the fix and PASS after — green on the unpatched build guards nothing.
    Rebuild without the fix (or point at the pre-fix asset/bundle), confirm FAIL; restore, confirm
    PASS. Net-new surfaces use the documented "no fail-before possible" one-line exception.
- `test run [<id> | --tag <tag> | --surface <name> | --all]` - run existing tests headless and
  report pass/fail + the screenshots.
- `test list [--surface <name>]` - show the library and what each test covers.

## What a test does (view, operate, verify)

1. Resolve the base URL from `NEXT_PUBLIC_SITE_ENV` (environments.md): the dev-apps mirror by
   default; a `live` smoke run targets production. Never hardcode the URL.
2. Navigate to the target route.
3. **View:** screenshot to `test-results/` (or the Playwright report) for visual review of
   layout, the dark-blue accent, and content.
4. **Operate:** perform the real interaction for the surface (submit the newsletter form, log
   in, open the play route, create a support ticket, grant access as admin, etc.).
5. **Verify:** assert the observable result (DOM state, redirect, network response, Convex
   round-trip, visible content).

## Cleanup after every run

Clean up test data and files after every run, UNLESS Francis explicitly instructs otherwise for
a given run (e.g. "keep the screenshots", "leave the seeded data"):

- **Convex test data:** tear down rows the test created (test users, sessions, moduleAccess
  grants, accessRequests, per-module state rows, support tickets and messages). Prefer a dedicated test
  user/namespace and delete it at the end. Never leave test rows in a shared dev or live DB, and
  never run destructive cleanup against the live DB (scoped deletes of the test namespace only).
- **Files:** remove generated screenshots, traces, videos, the Playwright report, and temp
  fixtures the run produced. Keep the `tests/` source specs (those are the library); remove only
  run artifacts.
- **State:** leave the environment as found (servers, env vars, the bind-mounted DB file) so the
  next run starts clean.
- **Retention override:** when Francis asks to keep artifacts or seeded data for a run, retain
  them and say so. Otherwise default to full cleanup.

## Admin in tests (shared helper)

Admin-gated specs (`admin`, `support`, `beta`, `module-app`, and any debug route that needs an admin)
use the deterministic admin from `ADMIN_USER` rather than re-signing-up a real identity. Auth is
PASSWORDLESS (no `ADMIN_PASS`): the shared `tests/_helpers/admin.ts` exposes `seedAdmin()` (runs
`npx convex run admin:seedAdmin`, idempotent) and `signInAsAdmin(page)`, which drives the real
6-letter code flow. In development the backend does not send email; the code is read with the
dev-only `authCodes.peekCode` query (the helper's `peekCode`/`loginWithCode`), and the code is not
consumed on verify, so parallel workers signing in as the shared admin reuse the same code without
colliding. `playwright.config.ts` loads `.env.local` (via `process.loadEnvFile`) so the runner has
`ADMIN_USER`. See backend.md § auth and § seed-admin.

`loginWithCode(page, identifier, email?)` is reusable for any account, not just the admin: it
requests a code for `identifier` (username or email), reads the dev code for `email`, enters it in
the split 3 + 3 boxes, and lands on `/account`. Created test accounts are torn down with the
dev-only `admin:purgeTestUser({ email })` mutation (guarded to development and refuses the admin).

## Coverage targets (author a test per surface)

One curated test (or small set) per surface, tagged by mode:
- `theme` - blue accent tokens render; no leftover coral or ported navy/cream; **gold appears
  only in permitted roles** and never as body text on white (palette.md § The gold rule).
- `home` - hero, the two module spotlights with their Beta chips, newsletter CTA present, and
  no claim that either module is generally available.
- `modules` - listing renders both module cards with correct beta state.
- `uniformity` - cross-page design-system conformance (the build-uniformity validator,
  Francis 2026-05-25). Guards the agreed structures so an off-pattern asset fails here instead
  of shipping. Locked invariants: (A) every hero bleeds to the top via the canonical
  `<HeroHeader transparent>` + `-mt-24 pt-32` pattern (hero image boundingBox.y ~ 0 on home,
  /modules, /modules/<slug>); (B) every `.cta-link` underline is brand-accent-light (matches
  <ArrowLink> / Button `link`); (C) every curved section divider (`[data-curved-divider]`)
  overlaps the section above via a negative top-margin ~ its own height, so the dark section's
  color rests along the curve (catches the home divider `-mt-px` regression). Extend as new
  structures are locked (hero CTA must use the shared Button; eyebrow tracking/size; palette
  tokens). Run it in the exit-test of any mode that touches a hero, a CTA, a section divider, or
  shared chrome.
- `module-intro` - `/modules/<slug>` content renders; the Request-beta block shows the correct
  one of its five states for each auth/entitlement combination.
- `newsletter` - submit posts to Mailchimp (this site's own audience, `status:"pending"`);
  honeypot + 3s-cookie gating fire.
- `contact` - Turnstile-gated submit.
- `auth` - create account, log in via the 6-letter code, header login becomes the user icon.
- `beta` - the seven cases in beta-access.md § Exit tests: five UI states, request creates a
  pending row, admin approval grants, denial stays neutral and never leaks `denyReason`,
  duplicate requests rejected server-side, non-accessible module rejected even when forced,
  erasure removes the rows.
- `app-gate` - `/modules/<slug>/app` shows the beta state when not granted and the app when
  granted; **and the module's own Convex functions refuse an ungranted caller** — a route-only
  test passes against an app whose API is wide open.
- `support` - a member creates a ticket (module + purpose); it appears for the admin. **And the
  privacy assertion, which is the load-bearing one:** a second signed-in user and a logged-out
  visitor both get denied on that ticket's URL and never see it in any list. Private-by-default
  is a claim that has to be tested, not assumed.
- `admin` - triage/reply (email action fires)/close/sort; user-management grant/revoke and the
  open-ticket quick-link.
- `convex` - schema deploys; a smoke mutation round-trips.
- `deploy` - `docker compose config` validates; the nginx proxy resolves the domain to the Next
  port and forwards WS.
- `usage` - metering (usage-metering.md § H). Calls are scripted server-side jobs, not chat, so
  assertions are on job outcomes and usage rows rather than streamed prose — and a multi-call job
  must produce ONE `runId` across its calls, which is a clean deterministic check on a
  non-deterministic operation. **Metering is what makes AI features testable:**
  generated content cannot be asserted on without flake, but "a usage row was written with the
  right shape" is deterministic. The model helper returns a canned response when
  `SITE_ENV=development` — the same proven pattern as `requestLoginCode` skipping SMTP — so the
  suite never burns real tokens, and the stub STILL writes usage rows so the metering path is
  exercised. Cases: a call writes a raw row + both rollups; an errored call is recorded; the anon
  rollup increments with no `userId`; erasure clears `aiUsage`/`usageDaily` but leaves
  `usageDailyAnon`; a non-admin cannot reach the Usage panel or its queries.
- `account` - the four Overview states render from seeded rows; the **zero-state** (account, no
  requests) shows the orientation line and the full beta-enabled module list — the state nearly
  every visitor sees and the easiest to leave untested because it looks like "nothing"; My Tickets
  lists only the caller's own; `denyReason` appears nowhere; no dead `?tab=progress` route survives.
- `email` - every send writes an `emailLog` row with the right type and status; a FAILED send is
  recorded as `failed` and surfaces to the user synchronously rather than showing "check your
  email"; no log row contains a plaintext address; and the resend affordance reports honestly when
  an unexpired code means no second email was sent.
- `observability` - a deliberately thrown error reaches the reporter; a domain failure writes an
  `errorLog` row with its correlation id; the invariant checks return sane values against seeded
  data. **And the scrubbing assertion, which is the one that matters:** a report generated from a
  request containing an email address must not carry that address (observability.md § D).
- `art` - **re-authored for the graphic system** (the ported suite asserts watercolour-era
  invariants): graphics render at both viewports, the aspect-ratio container paints a non-zero
  height (keep the Turbopack arbitrary-value guard), inline SVG picks up the palette tokens rather
  than hardcoded hexes, gold hairlines are actually visible at mobile width, and motion respects
  `prefers-reduced-motion`.
- `copy-truth` (cross-cutting, not per-surface) - rendered copy on a surface does not assert a
  capability the UI denies the reader it is shown to, and pro-forms resolve unambiguously. Seed
  case: the `/support` hero subtitle must NOT tell a logged-out / no-access visitor they can open
  a ticket by picking a module (reading is public; opening needs login + module access — see
  `src/components/support/SupportHub.tsx`). Authored via `test discover --surface support
  --complaint "..."` once the `/copy-truth` sweep flags a surface and the copy fix lands; run it
  in the exit-test of any mode that changes user-facing copy. Pairs with the `/copy-truth`
  authoring-time gate: the gate prevents writing the untrue string, this test prevents it
  silently reappearing.

## The exit-test rule (how every other mode uses this)

Every mode that creates or changes the site ends by:
1. Finding the test(s) tagged for the surface it touched.
2. If none exists, running `test discover` to author one.
3. Running them headless and confirming they pass and the screenshot looks right — AND that the
   test discriminates: it was observed to FAIL before the fix and PASS after (Regression-Guard
   Discrimination Gate, at the end of this file). A test green on the unpatched build is not
   regression coverage.
4. Only then presenting the work. A failing or absent or non-discriminating test means the work
   is not done.

Modes that change **user-facing copy** additionally run the `copy-truth`-tagged spec(s) for the
affected surface (authoring one via `test discover` if absent), so a copy regression that
re-introduces an untrue UI claim fails here instead of shipping.

This is enforced by the Test-Suite Verification gate in SKILL.md, which fires before any mode
presents its result.

## verify (the gate) — `pnpm verify` / `/odyssey-apps verify`

`test run` is for authoring and spot-checking. **`verify` is the gate**: the single command that
earns the word "verified," and the only run whose result may be presented as done. It exists
because a verification is only meaningful if it ran the WHOLE suite against the SAME single
backend the browser uses. `scripts/verify.sh` does, in order:

1. **Clean restart** (`serve stop`): kill Next on :3050, the stray host `convex-local-backend`
   for this instance, and `docker compose stop` (data preserved). Start from a known state.
2. **Bring up Convex** (docker only; Playwright boots its own prod Next on the freed :3050).
3. **Single-backend assert (fail loud, non-zero exit):** refuse to proceed if BOTH a host
   `convex-local-backend --instance-name odyssey-apps` AND the docker `odyssey-apps-convex-backend-1`
   are alive (the :3220 split that makes "verified" a lie), or if neither owns :3220. Then deploy
   functions (`npx convex dev --once`) and run a read-only sentinel (`authCodes:peekCode`) to
   confirm the authoritative backend actually has the deployed functions in development mode.
4. **Build** (`pnpm build`: types/lint gate), then the **FULL** Playwright suite at **BOTH**
   viewports (no `-g`, no path filter). Regression coverage only works if every surface runs.
5. **Freshness marker:** on a fully green run, stamp `.last-verify` with `HEAD-sha:tree-hash`
   plus a timestamp. Any failure writes no marker and exits non-zero.

The `.last-verify` marker is what the `Stop` hook reads to flag "the working tree changed since
the last real verification" — so a "done" claim that skipped the gate gets caught mechanically.
Run `verify` (not a `-g` subset) before declaring any change/fix/feature done. For fast local
iteration `npx playwright test -g <name>` is fine, but it is NOT gate-qualifying and stamps no
marker.

---

## The Regression-Guard Discrimination Gate

**Carried into this file 2026-07-22.** It previously lived in a separate `/test-suite` skill,
which was nsayka-wawa's **Inform 7 game harness** (node smoke tests driving a gblorb) and was
removed from this project — the site's Playwright suite is owned by `/odyssey-apps test`. The rule
itself is general and load-bearing, so it lives here now. Any reference to
`../../test-suite/SKILL.md` means this section.

CHECKPOINT — Regression-Guard Discrimination Gate (fires whenever a test is authored or updated to cover a fix, immediately after the covering-test-exists-and-passes gate, before declaring the fix done):
1. A covering test that only passes on the fixed build is NOT proven to guard the regression. It MUST be observed to FAIL on the pre-fix state AND PASS on the post-fix state. Until both observations exist, the fix is NOT done.
2. Canonical method — the stash-baseline technique: with the test authored and the fix applied, (a) stash/revert ONLY the fix (`git stash -- <fix-files>`), leaving the test in place; (b) **rebuild the affected artifact** — `next build`, or restart the dev server, and `npx convex deploy` if Convex functions changed; a stale build voids the observation; (c) run the covering test; (d) record the result.
3. STOP — no fail-before. IF the test PASSES against the stashed pre-fix build → it discriminates nothing. Do NOT declare done. Restore the fix, tighten the assertion until it fails pre-fix, re-run step 2.
4. Restore the fix (`git stash pop`), rebuild, run again, confirm PASS. Record this second observation.
5. STOP — no pass-after. IF it does NOT pass on the restored build → the fix is incomplete or the test mis-targeted. Resolve before presenting.
6. Legitimate exception — a brand-new surface with NO prior behavior to break (net-new feature/route/asset). NEVER a silent skip: write a one-line justification into the test body AND the closing report: "regression-guard: no fail-before possible — net-new <surface>." Absent that line, steps 1-5 stand.
7. Forbidden failure modes (any one voids the gate — STOP and rewrite): (a) asserts an always-true/tautological condition; (b) asserts imagined behavior the build was never observed to produce; (c) confirms only pass-after without the step-2/3 fail-before and without the step-6 exception.
8. Closing report MUST state, per covering test: the pre-fix result (FAIL, or the step-6 justification) and the post-fix result (PASS), both against a rebuilt artifact. "Test passes" alone MUST NOT be reported as a guarded regression.

**Note on scope here.** Most of this project's early work is net-new surface, so clause 6 will
apply often — which makes it the clause most likely to be abused. The justification line is
mandatory: a net-new claim written down is auditable, a net-new claim assumed is a silent skip.

---

## Delegate the plumbing to playwright-mcp

**Added 2026-07-22.** This procedure was ported from a project that drove Playwright by hand. The
`playwright-mcp` server ships a tested e2e pack, and reinventing it here would be strictly worse.
It is the approved browser path (CLAUDE.md forbids the chrome extension, not Playwright).

**Read `suite_methodology` BEFORE creating, editing, or auditing any spec.** Topics: `overview`,
`methodology`, `authoring`, `audit`. The lessons below are drawn from it; the tool is the source.

| Tool | Use for |
|---|---|
| `suite_methodology` | The playbook. Read first, every time |
| `suite_scaffold` | Lays the whole foundation into the repo: Playwright config with captured-session reuse, an **environment guard**, an **enforcing page-integrity gate**, **report-only error capture**, session-isolation rules, plus a project-local test-suite skill. Run in build phase 1 |
| `session_login` | Capture one authenticated session. **This site needs it** — passwordless email-code auth means every gated test would otherwise re-drive the whole login flow |
| `session_attach` | Re-bind a session captured in an earlier run, or **switch which actor the browser is** mid-suite. `session_attach({name: null})` drops back to anonymous |
| `session_scaffold_tests` | Freeze a flow as a deterministic runner-executed suite reusing that session, with no model in the loop |
| `suite_audit` | Run the suite (or parse `test-results/last-run.json`) and get per-failure dossiers plus the adjudication rubric |

`suite_scaffold` writes templates only — no session data, no credentials — and project specifics
stay in this repo. Run it ONCE in build phase 1; `force: true` overwrites customisations, so treat
a re-run as a deliberate act, not a refresh.

### The two-actor pattern — required for SignMe, useful for admin flows

Some flows cannot be tested as one logged-in user, because the whole point is that **two different
people do two different things to the same object**. SignMe is the clearest case: an agent composes
and sends an envelope, and a *different* person — who has no account and no `moduleAccess` grant —
receives and signs it. A single-session test cannot prove the signer path works without an account,
which is exactly the property that must not silently break.

The pattern:

1. `session_login({name: "sender", ...})` once, capture the agent's session.
2. Drive the sender half — upload, detect, adjust fields, send.
3. `session_attach({name: null})` to become **anonymous**, then follow the signing link. Anonymous
   is the correct actor for the signer, and using it is what proves the route is ungated.
4. For flows where the second actor IS authenticated (admin triage of a user's beta request, support
   replying to a ticket), `session_attach({name: "admin"})` instead.
5. Return to the first actor with `session_attach({name: "sender"})` to assert what they now see.

**Anonymous is not a fallback, it is an assertion.** A signer test that runs while still bound to
the sender's session proves nothing about the ungated route and will keep passing after that route
is accidentally put behind auth.

**Capability note.** Session binding — a captured login that the interactive `browser_*` tools
share, not just `web_fetch` and generated suites — was advertised by `playwright-mcp` but not
implemented until 2026-07-27, when it was built during the DocuSign review (see `research-log.md`
§ 12.5). If a suite behaves as though `session_login` did not authenticate the browser, check that
the `playwright-mcp` in use is at or after that change rather than assuming a test defect.

---

## Failure adjudication — TEST-DEFECT vs PRODUCT-BUG

Every failure gets exactly one verdict, evidence-first, one failure at a time.

- **TEST-DEFECT** — the software is right, the test is wrong: stale selector, wrong fixture data,
  timing budget, session-shape violation, mis-declared expectation, environment not established.
  → Fix the SCRIPT, re-run to green.
- **PRODUCT-BUG** — the software violates its own contract while the test's expectation matches
  intended behavior, reproduced under a correct, freshly-verified setup. → **The spec stays
  byte-for-byte untouched.** Fixing the product is a separate deliberate task with its own review,
  never a quiet side effect of making tests pass.
- **AMBIGUOUS** — evidence supports both. → Present both readings to Francis. **Never default
  toward the side you are allowed to edit.**

**Evidence over error text.** Two unrelated bugs can render the same user-facing error. Classify
by artifacts — failure screenshots, page snapshots, attachments — server-side state, and
clean-condition reproduction. Never by message string alone. And an empty log next to a
user-visible error means the failing branch has no logging, not that nothing failed.

This rubric is what keeps the autonomous `build` loop honest (build.md § Per-phase loop step 4).
A loop rewarded for turning red green will eventually weaken an assertion, and a weakened
assertion reads exactly like success.

---

## Session isolation — fresh per test by default

**Fresh-session-per-test is the DEFAULT. Sharing is an opt-in exception that must state its
reason.**

A shared `storageState` means ONE server-side session across every test in a file. Session-mutating
flows then accumulate state and fail in ways that implicate innocent code.

**This site has a spectacular instance: the erasure test DELETES THE ACCOUNT.** Run it on a shared
session and it destroys the fixture every later test depends on — and those tests fail somewhere
else entirely, pointing at code that is perfectly fine. Same hazard, lower severity: beta requests
(one live request per user per module), lockout tests (they lock the account), ticket creation, and
account edits.

The port's `signInAsAdmin` deliberately does NOT consume the login code in development so parallel
workers can share the admin. That is a legitimate opt-in for **read-style admin specs**. It is not
a licence to share sessions for anything that mutates.

Rule: if a spec changes account state, it owns its own account.

---

## Two error layers, two verdicts

Keep these apart. Collapsing them either drowns signal or ships artifacts.

- **Rendered-DOM artifacts FAIL the test.** Server error text, leaked template tokens, raw markup
  rendered as text, and `undefined` / `NaN` in visible content are deterministic first-party
  defects. The page-integrity gate from `suite_scaffold` enforces this.
- **Console and network noise is ATTACHED, never failing.** Beacons, third-party 4xx, transient
  aborts. Captured to the report for diagnosis.

The first layer catches real shipped bugs on day one more often than expected — and a beta site
with thin copy and empty states is exactly where a stray `undefined` reaches a page.

---

## Other run discipline (from the playbook)

- **Environment first.** Most "flaky tests" are mode bugs — a spec run against the wrong
  `NEXT_PUBLIC_SITE_ENV`, a stale Convex deploy, or a backend that never reloaded. The guard runs
  on EVERY invocation, and it must PROVE the mode took effect rather than trusting the flip. This
  is why `verify` asserts exactly one authoritative Convex backend with current functions.
- **Serial workers by default.** Convex is a shared backend and specs reconcile against it.
- **Seed real row shapes.** Fixture rows that fill only the columns the happy path reads will pass
  and then violate an invariant some other code path enforces. Derive scoping values from parent
  records; never hardcode.
- **Finite resources.** The suite's finite resource here is **AI spend** — which is why the model
  helper stubs under `SITE_ENV=development` (usage-metering.md § H). A suite that burns tokens on
  every `verify` is a suite that gets run less often.
- **After any suite-infrastructure change, re-run a known-green slice** before trusting new results.

Source: playwright-mcp `suite_methodology`.
