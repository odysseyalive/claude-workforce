# The Account Area — specification

**Status: SPECIFICATION ONLY.** Nothing here is built. This is what `/odyssey-apps build` reads
when it reaches the account surfaces. Read alongside [beta-access.md](beta-access.md),
[schema.md](schema.md) § H, and [procedures/support-admin.md](procedures/support-admin.md), which
own the parts this page merely presents.

---

## A. The reframe: for most of launch this is a WAITING ROOM, not a dashboard

The port's account area assumes an active player with progress to show. This site's population at
launch is the opposite, and it follows directly from two decisions already made:

- **Open signup** — anyone can register.
- **Manual grants** — almost nobody has access to anything.

So the modal account holder is someone with **an account and no entitlement**. The account area's
primary job is to tell that person where they stand and what happens next. A dashboard built for
the granted minority will be empty for nearly everyone who sees it.

**The failure mode to design against:** an empty page reads as a dead product. With two
coming-soon modules and no progress to show, "your account" can easily render as three headings
and nothing underneath — and the visitor concludes the site is abandoned. Same discipline as the
thin module intro pages (build.md phase 4): **design for the empty case first**, because it is the
common case and it ships first.

**And its opposite, for the granted minority: get out of the way.** Someone with access came to use
the module, not to admire an account page. The granted state's job is one obvious route into
`/modules/<slug>/app`. Do not build a hub that competes with the product.

---

## B. Tabs — what the port gives, what changes

The port ships `AccountShell` with tabs `Overview | Progress | Data & Privacy | (Admin)`, driven by
a `?tab=` param, each with a `data-testid` (`account-tab-<key>`) the test suite can drive.

| Tab | Disposition |
|---|---|
| **Overview** | KEEP the shell, REWRITE the contents (§ C) |
| **Progress** | **STRIP** — `ProgressPanel.tsx`, kəmtəks, missions, vocabulary |
| **Data & Privacy** | KEEP as-is. `DataPrivacyPanel.tsx` backs the GDPR controls; erasure semantics are schema.md § H |
| **Admin** | KEEP. Conditional on role; links to the desk rather than duplicating it |
| **My Tickets** | **ADD** — see § D |

Also from `components/account/`: **keep** `AccountShell`, `AvatarPicker` (the curated no-upload
set — mechanism sound, artwork needs replacing), `DataPrivacyPanel`, `AdminPanel`, and
**`BetaIntentClaimer`** (§ E). **Strip** `ProgressPanel` and `LocationField` (the `location` field
is dropped, schema.md § C). `UsageChart` is an ADMIN stat component that happens to live in this
folder — it stays, and it is the existing pattern the metering dashboard should build on
(usage-metering.md § G).

---

## C. Overview — the four states

This is the whole page for most users. It is a **per-module status list**, because that is the
question they actually have: *where am I with each of these?*

| State | What it shows | Primary action |
|---|---|---|
| **No request** | The module, one line on what it is, and that it is in beta | Request beta access |
| **Pending** | "You're on the beta list", requested date | Nothing loud. A quiet Withdraw, if built |
| **Granted** | The module is open | **Enter the app** — prominent, the page's clear exit |
| **Denied** | Neutral: not enabled for your account right now | Support link. **Never `denyReason`** |

**Show every beta-enabled module, not only the ones with a row.** The user's mental question spans
the catalog; a list of only their existing requests hides the thing they might want next.

**The zero-state — the one that ships to nearly everyone.** A signed-in user with no requests
should see, above the module list, a short line orienting them: they have an account, the modules
are in beta, requesting access is how they get in. Two sentences. It is the difference between "an
empty page" and "a page that told me where I am."

**Keep the profile summary light here** — username, email (display only; it cannot be changed,
email.md § H), avatar. It belongs on Overview rather than earning its own tab at this size.

---

## D. My Tickets — new, and required by an earlier decision

Support became **private tickets only** (DEC-2026-07-22-private-tickets-only). That removed the
public `/support/<slug>` thread list — which was also how a user found their own tickets.

**So the account area has to provide it, or a user's tickets become unreachable to them.** This is
a direct consequence of the privacy decision and easy to miss precisely because nothing errors:
the tickets still exist, still get replies, and the user simply has nowhere to read them.

`listMyTickets` already exists in the port. The tab lists the caller's tickets with status and last
activity, linking to the existing `/support/.../ticket/<hash>` permalink.

---

## E. `BetaIntentClaimer` — keep it, and know why

A user who clicks "Request beta access" while signed out gets sent to signup. The intent is stashed
in `sessionStorage` by the login form and fired **on `/account`** after signup completes.

**It lives here for a non-obvious reason worth preserving in a comment:** firing the mutation
immediately after `signIn()` resolves gets dropped as unauthenticated, because the Convex Auth
header has not propagated yet. `/account` mounting is a reliable point at which it has. The
component clears the sessionStorage key before firing, so a refresh or a StrictMode double-invoke
cannot re-fire, and the mutation is idempotent server-side regardless.

This is exactly the kind of hard-won detail a rewrite loses. Port it; do not reimplement it.

---

## F. What NOT to build

- **Usage or token stats for the user.** There are no caps and no billing, so the number is
  meaningless to them and invites questions with no answers. Metering is an ADMIN surface for now
  (usage-metering.md § A).
- **A notification preference centre.** Per-thread opt-out already exists (`ticketSubscriptions`).
  A global preferences page is a surface to maintain with almost nothing in it.
- **Anything billing-shaped.** No subscriptions exist, and a "Billing (coming soon)" tab is a
  promise with a date attached.
- **A second home for module discovery.** `/modules` is the catalog. Overview shows *status*, and
  links out.

---

## G. Exit tests

Per the standing directive, `build` does not present this without them:

1. Each of the four Overview states renders correctly — driven by seeding the underlying rows, not
   by mocking the UI.
2. The zero-state (account, no requests) renders the orientation line and the full beta-enabled
   module list — **the state most users see, and the easiest to leave untested because it is
   "empty."**
3. A granted user sees a working route into `/modules/<slug>/app`.
4. `denyReason` appears nowhere in the served HTML for a denied user.
5. My Tickets lists only the caller's own tickets; a second user's ticket is not reachable.
6. The Progress tab is gone — no dead `?tab=progress` route, no orphaned test.
7. Data & Privacy still drives erasure correctly after the tab changes.
