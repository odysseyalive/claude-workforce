# Meridian — workflow notes from the working agent

Raw interview record. **Her words first, interpretation second.** Per
`modules.json → meridian.positioning.source_of_truth`, this file is the evidence base for
Meridian's product scope; nothing gets built that cannot be traced back to a line in here.

Gathered by Francis from his wife, a working solo real-estate agent. One question at a time.

---

## Session 1 — 2026-07-22

### Q: When you sit down to work in the morning, what's the first thing you check?

> "The first thing is texts and any voicemails, and then also email and social media for a new
> request. Then makeup and hair while listening to podcasts. Then get dressed and go on Zoom for
> our weekly brokerage meeting."

### Q: What scenarios direct the type of work you do each day?

> "Sometimes, or every day, I log into my MLS and see if there's any new properties on the market
> that I've just sent to my buyer clients and see if they want to become interested in them. Or
> sometimes I see if there's any expired listings, or ones that have gone off the market, that I
> feel comfortable enough reaching out to. And just reaching out to my sphere, seeing if they are
> pursuing any real estate goals right now. And sometimes I'm just writing to prospects."

### Q: When you reach out to your sphere, how do you decide who to contact that day?

> "It all depends on what's on the market and how they rank and being serious about putting in an
> offer. Because if they are not like super motivated, then I may just not decide to contact them.
> But if they are super motivated and I know that they are needing to put in an offer, then I will
> reach out to them first and take things from there. It's basically on a ranking system where I
> don't want to get too overwhelmed, but I reach out to those people who have been recent and are
> wanting to find interest in a new place of purchase."

### Q: Where does that ranking live — in your head, or written down somewhere?

> "It lives by my conversations with these people on how fast they respond back to messages and how
> motivated I feel they are in looking at another property. Or if they live out of the area and they
> need to travel a distance to meet up again."

### Q: Do you have a CRM, or anywhere you keep notes on these people? Or is it all in your head?

> "It's not my head, it's on literal paper — because when I write people's information out on
> literal paper I have an easier time referencing it. I know I need a CRM and I don't use one right
> now, but I'm sure that when I get enough clients underneath my belt I will start needing to use
> one and being able to afford to use one. But right now it's in literal notebooks and scraps of
> paper that I take mental notes of and recognize the handwriting and, you know, whatever was
> happening when I wrote their information down."

### Q: When you need to find something you wrote down, how easy is it to find?

> "It's fairly easy, because I only have a few notebooks and things are fairly easy to find based on
> where I wrote them down at. Like if I'm writing them down at the office, I use a smaller notebook,
> but when I'm with the actual prospect or client, I have a bigger notebook where I write more
> specific information for them. But then if I'm just like taking notes about things in general,
> even though they are specific, I use a different notebook. I know it's kind of weird, but that's
> how my mind thinks."

### Q: Has anything ever slipped through the cracks — and how did you find out?

> "There may be a few people that have slipped through the cracks, because I have only communicated
> with them over the phone through voicemail and text message, but they're so far back in my text
> messages that I kind of am like out of sight, out of mind. So yeah, there are some prospects that
> do slip out of mind like that. Sometimes it's just time, because it's been so long since I've
> talked to them. But others, I feel that they're interested in working with me, or they've decided
> to do other plans. So I just leave them on the very very very very very back burner for the
> conversation."

### Q: Of the ones that slipped — would you have wanted to talk to them, or were you fine letting them go?

> "That is such an interesting question, because there are some of them that I am honestly glad that
> they decided to work with somebody else, because of where they were located or what was going on
> with me at that time that they decided to list. But then others I felt sad that I didn't stay in
> contact with them, because I felt like we got on with each other and we could have been a great fit
> to work with professionally. It's always a trial and error situation with people, because I try to
> accommodate people no matter where they come from — but there are just some that just slip through
> the cracks because I'm not sure."

### Q: When you finish a conversation with someone, do you write anything down about how it went — or just what they need?

> "It depends on the person and how rushed they are. Because sometimes people come into the office or
> call me and they want this and that, and I try to take down as many notes as I can. But then others,
> I just write down their name and number and email if they agreed to give that to me, so that I can
> stay in touch later, and just write a few notes about what properties that they are looking for, or
> if they are doing a sell in a specific period. But sometimes it's just whatever lands on my plate
> during the day."

### Q: When you go back to those notes later, what's usually missing?

> "Nothing's usually missing, unless it's a question I forgot to ask the person who came in to the
> office or called me. I think it's just a reflection of what they had time to reveal at the time."

### Q: What kind of question do you usually forget to ask?

> "I usually forget to ask when they're needing to buy, or sometimes I forget to ask the price range,
> or the location that they're wanting to look for. But most of the time it's the prospect being in a
> big rush and not wanting to reveal too much. And I just have to leave it at that, because they are
> the ones in the end controlling how much information they want to reveal. And sometimes they feel
> uncomfortable with revealing like their price range, or if they're paying cash, or when they're
> needing to buy, or if it's actually a need to buy. And so I feel like—"

### Q: Finish that thought — "and so I feel like…" what?

> "I just feel like when somebody walks into the office blindly and wants to know what properties
> match what they're looking for — sometimes they're wanting more information than they're willing to
> [give]. So it seems like they're wanting a lot of information, but they're not wanting to give us a
> bunch of information about them to follow up."

### Q: When someone walks in like that, what do you actually end up doing for them?

> "It depends on the day. Sometimes if I'm not really busy doing anything, I will get to work on what
> they're wanting to know right away. But if I'm slammed with what I'm working on, it may take me up
> to a week or two to address their questions or get back to them, because I'm a busy person."

### Q: When you sit down to work on their questions, what are you actually doing?

Volunteered first — a concrete loss:

> "A case in point: I had done a market analysis for somebody last year, and they were like, oh, we
> decided that we're not going to be selling until next summer. And lo and behold, they must have
> gotten contact with another brokerage and had their property listed. And it's a beautiful property.
> I would have been glad to list it for them. But I have a hard time getting people wanting to keep
> contact with me, instead of me always being the one keeping contact with them."

Then the answer:

> "I'm actually trying to see if they are serious about what they're talking about. Because sometimes
> I feel like they are serious when they end up not being serious at all, or they're just phishing for
> information. Other times I know they're serious, but then their financial goals don't align with
> what they want to do, and it goes nowhere. So either way it goes nowhere."

### Q: When someone tells you a date like "next summer" — what happens to that?

> "It's really sad, because even though I write down their information, I have emails from them — I
> get so busy and preoccupied, or I'm in a funk, where I fail to follow through and make sure that I
> have them hot under my tail. I know it's a failure on my part, because I just don't know how to
> handle my time management with people like this. But I need a system where I can make sure that I'm
> keeping these people thinking about me. And it's really sad that I haven't figured that out yet."

Volunteered before the next question — unprompted confirmation of the guilt constraint:

> "I know I need more accountability, but I don't want to be made to feel like I'm not doing enough,
> because my life is so full. I just need a system that's going to work for what I want to do. And to
> make sure that none of my contacts know that I have left them on the side of the road to die."

### Q: When you do remember someone months later and reach out — what do you actually say to them?

> "I've been thinking about you and I hope everything's going okay in your life. I'm not sure if
> you've decided to move to a different location or not, or if things haven't progressed for you
> financially to buy a home or to sell your home. I just want you to know that I'm still here for
> you, and that I'm here for you and I'll make time for you."

Volunteered — the business context, offered for the first time:

> "Something that my partner at our firm and I have expressed is that we don't have a transaction
> coordinator, because we are a boutique brokerage here in the Pacific Northwest. We want to keep our
> brokerage small but yet develop our growth within. But sometimes we just don't have the systems in
> place to make things successful, because we're kind of behind on the game with technology here and
> there, unless we decide to research what's new out there. It's definitely a system issue and will.
> It was definitely a subscription issue — and what I can afford to subscribe to, for these fancy
> tools that honestly I don't even know if they're gonna work or not."

### Q: Which part is harder — figuring out who you should reach out to, or actually getting yourself to do it?

> "I think the reaching out part, because it's all a mixed bag of nuts — because I don't really know
> who's really serious or not. But I know that if I do reach out, the money is going to be good. But
> I don't really have a hard time reaching out to people. It's not knowing if they're going to really
> appreciate me reaching out, or if they're really serious or not. It's really interesting, because
> I'm dealing with all different types of personalities. And I don't have my time to be wasted on
> people who aren't serious, or who are just playing with me, or just want to see how far they could
> get before they just totally ghost me."

### Q: When you reach out to someone and they turn out not to be serious — what has that actually cost you?

> "It's really caused me a lot of mindless research and just thinking about them. If I had known that
> they were not serious and decided to do other things, then why would I have reached out to them —
> other than just to keep my name in their ear?"

### Q: When you reach out just to keep your name in their ear — does that usually turn into research anyway?

> "Well, I haven't had enough clients who have reciprocated the same way, so I don't really have
> anything to base that off of — except for the fact that I have made a lot of contacts of people and
> they have gone nowhere. I would have to think about that for a little bit."

**ANSWERED on return, 2026-07-22:**

> "Not really — because they're glad I kept in touch. But I think it's been too long for them, and
> they decided to make other plans, to go with another broker. And I don't know how to answer that
> question more than that."

*(She marked the limit of what she can say. Do not press this further.)*

### Q: When someone asks what's out there for them, what do you actually look up — and where do you go to find it?

> "Well first, based on their comfortability level, I ask them where they want to search for, and
> their price range. And if it's an actual house, ask them how many bedrooms, how many bathrooms, and
> if they want an ocean view or not. And sometimes they get weirded out by me [transcription unclear]
> and feel like I'm interrogating them — when I'm not. I just want to narrow down what properties
> might be available to them for what they're looking for."

**Note: she answered the intake half and not the lookup half.** Re-asked on its own below.

### Q: Once you have those answers, where do you go to look?

> "[dictation unclear] my local MLS. And if I feel like there are some properties being left out of
> that, I go to my principal broker and ask her if there's anything on her MLS. And if not, then I just
> keep on looking week after week, because I know there's something that will turn out eventually. So
> it's just a bunch of cat and mouse. It's really frustrating at times, but I just keep persisting. And
> if something comes up and they're profiled — I know it matches their criteria — then I send it to
> them or I call them about it. But I'm just tired of the ghosting. It's getting ridiculous."

### Q: How many people are you keeping an eye out for at any one time?

> "On my current radar, I have six [dictation unclear — likely 'buyers'] and one possible prospect who
> wants to sell."

### Q: And roughly how many are in the other pile — people you've made contact with who went nowhere?

> "I would assume at least a dozen, but that number is undetermined, because of how far back they are
> in my text messages or emails that have gone off the radar."

### Q: If someone handed you that list tomorrow — everyone in it, by name — what would you do with it?

> "I would try to wrap my brain up to help [dictation unclear]. I'd talk to them and just casually
> call them up and ask them if their realistic goals had been met, and what prevented that from
> happening if I wasn't in the picture. Was it their financing? Was it something else? Was the sky the
> limit in that regard? Basically asking them if they still remembered me, and how I was eager and
> willing to help them."

Volunteered — how she sees her competition:

> "Sometimes I feel inadequate because of how much success the other brokers in my area have been able
> to do — who started out from scratch, from my point of view — and how they were able to get so many
> closings from the past 12 months. But I know some of them cut corners and take risks that I'm not
> willing to take, because my reputation is on the line. And I don't play with my reputation. So it's
> really hard competing with a bunch of other realtors in my area. And helping the public to see how
> serious I am about representing them even may take a lot more time. But representing them in a way
> that will garner my respect and uphold their dignity."

### Q: Before you called one of them, what would you want to know about them?

> "Well, I can't know anything new about them unless I actually talk to them in a new conversation. So
> I have a feeling about what little I know about them, but I can't get to know them any more unless I
> have a new conversation with them."

### Q: What's the last thing you'd have written down about one of those dozen people?

> "I honestly don't remember, because it's been too long ago. I have to refer to my notes and scroll
> through my messages to see what we talked about last."

### Q: Where do those messages live — personal phone, work phone, work email, or mixed?

> "It's all mixed together. Mostly my text messages and email, and sometimes WhatsApp if the messages
> are a little bit more intense and videos need to be sent to them that are longer than what a message
> will allow. But yeah, some of them are ancient and it's really hard to search for them anymore."

### Q: Would you be comfortable with software reading your texts and emails to build that list — knowing it's mixed in with your personal life?

> "I really don't know right now, because I don't have a work phone. Everything's on my private phone.
> I just don't know how I feel about that right now. If I could have a trial period where this program
> would do that, then I may be more open to that. But it's almost like a case by case basis, because
> there are some people that I don't know about well, and then others I do. It all depends on the
> contact."

### Q: You said it depends on the contact — what makes some of them different?

> "Because I talk to my personal friends about real estate, and I'm not wanting them to be confused
> with actual contacts or actual prospects. Is there any way to kind of filter those out?"

*(She asked a direct question. Answer honestly when relaying: partly — by her sorting them, not by the
software deciding. See observations.)*

### Q: If you were handed a list of just names and the date you last spoke — nothing else — could you sort them into friends and prospects?

> "That's hard to tell, because I've saved a lot of people on my phone who I've only met once or twice,
> talking about non-real-estate issues. So there would have to be a way to filter out those people and
> just single out the ones who I have definitely talked to about real estate goals."

### Q: Looking at just a name, would you remember whether you'd talked real estate with them — or would you need to see the conversation?

> "The conversation, to be sure."

### Q: Which MLS are you on? / Would you allow a narrow read of your messages?

> "The MLS doesn't work like that. The MLS is only to upload listings, see what's on the market, do
> searches, comparative market analysis. It's not a communication tool — unless you're sending
> listings or CMAs to possible clients."

**MLS answered 2026-07-22: `CLT.FLEXMLS.COM`** — a flexmls instance (platform by FBS), local
association subdomain `CLT`, probably Clatsop County OR. See `DEC-2026-07-22-mls-data-access`
§ Amendment for the sanctioned-feed route and what still needs verifying.

### Q: Separate from the MLS — would you let software read your texts, email and WhatsApp, for the one narrow purpose of finding who you've discussed real-estate goals with, so you can sort that list yourself?

> "I would just do the text messages and maybe email. The others — I've talked to friends and other
> people about real estate, but they're not possible clients."

---

## Francis's proposal — 2026-07-22 (HIS idea, not hers; not yet put to her)

Recorded verbatim in substance, and kept in its own section deliberately: per
`modules.json → meridian.positioning.source_of_truth`, an idea from Francis is a hypothesis to test
with her, not a requirement. It has NOT been shown to her yet.

> Counties publish property information — last sale, and similar public record. Build per-county
> tooling so a user says "I'm in this county" and AI scours county sources; she plugs in a
> spreadsheet of properties someone is interested in and gets information back quickly, then vets it
> to give her client the best possible answer. Additionally: at the points in the process where she
> needs to reach back out to a client, have AI gather that information (via Playwright MCP) and draft
> the email or text she wants to send.

**Where it lands well:**
- It attacks friction #3 directly — the walk-in question that waits "a week or two" because the
  research is slow.
- **It is coherent with the decoupling hypothesis, from the other side.** She hesitates because a
  wasted outreach costs "a lot of mindless research." Making the research cheap lowers the cost of
  being wrong, which is the same result as separating the two modes — reached by a different route.
- The property research is the one part of her work she has described as genuinely slow.

**Where it needs testing before it is built:**
- **She has never described the research mechanics.** Twice she stayed abstract ("get to work on what
  they're wanting to know"). We do not know what she looks up, where she looks it up, or how long it
  takes. Building a research tool without that is inventing a surface.
- **MLS overlap is unestablished.** She already logs into MLS daily. What county records give her
  that MLS does not is unknown, and the answer determines whether this is valuable or redundant.
- **"Per county" is a long tail, not a feature.** County record systems differ site by site; each is
  its own integration and its own breakage. Scope needs to start at *her* county and prove value
  there before generalising.
- **The spreadsheet input may not match her.** She keeps notes on paper, has no CRM, and has never
  mentioned working from a list of properties. Whether a spreadsheet is natural to her is an open
  question, not a given.
- **Drafting the communication is the piece with the weakest evidence.** She wrote a good outreach
  message cold, in one pass, unprompted. Writing does not appear to be her bottleneck.
- Legal note for later: county public records are generally fine to use; MLS data is contractually
  restricted. Keep the two clearly separate.

**Addendum — Francis, same session:** "we can use Playwright MCP to log in and create a session, log
in, where we can go and get information from that site."

**This one carries real risk and needs a decision before any code, so it is flagged, not deferred.**
Automated login to an MLS and extraction of its listing data is normally prohibited by the MLS
participation agreement and the terms the *agent* signs — not by a general scraping law. The exposure
lands on her licence and on the boutique brokerage, not on the software. Getting caught typically
means loss of MLS access, which would end her ability to work.

The sanctioned route exists and is boring: most MLSs offer an authorised data feed (RESO Web API,
historically RETS) that a brokerage or its vendor can be approved for. It is an application and a
signature, not a technical obstacle. **Establish which MLS she is on and whether her brokerage can be
approved for a feed BEFORE building anything that reads listing data.** County public records stay
usable either way and are a separate, safe source.

Playwright-driven login remains fine for sources that permit it; the constraint is specific to the
MLS.

**Addendum 2 — Francis, same session:** he uses **Quo** (Q-U-O), which exposes an API for recent text
messages and call transcripts that could feed this process. A Quo MCP server is connected in this
session (`fetch-messages`, `fetch-call-transcripts`, `list-contacts`, `send-message`, and others), so
it is real and reachable, not hypothetical.

**Where it helps:** it is the cleanest available answer to "how does software see her text messages",
and call transcripts would additionally capture the channel she says she actually re-engages on — the
phone. Going forward, it would make the leak visible as it happens.

**Three things to settle before it becomes the plan:**
1. **It does not solve the problem she actually described.** Quo can only see messages that pass
   through Quo. The dormant dozen are in *ancient threads on her existing personal phone and email*,
   from before any such tool existed. Quo prevents the next dozen; it does not recover this one. Those
   are different products and she asked for the second.
2. **It is a subscription, and subscriptions are her stated barrier** — "what I can afford to subscribe
   to, for these fancy tools that honestly I don't even know if they're gonna work or not." Requiring
   one to use Meridian imports the exact objection the module is meant to clear. See
   `DEC-2026-07-22-in-house-by-default`: third parties carry a burden of proof, and the ladder is
   don't-need-it > build-into-what-we-run > self-host > subscribe.
3. **It requires her to change how she communicates** — routing client contact through a business
   number. That is a real behaviour change for someone whose current system is a notebook, and it must
   be tested with her rather than assumed.

Francis's use of Quo is his own; whether it belongs in *her* workflow is an open question for her.

---

## Observations (assistant — provisional, not decisions)

- **Morning triage spans four separate inboxes** — text, voicemail, email, social — all scanned
  for the same thing: *a new request*. Four places, one question.
- **The brokerage Zoom is a fixed weekly anchor** in the schedule.
- **Daily work is driven from two directions:**
  - *Inbound* — the new request found during triage.
  - *Outbound prospecting*, from three distinct sources: (1) new MLS listings matched to existing
    buyer clients, (2) expired / off-market listings she judges herself "comfortable enough" to
    approach, (3) her sphere — checking whether anyone is pursuing real-estate goals right now.
- **"Comfortable enough to reach out to" is a judgment call**, not a filter. Worth understanding
  before assuming any of it can be automated.
- **"Sometimes / or every day"** — the outbound work is not a fixed routine. Whether that is by
  choice or by drift is not yet known.
- **There is a real ranking system, and it is the core of the daily decision.** Three inputs in
  her words: (1) *motivation* — "super motivated", "needing to put in an offer"; (2) *recency* —
  "those people who have been recent"; (3) *market fit* — "what's on the market", i.e. whether
  inventory exists that suits them. Contact order falls out of the ranking; the unmotivated are
  simply not contacted.
- **The ranking is throttled by her own capacity** — "I don't want to get too overwhelmed." This is
  a constraint, not a nice-to-have: a system that surfaces everyone who *could* be contacted would
  make her day worse, not better. Whatever Meridian shows has to be a SHORT list.
- **The ranking is not stored anywhere — it lives in the conversations themselves.** Asked where it
  lives, she described *what it is made of*, not a place. Read carefully, that is the answer: there
  is no artifact. The ranking is re-derived from memory of message threads each time she needs it.
- **Two of her three ranking signals are mechanical, one is not.** *Response speed* ("how fast they
  respond back to messages") is measurable from message timestamps. *Distance* ("live out of the
  area and need to travel a distance to meet up") is computable from an address. *Felt motivation*
  ("how motivated I feel they are") is a human read — provisionally, that one is hers to make and
  the system's job is to inform it, not replace it.
- **The system of record is PAPER — notebooks and scraps — and it is a considered choice, not a
  gap.** Writing by hand helps her reference it later, and the physical page carries context the
  data does not: "recognize the handwriting and whatever was happening when I wrote their
  information down." Paper is beating software at *capture speed* and at *recall cues*. Any
  Meridian surface that requires typing a contact into a form is competing with a pen, and will
  lose on those two axes unless capture is at least as cheap.
- **She has no CRM, knows what a CRM is, and has deferred it deliberately on volume and cost** —
  "when I get enough clients underneath my belt… and being able to afford to use one." So the
  objection is not ignorance or resistance to software; it is overhead and price. That is exactly
  the site thesis in `$site_thesis` ("you will spend less time administering this than you save"),
  and it is the strongest evidence so far that the thesis is aimed correctly.
- **NEGATIVE FINDING — retrieval from paper is not a pain point.** "Fairly easy." Her filing scheme
  is three notebooks segmented by *where she was when she wrote*: small notebook at the office,
  large notebook when face to face with a prospect or client (more specific information), a third
  for general notes. Context of capture is the index, and it works because the volume is small
  ("I only have a few notebooks"). **Do not build search-your-notes, digitize-your-notebook, or
  photograph-your-paper features.** They solve a problem she does not have, and she apologized for
  the scheme ("I know it's kind of weird") while describing something that functions.
- **The paper system has a scaling cliff, not a present failure.** Both paper answers are bounded
  by volume — "only have a few notebooks", "when I get enough clients underneath my belt". It works
  now and breaks later. Building for the break is building for a customer she is not yet; the
  friction that sells this today is somewhere else, and we have not found it yet.
- **FIRST REAL FRICTION FOUND — people who exist only in the phone scroll out of existence.** The
  paper system holds the people she sat down with. Everyone she has only ever texted or left
  voicemails for lives in the message thread itself, and a thread has no memory beyond scroll
  position: "so far back in my text messages that I kind of am like out of sight, out of mind."
  This is the gap between her two systems, and neither one covers it.
- **This finding closes a loop with the ranking answer.** Response speed — one of her three ranking
  signals — is read off exactly those message threads. The same surface she ranks from is the one
  people fall out of. The signal and the leak share a location.
- **She distinguishes two kinds of dormancy, and the distinction is the whole product question.**
  (1) *Parked on purpose* — "they've decided to do other plans", deliberately back-burnered; that
  is a decision working correctly and needs no fixing. (2) *Lost to time* — "sometimes it's just
  time, because it's been so long"; that is leakage. She can tell them apart in the moment and has
  no way to tell them apart months later, because nothing recorded which one it was.
- **Note what she did NOT say:** asked how she found out something slipped, she gave no discovery
  event. There isn't one. She knows these people exist in the abstract but does not learn about any
  specific one — which means the cost of the leak is currently invisible to her, and unmeasured.
- **The regret is about FIT, not about lost commission.** The ones she is sorry to have lost are the
  ones where "we got on with each other and we could have been a great fit to work with
  professionally." The ones she is glad to have lost failed on location, or on *her own capacity at
  the time* — "what was going on with me at that time that they decided to list." Her availability
  is a live variable in whether a lead was even worth having, which is consistent with "I don't want
  to get too overwhelmed" and is not a field any lead-scoring model carries.
- **She cannot state the rule — "it's always trial and error", "because I'm not sure."** So do NOT
  attempt to infer or automate the keep/drop judgment. Any attempt to score which dormant contacts
  deserve a call would be inventing a rule its own source says does not exist.
- **PATTERN ACROSS THREE ANSWERS — she knows it at the time, and nothing keeps it.** Motivation
  ("how motivated I feel they are"), park-or-lose ("they've decided to do other plans"), and
  personal fit ("we got on with each other") are all reads she makes confidently in the moment and
  cannot reconstruct months later. Paper catches this only for people she met in person. This is the
  strongest candidate so far for what Meridian is actually for — provisional, and to be tested with
  her rather than assumed.
- **She was asked "how it went, or just what they need" and answered ENTIRELY in terms of what they
  need.** Everything she listed is fact: name, number, email, what properties they are looking for,
  whether they are selling in a specific period. The relational read never reaches the page — which
  is precisely the thing she said she regrets losing. Strong corroboration of the pattern above, and
  it arrived unprompted rather than by agreeing with a leading question.
- **Capture is paced by the OTHER person, not by her** — "it depends on the person and how rushed
  they are." When someone is rushed she drops to a minimum: name, number, email "if they agreed to
  give that to me". Design constraint: any capture surface has to survive being used while a client
  is standing there being impatient, and has to degrade gracefully to almost nothing.
- **Contact details are not guaranteed** — "email if they agreed to give that to me." Any data model
  that requires email as an identifier will fail on real intake.
- **The floor is "whatever lands on my plate during the day"** — on a bad day there is no method at
  all. Whatever gets built has to be usable on that day too, or it only works when it is not needed.
- **CORRECTION — the notes are not experienced as deficient.** "Nothing's usually missing… it's just
  a reflection of what they had time to reveal at the time." This directly weakens the pattern
  recorded two answers above. The relational read genuinely does not reach the page, but she does not
  feel its absence, and a friction the practitioner does not feel is not a friction — it is the
  assistant's theory. **Demoted from "strongest candidate" to unsupported.** It may only ever have
  been an artifact of asking a leading question ("how it went, or what they need") and then treating
  the expected half of the answer as a finding. Do not revive it without her raising it unprompted.
- **What survives intact is the PHONE-THREAD LEAK** — people who exist only in text and voicemail and
  scroll out of reach. That one she raised herself, described concretely, and has not contradicted.
  It remains the only confirmed friction so far.
- **New, volunteered, and mechanical: "a question I forgot to ask."** The only gap she will name in
  her notes is a question that never got asked during intake — an incompleteness at the moment of the
  conversation, not a failure of the record afterward. Unexplored; the next thread to pull.
- **Her framing limits any intake feature:** the notes are "what they had time to reveal", so the
  binding constraint is the other person's patience, not her diligence. A prompt-her-with-questions
  feature has to fit inside a conversation someone else is controlling the pace of.
- **The intake fields she names are few and specific:** timing ("when they're needing to buy"), price
  range, and location. Add the two she lists as commonly withheld: cash vs financed, and whether it
  is a *need* to buy or merely a want.
- **But she immediately reframes it as NOT a memory problem — "most of the time it's the prospect
  being in a big rush and not wanting to reveal too much."** Forgetting is the minority case. The
  majority case is deliberate non-disclosure by a guarded stranger, and she accepts it: "I just have
  to leave it at that, because they are the ones in the end controlling how much information they
  want to reveal." A checklist that prompts her with the questions therefore addresses the small half
  of the problem and is powerless against the large half. Scope any intake feature honestly against
  that, or skip it.
- **Implication worth testing later:** if the missing facts are withheld rather than forgotten, they
  arrive gradually as trust builds — i.e. across later conversations, which for phone-only prospects
  means across exactly the text threads that scroll out of reach. That would connect the intake gap
  to the one confirmed friction. Unverified; do not build on it yet.
- **SECOND CONFIRMED FRICTION — the walk-in asymmetry.** Someone arrives "blindly", wants to know
  which properties match what they are looking for, and expects real work from her — while withholding
  the details that would let her follow up afterward. She gives value up front and is left with
  nothing durable. Unprompted, felt, and stated twice in different words.
- **The two confirmed frictions are one story from opposite ends.** The walk-in asymmetry is how a
  person enters her world without a handle on them; the phone-thread leak is how that same person
  then disappears. Neither paper nor her phone closes the loop, because the person never gave her
  enough to open one.
- **THIRD CONFIRMED FRICTION — turnaround on a walk-in's question ranges from same-day to "a week or
  two", set entirely by her load.** Stated flatly, without complaint: "because I'm a busy person."
  This is the first friction with an obvious commercial cost — a stranger who asked what is on the
  market and heard nothing for two weeks has almost certainly asked someone else by then. It is also
  the first one that matches the module's stated first promise in `positioning.two_promises`
  ("work that took hours takes minutes"): the queue backs up because the task is slow, so making the
  task fast shortens the queue.
- **She still has not said what the work IS.** Across two answers it stays abstract — "get to work on
  what they're wanting to know", "address their questions". The content of that work is the next
  thing to establish, and nothing should be designed around it until she has described it concretely.
- **THE MARKET-ANALYSIS STORY IS THE CLEAREST LOSS IN THE WHOLE INTERVIEW, AND IT HAS A DATE IN IT.**
  She did real unpaid work, was told "not going to be selling until next summer", and the listing went
  to another brokerage. "Next summer" was a **known future re-engagement point, stated out loud, and
  nothing held it.** This is not a judgment call, not a ranking, not a relational read — it is a date
  someone said, and it is the single most concrete and most obviously buildable thing she has
  described. It also converts the phone-thread leak from an abstraction into a specific lost listing.
- **She names the underlying grievance directly: the relationship is one-way.** "I have a hard time
  getting people wanting to keep contact with me, instead of me always being the one keeping contact
  with them." All maintenance effort is hers. Any design that adds more outbound effort is pushing on
  the side that is already carrying the whole load.
- **The real content of the walk-in work is QUALIFICATION, not research** — "I'm actually trying to
  see if they are serious." Two failure modes she names: not serious at all / "just phishing for
  information", and genuinely serious but "their financial goals don't align with what they want to
  do". Her own summary: "either way it goes nowhere."
- **This REFRAMES the two-week turnaround (friction #3).** The delay is not negligence — it is
  rational triage of work that usually yields nothing. She deprioritizes walk-in questions *because
  most of them go nowhere*, and she is right to. Therefore "make the analysis faster" is only half a
  fix; the other half is knowing which ones are worth doing at all. Note the tension with the earlier
  do-not-automate finding: she could not state a rule for keep-or-drop on dormant contacts. Whether
  she can state one for *serious vs not* at intake is a separate and still-open question — ask, do
  not assume.
- **THE ONLY THING SHE HAS EXPLICITLY ASKED FOR, IN HER OWN WORDS:** *"I need a system where I can
  make sure that I'm keeping these people thinking about me."* Ten questions in, this is the first
  request rather than a description. Note the direction of it — **not** "remind me to contact them",
  but *keep them thinking about me*. Staying top-of-mind, which is the exact inverse of the one-way
  grievance in the previous answer.
- **The information is NOT missing — the follow-through is.** "Even though I write down their
  information, I have emails from them." She has the contact details and the record. What fails is
  acting on them at the right moment. This kills any remaining temptation to build capture, storage,
  or search: the data is already in hand and the loss happens downstream of it.
- **CRITICAL DESIGN CONSTRAINT — she already supplies the guilt; the software must not add more.**
  Her language is "really sad" (twice), "a funk", "failure on my part", "I haven't figured that out
  yet." A surface that counts overdue follow-ups, badges them red, or opens with how many people she
  has neglected would be describing her worst feeling about herself back to her every morning. She
  would stop opening it, and she would be right to. Whatever this becomes has to make the next action
  easy without keeping score of the missed ones. Recorded as binding.
- **"I'm in a funk" is a real operating state, not an excuse.** Combined with "whatever lands on my
  plate during the day" and "I don't want to get too overwhelmed", the pattern is consistent: her
  capacity fluctuates and the system must degrade with it. A tool that only works on a good week
  fails precisely on the weeks that produced every loss she has described.
- **The guilt constraint was confirmed by her, unprompted, before the next question was even asked** —
  "I know I need more accountability, but I don't want to be made to feel like I'm not doing enough,
  because my life is so full." It is now hers, not an inference. **The resolution of the apparent
  contradiction is in her next sentence:** the accountability she wants is *to the contact* — "make
  sure that none of my contacts know that I have left them on the side of the road to die" — not to a
  scoreboard. Success is measured on the recipient's side: nobody feels dropped. It is NOT measured
  by her compliance rate, and must never be displayed that way.
- **"A system that's going to work for what I want to do"** — note the emphasis. Not a best-practice
  cadence, not a methodology imported from a coach. Her practice, made reliable.
- **THE MESSAGE SHE WROTE IS THE SPEC FOR THE OUTPUT, AND IT IS NOT MARKETING.** It contains no
  property, no market data, no listing, no call to action, and no pitch. What it does contain: an
  acknowledgement of elapsed time with no excuse offered, an explicit refusal to assume their
  situation ("I'm not sure if you've decided…"), and an offer of availability — "I'm still here for
  you… I'll make time for you." **A listing drip campaign is the wrong artifact and would read as the
  opposite of this.** Anything generated here has to sound like a person who remembered you, not a
  brokerage that queued you.
- **She produced that message fluently, in one pass, unprepared.** Provisional but important: writing
  the outreach may not be her bottleneck. If so, generate-the-copy is the least valuable thing to
  build, and the value is in *who* and *when*. To be tested next, not assumed.
- **SHE NAMED THE TRANSACTION COORDINATOR HERSELF, UNPROMPTED.** `$site_thesis.home_page_proposition`
  already argues that a solo agent "loses to someone who had a transaction coordinator, a marketing
  assistant, and an ISA" — written before this interview. She independently produced the first item on
  that list as her firm's stated gap. That is the strongest external corroboration the positioning has
  received, and it came from the practitioner rather than from the copy.
- **AUDIENCE TENSION — FLAG, DO NOT RESOLVE HERE.** `positioning.audience` ratifies **the solo agent**
  and says a brokerage product is a separate future module. But she speaks as "we": a partner, a firm,
  a boutique brokerage. A two-person boutique may behave exactly like a solo agent (no support staff,
  no budget, no systems) and the ratified decision may hold unchanged. Or the real buyer may be the
  small firm rather than the individual. **Unresolved. Take it back to her and to Francis before any
  copy or pricing depends on it** — it affects the home page, the module intro, and eventually the
  plan picker.
- **"We want to keep our brokerage small but yet develop our growth within."** Growth without
  headcount is the exact shape of the pitch. Not "scale up" — do more with the two people already
  there.
- **PURCHASE BARRIER, IN HER WORDS, TWO PARTS:** (1) price — "what I can afford to subscribe to"; and
  (2) **trust** — "these fancy tools that honestly I don't even know if they're gonna work or not."
  The second is the harder one and no amount of feature copy solves it. This is the same instinct as
  `DEC-2026-07-22-in-house-by-default`'s burden of proof, arriving from the customer's side. It argues
  for something demonstrable before payment — and note the site already has admin-granted beta access
  and a Request-beta flow, which is exactly that shape.
- **"We're kind of behind on the game with technology… unless we decide to research what's new out
  there."** Evaluating tools is itself unpaid work she has no time for. A product that requires
  research to understand loses before it is tried.
- **THE BLOCKER IS NEITHER SELECTION NOR EXECUTION — IT IS UNCERTAINTY ABOUT WHETHER IT IS WORTH IT.**
  She answers "the reaching out part" and then immediately takes it back: "I don't really have a hard
  time reaching out to people." What stops her is not knowing "if they're going to really appreciate
  me reaching out, or if they're really serious." So the friction is not mechanical — not writing (she
  drafted a good message cold), not sending, not finding names. It is the expected-value question she
  cannot answer, and the hesitation it produces is what the drift is made of.
- **She already believes outreach pays: "I know that if I do reach out, the money is going to be
  good."** Conviction is not the missing ingredient either, which rules out anything motivational.
- **What she is defending is her TIME, and the tax is uncertainty** — "I don't have my time to be
  wasted on people who aren't serious, or who are just playing with me, or just want to see how far
  they could get before they just totally ghost me." She has been burned and is now pricing that risk
  into every outreach decision.
- **HYPOTHESIS (clearly marked, unverified) — lower the COST of a wasted outreach rather than try to
  predict seriousness.** She has already said she cannot state a rule for who is serious ("trial and
  error", "I'm not sure"), so a scoring model is ruled out by her own testimony. But the same
  hesitation dissolves if reaching out costs her almost nothing: if the wrong guess costs a few
  seconds instead of an afternoon, the uncertainty stops mattering. **Test this with her before
  designing anything on it** — specifically by finding out what a wasted outreach actually costs her
  today, which is the next question.
- **THE COST OF A WASTED OUTREACH IS RESEARCH PLUS RUMINATION — "a lot of mindless research and just
  thinking about them."** Not the message. The message is cheap. What is expensive is the work the
  message commits her to (pulling matches, market analysis) and the headspace the person then occupies.
  That is why the uncertainty is paralysing: reaching out is not a small act, it is the front door to
  an afternoon.
- **SHE SEPARATED THE TWO MODES OF OUTREACH HERSELF, IN A RHETORICAL QUESTION — this is the sharpest
  structural insight in the interview and it is entirely hers.** "Why would I have reached out to them
  *other than just to keep my name in their ear?*" Two distinct things she currently treats as one:
  - **Working outreach** — reach out *and* do the research/analysis for them. Expensive, only worth it
    if they are serious, and therefore gated behind a judgment she cannot make.
  - **Presence outreach** — "keep my name in their ear." Cheap, worth doing regardless of seriousness,
    and *unaffected by the uncertainty that blocks the other kind*. This is the same thing she asked
    for outright: "a system where I can make sure that I'm keeping these people thinking about me" —
    and the message she drafted is exactly this mode, containing no research and no listings.
  **The two are currently coupled: reaching out drags the research along with it.** Decoupling them
  would let the cheap kind run at a volume the expensive kind never could — and the cheap kind is the
  one that would have caught "not until next summer".
  **Still to verify with her (next question), not to assume.**
- **DECOUPLING HYPOTHESIS: CONFIRMED — presence outreach does NOT drag research along.** "Not really,
  because they're glad I kept in touch." The cheap mode stays cheap. The two kinds of outreach are
  separable in practice and not only in theory, which is what the scope decision rested on.
- **BUT THE SAME ANSWER PRICES THE BACKLOG DOWN — "it's been too long for them, and they decided to
  make other plans, to go with another broker."** Late presence outreach buys goodwill, not
  business. So reconstructing the existing dozen produces warm conversations and probably few deals:
  worth doing, and worth being honest that it is mostly a starting position rather than a payday.
- **THE VALUE IS IN TIMING, AND TIMING FAVOURS PREVENTION.** What the losses have in common is not
  that she never called — it is that she called after the decision was made. The "not until next
  summer" case is the shape that pays: a stated date, caught before it passes. **This partially
  rehabilitates Francis's Quo proposal**, which was discounted for addressing the next dozen rather
  than this one — on this answer, the next dozen is where the money actually is. The two are now
  complementary rather than ranked: reconstruct the backlog to establish the list, then keep it from
  happening again.
- **Design consequence: the backlog is a one-time onboarding pass, not the product.** The product is
  what stops the next twelve. Ship the reconstruction first because it is what makes the list exist
  at all — but do not let it define the module.
- **The decoupling hypothesis WAS unverified; the note below records why it was hard to answer.** She has never
  run presence-only outreach at volume, so she has no experience to report. Worth noting *why*: the
  cheap mode has never been tried precisely because it is currently welded to the expensive one. The
  hypothesis is therefore plausible and untested — leave it in that state.
- **"I have made a lot of contacts of people and they have gone nowhere."** The dead-contact pool is
  large by her own account. That is the population any presence system would act on, and its size is
  worth establishing — a number, roughly, when she has one.
- **The search criteria are ordinary and few:** location, price range, property type, bedrooms,
  bathrooms, and — regionally specific — ocean view. These are MLS search fields. Provisional but
  worth noting against Francis's proposal: if the walk-in research is an MLS search on these criteria,
  county records may be redundant *for this task*, whatever else they are good for.
- **"Based on their comfortability level"** — she calibrates how much she asks to how guarded the
  person seems. The intake is not a fixed script and she is already adapting it in real time.
- **ASKING THE QUALIFYING QUESTIONS ITSELF CAUSES FRICTION** — "sometimes they get weirded out… and
  feel like I'm interrogating them, when I'm not. I just want to narrow down what properties might be
  available to them." This is the counterpart to the withholding finding: the same facts she needs
  (price range, cash or financed, timing) are the ones that make a stranger feel interrogated when
  asked for them. So the intake gap is not solved by prompting her with better questions — the
  questions are the problem, not her memory of them. **This closes out the "forgot to ask" thread:
  it is a trust problem at first contact, not a checklist problem.**
- **THE SEARCH IS NOT A TASK, IT IS A STANDING WATCH.** "I just keep on looking week after week,
  because I know there's something that will turn out eventually." She is not running a search and
  delivering a result; she is holding each client's criteria and re-checking new inventory against
  them indefinitely. That reframes the whole research question — the slow part is not any single
  lookup, it is carrying N sets of criteria in her head and re-running them forever. It is the same
  *state* problem as the dormant contacts, wearing different clothes.
- **A NEW MATCH IS A NON-INTERROGATING REASON TO MAKE CONTACT.** "If something comes up and they're
  profiled… then I send it to them or I call them about it." The match supplies an occasion to reach
  out that costs no research (the criteria were already set), does not require judging whether they
  are serious, and cannot feel like an interrogation because she is giving rather than asking.
  **TENSION TO RESOLVE WITH HER, NOT HERE:** she also drafted the presence message with no property in
  it at all. Whether a genuine criteria match counts as presence outreach or as the marketing she
  implicitly rejected is her call, and the difference between "a listing I thought of you for" and a
  drip campaign is probably the whole answer. Do not decide it without asking.
- **MULTIPLE MLS BOUNDARIES ARE A REAL FRICTION.** When properties seem to be missing she asks her
  principal broker to check *her* MLS. So coverage depends on another person's access and another
  person's time. Unexplored: how often, how long it takes, and whether the broker's MLS is a different
  region or a different service.
- **"I'm just tired of the ghosting. It's getting ridiculous."** Second unprompted mention of ghosting
  in three answers. It is the strongest negative emotion in the interview and it attaches to clients
  she has already done work for.
- **THE ACTIVE PIPELINE IS SEVEN PEOPLE. This is the most clarifying number in the interview.** Six on
  the buy side, one possible seller. Consequences, and they are large:
  - **Managing the active radar is not a software problem.** Seven people fit in a head and on paper,
    which is exactly why paper has never failed her. A dashboard of seven is not worth opening.
  - **Therefore the product is about the OTHER pile** — "a lot of contacts of people and they have
    gone nowhere" — the population too large to hold and too dormant to think about. Everything that
    has survived scrutiny in this interview points there: the phone-thread leak, "not until next
    summer", "keeping these people thinking about me."
  - **It settles the CRM question empirically.** She declined a CRM on cost and volume and she was
    right to; seven active clients do not need one. Anything that opens by asking her to maintain
    records for seven people has already lost to a notebook.
  - **It bounds the standing watch.** Six sets of buyer criteria re-run weekly is small enough to
    automate cheaply and small enough that she may not experience it as a burden — verify which,
    because it decides whether the match-watch is worth building at all.
- **One seller against six buyers, and every loss she recounted was a SELLER** — the market analysis
  that went to another brokerage, the "beautiful property" she would have been glad to list. Listings
  are where the money and the regret both are, and they are the scarcer side of her book.
- **THE DORMANT PILE IS "AT LEAST A DOZEN" AND — THE IMPORTANT PART — UNCOUNTABLE.** "That number is
  undetermined, because of how far back they are in my text messages or emails." She cannot enumerate
  the population she has been describing as her main loss. **The list does not exist anywhere.**
- **So the first useful act may be simply MAKING THE LIST EXIST** — not managing it, not scoring it,
  not automating it. Naming who is in the pile. Note how modest that is against everything considered
  so far, and that it is the one thing she demonstrably cannot do herself, by her own account, because
  the evidence is buried in threads she will not scroll.
- **The whole problem is small: ~7 active, ~12+ dormant.** Roughly twenty people. That is not a data
  problem and no part of this needs scale. It also means the barrier to presence outreach is **not
  capacity** — a dozen messages is an afternoon, and she has said she does not mind reaching out. The
  barrier is that she does not know who they are. Those are completely different products, and the
  evidence favours the second.
- **The raw material is her own text and email history**, which is where the buried threads live. Any
  attempt to reconstruct the list reads her personal correspondence — feasible, and it makes privacy,
  consent, and local-vs-server handling a first-order design question rather than a footnote. Note it
  now; do not design it yet. Relevant ledger records: `DEC-2026-07-22-data-outside-the-container`,
  `DEC-2026-07-22-hard-delete-erasure`.
- **GIVEN THE LIST, SHE KNOWS EXACTLY WHAT TO DO — AND SHE ANSWERED INSTANTLY.** Compare this with the
  lookup mechanics, which took three attempts to extract. There is no hesitation about the action, no
  request for a script, no uncertainty about what to say. **The action is not the missing piece. The
  list is.** This is the strongest support yet for a minimal first product: produce the list, stop
  there, and let her work.
- **What she would actually ask them** — casual phone call, not email: did their goals get met, what
  prevented it "if I wasn't in the picture", was it financing or something else. Note that this is
  *diagnostic as well as social*; she wants to learn what happened after she fell out of the picture,
  which is the discovery event she has never had (see the earlier observation that she never finds out
  when someone slips).
- **"Asking them if they still remembered me."** The fear underneath all of it, stated plainly. It is
  the same thing as "keeping these people thinking about me" and "none of my contacts know that I have
  left them on the side of the road to die" — three phrasings of one anxiety, across the interview.
- **She said CALL, not email or text.** The outreach she imagines is voice. Any assumption that the
  output of this is a drafted email should be checked against that — twice now the channel she names
  for real re-engagement is the phone, while text and email are where people got lost.
- **NO ENRICHMENT IS POSSIBLE, AND SHE SAID SO WITHOUT PROMPTING.** "I can't know anything new about
  them unless I actually talk to them." Asked what she would want to know before calling, she reports
  that nothing knowable exists — the only source of new information is the conversation itself. **So do
  not build research, enrichment, background-gathering, or "here is what we found out about them."**
  The list needs almost nothing attached to it: who they are, how to reach them, what she already knew,
  when they last spoke. That is the whole row. Combined with "given the list she knows what to do", the
  minimal product is now sharply bounded from both ends.
- **REPUTATION IS A HARD CONSTRAINT AND SHE STATED IT AS AN ABSOLUTE — "I don't play with my
  reputation."** She believes some competitors get their closings by cutting corners and she will not.
  Anything that looks automated, mass-produced, or salesy is therefore not a taste preference to
  negotiate — it is a threat to the thing she has explicitly refused to risk. This kills bulk sends,
  templated blasts, and anything a recipient could recognise as machine-generated. It also gives the
  presence outreach its real requirement: it has to be indistinguishable from her remembering someone.
- **She measures herself against OTHER AGENTS and it makes her feel inadequate** — "sometimes I feel
  inadequate… how they were able to get so many closings from the past 12 months." **This empirically
  validates `$site_thesis.home_page_cautions`**, written before the interview: comparison to peers
  "puts the reader on the back foot." She is living proof that it does. Keep the enemy the
  well-resourced company, exactly as ratified, and never the agent down the road.
- **"Representing them in a way that will garner my respect and uphold their dignity."** Her stated
  standard for her own work, unprompted. Any copy written for this module has to survive being read by
  someone who talks like that about her clients.
- **REFINEMENT OF THE EARLIER "RETRIEVAL IS EASY" FINDING — it holds for ACTIVE contacts and fails for
  DORMANT ones.** Asked about the recent and the few, retrieval was "fairly easy". Asked about the
  dormant dozen: "I honestly don't remember… I have to refer to my notes AND scroll through my
  messages." Two systems, both requiring effort, for people she is not currently thinking about. The
  do-not-build-search finding stands for the active pipeline and does NOT extend to the dormant pile.
- **This is precisely what makes the list valuable — assembling it requires the scrolling she will not
  do.** The cost of reconstructing one dormant contact is small; the cost of reconstructing twelve is
  what has stopped her, and the reason the number is "undetermined". The work is not hard, it is
  merely unbearable, which is the best possible profile for something to hand off.
- **WORK AND PERSONAL ARE NOT SEPARATED — "it's all mixed together."** There is no work-only channel to
  read. Any reconstruction of the dormant list touches her private life, so consent and scope are not
  a compliance footnote, they are the first design question. **Ask her directly before designing
  anything that reads her correspondence.**
- **Three channels, in her order: SMS, email, WhatsApp** — the last reserved for "more intense"
  exchanges and for video too large to text. Note that the *most* engaged conversations may live in the
  most closed channel.
- **"Some of them are ancient and it's really hard to search for them anymore."** The backlog is not
  merely unscrolled, it may be partly unreachable. Establish what actually still exists on her devices
  and accounts before promising to reconstruct anything from it.
- **WHOLESALE INBOX ACCESS IS A SOFT NO — "I just don't know how I feel about that right now."** Not a
  refusal, not permission. Treat it as a no until she says otherwise. **Do not design a product whose
  first screen asks for her whole message history**; on this answer she would not get past it, and she
  is the friendliest possible user.
- **She proposed the resolution herself: "case by case basis… it all depends on the contact."** Her
  instinct is selective, per-contact scope rather than blanket ingestion. Any access model should start
  from that shape — she points, it reads — not from a full sweep with an opt-out.
- **THE CENTRAL TENSION OF THE WHOLE INTERVIEW, STATED PLAINLY SO IT IS NOT LOST:** she can only
  consent contact by contact, and **she cannot name the contacts** — that is the entire problem ("that
  number is undetermined, because of how far back they are"). Per-contact consent presumes a list; the
  list is what she lacks. **This is unresolved and it is the hinge the minimal product turns on.** Do
  not paper over it. Plausible ways through, none yet tested with her: a first pass that surfaces only
  names and dates with no message content; processing that never leaves her device; or she names who
  she can and the tool works only from there. Ask her.
- **"If I could have a trial period… then I may be more open."** Trial is how she converts, and it is
  the same answer she gave about tools generally ("I don't even know if they're gonna work"). The site
  already has admin-granted beta access and a Request-beta flow — the existing machinery matches the
  objection, which is a genuine point in favour of the ported design.
- **No work phone at all — "everything's on my private phone."** Worth stating separately from the
  mixing observation: there is no second device to fall back on, so any device-level approach targets
  the phone she also uses for her family.
- **HER OBJECTION IS CLASSIFICATION, NOT SURVEILLANCE — and that is a far more tractable problem.**
  "I talk to my personal friends about real estate, and I'm not wanting them to be confused with actual
  prospects." She is not worried about being read; she is worried about being *wrong* — friends filed
  as leads. Re-read the previous answer in this light: "it all depends on the contact" was about
  accuracy, not about privacy. The soft no stands, but its cause is different from what was assumed,
  and it is fixable.
- **Note why a false positive is expensive for her specifically.** Treating a friend like a prospect is
  exactly the machine-generated, salesy behaviour she said she will not risk — "I don't play with my
  reputation." A misfiled friend is not a tidy-up, it is the failure mode she most fears, aimed at the
  people closest to her.
- **CANDIDATE RESOLUTION OF THE CONSENT HINGE (untested — put it to her).** The software should NOT
  classify friend-vs-prospect; that judgment is exactly the kind she has twice said cannot be reduced
  to a rule. Instead: a first pass surfaces **names and last-contact dates only, no message content**,
  she sorts them — prospect / friend / ignore — and only then does anything read further, per contact,
  with her consent. This satisfies "case by case", never asks for blanket access, and produces the list
  she cannot produce herself. **The volume makes it viable: ~a dozen dormant plus seven active is a few
  minutes of sorting, not an afternoon.** It also matches how she already thinks — she is the one who
  ranks people, and this asks her to do the thing she is good at while the machine does the scrolling
  she will not do.
- **CORRECTION TO THE CANDIDATE RESOLUTION — names and dates alone are NOT sufficient.** Her phone
  holds "a lot of people I've only met once or twice, talking about non-real-estate issues." A bare
  contact list is mostly noise, so the sort she was asked to do is not a sort she can perform. The
  content-free first pass, as proposed, does not work.
- **But she named the filter she does want, and it is a better one than friend-vs-prospect:** "single
  out the ones who I have definitely talked to about real estate goals." **Topic, not relationship.**
  That is close to binary, largely mechanical, and does not require judging seriousness, friendship, or
  intent — all the judgments she has said have no rule. It is the one classification in this entire
  interview that is safe to automate.
- **REVISED SHAPE (still untested): two stages, machine then human.** (1) The software narrows the
  contact list to conversations that actually touched real-estate goals — this requires reading
  content, so the consent question does not disappear, but its *purpose* becomes narrow and
  explainable ("find who you discussed real estate with") rather than open-ended. (2) She sorts the
  much smaller remainder, which will still contain friends, since friends talk to her about real estate
  too. Machine narrows by topic; she judges relationship. Each side does what it is actually good at.
- **The consent conversation is now answerable in concrete terms rather than in the abstract** — a
  specific read, for a stated purpose, over a bounded question. Put the revised shape to her; her
  earlier "I don't know how I feel" was a response to unbounded access, which is not what this is.
- **A CONTENT-FREE VERSION IS NOW FULLY RULED OUT — "the conversation, to be sure."** She cannot
  recognise these people from a name. Recognition requires seeing what was said. So the surface must
  show her enough of the thread to remember who this was, which means content is both read by the
  software and displayed back to her. Every content-free variant proposed above is dead; do not revive
  them.
- **This is not a new privacy problem, though — it is her own correspondence shown back to her.** The
  open question was never whether she may see it; it is what the software may read, retain, and send
  elsewhere. That is now a sharp, answerable design question: read to find, show to her, retain only
  what she keeps. Relevant: `DEC-2026-07-22-data-outside-the-container`,
  `DEC-2026-07-22-hard-delete-erasure`.
- **The minimal product is now specified end to end by her own answers**, with no invented surface:
  read her messages for conversations that touched real-estate goals → show each as a name, a last-
  contact date, and enough of the exchange to recognise them → she sorts prospect / friend / ignore →
  what remains is the list she cannot build herself. She has already said that given the list, she
  knows exactly what to do, and that no further research is possible or wanted.
- **WHAT THE MLS IS, IN HER WORDS:** upload listings, see what is on the market, run searches, and
  produce comparative market analyses. Explicitly **not** a communication tool. Correct an assumption
  that was drifting in: the standing watch and the message archive are two different systems, and
  nothing about the dormant-contact list touches the MLS. `DEC-2026-07-22-mls-data-access` therefore
  blocks less than it appeared to — it gates the standing watch and CMA work, not the first build.
- **One exception she named, and it matters:** the MLS *is* the channel "if you're sending listings or
  CMAs to possible clients." So the market analysis in her lost-listing story — free work, "not until
  next summer", listing went elsewhere — plausibly went out through MLS tooling. That is the one place
  where her outbound contact and the MLS overlap, and it is exactly where the most expensive loss
  happened. Worth understanding before assuming her outbound history lives only on her phone.
- **CONSENT GRANTED, AND SCOPED BY HER — SMS yes, email "maybe", WhatsApp no.** The earlier soft no
  was a response to unbounded access; asked for a specific read with a stated purpose, she agreed.
  This is the single most important unblock in the interview and it validates the narrowing approach
  over asking for everything. **Build for SMS first.** Treat "maybe email" as conditional, not
  granted — confirm before touching it. Do not read WhatsApp.
- **Her reason for excluding WhatsApp is relevance, not privacy** — friends and others who discuss
  real estate with her but "are not possible clients". Consistent with the classification worry she
  raised earlier: she is guarding against false positives, not against being read.
- **FLAG — this sits awkwardly against her earlier WhatsApp answer** and should be checked before the
  exclusion is treated as final. Earlier: WhatsApp is used "if the messages are a little bit more
  intense and videos need to be sent to them that are longer than what a message will allow" — which
  sounds like engaged clients, not friends. Both can be true (friends *and* the occasional serious
  client), but if any real prospects live there, excluding it drops exactly the people the list
  exists to recover. **Raise it gently and later; the exclusion is her call and stands until she
  changes it.** Do not re-litigate a consent decision the same day she made it.
- **Standing caution:** this does NOT mean "build a CRM." `positioning.name_rationale` already
  rejected the name 'Sphere' precisely to avoid being filed as another CRM, and a CRM is the
  category she has already priced out and declined. Whatever this becomes has to earn its place
  against a notebook on day one, with one client, at her current budget.
- **Terminology ambiguity to resolve:** the question asked about her "sphere", but the answer is
  about people close to making an offer. Whether "sphere" here means active buyer clients, cold
  past contacts, or both is not yet established — and it matters, because they rank on completely
  different signals.

## Open threads to pull

- How she decides *who* in the sphere to contact on a given day.
- Whether the MLS-to-buyer matching is manual, saved-search driven, or both.
- What "comfortable enough" means for an expired listing.
