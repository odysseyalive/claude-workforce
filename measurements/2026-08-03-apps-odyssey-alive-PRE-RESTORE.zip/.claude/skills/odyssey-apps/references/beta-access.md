# Beta Access — request flow and manual grant

**Directive (2026-07-22, Francis):** *"Both new modules have a beta button where people can ask
to join, but access has to be given manually."*

**CORRECTED 2026-07-22 — this is NOT a from-scratch build.** odyssey-skul's prose says
`accessRequests` was left deliberately unwired ("DEFERRED… Do NOT build the self-service UI yet").
**The code disagrees.** Verified by reading `nsayka-wawa/convex/access.ts`, a working flow already
exists and ports directly:

| Already implemented | What it does |
|---|---|
| `requestBetaAccess` | Auth-gated mutation: checks `moduleBetaEnabled`, short-circuits if already granted, refuses duplicates, inserts `pending`, schedules the admin notification email |
| `myAccessRequests` | The caller's own rows — powers the CTA state |
| `hasPendingBetaRequest` | Cheap check for the button state |
| `listAccessRequests` | The admin queue |
| `grantAccess` / `revokeAccess` / `grantAccessByEmail` | Entitlement writes |
| `BetaIntentClaimer` (client) | Reads a beta intent stashed in `sessionStorage` by the login form and fires the request once on `/account`. **Solves a real race** — firing immediately after `signIn()` resolves gets dropped as unauthenticated because the Convex Auth header has not propagated. Clears the key first so a refresh or StrictMode double-invoke cannot re-fire; the mutation is idempotent server-side anyway |
| `sendBetaRequestNotification` | The admin email |

**Port it, then add only what is genuinely missing.** The work is a fraction of what this file
originally specified. (Fourth instance of PAT-2026-07-22-port-description-drift — and the most
expensive, because the docs caused an implemented feature to be re-specified as new.)

### What is actually missing

- `note` — the requester's optional "what would you use it for"
- `withdrawn` status + `withdrawRequest`
- `denyReason` (admin-internal)
- `decideAccessRequest` — verify whether an approve/deny mutation exists in `admin.ts`; the queue
  query does, the decision half may not
- The five UI states on the intro page, and the approval/denial emails

### Two behaviours to decide, not inherit silently

**1. A prior decision is permanent.** The existing code returns early on ANY existing row: *"A prior
decision stands; do not resurrect it or re-email."* So a denied user can never request again, ever.
That is defensible for a closed beta and probably wrong for a product — someone denied in month one
may be exactly who you want in month six. If re-requests should be possible, that early return needs
a deliberate change plus the rate limit; otherwise keep it and make the denial copy final rather
than hopeful.

**2. Turnstile is NOT required here, contrary to this file's original spec.** The inherited directive
covers *public* form submissions — signup, contact, newsletter. `requestBetaAccess` is auth-gated,
and the one-row-per-user-per-module guard caps it at a single write per module. Adding Turnstile to
an authenticated, structurally-idempotent mutation buys almost nothing. **The public surface that
DOES need it is signup**, which already has it.

---

## Schema

Extend the ported `accessRequests` table (`convex/schema.ts`). Verified against the source file
2026-07-22, the port already carries `userId`, `moduleSlug`, `status` (pending/approved/denied),
`email`, `requestedAt`, `decidedAt`, `decidedBy`, **and all four indexes**. So this is a smaller
change than it looks — add the `withdrawn` status, `note`, and `denyReason`:

```ts
accessRequests: defineTable({
  userId: v.id("users"),
  moduleSlug: v.string(),
  status: v.union(
    v.literal("pending"),
    v.literal("approved"),
    v.literal("denied"),
    v.literal("withdrawn"),
  ),
  requestedAt: v.number(),
  decidedAt: v.optional(v.number()),
  decidedBy: v.optional(v.id("users")),
  note: v.optional(v.string()),        // the requester's optional "why I want in"
  denyReason: v.optional(v.string()),  // admin-visible; NEVER sent verbatim in email
})
  .index("by_user", ["userId"])
  .index("by_module", ["moduleSlug"])
  .index("by_user_module", ["userId", "moduleSlug"])
  .index("by_status", ["status"]),
```

`note` is user-supplied text: cap it (500 chars), run it through the ported `censor.ts` /
`profanity.ts` path the forum already uses, and never render it as HTML.

**One live request per user per module.** Enforce in the mutation via `by_user_module`, not by
convention: a user with a `pending` row cannot create a second. `denied` does not permanently
bar a re-request, but rate-limit it (§ Abuse) rather than allowing an immediate retry.

---

## Module gating

A module's beta button is governed by **two** existing flags plus one content field — reuse the
`moduleSettings` machinery, do not invent a parallel switch:

| Gate | Source | Meaning |
|---|---|---|
| `accessible` | `moduleSettings` (admin, runtime) | the module is grantable at all — if false, the button does not render AND `requestAccess` rejects. **It must be `true` at launch** even though neither app runs yet (schema.md § D) |
| `betaEnabled` | `moduleSettings` (admin, runtime), defaulted from content | the module is in its beta-request phase. **This field already exists in the source schema** — use it, do not invent a content-only flag |
| `appEnabled` | `moduleSettings` (admin, runtime) | the module's app actually runs at `/modules/<slug>/app` |

Resolution goes through the existing `effectiveModuleFlags` merge in `src/lib/modules.ts` —
runtime override wins over content default, absent falls back. **Server-side defense in depth:**
`requestAccess` re-reads the flags and rejects a request for a non-accessible module, exactly as
`createTicket` re-checks module validity today.

---

## Functions (`convex/access.ts`, extending the ported file)

| Function | Kind | Behavior |
|---|---|---|
| `requestBetaAccess({ moduleSlug, moduleTitle?, note? })` | auth mutation | **EXISTS — port it.** Gates on `moduleBetaEnabled`, short-circuits on already-granted, refuses duplicates, inserts `pending`, schedules the admin email. Add `note` only. No Turnstile (see above) |
| `myAccessRequests()` | auth query | The signed-in user's rows, for the intro page and the account area. |
| `withdrawRequest({ requestId })` | auth mutation | Owner-only; `pending` → `withdrawn`. |
| `pendingAccessRequests({ moduleSlug? })` | admin query | The admin queue, newest first, joined to profile username + email. |
| `decideAccessRequest({ requestId, decision, denyReason? })` | admin mutation | `approved` → **calls the existing `grantAccess`** in the same mutation so the grant and the decision cannot diverge; `denied` → records the reason. Stamps `decidedAt`/`decidedBy`. Fires the requester email. |

`decideAccessRequest` is the only place approval and granting meet. Do not add a separate
"grant from the queue" button that bypasses it — that is how the two records drift apart.

**Revocation:** revoking `moduleAccess` does not rewrite history. The `approved` row stands; the
user simply loses access. If they should be able to ask again, the admin flips the row to
`withdrawn` — never delete rows.

---

## The button — public intro page `/modules/<slug>`

The intro page stays public to everyone (inherited directive). The Request-beta block is the
one element on it that changes by auth and entitlement state. Five states, all of which need a
Playwright test:

| State | What renders |
|---|---|
| Not signed in | "Request beta access" → routes to `/login?next=/modules/<slug>` with a line explaining an account is needed first. Do not put the form behind the button for anonymous users. |
| Signed in, no request | The form: optional "what would you use it for?" textarea + Turnstile + submit. |
| Signed in, `pending` | "You're on the beta list" + requested date + a quiet Withdraw link. Button disabled, not hidden. |
| Signed in, `denied` | Neutral "not enabled for your account right now" + a support link. **Never show `denyReason`.** |
| Signed in, granted | The block is replaced by the primary CTA into `/modules/<slug>/app`. |

Build it with `/frontend-design`. Visually it is the page's primary CTA: blue button, gold
"Beta" badge (badge fill gold, dark text — palette.md § The gold rule). It also appears on the
`/modules` listing card as a secondary "Beta" chip so the state is legible before the click.

---

## Emails (`convex/email.ts`, the ported Nodemailer path)

Three templates, all in Francis's voice via `/my-voice`, all plain and short:

1. **To the admin, on request** — username, email, module, the note, and a deep link to the
   admin queue. Batched is fine; instant is better while volume is low.
2. **To the requester, on approval** — "your access to <Module> is on" + the direct app link.
3. **To the requester, on denial** — neutral, no reason text, with the support-desk link. If
   there is nothing kind to say, say less; never paste `denyReason`.

No email fires on withdrawal. The requester gets **no** confirmation email at request time — the
on-page `pending` state is the receipt, and a confirmation email would double the volume for no
information gain. (If Francis wants one later, it is one template, not a redesign.)

---

## Admin queue (`/admin`, extending the ported desk)

Add a **Beta requests** panel beside the existing user-management and ticket views:

- Default filter `pending`, newest first, with a module filter and a count badge in the nav.
- Each row: username, email, module, requested-at, the note, and **Approve** / **Deny**.
- Approve is one click and grants immediately (via `decideAccessRequest`). Deny opens a small
  reason field that stays internal.
- Cross-links both ways: from a row to that user's row in user management, and from a user's
  detail view to their request history. Francis's directive says the admin interface is fine as
  it is — so this extends the existing patterns, it does not restyle the desk.

---

## Abuse and privacy

- **No Turnstile** — the mutation is auth-gated and structurally idempotent (one row per user per module). The directive covers PUBLIC submissions; signup is the surface that needs it, and has it.
- **Rate limit** re-requests after a denial — reuse the ported `lockout.ts` pattern rather than
  a new mechanism; 1 request per user per module per 30 days is the proposed default (confirm
  with Francis before locking).
- **GDPR:** account erasure deletes that user's `accessRequests` rows outright. They hold no
  content anyone else depends on, so unlike tickets there is no tombstone — delete, don't scrub.
  Wire this into the ported erasure path in `convex/account.ts`; a table added without touching
  erasure is a compliance bug.
- Never disclose whether an email has an account through this flow — the enumeration-resistance
  rule from auth applies here too.

---

## Exit tests (mandatory, `tests/beta/`)

Per the inherited test directive, `beta` mode does not report done until these pass headless at
both viewports:

1. All five intro-page states render correctly (drive each by seeding the underlying row).
2. Request → row created `pending` → admin sees it in the queue.
3. Approve → `moduleAccess.granted` true → the user reaches `/modules/<slug>/app`; the app
   route is still 403 for a user without a grant.
4. Deny → the user sees the neutral state, `denyReason` appears nowhere in the served HTML.
5. Duplicate request is rejected server-side (call the mutation twice).
6. A request for a non-`accessible` module is rejected even when the client is forced to send it.
7. Account erasure removes the rows.

Clean up seeded users and requests after every run (test-suite.md § Cleanup).
