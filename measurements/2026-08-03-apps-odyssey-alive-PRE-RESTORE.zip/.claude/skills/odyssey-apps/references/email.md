# Email — deliverability, inventory, and the auth dependency

**Why this file exists and why it outranks its apparent importance: on this site, the email IS the
password.** Auth is passwordless. A login code that does not arrive is not a missed notification —
it is an account that cannot be entered, with **no fallback path**, because there is no password to
reset. Every other site degrades when email fails. This one stops.

Read before `auth`, `beta`, `support`, and `deploy`.

---

## A. The inventory — what this site sends

| # | Email | Trigger | Criticality | Notes |
|---|---|---|---|---|
| 1 | **Login code** | Any sign-in or sign-up | **AUTH-CRITICAL** | 6 uppercase letters, 10-minute TTL, one-time. Reused while unexpired — a repeat request sends NO second email |
| 2 | Lockout warning | Repeated failed codes | High | Already rate-limited to one per `LOCK_WARNING_WINDOW_MS` (`authShared.ts`) |
| 3 | Beta request → admin | A user requests access | Medium | To Francis. The only one whose failure he notices himself |
| 4 | Beta approval → user | Admin approves | High | Access granted that the user never learns about is access that does not exist |
| 5 | Beta denial → user | Admin denies | Medium | Neutral wording; **never** carries `denyReason` |
| 6 | Ticket reply | Support replies | Medium | Honors `ticketSubscriptions` opt-out |
| 7 | Contact form → admin | Public contact form | Medium | To Francis |
| 8 | Newsletter | Mailchimp | — | **Separate infrastructure entirely** — Mailchimp's sending, reputation, and unsubscribe. Not covered by this file except § F |

1–7 are **transactional**, sent through the app's SMTP path (`convex/email.ts`, Nodemailer, from a
Convex action). They carry no marketing content and need no unsubscribe link — but see § F, because
that boundary is a legal one and easy to blur.

---

## B. The current sender — and the problem with it

**Verified 2026-07-22:** `SMTP_HOST=smtp.mail.me.com` — **iCloud Mail**, with `odysseyalive.com` as
an iCloud+ custom domain. Inherited from odyssey-alive, where it sends a contact form.

That is a **consumer mailbox service being used as a transactional sender**, and the mismatch is
material:

- **A hard ceiling of ~1,000 messages/day**, which Apple does not raise. Fine now; a wall later,
  and the wall arrives precisely when the site is succeeding.
- **Automated and bulk sending is outside its intended use.** Apple's terms prohibit unsolicited
  bulk mail through iCloud servers, and the service is documented as designed for personal use.
- **No feedback loop.** No delivery webhooks, no bounce notifications, no complaint reporting, no
  reputation dashboard. **You cannot know whether a login code was delivered** — only that the SMTP
  handoff did not throw.
- **Bursty automated traffic is the throttling profile.** A contact form sends one message when a
  human clicks. Login codes fire whenever anyone signs in, and every retry adds another.

**None of this is urgent at beta volume.** Access is granted by hand, so traffic is bounded by a
number Francis chose. It becomes urgent at exactly the moment the site works.

### The in-house directive does NOT settle this — read it carefully

Email deliverability reputation is one of the categories the self-hosting directive names as
**structurally unavailable in-house** (SKILL.md § Directive amendment). Running a mail server on
the VPS would be strictly worse: VPS IP ranges are widely blocklisted, and auth mail landing in
spam is the same outcome as not sending it.

So the real question is not in-house vs third party — **iCloud is already a third party.** It is
whether the third party is fit for the job. Swapping a consumer mailbox for a transactional sender
adds no new *category* of dependency; it changes which vendor holds an existing one. The directive
still applies in two ways: **isolate it behind an interface we control** (Nodemailer already
provides that — the swap is config, not a rewrite), and prefer providers whose free tier covers
this volume so cost stays flat.

**Recommendation: keep iCloud through beta, and treat "transactional email provider" as a planned
migration rather than a surprise.** Revisit when any of these is true: approaching a few hundred
messages/day, any evidence of throttling, or the first report of a code not arriving.

---

## C. Authentication records — and the subdomain trap

SPF, DKIM, and DMARC are not optional. Major providers now reject or spam-folder unauthenticated
mail as a matter of routine.

**The trap: SPF and DKIM are per-domain, and a subdomain does not inherit them.** iCloud+ configures
these for `odysseyalive.com` when the custom domain is set up. It does **not** cover
`apps.odysseyalive.com`, and iCloud may not permit a subdomain alias as a From address at all.

**DECISION: send transactional mail from `@odysseyalive.com`, not `@apps.odysseyalive.com`.**

- The authentication records already exist there and are already working.
- The sending identity is already verified with iCloud.
- The domain has existing sending history; a fresh subdomain starts with no reputation at all.
- It matches the **quiet parent** brand position — the mail is from Odyssey Alive, mentioning the
  product, exactly as the footer does.

The cost is honest and worth stating: **reputation is shared across properties.** A deliverability
problem caused by one site affects the others. At this volume, borrowing established reputation
beats isolating on a cold subdomain — but if sending ever grows enough to justify isolation, a
dedicated subdomain with its own SPF/DKIM/DMARC is the move, and it is a migration, not a toggle.

**Before launch, verify — do not assume:** SPF and DKIM pass for the actual From address, and DMARC
exists with at least `p=none` plus a reporting address so failures are visible rather than silent.

---

## D. Sender identity and message shape

- **From:** a real, verified iCloud address on `odysseyalive.com`, with a display name naming the
  product ("Odyssey Apps").
- **Reply-To:** `CONTACT_EMAIL` — a real inbox, as the port already does. Avoid a `noreply@`
  identity: it hurts deliverability, and it tells a confused user their reply went nowhere.
- **The login-code email should be plain and boring.** Minimal HTML, one purpose, no tracking
  pixels, no marketing styling, no link shorteners, few or no links. **A code email dressed as
  marketing looks like phishing to a filter AND to a person** — and this is the one message that
  must arrive.
- Keep the code **in the body text**, not only in an image or a button, so it survives image
  blocking and plain-text rendering.
- The existing "check your spam folder" line on the code-entry screen stays. Add a **resend**
  affordance with its own rate limit — but note the reuse rule: while an unexpired code exists the
  system deliberately sends no second email, so "resend" must not silently do nothing. Say what it
  did.

---

## E. Knowing whether it worked — the silent-failure problem

**An SMTP handoff that does not throw is not a delivery.** This is the gap that makes email failures
invisible (observability.md § C).

**Log every send attempt** to an `emailLog` table: type, recipient hash or user id (**never the
plaintext address** — that is PII in a log), status (`attempted` / `sent` / `failed`), the provider
error if any, `correlationId`, timestamp. Surface it in the admin desk. This is in-house, inside the
backup, and reached by erasure.

**Surface failures synchronously where the user is present.** If the SMTP send throws while a user
is waiting on the code screen, tell them *then* — "we could not send the code, try again or contact
support" — rather than showing "check your email" for a message that was never accepted. A visible
error costs one confused user; silence costs the account.

**The invariant checks** (observability.md § C) cover the rest: attempted-vs-sent gaps, and any
login-code request with no corresponding send.

**Bounce handling is the honest gap with iCloud.** There is no feedback loop, so a hard-bouncing
address will be retried forever and silently. Mitigation while on iCloud: watch the Reply-To inbox
for bounce messages by hand. A real feedback loop is one of the strongest arguments for the § B
migration.

---

## F. Transactional vs marketing — a legal boundary, not a style one

Emails 1–7 are transactional: they respond to something the user did, and need no unsubscribe link.
The newsletter is marketing and lives entirely in Mailchimp with its own consent and unsubscribe.

**Do not blur them.** The moment a transactional email carries promotional content — "here's your
login code, and by the way check out our new module" — it becomes marketing, and it needs consent
and an unsubscribe it does not have. That is a compliance problem *and* a deliverability one, since
recipients mark it as spam.

The beta-approval email (#4) is the one most likely to drift, because it is genuinely good news and
the temptation to add a pitch is real. Keep it to: what was granted, and where to go.

---

## G. Testing and the development bypass

**`SITE_ENV=development` skips SMTP entirely** and returns the code in plaintext for headless tests
(`requestLoginCode`). That is what makes the auth suite deterministic — and it is a **production
catastrophe if it leaks**: no real emails, one-time-use disabled, codes exposed.

The port already gates this ("Live must NOT set `SITE_ENV=development`"). **`verify` should assert
it explicitly against the live backend** rather than trusting the deploy, because the failure is
silent and total.

**Before launch, send real mail to real inboxes** — Gmail, Outlook, and one more — and confirm each
arrives, lands in the inbox rather than spam, and passes SPF/DKIM/DMARC (visible in the receiving
provider's "show original"). A one-time check, not a project, and it is the only way to learn what
strangers will actually experience.

---

## G-bis. Recovery is DELEGATED to the email provider (decided 2026-07-22)

> **"Email lives on a different platform than my website. I don't have any control over Apple, so
> that is a manual process… Email is normally like that anyway — you're always going through a
> service and having to deal with that service for GDPR compliance. Because email is a third-party
> process, we're not worried about recovery either. That's going to have to be offloaded to the
> company that we're purchasing our email account through."**

*— Francis Meetze, session "site-development"*

**This site builds NO account-recovery mechanism.** No recovery codes, no secondary email, no
admin-mediated identity check. It is a deliberate delegation, and it is coherent: with passwordless
auth, **recovering the mailbox IS recovering the account.** Whoever controls the inbox can request a
code and sign in. Building a parallel recovery path would add a second way into an account —
strictly more attack surface, and only as strong as whatever identity check backed it.

**Support's answer, when asked:** recover your email account with your email provider, then sign in
normally. Write that into the support macros so it is a stated policy, not an improvisation under
pressure.

### The one edge case worth knowing about — and a free mitigation

The delegation holds whenever the user can regain their mailbox. It **fails when the address itself
is gone or was never theirs** — and that scenario is unusually common in this exact industry:

An agent signs up as `agent@theirbrokerage.com`. They move brokerages. The brokerage deletes the
mailbox. **No email provider can restore an address a third party owns and revoked**, so the account
and everything in it becomes unreachable — and unlike a lost password, there is nothing to reset.

**The mitigation is copy, not engineering, and it costs nothing:** at signup, encourage a personal
address over a work one — one line near the email field, in the spirit of "use an address you will
keep if you change firms." Real-estate agents change brokerages routinely, and they know it, so the
advice reads as considerate rather than officious.

Nothing to build. Worth a sentence on the signup form and a line in the support macros.

### GDPR — scoped correctly

Mail in transit and in mailboxes is the email provider's surface as processor; that is their
compliance responsibility, and it is normal for every site that sends email. **Nothing in this
project needs to reach it.**

What DOES belong to this project is the `emailLog` table in our own database (§ E). That is why it
stores a `userId` or a recipient **hash**, never a plaintext address — PII in a log is PII we
control, inside our erasure and backup boundaries. Cheap to do correctly from the start, awkward to
unpick later.

## H. Open decisions

- **When to migrate off iCloud** (§ B). Proposed trigger: a few hundred messages/day, any sign of
  throttling, or the first report of a code not arriving.
- **Which provider**, when that happens — chosen for a free tier that covers this volume and for
  delivery/bounce webhooks, since the missing feedback loop is the real reason to move.
- **Whether a dedicated sending subdomain is ever worth the reputation reset** (§ C).
- **Whether email change is ever supported.** Not today — the signup address is permanent, and its
  absence prevents a typo'd change from becoming an instant permanent lockout. If it is ever built
  it is an AUTH-critical flow: send a code to the NEW address, verify it, and only then switch;
  notify the old address too, so a hijacked session cannot silently move an account.

Sources for § B (search-derived 2026-07-22 — verify against Apple's current terms before relying on
the numbers): [Apple — mailbox size and message sending limits in
iCloud](https://support.apple.com/en-us/102198) ·
[Mailtrap — iCloud SMTP](https://mailtrap.io/blog/icloud-smtp/) ·
[UniOne — iCloud SMTP configuration](https://unione.io/en/blog/icloud-smtp-server-configuration)
