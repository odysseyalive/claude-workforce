# Observability — errors, silent failures, and knowing before your users do

**The scenario this exists for:** something breaks at 2am for a stranger who signed up an hour
ago. Do you find out — and can you tell what happened?

Read before `deploy`, and whenever a new failure path is added.

---

## A. Three layers, three destinations, no correlation

This stack scatters failures across three places that do not talk to each other:

| Layer | Fails as | Lands in |
|---|---|---|
| **Browser** | React render errors, hydration mismatches, unhandled rejections, failed fetches | Nowhere. The user sees a broken page; you see nothing |
| **Next.js server** | Route handler + server action throws, SSR errors | The Next container's stdout |
| **Convex functions** | Query / mutation / action throws, schema violations, timeouts | The Convex backend logs + its dashboard (`:6792` locally) |

**The problem is not that logs are missing — it is that nothing joins them.** A user says "it
didn't work." You have three unrelated log streams and no shared identifier to line them up.

**So: a correlation id, generated once per request and threaded through.** Attach it to the client
call, log it server-side, pass it into Convex calls, and surface it in the user-facing error UI
("something went wrong — reference `a1b2c3`"). It costs almost nothing at build time and converts
an archaeology session into a single grep. A support ticket quoting that reference is worth ten
describing the symptom.

---

## B. The reporter must not depend on the thing that might be broken

**Do not put error reporting solely inside Convex.** An error log stored in Convex records nothing
when Convex is the thing that is down — which is precisely the outage you most need to know about.
Same logic for the browser: if the JS bundle fails to load, the app cannot report its own failure.

That forces a split by LAYER, which survives the in-house decision in § H:

- **Domain-level failures** (an email send failed, an OpenRouter call errored, a beta approval did
  not complete) → an **`errorLog` table in Convex**, surfaced in the admin desk. These are
  application events, they belong where the admin already looks, and they are covered by the backup
  (backups.md § A-bis) and reached by erasure.
- **Infrastructure-level failures** (the box is down, Convex unreachable, the container crashed,
  the bundle 500s) → **something outside the failing system**. Per the self-hosting directive that
  is NOT a subscription and NOT a new container: it is jstack's existing container logs plus a
  cheap external heartbeat against a health endpoint (§ H).

Both layers, by different means. The split is the design; § H decides the mechanism.

---

## C. The real risk here is not crashes — it is SILENT failures

Error monitoring catches things that throw. **This application's worst failures do not throw**, and
that is the part worth designing for deliberately:

| Silent failure | What the user experiences | What you see by default |
|---|---|---|
| Login-code email not sent | "Check your email" — nothing arrives. They cannot get in, and never complain | Nothing |
| Beta approval email not sent | Granted access they never learn about | Nothing |
| Usage row not written | Metering under-reports; pricing built on it is wrong | Nothing |
| OpenRouter stops reporting cost | `costSource: estimated` everywhere; cost data quietly degrades | Nothing |
| A module's AI job fails partway | A half-finished result that looks finished | Nothing |

**None of these produce an error.** They produce an absence, and absence is invisible to every
error monitor ever built.

**So pair error capture with a small set of INVARIANT CHECKS**, surfaced in the admin desk. Not a
monitoring platform — a handful of questions asked on a schedule:

- Emails attempted vs emails confirmed sent, last 24h. A widening gap is SMTP failing.
- Any login-code request in the last hour with no corresponding send.
- Share of `aiUsage` rows with `costSource: "estimated"`. Should be near zero; a spike means
  OpenRouter's reporting changed or broke.
- AI jobs started vs completed (by `runId`). A persistent gap is jobs dying midway.
- Beta requests `pending` older than 7 days — not a fault, but the queue being ignored is a
  failure of the same kind: a user waiting on nothing.

Keep the list SHORT. Five checks that get read beat fifty that get ignored — and each one exists
because its failure mode is invisible, not because the metric is interesting.

---

## D. PII — error reports are a data-protection surface

Stack traces, breadcrumbs, and request captures routinely sweep up emails, form values, session
tokens, and document contents. On a GDPR-compliant site that is not a detail:

- **Scrub before send, from day one.** Deny-list request bodies, headers, and cookies by default;
  allow-list what is genuinely needed. Retrofitting scrubbing means the unscrubbed data is already
  sitting in someone else's system.
- **Never send document contents or model inputs/outputs.** Especially `sign-me` — those are the
  user's clients' agreements, not yours to forward to a third party.
- **An external error service would be a data processor** — a privacy-policy entry, likely a DPA,
  and a store erasure cannot reach. **This is one of the concrete reasons the in-house decision in
  § H is the right one**, not merely the cheaper one. Keeping errors in Convex keeps them inside
  the erasure and backup boundaries that already work.
- **User identifiers in reports:** an internal user id is far better than an email. It is enough to
  correlate, and it is not personal data on its own.
- **Erasure does not reach a third-party error store.** Another argument for keeping domain-level
  errors in Convex, where erasure and backups already work.

---

## E. Source maps — otherwise every report is unreadable

**Applies to the in-house handler too** (§ H) — anything that captures a client stack has this
problem. The production build is Next.js standalone in Docker, so client stack traces arrive
**minified** unless source maps are retained and resolvable at build time. Without them a report reads
`t is not a function at chunk-4f2.js:1:88231`, which is worse than useless — it looks like
information.

Wire this into the Docker build, and tag every report with a **release identifier** (a commit sha)
so a trace maps to the exact bundle that produced it. Resolving source maps without tagging the
release gets you the wrong symbols with total confidence — which is worse than no symbols. Keep the
maps server-side; do not serve them publicly.

---

## F. Alerting discipline for one person

The failure mode of alerting is not missing an alert — it is **being alerted so often you stop
reading**. For a solo operator:

- Alert on **new** error types and on invariant-check breaches (§ C). Not on every occurrence.
- Rate-limit per error type. One email for a hundred instances of the same failure.
- Ambient noise — third-party 4xx, beacons, transient aborts — is **recorded, never alerted**.
  Exactly the two-layer discipline the test suite already uses (test-suite.md § Two error layers).
- Route alerts somewhere they will actually be seen. An alert nobody reads is a log entry with
  extra steps.

---

## G. What already exists — do not rebuild it

- **The Convex dashboard** (`:6792` locally) shows function logs and errors. For development that
  is often enough on its own.
- **jstack** ships log rotation (`scripts/core/setup_log_rotation.sh`) and troubleshooting docs.
  Container logs are already handled; do not invent a parallel scheme.
- **`analytics`** (Cloudflare RUM, imported skill) covers traffic, not errors. Different question,
  and cookieless — which keeps it out of consent-banner territory.

---

## H. The reporter — DECIDED: in-house (2026-07-22)

The self-hosting directive (SKILL.md § Directive amendment) resolves this. Sentry cloud is out: it
is a subscription, and a processor holding error data that erasure cannot reach.

**What ships: the Convex `errorLog` (§ B) plus the invariant checks (§ C). No new service, no new
container.**

**And notably NOT a self-hosted GlitchTip** — at least not first. Both of Francis's stated reasons
argue against it, not just against the cloud option: *"easier to maintain"* and *"costs relatively
stable."* Running another container means another thing to patch, back up, restore, and be woken by.
Self-hosting a service is the THIRD preference in the directive's ladder, behind "don't need it"
and "build it into what we already run."

So the ladder resolves here as: **build it into what we already run.** Convex is already deployed,
already backed up, already the place the admin logs in.

### Living with the § B limitation honestly

§ B is still true: an error log inside Convex records nothing when Convex is what broke. In-house
does not repeal that — it means covering the gap with things already running rather than a new
dependency:

- **Container-level failures are visible in Docker/jstack logs**, which already have rotation
  configured (`scripts/core/setup_log_rotation.sh`). That is where a crashed Next container or an
  unreachable Convex shows up.
- **An external heartbeat is the one honest gap.** If the whole box is down, nothing inside it can
  tell you. The cheapest in-house answer is a check that runs somewhere else — a cron on another
  machine Francis controls hitting a health endpoint, alerting by email on failure. That is a few
  lines, not a service, and it keeps the directive intact.
- **Client-side errors** cannot reach Convex if the bundle failed to load. Accept the blind spot
  and narrow it: a small inline error handler in the document head that reports to a same-origin
  endpoint catches most client errors without shipping an SDK. It will not catch a total asset
  failure — nothing self-hosted will.

**Revisit only if** the blind spots demonstrably cost real debugging time. Reconsidering then is a
data-driven exception to the directive, not a violation of it.

### A health endpoint, since several things want one

Expose a small unauthenticated `/api/health` returning build id, Convex reachability, and a
timestamp. It backs the external heartbeat above, gives the deploy an empirical check, and is the
first thing to hit when something looks wrong. Keep it boring and never let it leak configuration.
