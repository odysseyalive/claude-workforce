# Parity with odyssey-alive

The Odyssey Apps site was templated from odyssey-alive (`/home/francis/lab/odyssey-alive`)
and is expected to retain feature parity on cross-cutting infrastructure: security gates,
SEO/metadata, OG/social cards, newsletter mechanics, sitemap/robots. This file is the
canonical inventory of what must match and what is intentionally diverged.

Use it when answering "is X locked down like odyssey-alive?" — read this first instead of
spawning an audit agent. When odyssey-alive adopts a new invariant, port it here and add the
matching `/odyssey-apps debug <route>` enforcement.

## Reference paths

- odyssey-alive repo: `/home/francis/lab/odyssey-alive` (Next.js 16 + Velite/MDX)
- Odyssey Apps Next app: repo root (`src/app/...`), this monorepo
- Site URL constant: `src/lib/schema.ts` → `SITE_URL = "https://apps.odysseyalive.com"`

## Invariants — must match

### Newsletter subscribe lockdown — `debug newsletter`
- Honeypot field, cookie-based timing gate (>=3s), Mailchimp `status: "pending"` (double
  opt-in), server-side Zod validation. Turnstile gates **unsubscribe**, not subscribe (matches
  odyssey-alive: subscribe is friction-light, unsubscribe is the abuse surface).
- Reference: `/home/francis/lab/odyssey-alive/src/lib/actions/newsletter.ts:7-84` (subscribe)
  and `:165-185` (unsubscribe).
- Mirror: `src/lib/actions/newsletter.ts` — same shape, audience `b7792f6c03`.

### Root metadata (SEO + social) — `debug og-parity` step 1
- `metadataBase: new URL(SITE_URL)`, full `openGraph` (type/locale/url/siteName/title/
  description/images[1200x630]), full `twitter` (`summary_large_image` + site + creator
  handles), `robots` block, `alternates.canonical`.
- Reference: `/home/francis/lab/odyssey-alive/src/app/layout.tsx:27-95`.
- Mirror: `src/app/layout.tsx:31-92`. Uses `SITE_URL` constant (better externalization than
  the reference's hardcode).

### Dynamic OG image endpoint — `debug og-parity` step 2
- Edge-runtime image generator at `src/app/api/og/route.tsx`, query params
  `?title=&description=&eyebrow=`, 1200x630 PNG, themed dark-blue PNW palette.
- Reference: `/home/francis/lab/odyssey-alive/src/app/api/og/route.tsx:1-134` (uses
  `@vercel/og`; cream + coral palette, "Odyssey Alive" / `odysseyalive.com` footer).
- Mirror: `src/app/api/og/route.tsx` — uses `next/og` (Next 16 built-in, no extra dep),
  dark-blue PNW palette (`#0E1A29` → `#142233` → `#1E3A5F` gradient, cream-header title,
  accent-light `#8FB8DD`), "Learn a world by living in it" / `apps.odysseyalive.com` footer.

### Per-page dynamic metadata — `debug og-parity` step 3
- Detail pages (`/focus/[slug]` on odyssey-alive; `/modules/[slug]` on Odyssey Apps) export
  `generateMetadata` returning the FULL Metadata shape, not just `{title, description}`. OG
  image fallback chain: author override → dynamic `/api/og` endpoint. Set
  `alternates.canonical`.
- Reference: `/home/francis/lab/odyssey-alive/src/app/(editorial)/focus/[slug]/page.tsx:35-83`
  — chain: `post.socialImage` → pre-generated `/images/social/[slug]-social.jpg` → dynamic
  `/api/og?title=…&description=…`.
- Mirror: `src/app/(marketing)/modules/[slug]/page.tsx:37-83` — chain: `mod.socialImage` →
  dynamic `/api/og?title=…&description=…&eyebrow=…`. No pre-generated stage (no build-time
  social-image generation today).

### Velite schema `socialImage` field — `debug og-parity` step 4
- `modules` collection in `velite.config.ts` exposes optional `socialImage: s.string()`. Lets
  a module author override the OG image with a static asset path under `/public`. Optional;
  the dynamic /api/og fallback covers modules that omit it.

### Captcha on public form POSTs — `debug support`, `debug auth`
- Cloudflare Turnstile gates every public form POST: account signup, login code request,
  contact form, newsletter unsubscribe, **support ticket create + reply** (community AND
  staff). Honeypot pairs with Turnstile on the support flow.
- Server verify: `src/lib/actions/turnstile.ts` (`verifyTurnstileToken`). Dev bypass
  (`NEXT_PUBLIC_SITE_ENV === "development"` returns `true`) so headless tests stay
  deterministic; in live, real `siteverify` is always called.
- Support-flow gates:
  - Ticket create: `src/components/support/ModuleForum.tsx:78-84` (verify) + `:202-212`
    (widget) + `:108-124` (honeypot).
  - Reply: `src/components/support/TicketThread.tsx:117-124` (verify) + `:326-336` (widget).
- Admin paths under `/account` are exempt — already gated by signed-in admin session.

## Invariants — intentionally diverged

### Sitemap content model
- odyssey-alive's `app/sitemap.ts` crawls published posts + projects + tags (it has a blog).
- Odyssey Apps's `app/sitemap.ts` is static pages + published modules. There is no blog or
  tag archive to crawl. Field Notes links **out** to `odysseyalive.com/focus`.
- This is NOT a parity gap. Do not re-import the article-crawling sitemap.

### robots.txt disallow list
- odyssey-alive blocks `/api/`, `/_next/`, `/lore-keepers/`.
- Odyssey Apps ALSO blocks `/account/`, `/admin/`, `/login/` — appropriate for an
  account-gated app. Stricter on purpose.

### Newsletter audience
- Same Mailchimp account, different audience ID (`b7792f6c03` for Odyssey Apps; odyssey-alive
  has its own). Same SMTP/Turnstile/Cloudflare creds.

### OG image palette
- odyssey-alive: cream `#FAF9F5` BG + coral accent `#FFA07A`.
- Odyssey Apps: dark-blue PNW (`#0E1A29` → `#142233` → `#1E3A5F` gradient) + accent-light
  `#8FB8DD`. Matches the dark hero band aesthetic on home/module pages.

### Per-page social image pre-generation
- odyssey-alive pre-generates `/images/social/[slug]-social.jpg` at build time. Odyssey Apps
  does not (yet). The fallback chain `socialImage → /api/og` is sufficient until module
  detail pages need richer pre-rendered social cards. Revisit when the catalog grows.

## When to re-audit

- Adding a new public form route → confirm Turnstile + honeypot + verify wiring.
- Adding a new dynamic route under `/modules` or any new top-level section → confirm
  `generateMetadata` returns the full Metadata shape with OG/Twitter/canonical + image
  fallback chain.
- Pulling a feature from a future odyssey-alive change → add the invariant here and a
  matching enforcement step in `debug og-parity` or a new debug route.
