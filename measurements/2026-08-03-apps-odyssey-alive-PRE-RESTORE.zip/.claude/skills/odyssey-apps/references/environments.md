# Environments (live vs development)

The site runs in one of two environments, selected by a single env flag. Modes that resolve
URLs, backends, or module-serving endpoints MUST read it and use the matching values. Never use
a temporary/dev URL in a live build, or a live backend in a dev run.

## Port allocation — this site's block, and why it is not the port source's

**One jstack box hosts several sites.** `apps.odysseyalive.com` will sit alongside
`skul.odysseyalive.com` and whatever else lives under `jstack/sites/`, sharing one host network
namespace. Every published port must therefore be unique **across sites**, not just within this one.

The port source (nsayka-wawa / skul) binds `127.0.0.1:3040`, `:3210`, `:3211`, `:6791`. Carrying
those over verbatim — which the port did for everything except the web port — produces two failures:

1. **The obvious one:** the second stack refuses to start, "port is already allocated."
2. **The dangerous one:** `verify` asserts "exactly ONE authoritative Convex backend on :3210," and
   the Convex CLI (`npx convex env set`, `convex deploy`, `convex run`) targets
   `CONVEX_SELF_HOSTED_URL`. On a shared box **:3210 is skul's database.** Every one of those
   commands would succeed against the wrong site's backend while reporting success — deploying
   functions to, and reading data from, a database that belongs to another product.

**This site's block (reallocated 2026-07-22):**

| Service | Host binding | Port source used |
|---|---|---|
| Next.js | `127.0.0.1:3050` | 3040 |
| Convex backend | `127.0.0.1:3220` | 3210 |
| Convex site origin | `127.0.0.1:3221` | 3211 |
| Convex dashboard | `127.0.0.1:6792` | 6791 |

**All bindings stay on the host loopback** (`127.0.0.1:`), never `0.0.0.0:`. jstack's nginx is the
only thing that should be publicly reachable; a Convex backend or dashboard exposed on a public
interface is an unauthenticated door into the database.

**Before claiming any new port, check the other sites** — `jstack/sites/*/docker-compose.yml` and
`docker-compose.override.yml` — per jstack's own guidance (`jstack/docs/ports.md`). Adding a
third site later means doing this again; the block above is this site's claim, not a global
convention.

## The flag

`.env` carries:

```
NEXT_PUBLIC_SITE_ENV=development   # or: live
```

It is `NEXT_PUBLIC_` because the browser needs it to choose the right module-serving URL and the
right public Convex URL. A non-public mirror (`SITE_ENV`) may be read server-side if convenient,
but the public value is the source of truth for client code.

## What resolves per environment

| Concern | development | live |
|---|---|---|
| Site base URL | `https://dev-apps.odysseyalive.com` (hosts-file mirror, see below) | `https://apps.odysseyalive.com` |
| Convex (`NEXT_PUBLIC_CONVEX_URL`) | local self-hosted, proxied under the dev hostname so public-origin + WSS behavior matches live | public backend origin (HTTPS) |
| `CONVEX_CLOUD_ORIGIN` / `CONVEX_SITE_ORIGIN` | the dev hostname's HTTPS origins (mirrors the live shape) | public HTTPS (research-log.md s2) |
| Module app URL | `/modules/<slug>/app` under the dev mirror | `/modules/<slug>/app` on the live host |
| Mailchimp / Turnstile / SMTP | same creds as odyssey-alive, **including its audience ID** — this is the same newsletter, not a separate list (port-inventory.md § C.4) | same |

Resolve these from env, not hardcoded. A small `src/lib/env.ts` helper that reads
`NEXT_PUBLIC_SITE_ENV` and returns the resolved config is the single place to centralize this.

## Local mirror: dev-apps.odysseyalive.com

Development does not run on bare `localhost`. It runs on a hostname that mirrors live, so dev
faithfully simulates the live server. Setup:

1. **Hosts file:** add `127.0.0.1  dev-apps.odysseyalive.com` to `/etc/hosts`.
2. **Local nginx proxy:** run a local nginx whose config MIRRORS the proxy vhost jstack generates
   for live (proxy_pass + `proxy_http_version 1.1` + Upgrade/Connection WS headers + X-Forwarded-*;
   see deploy.md), pointed at `dev-apps.odysseyalive.com`, forwarding to the local Next.js port and
   to the local Convex backend (a second vhost, e.g. `convex.dev-apps.odysseyalive.com`). jstack
   is NOT used in dev; this is your own local proxy that rehearses the production proxy shape
   (including WS forwarding for Convex realtime) before live.
3. **Local TLS:** issue a locally-trusted cert for `dev-apps.odysseyalive.com` (mkcert is the
   simplest) so dev runs over HTTPS exactly like live. This matters for secure cookies,
   Convex WSS, and Turnstile behaving as they will in production.
4. **Full stack local:** Next.js + self-hosted Convex both run locally behind that proxy. Set
   `NEXT_PUBLIC_SITE_ENV=development` and point the Convex public origins at the dev hostname.
   Convex data is **bind-mounted** to a local `./data/convex` dir (gitignored), outside the
   image, exactly as live bind-mounts under the jstack site dir (backend.md § Database
   persistence). Dev and live use the same compose; only the data path and origins differ.

Why a hostname instead of localhost: it exercises the real HTTPS + public-origin conditions (the
Convex "browser-reachable vs internal URL" gotcha, research-log.md s2) and the secure-cookie and
WSS behavior that `localhost:<port>` hides. The dev mirror is the faithful rehearsal of live;
`pnpm serve` on `localhost:3050` is the fast path for ordinary iteration.

## Module serving URL

Modules here are **first-party route trees in this repo**, so there is no external artifact to
serve and no second origin to reason about. Each module in [modules.json](modules.json) carries a
`serving` block with the dev-mirror and live paths, both of the shape
`/modules/<slug>/app`.

The same-origin constraint that governed odyssey-skul is **gone** — it existed only because the
embedded Glulx interpreter's save hook required it. The path shape is kept anyway, for URL
stability and because it reads correctly.

## How each mode reacts

- **serve:** runs `development` on the dev mirror (`dev-apps.odysseyalive.com`, behind the local
  nginx proxy + TLS) when simulating live; or a lighter bare `pnpm serve` on `localhost:3050` for
  ordinary iteration.
- **test:** reads `NEXT_PUBLIC_SITE_ENV` and targets the matching base URL and module URL.
  Playwright specs assert against the resolved URL, not a hardcoded one. Run the suite in
  `development` locally; a `live` smoke run targets the production URL.
- **debug:** every route resolves its target from env first (`debug deploy`, `debug convex`,
  `debug module`, `debug beta`, `debug newsletter` all grab the correct env's URL/backend). Report which env is
  active at the top of any debug run so findings are not misread across environments.
- **deploy:** produces the `live` configuration (public Convex origins, `serving.live` for the
  module, `NEXT_PUBLIC_SITE_ENV=live` in the VPS `.env`).

State the active environment before acting in any of these modes.
