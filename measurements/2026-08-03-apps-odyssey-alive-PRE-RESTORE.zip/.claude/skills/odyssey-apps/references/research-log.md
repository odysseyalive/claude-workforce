# Research Log

Citation-grounded findings gathered during the build. Persisted here so future sessions do
not re-run the same lookups. Each section notes confidence and the items that still need an
empirical test (a real compile/run), per the project rule that "compatibility verdicts" from
doc review are not trusted until verified at runtime.

Gathered 2026-05-24 via two research agents (primary sources: official docs + GitHub repos).

---

## 1. (Removed) Parchment / GlkOte save interception

odyssey-skul's §1 researched intercepting Glulx saves from an embedded interpreter. **It has no
analogue here** and is deliberately not carried: modules on this site are first-party Next.js
route trees whose state is ordinary typed Convex data. If you find yourself reaching for this
section, you have mistaken a module for an embedded artifact — see connectors.md.

The original research remains in
`/home/francis/lab/nsayka-wawa/.claude/skills/odyssey-skul/references/research-log.md` if it is
ever needed.

## 2. Self-hosted Convex (for `convex`)

Three services (from `get-convex/convex-backend` `self-hosted/`):

- **Backend:** `ghcr.io/get-convex/convex-backend` - API on `:3210`, HTTP-actions/site proxy
  on `:3211`. Pin a tag (compose ships `:latest` with a comment to switch to `:${REV}`).
- **Dashboard:** `ghcr.io/get-convex/convex-dashboard` on `:6791`. Full admin access - firewall
  or proxy behind auth.
- **Data volume:** `data:/convex/data` (default SQLite). Survives `down`/`up`, NOT `down -v`.
  Bind-mount under the jstack site dir or migrate to Postgres via `POSTGRES_URL`.

**CLI targets self-hosted** by setting (exact names, confirmed):
```sh
CONVEX_SELF_HOSTED_URL='http://127.0.0.1:3210'
CONVEX_SELF_HOSTED_ADMIN_KEY='<from: docker compose exec backend ./generate_admin_key.sh>'
```
These REPLACE the cloud `CONVEX_DEPLOY_KEY`. Then `npx convex dev` / `npx convex deploy` push
schema + functions as usual.

**Production origins (default to localhost - MUST override behind a proxy):**
```
CONVEX_CLOUD_ORIGIN=https://<public-backend-url>
CONVEX_SITE_ORIGIN=https://<public-backend-url>/http
```
If TLS terminates at nginx and the backend speaks HTTP internally, likely need
`DO_NOT_REQUIRE_SSL` (documented compose env var) - confirm against
`self-hosted/advanced/hosting_on_own_infra.md` with a real run.

**Schema/functions:** `defineSchema`/`defineTable` + `v.*` validators in `convex/schema.ts`;
`query`/`mutation`/`action` from `./_generated/server`, called via the generated `api` object.
`undefined` is not a valid value (use `v.null()`).

**Next.js wiring:** client - `ConvexReactClient` + `ConvexProvider` with
`NEXT_PUBLIC_CONVEX_URL`; server - `preloadQuery`/`fetchQuery`/`fetchMutation` from
`convex/nextjs`.

**#1 gotcha (single-VPS compose):** `NEXT_PUBLIC_CONVEX_URL` is baked into the browser bundle,
so it must be the backend's **public** origin, never a docker-internal name like
`http://backend:3210`. The realtime client uses WebSockets, so the reverse proxy must forward
WS upgrades to `:3210`. Server-side calls MAY use the internal URL via the `url` option to
`fetchQuery`.

**Confidence:** High on images/ports/env names. **Empirical test required:** the exact
`DO_NOT_REQUIRE_SSL` + `CONVEX_SITE_ORIGIN` "/http" routing under one hostname behind nginx.
There is no official "Next.js + Convex single docker-compose" reference; we assemble it.

Sources: github.com/get-convex/convex-backend `self-hosted/README.md` +
`self-hosted/docker/docker-compose.yml`, docs.convex.dev/self-hosting,
stack.convex.dev/self-hosted-develop-and-deploy, docs.convex.dev/client/react/nextjs/server-rendering.

---

## 3. Convex auth (for `auth`) - DECIDED: passwordless email-code (2026-05-25)

**Stack: Convex Auth (`@convex-dev/auth`), self-hosted, NO password.** Still inside the
deployment, no third-party SaaS (honors "open-source Convex locally"). The 2026-05-24 password
provider lock is SUPERSEDED. Clerk stays out.

**The flow (decided by Francis 2026-05-25):**
- Sign-up requires a **unique username AND a unique email** (both unique among *active* accounts;
  deleting an account frees both - no PII tombstone, clean GDPR erasure).
- Login takes a **username OR email** identifier; a **6-uppercase-letter (A-Z) code** is emailed
  to the account's address. Code is good for **10 minutes**, **one-time use**.
- **Reuse, don't resend:** while an unexpired code exists for an email, repeat requests reuse it
  and send NO second email. This is the key reason we cannot use the built-in Email provider.
- **Enumeration resistance:** a taken *username* gets an explicit "already taken" error (usernames
  are necessarily enumerable). A taken *email* is NEVER disclosed - signup with an existing email
  silently sends a *login* code to that address and advances to the same code screen. The login
  email carries a "if you didn't request this, contact support" line.

### Why NOT the built-in Email/OTP provider

`Email({ generateVerificationToken, sendVerificationRequest, maxAge })` from
`@convex-dev/auth/providers/Email` (the Resend-OTP recipe in docs/config/otps.mdx) **regenerates
the token and overwrites the stored hash on every `signIn(email)` call**, then sends. That
directly conflicts with "reuse the existing unexpired code, don't resend." So we own issuance.

### The chosen mechanism: ConvexCredentials + our own `loginCodes` table

`ConvexCredentials({ id, authorize })` from `@convex-dev/auth/providers/ConvexCredentials`
(docs: api_reference/providers/ConvexCredentials.mdx). `authorize(credentials, ctx)` runs in an
**action ctx** (`GenericActionCtxWithAuthConfig`), returns `{ userId }` (optionally `{ sessionId }`)
on success or `null`/throw on failure; the library mints the session from the returned `userId`.
The OTP doc explicitly sanctions this: *"If you use a third-party service that takes care of
generating and validating OTPs, you can use a custom ConvexCredentials config."* We are our own
issuing service.

- **Issuance** = a separate public **`"use node"` action** (`requestLoginCode`), NOT `signIn`.
  It resolves identifier->email, runs the username/email enumeration logic, calls an internal
  mutation `issueCode` that **mints-or-reuses** a row in `loginCodes`
  (`{ email, codeHash, expiresAt, attempts, pendingUsername?, kind }`), and emails the code via
  the existing Nodemailer/SMTP action path (email.ts) only on a fresh mint. Turnstile-gated.
- **Verification** = `signIn("email-code", { email, code })` -> `authorize` calls internal
  mutation `consumeCode` (compare hash, check expiry, increment/lock attempts, delete on
  success, return `pendingUsername`). Then: existing user by email -> return `{ userId }`;
  no user -> `createAccount(ctx, { provider: "email-code", account: { id: email }, profile: {
  email, name, username, usernameLower } })` (secret OMITTED - passwordless) and return its
  `user._id`. Username uniqueness re-checked atomically here to close the pre-check race.
- **`createAccount`/`retrieveAccount`** (`@convex-dev/auth/server`): create account+user with a
  unique account `id` (we use the email) and a `profile` that must fit the `users` schema -> this
  is where `username`/`usernameLower` are written. `secret` is optional; passwordless omits it.
- **Custom user fields:** the `users` table is redefined in schema.ts (spread `authTables` then
  override `users` with the extra `username`/`usernameLower` columns + a `by_username` index).
  `callbacks.createOrUpdateUser` is for "credentials" type only called when `createAccount` is
  called - we write the profile directly via `createAccount`, so we do not need it.
- **Dev testability:** `loginCodes` stores a **hash** (sha256) for verification; in
  `development` env only, `requestLoginCode` ALSO returns the plaintext code to the caller so the
  headless Playwright test can read+enter it. In live it returns `{ sent: true }` with no code.
  **Reuse path (revised 2026-05-27):** in development the reuse path ALSO returns the live
  plaintext (`issueCode` hands back the stored `devPlain` of the unexpired row, and
  `requestLoginCode` returns it as `devCode`), so requesting a code more than once inside the
  10-minute window keeps surfacing the on-screen dev-code box rather than going blank on the
  second click. This is dev-only and leak-safe: `devPlain` is never stored in live, so live still
  returns `{ sent: true }` with no code on reuse. The real reuse-don't-resend invariant is
  unchanged (no new row is minted and no second email is sent: the returned code on reuse is
  byte-identical to the first mint, which is what the test now asserts). The earlier note that
  the reuse path returned no plaintext is superseded; it conflated "no new mint" (the invariant)
  with "no devCode echoed" (an incidental detail that left the human dev page blank on the common
  re-request loop, e.g. logging in as the seeded admin right after its code was minted).
- **Rate-limit / brute force:** 26^6 ~= 308M space; `consumeCode` locks a code after N failed
  attempts (delete the row). Email-bombing is bounded by reuse (<=1 email per 10 min per email)
  plus the Turnstile gate on `requestLoginCode`.

### Admin bootstrap without a password

`seedAdmin` no longer uses `ADMIN_PASS`. It creates/ensures the admin account from `ADMIN_USER`
(an email) + `ADMIN_USERNAME` (default derived), via `createAccount` with no secret. `lib.ts
adminEmails()` already grants admin to `ADMIN_USER`, so authority follows the env. The
`signInAsAdmin` test helper signs in by issuing+consuming a code for `ADMIN_USER` through the dev
deterministic-code path (no password to type). NOTE 2026-05-25: `ADMIN_USER` was changed to
`francis@odysseyalive.com` (the `admin@` mailbox does not exist); an idempotent reconcile renames
any legacy `admin@odysseyalive.com` user row + its `authAccounts` providerAccountId to the
current `ADMIN_USER`.

**Confidence:** High on the ConvexCredentials/createAccount API (official docs, read 2026-05-25).
**Empirical tests required before declaring done (project rule):** (a) the two-phase
`requestLoginCode` -> `signIn("email-code", {email,code})` round-trip actually mints a session and
redirects, driven headless by Playwright; (b) reuse-don't-resend holds across two rapid requests;
(c) the username-taken vs email-silent-login branches behave as specified.

Per-user ownership unchanged: `getAuthUserId(ctx)` / `ctx.auth.getUserIdentity()`, scope rows by
`userId` (the `lib.ts requireUserId` pattern).

Sources (read 2026-05-25): github.com/get-convex/convex-auth docs `config/otps.mdx`,
`api_reference/providers/ConvexCredentials.mdx`, `api_reference/providers/Email.mdx`,
`api_reference/server.mdx` (createAccount, retrieveAccount, callbacks.createOrUpdateUser,
afterUserCreatedOrUpdated), `advanced.mdx`. Plus docs.convex.dev/auth/convex-auth,
labs.convex.dev/auth/setup/manual.

---

## 4. Next.js 16 standalone in Docker + nginx proxy (for `deploy`)

- Requires `output: 'standalone'` in next config (odyssey-alive already sets this).
- Canonical multi-stage Dockerfile = `vercel/next.js/examples/with-docker` (deps -> builder ->
  runner). `public` and `.next/static` are NOT copied automatically by the standalone server -
  copy them explicitly into `./public` and `./.next/static`. Run as non-root `node` user; set
  `ENV PORT=3000` and `ENV HOSTNAME="0.0.0.0"`; `CMD ["node", "server.js"]`.
- **nginx proxy template** (the jstack "proxy" variant, vs jstack's current static `root`
  block). The `map` goes at `http{}` scope:
```nginx
map $http_upgrade $connection_upgrade { default upgrade; '' close; }
server {
    listen 80;
    server_name <domain>;
    location / {
        proxy_pass http://127.0.0.1:<port>;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection $connection_upgrade;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```
  The `Upgrade`/`Connection` pair carries WS (Convex realtime + Next streaming/HMR);
  `X-Forwarded-Proto $scheme` is what Next/auth read for correct cookies/redirects behind TLS.

**Confidence:** High (official Next.js docs v16.2.6 + nginx.org). jstack currently emits a
static `root` server block in `scripts/core/register_sites_nginx.sh`; a proxy template is
needed - see deploy.md.

Sources: nextjs.org/docs/app/getting-started/deploying, nextjs.org/docs/app/api-reference/config/next-config-js/output,
raw.githubusercontent.com/vercel/next.js/canary/examples/with-docker/Dockerfile, nginx.org/en/docs/http/websocket.html.

---

## 5. First-party AI features on Convex (for `module-app`) — NOT YET RESEARCHED

Placeholder, opened 2026-07-22. The architecture is decided (modules.json `$architecture`): AI is
first-party code in this repo, running through Convex actions, with no external workflow platform.
What is NOT established, and must be before any AI surface is designed:

- Which Convex capabilities the work actually leans on, and their current shape.
- How model provider credentials reach the **self-hosted** backend's environment (`npx convex env
  set`), and how they differ between the dev mirror and live.
- Timeout, retry, and streaming behavior for calls that outlast a normal request.
- Cost controls: per-user and per-account limits, given open signup.

Run this on the **coding lane** and write the findings here with citations before designing
against them. Direction is not a citation — the rest of this file earns its authority by being
grounded, and this section has not yet.

---

## 6. Square for subscription billing (for the future payment work) — PRELIMINARY

Researched 2026-07-22 in response to Francis's "maybe we could offload this to Square." **Source
quality caveat: this section is built from search results, NOT from fetched documentation** — the
local browser profile was locked, so pages could not be rendered and verified directly. Treat
every claim below as a lead to confirm against the live docs before designing. Links at the end.

### The data model

Three objects: **subscription plan** (what is sold), **subscription plan variation** (how it is
sold — cadence and price), and **subscription** (who is buying). Subscriptions bill **in advance**
from `start_date`, repeating on the variation's cadence, charging the customer's card on file.

### Hosted checkout — this is the part that matters for us

`CreatePaymentLink` (Checkout API) generates a **Square-hosted checkout page** for a subscription
plan variation. On completion Square finds-or-creates the customer, stores the card on file,
creates the subscription, and charges the first paid phase.

**This confirms the architecture we recorded in schema.md § G:** checkout happens on Square, so
this database never stores an address or card data.

### Findings that would change a design decision

1. **Customer matching is by PHONE NUMBER.** Square's subscription checkout searches the seller's
   Customer Directory by the phone number the buyer types. Site accounts here are
   **username + email, with no phone**. So the Square customer cannot be assumed to match a site
   account by email, and a buyer can trivially end up with a Square customer record that has no
   reliable link back to their account. **The `billingLinks` table must be populated from the
   checkout/webhook flow with an explicit correlation token, never inferred by matching contact
   details.** This is the single most load-bearing finding here.
2. **Checkout API supports only ONE paid phase** (or one free phase plus one paid phase) per plan
   variation. Multi-phase pricing ladders are out if hosted checkout is the front door.
3. **Metered / usage-based pricing is NOT supported.** Directly relevant: this site's modules are
   AI-backed, and AI cost scales per call. Flat monthly pricing plus internal usage caps is
   therefore the shape Square supports — usage-based billing would need a different processor or
   an invoicing workaround. Decide pricing shape and processor together, not separately.
4. **ACH is unavailable** through the Subscriptions API (bank accounts cannot be stored and
   charged later). Card only.
5. **$1 minimum** per subscription charge.
6. **Free trials** are modeled as an initial phase with a 100% discount, not a distinct trial
   concept. **Proration** is opt-in per variation via `can_prorate`.
7. **Webhooks exist and are the right entitlement trigger:** `subscription.updated` fires on
   status change (e.g. to `DEACTIVATED`), with `ListSubscriptionEvents` for the reason;
   `payment.updated` covers payment outcomes.

### What this means for entitlement

The intended wiring is `subscription.updated` webhook → a Convex action → grant or revoke
`moduleAccess`. **That path is currently forbidden** by the 2026-07-22 directive ("access has to
be given manually") and requires a dated directive amendment first — see schema.md § G. Do not
build the webhook grant before the amendment exists.

### Still unverified — confirm before designing

Fee structure for recurring card-not-present transactions; sales-tax determination for software
subscriptions (does Square compute it, or is that on us); whether plan/variation modeling can
express module bundles; dunning and failed-payment retry behavior; and how well the Customer
Directory model fits a software business rather than a retail one.

Sources (search-derived, not fetched):
[Subscriptions API overview](https://developer.squareup.com/docs/subscriptions-api/overview) ·
[Plans and variations](https://developer.squareup.com/docs/subscriptions-api/plans-and-variations) ·
[Subscription billing and invoices](https://developer.squareup.com/docs/subscriptions-api/subscription-billing) ·
[Subscription plan checkout](https://developer.squareup.com/docs/checkout-api/subscription-plan-checkout) ·
[Checkout API](https://developer.squareup.com/docs/checkout-api) ·
[Square webhooks](https://developer.squareup.com/docs/webhooks/overview) ·
[App Subscriptions (metered-pricing limitation)](https://developer.squareup.com/docs/app-marketplace/app-subscriptions)

---

## 7. DocuSign's own legal surface (for `sign-me`) — TEARDOWN, 2026-07-27

Francis asked for a discovery read of DocuSign's privacy notice and terms, focused on
**presentation, document retention, and the legalities of providing the service** — explicitly
NOT as a competitive analysis (sign-me is real-estate-only and does not compete head-on).

Four documents were fetched and read in full on 2026-07-27. This is a reading of **what the
market leader commits to and, far more importantly, what it refuses to commit to**. Their
disclaimers are a map of where the legal risk actually sits in this business.

**Nothing here is legal advice, and none of it substitutes for the primary sources.** ESIGN,
UETA, state real-estate law, and RON statutes have NOT been read yet — see § What is still
unresearched.

### 7.1 The headline: DocuSign warrants almost nothing substantive

The eSignature Service Schedule § 2 is a list of things DocuSign explicitly **is not responsible
for**. Verbatim scope, condensed:

| Clause | DocuSign is NOT responsible for |
|---|---|
| 2(c) | Determining whether a document is **excepted** from e-signature law (wills, family law are named) or subject to a particular agency's regulations, or whether it can legally be formed by e-signature at all |
| 2(d) | **Determining how long any contract, document, or record must be retained** under any law or regulation — and not responsible for producing the customer's documents to third parties |
| 2(e) | Determining whether a transaction involves a **"consumer"**; furnishing or obtaining consumer consents; providing the disclosures that accompany them; legally reviewing those disclosures; or providing paper copies |
| 2(f) | (the flip side) **The CUSTOMER undertakes** to determine whether a consumer is involved and to comply with everything that follows |
| 2(g) | Anything the customer decides in reliance on the service. Verbatim: *"neither Docusign nor Docusign eSignature is providing Customer with legal advice, and Customer shall consult its own legal subject matter expert"* |

Backed by hard caps: liability is limited to **12 months of fees paid or $100, whichever is
greater** (Terms § 4.6.7), the site and information are **"AS IS"** with all implied warranties
disclaimed (§ 7.1), and the **customer indemnifies DocuSign** for "the nature and substance of
all documents, data, or other content uploaded" (§ 8.1).

**Why this matters more than any feature comparison.** DocuSign has a large legal department and
two decades of case exposure, and it still will not warrant that a signature it collected is
enforceable. That is simultaneously:

- **Permission.** sign-me does not need to warrant enforceability either, and any expectation
  that it should is not the industry standard. The honest posture is available and is what the
  leader uses.
- **Warning.** "Legally guaranteed signatures" is therefore NOT an available differentiator, and
  copy that drifts toward it takes on risk DocuSign specifically declined. `/copy-truth` should
  treat any enforceability claim on the sign-me intro page as a MUST FIX by default.
- **A build spec.** Every determination DocuSign pushes onto the customer is a determination a
  *solo agent* is now making alone, badly, with no legal team. **That gap is the actual product
  opportunity** — not the signing UI, which is commoditized. A real-estate-specific tool can
  encode the determinations a general-purpose tool refuses to make. Whether it *should* is a
  liability question for Francis and a lawyer, because encoding them is the moment you stop
  disclaiming them.

### 7.2 Retention — the vendor takes no position, and that is deliberate

Defaults, from the Service Schedule § 3:

- **§ 3.1 Default storage:** completed eDocuments are stored "for the duration of the Term, or
  until Customer deletes the eDocument, whichever occurs first." Earlier deletion is a per-account
  setting the Account Administrator configures. There is no opinionated default period.
- **§ 3.2 Post-term:** after the Term expires the customer has **two years** to request retrieval,
  and retrieval is a **paid Professional Services engagement**, not a self-serve export. After two
  years DocuSign may delete the account and everything in it.
- **§ 3.3 Transaction Data:** DocuSign retains it "for as long as it has a business purpose to do
  so" — an open-ended term, and notably NOT tied to the customer's retention setting.

**The design lesson for sign-me is the split, not the durations.** DocuSign separates two things
this project has so far treated as one:

1. **The eDocument** — the content. Customer-controlled, purgeable at will, and its deletion is
   verifiable through the product or API.
2. **The audit trail / Transaction Data** — defined in the Schedule as the metadata used "to
   generate and maintain the digital audit trail," specifically: transaction history, **image hash
   value**, method and time of envelope deletion, sender and recipient names, email addresses, and
   signature IDs.

From the data-management page, on purging: *"we provide an option to retain the audit log data
(which includes the Certificate of Completion and history) to support our ability to attest to the
details of a transaction. Customers view this behavior as a valuable feature that allows Docusign
to be a **neutral record**."*

**This resolves the erasure collision this project already flagged**
(`DEC-2026-07-22-hard-delete-erasure` vs. sign-me's evidentiary weight, noted in modules.json
`sign-me.convex._note`). The resolution is architectural, not a policy exception:

> **Erase the document. Keep the hash.** The signed PDF lives in Convex file storage and is fully
> reachable by hard-delete erasure. The audit trail retains an **image hash** of what was signed
> plus the event metadata — enough to attest that a specific document was signed by a specific
> party at a specific time, with **no document content retained**. A hash is not the personal data;
> it is a fingerprint of a record that no longer exists.

That gives the "retained with justification" state the registry says must exist **before this
module ships** a concrete shape: it is not a retained *document*, it is a retained *attestation*.
This is a proposal from reading DocuSign's design, not a verified GDPR conclusion — whether an
audit row naming a signer survives that signer's erasure request is exactly the question for a
lawyer, and the hash trick does not by itself answer it, because names and emails are in the audit
trail too.

### 7.3 Presentation is a LEGAL surface here, not a design surface

The most under-appreciated finding. Service Schedule § 2(e) states that consumer-protection law
"may impose special requirements... such as requirements that the **consumer consent to the method
of contracting** and/or that the consumer be provided with a copy, or access to a copy, of a paper
or other non-electronic, written record." DocuSign then refuses to furnish the consent, obtain it,
provide the disclosures, or review them — and § 2(f) hands all of it to the customer.

In practice this is why every DocuSign signing session opens with an *Electronic Record and
Signature Disclosure* the signer must affirmatively accept before the document appears. **That
screen is a compliance artifact wearing a UI costume.**

Consequences that bind sign-me's signing flow from the first wireframe:

1. **Consent-before-content.** The signer sees and accepts an electronic-records disclosure
   *before* the document is presented, and the acceptance is an audit-trail event with timestamp,
   IP, and method — not a checkbox whose state is discarded.
2. **The disclosure text is not ours to write.** DocuSign makes it customer-configurable precisely
   because its content is the customer's legal responsibility. sign-me should do the same:
   a configurable disclosure with a clearly-labeled default, never a hardcoded paragraph we
   authored that reads as though a lawyer reviewed it.
3. **"Access to a copy" is a product requirement.** The signer — who is NOT our account holder and
   may never create an account — must be able to obtain a copy. That is a schema consequence
   (recipient-scoped access tokens) and an entitlement-model consequence: **the signing surface
   must be reachable without a moduleAccess grant**, since the signer is the agent's client, not a
   subscriber. Worth stating plainly because the site's entitlement gate is otherwise universal.
4. **Real estate is dense with consumers.** § 2(f)'s "determine whether a consumer is involved" is
   nearly always *yes* here. A general tool can punt on that; a real-estate-only tool cannot
   credibly claim to be real-estate-focused and then punt on the single determination the vertical
   makes predictable.

Also § 2(b): the customer has "exclusive control over and responsibility for the content, quality,
and format of any eDocument." sign-me does not vet document contents, and should say so.

### 7.4 Processor vs. controller — the registry's `privacy_flag`, answered

From the Privacy Notice § 1: *"when a customer uploads contracts or other documents for review or
signature, we act as a **data processor**... In those instances, the **customer is the data
controller** and is responsible for most aspects of the processing."* Rights requests received by
DocuSign are **forwarded to the customer**, not answered.

Mapped onto sign-me: **the agent is the controller of their clients' documents; Odyssey Alive is
the processor.** Direct consequences:

- A **DPA** (data processing agreement) is needed between Odyssey Alive and each agent — not a
  privacy policy, a contract. This is a real drafting cost, and it is the first thing on this site
  that plausibly needs a lawyer rather than an adaptation of odyssey-alive's pages.
- A **published subprocessor list**, since DocuSign maintains one and it is standard processor
  hygiene. This tightens `DEC-2026-07-22-in-house-by-default` usefully: every third party added to
  sign-me's path becomes a public disclosure and a DPA amendment, which is exactly the "permanent
  administrative cost" the directive's question 3 predicted.
- **A signer's rights request routes to the agent**, not to us. That needs a stated flow before
  launch, and it is a support-desk surface as much as a legal one.
- Note the asymmetry DocuSign admits: for some products it is processor *and* controller
  simultaneously — controller "e.g., retention of transactional data to comply with Docusign's
  legal obligations." **The audit trail is the thing that makes you a controller.** Retaining an
  attestation for our own evidentiary purposes is our decision, not the agent's instruction, so
  that slice of sign-me is Odyssey Alive acting as controller. Say so in the privacy page.

### 7.5 What DocuSign spends money on that sign-me cannot match

From the data-management page (last updated 2026-04-14), stated plainly so no copy ever implies
parity:

- AES-256 encryption at rest, TLS 1.2+ in transit, and an architecture that **prevents DocuSign
  personnel from reading document contents** — staff see only envelope metadata, role-based.
- **ISO 27001 certification** of a written information security program.
- **Binding Corporate Rules** approved annually by the Irish Data Protection Commission, for both
  processor and controller roles.
- **Five data-center regions** (US, Canada, Europe, Australia, Japan) with data-residency choice.
- A published subprocessor list; customer-managed encryption keys as a paid add-on.

sign-me will have none of ISO 27001, BCRs, or multi-region residency at launch. **That is
acceptable and unremarkable for a beta** — it is not acceptable to be vague about it. The honest
version is a short, specific security statement (encrypted at rest in Convex file storage, one
region, backed up, here is who can see what) rather than reassuring adjectives. The encryption
posture and the "our staff cannot read your documents" property ARE worth deliberately copying,
because they are cheap to design in and expensive to retrofit.

### 7.6 Two incidental findings

- **DocuSign already sells real-estate transaction management.** The Service Schedule defines
  **DocuSign Rooms** — "transaction management, which provides online display of Rooms, management
  of eDocuments, people, and tasks" — which is functionally a real-estate transaction room, plus
  **DocuSign Workspaces** for shared files. So "e-signature focused on real estate" is *not* an
  unoccupied position, and the sign-me positioning cannot rest on the vertical alone. It has to
  rest on something Rooms is bad at — most plausibly price and overhead for a solo agent, which is
  the site thesis anyway (`$site_thesis.statement`).
- **Terms § 1.1.2:** *"If you are or become a direct competitor of ours, you may not access or use
  any Site without our written consent."* This restricts *using DocuSign's site/service* while
  building a competitor; it is an account-level term, not a bar on building the product. Worth
  knowing before anyone signs up for a DocuSign trial to study the UX.

### What is still unresearched — do NOT design past this line

None of the following has been read; everything above is DocuSign's *self-description*, which is
evidence about industry practice and about DocuSign's risk posture, **not a statement of law**:

1. **ESIGN Act and UETA primary text** — particularly ESIGN's consumer-consent provisions, which
   are the actual source of § 7.3's requirements, and UETA's state-by-state adoption variance.
2. **State real-estate specifics** — which transaction documents may be signed electronically,
   and which must be wet-signed or notarized. § 2(c)'s "exceptions" clause exists for a reason.
3. **Remote online notarization (RON)** — state-authorized, technically demanding, and a plausible
   hard boundary for the roadmap's "not planned" list rather than a feature.
4. **Brokerage and association forms libraries** (zipForm / Lone Wolf, Dotloop, SkySlope, Form
   Simplicity) — whether the agent's actual transaction paperwork is already locked to a mandated
   platform. **This is the question most likely to invalidate the module's premise** and it is
   answerable by asking one working agent, not by research.
5. **What a defensible audit trail contains** — DocuSign's Certificate of Completion is a de facto
   standard worth reproducing in substance; its exact evidentiary contents have not been examined.

Items 1–3 and 5 are coding-lane research. Item 4 is a question for the working agent, per
`meridian.positioning.source_of_truth`, and should be asked before the others get expensive.

Sources — all fetched 2026-07-27 via playwright-mcp:
[Privacy Notice (version date 2025-10-09)](https://www.docusign.com/privacy) ·
[Data management and privacy practices (updated 2026-04-14)](https://www.docusign.com/trust/privacy/data-mgmt-privacy) ·
[Sites & Services Terms and Conditions](https://www.docusign.com/legal/terms-and-conditions) ·
[Service Schedule for DocuSign eSignature](https://www.docusign.com/legal/terms-and-conditions/schedule-docusign-signature)

---

## 8. What an e-signature system must BE (for `sign-me`) — DISCOVERY, 2026-07-27

Francis: *"I want to do a discovery... understand the system [that] companies require and rely on
on such a system."* § 7 read what DocuSign *says*. This section reads what the **law** says and
what makes a system **relied upon** — the legal floor and the system floor.

Primary sources this time (ESIGN is quoted from the statute), plus search-derived findings for
UETA, URPERA, and RON, which are state law and were NOT read in primary form. Search-derived
findings are marked. **Not legal advice.**

### 8.1 The federal floor — ESIGN, 15 U.S.C. § 7001

**The grant is narrow and negative.** § 7001(a) does not say an e-signature is valid; it says one
may not be denied effect *solely* because it is electronic:

> *"a signature, contract, or other record... may not be denied legal effect, validity, or
> enforceability solely because it is in electronic form."*

Everything that makes a signature actually stick — that this person signed, that they meant to,
that the document is unchanged — is left to ordinary contract and evidence law. **The statute
gives you non-discrimination; the SYSTEM has to give you proof.** That single distinction is the
whole reason e-signature platforms have the shape they do, and it is the frame for § 8.6.

**§ 7001(c) — the consumer-consent machinery.** Where any law requires information be given to a
consumer *in writing*, an electronic record satisfies it only if the consumer affirmatively
consented and was first given a **clear and conspicuous statement** covering: any right to a paper
copy; the right to withdraw consent, with conditions, consequences, and fees; whether consent
covers this transaction only or a category of records; how to withdraw and how to update contact
info; and how to obtain a paper copy and at what cost. Separately, § 7001(c)(1)(C) requires a
statement of **hardware and software requirements**, and consent given electronically *"in a manner
that reasonably demonstrates that the consumer can access information in the electronic form."*

That is a literal specification of the disclosure screen § 7.3 inferred from DocuSign's behavior —
DocuSign is not being cautious, it is tracking the statute. **The consent screen is not
boilerplate; it is a checklist, and it is checkable.**

Two nuances that prevent over-engineering:

- **§ 7001(c)(3):** failure to obtain the "reasonably demonstrates" confirmation *"shall not"* by
  itself deny a consumer contract its effectiveness. The demonstration is a compliance requirement,
  not a validity condition.
- **§ 7001(c)(1)(D):** if hardware/software requirements later change materially, you must re-
  disclose and re-consent. A retention or viewer change is a compliance event, not just a release.

**§ 7001(d) and (e) — retention, and the sharpest constraint we have found.** § 7001(d) says a
retention requirement is met by an electronic record that *"accurately reflects"* the information
and *"remains accessible... in a form that is capable of being accurately reproduced for later
reference."* Then § 7001(e) supplies the teeth:

> *"the legal effect, validity, or enforceability of an electronic record... may be denied if such
> electronic record is not in a form that is capable of being retained and accurately reproduced
> for later reference by all parties or persons who are entitled to retain the contract."*

**Read that against the signing flow.** If the signer cannot retain and reproduce a copy,
enforceability is exposed — not as vendor best practice but as statute. § 7.3 flagged "access to a
copy" from DocuSign's terms; § 7001(e) is where it actually comes from, and it upgrades the
requirement from *courteous* to *load-bearing*.

**§ 7001(g) — notarization.** A notarization requirement is satisfied if the authorized person's
electronic signature *"together with all other information required to be included by other
applicable statute"* is *"attached to or logically associated with"* the record. ESIGN permits
e-notarization in principle and then defers entirely to state law for the substance — which is
where RON lives (§ 8.5).

### 8.2 UETA § 9 — attribution, and why audit trails exist at all

*(Search-derived; UETA is state law and the uniform text was not fetched in primary form.)*

UETA § 9(a): an electronic record or signature is attributable to a person **if it was the act of
that person**, and that act *"may be shown in any manner, including a showing of the efficacy of
any security procedure applied."*

This is the most product-shaping sentence in the whole body of law. It means:

- **There is no statutory checklist that makes a signature attributable.** It is an evidentiary
  question decided after the fact, on whatever proof exists.
- **"Efficacy of the security procedure" is expressly named as admissible proof.** The audit trail
  is not paperwork — it is the evidence that decides attribution when someone says *"I never signed
  that."*
- **Therefore the audit trail IS the product.** The signing UI is commodity; what a business relies
  on is the ability to answer a repudiation two years later. Everything in § 8.6 follows from this.

UETA § 12 mirrors ESIGN on retention (accurately reflects + remains accessible). UETA § 13:
evidence *"may not be excluded solely because it is in electronic form"* — again non-discrimination,
not sufficiency.

### 8.3 The exceptions — ESIGN § 7003, and a real-estate landmine

§ 7001 does **not** apply to wills/codicils/testamentary trusts, family-law matters, or most of the
UCC (§ 7003(a)). The additional exceptions in § 7003(b) include one that lands squarely in
property:

> *"any notice of... default, acceleration, repossession, foreclosure, or eviction, or the right to
> cure, under a credit agreement secured by, or a rental agreement for, a **primary residence** of
> an individual"*

Also excepted: court orders and official court documents, utility cancellations, health/life
insurance cancellation, and product-safety recalls.

**Consequence for `sign-me`:** default, foreclosure, eviction, and right-to-cure notices on a
primary residence are OUTSIDE the e-signature safe harbor. That is a concrete, citable entry for
the roadmap's "what is NOT planned" section — which `procedures/content.md` § roadmap already asks
for, on the grounds that a DocuSign comparison invites assumptions. This is better than a vague
disclaimer: it is a named boundary with a statute behind it.

### 8.4 The recording problem — URPERA

*(Search-derived.)* The Uniform Real Property Electronic Recording Act (2004, amended 2005) lets
county clerks and recorders **accept** electronically signed and notarized real-property documents,
equating them to paper originals. Adopted in roughly 37 states plus DC as of 2021.

**The critical property: URPERA AUTHORIZES, it does not MANDATE.** Whether a specific county
recorder actually accepts an electronic deed is a county-level operational fact, not a state-level
legal one.

This is a system dependency of a kind pure e-signature products do not have: **a signed deed that
no recorder will accept has not accomplished the transaction.** It also sets a natural scope line —
`sign-me` can be a signing system without being an e-recording system, but the copy must not imply
it closes anything at the county.

### 8.5 RON — a product, not a feature

*(Search-derived.)* Remote Online Notarization is authorized permanently in roughly 44 states plus
DC. A conforming RON session requires, at minimum: identity proofing via **knowledge-based
authentication and/or credential analysis**; live **audio-visual** communication; an **electronic
notarial journal**; and an **audio-video recording of the session retained typically 5–10 years**,
with the notary or platform responsible for secure storage of that recording and its PII. Platforms
handling mortgage transactions commonly carry **MISMO** certification covering credential analysis,
identity verification, A/V quality, record storage, and audit trails.

**Assessment: RON is out of scope and should be stated as out of scope.** It is a separate
regulated product with a video-retention obligation that dwarfs the document-retention problem, an
identity-proofing dependency that cannot be built in-house, and a per-state compliance surface. It
belongs on the roadmap's NOT-planned list beside § 8.3's excepted notices.

### 8.6 The system floor — what a business actually relies on

Synthesized from §§ 8.1–8.2 plus § 7. Six capabilities. Everything else in an e-signature product
is convenience; these are the load-bearing ones, and each maps to a legal requirement rather than a
competitor's feature list.

| # | Capability | What it answers | Source |
|---|---|---|---|
| 1 | **Attribution / identity** | "Prove *I* signed it" | UETA § 9 — efficacy of the security procedure |
| 2 | **Intent + consent capture** | "Prove I *agreed*, and was told what I was agreeing to" | ESIGN § 7001(c) |
| 3 | **Tamper-evidence** | "Prove this is what I signed, unaltered" | § 8.7 |
| 4 | **The audit trail** | The evidence carrying 1–3 into a dispute | UETA § 9 |
| 5 | **Retention + reproducibility** | "Produce it, accurately, years later — for *every* entitled party" | ESIGN § 7001(d), (e) |
| 6 | **Vendor-independent verifiability** | "Prove it without the vendor" | § 8.7 |

Note what is absent: templates, bulk send, integrations, mobile apps, branding. Real products, and
none of them is why a business trusts the system. **A minimum viable e-signature product is
therefore not a small signing UI — it is a small signing UI plus all six of these.** That is the
honest answer to "how big is the first slice," and it is bigger than a wizard.

### 8.7 Vendor-independent verifiability — the finding most likely to change our architecture

*(Search-derived.)* The mature mechanism is **PAdES** (PDF Advanced Electronic Signature): a
cryptographic certificate, timestamp, and validation data embedded *into the PDF itself*, so the
signature travels with the file and any alteration is detectable. When the sealing certificate
chains to a CA on the **AATL** (Adobe Approved Trust List), Acrobat and Reader show the document as
trusted and tamper-evident **with no configuration and no contact with the issuing platform**.

Why this matters more than it looks:

- **It decouples the evidence from us.** A PAdES-sealed PDF remains verifiable if `sign-me` is
  down, discontinued, or gone. For a solo agent deciding whether to trust an unknown vendor with
  transaction paperwork, "your documents outlive us" is a genuine and checkable answer to the
  strongest objection they have.
- **It changes what a signed document IS.** Not a stored file the platform vouches for, but a
  self-contained artifact that vouches for itself. That is a different data model than "PDF in file
  storage plus rows in a table," and retrofitting it is expensive.
- **It interacts with `DEC-2026-07-27-erase-document-keep-hash` favorably.** If the seal is in the
  document and the document goes to the parties, erasing our copy destroys less. The parties hold
  independently verifiable originals; we hold the attestation.

**And it collides with `DEC-2026-07-22-in-house-by-default`, honestly stated.** AATL membership
means a commercial relationship with a certificate authority — a paid third party, in the request
path, holding a key we depend on. Run against the directive's three questions: (1) *structurally
unavailable in-house?* **Yes** — trust in a CA is precisely the thing you cannot self-issue; a
self-signed seal is cryptographically fine and socially worthless, because Acrobat will warn on it.
(2) *What breaks if they vanish or reprice?* Already-sealed documents keep validating; new sealing
stops. Bounded, not catastrophic. (3) *Does it hold user data?* No — a CA signs hashes, not
documents. **It clears the ladder on the same grounds as OpenRouter and card processing.** But it
is a NEW third party and the directive requires that be a deliberate, recorded decision rather than
an implementation detail — flagging it, not deciding it.

### 8.8 What this changes for `sign-me`

1. **The consent screen is a statutory checklist** (§ 7001(c)) — build it against the statute, not
   against a screenshot of DocuSign.
2. **The signer must be able to retain and reproduce a copy**, and § 7001(e) makes that an
   enforceability question. Reinforces § 7.3: the signing surface is reachable without a
   `moduleAccess` grant.
3. **The audit trail is the product** (UETA § 9), not a compliance appendix. Design it first.
4. **Two citable NOT-planned boundaries** for the roadmap: ESIGN § 7003(b)(2)(B) excepted notices
   (default/foreclosure/eviction/right-to-cure on a primary residence), and RON.
5. **E-recording is a separate system** (URPERA is permissive and county-level) — do not imply
   `sign-me` closes anything at the county.
6. **PAdES/AATL sealing is a real architectural fork**, and the in-house directive requires it be
   decided deliberately.
7. **A refinement to `DEC-2026-07-27-erase-document-keep-hash`, discovered here:** ESIGN § 7001(d)
   contemplates records that **law requires be retained**. If such a law applies, erasing the
   document on request destroys a record that had to be kept — and per § 7.1, DocuSign explicitly
   refuses to determine when that is, because it is the *customer's* determination. So the erasure
   flow cannot silently erase: **at erasure time the agent (the controller) must be told that
   whether these documents are subject to a retention obligation is their call, not ours.** That is
   a UI and a policy consequence, and it was not visible when the decision was recorded.

### Still unresearched

- **UETA in primary form**, and the non-UETA states' own statutes (NY and IL notably diverge).
- **Her state's** real-estate rules and its county recorders' e-recording posture — blocked on
  knowing the state, same as `DEC-2026-07-22-mls-data-access`.
- **What a defensible Certificate of Completion contains**, field by field. § 7 gives DocuSign's
  list; nobody has checked it against what courts have actually accepted.
- **Case law on repudiated e-signatures** — where attribution succeeded and failed under UETA § 9.
  This is the highest-value remaining item: it is the difference between a plausible audit trail
  and a proven one.
- **PAdES/AATL practicalities**: CA options, cost, key custody, and long-term validation (LTV).

Sources — ESIGN fetched 2026-07-27 via playwright-mcp; the rest search-derived and NOT fetched:
[15 U.S.C. § 7001 (Cornell LII)](https://www.law.cornell.edu/uscode/text/15/7001) ·
[15 U.S.C. § 7003 (Cornell LII)](https://www.law.cornell.edu/uscode/text/15/7003) ·
[UETA (1999) final act, ULC](https://www.uniformlaws.org/) ·
[URPERA overview (Wikipedia / CSG Knowledge Center)](https://en.wikipedia.org/wiki/Uniform_Real_Property_Electronic_Recording_Act) ·
[RON laws by state](https://notarypublicassociation.org/remote-online-notary-laws-by-state/) ·
[PAdES / AATL background](https://www.certinal.com/blog/pades)

---

## 9. Case law on repudiated e-signatures (for `sign-me`) — PRIMARY SOURCES, 2026-07-27

§ 8.2 established that attribution under UETA § 9 is decided after the fact on whatever evidence
exists. This is what courts have actually accepted and rejected. **It is the most directly
buildable research in this file** — two of these opinions contain, in the court's own words, a
checklist of what the losing party should have said.

**All three opinions were read in full, from the California Courts opinion archive** (the free
`.DOC` files at `courts.ca.gov/opinions/archive/<DOCKET>.DOC`, which is not bot-walled the way
FindLaw, Justia, and CourtListener are). Working copies are in this session's scratchpad. An
earlier draft of this section relied on secondary summaries and **misidentified Fabian's docket as
D074449; the correct docket is D075519.**

### 9.1 The three cases

| Case | Court / docket | Result |
|---|---|---|
| **Ruiz v. Moss Bros. Auto Group** (2014) 232 Cal.App.4th 836 | 4th Dist. Div. Two, **E057529**, filed 12/23/14 | Authentication **FAILED** |
| **Espejo v. So. Cal. Permanente Medical Group** (2016) 246 Cal.App.4th 1047 | 2d Dist. Div. Four, **B262717**, filed 4/22/16 (Collins, J.) | Authentication **SUCCEEDED** — denial reversed, remanded |
| **Fabian v. Renovate America** (2019) 42 Cal.App.5th 1062 | 4th Dist. Div. One, **D075519**, filed 11/19/19, published 12/4/19 (Irion, J.) | Authentication **FAILED** |

Statutory frame, identical across all three: **Civ. Code § 1633.9(a)** (California's enactment of
UETA § 9) — a signature is attributable to a person *"if it was the act of the person,"* shown
*"in any manner, including a showing of the efficacy of any security procedure applied"* — plus
Evid. Code §§ 1400–1401, and *People v. Skiles* (2011) 51 Cal.4th 1178, 1187 (a writing may be
authenticated by circumstantial evidence and by its contents).

### 9.2 The finding that should drive the whole design

**In Fabian, DocuSign's identity verification was PRINTED ON THE DOCUMENT — and it still failed.**

From the opinion, describing the signature box:

> *"The words 'DocuSigned by:' and the printed electronic signature ''Rosa Fabian'' appear in a
> signature box at the end of the Contract. The date '2/28/2017,' a 15-digit alphanumeric
> character, and the words **'Identity Verification Code: ID Verification Complete'** also appear
> in the signature box."*

And the fatal omission:

> *"Anderson did not explain the significance of the 15-digit alphanumeric characters or the words
> 'Identity Verification Code: ID Verification Complete' that appear below Fabian's electronic
> signature."*

The proof was on the page. Nobody could say what it meant, so it counted for nothing. The court
also noted that **the word "DocuSign" never appears anywhere in Renovate's moving papers.**

> **The evidence is inert without a witness who can interpret it. An audit artifact that requires
> expertise the holder does not have is not evidence — it is decoration.**

That is a design requirement almost nobody would derive from first principles, and it is the
single most useful thing in this file.

### 9.3 What the courts said the winning declaration contains

**Ruiz gives a four-part template**, phrased as what the declarant failed to say (¶ 61, condensed
but tracking the court's structure):

1. that a signature in that name **could only have been placed** on the document by a person using
   the signer's unique credentials;
2. that **the date and time printed next to the signature indicate when the signature was made**;
3. that **all** users are required to use their unique credentials to sign; and
4. that the signature was **therefore** apparently made by that person, at that date and time.

Item 2 is easy to miss and is a schema consequence: the timestamp must be attestable as *the time
of signing*, not merely a value printed on a page.

**Espejo shows the same structure actually satisfying a court.** The declarant (Tellez) detailed:
how credentials reached the applicant (**by phone, orally, directly**); that he had to **reset the
password before he could proceed to the next page**; that he had to **affirmatively opt in** to
using an electronic signature; that the documents were reachable *only* through those credentials;
that at the signature page he was **prompted to accept or decline**; that **whatever name he typed
populated the signature line**; and that on acceptance the record was finalized with **name, date,
time, and IP address**. Her conclusion — that the name *"could have only been placed on the
signature pages... by someone using Dr. Espejo's unique user name and password"* — is what the
court held *"offered the critical factual connection that the declarations in Ruiz lacked."*

**Newton v. American Debt Services** (N.D. Cal. 2012) 854 F.Supp.2d 712, 731–732 is the affirmative
DocuSign case, cited approvingly in **both** Ruiz and Fabian: the signature was proved because
*"the process DocuSign used to verify the plaintiff's electronic signature was explained."* Same
technology as Fabian. Opposite result. The variable was never the technology.

### 9.4 How little it takes to trigger the burden

**Neither losing plaintiff denied signing.**

- **Ruiz** *"averred he did not recall signing any arbitration agreement"* — non-recollection, not
  denial. Burden shifted anyway.
- **Espejo** admitted signing the employment contract and said only that he did not recall seeing
  or signing the *second* document one minute later. A partial non-recollection was enough to put
  the whole authentication question in play.
- **Fabian** did deny it outright.

The counterweight, from Ruiz's reading of *Condee v. Longwood Management* (2001) 88 Cal.App.4th
215: **if authenticity is not challenged, no authentication is required at all.** The entire burden
is challenge-triggered.

> Practical shape: this evidence is needed **rarely, unpredictably, and years later — and it is
> triggered by someone merely not remembering.** That argues for capturing everything cheaply at
> signing time and never relying on being able to reconstruct it afterward.

### 9.5 An honest limit on how much Fabian proves

Fabian turned partly on standard of review. Because the trial court found the party bearing the
burden had not carried it, Renovate had to show its evidence was *"of such a character and weight
as to leave no room for a judicial determination that it was insufficient"* — the opinion quotes
the rule that where judgment goes against the party with the burden, *"it is almost impossible for
him to prevail on appeal."*

**So Fabian does not hold that DocuSign markers are always insufficient.** It holds Renovate failed
to compel the opposite finding on a thin record. **Ruiz is the stronger authority** for the
underlying proposition: it reviewed *de novo* on undisputed evidence and independently concluded
the showing was insufficient. Do not overstate Fabian in any internal doc, and never in copy.

### 9.6 What this means for `sign-me`

1. **The Certificate of Completion must be SELF-EXPLAINING.** Not just complete, not just
   exportable — it must state, in plain language a non-technical person can read aloud under oath,
   what each element is and what it proves. Fabian lost with a verification code printed on the
   page. **Ship a legend, not a log.** This is the § 9.2 finding turned into a build item.
2. **Structure the export around Ruiz's four-part template** (§ 9.3), so the document itself makes
   the argument: how the signer was reached, what only they could have done, what the timestamp
   means, and therefore whose act it was.
3. **Capture Espejo's fields**: credential delivery channel, any forced credential step, the
   explicit e-signature opt-in, the accept/decline event, what the signer typed, and **IP address**
   alongside name/date/time.
4. **Record identity verification as a first-class, human-readable fact** — not a code. If we ever
   print an equivalent of "ID Verification Complete," the export must define it in the same breath.
5. **Timestamp integrity is attestable**, per Ruiz item 2 — we must be able to say the recorded
   time *is* the time of signing.
6. **Assume retrieval years later by someone who is no longer a customer**, on a litigation
   deadline, triggered by a signer who merely does not remember.
7. Everything here also **strengthens § 9.3's review-evidence idea** from § 8's commentary: if the
   trail can prove *what only the signer could have done*, adding *what the signer was shown and
   for how long* is the same machinery pointed at the next likely challenge.

### Still unresearched

- **Non-California authority.** All three are California. Convenient (huge real-estate market,
  plaintiff-friendly, and Civ. Code § 1633.9 is verbatim UETA § 9) but not general.
- **What has cited Fabian since 2019**, and whether it has been distinguished or limited.
- **The cases DocuSign itself collects** where signatures were accepted once the Certificate of
  Completion was produced — those are the wins, and they would show field by field what sufficed.
- **The Certificate of Completion field by field** — still open from § 7 and § 8.
- **Whether any court has addressed the "no meaningful opportunity to review" theory** (§ 8's
  commentary). If one has, it moves from design hypothesis to citable position.

Sources — all three opinions fetched in full 2026-07-27 from the California Courts opinion archive:
[Fabian v. Renovate America, D075519](https://www.courts.ca.gov/opinions/archive/D075519.DOC) ·
[Ruiz v. Moss Bros. Auto Group, E057529](https://www.courts.ca.gov/opinions/archive/E057529.DOC) ·
[Espejo v. SCPMG, B262717](https://www.courts.ca.gov/opinions/archive/B262717.DOC) ·
commentary: [Hon. Meredith Jury (Ret.), case update, California Lawyers Association](https://calawyers.org/business-law/fabian-v-renovate-america-inc-cal-app/) ·
[Weston v. DocuSign (securities; see § 9.7)](https://www.labaton.com/cases/weston-v-docusign-inc)

### 9.7 DocuSign's own litigation — and why it is not the interesting part

The headline case is **Weston v. DocuSign, Inc.** (N.D. Cal., filed 2022-02-08): a securities-fraud
class action under §§ 10(b)/20(a) and Rule 10b-5 alleging misleading statements about the
durability of pandemic-driven growth, demand for eSignature, competition, and CLM prospects, for
purchasers between 2020-06-04 and 2021-12-02. **Dismissed with prejudice 2026-01-26** (Chhabria, J.).
*(Search-derived; verify via the company's own Form 10-K Item 3 "Legal Proceedings" on SEC EDGAR,
which is the authoritative source for a public company's litigation.)*

An investor case about forecasting. It says nothing about whether the product works — and that
absence is the finding:

> **The legal risk in this business does not appear as suits against the e-signature vendor. It
> appears as the vendor's CUSTOMER losing a case because it could not authenticate a signature the
> vendor collected.** Renovate lost; DocuSign was not a party.

That is precisely what § 7.1's disclaimer stack is engineered to produce. **Our liability exposure
is lower than it feels; our customers' is higher than they think. Helping them not be Renovate is
the product.**

---

## 10. Sending documents to a model — OpenRouter ZDR (for `sign-me`) — 2026-07-27

Blocks `modules.json` `sign-me.ai_field_detection` consequence (1): field detection would send the
agent's clients' documents to a model provider. Fetched from OpenRouter's own docs 2026-07-27.

### 10.1 The controls that exist

**Zero Data Retention (ZDR)** = the provider stores nothing for any period. Per OpenRouter:
*"Providers that do not retain your data are also unable to train on your data."* Some endpoints
don't train but do retain (abuse scanning, legal) — the two policies are controlled separately.

Three enforcement layers, and they compose:

| Layer | Mechanism |
|---|---|
| **Account** | Privacy settings, one toggle per model group |
| **Guardrail** (per API key / org member) | `enforce_zdr_anthropic`, `enforce_zdr_openai`, `enforce_zdr_google`, `enforce_zdr_xai`, `enforce_zdr_other`. The legacy `enforce_zdr` is **deprecated** — use the per-group fields |
| **Per request** | `{"provider": {"zdr": true}}` |

**The per-request flag ORs with the account/guardrail settings — it can only ever ADD enforcement,
never disable it.** That is the property that makes this safe to rely on: a request cannot
accidentally opt out of an account-level guarantee. (Search-derived, not seen in the fetched page:
a `data_collection: "deny"` provider preference blocks providers that store or train.)

**OpenRouter itself is ZDR** — prompts are not retained unless you opt into prompt logging.

**Its default is conservative:** *"If OpenRouter is not able to establish or ascertain a clear
policy for a provider or endpoint, we take a conservative stance and assume that the endpoint both
retains and trains on data and mark it as such."*

### 10.2 The verification hook — use this

> **`https://openrouter.ai/api/v1/endpoints/zdr`** — the machine-readable list of ZDR endpoints,
> *"automatically updated when there are changes to a provider's data policy."*

This turns a policy promise into a **testable invariant**. The privacy page will say documents go
only to zero-retention endpoints; that claim can be verified in CI and re-verified before each
send, rather than asserted once and rotting. Given `/copy-truth`'s standard — the interface's
actual behavior is ground truth — a claim we can check on a schedule is worth much more than one we
cannot. Wire it as a startup/CI check on the pinned model, and fail loud on a policy change.

### 10.3 Two caveats that must reach the privacy page

1. **Implicit prompt caching is NOT treated as retention.** OpenRouter's stated position: in-memory
   caching keeps repeated prompt data in the provider's datacenter, and *"OpenRouter has taken the
   stance that in-memory caching of prompts is not considered 'retaining' data,"* so cache-enabled
   endpoints remain reachable under ZDR. Defensible, and **not what a careful reader assumes "zero
   retention" means.** If we claim zero retention, this belongs in the fine print — or pin a model
   whose ZDR row shows implicit caching **No**, which most currently do.
2. **ZDR covers inference routing only** — not plugins or tools (web search etc.), which carry
   their own policies. Not relevant to a field-detection sweep, but it constrains what any future
   AI feature may switch on without re-examining this.

### 10.4 Cheap ZDR models exist — the sweep design is compatible

The ZDR list includes small, cheap models suitable for a verification sweep: **Gemini 2.5 Flash
Lite** (Google), **Amazon Nova Micro / Nova Lite** (Bedrock), **Claude Haiku 4.5** (Google and
Bedrock), and numerous DeepSeek endpoints. So "mechanical first, cheap model last" (§ 10.5) does
not force a privacy compromise — the cheap tier and the ZDR tier overlap.

Note the routing consequence for `DEC-2026-07-22-openrouter-provider`, which requires recording the
model that **ANSWERED**: under ZDR the same model is reachable through several ZDR endpoints
(Claude Haiku 4.5 appears under both Google and Bedrock). The recorded answer therefore needs the
**endpoint/provider**, not just the model name — otherwise the compliance record cannot show which
data policy actually applied.

### 10.5 Recommended posture for `sign-me`

1. **Enforce ZDR at the ACCOUNT level, all five model groups** — not per request. Per-request
   flags are additive-only, so account-level is the floor nothing can fall below, and a forgotten
   flag in new code fails safe.
2. **Pin the endpoint**, do not let it float. Record model + provider on every run.
3. **Assert the pin against `/api/v1/endpoints/zdr`** in CI and before sending (§ 10.2).
4. **Prefer an endpoint with implicit caching `No`**, so § 10.3(1) never has to be explained.
5. **Send the least possible.** The architecture in § 10.6 is what makes this real: the strongest
   privacy control is not a ZDR flag, it is not transmitting the document.
6. **Disclose it regardless.** ZDR reduces exposure; it does not remove the subprocessor. The
   privacy page names the provider, and the DPA lists it.

### 10.6 The architecture that makes the privacy question small — Francis, 2026-07-27

> **"we could create a script with AI that can be smart enough to build those boxes mechanically
> than using a cheap model to do a sweep of the document as the last step just to make sure
> everything looks right and filling in the gaps."**

**Mechanical primary, model as verifier.** This is better than a model-first pipeline on three
independent axes, and the third is the one that matters most:

1. **Cost** — per-run cost collapses; `usage-metering.md`'s cost-per-run framing gets easy.
2. **Privacy** — less content leaves, and for cached/known forms possibly none (§ 10.7).
3. **EVIDENCE — the decisive one.** § 9's standard is *"could only have happened this way."* A
   deterministic placement pass is **replayable**: re-run it on the same bytes and get the same
   field map, which is an attestable property in the Ruiz/Espejo sense. A model cannot promise
   that. **Mechanical-primary is not merely cheaper, it is more defensible** — so the cheap design
   and the correct design are the same design, which is rare and worth not squandering.

**Deterministic primitives that need no model at all:** existing **AcroForm** field definitions
(many form PDFs already declare them — read, don't infer); text runs with bounding boxes
(pdf.js / pdfminer); anchor-phrase matching ("Buyer's Signature", "Initials", "Date"); and
underscore-run / drawn-rule detection for signature lines.

**Constraint on the sweep:** the model may **propose** additions and **flag** anomalies. It must
never silently move or delete what the mechanical pass produced — that would put a
non-deterministic edit under the deterministic layer and forfeit advantage 3. Its output is a
diff for the agent to accept, which is the same shape as the never-auto-send rule.

### 10.7 The template cache — where this compounds

Real-estate forms are **heavily templated**: the same association and brokerage forms, repeatedly,
across many agents. So fingerprint each document by its text layout and cache the resulting field
map. **The second time anyone uploads that form, placement is instant, free, fully deterministic,
and involves no model and no data leaving.** Model usage decays toward zero as the catalog fills,
which inverts the usual AI cost curve — and the cache is a genuine moat that a competitor starting
later does not have.

Two cautions: a cached map must be **keyed to an exact layout fingerprint**, since a revised form
with shifted fields is a different document and a stale map places boxes wrongly — which is now an
evidentiary error, not a cosmetic one. And the cache stores **field geometry only, never document
content**, or it becomes a second store of client data and re-opens everything in § 7.4.

### 10.8 The fork to plan for: scanned PDFs

Everything above assumes a **text layer**. Scanned image PDFs have none, and real estate has many
of them. Those need OCR before any mechanical pass runs — **Tesseract, in-house**, which satisfies
`DEC-2026-07-22-in-house-by-default` and keeps the image from leaving. Treat text-layer and scanned
documents as two paths from the first design, not one path with a patch: OCR introduces positional
error that lands directly on field placement.

### 10.9 DECIDED 2026-07-27 — the sweep goes direct to Anthropic, not through OpenRouter

**This supersedes §§ 10.1–10.5 for `sign-me`'s field-detection sweep only.** Everywhere else,
`DEC-2026-07-22-openrouter-provider` and the OpenRouter ZDR posture above still stand — the ZDR
research is not wasted, it is the fallback if this decision is reversed and the reference for any
other AI feature.

Francis, after reading § 10: *"if Heiku 4.5 is adequate enough to do that, I could easily just
build a plugin for that model that would interface my Claude account."* Ratified as the
**Anthropic API** path (API key, pay-per-token) — explicitly NOT a Claude.ai Pro/Max subscription,
which is a personal subscription for the Claude interface and not a backend for a product we sell.
Full record: `DEC-2026-07-27-mechanical-first-field-detection` § Amendment.

**The deciding argument is subprocessor count, not cost.** The path would otherwise be
agent → us → OpenRouter → model provider; direct removes one party from a chain carrying the
agent's clients' documents. Per § 7.4 we are the processor and the agent is the controller, so each
added party is a privacy-page entry, a DPA line, and a place erasure cannot reach. Secondary:
**org-level retention configuration is a stronger guarantee than per-request routing flags** — it
is account state, not something a forgotten parameter can bypass, which is the exact weakness
§ 10.1 works around with OpenRouter's additive-only `zdr`.

**Model:** `claude-haiku-4-5` — **$1.00 / $5.00 per million tokens** (in/out), 200K context,
64K max output, verified 2026-07-27.

**Two consequences worth carrying into the build:**

1. **Strict structured outputs are supported on Haiku 4.5**, so the sweep can be constrained to a
   JSON schema at the API level — it *must* return a machine-readable diff of proposed fields and
   cannot return prose. That makes § 10.6's "propose, never edit" constraint a request-level
   guarantee rather than a prompt instruction. Build it that way.
2. **We now maintain a price entry.** `DEC-2026-07-22-openrouter-provider` chose OpenRouter partly
   because it reports actual cost per response and this repo kept no price table; going direct
   reverses that for this one call. Keep the number in ONE place with a checked date —
   `usage-metering.md` — because a stale price goes wrong silently.

**Lock-in, honestly assessed:** low here and only here. A mechanical verification sweep is narrow
and well-specified; model choice barely matters, and the single metered helper
(`usage-metering.md`) keeps the provider swappable regardless. **Revisit the moment the sweep grows
into open-ended generation** — that is when model choice starts mattering and the argument inverts.

**Launch checklist item, since nothing in the repo can catch it:** confirm the Anthropic org's
data-retention configuration before the first client document is sent, and re-confirm at launch.
It is account state, not code.

### Still unresearched

- **Anthropic's DPA / processor terms** — now the operative one for `sign-me` (§ 10.9); a
  subprocessor needs a data processing agreement, and it has not been located or read.
- **How org-level retention is configured and verified** on the Anthropic account, and whether
  that state is inspectable via API (if it is, the launch-checklist item in § 10.9 becomes a test).
- *(OpenRouter, now fallback-only for this feature but live everywhere else)* the exact
  `data_collection: "deny"` semantics and how they compose with `zdr`; OpenRouter's own DPA terms;
  and whether ZDR endpoints carry a price premium.
- **PDF library choice** for the deterministic pass, and AcroForm coverage in real-estate forms.
- **OCR accuracy** on the scanned documents agents actually receive.

Sources — fetched 2026-07-27:
[OpenRouter, Zero Data Retention](https://openrouter.ai/docs/guides/features/zdr) ·
[ZDR endpoint list (machine-readable)](https://openrouter.ai/api/v1/endpoints/zdr) ·
Anthropic model IDs, pricing, and structured-output support: the `claude-api` skill's model
catalog (`claude-haiku-4-5`, $1.00/$5.00 per MTok, 200K context, 64K max output), consulted
2026-07-27

---

## 11. DocuSign's sender surface (for `sign-me`) — HANDS-ON REVIEW, 2026-07-27

Everything in §§ 7–10 was read from documents. This section and § 12 are the first **operated**
findings: a live account was driven end to end — upload, place fields, send, sign, complete,
download — and the artifacts inspected. Method: `session_login` capture bound to the `browser_*`
tools (see § 12.5 for why that mattered).

**Data discipline.** No counterparties, addresses, property details, or document titles from the
account appear below. Everything recorded is *structure*: what the UI offers, what the artifacts
contain, and what the schema implies. One purpose-made single-page test PDF was sent to an address
Francis controls; that envelope is the only one whose contents are described.

### 11.1 The send flow, as steps

Upload → recipients → message → **place fields** → send. Four screens, one of which is the whole
product. Observations that bear on `sign-me`:

- **Field placement is manual and is the default.** On an arbitrary uploaded PDF, DocuSign places
  nothing. The sender drags every tab onto every page by hand. There is no auto-tagging pass on
  upload — the thing § 10 proposes to build is not a commodity feature we would be re-implementing
  behind a competitor. It is the differentiator, and DocuSign's own default is the manual baseline
  it beats. This is the single most product-relevant finding of the review.
- **An AI-prep container exists in the DOM and renders empty on this plan.** A
  `prepare-ai-tools-container` element is present in the send flow's markup but produces no UI for
  this account. So DocuSign is building toward the same idea, gated to higher tiers. Two
  consequences: the thesis is not eccentric, and the window in which it is a differentiator for a
  solo agent is finite. Do not plan as though the manual baseline is permanent.
- **The field palette is the vocabulary the AI pass must emit.** Signature, Initial, Date Signed,
  Name, Email, Company, Title, Text, Checkbox, Radio, Dropdown, Attachment. A detection pass that
  cannot name a tag in this list has produced something the signing UI cannot render — this list
  is the output schema's enum, not an aspiration.
- **Placement UI is cross-frame.** Field placement runs inside nested `widget.frame` iframes.
  Recorded because it dictates how the Playwright suite must reach the equivalent surface in
  `sign-me`: frame-scoped locators, not page-scoped. See `procedures/test-suite.md`.

### 11.2 Templates are not the leanness lever — evidence against a plausible plan

The obvious way to make repeat paperwork fast is templates: tag the state form once, reuse forever.
It is DocuSign's own answer, and it was the hypothesis going into the review.

**The account contains exactly one template. It is named "[Untitled]", it was created 7/24/2023,
and it was last modified one second later.** It was opened once, never filled in, and never touched
again in three years of active use.

That is a single data point from a single agent and it is not proof of anything general. But it is
the *right* agent — a working solo agent, exactly the target user — and it says something the
feature list cannot: the template was available, free, and obviously applicable, and it still did
not get built. The likely reason is that templates front-load the work. You must decide, before
sending anything, that this form is worth a setup session. The agent with a document to send
tonight never has that session.

**Consequence for `sign-me`:** do not lead with templates, and do not make the fast path depend on
one existing. The AI-detection pass is valuable *precisely because* it needs no prior setup — it
pays off on the first document, from a cold start, which is the only moment a busy agent will
give it. If templates ship at all they should be a **byproduct**: "save this tagging as a template"
offered *after* a successful send, when the work is already done and the marginal cost is one
click. Never a prerequisite, never a setup wizard.

This is recorded as an argued inference from one observation, not a finding. It should be checked
against the agent directly — it is a good question for the same interview that produces Meridian's
task inventory.

### 11.3 The account-settings surfaces worth copying

- **Signatures are a user-level library, not per-envelope state.** The account holds multiple named
  signature styles, each a **signature + initials pair** under one UUID, rendered as two image
  assets (`signature_image`, `initials_image`). Adopt once, reuse across every envelope forever.
- **Every rendered signature image embeds provenance.** The bitmap itself carries `Signed by:
  <name>`, the account GUID, and a "DS" mark — burned into the pixels, not overlaid at signing
  time. The visual artifact is self-attesting even when separated from the certificate.
- The profile splits into My Profile / Privacy & Security / Connected Apps / Identity Wallet /
  Signatures / Stamps / Language & Region. Only **Signatures** is load-bearing for a lean clone;
  Stamps is a JP/hanko market feature and Identity Wallet is the ID-verification upsell.

### 11.4 One real-estate-specific affordance, and what it signals

The signature-creation dialog offers a checkbox: **"Add the REALTOR® logo to my signature."**

Trivial as a feature. Interesting as evidence — it is the *only* vertical-specific control found
anywhere in the sender surface. DocuSign is horizontal software with one real-estate checkbox bolted
on. `sign-me`'s entire premise is the inverse. Where DocuSign has one affordance, a real-estate-first
tool has room for the vocabulary the agent actually uses: buyer/seller/listing-agent as recipient
roles rather than "Signer 1", transaction grouping rather than flat envelopes, and disclosure forms
as a recognized document class rather than an anonymous PDF.

Do not build the REALTOR®-logo checkbox. Note that a licensed-member logo has trademark-usage rules
attached and is not a decoration we can offer unilaterally.

## 12. The signing side and the artifacts (for `sign-me`) — HANDS-ON REVIEW, 2026-07-27

### 12.1 Signature adoption, as a dialog

`ADD SIGNATURE` opens **Create Your Signature**, and the whole adoption model is in it:

| Control | Detail |
|---|---|
| Full Name | required, max 100 chars |
| Initials | required, max 50 chars |
| **CHOOSE** | default tab — 10+ pre-rendered script fonts, radio-selected |
| **DRAW** | freehand canvas |
| **UPLOAD** | image of a wet signature |

Three adoption methods, one of them default and effortless, and **the choice is recorded** — the
certificate names it (§ 12.3). The name/initials split matters: initials are not derived from the
name, they are a separate required field with their own rendered asset, because forms tag them
independently and a middle initial is a choice the signer makes.

For `sign-me`: **CHOOSE plus DRAW is the whole feature.** UPLOAD is the least-used and the most
support-burdened (cropping, transparency, resolution), and it is the one path where the signer can
supply an image of someone else's signature. Ship the two; add UPLOAD only if asked for.

### 12.2 Consent is relationship-scoped, and the sender is the discloser

Two findings that resolve an open question from § 8.

**The ERSD is accepted once per sender relationship, not once per envelope.** The certificate
records acceptance with a timestamp and a stable **consent ID** (`ID: <uuid>`). A signer who has
already consented to this sender does not see the gate again — which explains the § 7 puzzle of a
live document showing no consent screen. It was not missing; it had already been given.

**The disclosing party is the sending account, not DocuSign.** The disclosure's own text opens
*"From time to time, [sender name] (we, us or Company) may be required by law to provide to you
certain written notices or disclosures"*, and every contact route in it — change of email, request
paper copies, withdraw consent — resolves to **the sender's own email address**. DocuSign templates
the document and stores the acceptance; the ESIGN § 7001(c) obligation sits with the agent.

This is the § 7 processor/controller split appearing in the artifact rather than in a contract, and
it is directly binding on `sign-me`'s schema and copy:

- **Consent is a row keyed `(signer, sending account)`, not `(signer, envelope)`** — with a
  timestamp and a stable ID, both of which must appear on the certificate.
- **The ERSD must be templated with the agent's identity and contact details substituted in**, and
  those details must be ones the agent maintains. An ERSD naming `support@apps.odysseyalive.com` as
  the route to withdraw consent would be false — we are not the party the signer is contracting
  with, and § 7001(c) requires the *provider of the notices* to be reachable.
- **Withdrawal has to work**, including the in-session path DocuSign offers: decline to sign, then
  check a box to withdraw consent. That is a real state transition, not a link to a help page.
- **Copy consequence:** we cannot claim the platform "handles ESIGN compliance." It supplies the
  mechanism; the agent supplies the disclosure and remains the discloser. `/copy-truth` should
  treat any claim otherwise as a live capability overclaim.

### 12.3 The Certificate of Completion, field by field

Retrieved as a separate PDF — the download offers **Document** and **Certificate of Completion** as
independently selectable files, plus a "combine into a single PDF" option. Three pages for a
one-page document. Internally the certificate is called the "summary" (`data-qa=
"download-summary-label"`), and the file ships as `Summary.pdf`.

Contents, which is as close to a specification for `sign-me`'s audit trail as anything in this log:

- **Envelope** — Envelope ID (uppercase UUID), Status, Subject, document page count, signature
  count, initials count.
- **Originator** — name, email, **IP address**.
- **Envelope settings, recorded as facts** — `AutoNav: Enabled`, `EnvelopeId Stamping: Enabled`,
  Time Zone. The certificate attests to the *configuration under which signing occurred*, not just
  the events. Worth copying: it forecloses a later argument that the UI behaved differently.
- **Record Tracking** — status (`Original`), holder, timestamp, and `Location: DocuSign`.
- **Per-signer block** — name, email, the rendered signature image, `Security Level` (here
  `Email, Account Authentication`), ID-check method (`(None)`), a signing-mode marker
  (`Freeform Signing` — observed, exact trigger not isolated), **`Signature Adoption: <method>`**,
  the signer's **IP address**, and three timestamps: **Sent / Viewed / Signed**.
- **ERSD acceptance** — timestamp and consent UUID.
- **The full recipient-role taxonomy, printed even when empty** — In Person Signer, Editor
  Delivery, Agent Delivery, Intermediary Delivery, Certified Delivery, Carbon Copy, Witness,
  Notary, Payment. All blank on a one-signer envelope, all still on the page.
- **Envelope Summary Events** — `Envelope Sent — Hashed/Encrypted`, `Certified Delivered — Security
  Checked`, `Signing Complete — Security Checked`, `Completed — Security Checked`, each with a
  timestamp.
- **The complete ERSD text**, appended verbatim as pages 2–3.

Four things to carry into `sign-me`:

1. **The certificate is a separate first-class artifact**, downloadable on its own, and it embeds
   the disclosure text. That is what makes § 9's reproducibility requirement satisfiable years
   later without the platform: the document, the events, and the terms travel together.
2. **Sent / Viewed / Signed are three distinct timestamps.** § 9's case law turns on attribution
   evidence; "viewed" is the one that answers *did they have the chance to read it*, and it is a
   separate row from *did they sign it*.
3. **IP address is captured for both originator and signer.** This is UETA § 9 attribution
   evidence — the "efficacy of the security procedure applied" made concrete. It is also personal
   data under GDPR, which sharpens the `DEC-2026-07-27-erase-document-keep-hash` question: the
   attestation row we proposed retaining after erasure contains **name, email, and IP**. The hash
   was the easy part. Whether *that* row survives an erasure request is still the lawyer question,
   and this review has made it more pointed, not less.
4. **Printing empty role categories is a deliberate choice.** It shows what the envelope was *not* —
   no notary, no witness, no in-person signer — which is itself attestable. Cheap to copy; do it.

### 12.4 What a lean version drops

Against the observed surface, `sign-me`'s first version should carry: upload, **AI field
detection**, recipients with real-estate role names, place/adjust fields, send, remind, signer view,
adopt-signature (choose + draw), sign, certificate, download, void. It should drop, at least
initially: templates as a front-loaded feature (§ 11.2), Stamps, Identity Wallet / ID verification,
payment tabs, bulk send, in-person signing, PowerForms, Connected Apps, the REALTOR® logo checkbox,
and every recipient role except signer and carbon-copy.

Witness and notary are dropped **for now with a flag**, not permanently: § 8 recorded that some
real-estate instruments need notarization, RON is a real market, and § 7001(g) exempts notarization
from ESIGN's general rule. Dropping them is a scope decision about version one, and it constrains
which documents `sign-me` can honestly claim to handle. That belongs in the copy.

### 12.5 Method note — what this review required of the tooling

The review could not be done read-only. It needed an authenticated session that both `web_fetch`
*and* the interactive `browser_*` tools shared, plus a second session so a different actor could
sign. `playwright-mcp` advertised the first and did not implement it — `session_login` captured a
`storageState` that only `web_fetch` and generated suites consumed, while `browser_*` kept a
separate persistent profile. Fixed in that repo the same day (session binding via
`upstream.ts`, cookie-delta evidence so a capture cannot silently succeed while anonymous, and
`session_attach` for re-binding and actor-switching).

Recorded here because it is a **test-suite dependency, not a detour**: `sign-me`'s Playwright suite
must exercise a two-actor flow — sender composes and sends, signer receives and signs — which is
exactly the capability that had to be built. `procedures/test-suite.md` should name the
`session_attach` actor-switch pattern before the module's suite is written.

### Still unresearched, after the hands-on review

- **The field layout of a real state disclosure form** — tag types, density, required-vs-optional
  patterns, and ordering across a 5-page form. This is the highest-value remaining input for the
  § 10 detection pass, because it defines what "correct" looks like for the evaluation set. It was
  **not** taken from the live client envelope in the account: reading it means opening a real legal
  transaction and adding audit events to it, and the privacy rule above bars recording most of what
  it contains. **Better path:** obtain the *blank* published state form and tag that. Same
  structural answer, no client data, no audit events, and it doubles as the first fixture in the
  evaluation set the `evaluation_plan` requires.
- **What DocuSign's AI-prep tools actually do** when enabled — the container was present but empty
  on this plan (§ 11.1). Worth knowing what the competing implementation does before shipping ours.
- **Reminder and expiration mechanics** — not exercised; they are the difference between "sent" and
  "signed" in practice, and an agent chasing a signature is the workflow the module exists for.
- **Void and correct** — both alter a sent envelope, so neither was tested against a live account.
  Their audit-trail representation matters for § 9's attestation story.

Sources — operated 2026-07-27 on a live account with the account holder's permission:
DocuSign send flow (`apps.docusign.com/send`), envelope details, download/certificate path,
signer flow, and profile signature settings (`account.docusign.com/me/signatures`). Certificate of
Completion retrieved and read in full.
