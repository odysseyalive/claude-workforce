#!/bin/bash
# code-eval enforce — Phase 3 (commit gate): no commit/push until the tree matches the last clean review.
# code-eval-enforce-version: 2
trap 'exit 0' ERR
INPUT=$(cat 2>/dev/null) || exit 0
PROJ="${CLAUDE_PROJECT_DIR:-.}"
[ -f "$PROJ/.claude/.code-eval-active" ] && exit 0
CMD=$(printf '%s' "$INPUT" | grep -oE '"command"[[:space:]]*:[[:space:]]*"[^"]*"' | head -1 | sed 's/.*"command"[[:space:]]*:[[:space:]]*"//;s/"$//')
printf '%s' "$CMD" | grep -qE '\bgit[[:space:]]+(commit|push)\b' 2>/dev/null || exit 0
CUR=$( { git -C "$PROJ" diff HEAD 2>/dev/null; git -C "$PROJ" status --porcelain 2>/dev/null; } | sha256sum 2>/dev/null | cut -d' ' -f1)
[ -z "$CUR" ] && exit 0                                     # not a git repo / no sha tool → fail-open
SAVED=$(cat "$PROJ/.claude/.code-eval-reviewed" 2>/dev/null || echo "")
if [ "$CUR" != "$SAVED" ]; then
  {
    echo "BLOCKED by code-eval enforce (commit gate): the working tree changed since the last clean /code-evaluator review."
    echo "Run /code-evaluator review (it stamps the reviewed state on a clean pass), then commit."
  } >&2
  exit 2
fi
exit 0
