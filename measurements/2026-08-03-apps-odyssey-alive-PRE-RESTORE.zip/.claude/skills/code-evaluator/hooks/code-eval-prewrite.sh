#!/bin/bash
# code-eval enforce — Phase 1 (before write): force design direction before code lands.
# code-eval-enforce-version: 2
trap 'exit 0' ERR
INPUT=$(cat 2>/dev/null) || exit 0
PROJ="${CLAUDE_PROJECT_DIR:-.}"
[ -f "$PROJ/.claude/.code-eval-active" ] && exit 0          # loop guard: evaluator's own edits
[ -f "$PROJ/.claude/.code-eval-advised" ] && exit 0         # direction already taken this changeset
FILE_PATH=$(printf '%s' "$INPUT" | grep -oE '"file_path"[[:space:]]*:[[:space:]]*"[^"]*"' | head -1 | sed 's/.*"file_path"[[:space:]]*:[[:space:]]*"//;s/"$//')
[ -z "$FILE_PATH" ] && exit 0
# Scope guard: this is THIS project's design gate. A write into a DIFFERENT repo
# is out of its jurisdiction — gating it strands cross-project work behind a
# marker file that lives here (and an advisor briefed on the wrong codebase).
# Only applied when PROJ is absolute, so an unset CLAUDE_PROJECT_DIR cannot
# fail-open and silently disable the gate.
case "$PROJ" in
  /*)
    case "$FILE_PATH" in
      "$PROJ"/*) ;;                                          # inside the project → gate below
      /*) exit 0 ;;                                          # absolute path elsewhere → not ours
    esac
    ;;
esac
case "$FILE_PATH" in
  *.claude/*) exit 0 ;;                                      # skip skill machinery
  *.md|*.mdx|*.txt|*.rst|*.json|*.yaml|*.yml|*.toml|*.lock|*.cfg|*.ini|*.env) exit 0 ;;  # skip prose/config/data
esac
{
  echo "BLOCKED by code-eval enforce (before-write): get design direction before writing code."
  echo "1. Spawn the code-design-advisor (Task) for this approach — what already exists, what to reuse, what to watch for."
  echo "2. Then mark direction taken and re-attempt: touch \"$PROJ/.claude/.code-eval-advised\""
  echo "   If the code-design-advisor agent type does not resolve, the code-evaluator is not registered. Run /skill-builder code-eval create to restore it. Do NOT fabricate a substitute agent or skip the design check."
} >&2
exit 2
