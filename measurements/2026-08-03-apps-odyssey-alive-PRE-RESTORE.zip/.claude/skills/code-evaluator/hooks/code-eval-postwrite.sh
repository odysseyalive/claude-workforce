#!/bin/bash
# code-eval enforce — Phase 2 (at write): track unreviewed source, emit deterministic ladder signals, remind to review.
# code-eval-enforce-version: 2
trap 'exit 0' ERR
INPUT=$(cat 2>/dev/null) || exit 0
PROJ="${CLAUDE_PROJECT_DIR:-.}"
[ -f "$PROJ/.claude/.code-eval-active" ] && exit 0          # loop guard
FILE_PATH=$(printf '%s' "$INPUT" | grep -oE '"file_path"[[:space:]]*:[[:space:]]*"[^"]*"' | head -1 | sed 's/.*"file_path"[[:space:]]*:[[:space:]]*"//;s/"$//')
[ -z "$FILE_PATH" ] && exit 0
case "$FILE_PATH" in *.claude/*) exit 0 ;; esac           # skill machinery

emit() {                                                   # $1 = plain text -> JSON additionalContext (fail-open)
  local esc
  esc=$(printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g' | sed ':a;N;$!ba;s/\n/\\n/g')
  printf '{"additionalContext":"%s"}\n' "$esc"
}

# rung 5 — dependency manifest grew. Checked BEFORE the code skip-list so package.json/etc. are seen.
case "$FILE_PATH" in
  */package.json|package.json|*/composer.json|composer.json|*/requirements*.txt|requirements*.txt|*/pyproject.toml|pyproject.toml|*/Cargo.toml|Cargo.toml|*/go.mod|go.mod|*/Gemfile|Gemfile|*/build.gradle*|*/pom.xml)
    if git -C "$PROJ" ls-files --error-unmatch -- "$FILE_PATH" >/dev/null 2>&1; then
      N=$(git -C "$PROJ" diff HEAD -- "$FILE_PATH" 2>/dev/null | grep -c '^+[^+]') || true   # tracked: added lines
    else
      N=$(grep -c . "$FILE_PATH" 2>/dev/null) || true                                        # untracked: whole file is new
    fi
    [ "${N:-0}" -gt 0 ] 2>/dev/null && emit "code-eval enforce — rung 5 (dependency): $FILE_PATH grew by ${N} line(s). Before a new dependency, check whether stdlib, a native feature, or an already-installed dep already covers what was added."
    exit 0 ;;
esac

# code files only beyond here
case "$FILE_PATH" in
  *.md|*.mdx|*.txt|*.rst|*.json|*.yaml|*.yml|*.toml|*.lock|*.cfg|*.ini|*.env) exit 0 ;;
esac
PENDING="$PROJ/.claude/.code-eval-pending"
grep -qxF "$FILE_PATH" "$PENDING" 2>/dev/null || printf '%s\n' "$FILE_PATH" >> "$PENDING" 2>/dev/null || exit 0

# Deterministic ladder signals over ADDED lines only (grep, no LLM). New/untracked file -> whole body is new.
# `|| true` on every grep-terminated substitution: a no-match grep returns non-zero, which the ERR trap
# would otherwise turn into a silent fail-open exit before the signal is ever emitted (shell-safety).
DIFF=$(git -C "$PROJ" diff HEAD -- "$FILE_PATH" 2>/dev/null | grep '^+' | grep -v '^+++') || true
[ -z "$DIFF" ] && DIFF=$(sed 's/^/+/' "$FILE_PATH" 2>/dev/null)
SIGNALS=""
SCAF=$(printf '%s' "$DIFF" | grep -noE 'console\.(log|debug)|\bdebugger\b|\bTODO\b|\bFIXME\b|\bdbg!|binding\.pry|pdb\.set_trace' | head -1) || true
[ -n "$SCAF" ] && SIGNALS="${SIGNALS}- scaffolding: debug/TODO marker in added lines ($SCAF) — strip before done.\n"
NAME=$(printf '%s' "$DIFF" | grep -oE '(def|function|fn|func)[[:space:]]+[A-Za-z_][A-Za-z0-9_]*' | head -1 | grep -oE '[A-Za-z_][A-Za-z0-9_]*$') || true
if [ -n "$NAME" ]; then
  REL="${FILE_PATH#"$PROJ"/}"                               # repo-relative, to match git grep's output and exclude self
  HIT=$(git -C "$PROJ" grep -wl -e "$NAME" 2>/dev/null | grep -vxF "$REL" | grep -ivE 'node_modules|vendor|dist|build|/\.' | head -1)
  [ -n "$HIT" ] && SIGNALS="${SIGNALS}- rung 2 (reuse): new \`$NAME\` may duplicate an existing symbol in $HIT — reuse before reimplementing.\n"
fi

# One debounced injection (~120s); actionable signals take priority over the generic reminder.
TS="$PROJ/.claude/.code-eval-nudge-ts"
NOW=$(date +%s 2>/dev/null) || exit 0
LAST=$(cat "$TS" 2>/dev/null || echo 0)
[ $((NOW - LAST)) -ge 120 ] || exit 0
printf '%s' "$NOW" > "$TS" 2>/dev/null
if [ -n "$SIGNALS" ]; then
  emit "code-eval enforce — ladder signals on added code:\n${SIGNALS}Then run /code-evaluator review; nothing commits until the review is clean."
else
  emit "code-eval enforce: source changed and not yet reviewed. Before declaring this code task done, invoke /code-evaluator review on the changed paths. Nothing commits until the review is clean."
fi
exit 0
