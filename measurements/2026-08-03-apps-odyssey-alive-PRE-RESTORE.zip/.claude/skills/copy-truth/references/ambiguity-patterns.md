# Ambiguity Patterns
<!-- Enforcement: HIGH — Pass B of the ground-truth model; the interface-claim-auditor applies this checklist to every string. -->

Pass B is independent of behavior: a string can be perfectly truthful and still be unparseable on first read. This file is the checklist. It also draws the **functional-claim vs brand-claim** line that keeps the gate from flagging aspirational marketing copy.

---

## 1. Anaphora — every pro-form needs one antecedent

A pro-form (a word standing in for a noun) must resolve to a **single** noun phrase already in the sentence. List the candidates; if more than one fits grammatically, it's ambiguous.

| Pro-form | Check |
|---|---|
| `one` | "open a new **one**" → candidates: the noun(s) introduced earlier. If two count nouns precede it (module, ticket), it's ambiguous. |
| `it` / `its` | Resolve to the nearest agreeing singular. Flag if two singulars compete. |
| `them` / `they` | Resolve to a plural antecedent. Flag if the plural is only implied. |
| `this` / `that` | Especially slippery — often refers to a whole clause, not a noun. Flag bare demonstratives with no clear referent. |
| `here` / `there` | Locational pro-forms on a multi-section page. Flag when the place is not named. |

**Worked example.** "Pick a module to read its tickets or open a new **one**." Candidates for *one*: `module` (object of "Pick") and `ticket` (singular of "tickets"). Two candidates → ambiguous. Because "open a new module" is also *false* (users don't open modules), the readings differ in truth value → escalate **SHOULD FIX → MUST FIX**.

## 2. Attachment / coordination — where does the tail attach?

When a sentence coordinates verb phrases or trails a modifier, check what it attaches to.

- **Coordination scope:** "Pick a module to read its tickets **or open** a new one." Does "or open" coordinate with "Pick" (pick-a-module OR open-a-new-X) or with "read" (read-tickets OR open-a-new-X)? Both parse. Flag when the verb's scope is structurally ambiguous and the readings imply different user actions.
- **Dangling modifiers:** a trailing clause ("…, before you ask") that could modify more than one preceding element.
- **List terminators:** "X, Y or Z" where Z could be a third list item or a fresh independent clause.

## 3. Severity rules for Pass B
- Ambiguous antecedent or attachment, both readings equally true → **SHOULD FIX** (clarity).
- Ambiguous, and the competing readings **differ in truth value** → **MUST FIX** (one reading is a false claim).
- Mild awkwardness with a single obvious reading → **CONSIDER**.

---

## 4. Functional-claim vs brand-claim (scope gate — read before flagging Pass A)

copy-truth gates **functional claims**, not brand promises. Misapplying it would flag the home-page mission framing as a "lie," which it is not.

A string is a **functional claim** (in scope for Pass A) when it asserts something **falsifiable about what the interface lets the reader do** — an instruction, a capability, a state, a count, a permission. Test: *could I open the app and find this true or false?*
- "Pick a module to read its tickets" — functional (I can check whether picking a module shows tickets).
- "Log in to open or reply to a ticket" — functional.
- "No forums are open yet" — functional (a state claim).

A string is a **brand/aspirational claim** (out of scope for Pass A; Pass B still applies) when it expresses a value, mood, mission, or promise that isn't a checkable interface behavior.
- "Learn a world by living in it" — brand. Not a UI capability; do not flag as claim-vs-behavior.
- "Immersive worlds spanning history, culture, and language" — brand framing of the catalog.

**Boundary cases:** a sentence can do both. "Start your journey — create a free account" pairs a brand verb ("Start your journey") with a functional claim ("create a free account" — checkable: is the account actually free? does the button create one?). Split it: gate the functional half, leave the brand half. When genuinely unsure, treat it as brand and report it as a CONSIDER note rather than a MUST FIX — the gate should not litigate marketing tone (that's `/wit` + `/my-voice`).
