# Ground-Truth Model
<!-- Enforcement: HIGH — the four reads + two passes are the executable core of the check/gate/sweep modes and the interface-claim-auditor agent. -->

`/cw-accuracy`'s ground truth is a file (the Zenk dictionary). copy-truth has **no single artifact** — the ground truth is *what the component does when it renders*, reconstructed from source. Establish it with four reads, then run two comparison passes. This file is the procedure; the `interface-claim-auditor` agent executes it under context isolation.

---

## Establishing "what the interface actually does" for a string S

### Read 1 — Locate S and its render scope
1. Grep the literal string for its file + line (`rg -n "<text>"`). If invoked with `file:line`, start there.
2. Identify the enclosing component and **which JSX subtree S labels**. Scope matters: a `<Hero subtitle=…>` prop describes the *whole page below it*; a `<p>` inside `<Unauthenticated>` describes *only the logged-out branch*. A claim true for one scope can be false for another.

### Read 2 — Map the conditional/auth guards into a capability table
Enumerate the gates in that subtree that decide what renders and what a user can do:
- Auth wrappers: `<Unauthenticated>`, `<Authenticated>`, `<AuthLoading>`.
- Access/entitlement checks: `hasAccess(...)`, role/`isAdmin` checks, the Module Access Gate.
- State branches: empty-states (`if (x.length === 0)`), loading (`=== undefined`), error states.
- The **trust scope of any data fetch** (`useQuery`/server load): is the data public, or scoped to the signed-in user? (e.g. SupportHub's comment "reading is open to everyone" is load-bearing truth.)

Output a small **capability table** — for each actor, what they can DO on this surface:

| Actor | Can see | Can do |
|---|---|---|
| logged-out visitor | … | … |
| logged-in, no module access | … | … |
| logged-in, with module access | … | … |
| admin | … | … |

### Read 3 — Extract the action claims in S
Tokenize S into:
- **Action claims** — the verbs the copy says the reader can perform ("read its tickets", "open a new one").
- **Implied subject/permission** — who the sentence addresses and what it presupposes they may do ("Pick a module to [you can] open a new one" presupposes *you* may open one).
- **Pro-forms and their candidate antecedents** (hand off to Pass B).

### Read 4 — Collect honest sibling strings
Other strings on the same surface that already describe the flow correctly are corroborating ground truth **and the model for a truthful rewrite**. Example: SupportHub's empty-state "To post, you need to be signed in and using that module" states the real rule the subtitle contradicts.

---

## Pass A — claim-vs-behavior
For each action claim in S:
1. Find the capability-table row(s) that grant it.
2. Determine the **reader the string is shown to** (from S's render scope, Read 1). A subtitle on a public page is read by the generic/logged-out visitor; a string inside `<Authenticated>` is read by a member.
3. Decide:
   - The claim holds for the reader it's shown to → OK.
   - The claim is granted only to a **narrower actor** than the reader it's shown to, and S does not say so → **MUST FIX** (the copy tells a reader they can do something they can't).
   - The claim is true but the *path* it implies is wrong (e.g. "pick a module to open a ticket" when opening also requires login) → **MUST FIX** if it sends the reader down a dead end, else SHOULD FIX.

Worked example (`/support` subtitle): "Pick a module to read its tickets **or open a new one**." Capability table: reading is public; opening a ticket needs logged-in + module access. The subtitle is shown to everyone (public hero). It implies any visitor who picks a module can open a ticket. Mismatch → **MUST FIX**. Truthful rewrite, grounded in the empty-state sibling: name the real precondition (e.g. "Pick a module to read its tickets; opening a new ticket needs an account and access to that module.").

## Pass B — referential/parse ambiguity
Apply [ambiguity-patterns.md](ambiguity-patterns.md). Independent of behavior:
- Every pro-form (one / it / them / this / that) must resolve to a **single** noun phrase in S. Two or more candidates → ambiguous.
- Coordination/attachment: does a trailing verb phrase attach to the main verb or a nested one? ("Pick a module to read its tickets or open a new one" — does "or open" coordinate with "Pick" or with "read"?)
- Severity: ambiguous → **SHOULD FIX**; escalate to **MUST FIX** when the competing readings differ in truth value (here, "open a new module" vs "open a new ticket" — one is false for users).

---

## Output contract
- Findings in MUST FIX / SHOULD FIX / CONSIDER vocabulary (`.claude/skills/text-eval/references/flag-severity.md`).
- For each finding: the quoted span, which read/pass produced it, and why.
- A single proposed truthful rewrite grounded in the sibling strings — **proposed, never applied**. The caller applies it via `/edit`.

## Scope bound (how far to trace)
Behavior sometimes spans files (a Convex query's auth check, a server component's guard). Cap tracing at **the component plus its directly-referenced query/guard (one import hop)**. If the truth depends on logic beyond that hop, report it as an open question rather than guessing — do not silently assume.
