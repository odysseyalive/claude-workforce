# Writing Craft Directives

> **This file has been superseded by [directives.md](directives.md)**, which includes enforcement annotations (which hook or agent enforces each rule).
>
> All directives are preserved verbatim in the new location.
