---
name: writing
description: Load content and communication protocol. Use for emails, messages, correspondence, drafting copy, any written content.
allowed-tools: Read, Glob, Grep, Edit, Write
minimum-effort-level: xhigh
strictness: standard
---

# Content & Communication Protocol

**Write with intention, wit, and humanity.** Text is interface. Every word shapes experience.

## Directives

<!-- origin: user | immutable: true | added: 2026-01-29 -->
> **Let new ideas land before moving on.**
> When a new concept or frame enters the piece, let the reader sit inside it for a beat before pivoting to analysis, callback, or the next idea. The tendency is to introduce a concept and immediately connect it to something else. That rewards the fast reader but loses the one who's still arriving. One more sentence inside the experience — what it feels like, what it looks like in practice, why it's strange — makes the difference between an idea the reader follows and one they inhabit. Accessibility isn't about simpler words. It's about pacing that lets the reader keep up without rushing.

*— Added 2026-01-29, source: comparison of podcast commentary pacing vs. focus article pacing*
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Let new ideas land before moving on. When a new concept or frame enters the piece..." -->
CHECKPOINT — Idea-Landing Gate:
1. After drafting each section, identify every sentence that introduces a new concept, frame, metaphor, or named phrase for the first time in the piece.
2. For each such sentence, count the number of sentences that follow it before the next pivot (analysis, callback, transition, or new concept).
3. IF count < 1 sentence of dwell (concept → immediate pivot) → STOP. Report: "Concept '[phrase]' introduced without dwell. Add one sentence that shows it in practice, describes what it feels like, or names why it's strange, before pivoting."
4. The dwell sentence must be concrete: name a physical detail, a lived moment, or a specific example. A restatement or synonym does not count.
5. IF dwell sentence is abstract restatement → STOP. Report: "Dwell sentence for '[phrase]' is abstract. Replace with one concrete instance."
6. IF every new concept has at least one concrete dwell sentence before pivot → CONTINUE to next gate.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- origin: user | immutable: true | added: 2026-01-29 -->
> **Give the reader something portable.**
> Every piece should leave the reader with one idea they could repeat to someone else without referencing the article. Not a slogan. A practical point that holds up in conversation. If the writing covers a lot of ground, make sure one thread stands above the rest as the thing worth remembering. Beautiful wordplay that doesn't leave the reader with something useful is craft for its own sake. The test is simple: if someone read this and a colleague asked what it was about, could they answer in one sentence?

*— Added 2026-01-29, source: reflection on practicality vs. craft in content creation*
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Give the reader something portable. Every piece should leave the reader with one idea..." -->
CHECKPOINT — Portable-Takeaway Gate:
1. After drafting, write one sentence (≤ 20 words) that completes: "If a colleague asked the reader what this piece was about, they would say: ___"
2. IF the sentence exceeds 20 words → STOP. Report: "Takeaway is too diffuse to be portable. Narrow to one thread."
3. IF the sentence is a slogan, tagline, or abstract theme (e.g., "the importance of X") rather than a practical point that holds up in conversation → STOP. Report: "Takeaway is decorative, not practical. Replace with a point the reader could actually use or repeat."
4. IF you cannot produce the sentence at all → STOP. Report: "No portable takeaway. Revise the piece so one thread stands above the rest."
5. IF the piece covers multiple threads and the takeaway sentence names more than one → STOP. Report: "Multiple threads competing. Elevate one as the thing worth remembering."
6. IF takeaway sentence passes all checks → CONTINUE to next gate. Include the takeaway sentence in the final draft review note.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- origin: user | immutable: true | added: pre-2026-01-29 -->
> **Never compact voice to fit length.**
> When text exceeds a word limit, never shorten sentences, remove texture, or tighten phrasing to fit. Voice has rhythm and breathing room that must be preserved. Instead, identify the least consequential conceptual section and remove it entirely. Update transitions so the reader never senses something was removed. If two passages make the same point, cut the second one. Reduce scope, not voice.

*— Added pre-2026-01-29, source: user instruction*
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Never compact voice to fit length. When text exceeds a word limit, never shorten..." -->
CHECKPOINT — Length-Reduction Gate (triggers ONLY when text exceeds a word/length limit):
1. IF current draft is within the word limit → SKIP this gate.
2. IF over limit, list every distinct conceptual section in the piece (one line per section, name + one-sentence purpose).
3. For each section, mark: (a) does another section make the same point? (b) is this section load-bearing for the portable takeaway (prior directive)?
4. Identify the section with the lowest stakes: not load-bearing AND (duplicates another OR adds the least to the takeaway). Remove that section in full. Do not shorten sentences, strip texture words, or tighten phrasing anywhere in the remaining text.
5. IF two passages make the same point, cut the second one entirely (not a merge, not a compression).
6. Rewrite the transitions on either side of the removed section so the seam is invisible. The reader must not sense anything was cut.
7. IF still over limit → repeat steps 2–6. IF removing further sections would destroy the takeaway → STOP. Report: "Cannot reduce further without losing portable thread. Request length-limit relief or confirm which thread to sacrifice."
8. IF any sentence was shortened, any texture word stripped, or any phrasing tightened for length → STOP. Report: "Voice was compacted. Revert and remove a section instead."
<!-- END ENFORCEMENT ANNOTATION -->

**Enforced directives:** Read [references/directives.md](references/directives.md) for all hook-enforced and evaluator-enforced prose craft directives with enforcement annotations.

<!-- origin: user | immutable: true | added: 2026-01-29 -->
> **Never cite what you can't read.**
> If a reference has a URL, that URL must be accessible and the full text must be read before it can be cited. Search result summaries, snippets, and metadata descriptions are not substitutes for reading the source. If the URL returns a 404, a paywall blocks most of the text, or the content is otherwise inaccessible, stop immediately. Ask the user if they can supply the full text. If they cannot, the source must not be cited, referenced, paraphrased, or used in any way.

*— 2026-01-29, source: user directive on reference integrity*
<!-- /origin -->

<!-- origin: user | immutable: true | added: 2026-02-13 -->
> **Never fabricate Francis's actions or experiences.**
> If Francis hasn't given an indication that he did something, said something, or had a specific interaction, don't put words in his mouth. Instead, propose the angle and ask for approval: "It would be great if we hit this from this angle. Would it be appropriate?" This doesn't curb creativity. The ideas, angles, and framings are welcome. But when a draft needs a personal anecdote or claimed experience, ask before writing it in.

*— 2026-02-13, source: fabricated interaction that didn't happen*
<!-- /origin -->

<!-- origin: user | immutable: true | added: 2026-03-23 -->
> **When referring to math, use accepted statistical notation.**
> Percentages and mathematical values use their standard form (20%, not "20 percent") when presenting data as math. Spelled-out "percent" is reserved for conversational prose where the number isn't the point. This applies to all content types.

*— Added 2026-03-23, source: user directive on data presentation*
<!-- /origin -->

---


<!-- MODEL-LANE-GATE START — auto-generated by /skill-builder route embed; safe to replace -->
<!-- origin: skill-builder | modifiable: true -->
## Model-Lane Preflight

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: /skill-builder route embed (model-lane gate, slim form per the 2026-06-06 2-Brain Harness directive: gates are slimmed, never stripped — this block is the lane checkpoint that travels with the skill through EVERY entry path, including hand-run invocations, which are always permitted. It goes silent when /route already covered the endeavor. Advisory-only per the 2026-06-06 No-Switch-Prompt directive: the gate CANNOT switch the model and NEVER asks the user to — its entire output is one advisory line, which names the exact remedy informationally per the 2026-06-11 named-command advisory directive. -->
CHECKPOINT — Model-Lane Preflight Gate (slim, advisory-only; fires at the TOP of this skill's workflow, before any generative step):
1. SKIP silently IF ANY of: `/route` dispatched this invocation after running its own lane preflight (a lane advisory OR ask already printed, route otherwise ASSESSED the lane this turn, or it was deliberately suppressed — route's coverage extends to the whole endeavor whether route asked, matched, or the user declined, including skills this one chains); this skill's frontmatter sets `model-lane-gate: off`; the session is headless / non-interactive; this gate is executing inside a subagent (a subagent is already model-pinned via its own frontmatter); OR an advisory for this LANE already printed this endeavor AND the active model is unchanged (advise at most once per (lane, active-model) pair per endeavor).
2. Resolve this skill's lane (own `lane:` frontmatter → the Skill→Lane table in `.claude/skills/skill-builder/references/model-lanes.md` → NO LANE) and the lane's Preferred Model. IF no lane resolves OR the preferred-model cell is empty → silent no-op (correctly absent, not a gap). IF this skill declares per-function lanes AND the invocation's resolved mode has its own row → that function's lane governs; otherwise the skill-level lane covers all modes.
3. Read ACTIVE_MODEL from the session system-context line "The exact model ID is …" (strip `[1m]`/`[200k]`, lowercase — model-lanes.md § Active-Model Detection; never an env var or Bash probe). IF the Preferred Model is malformed or names a clearly superseded family → emit the one-line stale-mapping advisory and proceed; never advise from a stale mapping, never validate against a hardcoded list.
4. Compare. Match → silent no-op. Mismatch → print ONE advisory line and PROCEED: "Lane advisory: this skill declares the `<lane>` lane (preferred `<preferred>`); the active model is `<active>` — to align, run `/model <preferred>` and re-invoke; proceeding as-is." Naming the command is INFORMATIONAL (named-command advisory directive, 2026-06-11): NEVER an AskUserQuestion, never a blocking wait (No-Switch-Prompt directive, 2026-06-06). A skill can NEVER switch the session model and never asks the user to.
5. Primary-lane scope. This gate fires ONCE per invocation, for the resolved PRIMARY lane. Cross-lane mid-workflow steps never re-advise — they delegate via this skill's LANE-AGENT-EMBED Delegation Map when present (see .claude/skills/skill-builder/references/lane-delegation.md). Delegation is never a substitute for THIS gate: analytical primary work runs on the analytical main model — never a creative main session orchestrating analytical-pinned agents to dodge the lane.
<!-- END ENFORCEMENT ANNOTATION -->
<!-- /origin -->
<!-- MODEL-LANE-GATE END -->

## Grounding

**Before writing any content, read [reference.md](reference.md)** for voice guidelines (9 sections) and client language rules.

## Enforcement

| Mechanism | Purpose | Blocks |
|-----------|---------|--------|
| `hooks/no-em-dashes.sh` | Block em-dashes and en-dashes | Edit/Write with U+2014/U+2013 |
| `hooks/no-rhetorical-colons.sh` | Block rhetorical colons | Edit/Write with colon patterns |
| `hooks/check-temporal-refs.sh` | Validate temporal references against date anchors | Edit/Write with provable temporal mismatches |
| `agents/writing-validator/AGENT.md` | Validate content against directives, voice principles, and writing protocol | N/A (context: none) |

## Writing Validation (Enforced via Agent)

After generating any draft content, spawn the writing-validator agent (`agents/writing-validator/AGENT.md`). If violations found, fix before presenting to user.

## Self-Heal

If the user corrects you about not following a directive — whether they name it
explicitly, redirect your behavior, express frustration about a repeated issue,
or otherwise indicate you're not complying with a rule defined in this skill —
pause and run the self-heal diagnosis protocol:

Read `.claude/skills/self-heal/references/diagnosis-protocol.md` and follow it.

Only trigger when you can point to a specific directive the user believes was
not followed. General dissatisfaction or style preferences are not triggers.
