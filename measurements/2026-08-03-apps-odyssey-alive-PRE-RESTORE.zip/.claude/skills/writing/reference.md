# Writing Reference

## Voice & Approach

### 1. Lead with Engagement, Not Explanation

- Open with vivid, immediate scenarios that pull readers into experience
- Use questions that invite discovery rather than statements that lecture
- Ground abstract concepts in concrete, tactile details within a sentence or two

### 2. Structure Through Metaphor

- Metaphors aren't decoration; they're architecture. Let them do conceptual work
- Use modern, relatable analogies (think "Uber driver with a PhD in chaos theory")
- Bridge ideas by showing the thought process: "This got me thinking..." "Which brings us to..."

### 3. Balance Voice with Professionalism

- Sharp wit without cynicism; humor that illuminates, not deflects
- Conversational warmth without cutesiness
- Precise, playful language; reach for specificity with a light touch
- Season the conversation, don't drown it. Flavor, not feast.

### 4. Respect the Reader's Intelligence

- Vary rhythm deliberately; mix short declarative statements with longer meditative passages
- Layer in complexity naturally, without academic stuffiness
- Show transparent thinking; let the reader be a companion in discovery
- Don't rush to tidy up contradictions. Let complexity have its due.

### 5. Notice the Human Elements

- Capture texture: small victories, absurdities, moments of genuine insight
- Connect individual experience to larger truths about technology and human nature
- Write as if explaining to someone who notices everything and trusts the reader to keep up

### 6. Summaries and Descriptions Should Invite, Not Explain

- A description is not a summary, it's a hook. Create intrigue, not a synopsis.
- **Bad:** "Exploring the concept of X and what Y teaches us about Z." (explains what you'll learn)
- **Good:** "Step into a world where X meets Y, as we unravel the mystery of Z." (invites experience)
- Use language that beckons: "Step into...", "Discover...", "Unravel...", "Journey through..."
- Create curiosity gaps, hint at what's inside without giving it away
- This applies to: focus descriptions, meta descriptions, page subtitles, card excerpts, social share text

### 7. Never Use Hyphens or Em-Dashes to Break Up Thoughts

- Hyphens in compound words are fine (e.g., "long-term", "real-time")
- But never use dashes to interrupt sentences or add dramatic emphasis
- Use commas, periods, or restructure the sentence instead
- **Bad:** "Most clients start with a project and stay for the relationship---I'm here when things get weird."
- **Good:** "Most clients start with a project and stay for the relationship. I'm here when things get weird."

### 8. Never Use Colons for Rhetorical Emphasis

- Colons for lists, block quotes, and timestamps are fine
- But never use colons to set up a punchline or land a point with dramatic weight
- The "setup: payoff" construction is an AI default that most people never use in speech or casual writing
- Use a period and start a new sentence, or use a question mark
- **Bad:** "Here's the truth: it doesn't work."
- **Good:** "Here's the truth. It doesn't work."
- **Bad:** "The result: a seamless experience."
- **Good:** "The result was seamless."

### 9. Write for the Curious, Not the Credentialed

Assume the reader is intelligent but not specialized. When a concept comes from a specific industry (enterprise sales, supply chain, healthcare), translate it into language anyone can follow without stopping to Google. Don't remove the business concepts. They provide credibility. But gloss them on first use so non-specialists stay in the story. "Deal desks" becomes "the teams who finalize contracts." "Win-loss interviews" becomes "when the company asked prospects why they signed or walked away." The reader should never have to leave the page to understand the page.

## Client Language

**Use respectful language when describing client work.** Clients are long-term partners, not case studies to critique.

**Avoid:** "legacy" (implies outdated/crufty), "old," "outdated," "technical debt"

**Use instead:** "established," "mature," "production," "evolved organically," "battle-tested"

The goal is to honor what they've built while showcasing how we helped. Their codebase isn't a problem; it's a success story that accumulated complexity because the business grew.
