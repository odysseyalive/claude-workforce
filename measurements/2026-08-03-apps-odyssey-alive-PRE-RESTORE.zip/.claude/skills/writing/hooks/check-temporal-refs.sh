#!/usr/bin/env bash
# writing hook: Validate temporal references against date anchors
# Enforces: temporal accuracy in content-creation output
# Scope: Project content files only (skips .claude/ infrastructure, code blocks, frontmatter)
# Spec: skill-builder/references/temporal-validation.md

# Crash sentinel — if this hook itself errors, other hooks can detect it
CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR


_pass() { echo '{"continue":true,"suppressOutput":true,"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"allow","permissionDecisionReason":""}}'; exit 0; }
INPUT=$(cat 2>/dev/null) || _pass

# Scope check: skip .claude/ infrastructure files
FILE_PATH=$(echo "$INPUT" | grep -oP '"file_path"\s*:\s*"[^"]*"' | head -1 | sed 's/.*"file_path"\s*:\s*"//;s/"$//' || true)
if [[ "$FILE_PATH" == *"/.claude/"* ]]; then
  _pass
fi

# Extract content to scan
CONTENT=$(echo "$INPUT" | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    ti = data.get('tool_input', data)
    # For Edit: scan new_string; for Write: scan content
    print(ti.get('new_string', ti.get('content', '')))
except:
    pass
" 2>/dev/null || true)

if [ -z "$CONTENT" ]; then
  _pass
fi

# Run temporal validation via Python (preferred per spec)
python3 -c "
import re
import sys
from datetime import date, datetime

content = sys.stdin.read()

# Strip non-prose content before scanning
# Remove YAML/TOML frontmatter
content = re.sub(r'^---[\s\S]*?---', '', content)
content = re.sub(r'^\+\+\+[\s\S]*?\+\+\+', '', content)
# Remove code blocks
content = re.sub(r'\`\`\`[\s\S]*?\`\`\`', '', content)
# Remove HTML comments
content = re.sub(r'<!--[\s\S]*?-->', '', content)
# Remove image alt text
content = re.sub(r'!\[[^\]]*\]\([^\)]*\)', '', content)

# Temporal phrase patterns
patterns = {
    'quantified': r'(a few|a couple of|several)\s+(days?|weeks?|months?|years?)\s+(ago|later|after|before|earlier|since)',
    'generic': r'(recently|lately|soon|shortly|earlier this|last)\s*(week|month|year|time|spring|summer|fall|winter)?',
    'explicit_range': r'\d+\s+(days?|weeks?|months?)\s+(ago|later|after|before)',
    'relative': r'(yesterday|tomorrow|this\s+(week|month|year)|next\s+(week|month|year)|last\s+(week|month|year))',
}

# Expected day ranges for quantified phrases
ranges = {
    'a few days': (2, 4),
    'a couple of days': (1, 3),
    'several days': (3, 7),
    'a few weeks': (14, 28),
    'a couple of weeks': (10, 18),
    'several weeks': (14, 35),
    'a few months': (60, 120),
    'a couple of months': (50, 70),
    'several months': (60, 180),
    'a few years': (730, 1825),
    'a couple of years': (600, 800),
    'several years': (730, 2555),
}

# Date extraction pattern
date_pattern = r'(?:(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},?\s*\d{4}|\d{4}-\d{2}-\d{2}|\d{1,2}/\d{1,2}/\d{4})'

def parse_date(s):
    for fmt in ('%B %d, %Y', '%B %d %Y', '%Y-%m-%d', '%m/%d/%Y'):
        try:
            return datetime.strptime(s.strip().replace(',', ','), fmt).date()
        except ValueError:
            continue
    return None

found_issues = []

for name, pattern in patterns.items():
    for match in re.finditer(pattern, content, re.IGNORECASE):
        phrase = match.group(0).lower().strip()
        start = max(0, match.start() - 250)
        end = min(len(content), match.end() + 250)
        context = content[start:end]

        # Find date anchors in context
        dates_found = re.findall(date_pattern, context)
        parsed = [parse_date(d) for d in dates_found]
        parsed = [d for d in parsed if d is not None]

        if len(parsed) >= 2:
            # Compare the two dates
            gap = abs((parsed[1] - parsed[0]).days)

            # Find matching range
            for key, (lo, hi) in ranges.items():
                if key in phrase:
                    if gap < lo or gap > hi:
                        found_issues.append(
                            f\"'{match.group(0)}' used for {gap}-day gap between {parsed[0]} and {parsed[1]} (expected {lo}-{hi} days)\"
                        )
                    break

if found_issues:
    print('BLOCKED: Temporal mismatch detected:', file=sys.stderr)
    for issue in found_issues:
        print(f'  - {issue}', file=sys.stderr)
    print('Verify the date relationships before proceeding.', file=sys.stderr)
    sys.exit(2)
" <<< "$CONTENT" 2>&1

RESULT=$?
# Exit 2 (block) only if python explicitly returned 2; anything else is not a block
if [ "$RESULT" -eq 2 ] 2>/dev/null; then
  exit 2
fi
_pass
