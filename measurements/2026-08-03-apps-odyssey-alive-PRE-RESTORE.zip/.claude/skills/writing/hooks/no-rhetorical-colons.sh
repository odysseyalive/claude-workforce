#!/bin/bash
# Hook: Flag rhetorical colons per /writing directive
# Scope: Project content files only (skips .claude/ infrastructure)
# Note: Cannot distinguish all rhetorical vs mechanical colons mechanically.
#       Flags lines with colons that aren't clearly mechanical (URLs, timestamps,
#       list intros, frontmatter). False positives possible — warns, doesn't block.

# Crash sentinel — if this hook itself errors, other hooks can detect it
CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR


_pass() { echo '{"continue":true,"suppressOutput":true,"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"allow","permissionDecisionReason":""}}'; exit 0; }
INPUT=$(cat 2>/dev/null) || _pass

# Scope check: skip .claude/ infrastructure files
FILE_PATH=$(echo "$INPUT" | grep -oP '"file_path"\s*:\s*"[^"]*"' | head -1 | sed 's/.*"file_path"\s*:\s*"//;s/"$//')
if echo "$FILE_PATH" | grep -q '\.claude/'; then
  _pass
fi

# Only check content files (mdx, md, txt, html)
if ! echo "$FILE_PATH" | grep -qE '\.(mdx?|txt|html)$'; then
  _pass
fi

# Extract new content
CONTENT=$(echo "$INPUT" | grep -oP '"(?:new_string|content)"\s*:\s*"[^"]*"' | head -1 | sed 's/^"[^"]*"\s*:\s*"//;s/"$//')

# Skip if no content or no colons
if [ -z "$CONTENT" ] || ! echo "$CONTENT" | grep -q ':'; then
  _pass
fi

# Skip frontmatter-only content (starts with ---)
if echo "$CONTENT" | grep -qP '^---'; then
  _pass
fi

# Remove clearly mechanical colons before checking:
# - URLs (http:// https://)
# - Timestamps (HH:MM)
# - Frontmatter keys (key: value at line start)
# - Image/link syntax (](http)
# - Code blocks
CLEANED=$(echo "$CONTENT" | \
  sed 's|https\?://[^ ]*||g' | \
  sed 's|[0-9]\{1,2\}:[0-9]\{2\}||g' | \
  sed 's|^[a-zA-Z_-]*:.*||g' | \
  sed 's|```[^`]*```||g')

# Check if remaining text has colons that look rhetorical
# Pattern: word(s) then colon then word(s) — not at start of line (which would be a key: value)
if echo "$CLEANED" | grep -qP '(?<!^)\w\s*:\s+[A-Za-z]'; then
  echo "WARNING: Possible rhetorical colon(s) detected. Per /writing directive, colons for emphasis are an AI tell. Use periods, question marks, or restructure instead. Mechanical colons (lists, URLs, timestamps) are fine." >&2
  # Exit 0 — warn only, don't block. Colon distinction requires judgment.
  _pass
fi
_pass
