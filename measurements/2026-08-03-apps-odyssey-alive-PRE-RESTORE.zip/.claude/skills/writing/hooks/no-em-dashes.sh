#!/bin/bash
# Hook: Block em-dashes and en-dashes per /writing directive §7
# Scope: Project content files only (skips .claude/ infrastructure)

# Crash sentinel — if this hook itself errors, other hooks can detect it
CRASH_LOG="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.crash-log"
trap 'echo "$(date -Is) HOOK_CRASH $(basename "$0")" >> "$CRASH_LOG" 2>/dev/null' ERR


_pass() { echo '{"continue":true,"suppressOutput":true,"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"allow","permissionDecisionReason":""}}'; exit 0; }
INPUT=$(cat 2>/dev/null) || _pass

# Scope check: skip .claude/ infrastructure files
FILE_PATH=$(echo "$INPUT" | grep -oP '"file_path"\s*:\s*"[^"]*"' | head -1 | sed 's/.*"file_path"\s*:\s*"//;s/"$//')
if echo "$FILE_PATH" | grep -q '\.claude/'; then
  _pass
fi

# Check for em-dash (U+2014) and en-dash (U+2013)
if echo "$INPUT" | grep -qP '\x{2014}|\x{2013}'; then
  echo "BLOCKED: Em-dashes (—) and en-dashes (–) are forbidden per /writing directive §7." >&2
  echo "Use commas, periods, or restructure the sentence instead." >&2
  exit 2
fi
_pass
