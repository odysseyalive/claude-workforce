# `embed` Command Procedure

Wire the Model Switch Gate into a target skill's creative paths idempotently. This is the codified
form of the four hand-placed integrations (`/image`, `/edit`, `/frontend-design`, `/odyssey-apps`).

```
/model-switch embed <skill> [--modes "a,b,c"] [--remove] [--execute]
```

- **Risk:** high (modifies another skill's files). **Default mode:** display. `--execute` applies.
- `--modes "a,b,c"` — explicit creative-mode list. Omit to derive + confirm (Step 3).
- `--remove` — strip a previously embedded gate from the named skill (Step 7).

---

## Preflight

1. Parse args: `target` (skill name), optional `--modes`, `--remove`, `--execute`.
2. Resolve `.claude/skills/<target>/SKILL.md`. IF it does not exist → STOP. Report: "No skill named `<target>`."
3. **Refusals:**
   - `embed model-switch` → REFUSE ("a skill cannot embed its own gate into itself").
   - `embed route` / `embed skill-builder` → REFUSE (routing/meta skills are not creative paths).
   - `embed image` / `embed edit` / `embed frontend-design` → these already carry a hand-placed
     gate. Report that and treat as a REFRESH-to-canonical only if the user passes `--execute`
     (otherwise display the existing block and stop).

---

## Step 1: Detect subagent-pin delegation (the document-only branch)

Glob `.claude/skills/<target>/agents/*/AGENT.md` and grep each for `^model: claude-opus-4-6`.

- IF one or more authoring subagents are pinned to `claude-opus-4-6` AND the target's creative
  output is authored by those subagents (not inline in the main session) → this is the
  **`/odyssey-apps` case**. A main-session pre-gate is the WRONG fix: the dispatch boundary already
  satisfies the policy. Recommend the **document-only note** (§ Document-Only Note) instead of the
  pre/post gate, and say so in the report. Only proceed to a main-session gate if the user
  overrides with an explicit instruction.
- ELSE → proceed to the standard pre/post gate (Steps 2–6).

State which branch was taken before writing anything.

## Step 2: Classify modes (creative vs. programming)

Read the target's mode/command table (the `## Usage` / `## Modes` / `## Commands` table). For each
mode, classify:

- **Creative** (gate fires): authoring/generating user-facing prose, copy, images, or visual
  layout. Signal verbs: author, draft, write, compose, generate (image/art), paint, design,
  page, intro, blurb, fieldnotes, release notes, dialogue, room/mission/NPC prose.
- **Programming/infra** (gate does NOT fire): build, scaffold, theme, serve, test, verify, debug,
  deploy, convex, auth, migrate, audit, lint, index, mechanics, regen-*, save.

Rules:
- IF `--modes` was passed → use exactly that list; skip derivation.
- IF derivation is unambiguous (every mode falls cleanly into one bucket) → use it and report.
- IF any mode is ambiguous (matches both buckets, or is novel) → present the proposed creative-mode
  list via `AskUserQuestion` and let the user confirm/adjust before writing. Do NOT guess silently.

## Step 3: Pick the insertion target

1. IF `.claude/skills/<target>/references/enforcement-checkpoints.md` exists → append the gate block
   there (the skill's canonical CHECKPOINT home). Place it adjacent to a content/copy-authoring
   CHECKPOINT if one exists (natural companion), else at the end of the file.
2. ELSE IF any `references/enforcement*.md` exists → use it.
3. ELSE → inline the block at the end of `SKILL.md`, separated by a `---` rule and a blank line.

## Step 4: Reconcile (idempotent markers)

First, detect any **pre-marker** gate: grep the chosen target file for the line
`CHECKPOINT — Model Switch Gate` (the gate branch) or `**Model-routing note` (the document-only
branch) WITHOUT surrounding `<!-- MODEL-SWITCH-GATE ... -->` markers. This is the state of the four
hand-placed integrations (`/image`, `/edit`, `/frontend-design`, `/odyssey-apps`) and the
`/odyssey-apps` note, all written before this command existed.

- IF a pre-marker gate is found AND mode is display → **REPORT** "already integrated (pre-marker,
  not under embed's markers)"; do not duplicate.
- IF a pre-marker gate is found AND `--execute` → **WRAP**: add the START/END markers around the
  existing block in place (do not rewrite its tailored text). This brings it under management so
  future runs reconcile cleanly. Never insert a second block.

Then search for the markers `<!-- MODEL-SWITCH-GATE START -->` / `<!-- MODEL-SWITCH-GATE END -->`.

| On-disk | Requested | Action |
|---------|-----------|--------|
| absent (and no pre-marker gate) | embed | **NEW** — insert the block |
| pre-marker gate, no markers | embed | **REPORT** (display) / **WRAP** (`--execute`) — see above; never duplicate |
| present, differs from canonical | embed | **REFRESH** — replace between markers in place |
| present, byte-for-byte canonical | embed | **NOOP** |
| present | `--remove` | **REMOVE** — delete markers + content (+ the preceding `---` rule if `embed` inserted it) |
| absent | `--remove` | **NOOP** |
| one marker only (tampered) | any | **REPORT + SKIP** — surface the malformed file; do not auto-repair |

## Step 5: Generate the gate block

Use this canonical block byte-for-byte; substitute `<MODES>` with the comma-separated creative-mode
list from Step 2 and `<SKILL>` with the target name:

```markdown
<!-- MODEL-SWITCH-GATE START — auto-generated by /model-switch embed; safe to replace -->
<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: /model-switch embed. Project policy: creative work = claude-opus-4-6; programming + testing = claude-opus-4-8. -->
CHECKPOINT — Model Switch Gate (fires in the creative modes of /<SKILL>: <MODES>):
1. Pre-gate. Before authoring or generating creative content in those modes, read the active model from the session environment block. IF it is NOT `claude-opus-4-6` → STOP and output:
   "This is creative work. Switch to the creative model: `/model opus-4-6` — then re-run the command. I'll wait."
   Do not proceed until the user confirms the switch. IF already on `claude-opus-4-6` → skip silently.
2. Post-gate. After the creative output is presented, output (informational, non-blocking):
   "Creative work complete. Switch back to the code model: `/model opus-4-8`"
   The switch back MUST complete before any test / verify / build / deploy / infra work begins — testing and infra are always `claude-opus-4-8`.
3. This gate does NOT fire for the skill's programming/infra modes; those stay on `claude-opus-4-8`.
4. Chained-skill note. IF this skill authors creative copy by chaining /edit or /image, those skills SKIP their own gate in chained mode and defer to this caller-side gate — this block is the enforcer.
5. Delegation exception. IF a creative path is authored by a subagent pinned to `claude-opus-4-6` (via AGENT.md frontmatter), the dispatch boundary already satisfies the policy; the main-session pre-gate is suppressed for that path and inline main-session authoring remains forbidden.
<!-- END ENFORCEMENT ANNOTATION -->
<!-- MODEL-SWITCH-GATE END -->
```

## Document-Only Note (subagent-pin branch from Step 1)

When Step 1 found `claude-opus-4-6`-pinned authoring subagents, do NOT write the pre/post gate.
Instead write this note into the target's dispatch CHECKPOINT (or, if none, the SKILL.md tail),
substituting `<SKILL>` and the pinned subagent path:

```markdown
> **Model-routing note.** Project model policy: creative work = `claude-opus-4-6`, programming + testing = `claude-opus-4-8` (see `/model-switch`). The opus-4-6 subagent pins ARE /<SKILL>'s model-switch gate: creative authoring runs on the creative model inside the dispatched subagent, so NO main-session pre-gate fires and the main session stays on `claude-opus-4-8` for orchestration/integration. Authoring creative content INLINE in the main session — instead of dispatching to the pinned subagent — is FORBIDDEN.
```

## Step 6: Display vs. Execute

- **Display (default):** print, per target file, the action (NEW/REFRESH/REMOVE/NOOP), the chosen
  insertion target, the branch (gate vs. document-only), and the resolved creative-mode list.
  End with: "Use `/model-switch embed <skill> … --execute` to apply."
- **Execute (`--execute`):**
  1. Apply the Step 4 action to the chosen file.
  2. Re-read and verify: exactly one START/END marker pair (NEW/REFRESH), or none (REMOVE); the
     `<MODES>`/`<SKILL>` placeholders are fully substituted; no `origin: user | immutable: true`
     block was touched; frontmatter still parses.
  3. Update SKILL.md § Integration Points: add (or refresh, or remove on `--remove`) the row for
     `/<target>` describing where the gate fires.
  4. IF verification fails → restore the pre-edit content and report; do not proceed silently.

## Step 7: `--remove`

`/model-switch embed <skill> --remove [--execute]` strips the gate block (or document-only note)
from the named skill per the Step 4 REMOVE row, and removes its Integration Points row. Display by
default.

---

## Grounding

- SKILL.md § Model Assignments — the creative/code/test model IDs the block hardcodes.
- SKILL.md § Integration Points — the table this command maintains.
- `odyssey-apps/references/enforcement-checkpoints.md` § Model Switch Gate — worked example (gate branch).
- `nsayka-wawa/references/enforcement-checkpoints.md` § Prose Subagent Dispatch — worked example (document-only branch).
