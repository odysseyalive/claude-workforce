---
name: model-switch
description: "Model gate: ensures creative work (text, images, frontend design) runs on opus-4-6 and programming runs on opus-4-8. Auto-embedded in /image, /edit, /frontend-design; embeddable into any skill via `embed`; also invocable standalone."
allowed-tools: Read, Edit, Write, Glob, Grep, AskUserQuestion
minimum-effort-level: high
strictness: standard
---

# Model Switch

Lightweight gate that ensures creative work (text authoring, image generation, frontend design)
runs on the creative model (**claude-opus-4-6**) and programming work runs on the code model
(**claude-opus-4-8**). Fires automatically as a pre/post checkpoint inside `/image`, `/edit`,
and `/frontend-design`, and is also invocable standalone.

## Usage

```
/model-switch [on|off|status]
/model-switch embed <skill> [--modes "a,b,c"] [--remove] [--execute]
```

| Mode | Description |
|------|-------------|
| `on` | Request switch TO the creative model (opus-4-6). Use before starting creative work. |
| `off` | Request switch BACK to the code model (opus-4-8). Use after creative work completes. |
| `status` | Report which model is currently active and whether a switch is needed. |
| `embed <skill>` | Wire the gate into another skill's creative paths idempotently. Display by default; `--execute` to apply. See § The `embed` Command. |
| *(no arg)* | Same as `status`. |

---

<!-- origin: user | added: 2026-05-25 | amended: 2026-05-28 | immutable: true -->
## Directives

> **"One model does creative work (text, images, frontend design layout). Another does programming. The creative model is claude-opus-4-6. The code model is claude-opus-4-8."**

> **"When /image, /edit, or /frontend-design fires, this gate checks the active model. If it's not the creative model, stop and ask the user to switch before proceeding. After the creative task completes, stop and ask the user to switch back."**

> **"This is a prompt to the user, not a programmatic model change. The user switches via /model in their CLI. The skill's job is to surface the ask at the right moment so the user doesn't forget."**

*-- Added 2026-05-25, source: user directive (Francis Meetze). Amended 2026-05-28 (Francis Meetze): code model raised opus-4-7 → opus-4-8; testing work explicitly assigned to opus-4-8 alongside programming.*
<!-- /origin -->

---

## Model Assignments

| Role | Model | Model ID |
|------|-------|----------|
| Creative (text, images, frontend layout) | Opus 4.6 | `claude-opus-4-6` |
| Programming (code, tests, infra, debugging) | Opus 4.8 | `claude-opus-4-8` |
| **Testing (Playwright, test updates, visual review)** | **Opus 4.8** | `claude-opus-4-8` |

---

## How It Works

### Auto-gate (embedded in other skills)

When `/image`, `/edit` (standalone mode), or `/frontend-design` fires:

1. **Pre-gate:** Before doing creative work, check the current model. If it is NOT `claude-opus-4-6`, output:

   ```
   This is creative work (text/image/design). Switch to the creative model:
   /model opus-4-6

   Then re-run the command. I'll wait.
   ```

   STOP. Do not proceed with the creative task until the user confirms the switch.

2. **Post-gate:** After the creative task is complete and presented to the user, output:

   ```
   Creative work complete. Switch back to the code model:
   /model opus-4-8
   ```

   This is informational — don't block further work, just surface the reminder.

### Standalone invocation

`/model-switch on` — outputs the pre-gate message (switch to creative).
`/model-switch off` — outputs the post-gate message (switch to code).
`/model-switch status` — reports which model is active and whether a switch is appropriate for the next task.

---

## The `embed` Command

Wire this gate into another skill's creative paths idempotently — the codified form of the
hand-placed integrations in `/image`, `/edit`, `/frontend-design`, and (2026-05-28) `/odyssey-apps`.

```
/model-switch embed <skill> [--modes "a,b,c"] [--remove] [--execute]
```

- **Display by default** (it modifies another skill's files — high-risk). Add `--execute` to apply.
- `--modes` names the creative modes to gate; omit it to have the command derive them from the
  target's mode table and confirm before writing.
- `--remove` strips a previously embedded gate from the named skill.

**What it does, in one breath:** resolves the target skill, classifies its modes into creative vs.
programming, checks whether creative authoring is already delegated to `claude-opus-4-6`-pinned
subagents (the `/odyssey-apps` case — where the answer is a *document-only* note, not a
main-session pre-gate), picks the right insertion target (`references/enforcement-checkpoints.md`
if the skill has one, else the SKILL.md tail), writes the gate block between
`<!-- MODEL-SWITCH-GATE START/END -->` markers (idempotent refresh on re-run), and adds the
skill to the Integration Points table below.

**Grounding:** Read [references/embed.md](references/embed.md) for the full procedure, the mode
classification heuristics, the subagent-pin delegation branch, the canonical gate block, and the
reconciliation table (NEW / REFRESH / REMOVE / NOOP). Read it before running `embed`.

---

## Integration Points

The following skills embed this gate:

| Skill | Where the gate fires |
|-------|---------------------|
| `/image` | Before generating any image (pre-gate) and after presenting the final image (post-gate) |
| `/edit` | Before applying changes in standalone mode (pre-gate) and after presenting before/after (post-gate). Does NOT fire in chained mode (the calling skill handles it). |
| `/frontend-design` | Before writing or finalizing any UI markup (pre-gate) and after the design is presented (post-gate) |
| `/odyssey-apps` | **Caller-side enforcer** for the creative-copy modes (`page`, `module-intro`, `fieldnotes`, `forum-rules`, the `module` card blurb, the `release` updates prose). Pre-gate before drafting, post-gate after presenting. Required because the copy is authored via *chained* `/edit`, which defers its own gate to the caller. Lives in `odyssey-apps/references/enforcement-checkpoints.md` § Model Switch Gate. |
| `/odyssey-apps` | **No main-session gate — covered structurally.** Narrative prose is authored by per-command subagents pinned to `claude-opus-4-6` via `AGENT.md` frontmatter; the dispatch boundary IS the gate (the main session stays on `claude-opus-4-8` for orchestration/integration). Inline main-session prose authoring is forbidden. Illustrations chain `/image` (gated above). See `odyssey-apps/references/enforcement-checkpoints.md`. |

### Chained-mode behavior

When `/edit` is invoked in **chained** mode (from another skill like `/odyssey-apps page`), the
calling skill is responsible for the model-switch gate. `/edit` itself skips the gate in chained
mode to avoid double-prompting.

When multiple creative tasks run in sequence (e.g., a full `/odyssey-apps build` that does text +
images + design), the pre-gate fires once at the start and the post-gate fires once at the end.
Don't prompt for a model switch between consecutive creative tasks.

---

## Detecting the Active Model

The skill cannot run `/model` itself (it is prompt-only). The authoritative source for the
active model is the **session environment block** injected at session start — the line reading
`You are powered by the model named … The exact model ID is claude-opus-4-X[…]`. Read the model
ID from there to determine the active model.

To run a check, compare that active ID against the **Model Assignments** table above for the kind
of work about to happen:

- Creative work (text/image/design) → expected `claude-opus-4-6`
- Programming / testing → expected `claude-opus-4-8`

If the active ID already matches the expected role, skip the gate silently. If it does not, emit
the corresponding pre/post-gate switch prompt.

**Known failure mode (why a stale gate "stops working"):** if this table's model IDs drift behind
the model the CLI actually ships (e.g., the table still names `opus-4-7` after the session moved
to `opus-4-8`), every status check reports a spurious mismatch and prompts a switch to a
model that is no longer the intended code model. When the CLI's default code model changes, the
**Directives**, **Model Assignments**, **How It Works** prompt blocks, and **Scope** section must
all be updated together — a partial edit re-introduces the same drift. Last reconciled 2026-05-28
to `claude-opus-4-8`.

---

## Scope

This gate does NOT fire for:
- Reading files, grepping, git operations
- **Running tests (Playwright, inform-precheck, visual review)** — testing is always opus-4-8. When a workflow batches creative work on opus-4-6, the post-gate switch back to opus-4-8 MUST complete before any test execution begins.
- Backend/infrastructure work (Convex, deploy, Docker)
- `/cw-accuracy` checks (linguistic validation, not creative authoring)
- `/text-eval` or `/image-eval` (validation of creative output, runs after the creative model did its work)
- Any skill not listed in the integration table above
