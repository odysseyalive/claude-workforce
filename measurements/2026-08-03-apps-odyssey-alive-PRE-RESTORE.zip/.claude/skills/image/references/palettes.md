## Palette — one system, no variants

**RETARGETED 2026-07-22 for Odyssey Apps.** The source project used six rotating watercolour
palette variants and required a DIFFERENT one per image, to stop a set of independent
illustrations reading as AI monotony. **That rule is inverted here** (SKILL.md § Directive
amendment clause 2): this site's imagery is one drawn SYSTEM, and a system is recognisable
precisely because its colours and measurements repeat. There is one palette, and every asset uses
it.

Authoritative source: `.claude/skills/odyssey-apps/references/palette.md`.

| Role | Token | Hex | Notes |
|---|---|---|---|
| Ground | `--brand-bg` | `#FFFFFF` | Line-work needs air; a crowded field kills the precision |
| Ink / structure | `--brand-accent-primary` | `#123A6B` | Every structural line |
| Secondary field | `--brand-surface` | `#F4F7FA` | Section bands, card fills |
| Accent metal | `--brand-gold` | `#C9A227` | Hairlines, ticks, accent marks ONLY |
| Dark field | `--brand-footer` | `#0C2340` | Dark hero and footer panels |
| On dark | — | `#F2F6FA` / `#E8C766` | Body and gold-accent text on the navy field |

**The gold rule.** `#C9A227` on white is ~2.9:1 — below AA. Gold is a hairline, a tick, or a small
badge fill with dark text on it; never body text, never a link, never a button label on white.
Gold on the navy field (`#E8C766` on `#0C2340`) clears AA and is the ONE place gold may carry type.

**Avoiding monotony without varying the palette.** The original directive's concern is real; the
answer here is composition, not colour. Vary the field type (contour, grid, route, bearing fan,
elevation profile), the density, the crop, and the scale. Never the palette and never the stroke
weight.
