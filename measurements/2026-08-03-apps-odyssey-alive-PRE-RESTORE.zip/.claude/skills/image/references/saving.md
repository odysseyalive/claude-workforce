## Saving Images

> **RETARGETED 2026-07-22 for Odyssey Apps.** Paths for other projects below are inert here.
> This project's paths:
>
> - **Structural SVG** (marks, grids, contours, module glyphs — the majority of the system):
>   `src/components/graphics/` if it is a component, `assets/graphics/` if it is a static asset
>   staged into `public/` by `copy-assets`. **Authored, not generated** (SKILL.md § Directive
>   amendment clause 3).
> - **Generated textural fields:** source to `assets/images/pages/[name].[ext]`;
>   `pnpm run copy-assets` stages to `public/images/` (served at `/images/[name]`). Never write a
>   page image only to `public/` — `copy-assets` wipes and regenerates `public/images/` on every
>   build, so a file left only there is an orphan it deletes.
> - **Module assets:** resolve from `odyssey-apps/references/modules.json` → `assets.images`,
>   i.e. `assets/images/modules/<slug>/`.
> - **Never** hand-populate `public/static/` — that is Velite's gitignored hashed output; a file
>   placed there is untracked and will not deploy.


Image output paths depend on which project is invoking `/image`. Two destinations are supported:

### Odyssey Alive (default)

Save to the Velite/Next.js source layout:

1. Find the most recent image: `find /home/francis/Downloads -maxdepth 1 -type f \( -name "*.jpg" -o -name "*.png" -o -name "*.webp" \) -printf '%T@ %p\n' | sort -rn | head -1`
2. Copy to correct location:
   - **Hero images:** `assets/images/focus/hero/[article-slug]-hero.jpg`
   - **Inline images:** `assets/images/focus/inline/[article-slug]/[image-name].jpg`
   - **Project hero images:** `assets/images/projects/hero/[project-slug]-hero.jpg`
3. Update the MDX frontmatter or inline markdown reference with relative path
4. Run `pnpm dev` or `pnpm build` to process through Velite

**Example paths in MDX:**
```yaml
# Frontmatter hero
image: ../../assets/images/focus/hero/article-slug-hero.jpg
```
```markdown
# Inline image
![Alt text](../../assets/images/focus/inline/article-slug/image-name.jpg)
```

---

### Nsayka Wawa (Inform 7 game)

**REMOVED 2026-07-22.** Cross-repo game-figure paths, the CW label spec, and the map-overlay
composite have no analogue in this project and the referenced files do not exist here. The
clean-base `.orig` contract in SKILL.md's 2026-04-29 directive still stands as a general rule for
any future overlay pipeline.

### Odyssey Apps (Next.js web platform)

When invoked by `/odyssey-apps image <target>`, the destination depends on the art kind. **No
Velite step** for these.

1. Find the most recent image (same `find` command as above).
2. Copy to:
   - **Page/site art** (hero, section illustrations, OG images): save the SOURCE to
     `assets/images/pages/[name].[ext]`. The `copy-assets` prebuild (run by `pnpm dev` /
     `pnpm build`, or on demand via `pnpm run copy-assets`) stages it into `public/images/`,
     served at `/images/[name]`. **Never write page art only into `public/`.** `copy-assets`
     wipes and regenerates `public/images/` (everything but `social/`) from
     `assets/images/pages/` on every build, so a file placed only in `public/` is an orphan it
     deletes. Do NOT hand-populate `public/static/` either; that is Velite's gitignored hashed
     output, wiped on the next velite build.
   - **Module-specific art:** `public/modules/[slug]/[name].[ext]` (staged separately by
     `copy-assets`'s `stageModuleGame()`; this path is committed and not wiped).
3. Reference page art by its web path `/images/[name]` (module art by `/modules/[slug]/[name]`)
   in the page or MDX.
4. Use the dark-blue PNW palette and the cool paper-edge color from the background table.

---

### Detecting which destination to use

- Calling skill `/odyssey-apps` -> Inform 7 destination.
- Calling skill `/odyssey-apps` -> Next.js `public/` destination (above).
- Otherwise (Odyssey Alive context, or unknown) -> Velite destination.

The skill that invokes `/image` tells it which destination is intended (via the prompt or a
`--destination` argument once wired in).
