# Image Set Workflow

**RETARGETED 2026-07-22 for Odyssey Apps.** The source workflow assigned a different palette
variant per image. Here the palette is fixed and consistency is the requirement — see SKILL.md
§ Directive amendment clause 2 and [palettes.md](palettes.md).

When generating a set of textural fields (hero + section assets):

## 1. Confirm this should be generated at all

**SVG first.** Line-work — marks, grids, reticles, contours, module glyphs — is authored as SVG in
the repo, not generated: generated line-work drifts between assets and cannot be recoloured from
palette tokens. Generate only the textural layer that sits BENEATH the SVG structure, and only
where hand-authoring is impractical. If the answer is "this is really a diagram," stop and build
it as a component.

## 2. Plan the SET, not each image

Before generating anything, write down the constants and the variables:

```
Constants (identical across every asset):  palette, stroke weight, tick spacing, mark size
Variables (what makes each asset distinct): field type, density, crop, scale

Hero:      [field type] — [why it fits]
Section 1: [field type] — [why it fits]
Section 2: [field type] — [why it fits]
```

**Rule:** every asset shares the palette and the measurements. Distinction comes from composition.
Two assets with different stroke weights do not belong to the same system.

## 3. Generate in one session against one reference

Generate the first asset, accept it, then hold it as the visual reference for the rest. Drift is
the failure mode of a generated system; a shared reference is the cheapest defence.

## 4. Run the image-set validator (required)

Spawn `image-set-validator` with all asset paths. It checks **consistency** here rather than
diversity — same palette, same stroke weight, same mark language — plus visual clarity and file
locations. If INVALID, fix before proceeding.

## 5. Run `/image-eval` (required)

Invoke with all asset paths for AI-tell checks. Do not skip.

## 6. Verify on the rendered page

Playwright at BOTH viewports before presenting. Hairlines especially: a 1px gold line on white can
vanish on a low-DPI screen — fine in review, broken in production.

## 7. Present

Only after validation, evaluation, and the rendered-page check.

**Do not skip the evaluation step.**
