# Self-Heal History — /image

Log of friction events diagnosed by the embedded self-heal observer and the patches applied or declined.

---

## 2026-05-26 — Odyssey Apps save destination

**Friction:** Site page art ended up an orphan. The /contact "crow catching the moon" hero
(`contact-hero.jpg`) was written only into `public/`, then deleted by the `copy-assets` build
step, leaving the page heroless until restored this session.

**Diagnosis:** SKILL_CAUSED. The skill instructed that Odyssey Apps art be saved into the
Next.js `public/` tree (SKILL.md "Quick Reference (Odyssey Apps)" + `references/saving.md`
§Odyssey Apps), specifically `public/static/` for hero art. Both are disposable build outputs:
`scripts/copy-assets.js` wipes and regenerates `public/images/` from `assets/images/pages/` on
every build, and `public/static/` is Velite's gitignored hashed output. The instruction
contradicted the sibling `/odyssey-apps` art.md, which correctly sources page art from
`assets/images/pages/`.

**Patch applied (in scope):** SKILL.md "Quick Reference (Odyssey Apps)" — changed the
"Site/chrome art" line from `public/static/[name].[ext]` to: source to
`assets/images/pages/[name].[ext]`, staged to `public/images/` by `copy-assets`, with an
explicit orphan warning. Approved by Francis 2026-05-26.

**Companion correction (outside self-heal scope, applied with explicit approval):**
`references/saving.md` §Odyssey Apps was a reference file, which self-heal does not modify. With
the user's approval it was corrected directly to the same `assets/images/pages/` source-of-truth
flow. Noted here for traceability; not a self-heal action.

Project memory: `project_site_images_source_dir`.
