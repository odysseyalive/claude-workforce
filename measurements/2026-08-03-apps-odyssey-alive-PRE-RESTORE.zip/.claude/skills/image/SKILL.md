---
name: image
description: Generate imagery for the Odyssey Apps site via Nano Banana (Gemini 2.5 Flash) — a DRAWN GRAPHIC SYSTEM (surveying vocabulary, blue/white/gold), not watercolor. Line-work is authored as SVG; this skill covers textural fields only. Auto-chains to /image-eval.
allowed-tools: Read, Glob, Grep, Bash, ToolSearch, Skill, Task
minimum-effort-level: xhigh
strictness: standard
---

# AI Image Generation

This project's site uses a **drawn graphic system** — not watercolor. Most of it is authored as
**SVG in the repo**; this skill generates the **textural layer only**. See § Directive amendment
below and `odyssey-apps/references/procedures/art.md` for the full specification.

---

<!-- origin: user | added: 2026-02-12 | immutable: true -->
## Directives

> **"After generating any image, automatically invoke /image-eval to check for AI tells before presenting to user."**

*— Added 2026-02-12, source: skill-builder audit (extracted from IMPORTANT note)*

> **"Always include watercolor base style: wet-on-wet technique, diffused edges, transparent layered washes, medium-rough cold-press paper texture."**

*— Added 2026-02-12, source: skill-builder audit (extracted from Base Style section)*

> **"Every image must be immediately understandable. If a viewer has to ask 'what is this?' the image has failed."**

*— Added 2026-02-12, source: skill-builder audit (extracted from Visual Clarity section)*

> **"Each image in a set should use a different palette variant. Same palette across all images = AI monotony."**

*— Added 2026-02-12, source: skill-builder audit (extracted from Article Image Workflow)*
<!-- /origin -->

<!-- origin: user | added: 2026-04-29 | immutable: true -->
> **Clean-base contract for projects with a post-generation overlay step.** When a project layers a downstream stage onto Nano Banana output (e.g., Nsayka Wawa's `cw-accuracy/tools/overlay.py` for CW labels), the original generated PNG MUST be preserved as `<name>.png.orig` immediately after Nano Banana writes it. The `.orig` file is the immutable clean base; downstream stages (overlay, label correction, re-overlay) read it; nothing in any pipeline overwrites it. Any project tooling that consumes Nano Banana output and produces a labeled-or-otherwise-modified version MUST treat `.orig` as read-only input and write its result to a different filename (e.g., `.labeled.png`). The deploy step (writing `<name>.png` for the consumer that reads it, e.g., Inform 7 Figure declarations) is a final atomic copy from the labeled artifact, never from the live `.orig`. Without this contract, label corrections silently composite onto already-labeled bases and produce visible regressions (the Nsayka Wawa kʰanim/pʰipa correction surfaced this on 2026-04-29).

*— Added 2026-04-29, source: agent investigation (Nsayka Wawa kʰanim/pʰipa label-correction regression). The base-image producer is the natural place to document `.orig` preservation since it's the producer of the clean base.*
<!-- /origin -->

<!-- origin: user | added: 2026-07-22 | immutable: true | supersedes: the watercolor base-style and palette-variety directives, for this project only -->
## Directive amendment — Odyssey Apps uses a drawn graphic system (2026-07-22)

> **"The site's images are a GRAPHIC SYSTEM drawn from the surveying vocabulary — lines,
> reference points, plotted routes, instrument geometry — not photographs and not watercolour."**

*— Added 2026-07-22, source: Francis Meetze, session "site-development" (ratified via
AskUserQuestion). Ledger: DEC-2026-07-22-graphic-system-imagery.*

This is a **snapshot of the skill living inside the apps.odysseyalive.com repo**, and it
supersedes two earlier directives FOR THIS PROJECT. Both earlier texts stand verbatim above and
remain correct for the projects they were written for.

**1. Supersedes "Always include watercolor base style."** Watercolor is odyssey-alive's and
odyssey-skul's language. This site is a quiet sibling with its own: white ground, navy ink, gold
hairlines, built from surveying vocabulary (the line indexing many points, station marks,
bearings, contour fields, instrument geometry). Rationale — the site's own pitch is *trustworthy
AI*, so a visibly generated image is evidence against the argument; site-level imagery must stay
vertical-neutral because the catalog will outgrow real estate; and a drawn system has no uncanny
valley to fall into.

**2. Supersedes "Each image in a set should use a different palette variant."** That directive
prevents AI monotony across a set of independent illustrations, and it is right for that case.
Here it is **inverted**: this is a SYSTEM, and a system is recognisable precisely because its
measurements and colours repeat. Varying the palette per asset would destroy the thing that makes
it read as one design. The monotony the original directive guards against is instead avoided
through **composition and content**, never through palette drift.

**3. Consequence — SVG first, generation second.** Line-work (marks, grids, reticles, contours,
module glyphs) is authored as SVG in the repo, NOT generated: generated line-work drifts between
assets, and SVG recolours from the palette tokens so a hex change restyles everything. This skill
is therefore reduced in scope to **textural fields** — a weathered chart field, an organic contour
map, an atmospheric hero underlay — which sit BENEATH the SVG structure.

**4. The Visual Clarity Gate and the Image-Eval Chain Gate are unchanged** and still apply in
full. "What is this?" is still the test; a texture that reads as noise has still failed.
<!-- /origin -->

<!-- ENFORCEMENT ANNOTATION — auto-generated for Opus 4.7+ literal execution -->
<!-- Source directive: "Every image must be immediately understandable. If a viewer has to ask 'what is this?' the image has failed." -->
CHECKPOINT — Visual Clarity Gate:
1. Before presenting any generated image, state in one sentence what the primary subject is (e.g., "a person carrying a ladder up a hill").
2. Apply the caption test: write a 5-10 word caption for the image (no article context). If the caption requires naming an abstract concept the image only hints at (e.g., "the weight of expertise"), the image is abstract rather than immediately understandable.
3. IF the caption is concrete and names an object, action, scene, or recognizable activity → mark PASS.
4. IF the caption relies on abstract nouns (concepts, metaphors, feelings) with no concrete grounding → STOP. Regenerate with a more concrete subject before presenting.
5. IF the image contains no clearly identifiable subject that a viewer could name in a 5-second glance → STOP. Regenerate before presenting.
6. IF PASS on steps 3–5 → CONTINUE through /image-eval, then present.
<!-- END ENFORCEMENT ANNOTATION -->

<!-- ENFORCEMENT ANNOTATION — Image-Eval Chain Gate (added 2026-05-25) -->
<!-- Source directive: "After generating any image, automatically invoke /image-eval to check for AI tells before presenting to user." -->
CHECKPOINT — Image-Eval Chain Gate:
1. After EVERY image generation (including regenerations after user feedback), invoke `/image-eval` via the Skill tool before presenting the image or declaring it ready. The Visual Clarity Gate (above) runs first, then this gate fires.
2. IF the user requests changes and a new image is generated, the full pipeline re-runs: generation, Visual Clarity Gate, then this Image-Eval Chain Gate. A regeneration is not exempt from evaluation.
3. IF `/image-eval` was not invoked between the most recent Nano Banana call and the presentation of the image to the user, STOP. Report: "Image generated but /image-eval was not run. Invoking now." Then invoke `/image-eval` before continuing.
4. The eval result is advisory (the user decides whether to regenerate), but the eval itself is mandatory. Never skip it.
<!-- END ENFORCEMENT ANNOTATION -->

---


<!-- MODEL-LANE-GATE START — auto-generated by /skill-builder route embed; safe to replace -->
<!-- origin: skill-builder | modifiable: true -->
## Model-Lane Preflight

<!-- ENFORCEMENT ANNOTATION — Opus 4.7+ literal-execution gate -->
<!-- Source: /skill-builder route embed (model-lane gate, slim form per the 2026-06-06 2-Brain Harness directive: gates are slimmed, never stripped — this block is the lane checkpoint that travels with the skill through EVERY entry path, including hand-run invocations, which are always permitted. It goes silent when /route already covered the endeavor. Advisory-only per the 2026-06-06 No-Switch-Prompt directive: the gate CANNOT switch the model and NEVER asks the user to — its entire output is one advisory line, which names the exact remedy informationally per the 2026-06-11 named-command advisory directive. -->
CHECKPOINT — Model-Lane Preflight Gate (slim, advisory-only; fires at the TOP of this skill's workflow, before any generative step):
1. SKIP silently IF ANY of: `/route` dispatched this invocation after running its own lane preflight (a lane advisory OR ask already printed, route otherwise ASSESSED the lane this turn, or it was deliberately suppressed — route's coverage extends to the whole endeavor whether route asked, matched, or the user declined, including skills this one chains); this skill's frontmatter sets `model-lane-gate: off`; the session is headless / non-interactive; this gate is executing inside a subagent (a subagent is already model-pinned via its own frontmatter); OR an advisory for this LANE already printed this endeavor AND the active model is unchanged (advise at most once per (lane, active-model) pair per endeavor).
2. Resolve this skill's lane (own `lane:` frontmatter → the Skill→Lane table in `.claude/skills/skill-builder/references/model-lanes.md` → NO LANE) and the lane's Preferred Model. IF no lane resolves OR the preferred-model cell is empty → silent no-op (correctly absent, not a gap). IF this skill declares per-function lanes AND the invocation's resolved mode has its own row → that function's lane governs; otherwise the skill-level lane covers all modes.
3. Read ACTIVE_MODEL from the session system-context line "The exact model ID is …" (strip `[1m]`/`[200k]`, lowercase — model-lanes.md § Active-Model Detection; never an env var or Bash probe). IF the Preferred Model is malformed or names a clearly superseded family → emit the one-line stale-mapping advisory and proceed; never advise from a stale mapping, never validate against a hardcoded list.
4. Compare. Match → silent no-op. Mismatch → print ONE advisory line and PROCEED: "Lane advisory: this skill declares the `<lane>` lane (preferred `<preferred>`); the active model is `<active>` — to align, run `/model <preferred>` and re-invoke; proceeding as-is." Naming the command is INFORMATIONAL (named-command advisory directive, 2026-06-11): NEVER an AskUserQuestion, never a blocking wait (No-Switch-Prompt directive, 2026-06-06). A skill can NEVER switch the session model and never asks the user to.
5. Primary-lane scope. This gate fires ONCE per invocation, for the resolved PRIMARY lane. Cross-lane mid-workflow steps never re-advise — they delegate via this skill's LANE-AGENT-EMBED Delegation Map when present (see .claude/skills/skill-builder/references/lane-delegation.md). Delegation is never a substitute for THIS gate: analytical primary work runs on the analytical main model — never a creative main session orchestrating analytical-pinned agents to dodge the lane.
<!-- END ENFORCEMENT ANNOTATION -->
<!-- /origin -->
<!-- MODEL-LANE-GATE END -->

## Base Style (Always Include)

**Textural fields only** — line-work is SVG (§ Directive amendment). The prompt skeleton:

```
An abstract [FIELD TYPE] rendered as fine line-work on a white ground. [FIELD DETAILS]. Precise
technical draughtsmanship, engraved or surveyed quality, uniform hairline stroke weight. Deep navy
(#123A6B) lines on white (#FFFFFF), with sparing muted-gold (#C9A227) accent marks. No text, no
numerals, no labels, no signature, no watermark. Flat, no drop shadows, no 3D rendering, no glow.
Aspect ratio [RATIO].
```

`[FIELD TYPE]` is drawn from the system's vocabulary: contour map, survey grid, plotted route,
bearing fan, station-mark field, elevation profile.

**No paper-edge fade.** The watercolor pipeline baked art onto a paper-coloured ground so it
dissolved into the page; that is exactly wrong here. Generated fields get real edges and are
placed as full-bleed, card, or masked panel. If a soft edge is wanted it is a CSS mask on the
asset, so the same file works on white AND on the navy footer.

**Reject on sight:** gradients and glow, 3D or isometric rendering, hand-drawn or sketchy strokes,
varying line weights within one asset, blueprint-white-on-blue (this is navy-on-white), and any
text or numerals — the model renders both badly and neither belongs.

**Consistency is the requirement, not variety** (§ Directive amendment clause 2). Fix stroke
weight, tick spacing, and mark size ONCE and reuse across every asset. Generate a set in one
session against one reference so they read as siblings.

---

## Aspect Ratios

See [references/aspect-ratios.md](references/aspect-ratios.md) for the full table and common use cases.

**Common:**
- Full-width hero banners: 21:9
- Standard hero images: 16:9
- Article headers/cards: 4:3

---

## Palette

Read `.claude/skills/odyssey-apps/references/palette.md` — it is authoritative.

| Role | Token | Hex |
|---|---|---|
| Ground | `--brand-bg` | `#FFFFFF` |
| Ink / structure | `--brand-accent-primary` | `#123A6B` |
| Secondary field | `--brand-surface` | `#F4F7FA` |
| Accent metal | `--brand-gold` | `#C9A227` |
| Dark field | `--brand-footer` | `#0C2340` |
| On dark | — | `#F2F6FA` text, `#E8C766` gold |

**Gold is a hairline, a tick, and an accent mark — never a fill, never text on white** (2.9:1,
below AA). Sparse gold reads as engraved; generous gold reads as a chart. On the navy field gold
text IS legible and is the one place it may carry type.

State the hexes explicitly in every prompt. **Do not vary the palette between assets in a set** —
see § Directive amendment clause 2.

---

## Visual Clarity Over Abstraction

**Every image must be immediately understandable.** If a viewer has to ask "what is this?" the image has failed.

See [references/visual-clarity.md](references/visual-clarity.md) for detailed criteria.

**Quick Rules:**
- Concrete over abstract
- One concept per image
- Grounded in the article's world
- Pass the caption test (if the caption needs explanation, the concept is too abstract)

---

## Article Image Workflow

**Grounding:** Read [references/workflow.md](references/workflow.md) for the full 6-step workflow (palette planning → generation → validation → evaluation → regeneration → presentation).

**Key rule:** Each image uses a different palette variant. Same palette across all = AI monotony. Run image-set-validator agent AND `/image-eval` before presenting. Do not skip evaluation.

---

## Saving Generated Images

See [references/saving.md](references/saving.md) for detailed paths and examples.

**Quick Reference (Odyssey Alive):**
- Hero images: `assets/images/focus/hero/[article-slug]-hero.jpg`
- Inline images: `assets/images/focus/inline/[article-slug]/[image-name].jpg`
- Project heroes: `assets/images/projects/hero/[project-slug]-hero.jpg`

Run `pnpm dev` or `pnpm build` to process through Velite.

**Quick Reference (Odyssey Apps):**
- Page/site art: source to `assets/images/pages/[name].[ext]`; `pnpm run copy-assets` stages it to `public/images/` (served at `/images/[name]`). Never write a page image only to `public/`. `copy-assets` wipes and regenerates `public/images/` on every build, so a file left only there is an orphan it deletes.
- Module art: `public/modules/[slug]/[name].[ext]`

Next.js serves `public/` directly; no Velite step for these.

---

## Image Maintenance

See [references/maintenance.md](references/maintenance.md) for:
- Converting PNG to JPG (with site background color)
- Removing AI signatures without regeneration

---

