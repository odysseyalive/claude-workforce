# Diagnosis Protocol

How to determine whether friction originated in the skill's own instructions.

## When to Run

Run this protocol at **natural task resolution** — the moment when:
- The user signals the task is done ("thanks", "perfect", "that's it", "okay we're good")
- The conversation reaches a clear stopping point
- The user moves to a new topic

Do NOT run mid-session. Do NOT run after every response. Wait for resolution.

## Step 1: Assess the Friction Log

Review the internally held friction log from the session.

If the log is empty → no diagnosis needed. Session was clean. Stop here.

If the log contains only Quality signals (low confidence) and no Explicit or Implicit signals → skip diagnosis. Single low-confidence signals do not warrant a skill update.

If the log contains at least one Explicit or Implicit signal → proceed to Step 2.

## Step 2: Spawn Root-Cause Analyst

Spawn the root-cause-analyst agent (`context: none`) with:
- The skill's full SKILL.md content
- The friction log (signal type, text, turn, hypothesis)
- The task summary (what was being accomplished)
- The target skill's `eval-history.md` (if it exists) — the analyst checks for pending compensations targeting the same instruction area and notes overlap in the verdict

The agent returns one of three verdicts:

**SKILL_CAUSED** — The friction traces to a specific instruction in the skill.
- Must name the exact section and approximate line
- Must quote the specific instruction that caused the misrepresentation
- Must explain the causal chain: "This instruction says X, which led the AI to assume Y, which produced Z"

**REASONING_CAUSED** — The friction was a reasoning error, not an instruction error.
- The skill's instructions were adequate; the AI simply reasoned incorrectly
- No skill update warranted
- Stop here

**AMBIGUOUS** — Cannot determine with confidence.
- If ambiguous: do not propose an update. Ambiguous diagnoses should not trigger skill changes.
- Stop here

## Step 2b: Check Self-Heal History

Check `self-heal-history.md` for the target skill (at `.claude/skills/[skill-name]/self-heal-history.md`).

If the same instruction was previously diagnosed and a patch was declined, do not re-propose the same change. A different angle or framing is acceptable, but the identical patch is not. If no alternative angle exists, stop here.

## Step 3: Spawn Patch Reviewer (only if SKILL_CAUSED)

Before proposing anything to the user, spawn the patch-reviewer agent (`context: none`) with:
- The specific instruction identified as the source
- The full surrounding section for context
- The proposed fix (drafted by the root-cause-analyst)

The patch-reviewer checks:
1. **Minimality** — Is this the smallest change that fixes the root cause? If a single sentence can be clarified, do not rewrite the paragraph.
2. **Completeness** — Does it actually fix the misrepresentation? A minimal fix that doesn't solve the problem is not a fix.
3. **Directive safety** — Does it touch any directive? If yes, REJECT — directives are out of scope.
4. **New ambiguity** — Does the proposed change introduce a new unclear term or edge case?

Patch-reviewer returns: APPROVED or REJECTED with reason.

If REJECTED → do not propose to user. The proposed patch was not good enough. Stop here.

## Step 4: Present to User (only if patch-reviewer APPROVED)

Present the proposal naturally, as part of the conversation — not as a system alert.

Format:

```
I noticed I had some trouble with [brief description of what went wrong] earlier.
I think it came from how this skill describes [specific area].

Here's what I'd suggest changing:

**Current:**
[Exact quoted text of the current instruction]

**Proposed:**
[Exact quoted text of the proposed replacement]

Would you like me to update the skill? This won't affect anything else — just this section.
```

Tone: conversational, not clinical. "I noticed" not "DIAGNOSIS RESULT:".
This is a natural offer, not a system report.

## Step 5: Apply (only with explicit user approval)

If user approves:
1. Read the skill's current SKILL.md
2. Apply the exact change shown in the diff — nothing more
3. Confirm: "Updated. The skill now says [new text]."

If user declines:
1. Acknowledge: "No problem — I'll leave it as is."
2. Do not log, do not retry, do not mention it again.

## Root Causes That Are In Scope

The following skill content can be updated by self-heal:

| Content Type | In Scope? | Rationale |
|-------------|-----------|-----------|
| Workflow step descriptions | YES | Common source of misrepresentation |
| Context/framing statements | YES | Often cause false assumptions |
| Clarifying language and examples | YES | Can be improved for precision |
| Scope descriptions | YES | Ambiguous scope causes overreach or underreach |
| Directives | **NEVER** | Sacred — user's exact words |
| Reference file content | NO | Separate concern — not in scope for self-heal |
| Agent definitions | NO | Too structural — separate optimization concern |
| Frontmatter | NO | Structural — not a source of session friction |

## Surgical Means Surgical

One instruction. One change. If the diagnosis points to two separate instructions as sources of friction, that is two separate sessions' worth of self-heal. Do not batch. Do not improve adjacent things. The task list is the contract.
