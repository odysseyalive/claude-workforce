# The three habits `.claude/skills/my-voice/SKILL.md` most strongly forbids

Run 2026-07-31-04 | content-copywriter | source read in full, 158 lines.

Ranked by how hard the file itself pushes. Each of the three carries a flat prohibition in the
prose *and* a hard stop in one of the file's CHECKPOINT gates. Habits backed only by a preference
did not make the cut.

## 1. Inventing what Francis thinks, said, or lived through

Collaboration Principles, item 1:

> **Francis's ideas lead.** The AI helps articulate, refine, and structure thoughts Francis has
> already expressed or hinted at. Never invent positions, opinions, or experiences.

Item 5 closes the gap where a writer might quietly fill in a belief:

> **His name, his words.** Content published under Francis's name must reflect his actual thinking.
> If you're uncertain what he believes, ask.

The Humanity-First Calibration Gate makes it a stop rather than a preference:

> 4. IF a signal was invented without grounding in Francis's actual language, lived experience, or
> the source material → STOP. Replace with a grounded signal or remove.

## 2. Faking imperfection so the writing reads human

From the immutable user directive added 2026-02-25:

> Never fake imperfections — Francis's rough edges are real.

Same gate, step 3, with the remedy named so the writer cannot reach for invention under pressure:

> Do NOT fabricate imperfection — pull specificity from source material or ask Francis.

The forbidden move here is narrow and easy to miss. Cultivating human signals is what the file asks
for; manufacturing them is what it bans. A hedge Francis never had is the failure case.

## 3. Polishing the texture out into clean, generic prose

Collaboration Principles, item 3:

> **Preserve rough edges.** Francis's voice has texture. Don't polish away the humanity in pursuit
> of "clean" prose.

The gate gives it a test a draft can actually fail:

> 5. Apply the calibration test: read the draft and answer "Does this sound like a specific person
> thinking, or an average smart writer performing?" IF the answer is the latter → STOP and revise.

And a floor underneath the test:

> 3. After drafting, IF the humanity signal count per 200 words < 3 → STOP.

Two near-misses that did not rank: deploying wit as jokes rather than rhetorical work, and drafting
before reading the calibration texts. Both are real rules in the file, but the first is scoped to
argumentative pieces only and the second is a prerequisite rather than a habit.

---

## Verification

Ran the Tier 1 grep from `.claude/skills/text-eval/references/text-tells.md`
**§ Tier 1 — Surface tells**, the section the catalog marks grep-able. Located and scanned with
`Bash`, per the handbook.

**Counted:** my own authored prose in this file, listed by span.

- The title line and the run-metadata line
- The three-sentence preamble under the title
- The lead-ins to each quotation (`Collaboration Principles, item 1:`, `Item 5 closes…`,
  `The Humanity-First Calibration Gate…`, `From the immutable user directive…`, `Same gate, step 3…`,
  `Collaboration Principles, item 3:`, `The gate gives it a test…`, `And a floor underneath the test:`)
- The three-sentence commentary paragraph under item 2
- The closing near-misses paragraph
- The three `##` section headings

**Excluded, each named:**

- All eight blockquoted spans (`>` lines) under items 1, 2, and 3. These are verbatim quotation from
  `my-voice/SKILL.md` and carry that file's own em-dashes, arrows, and internal quote marks.
- Inline backticked paths and identifiers: `.claude/skills/my-voice/SKILL.md`,
  `.claude/skills/text-eval/references/text-tells.md`, `Bash`, and the eight backticked lead-in
  fragments in the counted-spans list above.
- This § Verification section itself, per the handbook.

**Result by the catalog's ladder:** zero Tier 1 hits in 245 words of counted prose.

- Em-dash / en-dash **[hard]**: 0 in counted prose. The file holds 3 em-dashes and 0 en-dashes, and
  all 3 sit inside excluded spans (two in blockquoted source text, one in the § heading cited above).
- Invisible Unicode **[hard]**: 0 file-wide, scanned by Unicode category plus the zero-width,
  narrow-no-break, bidi, tag-block, and Private Use ranges.
- Pipeline artifacts **[hard]** (citation residue, unfilled placeholders, cross-markup leakage):
  0 file-wide.
- Rhetorical colons: 0. Nine colons appear in counted prose. Eight introduce a quotation and one
  introduces the two-item near-miss list, and the catalog's test exempts both.
- AI vocabulary, filler phrases, Latinate bias, copulative avoidance, superlative stacking,
  "From X to Y", sentence-frame openers, cutoff disclaimers, connector overuse: 0 hits.
- Chat-frame leakage (wrapper, sycophantic openers, canned assurances, prompt echo): 0 hits.
- Curly/straight quote seam: 0. The file holds no curly quote or curly apostrophe at all, in either
  counted or excluded spans, so there is no mixed pair to flag.

No `MUST FIX` rung reached and no `[hard]` row hit, so by the handbook's mapping this is **PASS
with the finding stated**. The finding to state: the em-dash **[hard]** row and the quote-seam row
both come down entirely to the exclusion boundary. If quoted spans were counted, the em-dash row
alone would push this to FAIL, and a verbatim-quotation task cannot avoid that. The boundary is
doing real work here, which is why every excluded span is named above.
