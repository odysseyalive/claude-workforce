# eng-code-evaluator — findings report

- **Run-id:** 2026-07-31-06
- **Artifact reviewed:** `.claude/skills/code-evaluator/references/mistake-taxonomy.md`
- **Catalog judged against:** the same file (`<!-- code-eval-ref-version: 3 -->`, `origin: skill-builder | modifiable: true`)
- **Nature of this run:** an *inventory* of the catalog's declared mistake classes, per the work order.
  No source-code diff was under review, so no class was applied to any code. See § Checks not run.

## 1. Mistake classes defined

The file defines **24** mistake classes, in two tables. Every class below cites the heading it sits
under; the quoted name is the row's `Class` cell.

### Cited to § "Group 1 — Structural (the classic taxonomy)" — 12 classes

| # | Class | What (as stated under this heading) |
|---|-------|-------------------------------------|
| 1 | Unused files | Files unreachable from any entry point |
| 2 | Unused exports/symbols | Exported but never imported |
| 3 | Unused types | Type aliases/interfaces never referenced |
| 4 | Unused dependencies | Declared in manifest, never imported |
| 5 | Unlisted dependencies | Imported but missing from the manifest |
| 6 | Unused members | Enum values / class methods never used |
| 7 | Duplicate code | Copy-pasted / near-identical logic |
| 8 | Circular dependencies | Import cycles in the module graph |
| 9 | Re-export cycles | Barrels re-exporting each other in a loop |
| 10 | Complexity hotspots | High cyclomatic/cognitive functions |
| 11 | Complex × untested | High complexity + low coverage (CRAP) |
| 12 | Stale suppressions | Ignore comments that no longer match |

### Cited to § "Group 2 — AI-specific anti-patterns" — 12 classes

| # | Class | What (as stated under this heading) |
|---|-------|-------------------------------------|
| 13 | Reinvented helper | New function duplicating an existing util |
| 14 | Reinvented stdlib/native | Hand-rolled what the standard library or platform already ships |
| 15 | Needless new dependency | A new dependency added for what a few lines, an installed dep, or a native feature already cover |
| 16 | Speculative existence (YAGNI) | Code written for a need that is not real yet |
| 17 | Leftover scaffolding | Debug prints, TODO stubs, commented-out code, unused locals from an abandoned approach |
| 18 | Over-abstraction | Premature generic/indirection for one caller |
| 19 | Pattern drift | New code ignores the file's established idiom |
| 20 | Unused imports | Imports added then not used |
| 21 | Dead export from new code | Exported a symbol nothing imports |
| 22 | Silent breadth | Broadened a change beyond the task (bonus edits) |
| 23 | Copy-paste-and-tweak | Cloned a block and edited a few tokens |
| 24 | Swallowed errors | `catch {}` / bare `except: pass` added |

Both tables carry the columns `Class | What | Why it matters | Signal` — recorded here because the
absence of a fifth column is the evidence for § 2.

## 2. Does the file declare ordering or severity among the classes?

**No. The file declares no severity, priority, or confidence ranking over its 24 mistake classes.**

Evidence, cited:

- § "Group 1 — Structural (the classic taxonomy)" and § "Group 2 — AI-specific anti-patterns" each
  carry exactly four columns — `Class`, `What`, `Why it matters`, `Signal`. There is no severity,
  priority, tier, or confidence column, and no row states one in prose. The two groups are labelled
  by *kind* (structural vs AI-specific), not by rank; the § "Mistake Taxonomy" preamble describes
  them as "the first group" and "the second group" with no claim that one outranks the other.
- Per the handbook's § Procedure step 5, nothing above is ranked here. The order in § 1 is the
  file's own table order, and table order is not asserted to be a ranking.

**Four orderings the file *does* declare — none of them a ranking of the classes.** Recorded so the
"no ordering" answer is not read as "no ordered content anywhere in the file":

1. § "The minimalism escalation ladder (prevention order — L1)" declares an explicit 7-rung ordered
   ladder (exist at all → already in codebase → stdlib → native → installed dep → one line → minimum
   code), with the tie-break "Two rungs work → take the higher one." Its own heading names it
   *prevention order*. It orders **remedies**, and applies to only three of the 24 classes — the
   heading's body scopes it to "the three 'reinvented / needless / speculative' classes above."
2. § "Over-engineering evaluation (rubric + self-calibration — L2/L3)" declares a 0–3 severity scale
   ("0 — minimal… 3 — clearly over-engineered") plus a reporting threshold ("Only scores ≥2 are
   reported… 0–1 pass silently"). This is a severity scale over **individual candidate constructs**
   scored during a review, not over the taxonomy's classes; no class is assigned a score.
3. § "Minimalism safety floor (NEVER on the chopping block)" declares a **precedence** rather than a
   ranking: five items (input validation at trust boundaries, error handling that prevents data
   loss, security measures, accessibility basics, anything the user explicitly requested) MUST NOT be
   recommended for removal, and "flagging one of them as 'over-built' is itself a defect." This
   overrides findings; it does not order the classes among themselves. The same section exempts
   marked shortcuts carrying an intent marker.
4. § "How the layers use this taxonomy" declares a **routing** order — L1 advisor takes Group 2
   prevention, L2 reviewer runs "the full Group 1 + Group 2 checklist", Sweep runs Group 1 at scale —
   and one handling rule, "over-engineering is report-only, never auto-fixed." Routing by layer is
   not severity.

**One dangling reference, cited.** § "How the layers use this taxonomy" says the L2 reviewer "tiers
findings, and applies only HIGH-confidence, guard-cleared fixes." The file therefore *presupposes* a
confidence tiering but **does not define the tiers and assigns no class to one**. Anyone needing that
ordering must get it from a file outside this one — a section I did not read (see § 4).

## 3. Citation audit (handbook § Verification 1)

- Claims made in this report: 24 class entries + 1 ordering verdict + 4 declared-ordering entries +
  1 dangling-reference note = **30**.
- Claims carrying a citation to a heading in `mistake-taxonomy.md`: **30**.
- **Findings/claims without a catalog citation: 0.** This is the handbook's mechanical check and it
  passes.

## 4. Catalog sections read, and not read (handbook § Verification 2)

**Read — all 7 headings of `mistake-taxonomy.md`, in full:**

1. `# Mistake Taxonomy — what an AI coder commonly gets wrong` (preamble)
2. `## Group 1 — Structural (the classic taxonomy)`
3. `## Group 2 — AI-specific anti-patterns`
4. `## The minimalism escalation ladder (prevention order — L1)`
5. `## Minimalism safety floor (NEVER on the chopping block)`
6. `## Over-engineering evaluation (rubric + self-calibration — L2/L3)`
7. `## How the layers use this taxonomy`

**Not read — zero sections of `mistake-taxonomy.md` were skipped.**

**Not read — sibling files in the same `references/` directory, listed via `Bash`, opened by nothing
in this run.** They are out of the handbook's § Scope (which names `mistake-taxonomy.md` only), and
the first two are load-bearing for anything beyond an inventory:

- `cross-file-detection.md` — the taxonomy's preamble states "Detection method lives in
  cross-file-detection.md". Unread, so the `§2.3`, `§4`, and `§5` cross-references in the Group 1
  Signal column are **unresolved** in this report.
- `guards.md` — the preamble states "false-positive guards live in guards.md". Unread, so
  `guards.md #7` (dynamic dispatch, cited by the Unused members row) and `guards.md #21` (intent
  markers, cited by the safety floor) are **unresolved**.
- `gotchas.md`, `native-tool-map.md` — not referenced by `mistake-taxonomy.md`; not read.
- `.claude/skills/code-evaluator/SKILL.md`, `agents/`, `hooks/` — not read. Per handbook § Procedure
  step 2 and § Guardrails, the skill is never invoked; only files are read by path.

## 5. Checks the catalog demands that were NOT run (handbook § What this review does NOT cover)

Stating this every time is mandatory; a review that omits it reads as complete and is not.

**Ran:** one check — the mechanical citation count in § 3. Nothing else.

**Demanded by the catalog, not run here:**

- **Self-calibration gate** — § "Over-engineering evaluation (rubric + self-calibration — L2/L3)"
  requires scoring the known `@lru_cache` / `ComputeCache` pair *first* and treats a read as
  untrustworthy unless it separates them. Not run: no over-engineering scoring was performed, because
  the artifact is a markdown catalog and no code candidate was in scope. No score in this report.
- **Rubric scoring (0–3) and finding tiers** — same heading. Not run, same reason. No finding here
  carries a severity, and none should be read as carrying one.
- **The Group 1 + Group 2 checklist against a diff** — § "How the layers use this taxonomy" defines
  that as the L2 reviewer's job, executed "via cross-file-detection.md". Not run: no diff was given,
  and `cross-file-detection.md` was not read (§ 4).
- **The L1 prevention pass** — § "The minimalism escalation ladder (prevention order — L1)" is a
  pre-write advisory walk. Structurally impossible in a post-hoc read; not run.

**Agent-based verification — not runnable by any employee here.** § "How the layers use this
taxonomy" allocates work to three distinct layers (L1 advisor, L2 reviewer, Sweep). This employee
carries `disallowedTools: Agent` and cannot dispatch any of them, and per the handbook every other IC
— including whichever produced an artifact under review — carries the same restriction. Only a Lead
or the main session can spawn. Note for accuracy: `mistake-taxonomy.md` itself contains **no explicit
directive to spawn an agent**; the multi-layer execution is implied by the layer allocation, not
commanded. Whether the unread `SKILL.md` commands spawns is unknown to this run.

**No clean review is claimed.** Zero code was judged in this run; the result above is an inventory,
not a passing review.
