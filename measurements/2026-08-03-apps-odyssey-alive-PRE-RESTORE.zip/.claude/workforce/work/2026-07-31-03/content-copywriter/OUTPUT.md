# The three habits `my-voice` most strongly forbids

Run-id: 2026-07-31-03
Employee: content-copywriter
Source read: `.claude/skills/my-voice/SKILL.md` (15k, read in full)

Ranked by how the file itself enforces them. Each of the three is stated more than once, and each
carries a STOP-level or never-worded prohibition. Quotes are exact.

## 1. Inventing what Francis thinks, believes, or has lived

> Never invent positions, opinions, or experiences.

(Collaboration Principles, item 1.) The same prohibition is restated as a publishing condition:

> Content published under Francis's name must reflect his actual thinking. If you're uncertain what he believes, ask.

(Collaboration Principles, item 5.) And the Humanity-First Calibration Gate turns it into a stop:

> IF a signal was invented without grounding in Francis's actual language, lived experience, or the source material → STOP. Replace with a grounded signal or remove.

## 2. Faking human imperfection

> Never fake imperfections

(Directives block, 2026-02-25, marked `immutable: true`.) The gate that implements the directive
repeats it as an instruction inside the drafting loop:

> Do NOT fabricate imperfection

(Humanity-First Calibration Gate, step 3.) The forbidden habit is manufacturing texture the writer
does not have, so the two rules work as a pair: do not invent the person, and do not invent the
person's flaws.

## 3. Polishing the texture out, and writing generically competent prose in its place

> Don't polish away the humanity in pursuit of "clean" prose.

(Collaboration Principles, item 3, under *Preserve rough edges*.) The calibration test in the gate
names the failure mode and stops on it:

> Does this sound like a specific person thinking, or an average smart writer performing?

(Humanity-First Calibration Gate, step 5, which ends: IF the answer is the latter → STOP and revise.)

## Runners-up, and why they placed below

Two further prohibitions are real but weaker in this file. Guessing at direction is forbidden by
"Ask before assuming" (item 2), which carries no gate. Jokes in place of Twain-style wit are
forbidden by "IF a moment is a joke ... → FLAG and revise" (Satirical Wit checkpoint, step 7), which
flags rather than stops and applies only to argumentative pieces.

## Verification

Grepped against `.claude/skills/text-eval/references/text-tells.md` § Tier 1 — Surface tells, the
section that catalog marks grep-able. Every Tier 1 row was scanned: character and punctuation,
pipeline artifacts, vocabulary and phrasing, chat-frame leakage.

Scope of the count, per handbook Verification rule 3 ("count the draft only"): the deliverable
above, up to this section. This Verification section is the report, it quotes the catalog, and it is
excluded. All three segments were counted anyway and are stated separately, so nothing is hidden by
the scoping.

| Segment | Tier 1 signals |
|---|---|
| Authored draft prose (rule 3 scope) | **0** |
| Blockquoted source from `my-voice/SKILL.md` | 0 |
| This Verification section (excluded) | 1 |

That one signal is an em-dash sitting inside the catalog's own name for the section being cited, in
the first line of this section. It is the exact case rule 3 describes: a document that quotes the
catalog matches it. Counted and stated rather than quietly dropped.

Clustering rule applied, from the catalog's own § How to apply this library, item 1: "1 signal in a
passage → CONSIDER; 2 → SHOULD FIX; 3+ → MUST FIX", with `[hard]` rows not subject to clustering and
never demoted. At 0 signals in scope, the draft does not reach CONSIDER, so it passes.

Rhetorical colons were reviewed by hand, since that row is a judgment call rather than a regex. Four
candidates, all excluded by the row's own carve-out for list introductions, labels, and quotation
lead-ins. None is a setup-punchline.

Note on the catalog, not on this draft: text-tells.md points policy at
`[creative-integrity.md](../creative-integrity.md)`, which resolves to
`.claude/skills/text-eval/creative-integrity.md` and does not exist. The real file is
`.claude/skills/skill-builder/references/creative-integrity.md`. The clustering rule was applied
from the copy stated inline in text-tells.md § How to apply, so the broken link did not block the
check.
