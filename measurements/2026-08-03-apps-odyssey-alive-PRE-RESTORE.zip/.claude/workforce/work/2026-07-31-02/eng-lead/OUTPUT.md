# eng-lead — OUTPUT

Run-id: 2026-07-31-02
Source: `.claude/skills/odyssey-apps/references/port-inventory.md`
Task: the three largest things the port strips.

## The three largest strips

1. **The Inform 7 / Glulx game half and its save bridge.** The port deletes the entire authoring
   and runtime layer of the game — `Nsayka Wawa.inform/`, `Nsayka Wawa.materials/`, `gameinfo.dbg`,
   `Mechanics.md`, `library/`, `research/`, `tools/` (line 79-80) — together with everything that
   carried saves between the game and the site: `convex/saves.ts`, the asyncglk `Provider`/`Dialog`
   override, Parchment, `public/modules/<slug>/` game assets and `stageModuleGame()` in
   `copy-assets.js` (lines 81-84), plus the `play.gblorb` Git-LFS provisioning that shipped it
   (line 113).

2. **The whole progress/score model and the two public surfaces built on it.** `convex/progress.ts`,
   `src/components/progress/`, `src/lib/score.ts`, the `playerProgress` / `missionProgress` /
   `vocabProgress` tables, the kəmtəks STATE-line reader and the DEC-037 snapshot carryover contract
   all go (lines 90-92), and with them the leaderboard (`convex/leaderboard.ts`, `leaderboardEnabled`,
   `leaderboardOptIn`, `/leaderboard` — lines 93-94) and the explorer vocabulary surface
   (`convex/explorer.ts`, `/explorer`, `/explorer/[username]` — lines 95-96), which the file notes has
   no analogue here.

3. **The public support forum, and the GDPR anonymize-in-place machinery that existed only to serve
   it.** `convex/forumRules.ts`, `src/components/forum/` (incl. `ModuleForum.tsx`), the `/forum-rules`
   route, the `forumRules` + rules-version + re-agreement tables, the `forumEnabled` flag and its
   `moduleForumEnabled` gate, public thread reading in `tickets.ts` and `tests/forum-rules` are
   stripped fully — "do not leave it wired-but-disabled" — leaving support as private tickets only
   (lines 99-104); the erasure flags that only a public forum needed go with it:
   `supportTickets.ownerDeleted`, `ticketMessages.authorDeleted`, `DELETED_TICKET_SUBJECT`, the
   removal-notice body substitution and the `DELETED` author rendering, since erasure here
   hard-deletes (lines 107-111).

## Not counted, and why

Smaller strips in § B that did not make the top three: the Chinuk Wawa corpus and CW gates
(lines 97-98), Field Notes (line 112), and `convex/recovery.ts` (lines 85-89 — flagged there as a
name that must not be mistaken for account recovery).

## Verification performed

- Read `.claude/skills/odyssey-apps/references/port-inventory.md` in full (205 lines); every citation
  above was checked against the line it names.
- No command was run. `pnpm verify` does not exist in this repo, per handbook § Verification clause 3;
  this deliverable is a document read, not a build result, so no build command applied and none was
  claimed.

VERDICT: UNVERIFIED (no runnable check exists for a documentation read; `pnpm verify` absent).
