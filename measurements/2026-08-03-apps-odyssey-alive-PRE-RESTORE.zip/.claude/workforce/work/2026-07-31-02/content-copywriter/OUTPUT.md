# The three habits `my-voice` most strongly forbids

Source read: `.claude/skills/my-voice/SKILL.md` (2026-07-31, run `2026-07-31-02`).

Ranked by how much weight the file itself puts behind each one. A prohibition that sits in an
immutable user directive *and* has a STOP step in an enforcement gate outranks a numbered
collaboration principle, which outranks a step that only ends in a FLAG.

## 1. Inventing what Francis thinks

> "**Francis's ideas lead.** The AI helps articulate, refine, and structure thoughts Francis has
> already expressed or hinted at. Never invent positions, opinions, or experiences."
> (Collaboration Principles, 1)

The file says it twice more. Principle 5: "Content published under Francis's name must reflect his
actual thinking. If you're uncertain what he believes, ask." And principle 2 gives the remedy
instead of leaving the writer to improvise: "**Ask before assuming.** When direction is unclear, ask
Francis what he wants to say rather than guessing." Three of the five collaboration principles are
about this one habit, which is why it ranks first.

## 2. Faking imperfection, or planting a humanity signal with nothing under it

> "Never fake imperfections — Francis's rough edges are real."

That line lives inside a block stamped `origin: user | added: 2026-02-25 | immutable: true`, so it
is a user directive, not house guidance. The Humanity-First Calibration Gate then converts it into
two hard stops. Step 3: "Do NOT fabricate imperfection — pull specificity from source material or
ask Francis." Step 4: "IF a signal was invented without grounding in Francis's actual language,
lived experience, or the source material → STOP. Replace with a grounded signal or remove."

It is the only prohibition in the file carried by an immutable directive and a STOP at once.

## 3. Polishing the humanity out of the prose

> "**Preserve rough edges.** Francis's voice has texture. Don't polish away the humanity in pursuit
> of 'clean' prose." (Collaboration Principles, 3)

The same gate supplies the test that catches it, at step 5: "read the draft and answer 'Does this
sound like a specific person thinking, or an average smart writer performing?' IF the answer is the
latter → STOP and revise." A draft can pass every other rule in the file and still fail here, which
is the point of it.

## Named, but ranked below the three

The Twain-wit checkpoint forbids two more habits, both ending in a FLAG rather than a STOP, so they
sit under the three above:

- Jokes standing in for wit. "IF a moment is a joke (laugh-line, punchline, comedic timing without
  rhetorical work) → FLAG and revise. Twain-style wit teaches; jokes don't."
- Either edge of the wit budget. The checkpoint "forbids both (a) wit-free earnestness when a point
  would land harder with wit, and (b) wit-saturation that turns the piece into comedy."

## Verification

Check run: `grep` (via Bash, per handbook Procedure 4) of this draft against the Tier 1 grep-able
rows of `.claude/skills/text-eval/references/text-tells.md`.

Eleven Tier 1 rows were grepped. Row names only below, so this artifact does not seed hits for the
next reader who greps it.

| Row | Hits in authored prose |
|---|---|
| Em-/en-dash as crutch **[hard]** | 0 |
| Rhetorical colons | 0 |
| Invisible Unicode **[hard]** | 0 |
| Curly/straight quote seams | 0 |
| Citation-machinery residue **[hard]** | 0 |
| Unfilled placeholders **[hard]** | 0 |
| AI vocabulary | 0 |
| Filler phrases | 0 |
| Latinate bias | 0 |
| Copulative avoidance | 0 |
| Superlative stacking | 0 |
| "From X to Y" construction | 0 |
| Sentence-frame openers | 0 |
| Connector overuse | 0 |
| Chat-frame leakage (wrapper, sycophancy, canned assurance, prompt echo) | 0 |

**Tell count: 0.** The handbook threshold is three or more clustered tells, so this is a PASS.

Two notes on what the raw grep returned before the count was resolved. First, the earlier draft of
this table spelled out each row's trigger vocabulary, and the grep dutifully found all of it: 18
AI-vocabulary hits, 3 connectors, 5 copulatives, all on the table lines themselves and none in the
prose. Removing the example words removed every hit, except one that no rewrite can remove: the
"From X to Y" row cannot be named without matching its own pattern, so the raw grep still returns a
single hit at that table line. Its test is "more than once per piece", and there are no instances in
the prose. Second, two em-dashes remain in this file, both
inside verbatim quotations of `my-voice/SKILL.md`, along with three `→` arrows quoted from its
enforcement gates. The [hard] row targets the dash "leaned on as a routine connector" by the author;
my own sentences use none.
