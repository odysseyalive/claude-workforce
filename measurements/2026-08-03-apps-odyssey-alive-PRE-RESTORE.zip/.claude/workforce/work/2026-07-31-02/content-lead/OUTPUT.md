# content-lead — run 2026-07-31-02

## Deliverable

apps.odysseyalive.com sells AI productivity tools that are genuinely useful for businesses and
easy to manage, and its differentiator is low overhead rather than raw power, on the promise
that a customer spends less time administering a tool than it saves them. The one constraint
that thesis places on the home page is vertical neutrality in copy and in imagery, because
real estate is only where the catalog starts and a hero full of keys and closing tables would
make this a real estate site and every future non-real-estate module arrive looking like an
exception.

## Traceability

Both sentences trace to `.claude/skills/odyssey-apps/references/modules.json`:

| Sentence | Source key | Basis |
|---|---|---|
| 1 | `$site_thesis.statement` | "Tools that are genuinely useful for businesses and easy to manage. The differentiator is LOW OVERHEAD, not raw power — 'you will spend less time administering this than you save.'" |
| 2 | `$site_thesis.catalog_scope`, consequence (1) | "the HOME PAGE — copy AND imagery — stays vertical-neutral; a hero full of keys and closing tables makes this a real estate site and every future module arrives looking like an exception." |

Supporting context read but not asserted as thesis: `$comment` (module registry definition),
`$site_thesis.home_page_proposition`, `home_page_spine`, `home_page_cautions` (caution 5 restates
the neutrality constraint), `home_page_blocked_on`, `specificity_resolution` (reconciles
neutrality with the specificity requirement by placing the home page's specificity at the
problem-shape altitude and the module pages' at the work altitude).

Note on "the one constraint": `$site_thesis` states several home-page rules (single CTA, no beta
ask, short and fast, safety never in the opening). Vertical neutrality is the one selected because
it is the constraint the catalog scope *places on the home page* as a binding consequence, and it
is the one named in this handbook's own Guardrails ("NEVER let the home page's copy or imagery
assume real estate — the catalog is vertical-neutral").

## Verification

1. Dispatched work orders: none. Per Guardrails ("NEVER pass through… do the work yourself"),
   a two-sentence read-and-state order carries no coordination value, so it was not split
   across content-copywriter and content-imagemaker. Nothing to collect a verdict from.
2. Catalog check — copy checked against the `text-eval` catalog at `.claude/skills/text-eval/`,
   by grep against `references/text-tells.md`, not by opinion:
   - `grep -n '\[hard\]' references/text-tells.md` → 7 hard rows. Deliverable scanned against
     each: em-/en-dash as crutch (line 51) — 0 occurrences of `—`/`–` in the deliverable text;
     invisible Unicode (line 55) — 0 occurrences of U+200B-200D/FEFF/202F/202A-E/2066-9/E0000-E007F;
     pipeline artifacts (line 57) — none; ghost citations (line 167) — none, both claims name their
     source key; fabricated experience (line 168) — none, no first-person claims; wit-shaped noise
     (line 178) — not single-line content, and every referent resolves.
   - `grep -n -i 'rhetorical colon' references/text-tells.md` → line 52. Deliverable scanned:
     0 setup-punchline colons in the two sentences.
   - Quoted source strings above retain their original em-dashes; they are quotations from
     `modules.json`, not authored copy.
3. Image work: none in this order, so no check against `.claude/skills/image-eval/` was owed.
4. Re-dispatch: not reached; no FAIL to name.

## Exit criteria

Met. No order was dispatched, so there is no order that failed to return PASS, and the result
names which catalog checked what: `text-eval` checked the two sentences; `image-eval` was not
invoked because no imagery was produced.
