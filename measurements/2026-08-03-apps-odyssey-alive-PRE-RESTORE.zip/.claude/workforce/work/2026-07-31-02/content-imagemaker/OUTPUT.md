# Palette listing — every colour declared in `palette.md`

Run-id: 2026-07-31-02 · Employee: content-imagemaker · Branch: 2 (written answer)

Source: `.claude/skills/odyssey-apps/references/palette.md`. Every entry below cites that file;
section names in parentheses are that file's own headings.

## 1. The declared Odyssey Apps palette (`palette.md` § Token map, "Odyssey Apps" column)

| # | Hex | Token | Role, as given |
|---|---|---|---|
| 1 | `#FFFFFF` (white) | `--brand-bg` | main surface — `palette.md` § Token map |
| 2 | `#F4F7FA` (cool off-white) | `--brand-cream` → renamed `--brand-surface` | secondary surface, section bands, cards — `palette.md` § Token map |
| 3 | `#123A6B` (deep professional blue) | `--brand-accent-primary` | headings, links, primary CTAs, the nav dot — `palette.md` § Token map |
| 4 | `#1D5A9E` (brighter blue) | `--brand-accent-hover` | hover/active — `palette.md` § Token map |
| 5 | `#E3ECF5` (pale blue) | `--brand-accent-soft` | soft fills, badges, quiet backgrounds — `palette.md` § Token map |
| 6 | `#C9A227` (muted brass) | `--brand-gold` | **the signature metal**: rules, icon strokes, focus rings, "beta" badges, accent underlines — `palette.md` § Token map |
| 7 | `#E0B93C` | `--brand-gold-hover` | gold hover / active — `palette.md` § Token map |
| 8 | `#F6EDD2` | `--brand-gold-soft` | gold-tinted fills — `palette.md` § Token map |
| 9 | `#16202B` (near-black slate) | `--brand-ink` | body copy on white — `palette.md` § Token map |
| 10 | `#5A6B7C` | `--brand-muted` | secondary text, captions — `palette.md` § Token map |
| 11 | `#DCE3EA` | `--brand-border` | hairlines, card borders, table rules — `palette.md` § Token map |
| 12 | `#0C2340` (deep navy) | `--brand-footer` | footer / dark hero background — `palette.md` § Token map |
| 13 | `#F2F6FA` | `--brand-on-dark` (body) | text on the navy footer/hero — `palette.md` § Token map |
| 14 | `#E8C766` | `--brand-on-dark` (gold-on-navy accent) | gold accent on navy; the one place gold may carry type — `palette.md` § Token map and § The gold rule |

Fourteen colours are declared for this project. Three of the fourteen (`--brand-gold`,
`--brand-gold-hover`, `--brand-gold-soft`) are new rather than swaps: "odyssey-alive has no gold
family — this is new, not a swap" (`palette.md` § Apply sweep, step 1).

The whole set is marked **PROPOSED, finalized at site-build**: "The exact hexes below are a
starting point" and every graphic "gets reviewed with Playwright on the rendered site during
creation and adjusted then" (`palette.md` § header and § Build-time graphics review).

## 2. Constraints attached to these colours

- **Gold is a metal, not a text colour on white.** `#C9A227` on `#FFFFFF` is roughly 2.9:1, below
  WCAG AA for body and large text alike (`palette.md` § The gold rule).
- Gold IS for: rules and dividers, icon strokes, focus rings, small badge fills with dark text,
  underline accents, chart/stat marks, borders on hover (`palette.md` § The gold rule).
- Gold is NOT for: body copy on white, links on white, button labels on white, or any run of text
  a user must read (`palette.md` § The gold rule).
- `#E8C766` on `#0C2340` clears AA comfortably; gold text is permitted in the footer/dark hero only
  (`palette.md` § The gold rule).
- `#123A6B` on white clears AAA for body text, "so blue carries every text role gold cannot"
  (`palette.md` § The gold rule).
- Roles in the drawn graphic system: white is the ground, navy is the ink and the field, gold is
  the hairline, the tick, and the accent mark — never a fill (`palette.md` § Image guidance).
- No palette variant may be introduced outside this file: "a system is recognisable because its
  measurements repeat" (`palette.md` § Image guidance), and the amendment in
  `.claude/skills/image/SKILL.md` § Directive amendment clause 2 inverts the older per-asset
  palette-variety directive for this project.
- Type stack, declared alongside the colours: Inter (body) + Playfair Display (serif headings);
  Gentium Plus is dropped (`palette.md` § Token map, closing note).

## 3. Colours `palette.md` names but does NOT declare as this project's palette

Listed for completeness because they appear in the same file; each is named there as something to
replace, not as a colour of this system.

**Prior odyssey-alive values (`palette.md` § Token map, "odyssey-alive" column):** `#FDF8F0` warm
cream (`--brand-bg`), `#F7EDE2` (`--brand-cream`), `#FFA07A` coral (`--brand-accent-primary`),
"coral lighten" — no hex given (`--brand-accent-hover`), `#FFE0A8` (`--brand-accent-soft`),
`#4A3828` warm brown (`--brand-ink`), `#3B2F25` (`--brand-footer`). The white surface is called
"the deliberate break from odyssey-skul" (`palette.md` § header).

**Ported nsayka-wawa tokens to grep out (`palette.md` § Apply sweep, step 2):** `#1E3A5F`,
`#2C5F8A`, `#FDF8F0`, `#F7EDE2`, `#142233` — "those are what actually ship in the copied source."

## 4. Verification

**Branch 2 ran** — this work order produced a written answer about the graphic system (a palette
listing), not an image, so per the handbook § Verification the check is citation completeness.

What it checked: every claim above carries a citation to `.claude/skills/odyssey-apps/references/palette.md`
by name (with its section) or, in the two places noted, to `.claude/skills/image/SKILL.md` by name.
No uncited claim remains. **Branch 1 did not run and is not reported**: no image was produced, so
the `.claude/skills/image-eval/` catalog check was not performed.

Result: PASS on branch 2.
