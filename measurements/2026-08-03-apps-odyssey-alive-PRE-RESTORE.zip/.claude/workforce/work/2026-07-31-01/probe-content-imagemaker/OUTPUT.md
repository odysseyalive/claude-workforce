# Declared palette — Odyssey Apps

Source for every entry: `.claude/skills/odyssey-apps/references/palette.md`.

The file is headed "Palette: professional blue + white + gold (PROPOSED; finalized at
site-build)" — the hexes are stated there as a starting point, reviewed with Playwright on the
rendered site (`palette.md` § Build-time graphics review).

## 1. The Odyssey Apps colours (`palette.md` § Token map)

| # | Token | Hex | Role, as given |
|---|---|---|---|
| 1 | `--brand-bg` | `#FFFFFF` (white) | main surface — `palette.md` § Token map |
| 2 | `--brand-cream` → renamed `--brand-surface` | `#F4F7FA` (cool off-white) | secondary surface, section bands, cards — `palette.md` § Token map |
| 3 | `--brand-accent-primary` | `#123A6B` (deep professional blue) | headings, links, primary CTAs, the nav dot — `palette.md` § Token map |
| 4 | `--brand-accent-hover` | `#1D5A9E` (brighter blue) | hover/active — `palette.md` § Token map |
| 5 | `--brand-accent-soft` | `#E3ECF5` (pale blue) | soft fills, badges, quiet backgrounds — `palette.md` § Token map |
| 6 | `--brand-gold` | `#C9A227` (muted brass) | **the signature metal**: rules, icon strokes, focus rings, "beta" badges, accent underlines — `palette.md` § Token map |
| 7 | `--brand-gold-hover` | `#E0B93C` | gold hover / active — `palette.md` § Token map |
| 8 | `--brand-gold-soft` | `#F6EDD2` | gold-tinted fills — `palette.md` § Token map |
| 9 | `--brand-ink` | `#16202B` (near-black slate) | body copy on white — `palette.md` § Token map |
| 10 | `--brand-muted` | `#5A6B7C` | secondary text, captions — `palette.md` § Token map |
| 11 | `--brand-border` | `#DCE3EA` | hairlines, card borders, table rules — `palette.md` § Token map |
| 12 | `--brand-footer` | `#0C2340` (deep navy) | footer / dark hero background — `palette.md` § Token map |
| 13 | `--brand-on-dark` | `#F2F6FA` | body text on the navy footer/hero — `palette.md` § Token map |
| 14 | `--brand-on-dark` (second value in the same cell) | `#E8C766` | gold-on-navy accent, text on the navy footer/hero — `palette.md` § Token map |

Thirteen token rows; fourteen hexes, because `--brand-on-dark` declares two (`#F2F6FA` body and
`#E8C766` gold-on-navy accent) in one cell.

Overall assignment stated in the file's opening line: "White is the ground, blue is the structural
accent, gold is the signature metal" (`palette.md`, intro).

## 2. Constraints the file attaches to these colours

- **The gold rule** (`palette.md` § The gold rule, marked non-negotiable): gold `#C9A227` on
  `#FFFFFF` is ~2.9:1, below WCAG AA. Gold IS for rules/dividers, icon strokes, focus rings, small
  badge fills with dark text, underline accents, chart/stat marks, hover borders. Gold is NOT for
  body copy, links, button labels on white, or any run of text a user must read.
- **Gold-on-navy is the exception**: `#E8C766` on `#0C2340` clears AA; gold type is permitted in
  the footer/dark hero only (`palette.md` § The gold rule).
- **Blue carries the text roles gold cannot**: `#123A6B` on white clears AAA for body text
  (`palette.md` § The gold rule).
- **In the drawn graphic system** (`palette.md` § Image guidance): white is the ground, navy is the
  ink and the field, gold is the hairline/tick/accent mark — never a fill, never body text on
  white; stroke weight is a token, not a per-asset choice.

## 3. Hexes the file names that are NOT Odyssey Apps palette colours

Listed for completeness so they are not mistaken for declarations of this palette.

- Prior-project comparison column (`palette.md` § Token map, "odyssey-alive" column): `#FDF8F0`
  warm cream (`--brand-bg`), `#F7EDE2` (`--brand-cream`), `#FFA07A` coral
  (`--brand-accent-primary`), `#FFE0A8` (`--brand-accent-soft`), `#4A3828` warm brown
  (`--brand-ink`), `#3B2F25` (`--brand-footer`). Role given: what Odyssey Apps replaces — "the
  deliberate break from odyssey-skul".
- Search targets for the apply sweep (`palette.md` § Apply sweep, step 2): `#1E3A5F`, `#2C5F8A`,
  `#FDF8F0`, `#F7EDE2`, `#142233` — nsayka-wawa tokens that ship in the copied source and must be
  repointed. Role given: things to grep for and remove, not palette entries.

Non-colour item declared in the same file: the type stack is Inter (body) + Playfair Display
(serif headings); Gentium Plus is dropped (`palette.md` § Token map, closing note).

## Verification

- Handbook procedure step 1 — done: `.claude/skills/odyssey-apps/references/palette.md` read in
  full (94 lines); every colour above is quoted from it.
- Handbook procedure step 2 — done: `.claude/skills/image/SKILL.md` read, including its
  superseding directive amendment of 2026-07-22 (drawn graphic system; palette repetition is the
  system, not a defect) and its § Palette table, which defers to `palette.md` as authoritative.
  Its six-row summary table agrees with rows 1, 3, 2, 6, 12, 13/14 above and adds no colour.
- Handbook procedure step 3 / Verification step 1 — **NOT RUN, and therefore NOT PASS.** The
  catalog at `.claude/skills/image-eval/` (SKILL.md plus references `ai-patterns.md`,
  `graphic-system.md`, `visual-clarity.md`, `palette.md`, `watercolor.md`, `templates.md`,
  `invocation.md`, `output-formats.md`, and `agents/image-validator/AGENT.md`) checks a generated
  image for AI tells and graphic-system drift. This task generated no image, so the check has no
  subject. Reported as not applicable rather than passed, per Guardrail "NEVER report PASS on an
  unrun check."
- Handbook Exit criteria ("the image exists at its stated path and its catalog check is stated")
  is likewise not applicable: the probe asks for a list, not an image. The catalog check is stated
  above as not run and why.
