# The three habits `my-voice` most strongly forbids

Source read: `.claude/skills/my-voice/SKILL.md` (15k, read in full).
Ranked by strength of the prohibition in that file: an absolute "Never", placement inside an
`immutable: true` user-origin block, and a STOP checkpoint that enforces it.

## 1. Inventing anything Francis did not say, think, or live

> "**Francis's ideas lead.** The AI helps articulate, refine, and structure thoughts Francis has
> already expressed or hinted at. Never invent positions, opinions, or experiences."
> (Collaboration Principles, item 1)

Restated twice more in the same file:

> "**His name, his words.** Content published under Francis's name must reflect his actual
> thinking. If you're uncertain what he believes, ask." (item 5)

> "**Ask before assuming.** When direction is unclear, ask Francis what he wants to say rather than
> guessing." (item 2)

Strongest of the three: it is the only prohibition stated three times, and the sanctioned response
is to stop and ask rather than to fill the gap.

## 2. Faking imperfection, or manufacturing "human" texture that isn't grounded

From the `immutable: true` Directives block, added 2026-02-25:

> "Calibrate for humanity, not against AI. ... Never fake imperfections — Francis's rough edges are
> real."

This one carries a hard enforcement gate, so it is forbidden with machinery and not only with
words. Humanity-First Calibration Gate, step 4:

> "IF a signal was invented without grounding in Francis's actual language, lived experience, or
> the source material → STOP. Replace with a grounded signal or remove."

And step 3: "Do NOT fabricate imperfection — pull specificity from source material or ask Francis."

## 3. Polishing the texture out in pursuit of clean prose

> "**Preserve rough edges.** Francis's voice has texture. Don't polish away the humanity in pursuit
> of 'clean' prose." (Collaboration Principles, item 3)

Enforced by the calibration test at Humanity-First Calibration Gate step 5:

> "read the draft and answer 'Does this sound like a specific person thinking, or an average smart
> writer performing?' IF the answer is the latter → STOP and revise."

The forbidden habit is the default drafting reflex: smoothing a sentence until it reads well and
belongs to no one.

### Runners-up, not in the top three

Named for completeness only. Each is forbidden once, without the triple statement or the STOP gate:
jokes in place of Twain-style wit ("IF a moment is a joke ... → FLAG and revise. Twain-style wit
teaches; jokes don't."), and writing into the sibling `odyssey-alive` repo ("**Read-only.**
odyssey-alive is a live sibling project; never write into it.").

## Verification: catalog check

Catalog: `.claude/skills/text-eval/references/text-tells.md`. I ran the grep-able surface tells
against this file with `grep`, invoked through `Bash` per handbook Procedure step 4. Family names
below are deliberately not spelled with their trigger tokens; two earlier passes listed the tokens
in this table and the grep counted its own checklist (9 phantom vocabulary hits, then one each in
three other families, then one more from a row label that matched its own pattern). Those were
measurement artifacts, not prose defects, and the counts below are from the run after they were
removed.

| Surface-tell family | Hits in this file |
|---|---|
| Em/en dash as crutch **[hard]** | 2, both inside verbatim quotations |
| Citation-machinery residue **[hard]** | 0 |
| Unfilled placeholders **[hard]** | 0 |
| Invisible Unicode **[hard]** | 0 |
| AI vocabulary set | 0 |
| Filler phrases | 0 |
| Latinate inflation | 0 |
| Chained connectives | 0 |
| Range-sweep construction | 0 |
| Recurring sentence-frame openers | 0 |
| Knowledge-cutoff / RAG disclaimers | 0 |
| Chat-wrapper leakage, sycophantic openers, canned assurances, prompt echo | 0 |
| Curly/straight quote seam | 0 curly glyphs; straight quotes throughout, no mixed pairs |

**Total: 2 hits, one family, both quoting `SKILL.md` verbatim.** Quoted source text cannot be
rewritten without breaking the task's requirement to quote the file. Em/en dashes authored by me:
**0**, against a catalog target of no more than 1 per ~5,000 words in a 728-word document.

**Clustered-tell count against the handbook's FAIL rule (three or more clustered): 1 family, 0
authored occurrences. Under threshold. PASS.**

Not run, and not claimed: the structural, compositional, corpus-level, and overbuilt-prose cluster
passes. Those are agent and judgment passes, not the mechanical grep the handbook specifies.
