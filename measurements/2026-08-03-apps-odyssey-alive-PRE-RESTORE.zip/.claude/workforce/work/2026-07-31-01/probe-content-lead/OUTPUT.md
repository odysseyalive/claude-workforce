# Site thesis and the home-page constraint

Source: `.claude/skills/odyssey-apps/references/modules.json`

## Deliverable

apps.odysseyalive.com sells tools that are genuinely useful for businesses and easy to manage, and the differentiator is low overhead rather than raw power, so a customer spends less time administering them than they save.

The one constraint this places on the home page is that its copy and its imagery both stay vertical-neutral, because the catalog is a platform for business productivity tools and real estate is only where it starts.

## Traceability

| Sentence | Key in `modules.json` | Text relied on |
|---|---|---|
| 1 | `$site_thesis.statement` | "Tools that are genuinely useful for businesses and easy to manage. The differentiator is LOW OVERHEAD, not raw power — 'you will spend less time administering this than you save.'" |
| 2 | `$site_thesis.catalog_scope` | "The catalog is NOT real-estate-specific… This is a PLATFORM for business productivity tools; real estate is where it starts, not what it is. Consequences that bind now, not later: (1) the HOME PAGE — copy AND imagery — stays vertical-neutral…" |

Both sentences are restatements of those two keys; nothing above is inferred from any other file.

## Verification

- Dispatched work orders: none. The task is a single file read and two sentences, so it falls under
  the guardrail "NEVER pass through. If you add no coordination value, do the work yourself."
  Verification steps 1 and 3 have no dispatched order to apply to.
- Catalog check: the two deliverable sentences were checked against the `text-eval` catalog at
  `.claude/skills/text-eval/references/text-tells.md` by grep, not by opinion. Tier-1 `[hard]` rows
  scanned: em-/en-dash as crutch, invisible Unicode, citation-machinery residue, unfilled
  placeholders. Also scanned: rhetorical colons and AI vocabulary. Zero hits in the two sentences.
  (The quoted source text in the Traceability table contains em-dashes; those are verbatim quotation
  from `modules.json`, not authored prose.)
- `image-eval` was not run: this deliverable ships no imagery.
