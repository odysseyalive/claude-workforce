# The three largest things the port strips

Source: `.claude/skills/odyssey-apps/references/port-inventory.md` § B ("Strip — the game half").
Ranked by the breadth of the surface removed — build system, backend tables, routes, components, and
tests together.

1. **The Inform 7 / Glulx game and its save bridge.** The port deletes the entire interactive-fiction
   half — `Nsayka Wawa.inform/`, `Nsayka Wawa.materials/`, `gameinfo.dbg`, `library/`, `research/`,
   `tools/` (line 79-80) — together with the machinery that shipped it to the browser: `convex/saves.ts`,
   the asyncglk `Provider`/`Dialog` override, Parchment, the `public/modules/<slug>/` game assets, and
   `stageModuleGame()` in `copy-assets.js` (line 81-83), plus the `play.gblorb` Git-LFS provisioning
   (line 113).

2. **The whole progress/score model and the two public surfaces built on it.** Stripped are
   `convex/progress.ts`, `src/components/progress/`, `src/lib/score.ts`, the `playerProgress` /
   `missionProgress` / `vocabProgress` tables, the kəmtəks STATE-line reader, and the snapshot
   carryover contract (line 90-92), and with them the leaderboard — `convex/leaderboard.ts`,
   `leaderboardEnabled`, `leaderboardOptIn`, `/leaderboard` (line 93-94) — and the explorer,
   `convex/explorer.ts`, `/explorer`, `/explorer/[username]` (line 95-96).

3. **The public support forum, which drags the GDPR anonymize-in-place machinery out with it.** The
   2026-07-22 directive amendment removes `convex/forumRules.ts`, `src/components/forum/` (incl.
   `ModuleForum.tsx`), the `/forum-rules` route, the `forumRules` + rules-version + re-agreement
   tables, the `forumEnabled` flag and its `moduleForumEnabled` gate, public thread reading in
   `tickets.ts`, and `tests/forum-rules`, leaving support as private tickets only (line 99-104); the
   anonymize-in-place layer that existed only because the forum was public goes with it —
   `supportTickets.ownerDeleted`, `ticketMessages.authorDeleted`, `DELETED_TICKET_SUBJECT`, the
   removal-notice body substitution, and the `DELETED` author rendering — so erasure hard-deletes
   (line 107-111).

## Note carried alongside the strip (line 105-106)

`convex/profanity.ts` and `src/lib/censor.ts` are explicitly **not** stripped with the forum: they guard
usernames at signup/account edit and back `CensoredText` in ticket display, and both outlive the forum.

## Verification

Per handbook § Verification 3, `pnpm verify` does not exist yet (`CLAUDE.md` § Build / run / test,
line 138, lists it under "Expected scripts … adapt as the scaffold lands"; confirmed on disk —
`/home/francis/lab/apps-odyssey-alive/package.json` is absent). No command was available to prove this
result, so the verdict is `UNVERIFIED`, not `PASS`.

Commands that ran: `Read` of the two cited files; `test -f package.json` (absent).
Commands that do not exist: `pnpm verify`.
