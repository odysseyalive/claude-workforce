# Findings — `content-text-evaluator`

- **Run id:** 2026-07-31-05
- **Artifact:** `.claude/skills/odyssey-apps/references/beta-access.md` (1,766 words, 206 lines)
- **Catalog:** `.claude/skills/text-eval/references/text-tells.md` (read as a file; `/text-eval` was never invoked)
- **Employee:** `content-text-evaluator` (tier 3 IC, content dept, `disallowedTools: Agent`)
- **Uncited findings: 0** (handbook § Verification 1 — mechanical count)

Every citation below points at a heading in `text-tells.md`. Severities come from that file's
§ How to apply this library rule 1 ladder (1 signal → CONSIDER, 2 → SHOULD FIX, 3+ → MUST FIX) and
from rows that state their own severity.

---

## Human-presence census — run FIRST, as § Human-presence markers requires

§ Human-presence markers says to check FOR these before flagging anything, and that 4+ strong
markers plus a few rhetorical devices means human writing under revision pressure, warranting an
over-correction warning before requiring changes.

| Marker | Present? | Evidence |
|---|---|---|
| First-person presence | No | zero `I`; impersonal spec voice |
| Lived experience | **Yes** | named provenance — `nsayka-wawa/convex/access.ts`, `censor.ts`, `lockout.ts`, dated directive, a named person |
| Genuine commitment | **Yes** | L43 "Turnstile is NOT required here, contrary to this file's original spec"; L38 "probably wrong for a product" |
| Irregular rhythm | **Yes** | measured: 30 prose sentences, 5–61 words, σ=13.6; zero 5-sentence windows within a 5-word spread |
| Texture words | **Yes** | "anyway" (L18), "genuinely" (L21), "actually" (L25, L98), "almost" (L46), "also" (L141), "too" (L187) |
| Fragments & asides | **Yes** | parentheticals L22-23, L157-158, L180-181 |
| Contractions | Partial | 2 true contractions ("You're" L136, "don't" L183) against 13 possessives |
| Functional wit | **Yes** | L153-154 "If there is nothing kind to say, say less" — deadpan, load-bearing |

**6 strong markers. Over-correction warning surfaced.** Findings F4 and F5 below are judgment-class
and should be read against this census, not applied mechanically. **F1 is not affected**:
§ How to apply rule 1 states a `[hard]` row "is NEVER demoted by the voice-protection,
cluster-density, or human-presence gates."

---

## Findings

### F1 — Em-dash as crutch — **MUST FIX** `[hard]`, not demotable
**Citation:** § Tier 1 — Surface tells → *Character & punctuation* → row "Em-/en-dash as crutch **[hard]**"

**28 em-dashes (U+2014) in 1,766 words.** Zero en-dashes. The row's test is "a near-restriction, not
a baseline ratio. Target ≤1 em-dash per ~5,000 words. Flag every occurrence; a second within ~5,000
words is MUST FIX." This document's entire allowance is 0–1; it carries 28, roughly **79× the
catalogued target rate**.

Lines: 1, 6, 14, 18, 22, 27, 30, 38, 44, 56, 91, 96, 97, 100, 111, 118, 122, 126, 141, 150, 152,
153, 156, 172, 178, 179, 183, 186.

All 28 are the catalogued usage — routine connector, aside, or dramatic pause — not compound-word
hyphens (the row's stated exclusion; `long-term`-style hyphens were excluded from the count). The
row's prescribed remedy is to rewrite each as two sentences, a comma, or parentheses.

Representative: L1 heading (`Beta Access — request flow…`), L126 (`The button — public intro page`),
L183 (`no tombstone — delete, don't scrub`), L14 (`The caller's own rows — powers the CTA state`).

The row is `[hard]`. Per § How to apply rule 1, no "house style" or "genre baseline" exemption
applies — including the technical-spec genre of this document.

---

### F2 + F3 — Markdown-chat formatting habits — **SHOULD FIX** (2-signal cluster)

Two distinct mechanisms, counted separately per § How to apply rule 2 (dedupe is by *mechanism*;
these do not share one). Two signals → SHOULD FIX on the rule-1 ladder.

**F2 — Skipped heading levels**
**Citation:** § Tier 2 — Structural tells → *Markdown & heading style* → row "Skipped heading levels"

Heading tree: `#` (L1) → `###` (L25 "What is actually missing") → `###` (L34 "Two behaviours to
decide…") → `##` (L51 "Schema"). The two H3s sit under an H1 with **no H2 above them**. The row's
test — "Outline the heading tree; a level gap almost never occurs in hand-formatted documents" —
returns positive. Every other section (L51, 89, 107, 126, 146, 162, 176, 191) is a correctly-nested H2.

**F3 — Thematic break before every heading**
**Citation:** § Tier 2 — Structural tells → *Markdown & heading style* → row "Thematic break before every heading"

**8 of 8 H2 sections are immediately preceded by a `---` rule** (L49→51, 87→89, 105→107, 124→126,
144→146, 160→162, 174→176, 189→191). The row's test asks whether rules appear "before most headings,
rather than at one or two deliberate breaks." 100% coverage — no rule anywhere except before a
heading, and none skipped. This is the catalogued Markdown-chat habit, not deliberate sectioning.

---

### F4 — Contrastive negation — **MUST FIX** (row states its own threshold)
**Citation:** § Tier 2 — Structural tells → *Rhetoric clustering* → row "Contrastive negation"

The row: "One use per piece can be craft; **3+ is a dead giveaway** (cluster rule applies at full
strength)." **9 instances** of the X-not-Y frame:

| Line | Instance |
|---|---|
| 34 | "Two behaviours to **decide, not inherit** silently" (heading) |
| 84 | "Enforce in the mutation via `by_user_module`, **not by convention**" |
| 92 | "**reuse** the `moduleSettings` machinery, **do not invent** a parallel switch" |
| 97 | "**use it, do not invent** a content-only flag" |
| 122 | "the admin **flips** the row to `withdrawn` — **never delete** rows" |
| 136 | "Button **disabled, not hidden**." |
| 158 | "it is **one template, not a redesign**" |
| 172 | "this **extends** the existing patterns, it **does not restyle** the desk" |
| 183 | "there is **no tombstone** — **delete, don't scrub**" |

Deliberately **excluded** as plain imperatives rather than the contrastive frame (a negation is not
this row unless it sets up an affirmation): L37 "do not resurrect it", L72 "NEVER sent verbatim",
L81 "never render it as HTML", L117 "Do not add a separate button", L134 "Do not put the form
behind the button", L137 "Never show `denyReason`", L154 "never paste `denyReason`", L186 "Never
disclose". Counting those would have doubled the tally on a mechanism the row does not describe.

Two of the nine (L41 "final **rather than** hopeful", L179 "reuse … **rather than** a new
mechanism") were assessed under the adjacent row "Contrastive inversion" and **deduped into this
finding** per § How to apply rule 2 — they are not double-counted.

**Severity caveat, stated rather than resolved:** this is a judgment-class row. § How to apply
rule 3 demotes to CONSIDER any pattern "matching a documented voice-profile characteristic," and
makes voice-dependent judgments advisory-only absent a profile. A project voice profile exists at
`.claude/skills/my-voice/references/profile.md`; it was **not** part of my instructed inputs (see
§ Not checked), so no match is established and no demotion is claimed. If the profile documents
imperative X-not-Y phrasing as a Francis characteristic, this finding demotes to CONSIDER.

---

### F5 — Personification of abstractions — **SHOULD FIX** (2 signals)
**Citation:** § Tier 3 — Compositional tells → row "Personification of abstractions"

Row test: "Replace with the human actor; meaning improves."

- **L8 — "The code disagrees."** Replacement: "reading `access.ts` contradicts the prose." The
  catalogued examples ("the market spoke," "the data tells a story") are the same move.
- **L23 — "the docs caused an implemented feature to be re-specified as new."** Replacement:
  "whoever wrote the docs caused…" — sharpens, and restores the accountable party the sentence
  currently omits.

**Considered and not counted:** L118 "that is how the two records drift apart" — database rows
diverging is literal, not personification. L30 "the queue query does, the decision half may not" is
verb ellipsis. Excluding these keeps the cluster at 2 rather than inflating it to 4.

---

## Checked and NOT flagged — with the test that cleared each

Reported per § Verification 3: zero findings on a row is a result, and silence is not. Each of these
was measured, not skimmed.

| Row (citation) | Result |
|---|---|
| § Tier 1 *Character & punctuation* → "Invisible Unicode **[hard]**" | **Clean.** Full scan of U+200B–200D, U+FEFF, U+202F, U+202A–E, U+2066–9, U+E0000–E007F, PUA: zero hits. Entire non-ASCII census is 28 `—`, 9 `→`, 4 `§`, 1 `…`. |
| § Tier 1 *Pipeline artifacts* → "Citation-machinery residue **[hard]**" | **Clean.** No `oaicite`, `oai_citation`, `【…†…】`, `[web:N]`, `[attached_file:N]`, `grok_render`, `utm_source=chatgpt.com`. |
| § Tier 1 *Pipeline artifacts* → "Unfilled placeholders" | **Clean.** No `[Your …]`, `[Describe …]`, `20XX-XX-XX`, `PASTE_`, `INSERT_`, TODO/TBD. |
| § Tier 1 *Pipeline artifacts* → "Cross-markup leakage" | **Clean.** Markdown throughout; the one fenced block is `ts` and its dialect matches. |
| § Tier 1 *Character & punctuation* → "Curly/straight quote seams" | **Clean.** 56 straight doubles, 16 straight apostrophes, **zero** curly of either kind. Uniform → tooling, not a paste seam. |
| § Tier 1 *Character & punctuation* → "Rhetorical colons" | **Clean.** Every colon is a list introduction, a table cell, or code — all named exclusions in the row's test. No setup-punchline colon. |
| § Tier 1 *Vocabulary & phrasing* → "AI vocabulary" | **Clean.** Zero hits across all 18 listed words (delve/tapestry/pivotal/showcase/underscores/noteworthy/realm/beacon/multifaceted/meticulous/intricate/commendable/paramount/vibrant/boasts/leverage/robust/seamless). |
| § Tier 1 → "Filler phrases", "Latinate bias", "Connector overuse", "Knowledge-cutoff & RAG disclaimers" | **Clean.** Zero hits on each family. No Furthermore/Moreover/Additionally anywhere. |
| § Tier 1 *Vocabulary & phrasing* → "From X to Y construction" | **Clean.** One hit ("from a row to that user's row") is a literal navigation direction, not the rhetorical frame; the row needs >1 anyway. |
| § Tier 1 *Chat-frame leakage* (all 5 rows) | **Clean.** No wrapper leakage, sycophantic openers, canned assurances, or prompt echo. |
| § Tier 2 *Sentence & paragraph mechanics* → "Uniform sentence length" | **Clean, measured.** 30 prose sentences: 5–61 words, mean 23.6, σ=13.6. Row test is "in any 5-sentence stretch, all sentences within 5 words of each other" — **zero** such windows. Burstiness is high. |
| § Tier 2 → "Imbalanced contractions" | **Clean.** Row flags "all or zero, applied uniformly." This mixes (2 contractions against formal alternatives). |
| § Tier 2 *Markdown & heading style* → "Title Case headings" | **Clean.** Headings are sentence case ("What is actually missing", "Module gating", "Abuse and privacy"). Row needs 100% Title Case. |
| § Tier 2 *Markdown & heading style* → "Mechanical boldface" | **Clean.** 27 bold spans; row test is "strip all bold; if no contrastive stress is lost (bold tracks topic nouns, not emphasis), it was mechanical." Bold here tracks *directives and reversals* ("**EXISTS — port it.**", "**The code disagrees.**", "**two**", "**and all four indexes**"). Stripping loses real stress. |
| § Tier 2 *Markdown & heading style* → "Emoji decoration" | **Clean.** Zero emoji (confirmed by the non-ASCII census). |
| § Tier 2 *Markdown & heading style* → "Unnecessary mini-tables" | **Clean.** All 6 tables are multi-column with per-row content that does not collapse to a sentence. |
| § Tier 2 *Document shape* → "List-ification", "Symmetrical lists", "Listicle-in-disguise" | **Clean.** Row test is "does the format match the venue's genre norms?" — a reference spec is a list-native venue; item lengths vary (L27–32 run 6 to 24 words). |
| § Tier 2 *Document shape* → "Structural narration", "Bookend callbacks", "Oversized recap conclusion", "Challenges/Future Outlook outline", "Closing with a question" | **Clean.** No self-narration; the document ends on a numbered test list, with no recap section, no stock final headings, no closing question. |
| § Tier 2 *Rhetoric clustering* → "Negative parallelism" | **Clean — test returned negative.** L6-8 and L43 have the false-misconception *shape*, but the row's test is "was the misconception ever actually held, or manufactured to be corrected?" It was genuinely held: a sibling document states the opposite, and this file cites the source that overturned it. Manufactured framing is the tell; a real correction is not. |
| § Tier 2 *Rhetoric clustering* → "Triple beat", "Epiphany machine", "Self-posed revelation", "Balanced hedging", "Passive deflection" | **Clean.** Two triads total (L44 "signup, contact, newsletter"; L148) — not a cluster. No paragraph-final epiphanies, no "The result? …", and the piece commits repeatedly rather than hedging. |
| § Tier 3 → "Ghost citations **[hard]**" | **Clean.** No "studies show" / "experts agree" / "industry reports". Every claim names its source file. |
| § Tier 3 → "Fabricated experience **[hard]**" | **Clean — provenance verified.** L8-9 claims "Verified by reading `nsayka-wawa/convex/access.ts`". That file **exists** (`/home/francis/lab/nsayka-wawa/convex/access.ts`, 9.7k). The row demands a provenance check; it passes. |
| § Tier 3 → "Invented concept labels" | **Clean.** "PAT-2026-07-22-port-description-drift" resolves to `.claude/skills/awareness-ledger/ledger/patterns/PAT-2026-07-22-port-description-drift.md` and is load-bearing in 4 other files — the row's test ("used by anyone else, or load-bearing beyond one paragraph?") passes both ways. |
| § Tier 3 → "Hyperbolic scope", "Nice-nice wrap", "Motivational-poster tone", "Patronizing analogy", "Announced humor", "False vulnerability" | **Clean.** No unbounded scope claims; the document picks sides (L43, L46-47, L117-118); negatives stated plainly (L23 "the most expensive"); no "Think of it as…"; the one joke (L153) is deadpan and unannounced. |
| § Tier 3 → "Elegant variation", "Detail latch", "Redundant reintroduction" | **Clean.** Technical referents are reused verbatim (`accessRequests`, `denyReason`, `moduleSettings`) — which is the *human* behavior the "Elegant variation" row describes, not synonym-cycling. |
| § Tier 3 → "Vague pronoun referents", "Unnatural references" | **Clean.** Every "this"/"it"/"that" sampled resolves to a noun within one sentence. Zero hits on "the former/the latter/as mentioned above/aforementioned/in between". |
| § Tier 3 → "Meta-commentary on source form", "Abstracting humans", "Legacy framing", "Over-explanation of basics", "Explaining the point", "Heady abstraction" | **Clean.** Prose describes what sources *say*, not how they are typeset; no "stands as a testament"; nothing defined that the intended audience knows. |
| § Flow & connectivity checks → "Dangling references" | **Clean — all resolved to targets, section included.** `schema.md § D` → heading "D. What goes in the database on day one" (L117). `palette.md § The gold rule` → heading at L32. `test-suite.md § Cleanup` → "Cleanup after every run" (L93) in `references/procedures/`. |
| § Flow & connectivity checks → "Orphaned statements", "Compressed bullets as prose", "Ungrounded borrowed concepts", "Topic collisions", "Product/tool drops", "Filler word echo" | **Clean.** Connectives are explicit ("because", "so that", "rather than"); no unattributed borrowed phrases; the tool references are the subject matter, not promotional drops. |
| § Overbuilt-prose signals | **Clean.** Read-aloud test applied to the 30 prose sentences: the two longest (L18, 55 words; L96, 61 words) are table cells enumerating behavior, not nested rhetoric. No chiasmus, no triple-cascades, no 3+ dependent clauses before the point lands. |

---

## What this review did NOT cover

Stated in full per handbook § "What this review does NOT cover — state it every time" and
§ Verification 2. **A review that omits this reads as complete and is not.**

### Catalog-mandated checks I could not run — I carry `disallowedTools: Agent`

1. **Every § Corpus-level tells row — not run.** All 8 rows (Cross-document uniformity, Intra-author
   style shift, Locale mismatch, Word whiskers, Concept duplication, Metaphor reuse, Callback crutch,
   Structural echo) are labelled "sibling/author comparison; **invisible to single-document
   passes**." They require a defined sibling set and an author corpus. The work order named one
   artifact and no sibling set. `.claude/skills/odyssey-apps/references/` holds 18 sibling documents
   that would form a plausible set, but choosing it myself would be inventing the comparison basis.
   **These rows are unevaluated, not passed.**
2. **§ Tier 2 → "Rhetorical closure patterns" — not run.** Its test is an explicit "corpus check
   across the author's recent pieces." Same blocker as above.
3. **§ Tier 2 header says "whole-document *agent pass*, not regex."** I performed the Tier 2 rows by
   reading and by measurement, in this context — **not** by dispatching a fresh-context agent, which
   I cannot do. The catalog's owning skill ships two agents for exactly this work —
   `.claude/skills/text-eval/agents/voiceprint-examiner/AGENT.md` and
   `.claude/skills/text-eval/agents/glyph-counter/AGENT.md` — and **neither was invoked.** Only a
   Lead or the main session can spawn them. Every other IC in this department, including the author
   of this artifact, carries the same restriction.

### Scope and resolution limits

4. **The project voice profile was not applied.** § How to apply rule 3 and § Per-project adaptation
   make voice-dependent judgments contingent on a documented voice profile. One exists
   (`.claude/skills/my-voice/references/profile.md`, plus `characteristics.md`,
   `sentence-structure.md`, `vocabulary.md`). My handbook § Scope names `text-tells.md` as the
   standard and names nothing else, so I judged against the catalog alone. **Consequence:** F4 and
   F5 could demote to CONSIDER under rule 3; F1 could not (`[hard]`, explicitly non-demotable).
5. **The catalog's severity-architecture link is broken; I used its inline ladder instead.**
   `text-tells.md` opens with "Policy lives elsewhere — read it first, never restate it here.
   Severity architecture, the cluster-density rule, the voice-protection gate … are canonical in
   [creative-integrity.md](../creative-integrity.md)." That relative link resolves to
   `.claude/skills/text-eval/creative-integrity.md`, **which does not exist**. The file exists only
   at `.claude/skills/skill-builder/references/creative-integrity.md`. I did not read it — my
   handbook scoped me to `text-tells.md` — and instead used the severity ladder the catalog states
   inline in § How to apply rule 1. **All severities above are therefore derived from
   `text-tells.md` alone.** They may be refined by the canonical policy file. *(This is a defect in
   the catalog's cross-reference, not in the artifact under review; per handbook § Guardrails the
   catalog is read-only here — its Records Owner is `none (read-only: owned by skill-builder)` — so
   this is reported to the user, not filed against an owner who cannot act.)*
6. **Per-project pattern elevations were not gathered.** § Per-project adaptation and § How to apply
   rule 4 state projects may elevate patterns to zero-tolerance in their own skills. I did not
   inventory this project's directive blocks, so any local elevation is unapplied and some
   severities above may be understated.
7. **Content-type calibration was not applied.** § Per-project adaptation says "the owning skill
   defines its calibration table" for short- vs long-form. I did not read the owning skill
   (`text-eval/SKILL.md`) — my handbook directs me to the reference file. I treated this 1,766-word
   document as long-form and applied the full library, which is the conservative reading.
8. **Forward code references were not treated as dangling.** `convex/access.ts`, `convex/schema.ts`,
   `src/lib/modules.ts`, `convex/account.ts`, `censor.ts`, `lockout.ts` do not exist in
   `apps-odyssey-alive`. I did **not** flag these under § Flow & connectivity → "Dangling
   references": the document is an explicit build plan for files it says are yet to be ported. The
   one reference asserted as *already read* (`nsayka-wawa/convex/access.ts`) was provenance-checked
   and exists. A reviewer who reads these as claims-about-the-present rather than work-to-do would
   reach a different result.

### Observed but not reportable as findings — no catalog row covers it

Recorded here explicitly **outside** the findings list so the uncited-finding count stays zero
(handbook § Verification 1 and § Guardrails: "NEVER report a finding without a catalog citation").
These are **not** findings and carry no severity:

- **Internal contradiction, Turnstile.** L44-47 and L178 state "Turnstile is NOT required here" and
  "**No Turnstile**", but the state table at L135 still specifies "textarea + **Turnstile** +
  submit" for the signed-in-no-request state. The catalog covers pipeline residue, ghost citations,
  and fabricated experience — it has **no row for intra-document factual self-contradiction**, so
  this cannot be cited and is therefore not a finding.
- **Possible tension, re-request policy.** L37-39 says the ported early-return means "a denied user
  can never request again, ever" and frames it as undecided; L84-85 states as settled rule that
  "`denied` does not permanently bar a re-request." Same gap: no catalog row.

---

## Handbook return line (discharged here; the dispatcher requested a different token)

`FINDINGS | .claude/workforce/work/2026-07-31-05/content-text-evaluator/OUTPUT.md | 5 findings, 0 uncited. F1 em-dash [hard] MUST FIX — 28 in 1,766 words vs a ≤1-per-5,000 target. F2/F3 markdown-chat formatting (SHOULD FIX), F4 contrastive negation ×9 (MUST FIX), F5 personification ×2 (SHOULD FIX). 6 human-presence markers: over-correction warning surfaced. All corpus-level rows and both catalog agents UNRUN — disallowedTools: Agent.`
