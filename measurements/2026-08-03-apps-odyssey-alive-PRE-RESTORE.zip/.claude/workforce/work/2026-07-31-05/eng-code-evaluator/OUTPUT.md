# eng-code-evaluator — run 2026-07-31-05

**Artifact reviewed:** `.claude/skills/code-evaluator/references/mistake-taxonomy.md`
**Verdict:** BLOCKED — the task as written cannot be satisfied from this catalog.

## The requested finding cannot be produced

The work order asks for "the three mistake classes it treats as most severe, each cited to its
heading." **`mistake-taxonomy.md` has no severity axis.** Read in full (138 lines), it contains:

- Two class tables — `## Group 1 — Structural (the classic taxonomy)` (12 classes) and
  `## Group 2 — AI-specific anti-patterns` (12 classes). Both tables carry the columns
  *Class | What | Why it matters | Signal*. There is no severity column, no ordering claim, and
  no statement that any class outranks another. The header prose (lines 5–13) describes the two
  groups by *origin* — classic codebase-intelligence vs. AI-introduced — not by weight.
- `## The minimalism escalation ladder (prevention order — L1)` — explicitly a **prevention
  order**, i.e. which rung to try first when writing, not which mistake is worst.
- `## Over-engineering evaluation (rubric + self-calibration — L2/L3)` — a 0–3 score, and it
  scores *individual candidates* for one class (over-engineering), not the classes themselves.
- `## How the layers use this taxonomy` — assigns classes to layers (L1/L2/sweep), not severity.

The nearest severity-shaped statement in the file is `## Minimalism safety floor (NEVER on the
chopping block)`, which names five things a review must never recommend cutting and calls
flagging one of them "itself a defect." That is a rule about **reviewer error**, not a ranking of
the mistake classes, so it cannot answer "the three most severe" either.

Naming three classes anyway would mean inventing a ranking the source does not state. Per the
handbook's § Escalation ("do NOT guess and do NOT work around it"), no ranking is reported.

## Handbook defect this exposes

Handbook § Procedure step 5 (line 39): *"Report findings, each with its citation and the catalog's
own severity."* The catalog has no per-class severity to report. The § Probe "Correct result"
(line 72) inherits the same false premise.

Adjacent, and not a substitute: `cross-file-detection.md` § 3 defines HIGH/MEDIUM/LOW **confidence**
tiers — how sure the reviewer is that a candidate is really dead — which is a different axis from
severity and lives in a different file than the one this handbook points at.

`QUESTION: mistake-taxonomy.md ranks nothing by severity — which axis should "most severe" mean
(Group 1 vs Group 2, the L1 ladder's prevention order, the safety floor, or cross-file-detection.md's
confidence tiers), or should the catalog gain a severity column?`

## Checks run

| Check | Result |
|---|---|
| Findings without a catalog citation (handbook § Verification 1) | **0** — zero findings reported; every claim above cites a heading or line range of `mistake-taxonomy.md` |
| Artifact read in full | yes, 138/138 lines |
| Severity axis present in the artifact | no |

## Catalog sections read / not read

**Read in full:** all of `mistake-taxonomy.md` — header prose; `## Group 1 — Structural (the
classic taxonomy)`; `## Group 2 — AI-specific anti-patterns`; `## The minimalism escalation ladder
(prevention order — L1)`; `## Minimalism safety floor (NEVER on the chopping block)`;
`## Over-engineering evaluation (rubric + self-calibration — L2/L3)`; `## How the layers use this
taxonomy`.

**Not read** (keyword-scanned with `grep` only, never read as prose): `cross-file-detection.md`,
`guards.md` (referenced by taxonomy rows for false-positive guards #7 and #21), `gotchas.md`,
`native-tool-map.md`, `SKILL.md`, `agents/code-design-advisor/AGENT.md`,
`agents/deadcode-gardener/AGENT.md`, `hooks/*.sh`. The handbook scopes this review to the taxonomy
file alone, so their contents were not used to fill the severity gap.

## Catalog-mandated checks NOT run (handbook § What this review does NOT cover)

`mistake-taxonomy.md` § How the layers use this taxonomy delegates work to agent-driven layers that
this employee cannot invoke — it carries `disallowedTools: Agent`, and the handbook forbids invoking
`/code-evaluator` as a skill:

- **L1 advisor (pre-write)** pass — not run.
- **L2 reviewer (post-write)** pass, incl. the cross-file detection sweep via
  `cross-file-detection.md` — not run.
- **Sweep (full codebase)** Group 1 pass — not run.
- The § Over-engineering evaluation **self-calibration gate** (score the `@lru_cache` /
  `ComputeCache` pair before trusting a read) — not run; no code diff was in scope this run.

Only a Lead or the main session can spawn the agents these require.
