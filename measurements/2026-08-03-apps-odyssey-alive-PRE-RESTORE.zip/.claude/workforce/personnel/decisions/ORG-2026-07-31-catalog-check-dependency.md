# ORG-2026-07-31-catalog-check-dependency

**Status:** accepted
**Raised by:** three consecutive probes of `content-copywriter`, run 2026-07-31

## The pattern, not the items

`## Verification` in `content-copywriter` has been amended **three times** in one run — the tier
collision, quoted-source tells, and now the FAIL mapping and the draft/report circularity. Each
amendment was correct and each probe found the next thing. `staging.md` § Phase B says two
consecutive fails on one section means the handbook is **structurally unclear rather than locally
wrong**, and this is that signal.

## The structural fact

**This employee's check depends on an artifact the org does not own.** `text-eval`'s catalog is a
customized companion (`audit-setup.md` § Three states) with:

- its own tier vocabulary, colliding with the verification ladder and the org tier;
- its own escalation ladder — CONSIDER / SHOULD FIX / MUST FIX — with **no FAIL rung**, while a
  handbook's `## Verification` must return PASS or FAIL;
- a `[hard]` class exempt from clustering, which interacts with quotation;
- **a broken internal link** — `text-tells.md` points at `../creative-integrity.md`, which resolves
  to a file that does not exist. The real file is under `skill-builder/references/`.

None of that is a defect in the handbook. All of it lands *in* the handbook, because the handbook is
where the two vocabularies meet.

## Decision

**Keep the dependency; make the seam explicit.** The alternative — restating the catalog's rules in
the handbook — is the two-canonical-texts failure this project refuses everywhere else, and the
catalog is the better document.

So the handbook now carries **one translation clause** rather than a growing list of edge rules: it
maps the catalog's ladder onto PASS/FAIL, scopes the count positively, and defers everything else.

## Not repaired, reported

The broken link is in `skill-builder`'s emission. `legacy-markers.md` § An unpaired marker is
REPORTED: never edit another generator's file — the owner rewrites it on its next run. Reported here
with both paths so a human can decide.

## What would change this decision

An evaluator **employee** owning the catalog (`evaluators.md`) would move this translation out of
every writer's handbook and into one place. That hire is deferred only because the catalog is
currently `catalog-unappendable` — no supersession register — so its owner could not yet own it.
