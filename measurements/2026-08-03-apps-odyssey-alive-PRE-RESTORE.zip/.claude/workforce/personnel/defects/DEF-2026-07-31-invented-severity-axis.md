# DEF-2026-07-31-invented-severity-axis

**Status:** open → amended
**Raised by:** probe (cold executor, run 2026-07-31-05, eng-code-evaluator) — **FAIL**
**Handbook:** `eng-code-evaluator`; the same line shipped in `content-text-evaluator`
**Section implicated:** § `## Procedure` step 5, and § `## Probe`

## The finding, verbatim

> § Procedure step 5 — "Report findings, each with its citation and the catalog's own severity."
> `mistake-taxonomy.md` has no severity axis: both class tables are *Class | What | Why it matters |
> Signal*, with no severity column, no ordering claim, and no statement that any class outranks
> another. The § Probe "Correct result" inherits the same false premise, so "the three most severe
> classes" cannot be produced without inventing a ranking the source does not state — which
> § Escalation forbids.

## Why the text permitted it

**I asserted a property of someone else's document.** Both evaluator handbooks were generated from one
template, and the template said *"the catalog's own severity."* That is true of `text-eval`, which
ships a CONSIDER / SHOULD FIX / MUST FIX ladder, and **false of the mistake taxonomy**, which ranks
nothing. One sentence, correct for one catalog, shipped to both.

The probe task then compounded it by *requiring* the ranking, so a correct execution had to either
invent one or fail. The executor failed, correctly, and cited the escalation rule while doing it.

**Attribution: DOCUMENT.** Principle 5 — never invent — and I inverted it: I invented a property of a
file I did not write, then asked an employee to read it out.

## Amendment

Step 5 now reads the severity **where the catalog states one**, and says so explicitly where it does
not. The probe asks for what the taxonomy actually contains — its classes and whether it declares any
ordering — which is answerable and tests the same skill.

## The general form, landed upstream

An evaluator's handbook must not assert *any* structural property of its catalog it has not read.
Severity ladders, confidence tiers, clustering rules, `[hard]` classes — each exists in some catalogs
and not others, and the handbook is where a wrong assumption becomes an unsatisfiable instruction.
