# DEF-2026-07-31-tier-overloaded

**Status:** open → amended
**Raised by:** probe (cold executor, run 2026-07-31-01, content-copywriter) — **AMBIGUOUS**
**Handbook:** `content-copywriter`, and by inheritance any handbook whose check greps a catalog
**Section implicated:** § `## Verification` step 1

## The question, verbatim

> Verification step 1 says "Grep the draft against the tells catalog at `.claude/skills/text-eval/` —
> a tier-3 mechanical check," but the catalog it names labels **Tier 1** as the "grep-able" surface
> tier and labels **Tier 3** as "Compositional tells (judgment class ... not regex)" — while this
> handbook's own ORG-RECORD separately assigns me `tier: 3 (IC)`. Does "tier-3" mean the catalog's
> Tier 3 (in which case "grep the draft" is not a runnable instruction, since that tier is explicitly
> not regex), or does it mean "a mechanical check of the kind a tier-3 IC runs" (in which case the
> tier to grep is the catalog's Tier 1)? And relatedly, in "Three or more clustered tells is a FAIL,"
> what makes tells *clustered* — same family, same paragraph, or the catalog's own cluster-scoring
> rule?

## Why the text permitted this

**Three tier vocabularies collide in one sentence**, and nothing disambiguated them:

| Vocabulary | "tier 3" means |
|---|---|
| `verification.md`'s ladder | a file/string assertion — a grep against a catalog |
| the `text-eval` catalog | compositional tells, **explicitly not regex** |
| the `ORG-RECORD` | the employee's org tier (IC) |

Read against the catalog it names, my sentence instructed a grep of the one tier that cannot be
grepped. **Attribution: DOCUMENT.** The executor was right to stop.

## Amendment

The handbook no longer says "tier-3". It names the catalog section to grep, by heading, and defers
the clustering rule to the catalog rather than inventing a threshold. Verification ladder numbers are
a vocabulary for *authoring* a handbook, not for instructing an executor who is holding a different
document that numbers its own tiers.
