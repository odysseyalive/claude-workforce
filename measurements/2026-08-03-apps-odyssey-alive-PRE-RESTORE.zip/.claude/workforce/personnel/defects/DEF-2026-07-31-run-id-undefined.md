# DEF-2026-07-31-run-id-undefined

**Status:** open → amended
**Raised by:** probe (cold executor, run 2026-07-31-01, eng-scaffolder)
**Handbook:** all five staged handbooks — and `workforce/references/handbook-templates.md`
**Section implicated:** § `## Reporting`

## The observation, verbatim

> "the handbook's § Reporting says `.claude/workforce/work/<run-id>/eng-scaffolder/OUTPUT.md` but
> never defines how `<run-id>` is formed or where it comes from. An agent run from the handbook alone
> would have had to invent a run-id."

## Why this did not surface as AMBIGUOUS

**Because the probe harness supplied the full path.** The executor never had to derive it, so the gap
was masked by the dispatch rather than closed by the text. A real work order that omitted the path
would have produced either an invented run-id or a stop.

This is the sharper version of the finding: **a probe can pass because the harness was generous.**

## Why the text permitted it

`org.md` § Canonical Dispatch CHECKPOINT clause 6 requires every dispatch payload to carry the
artifact path — so the caller owns the run-id and the handbook never needed to derive one. That
contract is real and the handbook simply never said it. **Attribution: DOCUMENT, by omission.**

## Amendment

Every `## Reporting` section now states that the run-id arrives in the work order, and that a missing
one is a `QUESTION:` rather than something to invent. The shipped template carries the same sentence,
because every handbook this project ever generates inherits the gap otherwise.
