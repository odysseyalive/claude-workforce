# DEF-2026-07-31-imagemaker-exit-criteria

**Status:** open → amended
**Raised by:** probe (cold executor, run 2026-07-31-01)
**Handbook:** `.claude/workforce/staging/agents/content-imagemaker.md`
**Section implicated:** § `## Exit criteria`, § `## Verification`

## The question, verbatim

> `## Exit criteria` — "The image exists at its stated path and its catalog check is stated."
> Unsatisfiable for the handbook's own Probe, which asks for a colour list and produces no image;
> likewise Verification step 1's mandatory `image-eval` check for "generation tells and
> graphic-system drift" has no subject.

## Why the text permitted this

Both sections were written as though **every** work order produces an image. Reading the palette to
answer a question about the graphic system is squarely inside this employee's `## Scope` and produces
no image, so a correct execution cannot satisfy the stated exit criteria. The executor did the work
correctly — all 14 declared hexes cited to `palette.md` — and then could not report PASS.

**Attribution: DOCUMENT.** The handbook did not cover a case its own scope admits.

## Amendment

`## Verification` and `## Exit criteria` now branch on what the work order produced: an image is
checked against the catalog; a written answer about the system is checked by citation. The probe is
unchanged — it was the handbook that was narrow, not the probe that was wrong.
