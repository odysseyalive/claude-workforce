# DEF-2026-07-31-quoted-source-tells

**Status:** open → amended
**Raised by:** probe (cold executor, run 2026-07-31-02, content-copywriter) — volunteered on a PASS
**Handbook:** `content-copywriter`; the rule generalizes to every catalog-grep check
**Section implicated:** § `## Verification`

## The observation, verbatim

> "I hit this edge exactly (two em-dashes survive inside verbatim quotations) and resolved it by
> holding authored prose at zero, but the handbook gives no rule for quoted-source characters."

## Why the text permitted it

The check says grep *the draft*. A draft that quotes a source carries that source's punctuation, and
em-dash overuse ships `[hard]` in this catalog — **actionable at first occurrence, not subject to
clustering.** So a faithful quotation fails the writer for the source's habits, and the only way past
it is to misquote.

The executor resolved it correctly and reported that the handbook did not tell it to.
**Attribution: DOCUMENT, by omission.**

## Amendment

The exclusion list is now stated as a class rather than a single case: **count authored prose.** Not
the report about the draft, not verbatim quotation, not code or path literals. Each is a place the
catalog's own tells appear without the writer having chosen them.

## Why this is not a loophole

The excluded spans are *identifiable* — quotation marks, fences, backticks — and the rule says to
report what was excluded and why. An exclusion that cannot be pointed at is a way to pass; one that
is named in the report is a measurement.
